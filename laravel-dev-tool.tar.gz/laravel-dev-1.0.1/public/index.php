<?php

declare(strict_types=1);

$baseDir = realpath(__DIR__ . '/..') ?: dirname(__DIR__);
$home = getenv('HOME') ?: ($_SERVER['HOME'] ?? '');

$systemConfigFile = $baseDir . '/config/config.env';
$userConfigDir = $home . '/.config/laravel-dev';
$userConfigFile = $userConfigDir . '/config.env';
$activityLogFile = $userConfigDir . '/activity.log';

function h(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function allowed_views(): array
{
    return ['dashboard', 'projects', 'create', 'link', 'services', 'settings', 'logs'];
}

function normalize_view(?string $view): string
{
    $view = strtolower(trim((string)$view));
    return in_array($view, allowed_views(), true) ? $view : 'dashboard';
}

function view_for_action(string $action): string
{
    return match ($action) {
        'create' => 'create',
        'link' => 'link',
        'services_start', 'services_stop', 'optional_service_start', 'optional_service_stop' => 'services',
        'save_settings' => 'settings',
        'configure_db', 'apply_global_db', 'add_cron', 'remove_cron', 'repair', 'delete' => 'projects',
        default => 'dashboard',
    };
}

function current_view_input(string $view): string
{
    return '<input type="hidden" name="return_view" value="' . h($view) . '">';
}

function view_url(string $view): string
{
    return '?view=' . rawurlencode($view);
}

function parse_config_file(string $configFile, array $settings): array
{
    if (!is_file($configFile)) {
        return $settings;
    }

    $lines = file($configFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return $settings;
    }

    $home = getenv('HOME') ?: '';

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        $parts = explode('=', $line, 2);
        if (count($parts) !== 2) {
            continue;
        }

        $key = trim($parts[0]);
        $val = trim($parts[1], " \t\n\r\0\x0B\"");

        if (!array_key_exists($key, $settings)) {
            continue;
        }

        $val = str_replace('$HOME', $home, $val);
        $val = str_replace('$USER', get_current_user(), $val);

        $settings[$key] = $val;
    }

    return $settings;
}

function read_settings(string $systemConfigFile, string $userConfigFile): array
{
    $home = getenv('HOME') ?: '/home';
    $defaults = [
        'SITES_DIR' => $home . '/Sites',
        'DB_HOST' => '127.0.0.1',
        'DB_PORT' => '3306',
        'DB_USER' => getenv('USER') ?: 'root',
        'DB_PASSWORD' => '',
        'DB_TYPE' => 'mysql',
        'WEB_PORT' => '4040',
    ];

    $settings = parse_config_file($systemConfigFile, $defaults);
    $settings = parse_config_file($userConfigFile, $settings);

    return $settings;
}

function write_settings(string $userConfigFile, array $settings): bool
{
    $dir = dirname($userConfigFile);
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }

    $content = "# Laravel Dev user settings - auto-generated, do not edit manually\n";
    foreach (['SITES_DIR', 'DB_HOST', 'DB_PORT', 'DB_USER', 'DB_PASSWORD', 'DB_TYPE', 'WEB_PORT'] as $key) {
        $value = str_replace('"', '\\"', $settings[$key] ?? '');
        $content .= $key . '="' . $value . '"' . "\n";
    }

    return file_put_contents($userConfigFile, $content) !== false;
}

function run_cmd(string $command): array
{
    $output = [];
    $code = 0;
    exec($command . ' 2>&1', $output, $code);
    return ['code' => $code, 'output' => implode("\n", $output)];
}

function command_lines(string $command): array
{
    $result = run_cmd($command);
    if ($result['code'] !== 0 || trim($result['output']) === '') {
        return [];
    }

    $lines = preg_split('/\R+/', trim($result['output'])) ?: [];
    return array_values(array_filter(array_map('trim', $lines), static fn(string $line): bool => $line !== ''));
}

function has_passwordless_sudo(): bool
{
    $code = 1;
    exec('sudo -n true >/dev/null 2>&1', $out, $code);
    return $code === 0;
}

function get_askpass_helper(): string
{
    $candidates = [
        getenv('SUDO_ASKPASS') ?: '',
        '/usr/bin/ssh-askpass',
        '/usr/bin/ssh-askpass-fullscreen',
        '/usr/bin/ksshaskpass',
        '/usr/lib/ssh/ssh-askpass',
        '/usr/libexec/openssh/gnome-ssh-askpass',
    ];

    foreach ($candidates as $bin) {
        if ($bin !== '' && is_executable($bin)) {
            return $bin;
        }
    }

    return '';
}

function has_askpass_helper(): bool
{
    return get_askpass_helper() !== '';
}

function sudo_help_message(): string
{
    return "This action needs sudo.\nRun in terminal: sudo -v\nOr configure passwordless sudo / install askpass package (ssh-askpass / openssh-askpass).";
}

function run_sudo_cmd(string $command): array
{
    if (has_passwordless_sudo()) {
        return run_cmd('sudo -n ' . $command);
    }

    $askpass = get_askpass_helper();
    if ($askpass !== '') {
        return run_cmd('SUDO_ASKPASS=' . escapeshellarg($askpass) . ' sudo -A ' . $command);
    }

    return ['code' => 1, 'output' => sudo_help_message()];
}

function service_status(string $service): string
{
    $status = trim(shell_exec('systemctl is-active ' . escapeshellarg($service) . ' 2>/dev/null') ?? '');
    if ($status === '') {
        $status = trim(shell_exec('sudo -n systemctl is-active ' . escapeshellarg($service) . ' 2>/dev/null') ?? '');
    }
    return $status !== '' ? $status : 'unknown';
}

function status_class(string $status): string
{
    return match ($status) {
        'active' => 'ok',
        'inactive', 'failed' => 'bad',
        default => 'warn',
    };
}

function status_label(string $status): string
{
    return match ($status) {
        'active' => 'Healthy',
        'inactive' => 'Stopped',
        'failed' => 'Failed',
        'unknown' => 'Unknown',
        default => ucfirst($status),
    };
}

function read_project_env(string $envFile): array
{
    $keys = ['DB_CONNECTION', 'DB_HOST', 'DB_PORT', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD'];
    $values = array_fill_keys($keys, '');

    if (!is_file($envFile)) {
        return $values;
    }

    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return $values;
    }

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        $parts = explode('=', $line, 2);
        if (count($parts) !== 2) {
            continue;
        }
        $key = trim($parts[0]);
        $val = trim($parts[1], " \t\n\r\0\x0B\"");
        if (array_key_exists($key, $values)) {
            $values[$key] = $val;
        }
    }

    return $values;
}

function update_project_env_keys(string $envFile, array $updates): bool
{
    if (!is_file($envFile)) {
        return false;
    }

    $content = file_get_contents($envFile);
    if ($content === false) {
        return false;
    }

    foreach ($updates as $key => $value) {
        $pattern = '/^' . preg_quote($key, '/') . '=.*/m';
        if (preg_match($pattern, $content)) {
            $content = preg_replace($pattern, $key . '=' . $value, $content) ?? $content;
        } else {
            $content = rtrim($content) . "\n" . $key . '=' . $value . "\n";
        }
    }

    return file_put_contents($envFile, $content) !== false;
}

function detect_optional_services(): array
{
    $candidates = [
        ['name' => 'Mailpit', 'binary' => 'mailpit', 'unit' => 'mailpit'],
        ['name' => 'Meilisearch', 'binary' => 'meilisearch', 'unit' => 'meilisearch'],
        ['name' => 'MinIO', 'binary' => 'minio', 'unit' => 'minio'],
    ];

    $found = [];
    foreach ($candidates as $svc) {
        $out = [];
        $code = 1;
        exec('which ' . escapeshellarg($svc['binary']) . ' 2>/dev/null', $out, $code);
        if ($code === 0) {
            $svc['status'] = service_status($svc['unit']);
            $found[] = $svc;
        }
    }
    return $found;
}

function ensure_service_unit(string $unit): string
{
    $templates = [
        'mailpit' => [
            'description' => 'Mailpit - local mail catcher',
            'binary' => 'mailpit',
        ],
        'meilisearch' => [
            'description' => 'Meilisearch - full-text search engine',
            'binary' => 'meilisearch',
        ],
        'minio' => [
            'description' => 'MinIO - S3-compatible object storage',
            'binary' => 'minio',
        ],
    ];

    if (!isset($templates[$unit])) {
        return '';
    }

    $listed = [];
    exec('systemctl list-unit-files --type=service --no-legend 2>/dev/null', $listed);
    foreach ($listed as $line) {
        if (str_starts_with(trim($line), $unit . '.service')) {
            return '';
        }
    }

    $binaryOut = [];
    $binaryCode = 1;
    exec('which ' . escapeshellarg($templates[$unit]['binary']) . ' 2>/dev/null', $binaryOut, $binaryCode);
    if ($binaryCode !== 0 || empty($binaryOut[0])) {
        return "Binary '{$templates[$unit]['binary']}' not found in PATH.";
    }
    $binaryPath = trim($binaryOut[0]);

    $desc = $templates[$unit]['description'];
    $unitContent = "[Unit]\nDescription={$desc}\nAfter=network.target\n\n"
        . "[Service]\nExecStart={$binaryPath}\nRestart=on-failure\nRestartSec=5\n\n"
        . "[Install]\nWantedBy=multi-user.target\n";

    $tmpFile = tempnam(sys_get_temp_dir(), 'laravel_unit_');
    if ($tmpFile === false || file_put_contents($tmpFile, $unitContent) === false) {
        return 'Failed to create temporary unit file.';
    }

    $unitFile = '/etc/systemd/system/' . $unit . '.service';
    $copyResult = run_sudo_cmd('cp ' . escapeshellarg($tmpFile) . ' ' . escapeshellarg($unitFile));
    unlink($tmpFile);

    if ($copyResult['code'] !== 0) {
        return "Failed to install unit file at {$unitFile}: " . $copyResult['output'];
    }

    $reloadResult = run_sudo_cmd('systemctl daemon-reload');
    if ($reloadResult['code'] !== 0) {
        return 'Unit file written but daemon-reload failed: ' . $reloadResult['output'];
    }

    return '';
}

function read_project_crons(string $projectPath): array
{
    $lines = [];
    exec('crontab -l 2>/dev/null', $lines);
    return array_values(array_filter($lines, static function (string $line) use ($projectPath): bool {
        $trimmed = trim($line);
        return $trimmed !== '' && !str_starts_with($trimmed, '#') && str_contains($trimmed, $projectPath);
    }));
}

function build_activity_entry(string $action, string $status, string $message, string $output = '', array $context = []): array
{
    return [
        'timestamp' => date(DATE_ATOM),
        'action' => $action,
        'status' => $status,
        'message' => $message,
        'output' => $output,
        'context' => $context,
    ];
}

function append_activity_log(string $logFile, array $entry): array
{
    $dir = dirname($logFile);
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        return ['ok' => false, 'error' => 'Failed to create log directory at ' . $dir];
    }

    $json = json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return ['ok' => false, 'error' => 'Failed to encode activity log entry.'];
    }

    if (file_put_contents($logFile, $json . PHP_EOL, FILE_APPEND | LOCK_EX) === false) {
        return ['ok' => false, 'error' => 'Failed to write activity log at ' . $logFile];
    }

    return ['ok' => true, 'error' => ''];
}

function read_activity_logs(string $logFile, int $limit = 80): array
{
    if (!is_file($logFile)) {
        return [];
    }

    $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return [];
    }

    $entries = [];
    foreach (array_reverse($lines) as $line) {
        $decoded = json_decode($line, true);
        if (is_array($decoded)) {
            $entries[] = $decoded;
        }
        if (count($entries) >= $limit) {
            break;
        }
    }

    return $entries;
}

function metric_number(int $value): string
{
    return number_format($value);
}

$settings = read_settings($systemConfigFile, $userConfigFile);
$sitesDir = $settings['SITES_DIR'];
$cli = escapeshellarg($baseDir . '/bin/laravel-dev');
$baseEnv = 'LARAVEL_DEV_BASE_DIR=' . escapeshellarg($baseDir) . ' ';
$availablePhpVersions = command_lines($baseEnv . $cli . ' php-versions');
if ($availablePhpVersions === []) {
    $availablePhpVersions = ['8.4'];
}
$defaultPhpVersion = $availablePhpVersions[count($availablePhpVersions) - 1];
$phpFpmServices = command_lines($baseEnv . $cli . ' php-fpm-services');

$message = '';
$error = '';
$commandLog = '';
$logNotice = '';
$action = '';
$actionTarget = '';
$currentView = normalize_view($_GET['view'] ?? 'dashboard');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim((string)($_POST['action'] ?? ''));
    $currentView = normalize_view($_POST['return_view'] ?? view_for_action($action));
    $needsSudo = in_array($action, ['create', 'delete', 'repair', 'services_start', 'services_stop', 'optional_service_start', 'optional_service_stop'], true);

    if ($needsSudo && !has_passwordless_sudo() && !has_askpass_helper()) {
        $error = sudo_help_message();
    }

    if ($error === '' && $action === 'create') {
        $name = trim($_POST['project_name'] ?? '');
        $phpVersion = trim($_POST['php_version'] ?? $defaultPhpVersion);
        $actionTarget = $name;

        if (!preg_match('/^[a-z0-9][a-z0-9-]*$/', $name)) {
            $error = 'Invalid project name. Use lowercase letters, numbers, and dash only.';
        } elseif (!in_array($phpVersion, $availablePhpVersions, true)) {
            $error = 'Invalid PHP version.';
        } else {
            $cmd = $baseEnv . $cli . ' create ' . escapeshellarg($name) . ' ' . escapeshellarg($phpVersion);
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Project '$name' created successfully.";
            } else {
                $error = "Create failed for '$name'.";
            }
        }
    }

    if ($error === '' && $action === 'delete') {
        $name = trim($_POST['project_name'] ?? '');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } else {
            $cmd = $baseEnv . $cli . ' delete ' . escapeshellarg($name);
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Project '$name' deleted.";
            } else {
                $error = "Delete failed for '$name'.";
            }
        }
    }

    if ($error === '' && $action === 'repair') {
        $name = trim($_POST['project_name'] ?? '');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } else {
            $cmd = $baseEnv . $cli . ' repair ' . escapeshellarg($name);
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Project '$name' repaired.";
            } else {
                $error = "Repair failed for '$name'.";
            }
        }
    }

    if ($error === '' && $action === 'services_start') {
        $actionTarget = 'core-services';
        $result = run_cmd($baseEnv . $cli . ' start');
        $commandLog = $result['output'];
        $result['code'] === 0 ? $message = 'Services started.' : $error = 'Failed to start services.';
    }

    if ($error === '' && $action === 'services_stop') {
        $actionTarget = 'core-services';
        $result = run_cmd($baseEnv . $cli . ' stop');
        $commandLog = $result['output'];
        $result['code'] === 0 ? $message = 'Services stopped.' : $error = 'Failed to stop services.';
    }

    if ($error === '' && $action === 'link') {
        $name = trim($_POST['project_name'] ?? '');
        $path = trim($_POST['project_path'] ?? '');
        $phpVersion = trim($_POST['php_version'] ?? $defaultPhpVersion);
        $actionTarget = $name !== '' ? $name : $path;

        if ($name === '' || $path === '') {
            $error = 'Project name and path are required.';
        } elseif (!preg_match('/^[a-z0-9][a-z0-9-]*$/', $name)) {
            $error = 'Invalid project name. Use lowercase, numbers, dash only.';
        } else {
            $cmd = $baseEnv . $cli . ' link ' . escapeshellarg($name) . ' ' . escapeshellarg($path) . ' ' . escapeshellarg($phpVersion);
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Project '$name' linked successfully from $path.";
            } else {
                $error = "Linking failed for '$name'.";
            }
        }
    }

    if ($action === 'save_settings') {
        $actionTarget = 'global-settings';
        $allowedDbTypes = ['mysql', 'mariadb', 'pgsql', 'sqlite'];
        $newSettings = [
            'SITES_DIR' => trim($_POST['sites_dir'] ?? $sitesDir),
            'DB_HOST' => trim($_POST['db_host'] ?? '127.0.0.1'),
            'DB_PORT' => trim($_POST['db_port'] ?? '3306'),
            'DB_USER' => trim($_POST['db_user'] ?? (getenv('USER') ?: 'root')),
            'DB_PASSWORD' => (string)($_POST['db_password'] ?? ''),
            'DB_TYPE' => trim($_POST['db_type'] ?? 'mysql'),
            'WEB_PORT' => trim($_POST['web_port'] ?? '4040'),
        ];

        if (!preg_match('/^[0-9]{2,5}$/', $newSettings['WEB_PORT'])) {
            $error = 'Invalid dashboard port.';
        } elseif ($newSettings['SITES_DIR'] === '') {
            $error = 'Sites directory cannot be empty.';
        } elseif (!preg_match('/^[0-9]{1,5}$/', $newSettings['DB_PORT'])) {
            $error = 'Invalid database port.';
        } elseif (!in_array($newSettings['DB_TYPE'], $allowedDbTypes, true)) {
            $error = 'Invalid database type.';
        } elseif (write_settings($userConfigFile, $newSettings)) {
            $settings = $newSettings;
            $sitesDir = $settings['SITES_DIR'];
            $message = 'Settings saved to ~/.config/laravel-dev/config.env';
        } else {
            $error = 'Failed to write settings. Check permissions on ~/.config/laravel-dev/';
        }
    }

    if ($error === '' && $action === 'configure_db') {
        $name = trim($_POST['project_name'] ?? '');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } else {
            $projectDir = is_dir($sitesDir . '/' . $name) ? $sitesDir . '/' . $name : '';
            $envFile = $projectDir !== '' ? $projectDir . '/.env' : '';

            if ($envFile === '' || !is_file($envFile)) {
                $error = "Cannot find .env for project '$name'. Make sure the project directory exists.";
            } else {
                $dbConnection = trim($_POST['db_connection'] ?? 'mysql');
                $dbHost = trim($_POST['db_host'] ?? '127.0.0.1');
                $dbPort = trim($_POST['db_port'] ?? '3306');
                $dbDatabase = trim($_POST['db_database'] ?? $name);
                $dbUsername = trim($_POST['db_username'] ?? '');
                $dbPassword = (string)($_POST['db_password'] ?? '');

                $updates = [
                    'DB_CONNECTION' => $dbConnection,
                    'DB_HOST' => $dbHost,
                    'DB_PORT' => $dbPort,
                    'DB_DATABASE' => $dbDatabase,
                    'DB_USERNAME' => $dbUsername,
                    'DB_PASSWORD' => $dbPassword,
                ];

                if (update_project_env_keys($envFile, $updates)) {
                    $message = "Database settings updated for '$name'.";
                } else {
                    $error = "Failed to update .env for '$name'. Check file permissions.";
                }
            }
        }
    }

    if ($error === '' && $action === 'apply_global_db') {
        $name = trim($_POST['project_name'] ?? '');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } else {
            $cmd = $baseEnv . $cli . ' configure-db ' . escapeshellarg($name);
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Global DB settings applied to '$name'.";
            } else {
                $error = "Failed to apply DB settings to '$name'.";
            }
        }
    }

    if ($error === '' && $action === 'optional_service_start') {
        $unit = trim($_POST['service_unit'] ?? '');
        $actionTarget = $unit;
        if (!preg_match('/^[a-z0-9_\-\.]+$/', $unit)) {
            $error = 'Invalid service name.';
        } else {
            $unitErr = ensure_service_unit($unit);
            if ($unitErr !== '') {
                $error = $unitErr;
            } else {
                $result = run_sudo_cmd('systemctl start ' . escapeshellarg($unit));
                $commandLog = $result['output'];
                $result['code'] === 0
                    ? $message = "Service '$unit' started."
                    : $error = "Failed to start '$unit': " . $result['output'];
            }
        }
    }

    if ($error === '' && $action === 'optional_service_stop') {
        $unit = trim($_POST['service_unit'] ?? '');
        $actionTarget = $unit;
        if (!preg_match('/^[a-z0-9_\-\.]+$/', $unit)) {
            $error = 'Invalid service name.';
        } else {
            $result = run_sudo_cmd('systemctl stop ' . escapeshellarg($unit));
            $commandLog = $result['output'];
            $result['code'] === 0 ? $message = "Service '$unit' stopped." : $error = "Failed to stop '$unit'.";
        }
    }

    if ($error === '' && $action === 'add_cron') {
        $projectPath = trim($_POST['project_path'] ?? '');
        $schedule = trim($_POST['cron_schedule'] ?? '* * * * *');
        $command = trim($_POST['cron_command'] ?? '');
        $actionTarget = $projectPath;

        if ($projectPath === '' || $command === '') {
            $error = 'Project path and command are required.';
        } elseif (!preg_match('/^[\*0-9,\-\/\s]+$/', $schedule) || substr_count($schedule, ' ') < 4) {
            $error = 'Invalid cron schedule. Use five space-separated fields (e.g. * * * * *).';
        } else {
            $cronLine = $schedule . ' cd ' . $projectPath . ' && ' . $command;
            $cmd = '(crontab -l 2>/dev/null; echo ' . escapeshellarg($cronLine) . ') | crontab -';
            exec($cmd, $out, $code);
            $commandLog = implode("\n", $out);
            if ($code === 0) {
                $message = 'Cron job added.';
            } else {
                $error = 'Failed to add cron job. Check that crontab is available.';
            }
        }
    }

    if ($error === '' && $action === 'remove_cron') {
        $cronLine = trim($_POST['cron_line'] ?? '');
        $actionTarget = $cronLine;
        if ($cronLine === '') {
            $error = 'No cron line specified.';
        } else {
            $current = [];
            exec('crontab -l 2>/dev/null', $current);
            $filtered = array_filter($current, static fn(string $line): bool => trim($line) !== $cronLine);
            $newContent = implode("\n", $filtered);
            if ($newContent !== '') {
                $newContent .= "\n";
            }
            $tmpFile = tempnam(sys_get_temp_dir(), 'laravel_cron_');
            if ($tmpFile === false) {
                $error = 'Could not create temp file for crontab.';
            } else {
                file_put_contents($tmpFile, $newContent);
                exec('crontab ' . escapeshellarg($tmpFile), $out2, $code2);
                unlink($tmpFile);
                $commandLog = implode("\n", $out2);
                $code2 === 0 ? $message = 'Cron job removed.' : $error = 'Failed to remove cron job.';
            }
        }
    }

    if ($action !== '') {
        $status = $error !== '' ? 'error' : 'success';
        $summary = $error !== '' ? $error : ($message !== '' ? $message : 'Action completed.');
        $logResult = append_activity_log($activityLogFile, build_activity_entry(
            $action,
            $status,
            $summary,
            $commandLog,
            [
                'target' => $actionTarget,
                'view' => $currentView,
            ]
        ));

        if (!$logResult['ok']) {
            $logNotice = $logResult['error'];
        }
    }
}

$projects = [];
$sites = is_dir($sitesDir) ? (glob($sitesDir . '/*', GLOB_ONLYDIR) ?: []) : [];
foreach ($sites as $site) {
    $projects[basename($site)] = $site;
}

$nginxPaths = ['/etc/nginx/sites-enabled', '/etc/nginx/http.d', '/etc/nginx/conf.d'];
foreach ($nginxPaths as $nginxPath) {
    if (!is_dir($nginxPath)) {
        continue;
    }

    $configs = glob($nginxPath . '/*');
    if ($configs === false) {
        continue;
    }

    foreach ($configs as $config) {
        $name = basename($config);
        if (str_ends_with($name, '.conf')) {
            $name = substr($name, 0, -5);
        }

        if (isset($projects[$name]) || in_array($name, ['default', 'laravel-dev-tool'], true)) {
            continue;
        }

        $content = @file_get_contents($config);
        if ($content && preg_match('/root\s+([^;]+)\/public;/', $content, $matches)) {
            $projects[$name] = $matches[1];
        }
    }
}
ksort($projects);

$mysqlUnit = service_status('mysql') !== 'unknown' ? 'mysql' : 'mariadb';
$services = [
    'nginx' => service_status('nginx'),
    $mysqlUnit => service_status($mysqlUnit),
];

foreach ($phpFpmServices as $service) {
    $services[$service] = service_status($service);
}

$optionalServices = detect_optional_services();
$activityLogs = read_activity_logs($activityLogFile, 60);
$latestActivity = $activityLogs[0] ?? null;

$projectCount = count($projects);
$coreActiveCount = count(array_filter($services, static fn(string $status): bool => $status === 'active'));
$coreInactiveCount = count($services) - $coreActiveCount;
$optionalActiveCount = count(array_filter($optionalServices, static fn(array $service): bool => ($service['status'] ?? '') === 'active'));
$optionalInstalledCount = count($optionalServices);
$activeViewTitle = [
    'dashboard' => 'Dashboard',
    'projects' => 'Projects',
    'create' => 'Create Project',
    'link' => 'Link Existing Project',
    'services' => 'Services',
    'settings' => 'Settings',
    'logs' => 'Logs',
][$currentView];
$activeViewSubtitle = [
    'dashboard' => 'Overview, health signals, and quick actions.',
    'projects' => 'Inspect, repair, configure databases, and manage cron jobs.',
    'create' => 'Provision a new Laravel project with the selected PHP version.',
    'link' => 'Register an existing Laravel codebase inside Laravel Dev.',
    'services' => 'Monitor and control core and optional local services.',
    'settings' => 'Control default paths and database preferences.',
    'logs' => 'Review recent actions, failures, and command output.',
][$currentView];
$version = trim((string)@file_get_contents(dirname(__DIR__) . '/VERSION')) ?: '1.0.0';
$lastActionTone = is_array($latestActivity) ? (($latestActivity['status'] ?? 'info') === 'error' ? 'error' : 'success') : 'neutral';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Dev - Local Panel</title>
    <link rel="icon" type="image/svg+xml" href="logo.svg">
    <link rel="shortcut icon" href="logo.svg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            color-scheme: light dark;
            --font-sans: "Space Grotesk", system-ui, sans-serif;
            --font-mono: "IBM Plex Mono", ui-monospace, monospace;
            --sidebar-width: 280px;
            --radius-sm: 12px;
            --radius-md: 20px;
            --radius-lg: 28px;
            --shadow-soft: 0 18px 48px rgba(18, 34, 54, 0.12);
            --shadow-panel: 0 24px 56px rgba(10, 22, 38, 0.16);
            --bg: #f4efe6;
            --bg-accent: radial-gradient(circle at top left, rgba(213, 124, 49, 0.16), transparent 34%), radial-gradient(circle at bottom right, rgba(26, 113, 122, 0.12), transparent 32%);
            --surface: rgba(255, 250, 244, 0.86);
            --surface-strong: rgba(255, 255, 255, 0.94);
            --surface-alt: #ece2d3;
            --text: #1a2633;
            --muted: #6c7280;
            --border: rgba(76, 88, 104, 0.16);
            --border-strong: rgba(76, 88, 104, 0.22);
            --accent: #bd5b27;
            --accent-strong: #8f3f16;
            --accent-soft: rgba(189, 91, 39, 0.12);
            --brand: #0f766e;
            --brand-soft: rgba(15, 118, 110, 0.12);
            --ok: #0c8b63;
            --ok-soft: rgba(12, 139, 99, 0.12);
            --warn: #b7791f;
            --warn-soft: rgba(183, 121, 31, 0.14);
            --error: #c2413b;
            --error-soft: rgba(194, 65, 59, 0.12);
            --info: #2563eb;
            --info-soft: rgba(37, 99, 235, 0.12);
            --code-bg: #fff7eb;
        }

        :root[data-theme="dark"] {
            --shadow-soft: 0 18px 48px rgba(0, 0, 0, 0.32);
            --shadow-panel: 0 24px 56px rgba(0, 0, 0, 0.42);
            --bg: #11161c;
            --bg-accent: radial-gradient(circle at top left, rgba(222, 124, 43, 0.18), transparent 30%), radial-gradient(circle at bottom right, rgba(44, 169, 169, 0.16), transparent 28%);
            --surface: rgba(20, 28, 36, 0.88);
            --surface-strong: rgba(24, 33, 42, 0.96);
            --surface-alt: #1b242e;
            --text: #eef4ff;
            --muted: #9eaec0;
            --border: rgba(163, 184, 204, 0.12);
            --border-strong: rgba(163, 184, 204, 0.2);
            --accent: #ff9c55;
            --accent-strong: #ffb06d;
            --accent-soft: rgba(255, 156, 85, 0.14);
            --brand: #4fd1c5;
            --brand-soft: rgba(79, 209, 197, 0.14);
            --ok: #34d399;
            --ok-soft: rgba(52, 211, 153, 0.14);
            --warn: #f6c453;
            --warn-soft: rgba(246, 196, 83, 0.14);
            --error: #f87171;
            --error-soft: rgba(248, 113, 113, 0.14);
            --info: #60a5fa;
            --info-soft: rgba(96, 165, 250, 0.14);
            --code-bg: #18212c;
        }

        * { box-sizing: border-box; }

        html { scroll-behavior: smooth; }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: var(--font-sans);
            color: var(--text);
            background: var(--bg);
            background-image: var(--bg-accent);
        }

        a { color: inherit; text-decoration: none; }
        p { margin: 0; }
        h1, h2, h3, h4 { margin: 0; }
        code, pre { font-family: var(--font-mono); }

        .layout {
            display: grid;
            grid-template-columns: var(--sidebar-width) minmax(0, 1fr);
            min-height: 100vh;
        }

        .sidebar {
            position: sticky;
            top: 0;
            height: 100vh;
            padding: 28px 22px;
            border-right: 1px solid var(--border);
            background: rgba(255, 255, 255, 0.22);
            backdrop-filter: blur(22px);
        }

        :root[data-theme="dark"] .sidebar {
            background: rgba(11, 16, 23, 0.55);
        }

        .sidebar-inner {
            display: flex;
            flex-direction: column;
            gap: 22px;
            height: 100%;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .brand-badge {
            width: 52px;
            height: 52px;
            border-radius: 18px;
            box-shadow: var(--shadow-soft);
            overflow: hidden;
            flex-shrink: 0;
            border: 1px solid var(--border);
            background: var(--surface-strong);
        }

        .brand-badge img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .brand-title {
            font-size: 1.15rem;
            font-weight: 700;
            letter-spacing: -0.02em;
        }

        .brand-subtitle {
            color: var(--muted);
            font-size: 0.9rem;
            margin-top: 4px;
        }

        .nav-list {
            display: grid;
            gap: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 13px 14px;
            border-radius: 16px;
            color: var(--muted);
            border: 1px solid transparent;
            transition: 0.18s ease;
        }

        .nav-link:hover {
            background: var(--surface);
            color: var(--text);
            border-color: var(--border);
        }

        .nav-link.active {
            background: linear-gradient(135deg, var(--accent-soft), var(--brand-soft));
            color: var(--text);
            border-color: var(--border-strong);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.12);
        }

        .nav-icon {
            width: 34px;
            height: 34px;
            border-radius: 12px;
            background: var(--surface-strong);
            border: 1px solid var(--border);
            display: grid;
            place-items: center;
            font-size: 0.95rem;
        }

        .nav-text strong {
            display: block;
            font-size: 0.95rem;
        }

        .nav-text span {
            display: block;
            font-size: 0.78rem;
            color: var(--muted);
            margin-top: 3px;
        }

        .sidebar-footer {
            margin-top: auto;
            padding: 18px;
            border-radius: 20px;
            background: var(--surface);
            border: 1px solid var(--border);
        }

        .sidebar-footer h3 {
            font-size: 0.9rem;
            margin-bottom: 8px;
        }

        .sidebar-footer p {
            color: var(--muted);
            font-size: 0.84rem;
            line-height: 1.6;
        }

        .content {
            padding: 28px;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 24px;
        }

        .page-title {
            font-size: clamp(1.9rem, 2vw, 2.5rem);
            letter-spacing: -0.04em;
        }

        .page-subtitle {
            color: var(--muted);
            margin-top: 8px;
            max-width: 680px;
            line-height: 1.7;
        }

        .topbar-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .version-pill,
        .theme-toggle,
        .mobile-nav-toggle {
            border: 1px solid var(--border);
            background: var(--surface-strong);
            color: var(--text);
            border-radius: 999px;
            padding: 10px 14px;
            font: inherit;
            box-shadow: var(--shadow-soft);
        }

        .theme-toggle,
        .mobile-nav-toggle {
            cursor: pointer;
        }

        .mobile-nav-toggle {
            display: none;
        }

        .stack {
            display: grid;
            gap: 22px;
        }

        .alert {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            border-radius: var(--radius-md);
            padding: 16px 18px;
            border: 1px solid var(--border);
            background: var(--surface);
            box-shadow: var(--shadow-soft);
        }

        .alert strong {
            display: block;
            margin-bottom: 4px;
        }

        .alert.success { border-color: rgba(12, 139, 99, 0.24); background: linear-gradient(135deg, var(--ok-soft), var(--surface)); }
        .alert.error { border-color: rgba(194, 65, 59, 0.24); background: linear-gradient(135deg, var(--error-soft), var(--surface)); }
        .alert.warning { border-color: rgba(183, 121, 31, 0.24); background: linear-gradient(135deg, var(--warn-soft), var(--surface)); }

        .grid-metrics {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
        }

        .metric-card,
        .panel,
        .hero-card {
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            background: var(--surface);
            box-shadow: var(--shadow-panel);
        }

        .metric-card {
            padding: 20px;
        }

        .metric-label {
            font-size: 0.84rem;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .metric-value {
            margin-top: 12px;
            font-size: 2rem;
            font-weight: 700;
            letter-spacing: -0.04em;
        }

        .metric-note {
            margin-top: 10px;
            color: var(--muted);
            font-size: 0.92rem;
        }

        .hero-grid,
        .two-panel-grid,
        .services-grid {
            display: grid;
            grid-template-columns: repeat(12, minmax(0, 1fr));
            gap: 18px;
        }

        .hero-card {
            grid-column: span 8;
            padding: 26px;
            background: linear-gradient(135deg, var(--surface), rgba(255, 255, 255, 0.04));
        }

        .hero-card h2 {
            font-size: 1.5rem;
            letter-spacing: -0.03em;
        }

        .hero-card p {
            margin-top: 10px;
            color: var(--muted);
            line-height: 1.75;
        }

        .quick-actions {
            margin-top: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .hero-side {
            grid-column: span 4;
            display: grid;
            gap: 18px;
        }

        .mini-stat {
            padding: 20px;
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            background: var(--surface);
            box-shadow: var(--shadow-panel);
        }

        .mini-stat span {
            display: block;
            color: var(--muted);
            font-size: 0.84rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .mini-stat strong {
            display: block;
            margin-top: 12px;
            font-size: 1.5rem;
            letter-spacing: -0.04em;
        }

        .panel {
            overflow: hidden;
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            padding: 22px 24px 0;
        }

        .panel-title {
            font-size: 1.1rem;
            letter-spacing: -0.02em;
        }

        .panel-subtitle {
            color: var(--muted);
            margin-top: 6px;
            line-height: 1.6;
        }

        .panel-body {
            padding: 22px 24px 24px;
        }

        .dashboard-status-list,
        .service-list,
        .log-list {
            display: grid;
            gap: 12px;
        }

        .status-item,
        .service-item,
        .log-item,
        .project-card,
        .empty-state {
            border: 1px solid var(--border);
            background: var(--surface-strong);
            border-radius: 18px;
            padding: 16px 18px;
        }

        .status-item,
        .service-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
        }

        .status-meta strong,
        .service-meta strong,
        .log-item strong {
            display: block;
            font-size: 0.98rem;
        }

        .status-meta span,
        .service-meta span,
        .log-item small,
        .project-meta,
        .empty-state p {
            color: var(--muted);
            line-height: 1.6;
        }

        .status-pill,
        .log-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border-radius: 999px;
            padding: 8px 12px;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            border: 1px solid transparent;
            white-space: nowrap;
        }

        .tone-ok { color: var(--ok); background: var(--ok-soft); border-color: rgba(12, 139, 99, 0.2); }
        .tone-warn { color: var(--warn); background: var(--warn-soft); border-color: rgba(183, 121, 31, 0.22); }
        .tone-error { color: var(--error); background: var(--error-soft); border-color: rgba(194, 65, 59, 0.22); }
        .tone-info { color: var(--info); background: var(--info-soft); border-color: rgba(37, 99, 235, 0.22); }

        .button-row {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        button,
        .button-link {
            appearance: none;
            border: 0;
            border-radius: 14px;
            font: inherit;
            font-weight: 700;
            cursor: pointer;
            padding: 12px 16px;
            transition: transform 0.18s ease, box-shadow 0.18s ease, background 0.18s ease;
        }

        button:hover,
        .button-link:hover {
            transform: translateY(-1px);
        }

        .button-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-strong));
            color: white;
            box-shadow: 0 16px 30px rgba(189, 91, 39, 0.24);
        }

        .button-secondary {
            background: var(--surface-strong);
            color: var(--text);
            border: 1px solid var(--border);
        }

        .button-danger {
            background: linear-gradient(135deg, #d25549, #b93831);
            color: white;
            box-shadow: 0 16px 30px rgba(185, 56, 49, 0.22);
        }

        .button-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        form { display: grid; gap: 14px; }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }

        label {
            display: grid;
            gap: 8px;
            font-size: 0.88rem;
            font-weight: 700;
            color: var(--text);
        }

        .field-note {
            font-weight: 500;
            font-size: 0.8rem;
            color: var(--muted);
        }

        input,
        select,
        textarea {
            width: 100%;
            border-radius: 14px;
            border: 1px solid var(--border);
            background: var(--surface-strong);
            color: var(--text);
            font: inherit;
            padding: 13px 14px;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: rgba(37, 99, 235, 0.35);
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.12);
        }

        .helper-text {
            color: var(--muted);
            line-height: 1.7;
            font-size: 0.92rem;
        }

        .projects-list {
            display: grid;
            gap: 16px;
        }

        .project-card {
            display: grid;
            gap: 16px;
        }

        .project-head {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            align-items: flex-start;
        }

        .project-name {
            font-size: 1.05rem;
            font-weight: 700;
            letter-spacing: -0.02em;
        }

        .project-name a {
            color: var(--text);
        }

        .project-name a:hover {
            color: var(--accent);
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 999px;
            background: var(--info-soft);
            border: 1px solid rgba(37, 99, 235, 0.18);
            color: var(--info);
            font-size: 0.74rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-top: 8px;
        }

        .project-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        details {
            border: 1px solid var(--border);
            border-radius: 16px;
            background: var(--surface);
            overflow: hidden;
        }

        summary {
            list-style: none;
            cursor: pointer;
            padding: 15px 16px;
            font-weight: 700;
        }

        summary::-webkit-details-marker { display: none; }

        .details-body {
            padding: 0 16px 16px;
            display: grid;
            gap: 14px;
        }

        .cron-item {
            display: flex;
            gap: 10px;
            align-items: flex-start;
            justify-content: space-between;
            padding: 12px;
            border-radius: 14px;
            border: 1px solid var(--border);
            background: var(--surface-strong);
        }

        .code-block,
        .log-output {
            margin: 0;
            padding: 14px 16px;
            border-radius: 16px;
            background: var(--code-bg);
            border: 1px solid var(--border);
            overflow: auto;
            line-height: 1.7;
            font-size: 0.86rem;
            color: var(--text);
        }

        .log-item {
            display: grid;
            gap: 12px;
        }

        .log-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 14px;
        }

        .log-context {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .context-chip {
            padding: 6px 10px;
            border-radius: 999px;
            background: var(--surface);
            border: 1px solid var(--border);
            color: var(--muted);
            font-size: 0.78rem;
        }

        .split-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 360px;
            gap: 18px;
        }

        .empty-state {
            text-align: center;
            padding: 28px;
        }

        .empty-state h3 {
            margin-bottom: 8px;
            font-size: 1rem;
        }

        .muted-link {
            color: var(--accent);
            font-weight: 700;
        }

        @media (max-width: 1180px) {
            .grid-metrics { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .hero-card,
            .hero-side,
            .split-grid,
            .services-grid,
            .two-panel-grid { grid-template-columns: 1fr; }
            .hero-card,
            .hero-side { grid-column: span 12; }
        }

        @media (max-width: 940px) {
            .layout {
                grid-template-columns: 1fr;
            }

            .sidebar {
                position: fixed;
                inset: 0 auto 0 0;
                width: min(86vw, 320px);
                z-index: 20;
                transform: translateX(-100%);
                transition: transform 0.22s ease;
            }

            body.nav-open .sidebar {
                transform: translateX(0);
            }

            .mobile-nav-toggle {
                display: inline-flex;
            }

            .content {
                padding: 20px 16px 28px;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }
        }

        @media (max-width: 680px) {
            .grid-metrics,
            .form-grid {
                grid-template-columns: 1fr;
            }

            .topbar-actions,
            .project-head,
            .status-item,
            .service-item,
            .log-top,
            .cron-item {
                flex-direction: column;
                align-items: stretch;
            }

            button,
            .button-link {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<div class="layout">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-inner">
            <div class="brand">
                <div class="brand-badge">
                    <img src="logo.svg" alt="Laravel Dev logo">
                </div>
                <div>
                    <div class="brand-title">Laravel Dev</div>
                    <div class="brand-subtitle">Linux local control panel</div>
                </div>
            </div>

            <nav class="nav-list" aria-label="Sidebar">
                <?php
                $navItems = [
                    'dashboard' => ['icon' => '◎', 'title' => 'Dashboard', 'subtitle' => 'Overview & activity'],
                    'projects' => ['icon' => '▦', 'title' => 'Projects', 'subtitle' => 'Manage local apps'],
                    'create' => ['icon' => '＋', 'title' => 'Create Project', 'subtitle' => 'Scaffold a new app'],
                    'link' => ['icon' => '⇢', 'title' => 'Link Project', 'subtitle' => 'Bring existing code'],
                    'services' => ['icon' => '◌', 'title' => 'Services', 'subtitle' => 'Runtime health'],
                    'settings' => ['icon' => '⚙', 'title' => 'Settings', 'subtitle' => 'Paths and defaults'],
                    'logs' => ['icon' => '≡', 'title' => 'Logs', 'subtitle' => 'Errors and output'],
                ];
                foreach ($navItems as $view => $meta):
                ?>
                    <a class="nav-link <?= $currentView === $view ? 'active' : '' ?>" href="<?= h(view_url($view)) ?>">
                        <span class="nav-icon"><?= h($meta['icon']) ?></span>
                        <span class="nav-text">
                            <strong><?= h($meta['title']) ?></strong>
                            <span><?= h($meta['subtitle']) ?></span>
                        </span>
                    </a>
                <?php endforeach; ?>
            </nav>

            <div class="sidebar-footer">
                <h3>Current setup</h3>
                <p><?= h($projectCount) ?> project(s) discovered, <?= h($coreActiveCount) ?> core service(s) active, logs stored in <code><?= h($activityLogFile) ?></code>.</p>
            </div>
        </div>
    </aside>

    <main class="content">
        <div class="topbar">
            <div>
                <button class="mobile-nav-toggle" type="button" id="mobileNavToggle">Menu</button>
                <h1 class="page-title"><?= h($activeViewTitle) ?></h1>
                <p class="page-subtitle"><?= h($activeViewSubtitle) ?></p>
            </div>
            <div class="topbar-actions">
                <span class="version-pill">v<?= h($version) ?></span>
                <button class="theme-toggle" type="button" id="themeToggle">Theme</button>
            </div>
        </div>

        <div class="stack">
            <?php if ($message !== ''): ?>
                <div class="alert success" role="status">
                    <div>✓</div>
                    <div>
                        <strong>Action completed</strong>
                        <p><?= h($message) ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($error !== ''): ?>
                <div class="alert error" role="alert">
                    <div>!</div>
                    <div>
                        <strong>Action failed</strong>
                        <p><?= nl2br(h($error)) ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($logNotice !== ''): ?>
                <div class="alert warning" role="alert">
                    <div>!</div>
                    <div>
                        <strong>Log storage warning</strong>
                        <p><?= h($logNotice) ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($currentView === 'dashboard'): ?>
                <section class="grid-metrics">
                    <article class="metric-card">
                        <div class="metric-label">Projects</div>
                        <div class="metric-value"><?= h(metric_number($projectCount)) ?></div>
                        <div class="metric-note">Detected from <?= h($sitesDir) ?> and linked Nginx sites.</div>
                    </article>
                    <article class="metric-card">
                        <div class="metric-label">Core Services</div>
                        <div class="metric-value"><?= h(metric_number($coreActiveCount)) ?>/<?= h(metric_number(count($services))) ?></div>
                        <div class="metric-note"><?= h(metric_number($coreInactiveCount)) ?> service(s) need attention.</div>
                    </article>
                    <article class="metric-card">
                        <div class="metric-label">Optional Services</div>
                        <div class="metric-value"><?= h(metric_number($optionalActiveCount)) ?>/<?= h(metric_number($optionalInstalledCount)) ?></div>
                        <div class="metric-note">Installed extras like Mailpit, Meilisearch, or MinIO.</div>
                    </article>
                    <article class="metric-card">
                        <div class="metric-label">Last Operation</div>
                        <div class="metric-value"><?= is_array($latestActivity) ? h(strtoupper((string)($latestActivity['status'] ?? 'info'))) : 'NONE' ?></div>
                        <div class="metric-note"><?= is_array($latestActivity) ? h((string)($latestActivity['message'] ?? '')) : 'No activity recorded yet.' ?></div>
                    </article>
                </section>

                <section class="hero-grid">
                    <article class="hero-card">
                        <h2>Everything important is one click away.</h2>
                        <p>The dashboard now surfaces health, recent activity, and shortcuts first so the user can understand the environment before taking action. Use the quick actions below for the most common tasks.</p>
                        <div class="quick-actions">
                            <a class="button-link button-primary" href="<?= h(view_url('create')) ?>">Create Project</a>
                            <a class="button-link button-secondary" href="<?= h(view_url('projects')) ?>">Open Projects</a>
                            <a class="button-link button-secondary" href="<?= h(view_url('services')) ?>">Review Services</a>
                            <a class="button-link button-secondary" href="<?= h(view_url('logs')) ?>">Open Logs</a>
                        </div>
                    </article>
                    <div class="hero-side">
                        <article class="mini-stat">
                            <span>Log file</span>
                            <strong><?= is_file($activityLogFile) ? 'Ready' : 'Pending' ?></strong>
                            <p class="helper-text"><?= h($activityLogFile) ?></p>
                        </article>
                        <article class="mini-stat">
                            <span>Theme mode</span>
                            <strong>Auto + Manual</strong>
                            <p class="helper-text">Follows the system by default and stores the override in the browser.</p>
                        </article>
                    </div>
                </section>

                <section class="two-panel-grid">
                    <article class="panel" style="grid-column: span 7;">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Core service health</h2>
                                <p class="panel-subtitle">A quick read on Nginx, database, and PHP-FPM services.</p>
                            </div>
                            <a class="button-link button-secondary" href="<?= h(view_url('services')) ?>">Open Services</a>
                        </div>
                        <div class="panel-body">
                            <div class="dashboard-status-list">
                                <?php foreach ($services as $svcName => $svcStatus): ?>
                                    <?php $svcTone = status_class($svcStatus); ?>
                                    <div class="status-item">
                                        <div class="status-meta">
                                            <strong><?= h($svcName) ?></strong>
                                            <span><?= h(status_label($svcStatus)) ?></span>
                                        </div>
                                        <span class="status-pill tone-<?= h($svcTone === 'bad' ? 'error' : ($svcTone === 'warn' ? 'warn' : 'ok')) ?>"><?= h($svcStatus) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </article>

                    <article class="panel" style="grid-column: span 5;">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Latest activity</h2>
                                <p class="panel-subtitle">Recent success and error signals captured from actions in the panel.</p>
                            </div>
                            <a class="button-link button-secondary" href="<?= h(view_url('logs')) ?>">All Logs</a>
                        </div>
                        <div class="panel-body">
                            <?php if ($latestActivity !== null): ?>
                                <div class="log-item">
                                    <div class="log-top">
                                        <div>
                                            <strong><?= h((string)($latestActivity['message'] ?? 'Activity entry')) ?></strong>
                                            <small><?= h((string)($latestActivity['timestamp'] ?? '')) ?></small>
                                        </div>
                                        <span class="log-pill tone-<?= h($lastActionTone === 'error' ? 'error' : 'ok') ?>"><?= h((string)($latestActivity['status'] ?? 'info')) ?></span>
                                    </div>
                                    <div class="log-context">
                                        <span class="context-chip">action: <?= h((string)($latestActivity['action'] ?? '-')) ?></span>
                                        <?php if (!empty($latestActivity['context']['target'])): ?>
                                            <span class="context-chip">target: <?= h((string)$latestActivity['context']['target']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($latestActivity['output'])): ?>
                                        <pre class="log-output"><?= h((string)$latestActivity['output']) ?></pre>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="empty-state">
                                    <h3>No activity yet</h3>
                                    <p>Your first action in the panel will appear here and inside the Logs tab.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </article>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'create'): ?>
                <section class="panel">
                    <div class="panel-header">
                        <div>
                            <h2 class="panel-title">Create a new Laravel project</h2>
                            <p class="panel-subtitle">The generated project will be created under the configured sites directory and wired into the local stack.</p>
                        </div>
                    </div>
                    <div class="panel-body">
                        <form method="post">
                            <input type="hidden" name="action" value="create">
                            <?= current_view_input('create') ?>
                            <div class="form-grid">
                                <label>
                                    Project name
                                    <input type="text" name="project_name" placeholder="e.g. my-blog" required>
                                </label>
                                <label>
                                    PHP version
                                    <select name="php_version">
                                        <?php foreach ($availablePhpVersions as $version): ?>
                                            <option value="<?= h($version) ?>" <?= $version === $defaultPhpVersion ? 'selected' : '' ?>>PHP <?= h($version) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                            </div>
                            <p class="helper-text">Projects are created inside <code><?= h($sitesDir) ?></code>. You can change that from the Settings tab.</p>
                            <div class="button-row">
                                <button class="button-primary" type="submit">Create Project</button>
                                <a class="button-link button-secondary" href="<?= h(view_url('dashboard')) ?>">Back to Dashboard</a>
                            </div>
                        </form>
                    </div>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'link'): ?>
                <section class="panel">
                    <div class="panel-header">
                        <div>
                            <h2 class="panel-title">Link an existing Laravel project</h2>
                            <p class="panel-subtitle">Register a project already on disk so Laravel Dev can manage it like local generated projects.</p>
                        </div>
                    </div>
                    <div class="panel-body">
                        <form method="post">
                            <input type="hidden" name="action" value="link">
                            <?= current_view_input('link') ?>
                            <div class="form-grid">
                                <label>
                                    Project name
                                    <span class="field-note">This becomes <code>name.test</code>.</span>
                                    <input type="text" name="project_name" placeholder="e.g. legacy-site" required>
                                </label>
                                <label>
                                    PHP version
                                    <select name="php_version">
                                        <?php foreach ($availablePhpVersions as $version): ?>
                                            <option value="<?= h($version) ?>" <?= $version === $defaultPhpVersion ? 'selected' : '' ?>>PHP <?= h($version) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                            </div>
                            <label>
                                Full path to project root
                                <input type="text" name="project_path" placeholder="e.g. /var/www/site" required>
                            </label>
                            <div class="button-row">
                                <button class="button-primary" type="submit">Link Project</button>
                                <a class="button-link button-secondary" href="<?= h(view_url('projects')) ?>">View Projects</a>
                            </div>
                        </form>
                    </div>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'services'): ?>
                <section class="services-grid">
                    <article class="panel" style="grid-column: span 7;">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Core services</h2>
                                <p class="panel-subtitle">Main runtime services that Laravel Dev depends on.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="service-list">
                                <?php foreach ($services as $svcName => $svcStatus): ?>
                                    <?php $svcTone = status_class($svcStatus); ?>
                                    <div class="service-item">
                                        <div class="service-meta">
                                            <strong><?= h($svcName) ?></strong>
                                            <span><?= h(status_label($svcStatus)) ?></span>
                                        </div>
                                        <span class="status-pill tone-<?= h($svcTone === 'bad' ? 'error' : ($svcTone === 'warn' ? 'warn' : 'ok')) ?>"><?= h($svcStatus) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="button-row" style="margin-top: 18px;">
                                <form method="post">
                                    <input type="hidden" name="action" value="services_start">
                                    <?= current_view_input('services') ?>
                                    <button class="button-primary" type="submit">Start Core Services</button>
                                </form>
                                <form method="post">
                                    <input type="hidden" name="action" value="services_stop">
                                    <?= current_view_input('services') ?>
                                    <button class="button-secondary" type="submit">Stop Core Services</button>
                                </form>
                            </div>
                        </div>
                    </article>

                    <article class="panel" style="grid-column: span 5;">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Optional services</h2>
                                <p class="panel-subtitle">Only installed optional services appear here.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if ($optionalServices === []): ?>
                                <div class="empty-state">
                                    <h3>No optional services detected</h3>
                                    <p>Install Mailpit, Meilisearch, or MinIO to manage them from this panel.</p>
                                </div>
                            <?php else: ?>
                                <div class="service-list">
                                    <?php foreach ($optionalServices as $svc): ?>
                                        <?php $svcTone = status_class($svc['status']); ?>
                                        <div class="service-item">
                                            <div class="service-meta">
                                                <strong><?= h($svc['name']) ?></strong>
                                                <span><?= h(status_label($svc['status'])) ?></span>
                                            </div>
                                            <div class="button-row">
                                                <span class="status-pill tone-<?= h($svcTone === 'bad' ? 'error' : ($svcTone === 'warn' ? 'warn' : 'ok')) ?>"><?= h($svc['status']) ?></span>
                                                <form method="post">
                                                    <input type="hidden" name="service_unit" value="<?= h($svc['unit']) ?>">
                                                    <?= current_view_input('services') ?>
                                                    <?php if ($svc['status'] === 'active'): ?>
                                                        <input type="hidden" name="action" value="optional_service_stop">
                                                        <button class="button-secondary" type="submit">Stop</button>
                                                    <?php else: ?>
                                                        <input type="hidden" name="action" value="optional_service_start">
                                                        <button class="button-primary" type="submit">Start</button>
                                                    <?php endif; ?>
                                                </form>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <p class="helper-text" style="margin-top: 18px;">Use <code>systemctl enable SERVICE</code> if you want these services to start on boot.</p>
                            <?php endif; ?>
                        </div>
                    </article>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'projects'): ?>
                <section class="panel">
                    <div class="panel-header">
                        <div>
                            <h2 class="panel-title">Project management</h2>
                            <p class="panel-subtitle">Repair sites, manage per-project database config, and keep scheduled tasks visible.</p>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if ($projectCount === 0): ?>
                            <div class="empty-state">
                                <h3>No projects found</h3>
                                <p>No sites were found in <code><?= h($sitesDir) ?></code>. <a class="muted-link" href="<?= h(view_url('create')) ?>">Create one</a> or <a class="muted-link" href="<?= h(view_url('link')) ?>">link an existing project</a>.</p>
                            </div>
                        <?php else: ?>
                            <div class="projects-list">
                                <?php foreach ($projects as $pname => $ppath): ?>
                                    <?php
                                    $isLinked = !str_starts_with($ppath, $sitesDir);
                                    $envFile = $ppath . '/.env';
                                    $projEnv = read_project_env($envFile);
                                    $projectCrons = read_project_crons($ppath);
                                    ?>
                                    <article class="project-card">
                                        <div class="project-head">
                                            <div>
                                                <div class="project-name">
                                                    <a href="http://<?= rawurlencode($pname) ?>.test" target="_blank" rel="noreferrer"><?= h($pname) ?></a>
                                                </div>
                                                <div class="project-meta"><?= h($ppath) ?></div>
                                                <?php if ($isLinked): ?>
                                                    <span class="badge">Linked Project</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="project-actions">
                                                <form method="post">
                                                    <input type="hidden" name="action" value="repair">
                                                    <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                    <?= current_view_input('projects') ?>
                                                    <button class="button-secondary" type="submit">Repair</button>
                                                </form>
                                                <form method="post" onsubmit="return confirm('Delete project <?= h($pname) ?>?');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                    <?= current_view_input('projects') ?>
                                                    <button class="button-danger" type="submit">Delete</button>
                                                </form>
                                            </div>
                                        </div>

                                        <details>
                                            <summary>Database configuration</summary>
                                            <div class="details-body">
                                                <form method="post">
                                                    <input type="hidden" name="action" value="configure_db">
                                                    <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                    <?= current_view_input('projects') ?>
                                                    <div class="form-grid">
                                                        <label>
                                                            Driver
                                                            <select name="db_connection">
                                                                <?php foreach (['mysql', 'mariadb', 'pgsql', 'sqlite'] as $drv): ?>
                                                                    <option value="<?= h($drv) ?>" <?= $projEnv['DB_CONNECTION'] === $drv ? 'selected' : '' ?>><?= h($drv) ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </label>
                                                        <label>
                                                            Port
                                                            <input type="text" name="db_port" value="<?= h($projEnv['DB_PORT'] ?: '3306') ?>">
                                                        </label>
                                                    </div>
                                                    <div class="form-grid">
                                                        <label>
                                                            Host
                                                            <input type="text" name="db_host" value="<?= h($projEnv['DB_HOST'] ?: '127.0.0.1') ?>">
                                                        </label>
                                                        <label>
                                                            Database name
                                                            <input type="text" name="db_database" value="<?= h($projEnv['DB_DATABASE'] ?: $pname) ?>">
                                                        </label>
                                                    </div>
                                                    <div class="form-grid">
                                                        <label>
                                                            Username
                                                            <input type="text" name="db_username" value="<?= h($projEnv['DB_USERNAME']) ?>">
                                                        </label>
                                                        <label>
                                                            Password
                                                            <input type="password" name="db_password" value="<?= h($projEnv['DB_PASSWORD']) ?>">
                                                        </label>
                                                    </div>
                                                    <div class="button-row">
                                                        <button class="button-primary" type="submit">Save DB Config</button>
                                                    </div>
                                                </form>
                                                <form method="post">
                                                    <input type="hidden" name="action" value="apply_global_db">
                                                    <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                    <?= current_view_input('projects') ?>
                                                    <button class="button-secondary" type="submit">Apply Global DB Settings</button>
                                                </form>
                                                <p class="helper-text">This copies the Settings tab database defaults into the project's <code>.env</code>.</p>
                                            </div>
                                        </details>

                                        <details>
                                            <summary>Cron jobs</summary>
                                            <div class="details-body">
                                                <?php if ($projectCrons !== []): ?>
                                                    <?php foreach ($projectCrons as $cronLine): ?>
                                                        <div class="cron-item">
                                                            <code><?= h($cronLine) ?></code>
                                                            <form method="post" onsubmit="return confirm('Remove this cron job?');">
                                                                <input type="hidden" name="action" value="remove_cron">
                                                                <input type="hidden" name="cron_line" value="<?= h($cronLine) ?>">
                                                                <?= current_view_input('projects') ?>
                                                                <button class="button-danger" type="submit">Remove</button>
                                                            </form>
                                                        </div>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <p class="helper-text">No cron jobs were found for this project path.</p>
                                                <?php endif; ?>

                                                <form method="post">
                                                    <input type="hidden" name="action" value="add_cron">
                                                    <input type="hidden" name="project_path" value="<?= h($ppath) ?>">
                                                    <?= current_view_input('projects') ?>
                                                    <label>
                                                        Schedule
                                                        <span class="field-note">Use five fields, for example <code>* * * * *</code>.</span>
                                                        <input type="text" name="cron_schedule" value="* * * * *" required>
                                                    </label>
                                                    <label>
                                                        Command
                                                        <input type="text" name="cron_command" placeholder="php artisan schedule:run >> /dev/null 2>&1" required>
                                                    </label>
                                                    <button class="button-primary" type="submit">Add Cron Job</button>
                                                </form>
                                                <p class="helper-text">The command is prefixed automatically with <code>cd <?= h($ppath) ?> &amp;&amp;</code>.</p>
                                            </div>
                                        </details>
                                    </article>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'settings'): ?>
                <section class="split-grid">
                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Global settings</h2>
                                <p class="panel-subtitle">These values are stored in the user-writable config file and used as defaults across the panel.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <form method="post">
                                <input type="hidden" name="action" value="save_settings">
                                <?= current_view_input('settings') ?>
                                <label>
                                    Default sites directory
                                    <input type="text" name="sites_dir" value="<?= h($settings['SITES_DIR']) ?>" required>
                                </label>
                                <label>
                                    Database type
                                    <select name="db_type">
                                        <?php foreach (['mysql' => 'MySQL', 'mariadb' => 'MariaDB', 'pgsql' => 'PostgreSQL', 'sqlite' => 'SQLite'] as $val => $label): ?>
                                            <option value="<?= h($val) ?>" <?= $settings['DB_TYPE'] === $val ? 'selected' : '' ?>><?= h($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                                <div class="form-grid">
                                    <label>
                                        DB host
                                        <input type="text" name="db_host" value="<?= h($settings['DB_HOST']) ?>" required>
                                    </label>
                                    <label>
                                        DB port
                                        <input type="text" name="db_port" value="<?= h($settings['DB_PORT']) ?>" required>
                                    </label>
                                </div>
                                <div class="form-grid">
                                    <label>
                                        DB username
                                        <input type="text" name="db_user" value="<?= h($settings['DB_USER']) ?>" required>
                                    </label>
                                    <label>
                                        DB password
                                        <input type="password" name="db_password" value="<?= h($settings['DB_PASSWORD']) ?>">
                                    </label>
                                </div>
                                <label>
                                    Dashboard port
                                    <input type="text" name="web_port" value="<?= h($settings['WEB_PORT']) ?>" required>
                                </label>
                                <button class="button-primary" type="submit">Save Settings</button>
                            </form>
                        </div>
                    </article>

                    <aside class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Setup notes</h2>
                                <p class="panel-subtitle">A few details that help users avoid common issues.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="stack">
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Config file</strong>
                                        <span><?= h($userConfigFile) ?></span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Privileges</strong>
                                        <span>Privileged actions may need <code>sudo -v</code> or an askpass helper.</span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Theme storage</strong>
                                        <span>Theme preference is stored only in the browser, not in <code>config.env</code>.</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </aside>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'logs'): ?>
                <section class="split-grid">
                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Activity log</h2>
                                <p class="panel-subtitle">Every action records status, message, target, timestamp, and command output when available.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if ($activityLogs === []): ?>
                                <div class="empty-state">
                                    <h3>No logs yet</h3>
                                    <p>Once a user starts creating projects or controlling services, entries will appear here.</p>
                                </div>
                            <?php else: ?>
                                <div class="log-list">
                                    <?php foreach ($activityLogs as $entry): ?>
                                        <?php
                                        $entryStatus = (string)($entry['status'] ?? 'info');
                                        $entryTone = match ($entryStatus) {
                                            'success' => 'ok',
                                            'error' => 'error',
                                            'warning' => 'warn',
                                            default => 'info',
                                        };
                                        ?>
                                        <article class="log-item">
                                            <div class="log-top">
                                                <div>
                                                    <strong><?= h((string)($entry['message'] ?? 'Activity log')) ?></strong>
                                                    <small><?= h((string)($entry['timestamp'] ?? '')) ?></small>
                                                </div>
                                                <span class="log-pill tone-<?= h($entryTone) ?>"><?= h($entryStatus) ?></span>
                                            </div>
                                            <div class="log-context">
                                                <span class="context-chip">action: <?= h((string)($entry['action'] ?? '-')) ?></span>
                                                <?php if (!empty($entry['context']['target'])): ?>
                                                    <span class="context-chip">target: <?= h((string)$entry['context']['target']) ?></span>
                                                <?php endif; ?>
                                                <?php if (!empty($entry['context']['view'])): ?>
                                                    <span class="context-chip">view: <?= h((string)$entry['context']['view']) ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <?php if (!empty($entry['output'])): ?>
                                                <pre class="log-output"><?= h((string)$entry['output']) ?></pre>
                                            <?php endif; ?>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </article>

                    <aside class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Log details</h2>
                                <p class="panel-subtitle">Quick reference for where logs live and what they contain.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="stack">
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Stored at</strong>
                                        <span><?= h($activityLogFile) ?></span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Included data</strong>
                                        <span>Action name, result, message, timestamp, target, current view, and command output.</span>
                                    </div>
                                </div>
                                <?php if ($commandLog !== ''): ?>
                                    <div>
                                        <h3 style="margin-bottom: 10px;">Latest command output</h3>
                                        <pre class="code-block"><?= h($commandLog) ?></pre>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </aside>
                </section>
            <?php endif; ?>
        </div>
    </main>
</div>

<script>
    (function () {
        var root = document.documentElement;
        var storageKey = "laravel-dev-theme";
        var toggle = document.getElementById("themeToggle");
        var mobileToggle = document.getElementById("mobileNavToggle");
        var mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");

        function resolveTheme() {
            var stored = localStorage.getItem(storageKey);
            if (stored === "light" || stored === "dark") {
                return stored;
            }
            return mediaQuery.matches ? "dark" : "light";
        }

        function applyTheme(theme) {
            root.setAttribute("data-theme", theme);
            if (toggle) {
                toggle.textContent = theme === "dark" ? "Dark Mode" : "Light Mode";
            }
        }

        applyTheme(resolveTheme());

        if (toggle) {
            toggle.addEventListener("click", function () {
                var nextTheme = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
                localStorage.setItem(storageKey, nextTheme);
                applyTheme(nextTheme);
            });
        }

        mediaQuery.addEventListener("change", function (event) {
            var stored = localStorage.getItem(storageKey);
            if (stored !== "light" && stored !== "dark") {
                applyTheme(event.matches ? "dark" : "light");
            }
        });

        if (mobileToggle) {
            mobileToggle.addEventListener("click", function () {
                document.body.classList.toggle("nav-open");
            });
        }
    })();
</script>
</body>
</html>
