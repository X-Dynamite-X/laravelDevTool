<?php

declare(strict_types=1);

$baseDir = realpath(__DIR__ . '/..') ?: dirname(__DIR__);
$home = getenv('HOME') ?: ($_SERVER['HOME'] ?? '');

$systemConfigFile = $baseDir . '/config/config.env';
$userConfigDir = $home . '/.config/laravel-dev';
$userConfigFile = $userConfigDir . '/config.env';
$activityLogFile = $userConfigDir . '/activity.log';

function h(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function allowed_views(): array
{
    return ['dashboard', 'projects', 'create', 'link', 'git', 'services', 'settings', 'logs'];
}

function normalize_view(?string $view): string
{
    $view = strtolower(trim((string)$view));
    return in_array($view, allowed_views(), true) ? $view : 'dashboard';
}

function view_for_action(string $action): string
{
    return match ($action) {
        'create', 'create_node' => 'create',
        'git_clone', 'git_fetch', 'git_pull', 'git_push', 'git_run', 'git_commit' => 'git',
        'link', 'link_node', 'workspace_link' => 'link',
        'services_start', 'services_stop', 'optional_service_start', 'optional_service_stop', 'sudo_refresh' => 'services',
        'save_settings' => 'settings',
        'configure_db', 'apply_global_db', 'add_cron', 'remove_cron', 'repair', 'delete', 'start_project', 'stop_project', 'restart_project', 'expose_project' => 'projects',
        default => 'dashboard',
    };
}

function current_view_input(string $view): string
{
    return '<input type="hidden" name="return_view" value="' . h($view) . '">';
}

function view_url(string $view): string
{
    return '?view=' . rawurlencode($view);
}

function parse_config_file(string $configFile, array $settings): array
{
    if (!is_file($configFile)) {
        return $settings;
    }

    $lines = file($configFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return $settings;
    }

    $home = getenv('HOME') ?: '';

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        $parts = explode('=', $line, 2);
        if (count($parts) !== 2) {
            continue;
        }

        $key = trim($parts[0]);
        $val = trim($parts[1], " \t\n\r\0\x0B\"");

        if (!array_key_exists($key, $settings)) {
            continue;
        }

        $val = str_replace('$HOME', $home, $val);
        $val = str_replace('$USER', get_current_user(), $val);

        $settings[$key] = $val;
    }

    return $settings;
}

function read_settings(string $systemConfigFile, string $userConfigFile): array
{
    $home = getenv('HOME') ?: '/home';
    $defaults = [
        'SITES_DIR' => $home . '/Sites',
        'LARAVEL_SITES_DIR' => $home . '/Sites',
        'NODE_FRONTEND_DIR' => $home . '/NodeApps/frontend',
        'NODE_BACKEND_DIR' => $home . '/NodeApps/backend',
        'WORKSPACES_DIR' => $home . '/NodeApps/workspaces',
        'DB_HOST' => '127.0.0.1',
        'DB_PORT' => '3306',
        'DB_USER' => getenv('USER') ?: 'root',
        'DB_PASSWORD' => '',
        'DB_TYPE' => 'mysql',
        'WEB_PORT' => '4040',
        'WEB_BIND_HOST' => '0.0.0.0',
        'WEB_PUBLIC_HOST' => '127.0.0.1',
        'WEB_PUBLIC_SCHEME' => 'http',
    ];

    $settings = parse_config_file($systemConfigFile, $defaults);
    $settings = parse_config_file($userConfigFile, $settings);
    $settings['LARAVEL_SITES_DIR'] = $settings['LARAVEL_SITES_DIR'] !== '' ? $settings['LARAVEL_SITES_DIR'] : $settings['SITES_DIR'];
    $settings['SITES_DIR'] = $settings['LARAVEL_SITES_DIR'];

    return $settings;
}

function write_settings(string $userConfigFile, array $settings): bool
{
    $dir = dirname($userConfigFile);
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }

    $content = "# Laravel Dev user settings - auto-generated, do not edit manually\n";
    foreach (['SITES_DIR', 'LARAVEL_SITES_DIR', 'NODE_FRONTEND_DIR', 'NODE_BACKEND_DIR', 'WORKSPACES_DIR', 'DB_HOST', 'DB_PORT', 'DB_USER', 'DB_PASSWORD', 'DB_TYPE', 'WEB_PORT', 'WEB_BIND_HOST', 'WEB_PUBLIC_HOST', 'WEB_PUBLIC_SCHEME'] as $key) {
        $value = str_replace('"', '\\"', $settings[$key] ?? '');
        $content .= $key . '="' . $value . '"' . "\n";
    }

    return file_put_contents($userConfigFile, $content) !== false;
}

function parse_key_value_file(string $file): array
{
    $values = [];
    if (!is_file($file)) {
        return $values;
    }

    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return $values;
    }

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }
        [$key, $val] = explode('=', $line, 2);
        $values[trim($key)] = trim($val, " \t\n\r\0\x0B\"");
    }

    return $values;
}

function project_registry_dir(string $home): string
{
    $candidates = [
        $home . '/.config/laravel-dev/projects.d',
        '/tmp/laravel-dev-' . (function_exists('posix_geteuid') ? (string)posix_geteuid() : md5($home)) . '/projects.d',
    ];

    foreach ($candidates as $dir) {
        if (is_dir($dir) || @mkdir($dir, 0700, true)) {
            return $dir;
        }
    }

    return sys_get_temp_dir();
}

function project_pid_file(string $home, string $name): string
{
    return '/tmp/laravel-dev-' . (function_exists('posix_geteuid') ? (string)posix_geteuid() : md5($home)) . '/projects/' . $name . '.pid';
}

function read_registered_projects(string $home): array
{
    $dir = project_registry_dir($home);
    $projects = [];
    if (!is_dir($dir)) {
        return $projects;
    }

    foreach (glob($dir . '/*.env') ?: [] as $file) {
        $data = parse_key_value_file($file);
        $name = $data['PROJECT_NAME'] ?? basename($file, '.env');
        $path = $data['PROJECT_PATH'] ?? '';
        if ($name === '' || $path === '') {
            continue;
        }
        $projects[$name] = [
            'name' => $name,
            'path' => $path,
            'type' => $data['PROJECT_TYPE'] ?? 'laravel',
            'runtime' => $data['RUNTIME'] ?? 'php-fpm',
            'role' => $data['APP_ROLE'] ?? 'fullstack',
            'storage_root' => $data['STORAGE_ROOT'] ?? '',
            'domain' => $data['DOMAIN'] ?? ($name . '.test'),
            'port' => $data['PORT'] ?? '',
            'run_command' => $data['RUN_COMMAND'] ?? '',
            'install_command' => $data['INSTALL_COMMAND'] ?? '',
            'exposure_mode' => $data['EXPOSURE_MODE'] ?? 'local',
            'workspace_id' => $data['WORKSPACE_ID'] ?? '',
            'status' => $data['STATUS'] ?? 'ready',
            'public_url' => $data['PUBLIC_URL'] ?? '',
            'related_backend' => $data['RELATED_BACKEND'] ?? '',
            'related_frontend' => $data['RELATED_FRONTEND'] ?? '',
            'api_base_url' => $data['API_BASE_URL'] ?? '',
            'frontend_url' => $data['FRONTEND_URL'] ?? '',
            'package_manager' => $data['PACKAGE_MANAGER'] ?? '',
        ];
    }

    return $projects;
}

function discover_legacy_laravel_projects(string $sitesDir): array
{
    $projects = [];
    $sites = is_dir($sitesDir) ? (glob($sitesDir . '/*', GLOB_ONLYDIR) ?: []) : [];
    foreach ($sites as $site) {
        $name = basename($site);
        $projects[$name] = [
            'name' => $name,
            'path' => $site,
            'type' => 'laravel',
            'runtime' => 'php-fpm',
            'role' => 'fullstack',
            'storage_root' => $sitesDir,
            'domain' => $name . '.test',
            'port' => '80',
            'run_command' => '',
            'install_command' => 'composer install',
            'exposure_mode' => 'local',
            'workspace_id' => '',
            'status' => 'ready',
            'public_url' => '',
            'related_backend' => '',
            'related_frontend' => '',
            'api_base_url' => '',
            'frontend_url' => '',
            'package_manager' => '',
        ];
    }
    return $projects;
}

function project_runtime_status(array $project, string $home): string
{
    if (($project['runtime'] ?? '') !== 'node') {
        return $project['status'] ?? 'ready';
    }

    $pidFile = project_pid_file($home, (string)$project['name']);
    if (!is_file($pidFile)) {
        return $project['status'] ?: 'stopped';
    }

    $pid = trim((string)@file_get_contents($pidFile));
    if ($pid !== '' && preg_match('/^\d+$/', $pid) && ((function_exists('posix_kill') && @posix_kill((int)$pid, 0)) || file_exists('/proc/' . $pid))) {
        return 'running';
    }

    return 'stopped';
}

function run_cmd(string $command): array
{
    $output = [];
    $code = 0;
    exec($command . ' 2>&1', $output, $code);
    return ['code' => $code, 'output' => implode("\n", $output)];
}

function shell_join(array $parts): string
{
    return implode(' ', array_map(static fn(string $part): string => escapeshellarg($part), $parts));
}

function parse_cli_words(string $input): array
{
    preg_match_all('/"([^"\\\\]*(?:\\\\.[^"\\\\]*)*)"|\'([^\']*)\'|(\\S+)/', $input, $matches, PREG_SET_ORDER);
    $parts = [];

    foreach ($matches as $match) {
        if ($match[1] !== '') {
            $parts[] = stripcslashes($match[1]);
        } elseif ($match[2] !== '') {
            $parts[] = $match[2];
        } elseif ($match[3] !== '') {
            $parts[] = $match[3];
        }
    }

    return $parts;
}

function redact_sensitive_text(string $text, array $secrets): string
{
    foreach ($secrets as $secret) {
        $secret = trim($secret);
        if ($secret === '') {
            continue;
        }

        $text = str_replace($secret, '[REDACTED]', $text);
    }

    return $text;
}

function sanitize_git_text(string $text): string
{
    return preg_replace('#(https?://)([^/\s]+)@#', '$1***@', $text) ?? $text;
}

function command_lines(string $command): array
{
    $result = run_cmd($command);
    if ($result['code'] !== 0 || trim($result['output']) === '') {
        return [];
    }

    $lines = preg_split('/\R+/', trim($result['output'])) ?: [];
    return array_values(array_filter(array_map('trim', $lines), static fn(string $line): bool => $line !== ''));
}

function has_passwordless_sudo(): bool
{
    $code = 1;
    exec('sudo -n true >/dev/null 2>&1', $out, $code);
    return $code === 0;
}

function sudo_state_file(): string
{
    global $userConfigDir, $home;

    $candidates = [
        $userConfigDir . '/runtime',
        '/tmp/laravel-dev-' . (function_exists('posix_geteuid') ? (string)posix_geteuid() : md5($home)),
    ];

    foreach ($candidates as $dir) {
        if ((is_dir($dir) || @mkdir($dir, 0700, true)) && is_writable($dir)) {
            return $dir . '/sudo-session';
        }
    }

    return sys_get_temp_dir() . '/laravel-dev-sudo-session';
}

function sudo_session_status(): array
{
    $expiresAt = 0;
    $stateFile = sudo_state_file();

    if (is_file($stateFile)) {
        $raw = trim((string)@file_get_contents($stateFile));
        if (ctype_digit($raw)) {
            $expiresAt = (int)$raw;
        }
    }

    if ($expiresAt <= time()) {
        $expiresAt = 0;
    }

    $active = false;
    if ($expiresAt > 0) {
        $code = 1;
        exec('sudo -n true >/dev/null 2>&1', $out, $code);
        $active = $code === 0;
        if (!$active) {
            $expiresAt = 0;
        }
    }

    return [
        'active' => $active,
        'expires_at' => $expiresAt,
        'remaining_seconds' => max(0, $expiresAt - time()),
    ];
}

function get_askpass_helper(): string
{
    global $baseDir;

    $candidates = [
        $baseDir . '/ui/sudo-askpass.sh',
        getenv('SUDO_ASKPASS') ?: '',
        '/usr/bin/ssh-askpass',
        '/usr/bin/ssh-askpass-fullscreen',
        '/usr/bin/ksshaskpass',
        '/usr/lib/ssh/ssh-askpass',
        '/usr/libexec/openssh/gnome-ssh-askpass',
    ];

    foreach ($candidates as $bin) {
        if ($bin !== '' && is_executable($bin)) {
            return $bin;
        }
    }

    return '';
}

function has_askpass_helper(): bool
{
    return get_askpass_helper() !== '';
}

function sudo_help_message(): string
{
    return "This action needs sudo.\nUse Laravel Dev to refresh the sudo session, or install an askpass helper such as zenity or ssh-askpass.";
}

function ensure_sudo_session(): array
{
    global $baseDir;

    if (has_passwordless_sudo()) {
        return ['code' => 0, 'output' => 'sudo session already active'];
    }

    $status = sudo_session_status();
    if ($status['active']) {
        return ['code' => 0, 'output' => 'sudo session already active'];
    }

    $cli = shell_join([$baseDir . '/bin/laravel-dev']);
    return run_cmd('LARAVEL_DEV_BASE_DIR=' . escapeshellarg($baseDir) . ' ' . $cli . ' auth-refresh');
}

function run_sudo_cmd(string $command): array
{
    $ready = ensure_sudo_session();
    if ($ready['code'] !== 0 && !has_passwordless_sudo()) {
        return ['code' => 1, 'output' => $ready['output'] !== '' ? $ready['output'] : sudo_help_message()];
    }

    if (has_passwordless_sudo() || sudo_session_status()['active']) {
        return run_cmd('sudo -n ' . $command);
    }

    $askpass = get_askpass_helper();
    if ($askpass !== '') {
        return run_cmd('SUDO_ASKPASS=' . escapeshellarg($askpass) . ' sudo -A ' . $command);
    }

    return ['code' => 1, 'output' => sudo_help_message()];
}

function service_status(string $service): string
{
    $status = trim(shell_exec('systemctl is-active ' . escapeshellarg($service) . ' 2>/dev/null') ?? '');
    if ($status === '') {
        $status = trim(shell_exec('sudo -n systemctl is-active ' . escapeshellarg($service) . ' 2>/dev/null') ?? '');
    }
    return $status !== '' ? $status : 'unknown';
}

function status_class(string $status): string
{
    return match ($status) {
        'active' => 'ok',
        'inactive', 'failed' => 'bad',
        default => 'warn',
    };
}

function status_label(string $status): string
{
    return match ($status) {
        'active' => 'Healthy',
        'inactive' => 'Stopped',
        'failed' => 'Failed',
        'unknown' => 'Unknown',
        default => ucfirst($status),
    };
}

function read_project_env(string $envFile): array
{
    $keys = ['DB_CONNECTION', 'DB_HOST', 'DB_PORT', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD'];
    $values = array_fill_keys($keys, '');

    if (!is_file($envFile)) {
        return $values;
    }

    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return $values;
    }

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        $parts = explode('=', $line, 2);
        if (count($parts) !== 2) {
            continue;
        }
        $key = trim($parts[0]);
        $val = trim($parts[1], " \t\n\r\0\x0B\"");
        if (array_key_exists($key, $values)) {
            $values[$key] = $val;
        }
    }

    return $values;
}

function update_project_env_keys(string $envFile, array $updates): bool
{
    if (!is_file($envFile)) {
        return false;
    }

    $content = file_get_contents($envFile);
    if ($content === false) {
        return false;
    }

    foreach ($updates as $key => $value) {
        $pattern = '/^' . preg_quote($key, '/') . '=.*/m';
        if (preg_match($pattern, $content)) {
            $content = preg_replace($pattern, $key . '=' . $value, $content) ?? $content;
        } else {
            $content = rtrim($content) . "\n" . $key . '=' . $value . "\n";
        }
    }

    return file_put_contents($envFile, $content) !== false;
}

function detect_optional_services(): array
{
    $candidates = [
        ['name' => 'Mailpit', 'binary' => 'mailpit', 'unit' => 'mailpit'],
        ['name' => 'Meilisearch', 'binary' => 'meilisearch', 'unit' => 'meilisearch'],
        ['name' => 'MinIO', 'binary' => 'minio', 'unit' => 'minio'],
    ];

    $found = [];
    foreach ($candidates as $svc) {
        $out = [];
        $code = 1;
        exec('which ' . escapeshellarg($svc['binary']) . ' 2>/dev/null', $out, $code);
        if ($code === 0) {
            $svc['status'] = service_status($svc['unit']);
            $found[] = $svc;
        }
    }
    return $found;
}

function git_is_available(): bool
{
    $code = 1;
    exec('git --version >/dev/null 2>&1', $out, $code);
    return $code === 0;
}

function is_git_repository(string $path): bool
{
    if (!is_dir($path) || !git_is_available()) {
        return false;
    }

    $code = 1;
    exec('git -C ' . escapeshellarg($path) . ' rev-parse --is-inside-work-tree >/dev/null 2>&1', $out, $code);
    return $code === 0;
}

function git_command(string $path, string $args): array
{
    return run_cmd('git -C ' . escapeshellarg($path) . ' ' . $args);
}

function sanitize_git_remote_url(string $url): string
{
    return sanitize_git_text($url);
}

function git_cli_command(string $baseDir, string $target, array $args): array
{
    $segments = ['LARAVEL_DEV_BASE_DIR=' . escapeshellarg($baseDir), escapeshellarg($baseDir . '/bin/laravel-dev'), 'git', escapeshellarg($target), '--'];
    foreach ($args as $arg) {
        $segments[] = escapeshellarg($arg);
    }
    return run_cmd(implode(' ', $segments));
}

function detect_phpmyadmin_url(): string
{
    $candidates = [
        'http://127.0.0.1/phpmyadmin/',
        'http://localhost/phpmyadmin/',
    ];

    foreach ($candidates as $candidate) {
        $headers = @get_headers($candidate);
        if (is_array($headers) && isset($headers[0]) && preg_match('/\s(200|301|302)\s/', $headers[0])) {
            return $candidate;
        }
    }

    return '';
}

function dashboard_access_url(array $settings): string
{
    $scheme = trim((string)($settings['WEB_PUBLIC_SCHEME'] ?? 'http')) ?: 'http';
    $host = trim((string)($settings['WEB_PUBLIC_HOST'] ?? '127.0.0.1')) ?: '127.0.0.1';
    $port = trim((string)($settings['WEB_PORT'] ?? '4040')) ?: '4040';
    return $scheme . '://' . $host . ':' . $port;
}

function git_project_summary(string $path): ?array
{
    if (!is_git_repository($path)) {
        return null;
    }

    $branchResult = git_command($path, 'symbolic-ref --short HEAD');
    if ($branchResult['code'] === 0 && trim($branchResult['output']) !== '') {
        $branch = trim($branchResult['output']);
    } else {
        $branch = trim(git_command($path, 'rev-parse --short HEAD')['output']);
    }

    $remoteResult = git_command($path, 'remote get-url origin');
    $remote = $remoteResult['code'] === 0 ? sanitize_git_remote_url(trim($remoteResult['output'])) : 'No origin remote';

    $statusResult = git_command($path, 'status --short --branch');
    $statusOutput = trim(sanitize_git_text($statusResult['output']));
    $dirty = false;
    foreach (preg_split('/\R+/', $statusOutput) ?: [] as $line) {
        $trimmed = trim($line);
        if ($trimmed !== '' && !str_starts_with($trimmed, '##')) {
            $dirty = true;
            break;
        }
    }

    $upstreamResult = git_command($path, 'rev-parse --abbrev-ref @{upstream}');
    $upstream = $upstreamResult['code'] === 0 ? trim($upstreamResult['output']) : '';
    $ahead = 0;
    $behind = 0;

    if ($upstream !== '') {
        $countsResult = git_command($path, 'rev-list --left-right --count @{upstream}...HEAD');
        if ($countsResult['code'] === 0 && preg_match('/^\s*(\d+)\s+(\d+)\s*$/', trim($countsResult['output']), $matches)) {
            $behind = (int)$matches[1];
            $ahead = (int)$matches[2];
        }
    }

    return [
        'branch' => $branch !== '' ? $branch : 'unknown',
        'remote' => $remote,
        'dirty' => $dirty,
        'status_output' => $statusOutput !== '' ? $statusOutput : '## clean',
        'upstream' => $upstream,
        'ahead' => $ahead,
        'behind' => $behind,
    ];
}

function git_status_counts(string $statusOutput): array
{
    $counts = [
        'changed' => 0,
        'untracked' => 0,
        'conflicts' => 0,
    ];

    foreach (preg_split('/\R+/', trim($statusOutput)) ?: [] as $line) {
        $line = rtrim($line);
        if ($line === '' || str_starts_with($line, '##')) {
            continue;
        }

        $code = substr($line, 0, 2);
        if ($code === '??') {
            $counts['untracked']++;
            continue;
        }

        if (preg_match('/^(DD|AU|UD|UA|DU|AA|UU)$/', $code)) {
            $counts['conflicts']++;
            continue;
        }

        $counts['changed']++;
    }

    return $counts;
}

function ensure_service_unit(string $unit): string
{
    $templates = [
        'mailpit' => [
            'description' => 'Mailpit - local mail catcher',
            'binary' => 'mailpit',
        ],
        'meilisearch' => [
            'description' => 'Meilisearch - full-text search engine',
            'binary' => 'meilisearch',
        ],
        'minio' => [
            'description' => 'MinIO - S3-compatible object storage',
            'binary' => 'minio',
        ],
    ];

    if (!isset($templates[$unit])) {
        return '';
    }

    $listed = [];
    exec('systemctl list-unit-files --type=service --no-legend 2>/dev/null', $listed);
    foreach ($listed as $line) {
        if (str_starts_with(trim($line), $unit . '.service')) {
            return '';
        }
    }

    $binaryOut = [];
    $binaryCode = 1;
    exec('which ' . escapeshellarg($templates[$unit]['binary']) . ' 2>/dev/null', $binaryOut, $binaryCode);
    if ($binaryCode !== 0 || empty($binaryOut[0])) {
        return "Binary '{$templates[$unit]['binary']}' not found in PATH.";
    }
    $binaryPath = trim($binaryOut[0]);

    $desc = $templates[$unit]['description'];
    $unitContent = "[Unit]\nDescription={$desc}\nAfter=network.target\n\n"
        . "[Service]\nExecStart={$binaryPath}\nRestart=on-failure\nRestartSec=5\n\n"
        . "[Install]\nWantedBy=multi-user.target\n";

    $tmpFile = tempnam(sys_get_temp_dir(), 'laravel_unit_');
    if ($tmpFile === false || file_put_contents($tmpFile, $unitContent) === false) {
        return 'Failed to create temporary unit file.';
    }

    $unitFile = '/etc/systemd/system/' . $unit . '.service';
    $copyResult = run_sudo_cmd('cp ' . escapeshellarg($tmpFile) . ' ' . escapeshellarg($unitFile));
    unlink($tmpFile);

    if ($copyResult['code'] !== 0) {
        return "Failed to install unit file at {$unitFile}: " . $copyResult['output'];
    }

    $reloadResult = run_sudo_cmd('systemctl daemon-reload');
    if ($reloadResult['code'] !== 0) {
        return 'Unit file written but daemon-reload failed: ' . $reloadResult['output'];
    }

    return '';
}

function read_project_crons(string $projectPath): array
{
    $lines = [];
    exec('crontab -l 2>/dev/null', $lines);
    return array_values(array_filter($lines, static function (string $line) use ($projectPath): bool {
        $trimmed = trim($line);
        return $trimmed !== '' && !str_starts_with($trimmed, '#') && str_contains($trimmed, $projectPath);
    }));
}

function build_activity_entry(string $action, string $status, string $message, string $output = '', array $context = []): array
{
    return [
        'timestamp' => date(DATE_ATOM),
        'action' => $action,
        'status' => $status,
        'message' => $message,
        'output' => $output,
        'context' => $context,
    ];
}

function append_activity_log(string $logFile, array $entry): array
{
    $dir = dirname($logFile);
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        return ['ok' => false, 'error' => 'Failed to create log directory at ' . $dir];
    }

    $json = json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return ['ok' => false, 'error' => 'Failed to encode activity log entry.'];
    }

    if (file_put_contents($logFile, $json . PHP_EOL, FILE_APPEND | LOCK_EX) === false) {
        return ['ok' => false, 'error' => 'Failed to write activity log at ' . $logFile];
    }

    return ['ok' => true, 'error' => ''];
}

function read_activity_logs(string $logFile, int $limit = 80): array
{
    if (!is_file($logFile)) {
        return [];
    }

    $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return [];
    }

    $entries = [];
    foreach (array_reverse($lines) as $line) {
        $decoded = json_decode($line, true);
        if (is_array($decoded)) {
            $entries[] = $decoded;
        }
        if (count($entries) >= $limit) {
            break;
        }
    }

    return $entries;
}

function metric_number(int $value): string
{
    return number_format($value);
}

$settings = read_settings($systemConfigFile, $userConfigFile);
$sitesDir = $settings['SITES_DIR'];
$cli = escapeshellarg($baseDir . '/bin/laravel-dev');
$baseEnv = 'LARAVEL_DEV_BASE_DIR=' . escapeshellarg($baseDir) . ' ';
$availablePhpVersions = command_lines($baseEnv . $cli . ' php-versions');
if ($availablePhpVersions === []) {
    $availablePhpVersions = ['8.4'];
}
$defaultPhpVersion = $availablePhpVersions[count($availablePhpVersions) - 1];
$phpFpmServices = command_lines($baseEnv . $cli . ' php-fpm-services');
$knownProjects = discover_legacy_laravel_projects($settings['LARAVEL_SITES_DIR']);
foreach (read_registered_projects($home) as $knownProjectName => $knownProjectMeta) {
    $knownProjects[$knownProjectName] = $knownProjectMeta;
}

$message = '';
$error = '';
$commandLog = '';
$logNotice = '';
$action = '';
$actionTarget = '';
$secretsToRedact = [];
$currentView = normalize_view($_GET['view'] ?? 'dashboard');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim((string)($_POST['action'] ?? ''));
    $currentView = normalize_view($_POST['return_view'] ?? view_for_action($action));
    $needsSudo = in_array($action, ['create', 'delete', 'repair', 'services_start', 'services_stop', 'optional_service_start', 'optional_service_stop', 'sudo_refresh'], true);

    if ($needsSudo && !has_passwordless_sudo() && !has_askpass_helper()) {
        $error = sudo_help_message();
    }

    if ($error === '' && $action === 'sudo_refresh') {
        $actionTarget = 'sudo-session';
        $result = ensure_sudo_session();
        $commandLog = $result['output'];
        $result['code'] === 0 ? $message = 'Sudo session refreshed for 10 minutes.' : $error = 'Failed to refresh sudo session.';
    }

    if ($error === '' && $action === 'create') {
        $name = trim($_POST['project_name'] ?? '');
        $phpVersion = trim($_POST['php_version'] ?? $defaultPhpVersion);
        $actionTarget = $name;

        if (!preg_match('/^[a-z0-9][a-z0-9-]*$/', $name)) {
            $error = 'Invalid project name. Use lowercase letters, numbers, and dash only.';
        } elseif (!in_array($phpVersion, $availablePhpVersions, true)) {
            $error = 'Invalid PHP version.';
        } else {
            $cmd = $baseEnv . $cli . ' create ' . escapeshellarg($name) . ' ' . escapeshellarg($phpVersion);
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Project '$name' created successfully.";
            } else {
                $error = "Create failed for '$name'.";
            }
        }
    }

    if ($error === '' && $action === 'create_node') {
        $name = trim($_POST['project_name'] ?? '');
        $framework = trim($_POST['project_type'] ?? 'next');
        $workspaceId = trim($_POST['workspace_id'] ?? '');
        $actionTarget = $name;

        if (!preg_match('/^[a-z0-9][a-z0-9-]*$/', $name)) {
            $error = 'Invalid project name. Use lowercase letters, numbers, and dash only.';
        } elseif (!in_array($framework, ['next', 'nuxt', 'nest'], true)) {
            $error = 'Invalid Node framework.';
        } else {
            $cmd = $baseEnv . $cli . ' create-node ' . escapeshellarg($name) . ' ' . escapeshellarg($framework);
            $role = trim($_POST['app_role'] ?? '');
            if ($role !== '') {
                $cmd .= ' ' . escapeshellarg($role);
            }
            if ($workspaceId !== '') {
                $cmd .= ' ' . escapeshellarg($workspaceId);
            }
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            $result['code'] === 0 ? $message = "Node project '$name' created successfully." : $error = "Create failed for '$name'.";
        }
    }

    if ($error === '' && $action === 'delete') {
        $name = trim($_POST['project_name'] ?? '');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } else {
            $cmd = $baseEnv . $cli . ' delete ' . escapeshellarg($name);
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Project '$name' deleted.";
            } else {
                $error = "Delete failed for '$name'.";
            }
        }
    }

    if ($error === '' && $action === 'repair') {
        $name = trim($_POST['project_name'] ?? '');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } else {
            $cmd = $baseEnv . $cli . ' repair ' . escapeshellarg($name);
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Project '$name' repaired.";
            } else {
                $error = "Repair failed for '$name'.";
            }
        }
    }

    if ($error === '' && $action === 'services_start') {
        $actionTarget = 'core-services';
        $result = run_cmd($baseEnv . $cli . ' start');
        $commandLog = $result['output'];
        $result['code'] === 0 ? $message = 'Services started.' : $error = 'Failed to start services.';
    }

    if ($error === '' && $action === 'services_stop') {
        $actionTarget = 'core-services';
        $result = run_cmd($baseEnv . $cli . ' stop');
        $commandLog = $result['output'];
        $result['code'] === 0 ? $message = 'Services stopped.' : $error = 'Failed to stop services.';
    }

    if ($error === '' && $action === 'link') {
        $name = trim($_POST['project_name'] ?? '');
        $path = trim($_POST['project_path'] ?? '');
        $phpVersion = trim($_POST['php_version'] ?? $defaultPhpVersion);
        $actionTarget = $name !== '' ? $name : $path;

        if ($name === '' || $path === '') {
            $error = 'Project name and path are required.';
        } elseif (!preg_match('/^[a-z0-9][a-z0-9-]*$/', $name)) {
            $error = 'Invalid project name. Use lowercase, numbers, dash only.';
        } else {
            $cmd = $baseEnv . $cli . ' link ' . escapeshellarg($name) . ' ' . escapeshellarg($path) . ' ' . escapeshellarg($phpVersion);
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Project '$name' linked successfully from $path.";
            } else {
                $error = "Linking failed for '$name'.";
            }
        }
    }

    if ($error === '' && $action === 'link_node') {
        $name = trim($_POST['project_name'] ?? '');
        $path = trim($_POST['project_path'] ?? '');
        $framework = trim($_POST['project_type'] ?? 'next');
        $role = trim($_POST['app_role'] ?? '');
        $workspaceId = trim($_POST['workspace_id'] ?? '');
        $actionTarget = $name !== '' ? $name : $path;

        if ($name === '' || $path === '') {
            $error = 'Project name and path are required.';
        } elseif (!preg_match('/^[a-z0-9][a-z0-9-]*$/', $name)) {
            $error = 'Invalid project name. Use lowercase, numbers, dash only.';
        } elseif (!in_array($framework, ['next', 'nuxt', 'nest'], true)) {
            $error = 'Invalid Node framework.';
        } else {
            $cmd = $baseEnv . $cli . ' link-node ' . escapeshellarg($name) . ' ' . escapeshellarg($path) . ' ' . escapeshellarg($framework);
            if ($role !== '') {
                $cmd .= ' ' . escapeshellarg($role);
            }
            if ($workspaceId !== '') {
                $cmd .= ' ' . escapeshellarg($workspaceId);
            }
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            $result['code'] === 0 ? $message = "Node project '$name' linked successfully." : $error = "Linking failed for '$name'.";
        }
    }

    if ($error === '' && $action === 'git_clone') {
        $name = trim($_POST['project_name'] ?? '');
        $repoUrl = trim($_POST['repository_url'] ?? '');
        $phpVersion = trim($_POST['php_version'] ?? $defaultPhpVersion);
        $gitToken = (string)($_POST['git_token'] ?? '');
        $actionTarget = $name !== '' ? $name : $repoUrl;

        if (!git_is_available()) {
            $error = 'Git is not installed on this system.';
        } elseif (!preg_match('/^[a-z0-9][a-z0-9-]*$/', $name)) {
            $error = 'Invalid project name. Use lowercase letters, numbers, and dash only.';
        } elseif ($repoUrl === '') {
            $error = 'Repository URL is required.';
        } elseif (!preg_match('/^(https?:\/\/|ssh:\/\/|git@).+$/', $repoUrl)) {
            $error = 'Invalid repository URL.';
        } elseif (!in_array($phpVersion, $availablePhpVersions, true)) {
            $error = 'Invalid PHP version.';
        } else {
            $cmdParts = [$baseEnv . $cli . ' git-clone', escapeshellarg($name), escapeshellarg($repoUrl), escapeshellarg($phpVersion)];

            if ($gitToken !== '') {
                $cmdParts[] = escapeshellarg($gitToken);
                $secretsToRedact[] = $gitToken;
            }

            $result = run_cmd(implode(' ', $cmdParts));
            $commandLog = redact_sensitive_text(sanitize_git_text($result['output']), $secretsToRedact);
            if ($result['code'] === 0) {
                $message = "Repository cloned into '$name' successfully.";
            } else {
                $error = "Clone failed for '$name'.";
            }
        }
    }

    if ($action === 'save_settings') {
        $actionTarget = 'global-settings';
        $allowedDbTypes = ['mysql', 'mariadb', 'pgsql', 'sqlite'];
        $newSettings = [
            'SITES_DIR' => trim($_POST['sites_dir'] ?? $sitesDir),
            'LARAVEL_SITES_DIR' => trim($_POST['laravel_sites_dir'] ?? $settings['LARAVEL_SITES_DIR']),
            'NODE_FRONTEND_DIR' => trim($_POST['node_frontend_dir'] ?? $settings['NODE_FRONTEND_DIR']),
            'NODE_BACKEND_DIR' => trim($_POST['node_backend_dir'] ?? $settings['NODE_BACKEND_DIR']),
            'WORKSPACES_DIR' => trim($_POST['workspaces_dir'] ?? $settings['WORKSPACES_DIR']),
            'DB_HOST' => trim($_POST['db_host'] ?? '127.0.0.1'),
            'DB_PORT' => trim($_POST['db_port'] ?? '3306'),
            'DB_USER' => trim($_POST['db_user'] ?? (getenv('USER') ?: 'root')),
            'DB_PASSWORD' => (string)($_POST['db_password'] ?? ''),
            'DB_TYPE' => trim($_POST['db_type'] ?? 'mysql'),
            'WEB_PORT' => trim($_POST['web_port'] ?? '4040'),
            'WEB_BIND_HOST' => trim($_POST['web_bind_host'] ?? ($settings['WEB_BIND_HOST'] ?? '0.0.0.0')),
            'WEB_PUBLIC_HOST' => trim($_POST['web_public_host'] ?? ($settings['WEB_PUBLIC_HOST'] ?? '127.0.0.1')),
            'WEB_PUBLIC_SCHEME' => trim($_POST['web_public_scheme'] ?? ($settings['WEB_PUBLIC_SCHEME'] ?? 'http')),
        ];

        if (!preg_match('/^[0-9]{2,5}$/', $newSettings['WEB_PORT'])) {
            $error = 'Invalid dashboard port.';
        } elseif ($newSettings['SITES_DIR'] === '') {
            $error = 'Sites directory cannot be empty.';
        } elseif (!filter_var($newSettings['WEB_BIND_HOST'], FILTER_VALIDATE_IP) && !in_array($newSettings['WEB_BIND_HOST'], ['0.0.0.0', '127.0.0.1', 'localhost'], true)) {
            $error = 'Invalid dashboard bind host.';
        } elseif ($newSettings['WEB_PUBLIC_HOST'] === '') {
            $error = 'Dashboard public host cannot be empty.';
        } elseif (!in_array($newSettings['WEB_PUBLIC_SCHEME'], ['http', 'https'], true)) {
            $error = 'Dashboard public scheme must be http or https.';
        } elseif ($newSettings['LARAVEL_SITES_DIR'] === '' || $newSettings['NODE_FRONTEND_DIR'] === '' || $newSettings['NODE_BACKEND_DIR'] === '' || $newSettings['WORKSPACES_DIR'] === '') {
            $error = 'All storage directories must be filled.';
        } elseif (!preg_match('/^[0-9]{1,5}$/', $newSettings['DB_PORT'])) {
            $error = 'Invalid database port.';
        } elseif (!in_array($newSettings['DB_TYPE'], $allowedDbTypes, true)) {
            $error = 'Invalid database type.';
        } elseif (write_settings($userConfigFile, $newSettings)) {
            $newSettings['SITES_DIR'] = $newSettings['LARAVEL_SITES_DIR'];
            $settings = $newSettings;
            $sitesDir = $settings['SITES_DIR'];
            $message = 'Settings saved to ~/.config/laravel-dev/config.env';
        } else {
            $error = 'Failed to write settings. Check permissions on ~/.config/laravel-dev/';
        }
    }

    if ($error === '' && $action === 'configure_db') {
        $name = trim($_POST['project_name'] ?? '');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } else {
            $projectDir = $knownProjects[$name]['path'] ?? (is_dir($sitesDir . '/' . $name) ? $sitesDir . '/' . $name : '');
            $envFile = $projectDir !== '' ? $projectDir . '/.env' : '';

            if ($envFile === '' || !is_file($envFile)) {
                $error = "Cannot find .env for project '$name'. Make sure the project directory exists.";
            } else {
                $dbConnection = trim($_POST['db_connection'] ?? 'mysql');
                $dbHost = trim($_POST['db_host'] ?? '127.0.0.1');
                $dbPort = trim($_POST['db_port'] ?? '3306');
                $dbDatabase = trim($_POST['db_database'] ?? $name);
                $dbUsername = trim($_POST['db_username'] ?? '');
                $dbPassword = (string)($_POST['db_password'] ?? '');

                $updates = [
                    'DB_CONNECTION' => $dbConnection,
                    'DB_HOST' => $dbHost,
                    'DB_PORT' => $dbPort,
                    'DB_DATABASE' => $dbDatabase,
                    'DB_USERNAME' => $dbUsername,
                    'DB_PASSWORD' => $dbPassword,
                ];

                if (update_project_env_keys($envFile, $updates)) {
                    $message = "Database settings updated for '$name'.";
                } else {
                    $error = "Failed to update .env for '$name'. Check file permissions.";
                }
            }
        }
    }

    if ($error === '' && $action === 'apply_global_db') {
        $name = trim($_POST['project_name'] ?? '');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } else {
            $cmd = $baseEnv . $cli . ' configure-db ' . escapeshellarg($name);
            if (isset($knownProjects[$name]['path'])) {
                $cmd .= ' ' . escapeshellarg((string)$knownProjects[$name]['path']);
            }
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            if ($result['code'] === 0) {
                $message = "Global DB settings applied to '$name'.";
            } else {
                $error = "Failed to apply DB settings to '$name'.";
            }
        }
    }

    if ($error === '' && $action === 'optional_service_start') {
        $unit = trim($_POST['service_unit'] ?? '');
        $actionTarget = $unit;
        if (!preg_match('/^[a-z0-9_\-\.]+$/', $unit)) {
            $error = 'Invalid service name.';
        } else {
            $unitErr = ensure_service_unit($unit);
            if ($unitErr !== '') {
                $error = $unitErr;
            } else {
                $result = run_sudo_cmd('systemctl start ' . escapeshellarg($unit));
                $commandLog = $result['output'];
                $result['code'] === 0
                    ? $message = "Service '$unit' started."
                    : $error = "Failed to start '$unit': " . $result['output'];
            }
        }
    }

    if ($error === '' && $action === 'optional_service_stop') {
        $unit = trim($_POST['service_unit'] ?? '');
        $actionTarget = $unit;
        if (!preg_match('/^[a-z0-9_\-\.]+$/', $unit)) {
            $error = 'Invalid service name.';
        } else {
            $result = run_sudo_cmd('systemctl stop ' . escapeshellarg($unit));
            $commandLog = $result['output'];
            $result['code'] === 0 ? $message = "Service '$unit' stopped." : $error = "Failed to stop '$unit'.";
        }
    }

    if ($error === '' && $action === 'add_cron') {
        $projectPath = trim($_POST['project_path'] ?? '');
        $schedule = trim($_POST['cron_schedule'] ?? '* * * * *');
        $command = trim($_POST['cron_command'] ?? '');
        $actionTarget = $projectPath;

        if ($projectPath === '' || $command === '') {
            $error = 'Project path and command are required.';
        } elseif (!preg_match('/^[\*0-9,\-\/\s]+$/', $schedule) || substr_count($schedule, ' ') < 4) {
            $error = 'Invalid cron schedule. Use five space-separated fields (e.g. * * * * *).';
        } else {
            $cronLine = $schedule . ' cd ' . $projectPath . ' && ' . $command;
            $cmd = '(crontab -l 2>/dev/null; echo ' . escapeshellarg($cronLine) . ') | crontab -';
            exec($cmd, $out, $code);
            $commandLog = implode("\n", $out);
            if ($code === 0) {
                $message = 'Cron job added.';
            } else {
                $error = 'Failed to add cron job. Check that crontab is available.';
            }
        }
    }

    if ($error === '' && in_array($action, ['git_fetch', 'git_pull', 'git_push'], true)) {
        $projectPath = trim($_POST['project_path'] ?? '');
        $projectName = trim($_POST['project_name'] ?? '');
        $actionTarget = $projectName !== '' ? $projectName : $projectPath;

        if (!git_is_available()) {
            $error = 'Git is not installed on this system.';
        } elseif ($projectPath === '' || !is_dir($projectPath)) {
            $error = 'Project path not found.';
        } elseif (!is_git_repository($projectPath)) {
            $error = 'Selected project is not a Git repository.';
        } else {
            $gitArgs = match ($action) {
                'git_fetch' => ['fetch', '--all', '--prune'],
                'git_pull' => ['pull', '--ff-only'],
                'git_push' => ['push'],
                default => [],
            };
            $result = git_cli_command($baseDir, $projectPath, $gitArgs);
            $commandLog = sanitize_git_text($result['output']);

            if ($result['code'] === 0) {
                $message = match ($action) {
                    'git_fetch' => "Fetched latest refs for '$actionTarget'.",
                    'git_pull' => "Pulled latest changes for '$actionTarget'.",
                    'git_push' => "Pushed local commits for '$actionTarget'.",
                    default => 'Git action completed.',
                };
            } else {
                $error = match ($action) {
                    'git_fetch' => "Fetch failed for '$actionTarget'.",
                    'git_pull' => "Pull failed for '$actionTarget'.",
                    'git_push' => "Push failed for '$actionTarget'.",
                    default => 'Git action failed.',
                };
            }
        }
    }

    if ($error === '' && $action === 'git_run') {
        $projectPath = trim($_POST['project_path'] ?? '');
        $projectName = trim($_POST['project_name'] ?? '');
        $gitRawArgs = trim((string)($_POST['git_args'] ?? ''));
        $actionTarget = $projectName !== '' ? $projectName : $projectPath;

        if (!git_is_available()) {
            $error = 'Git is not installed on this system.';
        } elseif ($projectPath === '' || !is_dir($projectPath)) {
            $error = 'Project path not found.';
        } elseif (!is_git_repository($projectPath)) {
            $error = 'Selected project is not a Git repository.';
        } elseif ($gitRawArgs === '') {
            $error = 'Git command is required.';
        } else {
            $gitArgs = array_values(array_filter(array_map('trim', parse_cli_words($gitRawArgs)), static fn(string $arg): bool => $arg !== ''));
            if ($gitArgs === []) {
                $error = 'Git command is required.';
            } else {
                $result = git_cli_command($baseDir, $projectPath, $gitArgs);
                $commandLog = sanitize_git_text($result['output']);
                $result['code'] === 0 ? $message = "Git command completed for '$actionTarget'." : $error = "Git command failed for '$actionTarget'.";
            }
        }
    }

    if ($error === '' && $action === 'git_commit') {
        $projectPath = trim($_POST['project_path'] ?? '');
        $projectName = trim($_POST['project_name'] ?? '');
        $commitMessage = trim((string)($_POST['commit_message'] ?? ''));
        $commitAll = ($_POST['commit_all'] ?? '') === '1';
        $actionTarget = $projectName !== '' ? $projectName : $projectPath;

        if (!git_is_available()) {
            $error = 'Git is not installed on this system.';
        } elseif ($projectPath === '' || !is_dir($projectPath)) {
            $error = 'Project path not found.';
        } elseif (!is_git_repository($projectPath)) {
            $error = 'Selected project is not a Git repository.';
        } elseif ($commitMessage === '') {
            $error = 'Commit message is required.';
        } else {
            $gitArgs = ['commit'];
            if ($commitAll) {
                $gitArgs[] = '--all';
            }
            $gitArgs[] = '-m';
            $gitArgs[] = $commitMessage;
            $result = git_cli_command($baseDir, $projectPath, $gitArgs);
            $commandLog = sanitize_git_text($result['output']);
            $result['code'] === 0 ? $message = "Commit created for '$actionTarget'." : $error = "Commit failed for '$actionTarget'.";
        }
    }

    if ($error === '' && $action === 'remove_cron') {
        $cronLine = trim($_POST['cron_line'] ?? '');
        $actionTarget = $cronLine;
        if ($cronLine === '') {
            $error = 'No cron line specified.';
        } else {
            $current = [];
            exec('crontab -l 2>/dev/null', $current);
            $filtered = array_filter($current, static fn(string $line): bool => trim($line) !== $cronLine);
            $newContent = implode("\n", $filtered);
            if ($newContent !== '') {
                $newContent .= "\n";
            }
            $tmpFile = tempnam(sys_get_temp_dir(), 'laravel_cron_');
            if ($tmpFile === false) {
                $error = 'Could not create temp file for crontab.';
            } else {
                file_put_contents($tmpFile, $newContent);
                exec('crontab ' . escapeshellarg($tmpFile), $out2, $code2);
                unlink($tmpFile);
                $commandLog = implode("\n", $out2);
                $code2 === 0 ? $message = 'Cron job removed.' : $error = 'Failed to remove cron job.';
            }
        }
    }

    if ($error === '' && in_array($action, ['start_project', 'stop_project', 'restart_project'], true)) {
        $name = trim($_POST['project_name'] ?? '');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } else {
            $cmdAction = match ($action) {
                'start_project' => 'start-project',
                'stop_project' => 'stop-project',
                'restart_project' => 'restart-project',
            };
            $result = run_cmd($baseEnv . $cli . ' ' . $cmdAction . ' ' . escapeshellarg($name));
            $commandLog = $result['output'];
            $result['code'] === 0 ? $message = "Project '$name' updated." : $error = "Failed to update '$name'.";
        }
    }

    if ($error === '' && $action === 'expose_project') {
        $name = trim($_POST['project_name'] ?? '');
        $mode = trim($_POST['exposure_mode'] ?? 'local');
        $actionTarget = $name;
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $name)) {
            $error = 'Invalid project name.';
        } elseif (!in_array($mode, ['local', 'lan', 'public_tunnel', 'public_dns'], true)) {
            $error = 'Invalid exposure mode.';
        } else {
            $result = run_cmd($baseEnv . $cli . ' expose ' . escapeshellarg($name) . ' ' . escapeshellarg($mode));
            $commandLog = $result['output'];
            $result['code'] === 0 ? $message = "Exposure updated for '$name'." : $error = "Failed to update exposure for '$name'.";
        }
    }

    if ($error === '' && $action === 'workspace_link') {
        $frontend = trim($_POST['frontend_project'] ?? '');
        $backend = trim($_POST['backend_project'] ?? '');
        $workspaceId = trim($_POST['workspace_id'] ?? '');
        $actionTarget = $frontend . ' -> ' . $backend;
        if ($frontend === '' || $backend === '') {
            $error = 'Frontend and backend projects are required.';
        } else {
            $cmd = $baseEnv . $cli . ' workspace-link ' . escapeshellarg($frontend) . ' ' . escapeshellarg($backend);
            if ($workspaceId !== '') {
                $cmd .= ' ' . escapeshellarg($workspaceId);
            }
            $result = run_cmd($cmd);
            $commandLog = $result['output'];
            $result['code'] === 0 ? $message = 'Workspace relation saved.' : $error = 'Failed to save workspace relation.';
        }
    }

    if ($action !== '') {
        $status = $error !== '' ? 'error' : 'success';
        $summary = $error !== '' ? $error : ($message !== '' ? $message : 'Action completed.');
        $logResult = append_activity_log($activityLogFile, build_activity_entry(
            $action,
            $status,
            $summary,
            $commandLog,
            [
                'target' => $actionTarget,
                'view' => $currentView,
            ]
        ));

        if (!$logResult['ok']) {
            $logNotice = $logResult['error'];
        }
    }
}

$projects = read_registered_projects($home);
foreach (discover_legacy_laravel_projects($settings['LARAVEL_SITES_DIR']) as $projectName => $projectData) {
    if (!isset($projects[$projectName])) {
        $projects[$projectName] = $projectData;
    }
}
foreach ($projects as $projectName => $projectData) {
    $projects[$projectName]['status'] = project_runtime_status($projectData, $home);
}
ksort($projects);

$mysqlUnit = service_status('mysql') !== 'unknown' ? 'mysql' : 'mariadb';
$services = [
    'nginx' => service_status('nginx'),
    $mysqlUnit => service_status($mysqlUnit),
];

foreach ($phpFpmServices as $service) {
    $services[$service] = service_status($service);
}

$optionalServices = detect_optional_services();
$activityLogs = read_activity_logs($activityLogFile, 60);
$latestActivity = $activityLogs[0] ?? null;
$sudoStatus = sudo_session_status();
$phpmyadminUrl = detect_phpmyadmin_url();
$gitProjects = [];
foreach ($projects as $projectName => $projectMeta) {
    $gitSummary = git_project_summary((string)$projectMeta['path']);
    if ($gitSummary !== null) {
        $gitProjects[$projectName] = $gitSummary + ['path' => (string)$projectMeta['path']];
    }
}

$projectCount = count($projects);
$coreActiveCount = count(array_filter($services, static fn(string $status): bool => $status === 'active'));
$coreInactiveCount = count($services) - $coreActiveCount;
$optionalActiveCount = count(array_filter($optionalServices, static fn(array $service): bool => ($service['status'] ?? '') === 'active'));
$optionalInstalledCount = count($optionalServices);
$gitRepoCount = count($gitProjects);
$gitDirtyCount = count(array_filter($gitProjects, static fn(array $project): bool => (bool)($project['dirty'] ?? false)));
$activeViewTitle = [
    'dashboard' => 'Dashboard',
    'projects' => 'Projects',
    'create' => 'Create Project',
    'link' => 'Link Existing Project',
    'git' => 'Git',
    'services' => 'Services',
    'settings' => 'Settings',
    'logs' => 'Logs',
][$currentView];
$activeViewSubtitle = [
    'dashboard' => 'Overview, health signals, and quick actions.',
    'projects' => 'Inspect, repair, configure databases, and manage cron jobs.',
    'create' => 'Provision a new Laravel project with the selected PHP version.',
    'link' => 'Register an existing Laravel codebase inside Laravel Dev.',
    'git' => 'Clone repositories and run the most common Git actions from one place.',
    'services' => 'Monitor and control core and optional local services.',
    'settings' => 'Control default paths and database preferences.',
    'logs' => 'Review recent actions, failures, and command output.',
][$currentView];
$version = trim((string)@file_get_contents(dirname(__DIR__) . '/VERSION')) ?: '1.0.0';
$lastActionTone = is_array($latestActivity) ? (($latestActivity['status'] ?? 'info') === 'error' ? 'error' : 'success') : 'neutral';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Dev - Local Panel</title>
    <link rel="icon" type="image/svg+xml" href="logo.svg">
    <link rel="shortcut icon" href="logo.svg">
    <style>
        :root {
            color-scheme: light dark;
            --font-sans: "Noto Sans Arabic", "Noto Sans", "Cairo", "Tajawal", "Segoe UI", system-ui, sans-serif;
            --font-mono: "Cascadia Mono", "JetBrains Mono", "SFMono-Regular", Consolas, "Liberation Mono", monospace;
            --sidebar-width: 280px;
            --radius-sm: 12px;
            --radius-md: 20px;
            --radius-lg: 28px;
            --shadow-soft: 0 18px 48px rgba(18, 34, 54, 0.12);
            --shadow-panel: 0 24px 56px rgba(10, 22, 38, 0.16);
            --bg: #f4efe6;
            --bg-accent: radial-gradient(circle at top left, rgba(213, 124, 49, 0.16), transparent 34%), radial-gradient(circle at bottom right, rgba(26, 113, 122, 0.12), transparent 32%);
            --surface: rgba(255, 250, 244, 0.86);
            --surface-strong: rgba(255, 255, 255, 0.94);
            --surface-alt: #ece2d3;
            --text: #1a2633;
            --muted: #6c7280;
            --border: rgba(76, 88, 104, 0.16);
            --border-strong: rgba(76, 88, 104, 0.22);
            --accent: #bd5b27;
            --accent-strong: #8f3f16;
            --accent-soft: rgba(189, 91, 39, 0.12);
            --brand: #0f766e;
            --brand-soft: rgba(15, 118, 110, 0.12);
            --ok: #0c8b63;
            --ok-soft: rgba(12, 139, 99, 0.12);
            --warn: #b7791f;
            --warn-soft: rgba(183, 121, 31, 0.14);
            --error: #c2413b;
            --error-soft: rgba(194, 65, 59, 0.12);
            --info: #2563eb;
            --info-soft: rgba(37, 99, 235, 0.12);
            --code-bg: #fff7eb;
        }

        :root[data-theme="dark"] {
            --shadow-soft: 0 18px 48px rgba(0, 0, 0, 0.32);
            --shadow-panel: 0 24px 56px rgba(0, 0, 0, 0.42);
            --bg: #11161c;
            --bg-accent: radial-gradient(circle at top left, rgba(222, 124, 43, 0.18), transparent 30%), radial-gradient(circle at bottom right, rgba(44, 169, 169, 0.16), transparent 28%);
            --surface: rgba(20, 28, 36, 0.88);
            --surface-strong: rgba(24, 33, 42, 0.96);
            --surface-alt: #1b242e;
            --text: #eef4ff;
            --muted: #9eaec0;
            --border: rgba(163, 184, 204, 0.12);
            --border-strong: rgba(163, 184, 204, 0.2);
            --accent: #ff9c55;
            --accent-strong: #ffb06d;
            --accent-soft: rgba(255, 156, 85, 0.14);
            --brand: #4fd1c5;
            --brand-soft: rgba(79, 209, 197, 0.14);
            --ok: #34d399;
            --ok-soft: rgba(52, 211, 153, 0.14);
            --warn: #f6c453;
            --warn-soft: rgba(246, 196, 83, 0.14);
            --error: #f87171;
            --error-soft: rgba(248, 113, 113, 0.14);
            --info: #60a5fa;
            --info-soft: rgba(96, 165, 250, 0.14);
            --code-bg: #18212c;
        }

        * { box-sizing: border-box; }

        html { scroll-behavior: smooth; }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: var(--font-sans);
            color: var(--text);
            background: var(--bg);
            background-image: var(--bg-accent);
        }

        a { color: inherit; text-decoration: none; }
        p { margin: 0; }
        h1, h2, h3, h4 { margin: 0; }
        code, pre { font-family: var(--font-mono); }

        .layout {
            display: grid;
            grid-template-columns: var(--sidebar-width) minmax(0, 1fr);
            min-height: 100vh;
        }

        .sidebar {
            position: sticky;
            top: 0;
            height: 100vh;
            padding: 28px 22px;
            border-right: 1px solid var(--border);
            background: rgba(255, 255, 255, 0.22);
            backdrop-filter: blur(22px);
        }

        :root[data-theme="dark"] .sidebar {
            background: rgba(11, 16, 23, 0.55);
        }

        .sidebar-inner {
            display: flex;
            flex-direction: column;
            gap: 22px;
            height: 100%;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .brand-badge {
            width: 52px;
            height: 52px;
            border-radius: 18px;
            box-shadow: var(--shadow-soft);
            overflow: hidden;
            flex-shrink: 0;
            border: 1px solid var(--border);
            background: var(--surface-strong);
        }

        .brand-badge img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .brand-title {
            font-size: 1.15rem;
            font-weight: 700;
            letter-spacing: -0.02em;
        }

        .brand-subtitle {
            color: var(--muted);
            font-size: 0.9rem;
            margin-top: 4px;
        }

        .nav-list {
            display: grid;
            gap: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 13px 14px;
            border-radius: 16px;
            color: var(--muted);
            border: 1px solid transparent;
            transition: 0.18s ease;
        }

        .nav-link:hover {
            background: var(--surface);
            color: var(--text);
            border-color: var(--border);
        }

        .nav-link.active {
            background: linear-gradient(135deg, var(--accent-soft), var(--brand-soft));
            color: var(--text);
            border-color: var(--border-strong);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.12);
        }

        .nav-icon {
            width: 34px;
            height: 34px;
            border-radius: 12px;
            background: var(--surface-strong);
            border: 1px solid var(--border);
            display: grid;
            place-items: center;
            font-size: 0.95rem;
        }

        .nav-text strong {
            display: block;
            font-size: 0.95rem;
        }

        .nav-text span {
            display: block;
            font-size: 0.78rem;
            color: var(--muted);
            margin-top: 3px;
        }

        .sidebar-footer {
            margin-top: auto;
            padding: 18px;
            border-radius: 20px;
            background: var(--surface);
            border: 1px solid var(--border);
        }

        .sidebar-footer h3 {
            font-size: 0.9rem;
            margin-bottom: 8px;
        }

        .sidebar-footer p {
            color: var(--muted);
            font-size: 0.84rem;
            line-height: 1.6;
        }

        .content {
            padding: 28px;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 24px;
        }

        .page-title {
            font-size: clamp(1.9rem, 2vw, 2.5rem);
            letter-spacing: -0.04em;
        }

        .page-subtitle {
            color: var(--muted);
            margin-top: 8px;
            max-width: 680px;
            line-height: 1.7;
        }

        .topbar-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .version-pill,
        .theme-toggle,
        .mobile-nav-toggle {
            border: 1px solid var(--border);
            background: var(--surface-strong);
            color: var(--text);
            border-radius: 999px;
            padding: 10px 14px;
            font: inherit;
            box-shadow: var(--shadow-soft);
        }

        .theme-toggle,
        .mobile-nav-toggle {
            cursor: pointer;
        }

        .mobile-nav-toggle {
            display: none;
        }

        .stack {
            display: grid;
            gap: 22px;
        }

        .alert {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            border-radius: var(--radius-md);
            padding: 16px 18px;
            border: 1px solid var(--border);
            background: var(--surface);
            box-shadow: var(--shadow-soft);
        }

        .alert strong {
            display: block;
            margin-bottom: 4px;
        }

        .alert.success { border-color: rgba(12, 139, 99, 0.24); background: linear-gradient(135deg, var(--ok-soft), var(--surface)); }
        .alert.error { border-color: rgba(194, 65, 59, 0.24); background: linear-gradient(135deg, var(--error-soft), var(--surface)); }
        .alert.warning { border-color: rgba(183, 121, 31, 0.24); background: linear-gradient(135deg, var(--warn-soft), var(--surface)); }

        .grid-metrics {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
        }

        .metric-card,
        .panel,
        .hero-card {
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            background: var(--surface);
            box-shadow: var(--shadow-panel);
        }

        .metric-card {
            padding: 20px;
        }

        .metric-label {
            font-size: 0.84rem;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .metric-value {
            margin-top: 12px;
            font-size: 2rem;
            font-weight: 700;
            letter-spacing: -0.04em;
        }

        .metric-note {
            margin-top: 10px;
            color: var(--muted);
            font-size: 0.92rem;
        }

        .hero-grid,
        .two-panel-grid,
        .services-grid {
            display: grid;
            grid-template-columns: repeat(12, minmax(0, 1fr));
            gap: 18px;
        }

        .hero-card {
            grid-column: span 8;
            padding: 26px;
            background: linear-gradient(135deg, var(--surface), rgba(255, 255, 255, 0.04));
        }

        .hero-card h2 {
            font-size: 1.5rem;
            letter-spacing: -0.03em;
        }

        .hero-card p {
            margin-top: 10px;
            color: var(--muted);
            line-height: 1.75;
        }

        .quick-actions {
            margin-top: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .hero-side {
            grid-column: span 4;
            display: grid;
            gap: 18px;
        }

        .mini-stat {
            padding: 20px;
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            background: var(--surface);
            box-shadow: var(--shadow-panel);
        }

        .mini-stat span {
            display: block;
            color: var(--muted);
            font-size: 0.84rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .mini-stat strong {
            display: block;
            margin-top: 12px;
            font-size: 1.5rem;
            letter-spacing: -0.04em;
        }

        .panel {
            overflow: hidden;
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            padding: 22px 24px 0;
        }

        .panel-title {
            font-size: 1.1rem;
            letter-spacing: -0.02em;
        }

        .panel-subtitle {
            color: var(--muted);
            margin-top: 6px;
            line-height: 1.6;
        }

        .panel-body {
            padding: 22px 24px 24px;
        }

        .dashboard-status-list,
        .service-list,
        .log-list {
            display: grid;
            gap: 12px;
        }

        .status-item,
        .service-item,
        .log-item,
        .project-card,
        .empty-state {
            border: 1px solid var(--border);
            background: var(--surface-strong);
            border-radius: 18px;
            padding: 16px 18px;
        }

        .status-item,
        .service-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
        }

        .status-meta strong,
        .service-meta strong,
        .log-item strong {
            display: block;
            font-size: 0.98rem;
        }

        .status-meta span,
        .service-meta span,
        .log-item small,
        .project-meta,
        .empty-state p {
            color: var(--muted);
            line-height: 1.6;
        }

        .status-pill,
        .log-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border-radius: 999px;
            padding: 8px 12px;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            border: 1px solid transparent;
            white-space: nowrap;
        }

        .tone-ok { color: var(--ok); background: var(--ok-soft); border-color: rgba(12, 139, 99, 0.2); }
        .tone-warn { color: var(--warn); background: var(--warn-soft); border-color: rgba(183, 121, 31, 0.22); }
        .tone-error { color: var(--error); background: var(--error-soft); border-color: rgba(194, 65, 59, 0.22); }
        .tone-info { color: var(--info); background: var(--info-soft); border-color: rgba(37, 99, 235, 0.22); }

        .button-row {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .button-row.tight {
            gap: 8px;
        }

        button,
        .button-link {
            appearance: none;
            border: 0;
            border-radius: 14px;
            font: inherit;
            font-weight: 700;
            cursor: pointer;
            padding: 12px 16px;
            transition: transform 0.18s ease, box-shadow 0.18s ease, background 0.18s ease;
        }

        button:hover,
        .button-link:hover {
            transform: translateY(-1px);
        }

        .button-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-strong));
            color: white;
            box-shadow: 0 16px 30px rgba(189, 91, 39, 0.24);
        }

        .button-secondary {
            background: var(--surface-strong);
            color: var(--text);
            border: 1px solid var(--border);
        }

        .button-danger {
            background: linear-gradient(135deg, #d25549, #b93831);
            color: white;
            box-shadow: 0 16px 30px rgba(185, 56, 49, 0.22);
        }

        .button-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        form { display: grid; gap: 14px; }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }

        label {
            display: grid;
            gap: 8px;
            font-size: 0.88rem;
            font-weight: 700;
            color: var(--text);
        }

        .field-note {
            font-weight: 500;
            font-size: 0.8rem;
            color: var(--muted);
        }

        input,
        select,
        textarea {
            width: 100%;
            border-radius: 14px;
            border: 1px solid var(--border);
            background: var(--surface-strong);
            color: var(--text);
            font: inherit;
            padding: 13px 14px;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: rgba(37, 99, 235, 0.35);
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.12);
        }

        .helper-text {
            color: var(--muted);
            line-height: 1.7;
            font-size: 0.92rem;
        }

        .projects-list {
            display: grid;
            gap: 16px;
        }

        .projects-list.compact {
            gap: 18px;
        }

        .project-card {
            display: grid;
            gap: 16px;
        }

        .project-card.git-card {
            gap: 18px;
            padding: 20px;
            background:
                linear-gradient(180deg, rgba(255, 255, 255, 0.42), rgba(255, 255, 255, 0.08)),
                var(--surface-strong);
        }

        :root[data-theme="dark"] .project-card.git-card {
            background:
                linear-gradient(180deg, rgba(255, 255, 255, 0.03), rgba(0, 0, 0, 0.06)),
                var(--surface-strong);
        }

        .project-head {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            align-items: flex-start;
        }

        .project-name {
            font-size: 1.05rem;
            font-weight: 700;
            letter-spacing: -0.02em;
        }

        .project-name a {
            color: var(--text);
        }

        .project-name a:hover {
            color: var(--accent);
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 999px;
            background: var(--info-soft);
            border: 1px solid rgba(37, 99, 235, 0.18);
            color: var(--info);
            font-size: 0.74rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-top: 8px;
        }

        .badge.tone-warn {
            background: var(--warn-soft);
            border-color: rgba(183, 121, 31, 0.22);
            color: var(--warn);
        }

        .badge.tone-ok {
            background: var(--ok-soft);
            border-color: rgba(12, 139, 99, 0.22);
            color: var(--ok);
        }

        .badge.tone-brand {
            color: var(--brand);
            background: var(--brand-soft);
            border-color: rgba(15, 118, 110, 0.2);
        }

        .project-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .project-actions.inline-forms form {
            display: inline-flex;
        }

        .project-summary-grid,
        .git-metric-grid,
        .git-workbench,
        .git-highlight {
            display: grid;
            gap: 14px;
        }

        .project-summary-grid,
        .git-metric-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
        }

        .git-metric {
            padding: 14px 15px;
            border-radius: 16px;
            border: 1px solid var(--border);
            background: var(--surface);
        }

        .git-metric strong {
            display: block;
            font-size: 0.78rem;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--muted);
        }

        .git-metric span {
            display: block;
            margin-top: 8px;
            font-size: 1rem;
            font-weight: 700;
            line-height: 1.4;
        }

        .git-workbench {
            grid-template-columns: minmax(0, 1.02fr) minmax(0, 1.2fr);
            align-items: start;
        }

        .git-panel {
            display: grid;
            gap: 14px;
            padding: 16px;
            border-radius: 18px;
            border: 1px solid var(--border);
            background: var(--surface);
        }

        .git-panel-title {
            display: grid;
            gap: 4px;
        }

        .git-panel-title h3 {
            font-size: 0.98rem;
            letter-spacing: -0.02em;
        }

        .git-panel-title p {
            color: var(--muted);
            font-size: 0.86rem;
            line-height: 1.6;
            margin: 0;
        }

        .command-palette {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .command-chip {
            appearance: none;
            border: 1px solid var(--border);
            background: var(--surface-strong);
            color: var(--text);
            border-radius: 999px;
            padding: 8px 11px;
            font: inherit;
            font-size: 0.8rem;
            font-weight: 700;
            cursor: pointer;
        }

        .command-chip:hover {
            border-color: var(--border-strong);
            background: linear-gradient(135deg, var(--accent-soft), var(--brand-soft));
        }

        .git-toolbar {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            margin-bottom: 18px;
        }

        .git-search {
            max-width: 360px;
            width: 100%;
        }

        .git-highlight {
            grid-template-columns: repeat(4, minmax(0, 1fr));
            margin-bottom: 18px;
        }

        .git-highlight-card {
            padding: 16px;
            border-radius: 18px;
            border: 1px solid var(--border);
            background: linear-gradient(135deg, var(--surface), rgba(255, 255, 255, 0.04));
        }

        .git-highlight-card strong {
            display: block;
            color: var(--muted);
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .git-highlight-card span {
            display: block;
            margin-top: 8px;
            font-size: 1.55rem;
            font-weight: 800;
            letter-spacing: -0.04em;
        }

        .git-highlight-card small {
            display: block;
            margin-top: 8px;
            color: var(--muted);
            line-height: 1.6;
        }

        .section-kicker {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 11px;
            border-radius: 999px;
            background: linear-gradient(135deg, var(--accent-soft), var(--brand-soft));
            border: 1px solid var(--border);
            color: var(--text);
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
        }

        details {
            border: 1px solid var(--border);
            border-radius: 16px;
            background: var(--surface);
            overflow: hidden;
        }

        summary {
            list-style: none;
            cursor: pointer;
            padding: 15px 16px;
            font-weight: 700;
        }

        summary::-webkit-details-marker { display: none; }

        .details-body {
            padding: 0 16px 16px;
            display: grid;
            gap: 14px;
        }

        .cron-item {
            display: flex;
            gap: 10px;
            align-items: flex-start;
            justify-content: space-between;
            padding: 12px;
            border-radius: 14px;
            border: 1px solid var(--border);
            background: var(--surface-strong);
        }

        .code-block,
        .log-output {
            margin: 0;
            padding: 14px 16px;
            border-radius: 16px;
            background: var(--code-bg);
            border: 1px solid var(--border);
            overflow: auto;
            line-height: 1.7;
            font-size: 0.86rem;
            color: var(--text);
        }

        .log-item {
            display: grid;
            gap: 12px;
        }

        .log-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 14px;
        }

        .log-context {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .context-chip {
            padding: 6px 10px;
            border-radius: 999px;
            background: var(--surface);
            border: 1px solid var(--border);
            color: var(--muted);
            font-size: 0.78rem;
        }

        .split-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 360px;
            gap: 18px;
        }

        .empty-state {
            text-align: center;
            padding: 28px;
        }

        .empty-state h3 {
            margin-bottom: 8px;
            font-size: 1rem;
        }

        .muted-link {
            color: var(--accent);
            font-weight: 700;
        }

        @media (max-width: 1180px) {
            .grid-metrics { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .hero-card,
            .hero-side,
            .split-grid,
            .services-grid,
            .two-panel-grid { grid-template-columns: 1fr; }
            .hero-card,
            .hero-side { grid-column: span 12; }
            .project-summary-grid,
            .git-metric-grid,
            .git-workbench,
            .git-highlight { grid-template-columns: 1fr; }
        }

        @media (max-width: 940px) {
            .layout {
                grid-template-columns: 1fr;
            }

            .sidebar {
                position: fixed;
                inset: 0 auto 0 0;
                width: min(86vw, 320px);
                z-index: 20;
                transform: translateX(-100%);
                transition: transform 0.22s ease;
            }

            body.nav-open .sidebar {
                transform: translateX(0);
            }

            .mobile-nav-toggle {
                display: inline-flex;
            }

            .content {
                padding: 20px 16px 28px;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }
        }

        @media (max-width: 680px) {
            .grid-metrics,
            .form-grid {
                grid-template-columns: 1fr;
            }

            .git-toolbar {
                align-items: stretch;
            }

            .git-search {
                max-width: none;
            }

            .topbar-actions,
            .project-head,
            .status-item,
            .service-item,
            .log-top,
            .cron-item {
                flex-direction: column;
                align-items: stretch;
            }

            button,
            .button-link {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<div class="layout">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-inner">
            <div class="brand">
                <div class="brand-badge">
                    <img src="logo.svg" alt="Laravel Dev logo">
                </div>
                <div>
                    <div class="brand-title">Laravel Dev</div>
                    <div class="brand-subtitle">Linux local control panel</div>
                </div>
            </div>

            <nav class="nav-list" aria-label="Sidebar">
                <?php
                $navItems = [
                    'dashboard' => ['icon' => '◎', 'title' => 'Dashboard', 'subtitle' => 'Overview & activity'],
                    'projects' => ['icon' => '▦', 'title' => 'Projects', 'subtitle' => 'Manage local apps'],
                    'create' => ['icon' => '＋', 'title' => 'Create Project', 'subtitle' => 'Scaffold a new app'],
                    'link' => ['icon' => '⇢', 'title' => 'Link Project', 'subtitle' => 'Bring existing code'],
                    'git' => ['icon' => '⑂', 'title' => 'Git', 'subtitle' => 'Clone, pull, push'],
                    'services' => ['icon' => '◌', 'title' => 'Services', 'subtitle' => 'Runtime health'],
                    'settings' => ['icon' => '⚙', 'title' => 'Settings', 'subtitle' => 'Paths and defaults'],
                    'logs' => ['icon' => '≡', 'title' => 'Logs', 'subtitle' => 'Errors and output'],
                ];
                foreach ($navItems as $view => $meta):
                ?>
                    <a class="nav-link <?= $currentView === $view ? 'active' : '' ?>" href="<?= h(view_url($view)) ?>">
                        <span class="nav-icon"><?= h($meta['icon']) ?></span>
                        <span class="nav-text">
                            <strong><?= h($meta['title']) ?></strong>
                            <span><?= h($meta['subtitle']) ?></span>
                        </span>
                    </a>
                <?php endforeach; ?>
            </nav>

            <div class="sidebar-footer">
                <h3>Current setup</h3>
                <p><?= h($projectCount) ?> project(s) discovered, <?= h($coreActiveCount) ?> core service(s) active, logs stored in <code><?= h($activityLogFile) ?></code>.</p>
            </div>
        </div>
    </aside>

    <main class="content">
        <div class="topbar">
            <div>
                <button class="mobile-nav-toggle" type="button" id="mobileNavToggle">Menu</button>
                <h1 class="page-title"><?= h($activeViewTitle) ?></h1>
                <p class="page-subtitle"><?= h($activeViewSubtitle) ?></p>
            </div>
            <div class="topbar-actions">
                <span class="version-pill">v<?= h($version) ?></span>
                <button class="theme-toggle" type="button" id="themeToggle">Theme</button>
            </div>
        </div>

        <div class="stack">
            <?php if ($message !== ''): ?>
                <div class="alert success" role="status">
                    <div>✓</div>
                    <div>
                        <strong>Action completed</strong>
                        <p><?= h($message) ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($error !== ''): ?>
                <div class="alert error" role="alert">
                    <div>!</div>
                    <div>
                        <strong>Action failed</strong>
                        <p><?= nl2br(h($error)) ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($logNotice !== ''): ?>
                <div class="alert warning" role="alert">
                    <div>!</div>
                    <div>
                        <strong>Log storage warning</strong>
                        <p><?= h($logNotice) ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($currentView === 'dashboard'): ?>
                <section class="grid-metrics">
                    <article class="metric-card">
                        <div class="metric-label">Projects</div>
                        <div class="metric-value"><?= h(metric_number($projectCount)) ?></div>
                        <div class="metric-note">Detected from <?= h($sitesDir) ?> and linked Nginx sites.</div>
                    </article>
                    <article class="metric-card">
                        <div class="metric-label">Core Services</div>
                        <div class="metric-value"><?= h(metric_number($coreActiveCount)) ?>/<?= h(metric_number(count($services))) ?></div>
                        <div class="metric-note"><?= h(metric_number($coreInactiveCount)) ?> service(s) need attention.</div>
                    </article>
                    <article class="metric-card">
                        <div class="metric-label">Optional Services</div>
                        <div class="metric-value"><?= h(metric_number($optionalActiveCount)) ?>/<?= h(metric_number($optionalInstalledCount)) ?></div>
                        <div class="metric-note">Installed extras like Mailpit, Meilisearch, or MinIO.</div>
                    </article>
                    <article class="metric-card">
                        <div class="metric-label">Last Operation</div>
                        <div class="metric-value"><?= is_array($latestActivity) ? h(strtoupper((string)($latestActivity['status'] ?? 'info'))) : 'NONE' ?></div>
                        <div class="metric-note"><?= is_array($latestActivity) ? h((string)($latestActivity['message'] ?? '')) : 'No activity recorded yet.' ?></div>
                    </article>
                </section>

                <section class="hero-grid">
                    <article class="hero-card">
                        <h2>Everything important is one click away.</h2>
                        <p>The dashboard now surfaces health, recent activity, and shortcuts first so the user can understand the environment before taking action. Use the quick actions below for the most common tasks.</p>
                        <div class="quick-actions">
                            <a class="button-link button-primary" href="<?= h(view_url('create')) ?>">Create Project</a>
                            <a class="button-link button-secondary" href="<?= h(view_url('projects')) ?>">Open Projects</a>
                            <a class="button-link button-secondary" href="<?= h(view_url('git')) ?>">Open Git</a>
                            <a class="button-link button-secondary" href="<?= h(view_url('services')) ?>">Review Services</a>
                            <a class="button-link button-secondary" href="<?= h(view_url('logs')) ?>">Open Logs</a>
                        </div>
                    </article>
                    <div class="hero-side">
                        <article class="mini-stat">
                            <span>Log file</span>
                            <strong><?= is_file($activityLogFile) ? 'Ready' : 'Pending' ?></strong>
                            <p class="helper-text"><?= h($activityLogFile) ?></p>
                        </article>
                        <article class="mini-stat">
                            <span>Theme mode</span>
                            <strong>Auto + Manual</strong>
                            <p class="helper-text">Follows the system by default and stores the override in the browser.</p>
                        </article>
                    </div>
                </section>

                <section class="two-panel-grid">
                    <article class="panel" style="grid-column: span 7;">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Core service health</h2>
                                <p class="panel-subtitle">A quick read on Nginx, database, and PHP-FPM services.</p>
                            </div>
                            <a class="button-link button-secondary" href="<?= h(view_url('services')) ?>">Open Services</a>
                        </div>
                        <div class="panel-body">
                            <div class="dashboard-status-list">
                                <?php foreach ($services as $svcName => $svcStatus): ?>
                                    <?php $svcTone = status_class($svcStatus); ?>
                                    <div class="status-item">
                                        <div class="status-meta">
                                            <strong><?= h($svcName) ?></strong>
                                            <span><?= h(status_label($svcStatus)) ?></span>
                                        </div>
                                        <span class="status-pill tone-<?= h($svcTone === 'bad' ? 'error' : ($svcTone === 'warn' ? 'warn' : 'ok')) ?>"><?= h($svcStatus) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </article>

                    <article class="panel" style="grid-column: span 5;">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Latest activity</h2>
                                <p class="panel-subtitle">Recent success and error signals captured from actions in the panel.</p>
                            </div>
                            <a class="button-link button-secondary" href="<?= h(view_url('logs')) ?>">All Logs</a>
                        </div>
                        <div class="panel-body">
                            <?php if ($latestActivity !== null): ?>
                                <div class="log-item">
                                    <div class="log-top">
                                        <div>
                                            <strong><?= h((string)($latestActivity['message'] ?? 'Activity entry')) ?></strong>
                                            <small><?= h((string)($latestActivity['timestamp'] ?? '')) ?></small>
                                        </div>
                                        <span class="log-pill tone-<?= h($lastActionTone === 'error' ? 'error' : 'ok') ?>"><?= h((string)($latestActivity['status'] ?? 'info')) ?></span>
                                    </div>
                                    <div class="log-context">
                                        <span class="context-chip">action: <?= h((string)($latestActivity['action'] ?? '-')) ?></span>
                                        <?php if (!empty($latestActivity['context']['target'])): ?>
                                            <span class="context-chip">target: <?= h((string)$latestActivity['context']['target']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($latestActivity['output'])): ?>
                                        <pre class="log-output"><?= h((string)$latestActivity['output']) ?></pre>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="empty-state">
                                    <h3>No activity yet</h3>
                                    <p>Your first action in the panel will appear here and inside the Logs tab.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </article>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'create'): ?>
                <section class="split-grid">
                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Create Laravel app</h2>
                                <p class="panel-subtitle">Provision a classic Laravel project inside the Laravel storage root.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <form method="post">
                                <input type="hidden" name="action" value="create">
                                <?= current_view_input('create') ?>
                                <div class="form-grid">
                                    <label>
                                        Project name
                                        <input type="text" name="project_name" placeholder="e.g. my-blog" required>
                                    </label>
                                    <label>
                                        PHP version
                                        <select name="php_version">
                                            <?php foreach ($availablePhpVersions as $version): ?>
                                                <option value="<?= h($version) ?>" <?= $version === $defaultPhpVersion ? 'selected' : '' ?>>PHP <?= h($version) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <p class="helper-text">Laravel apps are created inside <code><?= h($settings['LARAVEL_SITES_DIR']) ?></code>.</p>
                                <div class="button-row">
                                    <button class="button-primary" type="submit">Create Laravel Project</button>
                                </div>
                            </form>
                        </div>
                    </article>

                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Create Node workspace app</h2>
                                <p class="panel-subtitle">Scaffold Next.js, Nuxt, or Nest and register it as a managed project with runtime, port, and domain metadata.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <form method="post">
                                <input type="hidden" name="action" value="create_node">
                                <?= current_view_input('create') ?>
                                <div class="form-grid">
                                    <label>
                                        Project name
                                        <input type="text" name="project_name" placeholder="e.g. client-web" required>
                                    </label>
                                    <label>
                                        Framework
                                        <select name="project_type">
                                            <?php foreach (['next' => 'Next.js', 'nuxt' => 'Nuxt', 'nest' => 'NestJS'] as $value => $label): ?>
                                                <option value="<?= h($value) ?>"><?= h($label) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-grid">
                                    <label>
                                        Role
                                        <select name="app_role">
                                            <?php foreach (['frontend', 'backend', 'service'] as $role): ?>
                                                <option value="<?= h($role) ?>"><?= h(ucfirst($role)) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                    <label>
                                        Workspace ID
                                        <input type="text" name="workspace_id" placeholder="optional-shared-workspace">
                                    </label>
                                </div>
                                <p class="helper-text">Next and Nuxt default to <code><?= h($settings['NODE_FRONTEND_DIR']) ?></code>; Nest defaults to <code><?= h($settings['NODE_BACKEND_DIR']) ?></code>.</p>
                                <div class="button-row">
                                    <button class="button-primary" type="submit">Create Node Project</button>
                                    <a class="button-link button-secondary" href="<?= h(view_url('dashboard')) ?>">Back to Dashboard</a>
                                </div>
                            </form>
                        </div>
                    </article>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'link'): ?>
                <section class="split-grid">
                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Link Laravel project</h2>
                                <p class="panel-subtitle">Register an existing Laravel codebase and wire it into the local stack.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <form method="post">
                                <input type="hidden" name="action" value="link">
                                <?= current_view_input('link') ?>
                                <div class="form-grid">
                                    <label>
                                        Project name
                                        <span class="field-note">This becomes <code>name.test</code>.</span>
                                        <input type="text" name="project_name" placeholder="e.g. legacy-site" required>
                                    </label>
                                    <label>
                                        PHP version
                                        <select name="php_version">
                                            <?php foreach ($availablePhpVersions as $version): ?>
                                                <option value="<?= h($version) ?>" <?= $version === $defaultPhpVersion ? 'selected' : '' ?>>PHP <?= h($version) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <label>
                                    Full path to project root
                                    <input type="text" name="project_path" placeholder="e.g. /var/www/site" required>
                                </label>
                                <div class="button-row">
                                    <button class="button-primary" type="submit">Link Laravel Project</button>
                                </div>
                            </form>
                        </div>
                    </article>

                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Link Node project</h2>
                                <p class="panel-subtitle">Bring in an existing Next, Nuxt, or Nest codebase, assign it a domain, and optionally attach it to a workspace.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <form method="post">
                                <input type="hidden" name="action" value="link_node">
                                <?= current_view_input('link') ?>
                                <div class="form-grid">
                                    <label>
                                        Project name
                                        <input type="text" name="project_name" placeholder="e.g. client-api" required>
                                    </label>
                                    <label>
                                        Framework
                                        <select name="project_type">
                                            <?php foreach (['next' => 'Next.js', 'nuxt' => 'Nuxt', 'nest' => 'NestJS'] as $value => $label): ?>
                                                <option value="<?= h($value) ?>"><?= h($label) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="form-grid">
                                    <label>
                                        Role
                                        <select name="app_role">
                                            <?php foreach (['frontend', 'backend', 'service'] as $role): ?>
                                                <option value="<?= h($role) ?>"><?= h(ucfirst($role)) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                    <label>
                                        Workspace ID
                                        <input type="text" name="workspace_id" placeholder="optional-shared-workspace">
                                    </label>
                                </div>
                                <label>
                                    Full path to project root
                                    <input type="text" name="project_path" placeholder="e.g. /srv/apps/client-api" required>
                                </label>
                                <div class="button-row">
                                    <button class="button-primary" type="submit">Link Node Project</button>
                                    <a class="button-link button-secondary" href="<?= h(view_url('projects')) ?>">View Projects</a>
                                </div>
                            </form>
                        </div>
                    </article>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'git'): ?>
                <section class="split-grid">
                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <span class="section-kicker">Git Workspace</span>
                                <h2 class="panel-title">Clone a repository</h2>
                                <p class="panel-subtitle">Bring in a repository, let Laravel Dev link it if it is a Laravel app, then manage the day-to-day workflow from the same page.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if (!git_is_available()): ?>
                                <div class="empty-state">
                                    <h3>Git is not available</h3>
                                    <p>Install <code>git</code> first, then come back to use clone, pull, push, and fetch from this tab.</p>
                                </div>
                            <?php else: ?>
                                <form method="post" autocomplete="off">
                                    <input type="hidden" name="action" value="git_clone">
                                    <?= current_view_input('git') ?>
                                    <div class="form-grid">
                                        <label>
                                            Project name
                                            <span class="field-note">This becomes <code>name.test</code> if the repository is a Laravel app.</span>
                                            <input type="text" name="project_name" placeholder="e.g. client-portal" required>
                                        </label>
                                        <label>
                                            PHP version
                                            <select name="php_version">
                                                <?php foreach ($availablePhpVersions as $version): ?>
                                                    <option value="<?= h($version) ?>" <?= $version === $defaultPhpVersion ? 'selected' : '' ?>>PHP <?= h($version) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </label>
                                    </div>
                                    <label>
                                        Repository URL
                                        <span class="field-note">Examples: <code>https://github.com/org/repo.git</code> or <code>git@github.com:org/repo.git</code>.</span>
                                        <input type="text" name="repository_url" placeholder="https://github.com/org/repo.git" required>
                                    </label>
                                    <label>
                                        Token (optional fallback)
                                        <span class="field-note">Usually you can leave this empty. Laravel Dev now asks for an HTTPS token in a popup only if Git actually needs one.</span>
                                        <input type="password" name="git_token" placeholder="Optional access token">
                                    </label>
                                    <p class="helper-text">The repository is cloned into <code><?= h($sitesDir) ?></code>. If Laravel files are detected, Laravel Dev will also configure Nginx, database defaults, and permissions.</p>
                                    <div class="button-row">
                                        <button class="button-primary" type="submit">Clone Repository</button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </article>

                    <aside class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Git overview</h2>
                                <p class="panel-subtitle">A quick snapshot of the repositories Laravel Dev can already control.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="stack">
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Detected Git repositories</strong>
                                        <span><?= h((string)$gitRepoCount) ?> repository(ies)</span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Working trees with local changes</strong>
                                        <span><?= h((string)$gitDirtyCount) ?> repository(ies)</span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Supported actions</strong>
                                        <span><code>clone</code>, <code>fetch</code>, <code>pull</code>, <code>push</code>, <code>commit</code>, and custom Git commands.</span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Credential flow</strong>
                                        <span>HTTPS token is requested in a popup only when Git needs it.</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </aside>
                </section>

                <section class="panel">
                    <div class="panel-header">
                        <div>
                            <span class="section-kicker">Fast Flow</span>
                            <h2 class="panel-title">Repository actions</h2>
                            <p class="panel-subtitle">Search a repository, inspect its state, write a commit, or run a custom Git command without leaving the dashboard.</p>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if ($gitProjects === []): ?>
                            <div class="empty-state">
                                <h3>No Git repositories detected</h3>
                                <p>Clone a repository from the form above or link a project that already contains a <code>.git</code> directory.</p>
                            </div>
                        <?php else: ?>
                            <div class="git-highlight">
                                <article class="git-highlight-card">
                                    <strong>Repositories</strong>
                                    <span><?= h((string)$gitRepoCount) ?></span>
                                    <small>Projects Laravel Dev can currently control through Git.</small>
                                </article>
                                <article class="git-highlight-card">
                                    <strong>Dirty trees</strong>
                                    <span><?= h((string)$gitDirtyCount) ?></span>
                                    <small>Repositories that still contain local changes.</small>
                                </article>
                                <article class="git-highlight-card">
                                    <strong>Popup auth</strong>
                                    <span><?= has_askpass_helper() ? 'Ready' : 'Limited' ?></span>
                                    <small><?= has_askpass_helper() ? 'Token and sudo prompts can open in a GUI popup.' : 'Install zenity or another askpass helper for the smoothest auth flow.' ?></small>
                                </article>
                                <article class="git-highlight-card">
                                    <strong>Common flow</strong>
                                    <span>Fetch → Commit</span>
                                    <small>Quick actions below are optimized for the most common local dev loop.</small>
                                </article>
                            </div>

                            <div class="git-toolbar">
                                <div class="command-palette">
                                    <button class="command-chip git-template-button" type="button" data-template="status --short --branch">Status</button>
                                    <button class="command-chip git-template-button" type="button" data-template="log --oneline -8">Recent log</button>
                                    <button class="command-chip git-template-button" type="button" data-template="diff --stat">Diff stat</button>
                                    <button class="command-chip git-template-button" type="button" data-template="branch --all">Branches</button>
                                    <button class="command-chip git-template-button" type="button" data-template="stash list">Stash list</button>
                                </div>
                                <label class="git-search">
                                    Search repositories
                                    <input type="search" id="gitRepoSearch" placeholder="Filter by name, branch, path, or remote">
                                </label>
                            </div>

                            <div class="projects-list compact" id="gitProjectsList">
                                <?php foreach ($gitProjects as $projectName => $gitProject): ?>
                                    <?php
                                    $syncSummary = [];
                                    $statusCounts = git_status_counts((string)$gitProject['status_output']);
                                    if (($gitProject['upstream'] ?? '') !== '') {
                                        $syncSummary[] = 'Upstream: ' . $gitProject['upstream'];
                                        $syncSummary[] = 'Ahead ' . (string)$gitProject['ahead'];
                                        $syncSummary[] = 'Behind ' . (string)$gitProject['behind'];
                                    } else {
                                        $syncSummary[] = 'No upstream tracking branch';
                                    }
                                    ?>
                                    <article
                                        class="project-card git-card"
                                        data-git-search="<?= h(strtolower($projectName . ' ' . (string)$gitProject['path'] . ' ' . (string)$gitProject['branch'] . ' ' . (string)$gitProject['remote'])) ?>"
                                    >
                                        <div class="project-head">
                                            <div>
                                                <div class="project-name"><?= h($projectName) ?></div>
                                                <div class="project-meta"><?= h($gitProject['path']) ?></div>
                                                <span class="badge tone-brand"><?= h((string)$gitProject['branch']) ?></span>
                                                <span class="badge <?= ($gitProject['dirty'] ?? false) ? 'tone-warn' : 'tone-ok' ?>">
                                                    <?= ($gitProject['dirty'] ?? false) ? 'Local Changes' : 'Clean' ?>
                                                </span>
                                            </div>
                                            <div class="project-actions inline-forms">
                                                <?php foreach (['git_fetch' => ['label' => 'Fetch', 'class' => 'button-secondary'], 'git_pull' => ['label' => 'Pull', 'class' => 'button-primary'], 'git_push' => ['label' => 'Push', 'class' => 'button-secondary']] as $gitAction => $meta): ?>
                                                    <form method="post">
                                                        <input type="hidden" name="action" value="<?= h($gitAction) ?>">
                                                        <input type="hidden" name="project_name" value="<?= h($projectName) ?>">
                                                        <input type="hidden" name="project_path" value="<?= h((string)$gitProject['path']) ?>">
                                                        <?= current_view_input('git') ?>
                                                        <button class="<?= h($meta['class']) ?>" type="submit"><?= h($meta['label']) ?></button>
                                                    </form>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>

                                        <div class="project-summary-grid">
                                            <div class="git-metric">
                                                <strong>Remote</strong>
                                                <span><?= h((string)$gitProject['remote']) ?></span>
                                            </div>
                                            <div class="git-metric">
                                                <strong>Sync</strong>
                                                <span><?= h(implode(' • ', $syncSummary)) ?></span>
                                            </div>
                                            <div class="git-metric">
                                                <strong>Health</strong>
                                                <span><?= $statusCounts['conflicts'] > 0 ? h((string)$statusCounts['conflicts']) . ' conflict(s)' : (($gitProject['dirty'] ?? false) ? 'Needs attention' : 'Ready to ship') ?></span>
                                            </div>
                                        </div>

                                        <div class="git-metric-grid">
                                            <div class="git-metric">
                                                <strong>Changed</strong>
                                                <span><?= h((string)$statusCounts['changed']) ?></span>
                                            </div>
                                            <div class="git-metric">
                                                <strong>Untracked</strong>
                                                <span><?= h((string)$statusCounts['untracked']) ?></span>
                                            </div>
                                            <div class="git-metric">
                                                <strong>Conflicts</strong>
                                                <span><?= h((string)$statusCounts['conflicts']) ?></span>
                                            </div>
                                        </div>

                                        <div class="stack">
                                            <div>
                                                <strong style="display: block; margin-bottom: 10px;">Working tree</strong>
                                                <pre class="code-block"><?= h((string)$gitProject['status_output']) ?></pre>
                                            </div>
                                            <div class="git-workbench">
                                                <form method="post" class="git-panel">
                                                    <input type="hidden" name="action" value="git_commit">
                                                    <input type="hidden" name="project_name" value="<?= h($projectName) ?>">
                                                    <input type="hidden" name="project_path" value="<?= h((string)$gitProject['path']) ?>">
                                                    <?= current_view_input('git') ?>
                                                    <div class="git-panel-title">
                                                        <h3>Commit flow</h3>
                                                        <p>Write a clean message and commit tracked file changes directly from the card.</p>
                                                    </div>
                                                    <label>
                                                        Commit message
                                                        <input type="text" name="commit_message" placeholder="Describe this change" required>
                                                    </label>
                                                    <label style="display: flex; align-items: center; gap: 10px;">
                                                        <input type="checkbox" name="commit_all" value="1" checked>
                                                        <span>Stage tracked file changes with <code>--all</code></span>
                                                    </label>
                                                    <div class="button-row tight">
                                                        <button class="button-primary" type="submit">Commit Now</button>
                                                    </div>
                                                </form>
                                                <form method="post" class="git-panel">
                                                    <input type="hidden" name="action" value="git_run">
                                                    <input type="hidden" name="project_name" value="<?= h($projectName) ?>">
                                                    <input type="hidden" name="project_path" value="<?= h((string)$gitProject['path']) ?>">
                                                    <?= current_view_input('git') ?>
                                                    <div class="git-panel-title">
                                                        <h3>Command runner</h3>
                                                        <p>Run advanced Git commands without leaving the dashboard.</p>
                                                    </div>
                                                    <div class="command-palette">
                                                        <button class="command-chip git-template-button" type="button" data-target="git-command-<?= h($projectName) ?>" data-template="log --oneline -5">Recent log</button>
                                                        <button class="command-chip git-template-button" type="button" data-target="git-command-<?= h($projectName) ?>" data-template="diff --stat">Diff stat</button>
                                                        <button class="command-chip git-template-button" type="button" data-target="git-command-<?= h($projectName) ?>" data-template="checkout ">Checkout</button>
                                                        <button class="command-chip git-template-button" type="button" data-target="git-command-<?= h($projectName) ?>" data-template="stash push -u">Stash</button>
                                                    </div>
                                                    <label>
                                                        Run any Git command
                                                        <span class="field-note">Examples: <code>log --oneline -5</code>, <code>checkout feature/login</code>, <code>stash push -u</code>.</span>
                                                        <input id="git-command-<?= h($projectName) ?>" class="git-command-input" type="text" name="git_args" placeholder="log --oneline -5" required>
                                                    </label>
                                                    <div class="button-row tight">
                                                        <button class="button-secondary" type="submit">Run Git Command</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </article>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'services'): ?>
                <section class="services-grid">
                    <article class="panel" style="grid-column: span 7;">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Core services</h2>
                                <p class="panel-subtitle">Main runtime services that Laravel Dev depends on.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="service-list">
                                <?php foreach ($services as $svcName => $svcStatus): ?>
                                    <?php $svcTone = status_class($svcStatus); ?>
                                    <div class="service-item">
                                        <div class="service-meta">
                                            <strong><?= h($svcName) ?></strong>
                                            <span><?= h(status_label($svcStatus)) ?></span>
                                        </div>
                                        <span class="status-pill tone-<?= h($svcTone === 'bad' ? 'error' : ($svcTone === 'warn' ? 'warn' : 'ok')) ?>"><?= h($svcStatus) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="button-row" style="margin-top: 18px;">
                                <form method="post">
                                    <input type="hidden" name="action" value="services_start">
                                    <?= current_view_input('services') ?>
                                    <button class="button-primary" type="submit">Start Core Services</button>
                                </form>
                                <form method="post">
                                    <input type="hidden" name="action" value="services_stop">
                                    <?= current_view_input('services') ?>
                                    <button class="button-secondary" type="submit">Stop Core Services</button>
                                </form>
                            </div>
                        </div>
                    </article>

                    <article class="panel" style="grid-column: span 5;">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Sudo session</h2>
                                <p class="panel-subtitle">Laravel Dev keeps sudo authorization warm for up to 10 minutes without storing the password.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="status-item">
                                <div class="status-meta">
                                    <strong>Status</strong>
                                    <span><?= $sudoStatus['active'] ? 'Active for about ' . h((string)max(1, (int)ceil($sudoStatus['remaining_seconds'] / 60))) . ' minute(s).' : 'Inactive. Refresh before privileged actions if you want a smoother flow.' ?></span>
                                </div>
                                <span class="status-pill tone-<?= $sudoStatus['active'] ? 'ok' : 'warn' ?>"><?= $sudoStatus['active'] ? 'active' : 'inactive' ?></span>
                            </div>
                            <div class="button-row" style="margin-top: 18px;">
                                <form method="post">
                                    <input type="hidden" name="action" value="sudo_refresh">
                                    <?= current_view_input('services') ?>
                                    <button class="button-primary" type="submit">Refresh sudo session</button>
                                </form>
                            </div>
                        </div>
                    </article>

                    <article class="panel" style="grid-column: span 12;">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Optional services</h2>
                                <p class="panel-subtitle">Only installed optional services appear here.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if ($optionalServices === []): ?>
                                <div class="empty-state">
                                    <h3>No optional services detected</h3>
                                    <p>Install Mailpit, Meilisearch, or MinIO to manage them from this panel.</p>
                                </div>
                            <?php else: ?>
                                <div class="service-list">
                                    <?php foreach ($optionalServices as $svc): ?>
                                        <?php $svcTone = status_class($svc['status']); ?>
                                        <div class="service-item">
                                            <div class="service-meta">
                                                <strong><?= h($svc['name']) ?></strong>
                                                <span><?= h(status_label($svc['status'])) ?></span>
                                            </div>
                                            <div class="button-row">
                                                <span class="status-pill tone-<?= h($svcTone === 'bad' ? 'error' : ($svcTone === 'warn' ? 'warn' : 'ok')) ?>"><?= h($svc['status']) ?></span>
                                                <form method="post">
                                                    <input type="hidden" name="service_unit" value="<?= h($svc['unit']) ?>">
                                                    <?= current_view_input('services') ?>
                                                    <?php if ($svc['status'] === 'active'): ?>
                                                        <input type="hidden" name="action" value="optional_service_stop">
                                                        <button class="button-secondary" type="submit">Stop</button>
                                                    <?php else: ?>
                                                        <input type="hidden" name="action" value="optional_service_start">
                                                        <button class="button-primary" type="submit">Start</button>
                                                    <?php endif; ?>
                                                </form>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <p class="helper-text" style="margin-top: 18px;">Use <code>systemctl enable SERVICE</code> if you want these services to start on boot.</p>
                            <?php endif; ?>
                        </div>
                    </article>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'projects'): ?>
                <section class="panel">
                    <div class="panel-header">
                        <div>
                            <h2 class="panel-title">Project management</h2>
                            <p class="panel-subtitle">Search, filter, operate, and connect Laravel plus Node workspaces from one place.</p>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php if ($projectCount === 0): ?>
                            <div class="empty-state">
                                <h3>No projects found</h3>
                                <p>No registered projects were found. <a class="muted-link" href="<?= h(view_url('create')) ?>">Create one</a> or <a class="muted-link" href="<?= h(view_url('link')) ?>">link an existing project</a>.</p>
                            </div>
                        <?php else: ?>
                            <div class="git-toolbar" style="margin-bottom: 18px;">
                                <label class="git-search">
                                    Search projects
                                    <input type="search" id="projectSearch" placeholder="Filter by name, path, domain, type, workspace">
                                </label>
                                <div class="button-row tight">
                                    <label>
                                        Type
                                        <select id="projectTypeFilter">
                                            <option value="">All</option>
                                            <option value="laravel">Laravel</option>
                                            <option value="next">Next.js</option>
                                            <option value="nuxt">Nuxt</option>
                                            <option value="nest">NestJS</option>
                                        </select>
                                    </label>
                                    <label>
                                        Status
                                        <select id="projectStatusFilter">
                                            <option value="">All</option>
                                            <option value="ready">Ready</option>
                                            <option value="running">Running</option>
                                            <option value="stopped">Stopped</option>
                                        </select>
                                    </label>
                                    <label>
                                        Exposure
                                        <select id="projectExposureFilter">
                                            <option value="">All</option>
                                            <option value="local">Local</option>
                                            <option value="lan">LAN</option>
                                            <option value="public_tunnel">Public tunnel</option>
                                            <option value="public_dns">Public DNS</option>
                                        </select>
                                    </label>
                                </div>
                            </div>

                            <section class="split-grid" style="margin-bottom: 18px;">
                                <article class="panel">
                                    <div class="panel-header">
                                        <div>
                                            <h2 class="panel-title">Workspace linking</h2>
                                            <p class="panel-subtitle">Bind a frontend app to a backend service and store the relationship for API URL wiring.</p>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form method="post">
                                            <input type="hidden" name="action" value="workspace_link">
                                            <?= current_view_input('projects') ?>
                                            <div class="form-grid">
                                                <label>
                                                    Frontend project
                                                    <select name="frontend_project">
                                                        <option value="">Select frontend</option>
                                                        <?php foreach ($projects as $projectName => $projectMeta): ?>
                                                            <?php if (in_array($projectMeta['role'], ['frontend', 'fullstack'], true)): ?>
                                                                <option value="<?= h($projectName) ?>"><?= h($projectName . ' (' . $projectMeta['type'] . ')') ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </label>
                                                <label>
                                                    Backend project
                                                    <select name="backend_project">
                                                        <option value="">Select backend</option>
                                                        <?php foreach ($projects as $projectName => $projectMeta): ?>
                                                            <?php if (in_array($projectMeta['role'], ['backend', 'service', 'fullstack'], true)): ?>
                                                                <option value="<?= h($projectName) ?>"><?= h($projectName . ' (' . $projectMeta['type'] . ')') ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </label>
                                            </div>
                                            <label>
                                                Workspace ID
                                                <input type="text" name="workspace_id" placeholder="e.g. client-suite">
                                            </label>
                                            <button class="button-primary" type="submit">Save Workspace Relation</button>
                                        </form>
                                    </div>
                                </article>
                            </section>

                            <div class="projects-list compact" id="managedProjectsList">
                                <?php foreach ($projects as $pname => $project): ?>
                                    <?php
                                    $ppath = (string)$project['path'];
                                    $isLaravel = ($project['type'] ?? '') === 'laravel';
                                    $projectType = (string)($project['type'] ?? 'laravel');
                                    $projectRole = (string)($project['role'] ?? 'fullstack');
                                    $projectStatus = (string)($project['status'] ?? 'ready');
                                    $projectDomain = (string)($project['domain'] ?? ($pname . '.test'));
                                    $projectExposure = (string)($project['exposure_mode'] ?? 'local');
                                    $workspaceId = (string)($project['workspace_id'] ?? '');
                                    $projEnv = $isLaravel ? read_project_env($ppath . '/.env') : ['DB_CONNECTION' => '', 'DB_HOST' => '', 'DB_PORT' => '', 'DB_DATABASE' => '', 'DB_USERNAME' => '', 'DB_PASSWORD' => ''];
                                    $projectCrons = read_project_crons($ppath);
                                    $projectTone = $projectStatus === 'running' ? 'ok' : ($projectStatus === 'stopped' ? 'warn' : 'info');
                                    ?>
                                    <article
                                        class="project-card git-card"
                                        data-project-search="<?= h(strtolower($pname . ' ' . $ppath . ' ' . $projectDomain . ' ' . $projectType . ' ' . $projectRole . ' ' . $workspaceId . ' ' . (string)($project['public_url'] ?? ''))) ?>"
                                        data-project-type="<?= h($projectType) ?>"
                                        data-project-status="<?= h($projectStatus) ?>"
                                        data-project-exposure="<?= h($projectExposure) ?>"
                                    >
                                        <div class="project-head">
                                            <div>
                                                <div class="project-name">
                                                    <a href="http://<?= rawurlencode($projectDomain) ?>" target="_blank" rel="noreferrer"><?= h($pname) ?></a>
                                                </div>
                                                <div class="project-meta"><?= h($ppath) ?></div>
                                                <span class="badge tone-brand"><?= h($projectType) ?></span>
                                                <span class="badge"><?= h($projectRole) ?></span>
                                                <span class="badge <?= $projectStatus === 'running' ? 'tone-ok' : 'tone-warn' ?>"><?= h($projectStatus) ?></span>
                                            </div>
                                            <div class="project-actions">
                                                <?php if ($isLaravel): ?>
                                                    <form method="post">
                                                        <input type="hidden" name="action" value="repair">
                                                        <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                        <?= current_view_input('projects') ?>
                                                        <button class="button-secondary" type="submit">Repair</button>
                                                    </form>
                                                <?php else: ?>
                                                    <form method="post">
                                                        <input type="hidden" name="action" value="<?= $projectStatus === 'running' ? 'stop_project' : 'start_project' ?>">
                                                        <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                        <?= current_view_input('projects') ?>
                                                        <button class="<?= $projectStatus === 'running' ? 'button-secondary' : 'button-primary' ?>" type="submit"><?= $projectStatus === 'running' ? 'Stop' : 'Start' ?></button>
                                                    </form>
                                                    <form method="post">
                                                        <input type="hidden" name="action" value="restart_project">
                                                        <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                        <?= current_view_input('projects') ?>
                                                        <button class="button-secondary" type="submit">Restart</button>
                                                    </form>
                                                <?php endif; ?>
                                                <form method="post" onsubmit="return confirm('Delete project <?= h($pname) ?>?');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                    <?= current_view_input('projects') ?>
                                                    <button class="button-danger" type="submit">Delete</button>
                                                </form>
                                            </div>
                                        </div>

                                        <div class="project-summary-grid">
                                            <div class="git-metric">
                                                <strong>Runtime</strong>
                                                <span><?= h((string)($project['runtime'] ?? 'php-fpm')) ?></span>
                                            </div>
                                            <div class="git-metric">
                                                <strong>Domain</strong>
                                                <span><?= h($projectDomain) ?></span>
                                            </div>
                                            <div class="git-metric">
                                                <strong>Exposure</strong>
                                                <span><?= h($projectExposure) ?></span>
                                            </div>
                                        </div>

                                        <div class="git-metric-grid">
                                            <div class="git-metric">
                                                <strong>Workspace</strong>
                                                <span><?= h($workspaceId !== '' ? $workspaceId : 'Not linked') ?></span>
                                            </div>
                                            <div class="git-metric">
                                                <strong>Port</strong>
                                                <span><?= h((string)($project['port'] ?: '80')) ?></span>
                                            </div>
                                            <div class="git-metric">
                                                <strong>Public URL</strong>
                                                <span><?= h((string)($project['public_url'] ?: 'Not enabled')) ?></span>
                                            </div>
                                        </div>

                                        <div class="status-item">
                                            <div class="status-meta">
                                                <strong>Current state</strong>
                                                <span><?= h('Role: ' . $projectRole . ' • Runtime: ' . (string)($project['runtime'] ?? 'php-fpm')) ?></span>
                                            </div>
                                            <span class="status-pill tone-<?= h($projectTone) ?>"><?= h($projectStatus) ?></span>
                                        </div>

                                        <?php if (!$isLaravel): ?>
                                            <form method="post" class="git-panel">
                                                <input type="hidden" name="action" value="expose_project">
                                                <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                <?= current_view_input('projects') ?>
                                                <div class="git-panel-title">
                                                    <h3>Networking / exposure</h3>
                                                    <p>Pick whether this project should stay local, be reachable on LAN, or expose a public tunnel/domain later.</p>
                                                </div>
                                                <div class="form-grid">
                                                    <label>
                                                        Exposure mode
                                                        <select name="exposure_mode">
                                                            <?php foreach (['local' => 'Local domain', 'lan' => 'LAN', 'public_tunnel' => 'Public tunnel', 'public_dns' => 'Public DNS'] as $value => $label): ?>
                                                                <option value="<?= h($value) ?>" <?= $projectExposure === $value ? 'selected' : '' ?>><?= h($label) ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </label>
                                                    <label>
                                                        Open current URL
                                                        <input type="text" value="<?= h((string)($project['public_url'] ?: ('http://' . $projectDomain))) ?>" readonly>
                                                    </label>
                                                </div>
                                                <div class="button-row">
                                                    <button class="button-secondary" type="submit">Save Exposure</button>
                                                </div>
                                            </form>
                                        <?php endif; ?>

                                        <?php if ($isLaravel): ?>
                                            <details>
                                                <summary>Database configuration</summary>
                                                <div class="details-body">
                                                    <div class="button-row" style="margin-bottom: 16px;">
                                                        <?php if ($phpmyadminUrl !== ''): ?>
                                                            <a class="button-secondary" href="<?= h($phpmyadminUrl) ?>" target="_blank" rel="noreferrer">Open phpMyAdmin</a>
                                                        <?php else: ?>
                                                            <span class="helper-text">phpMyAdmin is not installed or not reachable yet.</span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <form method="post">
                                                        <input type="hidden" name="action" value="configure_db">
                                                        <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                        <?= current_view_input('projects') ?>
                                                        <div class="form-grid">
                                                            <label>
                                                                Driver
                                                                <select name="db_connection">
                                                                    <?php foreach (['mysql', 'mariadb', 'pgsql', 'sqlite'] as $drv): ?>
                                                                        <option value="<?= h($drv) ?>" <?= $projEnv['DB_CONNECTION'] === $drv ? 'selected' : '' ?>><?= h($drv) ?></option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </label>
                                                            <label>
                                                                Port
                                                                <input type="text" name="db_port" value="<?= h($projEnv['DB_PORT'] ?: '3306') ?>">
                                                            </label>
                                                        </div>
                                                        <div class="form-grid">
                                                            <label>
                                                                Host
                                                                <input type="text" name="db_host" value="<?= h($projEnv['DB_HOST'] ?: '127.0.0.1') ?>">
                                                            </label>
                                                            <label>
                                                                Database name
                                                                <input type="text" name="db_database" value="<?= h($projEnv['DB_DATABASE'] ?: $pname) ?>">
                                                            </label>
                                                        </div>
                                                        <div class="form-grid">
                                                            <label>
                                                                Username
                                                                <input type="text" name="db_username" value="<?= h($projEnv['DB_USERNAME']) ?>">
                                                            </label>
                                                            <label>
                                                                Password
                                                                <input type="password" name="db_password" value="<?= h($projEnv['DB_PASSWORD']) ?>">
                                                            </label>
                                                        </div>
                                                        <div class="button-row">
                                                            <button class="button-primary" type="submit">Save DB Config</button>
                                                        </div>
                                                    </form>
                                                    <form method="post">
                                                        <input type="hidden" name="action" value="apply_global_db">
                                                        <input type="hidden" name="project_name" value="<?= h($pname) ?>">
                                                        <?= current_view_input('projects') ?>
                                                        <button class="button-secondary" type="submit">Apply Global DB Settings</button>
                                                    </form>
                                                    <p class="helper-text">This copies the Settings tab database defaults into the project's <code>.env</code>.</p>
                                                </div>
                                            </details>
                                        <?php endif; ?>

                                        <details>
                                            <summary>Cron jobs</summary>
                                            <div class="details-body">
                                                <?php if ($projectCrons !== []): ?>
                                                    <?php foreach ($projectCrons as $cronLine): ?>
                                                        <div class="cron-item">
                                                            <code><?= h($cronLine) ?></code>
                                                            <form method="post" onsubmit="return confirm('Remove this cron job?');">
                                                                <input type="hidden" name="action" value="remove_cron">
                                                                <input type="hidden" name="cron_line" value="<?= h($cronLine) ?>">
                                                                <?= current_view_input('projects') ?>
                                                                <button class="button-danger" type="submit">Remove</button>
                                                            </form>
                                                        </div>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <p class="helper-text">No cron jobs were found for this project path.</p>
                                                <?php endif; ?>

                                                <form method="post">
                                                    <input type="hidden" name="action" value="add_cron">
                                                    <input type="hidden" name="project_path" value="<?= h($ppath) ?>">
                                                    <?= current_view_input('projects') ?>
                                                    <label>
                                                        Schedule
                                                        <span class="field-note">Use five fields, for example <code>* * * * *</code>.</span>
                                                        <input type="text" name="cron_schedule" value="* * * * *" required>
                                                    </label>
                                                    <label>
                                                        Command
                                                        <input type="text" name="cron_command" placeholder="php artisan schedule:run >> /dev/null 2>&1" required>
                                                    </label>
                                                    <button class="button-primary" type="submit">Add Cron Job</button>
                                                </form>
                                                <p class="helper-text">The command is prefixed automatically with <code>cd <?= h($ppath) ?> &amp;&amp;</code>.</p>
                                            </div>
                                        </details>
                                    </article>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'settings'): ?>
                <section class="split-grid">
                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Global settings</h2>
                                <p class="panel-subtitle">These values are stored in the user-writable config file and used as defaults across the panel.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <form method="post">
                                <input type="hidden" name="action" value="save_settings">
                                <?= current_view_input('settings') ?>
                                <label>
                                    Default sites directory
                                    <input type="text" name="sites_dir" value="<?= h($settings['SITES_DIR']) ?>" required>
                                </label>
                                <div class="form-grid">
                                    <label>
                                        Laravel projects root
                                        <input type="text" name="laravel_sites_dir" value="<?= h($settings['LARAVEL_SITES_DIR']) ?>" required>
                                    </label>
                                    <label>
                                        Node frontend root
                                        <input type="text" name="node_frontend_dir" value="<?= h($settings['NODE_FRONTEND_DIR']) ?>" required>
                                    </label>
                                </div>
                                <div class="form-grid">
                                    <label>
                                        Node backend root
                                        <input type="text" name="node_backend_dir" value="<?= h($settings['NODE_BACKEND_DIR']) ?>" required>
                                    </label>
                                    <label>
                                        Workspaces root
                                        <input type="text" name="workspaces_dir" value="<?= h($settings['WORKSPACES_DIR']) ?>" required>
                                    </label>
                                </div>
                                <label>
                                    Database type
                                    <select name="db_type">
                                        <?php foreach (['mysql' => 'MySQL', 'mariadb' => 'MariaDB', 'pgsql' => 'PostgreSQL', 'sqlite' => 'SQLite'] as $val => $label): ?>
                                            <option value="<?= h($val) ?>" <?= $settings['DB_TYPE'] === $val ? 'selected' : '' ?>><?= h($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                                <div class="form-grid">
                                    <label>
                                        DB host
                                        <input type="text" name="db_host" value="<?= h($settings['DB_HOST']) ?>" required>
                                    </label>
                                    <label>
                                        DB port
                                        <input type="text" name="db_port" value="<?= h($settings['DB_PORT']) ?>" required>
                                    </label>
                                </div>
                                <div class="form-grid">
                                    <label>
                                        DB username
                                        <input type="text" name="db_user" value="<?= h($settings['DB_USER']) ?>" required>
                                    </label>
                                    <label>
                                        DB password
                                        <input type="password" name="db_password" value="<?= h($settings['DB_PASSWORD']) ?>">
                                    </label>
                                </div>
                                <label>
                                    Dashboard port
                                    <input type="text" name="web_port" value="<?= h($settings['WEB_PORT']) ?>" required>
                                </label>
                                <div class="form-grid">
                                    <label>
                                        Dashboard bind host
                                        <input type="text" name="web_bind_host" value="<?= h($settings['WEB_BIND_HOST']) ?>" required>
                                    </label>
                                    <label>
                                        Dashboard public host / domain
                                        <input type="text" name="web_public_host" value="<?= h($settings['WEB_PUBLIC_HOST']) ?>" required>
                                    </label>
                                </div>
                                <label>
                                    Dashboard public scheme
                                    <select name="web_public_scheme">
                                        <?php foreach (['http' => 'HTTP', 'https' => 'HTTPS'] as $val => $label): ?>
                                            <option value="<?= h($val) ?>" <?= $settings['WEB_PUBLIC_SCHEME'] === $val ? 'selected' : '' ?>><?= h($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                                <p class="helper-text">The dashboard can listen on all interfaces through <code><?= h($settings['WEB_BIND_HOST']) ?></code> while users open it from <code><?= h(dashboard_access_url($settings)) ?></code>. Set a custom host/domain here if you point DNS or a reverse proxy at this machine.</p>
                                <button class="button-primary" type="submit">Save Settings</button>
                            </form>
                        </div>
                    </article>

                    <aside class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Setup notes</h2>
                                <p class="panel-subtitle">A few details that help users avoid common issues.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="stack">
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Config file</strong>
                                        <span><?= h($userConfigFile) ?></span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Privileges</strong>
                                        <span>Privileged actions may need <code>sudo -v</code> or an askpass helper.</span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Dashboard URL</strong>
                                        <span><?= h(dashboard_access_url($settings)) ?></span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Theme storage</strong>
                                        <span>Theme preference is stored only in the browser, not in <code>config.env</code>.</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </aside>
                </section>
            <?php endif; ?>

            <?php if ($currentView === 'logs'): ?>
                <section class="split-grid">
                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Activity log</h2>
                                <p class="panel-subtitle">Every action records status, message, target, timestamp, and command output when available.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if ($activityLogs === []): ?>
                                <div class="empty-state">
                                    <h3>No logs yet</h3>
                                    <p>Once a user starts creating projects or controlling services, entries will appear here.</p>
                                </div>
                            <?php else: ?>
                                <div class="log-list">
                                    <?php foreach ($activityLogs as $entry): ?>
                                        <?php
                                        $entryStatus = (string)($entry['status'] ?? 'info');
                                        $entryTone = match ($entryStatus) {
                                            'success' => 'ok',
                                            'error' => 'error',
                                            'warning' => 'warn',
                                            default => 'info',
                                        };
                                        ?>
                                        <article class="log-item">
                                            <div class="log-top">
                                                <div>
                                                    <strong><?= h((string)($entry['message'] ?? 'Activity log')) ?></strong>
                                                    <small><?= h((string)($entry['timestamp'] ?? '')) ?></small>
                                                </div>
                                                <span class="log-pill tone-<?= h($entryTone) ?>"><?= h($entryStatus) ?></span>
                                            </div>
                                            <div class="log-context">
                                                <span class="context-chip">action: <?= h((string)($entry['action'] ?? '-')) ?></span>
                                                <?php if (!empty($entry['context']['target'])): ?>
                                                    <span class="context-chip">target: <?= h((string)$entry['context']['target']) ?></span>
                                                <?php endif; ?>
                                                <?php if (!empty($entry['context']['view'])): ?>
                                                    <span class="context-chip">view: <?= h((string)$entry['context']['view']) ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <?php if (!empty($entry['output'])): ?>
                                                <pre class="log-output"><?= h((string)$entry['output']) ?></pre>
                                            <?php endif; ?>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </article>

                    <aside class="panel">
                        <div class="panel-header">
                            <div>
                                <h2 class="panel-title">Log details</h2>
                                <p class="panel-subtitle">Quick reference for where logs live and what they contain.</p>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="stack">
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Stored at</strong>
                                        <span><?= h($activityLogFile) ?></span>
                                    </div>
                                </div>
                                <div class="status-item">
                                    <div class="status-meta">
                                        <strong>Included data</strong>
                                        <span>Action name, result, message, timestamp, target, current view, and command output.</span>
                                    </div>
                                </div>
                                <?php if ($commandLog !== ''): ?>
                                    <div>
                                        <h3 style="margin-bottom: 10px;">Latest command output</h3>
                                        <pre class="code-block"><?= h($commandLog) ?></pre>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </aside>
                </section>
            <?php endif; ?>
        </div>
    </main>
</div>

<script>
    (function () {
        var root = document.documentElement;
        var storageKey = "laravel-dev-theme";
        var toggle = document.getElementById("themeToggle");
        var mobileToggle = document.getElementById("mobileNavToggle");
        var mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");

        function resolveTheme() {
            var stored = localStorage.getItem(storageKey);
            if (stored === "light" || stored === "dark") {
                return stored;
            }
            return mediaQuery.matches ? "dark" : "light";
        }

        function applyTheme(theme) {
            root.setAttribute("data-theme", theme);
            if (toggle) {
                toggle.textContent = theme === "dark" ? "Dark Mode" : "Light Mode";
            }
        }

        applyTheme(resolveTheme());

        if (toggle) {
            toggle.addEventListener("click", function () {
                var nextTheme = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
                localStorage.setItem(storageKey, nextTheme);
                applyTheme(nextTheme);
            });
        }

        mediaQuery.addEventListener("change", function (event) {
            var stored = localStorage.getItem(storageKey);
            if (stored !== "light" && stored !== "dark") {
                applyTheme(event.matches ? "dark" : "light");
            }
        });

        if (mobileToggle) {
            mobileToggle.addEventListener("click", function () {
                document.body.classList.toggle("nav-open");
            });
        }

        document.querySelectorAll(".git-template-button").forEach(function (button) {
            button.addEventListener("click", function () {
                var template = button.getAttribute("data-template") || "";
                var targetId = button.getAttribute("data-target");
                var input = targetId ? document.getElementById(targetId) : document.querySelector(".git-command-input");

                if (!input) {
                    return;
                }

                input.value = template;
                input.focus();
                if (template.endsWith(" ")) {
                    input.setSelectionRange(template.length, template.length);
                } else {
                    input.select();
                }
            });
        });

        var gitSearch = document.getElementById("gitRepoSearch");
        var gitCards = Array.prototype.slice.call(document.querySelectorAll("#gitProjectsList .git-card"));
        if (gitSearch && gitCards.length > 0) {
            gitSearch.addEventListener("input", function () {
                var query = gitSearch.value.trim().toLowerCase();
                gitCards.forEach(function (card) {
                    var haystack = (card.getAttribute("data-git-search") || "").toLowerCase();
                    card.style.display = query === "" || haystack.indexOf(query) !== -1 ? "" : "none";
                });
            });
        }

        var projectSearch = document.getElementById("projectSearch");
        var projectTypeFilter = document.getElementById("projectTypeFilter");
        var projectStatusFilter = document.getElementById("projectStatusFilter");
        var projectExposureFilter = document.getElementById("projectExposureFilter");
        var managedProjectCards = Array.prototype.slice.call(document.querySelectorAll("#managedProjectsList .git-card"));

        function applyProjectFilters() {
            if (managedProjectCards.length === 0) {
                return;
            }

            var query = projectSearch ? projectSearch.value.trim().toLowerCase() : "";
            var type = projectTypeFilter ? projectTypeFilter.value : "";
            var status = projectStatusFilter ? projectStatusFilter.value : "";
            var exposure = projectExposureFilter ? projectExposureFilter.value : "";

            managedProjectCards.forEach(function (card) {
                var haystack = (card.getAttribute("data-project-search") || "").toLowerCase();
                var cardType = card.getAttribute("data-project-type") || "";
                var cardStatus = card.getAttribute("data-project-status") || "";
                var cardExposure = card.getAttribute("data-project-exposure") || "";
                var visible = true;

                if (query !== "" && haystack.indexOf(query) === -1) {
                    visible = false;
                }
                if (type !== "" && cardType !== type) {
                    visible = false;
                }
                if (status !== "" && cardStatus !== status) {
                    visible = false;
                }
                if (exposure !== "" && cardExposure !== exposure) {
                    visible = false;
                }

                card.style.display = visible ? "" : "none";
            });
        }

        [projectSearch, projectTypeFilter, projectStatusFilter, projectExposureFilter].forEach(function (node) {
            if (node) {
                node.addEventListener("input", applyProjectFilters);
                node.addEventListener("change", applyProjectFilters);
            }
        });
    })();
</script>
</body>
</html>
