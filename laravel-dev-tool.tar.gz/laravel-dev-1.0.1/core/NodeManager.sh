#!/usr/bin/env bash

set -euo pipefail

node_project_root_for_framework() {
  local framework="$1"
  case "$framework" in
    next|nuxt)
      echo "$NODE_FRONTEND_DIR"
      ;;
    nest)
      echo "$NODE_BACKEND_DIR"
      ;;
    *)
      echo "$NODE_FRONTEND_DIR"
      ;;
  esac
}

detect_node_package_manager() {
  local dir="$1"
  if [[ -f "$dir/pnpm-lock.yaml" ]] && command -v pnpm >/dev/null 2>&1; then
    echo "pnpm"
    return 0
  fi
  if [[ -f "$dir/yarn.lock" ]] && command -v yarn >/dev/null 2>&1; then
    echo "yarn"
    return 0
  fi
  echo "npm"
}

framework_role_default() {
  case "$1" in
    nest) echo "backend" ;;
    next|nuxt) echo "frontend" ;;
    *) echo "service" ;;
  esac
}

node_framework_install_command() {
  local framework="$1"
  local target_dir="$2"
  case "$framework" in
    next)
      printf 'npx create-next-app@latest %q --ts --eslint --app --src-dir --use-npm --yes' "$target_dir"
      ;;
    nuxt)
      printf 'npx nuxi@latest init %q && cd %q && npm install' "$target_dir" "$target_dir"
      ;;
    nest)
      printf 'npx @nestjs/cli@latest new %q --package-manager npm --skip-git' "$target_dir"
      ;;
    *)
      return 1
      ;;
  esac
}

node_framework_run_command() {
  local framework="$1"
  local port="$2"
  case "$framework" in
    next)
      printf 'npm run dev -- --hostname 127.0.0.1 --port %s' "$port"
      ;;
    nuxt)
      printf 'npm run dev -- --host 127.0.0.1 --port %s' "$port"
      ;;
    nest)
      printf 'npm run start:dev -- --host 127.0.0.1 --port %s' "$port"
      ;;
    *)
      return 1
      ;;
  esac
}

ensure_node_dependencies() {
  local missing=()
  command -v node >/dev/null 2>&1 || missing+=("node")
  command -v npm >/dev/null 2>&1 || missing+=("npm")
  if [[ ${#missing[@]} -gt 0 ]]; then
    echo "Error: missing required Node tools: ${missing[*]}"
    exit 1
  fi
}

register_node_project() {
  local name="$1"
  local framework="$2"
  local project_path="$3"
  local role="${4:-}"
  local domain="${5:-${name}.test}"
  local exposure_mode="${6:-local}"
  local workspace_id="${7:-}"
  local port="${8:-$(allocate_project_port)}"
  local package_manager install_cmd run_cmd storage_root

  storage_root="$(node_project_root_for_framework "$framework")"
  package_manager="$(detect_node_package_manager "$project_path")"
  install_cmd="$package_manager install"
  run_cmd="$(node_framework_run_command "$framework" "$port")"
  [[ -n "$role" ]] || role="$(framework_role_default "$framework")"

  write_project_record "$name" \
    "PROJECT_TYPE" "$framework" \
    "RUNTIME" "node" \
    "APP_ROLE" "$role" \
    "STORAGE_ROOT" "$storage_root" \
    "PROJECT_PATH" "$project_path" \
    "DOMAIN" "$domain" \
    "PORT" "$port" \
    "RUN_COMMAND" "$run_cmd" \
    "INSTALL_COMMAND" "$install_cmd" \
    "EXPOSURE_MODE" "$exposure_mode" \
    "WORKSPACE_ID" "$workspace_id" \
    "PACKAGE_MANAGER" "$package_manager" \
    "STATUS" "stopped" \
    "PUBLIC_URL" ""
}

create_node_project() {
  local name="$1"
  local framework="$2"
  local role="${3:-}"
  local workspace_id="${4:-}"
  local project_root
  local target_dir
  local scaffold_cmd

  ensure_node_dependencies
  validate_project_name "$name"
  validate_domain_project_name "$name"

  project_root="$(node_project_root_for_framework "$framework")"
  target_dir="$project_root/$name"
  mkdir -p "$project_root"

  if [[ -e "$target_dir" ]]; then
    echo "Error: project directory already exists: $target_dir"
    exit 1
  fi

  scaffold_cmd="$(node_framework_install_command "$framework" "$target_dir")"
  if [[ -z "$scaffold_cmd" ]]; then
    echo "Error: unsupported Node framework '$framework'"
    exit 1
  fi

  bash -lc "$scaffold_cmd"
  register_node_project "$name" "$framework" "$target_dir" "$role" "${name}.test" "local" "$workspace_id"
  create_node_nginx "$name" "$(get_project_field "$name" "PORT")"
  echo "Node project ready: $name"
  echo "http://${name}.test"
}

link_node_project() {
  local name="$1"
  local path="$2"
  local framework="$3"
  local role="${4:-}"
  local workspace_id="${5:-}"

  [[ -d "$path" ]] || { echo "Error: path not found: $path"; exit 1; }
  register_node_project "$name" "$framework" "$path" "$role" "${name}.test" "local" "$workspace_id"
  create_node_nginx "$name" "$(get_project_field "$name" "PORT")"
  echo "Linked Node project: $name"
}

start_node_project() {
  local name="$1"
  local path run_command log_file pid_file

  path="$(get_project_field "$name" "PROJECT_PATH")"
  run_command="$(get_project_field "$name" "RUN_COMMAND")"
  log_file="$(project_log_file "$name")"
  pid_file="$(project_pid_file "$name")"

  [[ -d "$path" ]] || { echo "Error: project path missing for '$name'"; exit 1; }
  [[ -n "$run_command" ]] || { echo "Error: missing run command for '$name'"; exit 1; }

  if project_pid_is_running "$name"; then
    echo "Project '$name' is already running."
    return 0
  fi

  (
    cd "$path"
    nohup bash -lc "$run_command" >>"$log_file" 2>&1 &
    echo $! >"$pid_file"
  )

  update_project_record "$name" "STATUS" "running"
  echo "Started project: $name"
}

stop_node_project() {
  local name="$1"
  local pid_file pid
  pid_file="$(project_pid_file "$name")"
  if [[ ! -f "$pid_file" ]]; then
    update_project_record "$name" "STATUS" "stopped"
    echo "Project '$name' is not running."
    return 0
  fi
  pid="$(cat "$pid_file" 2>/dev/null || true)"
  if [[ -n "$pid" ]]; then
    kill "$pid" 2>/dev/null || true
    sleep 1
    kill -9 "$pid" 2>/dev/null || true
  fi
  rm -f "$pid_file"
  update_project_record "$name" "STATUS" "stopped"
  echo "Stopped project: $name"
}

restart_node_project() {
  local name="$1"
  stop_node_project "$name"
  start_node_project "$name"
}

workspace_link_projects() {
  local frontend="$1"
  local backend="$2"
  local workspace_id="${3:-$frontend-$backend}"
  local frontend_path backend_path frontend_type backend_type frontend_domain backend_domain

  frontend_path="$(get_project_field "$frontend" "PROJECT_PATH")"
  backend_path="$(get_project_field "$backend" "PROJECT_PATH")"
  frontend_type="$(get_project_field "$frontend" "PROJECT_TYPE" || true)"
  backend_type="$(get_project_field "$backend" "PROJECT_TYPE" || true)"
  frontend_domain="$(get_project_field "$frontend" "DOMAIN" || printf '%s.test' "$frontend")"
  backend_domain="$(get_project_field "$backend" "DOMAIN" || printf '%s.test' "$backend")"

  update_project_record "$frontend" "WORKSPACE_ID" "$workspace_id" "RELATED_BACKEND" "$backend" "API_BASE_URL" "http://${backend_domain}"
  update_project_record "$backend" "WORKSPACE_ID" "$workspace_id" "RELATED_FRONTEND" "$frontend" "FRONTEND_URL" "http://${frontend_domain}"

  if [[ "$frontend_type" != "laravel" && -f "$frontend_path/.env" ]]; then
    upsert_project_key "$frontend_path/.env" "API_BASE_URL" "http://${backend_domain}"
  fi
  if [[ "$backend_type" != "laravel" && -f "$backend_path/.env" ]]; then
    upsert_project_key "$backend_path/.env" "FRONTEND_URL" "http://${frontend_domain}"
  fi

  echo "Linked workspace '$workspace_id': $frontend <-> $backend"
}

expose_project() {
  local name="$1"
  local mode="$2"
  local domain port
  domain="$(get_project_field "$name" "DOMAIN" || printf '%s.test' "$name")"
  port="$(get_project_field "$name" "PORT" || true)"

  update_project_record "$name" "EXPOSURE_MODE" "$mode"

  case "$mode" in
    local)
      update_project_record "$name" "PUBLIC_URL" ""
      echo "Exposure set to local: http://${domain}"
      ;;
    lan)
      update_project_record "$name" "PUBLIC_URL" "http://$(hostname -I | awk '{print $1}' 2>/dev/null || echo 127.0.0.1):${port}"
      echo "Exposure set to LAN."
      ;;
    public_tunnel)
      if command -v cloudflared >/dev/null 2>&1 && [[ -n "$port" ]]; then
        update_project_record "$name" "PUBLIC_URL" "pending://cloudflared:${port}"
        echo "Cloudflare tunnel configured as pending for $name."
      else
        update_project_record "$name" "PUBLIC_URL" "pending://install-cloudflared"
        echo "Tunnel mode saved. Install cloudflared to activate."
      fi
      ;;
    public_dns)
      update_project_record "$name" "PUBLIC_URL" "pending://configure-dns"
      echo "Public DNS mode saved. Finish DNS and reverse proxy setup manually."
      ;;
    *)
      echo "Error: unsupported exposure mode '$mode'"
      exit 1
      ;;
  esac
}
