#!/usr/bin/env bash

set -euo pipefail

ensure_git_available() {
  if ! command -v git >/dev/null 2>&1; then
    echo "Error: git is not installed or not available in PATH."
    exit 1
  fi
}

resolve_git_target_path() {
  local input="$1"

  if [[ -d "$input" ]]; then
    echo "$input"
    return 0
  fi

  if [[ -d "$SITES_DIR/$input" ]]; then
    echo "$SITES_DIR/$input"
    return 0
  fi

  echo "Error: project path not found: $input"
  exit 1
}

ensure_git_repository() {
  local dir="$1"

  if ! git -C "$dir" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo "Error: '$dir' is not a git repository."
    exit 1
  fi
}

git_authentication_required() {
  local output="$1"

  [[ "$output" == *"could not read Username"* ]] \
    || [[ "$output" == *"could not read Password"* ]] \
    || [[ "$output" == *"Authentication failed"* ]] \
    || [[ "$output" == *"HTTP Basic: Access denied"* ]] \
    || [[ "$output" == *"Repository not found"* ]] \
    || [[ "$output" == *"fatal: could not read"* ]]
}

git_command_capture() {
  local dir="$1"
  shift

  local output_file="" exit_code=0 output="" askpass_bin=""
  output_file="$(mktemp)"

  if git -C "$dir" "$@" >"$output_file" 2>&1; then
    cat "$output_file"
    rm -f "$output_file"
    return 0
  fi

  exit_code=$?
  output="$(cat "$output_file")"

  if git_authentication_required "$output"; then
    askpass_bin="$(find_git_askpass_helper)"
    if [[ -n "$askpass_bin" ]]; then
      if GIT_TERMINAL_PROMPT=0 \
        GIT_ASKPASS="$askpass_bin" \
        LARAVEL_DEV_RUNTIME_DIR="$(auth_runtime_dir)" \
        LARAVEL_DEV_GIT_TOKEN_FILE="$(git_token_state_file)" \
        git -C "$dir" "$@" >"$output_file" 2>&1; then
        cat "$output_file"
        rm -f "$output_file"
        return 0
      fi
      exit_code=$?
      output="$(cat "$output_file")"
    fi
  fi

  printf '%s' "$output"
  rm -f "$output_file"
  return "$exit_code"
}

build_clone_url_with_token() {
  local repo_url="$1"
  local token="${2:-}"

  if [[ -z "$token" ]]; then
    echo "$repo_url"
    return 0
  fi

  if [[ ! "$repo_url" =~ ^https?:// ]]; then
    echo "$repo_url"
    return 0
  fi

  local scheme="${repo_url%%://*}"
  local rest="${repo_url#*://}"

  if [[ "$rest" == *"@"* ]]; then
    echo "$repo_url"
    return 0
  fi

  echo "${scheme}://${token}@${rest}"
}

clone_project_repo() {
  local name="$1"
  local repo_url="$2"
  local php_version="$3"
  local token="${4:-}"
  local custom_domain="${5:-}"
  local dir="$SITES_DIR/$name"
  local output=""

  ensure_git_available

  if [[ -d "$dir" ]]; then
    echo "Error: project directory already exists: $dir"
    exit 1
  fi

  mkdir -p "$SITES_DIR"

  if [[ -n "$token" ]]; then
    store_git_token "$token"
  fi

  echo "Cloning '$repo_url' into '$dir'..."
  if ! output="$(git_command_capture "$SITES_DIR" clone "$repo_url" "$dir")"; then
    printf '%s\n' "$output"
    exit 1
  fi

  [[ -n "$output" ]] && printf '%s\n' "$output"

  if [[ -f "$dir/artisan" || -f "$dir/public/index.php" ]]; then
    echo "Laravel-style project detected. Linking it into Laravel Dev..."
    link_project "$name" "$dir" "$php_version" "$custom_domain"
  else
    echo "Clone completed, but Laravel entry files were not detected."
    echo "The repository was downloaded only and was not linked into Nginx automatically."
  fi
}

run_project_git_command() {
  local target="$1"
  shift
  local dir="" output=""

  ensure_git_available
  dir="$(resolve_git_target_path "$target")"
  ensure_git_repository "$dir"

  if [[ $# -eq 0 ]]; then
    echo "Error: no git arguments were provided."
    exit 1
  fi

  if ! output="$(git_command_capture "$dir" "$@")"; then
    printf '%s\n' "$output"
    exit 1
  fi

  printf '%s\n' "$output"
}
