#!/usr/bin/env bash

set -euo pipefail

get_nginx_include_glob() {
  local nginx_conf="/etc/nginx/nginx.conf"

  if [[ -d /etc/nginx/sites-enabled ]]; then
    echo "/etc/nginx/sites-enabled/*"
    return 0
  fi
  if [[ -f "$nginx_conf" ]] && grep -qE '/etc/nginx/http\.d/\*\.conf' "$nginx_conf"; then
    echo "/etc/nginx/http.d/*.conf"
    return 0
  fi
  if [[ -f "$nginx_conf" ]] && grep -qE '/etc/nginx/conf\.d/\*\.conf' "$nginx_conf"; then
    echo "/etc/nginx/conf.d/*.conf"
    return 0
  fi
  if [[ -d /etc/nginx/http.d ]]; then
    echo "/etc/nginx/http.d/*.conf"
    return 0
  fi
  echo "/etc/nginx/conf.d/*.conf"
}

nginx_loads_path() {
  local path="$1"
  local output
  output="$(sudo_cmd nginx -T 2>/dev/null)"

  # Check the path as given first (handles conf.d / http.d layouts).
  echo "$output" | grep -Fq "$path" && return 0

  # On sites-available/sites-enabled setups nginx -T reports the *symlink*
  # path (sites-enabled/name), not the real-file path (sites-available/name).
  # Cross-check both directions so the caller doesn't need to care which
  # side of the symlink pair it holds.
  local basename_path
  basename_path="$(basename "$path")"

  local enabled_path="/etc/nginx/sites-enabled/${basename_path}"
  if [[ "$enabled_path" != "$path" ]]; then
    echo "$output" | grep -Fq "$enabled_path" && return 0
  fi

  local avail_path="/etc/nginx/sites-available/${basename_path}"
  if [[ "$avail_path" != "$path" ]]; then
    echo "$output" | grep -Fq "$avail_path" && return 0
  fi

  return 1
}

get_nginx_config_path() {
  local name="$1"
  local include_glob=""

  if [[ -d /etc/nginx/sites-available ]]; then
    echo "/etc/nginx/sites-available/$name"
    return 0
  fi

  include_glob="$(get_nginx_include_glob)"
  echo "${include_glob/\*/$name.conf}"
}

ensure_nginx_include_exists() {
  local nginx_conf="/etc/nginx/nginx.conf"
  local include_glob=""
  local include_line=""

  if [[ ! -f "$nginx_conf" ]]; then
    return 0
  fi

  include_glob="$(get_nginx_include_glob)"
  include_line="    include ${include_glob};"

  if grep -Eq "^[[:space:]]*include[[:space:]]+${include_glob//\*/\\*};" "$nginx_conf"; then
    return 0
  fi

  sudo_cmd mkdir -p "$(dirname "$include_glob")"
  sudo_cmd cp "$nginx_conf" "${nginx_conf}.bak-laravel-dev"
  sudo_cmd awk -v include_line="$include_line" '
    BEGIN { inserted = 0; in_http = 0; depth = 0 }
    {
      line = $0
      if (line ~ /^[[:space:]]*http[[:space:]]*\{[[:space:]]*$/) {
        in_http = 1
        depth = 1
        print line
        next
      }

      if (in_http) {
        opens = gsub(/\{/, "{", line)
        closes = gsub(/\}/, "}", line)
        if (!inserted && depth == 1 && closes > 0 && opens == 0) {
          print include_line
          inserted = 1
        }
        print line
        depth += opens - closes
        if (depth <= 0) {
          in_http = 0
        }
        next
      }

      print line
    }
    END {
      if (!inserted) {
        exit 1
      }
    }
  ' "$nginx_conf" | sudo_cmd tee "$nginx_conf.tmp" >/dev/null
  sudo_cmd mv "$nginx_conf.tmp" "$nginx_conf"
}

remove_nginx_site() {
  local name="$1"
  local config_path
  config_path="$(get_nginx_config_path "$name")"

  sudo_cmd rm -f "$config_path" 2>/dev/null || true
  sudo_cmd rm -f "/etc/nginx/sites-enabled/$name" "/etc/nginx/sites-enabled/$name.conf" 2>/dev/null || true
  sudo_cmd rm -f "/etc/nginx/http.d/${name}.conf" 2>/dev/null || true
  sudo_cmd rm -f "/etc/nginx/conf.d/${name}.conf" 2>/dev/null || true
}

detect_project_php_version() {
  local name="$1"
  local config
  local parsed=""
  config="$(get_nginx_config_path "$name")"

  if [[ ! -f "$config" && -f "/etc/nginx/sites-available/$name" ]]; then
    config="/etc/nginx/sites-available/$name"
  fi
  if [[ ! -f "$config" && -f "/etc/nginx/sites-available/$name.conf" ]]; then
    config="/etc/nginx/sites-available/$name.conf"
  fi

  if [[ -f "$config" ]]; then
    parsed="$(grep -Eo 'php[0-9]+\.[0-9]+-fpm\.sock' "$config" | head -n1 | sed -E 's/php([0-9]+\.[0-9]+)-fpm\.sock/\1/' || true)"
  fi

  if [[ -n "$parsed" ]]; then
    echo "$parsed"
    return 0
  fi

  if command -v php >/dev/null 2>&1; then
    php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;'
    return 0
  fi

  default_php_version
}

ensure_domain_mapping() {
  local name="$1"
  local domain="${2:-${name}.test}"

  if ! grep -qE "^[[:space:]]*127\\.0\\.0\\.1([[:space:]]+[^#[:space:]]+)*[[:space:]]+${domain}([[:space:]]|$)" /etc/hosts; then
    echo "127.0.0.1 ${domain}" | sudo_cmd tee -a /etc/hosts >/dev/null
  fi
  # if ! grep -qE "^[[:space:]]*::1([[:space:]]+[^#[:space:]]+)*[[:space:]]+${domain}([[:space:]]|$)" /etc/hosts; then
  #   echo "::1 ${domain}" | sudo_cmd tee -a /etc/hosts >/dev/null
  # fi

  # Refresh resolver cache when available.
  if command -v resolvectl >/dev/null 2>&1; then
    sudo_cmd resolvectl flush-caches >/dev/null 2>&1 || true
  elif command -v systemd-resolve >/dev/null 2>&1; then
    sudo_cmd systemd-resolve --flush-caches >/dev/null 2>&1 || true
  fi

  # Hard check to prevent "DNS_PROBE_POSSIBLE" after a "successful" create.
  if ! grep -qE "^[^#]*[[:space:]]${domain}([[:space:]]|$)" /etc/hosts; then
    echo "Error: domain mapping missing from /etc/hosts for $domain."
    exit 1
  fi

  if ! getent hosts "$domain" | awk '{print $1}' | grep -Eq "^(127\\.0\\.0\\.1|::1)$"; then
    echo "Error: domain mapping failed for $domain. Verify /etc/hosts and NSS config."
    exit 1
  fi
}

create_nginx() {
  local name="$1"
  local php_version="$2"
  local socket
  local config
  local project_root

  socket="$(get_php_socket "$php_version")"
  config="$(get_nginx_config_path "$name")"
  project_root="${3:-$SITES_DIR/$name}/public"

  ensure_nginx_include_exists
  sudo_cmd mkdir -p "$(dirname "$config")"

  if [[ ! -S "$socket" ]]; then
    local fallback_socket
    fallback_socket="$(
      ls -1 /run/php/php*-fpm.sock /run/php-fpm/php*-fpm.sock /run/php-fpm/www.sock /run/php-fpm/php-fpm.sock 2>/dev/null \
      | head -n1 || true
    )"
    if [[ -n "$fallback_socket" ]]; then
      echo "Warning: requested socket '$socket' not found, using '$fallback_socket'"
      socket="$fallback_socket"
    fi
  fi

  if [[ ! -f "$BASE_DIR/config/nginx-template.conf" ]]; then
    echo "Error: nginx template not found"
    exit 1
  fi

  sudo_cmd cp "$BASE_DIR/config/nginx-template.conf" "$config"

  # Replace longer placeholders first to avoid partial replacement bugs
  # like PROJECT_ROOT -> test2_ROOT when PROJECT is replaced first.
  sudo_cmd sed -i "s#PROJECT_ROOT#$project_root#g" "$config"
  sudo_cmd sed -i "s#PHP_SOCKET#$socket#g" "$config"
  sudo_cmd sed -i "s/PROJECT/$name/g" "$config"
  # Backward compatibility with old template placeholder.
  sudo_cmd sed -i "s#HOME_PATH#$HOME#g" "$config"

  if sudo_cmd grep -qE 'PROJECT_ROOT|PROJECT|PHP_SOCKET|HOME_PATH' "$config"; then
    echo "Error: unresolved placeholders detected in nginx config: $config"
    exit 1
  fi

  if [[ ! -f "$project_root/index.php" ]]; then
    echo "Error: project public index not found at $project_root/index.php"
    exit 1
  fi

  # ── Symlink: sites-available → sites-enabled ──────────────────────────
  # When the sites-available/sites-enabled layout is present (Debian/Ubuntu),
  # ensure sites-enabled exists and the symlink is always created/updated.
  if [[ -d /etc/nginx/sites-available ]]; then
    sudo_cmd mkdir -p /etc/nginx/sites-enabled
    local symlink_target="/etc/nginx/sites-enabled/$name"
    if [[ -L "$symlink_target" || -e "$symlink_target" ]]; then
      sudo_cmd rm -f "$symlink_target"
    fi
    sudo_cmd ln -s "$config" "$symlink_target"
    echo "Nginx: symlink created → $symlink_target → $config"
  elif [[ -d /etc/nginx/sites-enabled ]]; then
    # sites-enabled exists but sites-available doesn't (unusual layout).
    sudo_cmd ln -sfn "$config" "/etc/nginx/sites-enabled/$name"
  fi
  # ──────────────────────────────────────────────────────────────────────

  if ! nginx_loads_path "$config"; then
    ensure_nginx_include_exists
  fi

  ensure_domain_mapping "$name" "${name}.test"

  sudo_cmd nginx -t
  if ! nginx_loads_path "$config"; then
    echo "Error: nginx is not loading project config: $config"
    echo "Check include directives inside /etc/nginx/nginx.conf"
    exit 1
  fi
  # Prefer reload (graceful, zero-downtime) when only adding/updating a site.
  sudo_cmd systemctl reload nginx 2>/dev/null \
    || sudo_cmd systemctl restart nginx 2>/dev/null \
    || sudo_cmd service nginx reload 2>/dev/null \
    || sudo_cmd service nginx restart
}

create_node_nginx() {
  local name="$1"
  local project_port="$2"
  local domain="${3:-${name}.test}"
  local config

  config="$(get_nginx_config_path "$name")"
  ensure_nginx_include_exists
  sudo_cmd mkdir -p "$(dirname "$config")"

  if [[ ! -f "$BASE_DIR/config/nginx-node-template.conf" ]]; then
    echo "Error: node nginx template not found"
    exit 1
  fi

  sudo_cmd cp "$BASE_DIR/config/nginx-node-template.conf" "$config"
  sudo_cmd sed -i "s/PROJECT_PORT/$project_port/g" "$config"
  sudo_cmd sed -i "s/PROJECT/$name/g" "$config"

  if [[ -d /etc/nginx/sites-available ]]; then
    sudo_cmd mkdir -p /etc/nginx/sites-enabled
    sudo_cmd rm -f "/etc/nginx/sites-enabled/$name"
    sudo_cmd ln -s "$config" "/etc/nginx/sites-enabled/$name"
  elif [[ -d /etc/nginx/sites-enabled ]]; then
    sudo_cmd ln -sfn "$config" "/etc/nginx/sites-enabled/$name"
  fi

  ensure_domain_mapping "$name" "$domain"
  sudo_cmd nginx -t
  sudo_cmd systemctl reload nginx 2>/dev/null \
    || sudo_cmd systemctl restart nginx 2>/dev/null \
    || sudo_cmd service nginx reload 2>/dev/null \
    || sudo_cmd service nginx restart
  echo "Node Nginx ready: http://${domain}"
}

diagnose_project() {
  local name="$1"
  local domain="${name}.test"
  local config
  local project_root
  local project_public

  config="$(get_nginx_config_path "$name")"
  project_root="$SITES_DIR/$name"
  project_public="$project_root/public"

  echo "Project: $name"
  echo "Sites dir: $SITES_DIR"
  echo "Project root: $project_root"
  echo "Public dir: $project_public"
  echo "Domain: $domain"
  echo "Nginx config path: $config"
  echo

  if [[ -d "$project_root" ]]; then
    echo "[ok] project directory exists"
  else
    echo "[error] project directory missing"
  fi

  if [[ -f "$project_public/index.php" ]]; then
    echo "[ok] public/index.php exists"
  else
    echo "[error] public/index.php missing"
  fi

  if [[ -f "$project_root/routes/web.php" ]]; then
    echo "[ok] routes/web.php exists"
  else
    echo "[warn] routes/web.php missing"
  fi

  if [[ -f "$config" ]]; then
    echo "[ok] nginx config exists"
  else
    echo "[error] nginx config missing"
  fi

  if nginx_loads_path "$config"; then
    echo "[ok] nginx loads project config"
  else
    echo "[error] nginx does not load project config"
  fi

  if grep -qE "^[^#]*[[:space:]]${domain}([[:space:]]|$)" /etc/hosts; then
    echo "[ok] hosts entry exists"
  else
    echo "[error] hosts entry missing"
  fi

  echo
  echo "getent hosts:"
  getent hosts "$domain" || true
  echo
  echo "curl headers:"
  curl -I --max-time 5 "http://$domain" 2>/dev/null || true
}
