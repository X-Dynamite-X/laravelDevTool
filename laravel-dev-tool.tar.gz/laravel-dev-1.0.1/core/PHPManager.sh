#!/usr/bin/env bash

set -euo pipefail

normalize_php_version() {
  local version="$1"
  if [[ "$version" =~ ^[0-9]+\.[0-9]+$ ]]; then
    echo "$version"
    return 0
  fi
  if [[ "$version" =~ ^php([0-9]+\.[0-9]+)$ ]]; then
    echo "${BASH_REMATCH[1]}"
    return 0
  fi
  echo ""
}

list_available_php_versions() {
  local versions=()
  local cmd=""
  local version=""
  local sock=""

  if command -v php >/dev/null 2>&1; then
    version="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  fi

  while IFS= read -r cmd; do
    version="$(normalize_php_version "${cmd##*/}")"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  done < <(compgen -c | grep -E '^php[0-9]+\.[0-9]+$' | sort -u || true)

  while IFS= read -r sock; do
    version="$(printf '%s\n' "$sock" | sed -nE 's#.*php([0-9]+\.[0-9]+)-fpm\.sock#\1#p')"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  done < <(find /run/php /run/php-fpm -maxdepth 1 -type s -name 'php*-fpm.sock' 2>/dev/null || true)

  if [[ ${#versions[@]} -eq 0 ]]; then
    echo "8.4"
    return 0
  fi

  printf '%s\n' "${versions[@]}" | awk 'NF' | sort -Vu | uniq
}

list_php_fpm_services() {
  local units=()

  if command -v systemctl >/dev/null 2>&1; then
    while IFS= read -r unit; do
      unit="${unit%.service}"
      [[ -n "$unit" ]] && units+=("$unit")
    done < <(systemctl list-unit-files --type=service --no-legend 2>/dev/null | awk '{print $1}' | grep -E '^php.*fpm\.service$' | sort -u || true)
  fi

  if [[ ${#units[@]} -eq 0 ]]; then
    units+=(php-fpm)
  fi

  printf '%s\n' "${units[@]}" | awk 'NF' | sort -u
}

default_php_version() {
  list_available_php_versions | tail -n1
}

get_php_socket() {
  local version="$1"
  local candidates=(
    "/run/php/php${version}-fpm.sock"
    "/run/php-fpm/php${version}-fpm.sock"
    "/run/php-fpm/www.sock"
    "/run/php-fpm/php-fpm.sock"
  )
  local sock=""

  for sock in "${candidates[@]}"; do
    if [[ -S "$sock" ]]; then
      echo "$sock"
      return 0
    fi
  done

  echo "/run/php/php${version}-fpm.sock"
}
