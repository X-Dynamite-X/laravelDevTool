#!/usr/bin/env bash

set -euo pipefail

can_connect_mysql() {
  local host="$1"
  local user="$2"
  local pass="${3:-}"
  local port="${4:-${DB_PORT:-3306}}"

  MYSQL_PWD="$pass" mysql -h "$host" -P "$port" -u "$user" -e "SELECT 1;" >/dev/null 2>&1
}

escape_sql_string() {
  printf "%s" "$1" | sed "s/'/''/g"
}

can_connect_mysql_as_sudo_root() {
  sudo_cmd mysql -e "SELECT 1;" >/dev/null 2>&1
}

create_database() {
  local db="$1"
  local host="${DB_HOST:-127.0.0.1}"
  local port="${DB_PORT:-3306}"
  local user="${DB_USER:-$USER}"
  local pass="${DB_PASSWORD:-}"
  local sudo_user
  local esc_user
  local esc_pass

  if ! can_connect_mysql "$host" "$user" "$pass" "$port"; then
    if can_connect_mysql "127.0.0.1" "$USER" "" "$port"; then
      host="127.0.0.1"
      user="$USER"
      pass=""
    elif can_connect_mysql "127.0.0.1" "root" "" "$port"; then
      host="127.0.0.1"
      user="root"
      pass=""
    elif can_connect_mysql_as_sudo_root; then
      sudo_user="${USER:-devuser}"
      if [[ ! "$sudo_user" =~ ^[a-zA-Z0-9_]+$ ]]; then
        sudo_user="devuser"
      fi
      esc_user="$(escape_sql_string "$sudo_user")"
      esc_pass="$(escape_sql_string "")"
      sudo_cmd mysql -e "CREATE DATABASE IF NOT EXISTS \`$db\`;"
      sudo_cmd mysql -e "CREATE USER IF NOT EXISTS '$esc_user'@'127.0.0.1' IDENTIFIED BY '$esc_pass';"
      sudo_cmd mysql -e "GRANT ALL PRIVILEGES ON \`$db\`.* TO '$esc_user'@'127.0.0.1'; FLUSH PRIVILEGES;"
      host="127.0.0.1"
      user="$sudo_user"
      pass=""
    else
      echo "Error: could not connect to MySQL/MariaDB. Update DB settings in ~/.config/laravel-dev/config.env"
      exit 1
    fi
  fi

  DB_HOST="$host"
  DB_PORT="$port"
  DB_USER="$user"
  DB_PASSWORD="$pass"
  MYSQL_PWD="$DB_PASSWORD" mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -e "CREATE DATABASE IF NOT EXISTS \`$db\`;"
}
