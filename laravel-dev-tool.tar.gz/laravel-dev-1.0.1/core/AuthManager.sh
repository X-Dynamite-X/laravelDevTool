#!/usr/bin/env bash

set -euo pipefail

SUDO_MODE="${SUDO_MODE:-tty}"
SUDO_ASKPASS_BIN="${SUDO_ASKPASS_BIN:-}"

auth_runtime_dir() {
  local candidates=(
    "${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev/runtime"
    "${XDG_RUNTIME_DIR:-}"
    "/tmp/laravel-dev-${UID:-$(id -u)}"
  )
  local dir=""

  for dir in "${candidates[@]}"; do
    [[ -n "$dir" ]] || continue
    if mkdir -p "$dir" 2>/dev/null; then
      chmod 700 "$dir" 2>/dev/null || true
      echo "$dir"
      return 0
    fi
  done

  echo "/tmp"
}

sudo_session_state_file() {
  echo "$(auth_runtime_dir)/sudo-session"
}

git_token_state_file() {
  echo "$(auth_runtime_dir)/git-token"
}

find_popup_helper() {
  local candidates=(
    "${1:-}"
    "${2:-}"
    "/usr/bin/zenity"
    "/usr/bin/kdialog"
    "/usr/bin/ssh-askpass"
    "/usr/bin/ssh-askpass-fullscreen"
    "/usr/bin/ksshaskpass"
    "/usr/lib/ssh/ssh-askpass"
    "/usr/libexec/openssh/gnome-ssh-askpass"
  )
  local candidate=""

  for candidate in "${candidates[@]}"; do
    if [[ -n "$candidate" && -x "$candidate" ]]; then
      echo "$candidate"
      return 0
    fi
  done

  echo ""
}

find_sudo_askpass_helper() {
  find_popup_helper "${BASE_DIR:-}/ui/sudo-askpass.sh" "${SUDO_ASKPASS:-}"
}

find_git_askpass_helper() {
  find_popup_helper "${BASE_DIR:-}/ui/git-askpass.sh" "${GIT_ASKPASS:-}"
}

record_sudo_session() {
  local ttl="${1:-600}"
  local state_file
  state_file="$(sudo_session_state_file)"
  printf '%s\n' "$(( $(date +%s) + ttl ))" >"$state_file"
  chmod 600 "$state_file" 2>/dev/null || true
}

clear_sudo_session() {
  rm -f "$(sudo_session_state_file)"
}

sudo_session_expires_at() {
  local state_file
  state_file="$(sudo_session_state_file)"

  if [[ ! -f "$state_file" ]]; then
    echo "0"
    return 0
  fi

  head -n1 "$state_file" 2>/dev/null | tr -dc '0-9'
}

sudo_session_is_active() {
  local expires_at
  expires_at="$(sudo_session_expires_at)"

  if [[ -z "$expires_at" || "$expires_at" -le "$(date +%s)" ]]; then
    clear_sudo_session
    return 1
  fi

  if sudo -n true 2>/dev/null; then
    return 0
  fi

  clear_sudo_session
  return 1
}

sudo_cmd() {
  case "${SUDO_MODE:-tty}" in
    askpass)
      SUDO_ASKPASS="${SUDO_ASKPASS_BIN}" command sudo -A -p "Laravel Dev requires your system password." "$@"
      ;;
    noninteractive)
      command sudo -n "$@"
      ;;
    *)
      command sudo "$@"
      ;;
  esac
}

require_system_access() {
  local askpass_bin=""

  if sudo_session_is_active; then
    SUDO_MODE="noninteractive"
    return 0
  fi

  if sudo -n true 2>/dev/null; then
    SUDO_MODE="noninteractive"
    record_sudo_session 600
    return 0
  fi

  askpass_bin="$(find_sudo_askpass_helper)"
  if [[ -n "$askpass_bin" && -n "${DISPLAY:-}" ]]; then
    SUDO_MODE="askpass"
    SUDO_ASKPASS_BIN="$askpass_bin"
    if sudo_cmd -v 2>/dev/null; then
      record_sudo_session 600
      return 0
    fi
  fi

  if [[ -t 0 ]]; then
    SUDO_MODE="tty"
    sudo_cmd -v
    record_sudo_session 600
    return 0
  fi

  echo "Error: sudo password is required but no terminal prompt is available."
  echo "Run once in terminal: sudo -v"
  echo "Or install/configure askpass (e.g. ssh-askpass) for GUI sudo prompts."
  exit 1
}

git_token_is_active() {
  local state_file expires_at
  state_file="$(git_token_state_file)"

  [[ -f "$state_file" ]] || return 1

  IFS= read -r expires_at <"$state_file" || true
  if [[ -z "$expires_at" || "$expires_at" -le "$(date +%s)" ]]; then
    rm -f "$state_file"
    return 1
  fi

  return 0
}

store_git_token() {
  local token="$1"
  local ttl="${2:-900}"
  local state_file
  state_file="$(git_token_state_file)"

  {
    printf '%s\n' "$(( $(date +%s) + ttl ))"
    printf '%s\n' "$token"
  } >"$state_file"
  chmod 600 "$state_file" 2>/dev/null || true
}

clear_git_token() {
  rm -f "$(git_token_state_file)"
}
