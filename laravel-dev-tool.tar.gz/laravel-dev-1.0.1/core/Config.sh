#!/usr/bin/env bash

set -euo pipefail

load_config() {
  SITES_DIR="$HOME/Sites"
  LARAVEL_SITES_DIR="$HOME/Sites"
  NODE_FRONTEND_DIR="$HOME/NodeApps/frontend"
  NODE_BACKEND_DIR="$HOME/NodeApps/backend"
  WORKSPACES_DIR="$HOME/NodeApps/workspaces"
  DB_HOST="127.0.0.1"
  DB_PORT="3306"
  DB_USER="root"
  DB_PASSWORD=""
  DB_TYPE="mysql"
  WEB_PORT="4040"
  WEB_BIND_HOST="0.0.0.0"
  WEB_PUBLIC_HOST="127.0.0.1"
  WEB_PUBLIC_SCHEME="http"

  # System-level defaults (installed with the app).
  local config_file="$BASE_DIR/config/config.env"
  if [[ -f "$config_file" ]]; then
    # shellcheck source=/dev/null
    source "$config_file"
  fi

  # User-level config overrides system config and is always writable by the
  # current user without requiring sudo.
  local user_config_file="$HOME/.config/laravel-dev/config.env"
  if [[ -f "$user_config_file" ]]; then
    # shellcheck source=/dev/null
    source "$user_config_file"
  fi

  # Backward compatibility for older config that only knows SITES_DIR.
  LARAVEL_SITES_DIR="${LARAVEL_SITES_DIR:-$SITES_DIR}"
  SITES_DIR="$LARAVEL_SITES_DIR"
  WEB_BIND_HOST="${WEB_BIND_HOST:-0.0.0.0}"
  WEB_PUBLIC_HOST="${WEB_PUBLIC_HOST:-127.0.0.1}"
  WEB_PUBLIC_SCHEME="${WEB_PUBLIC_SCHEME:-http}"
}
