#!/usr/bin/env bash

set -euo pipefail

load_config() {
  SITES_DIR="$HOME/Sites"
  DB_HOST="127.0.0.1"
  DB_PORT="3306"
  DB_USER="root"
  DB_PASSWORD=""
  DB_TYPE="mysql"
  WEB_PORT="4040"

  # System-level defaults (installed with the app).
  local config_file="$BASE_DIR/config/config.env"
  if [[ -f "$config_file" ]]; then
    # shellcheck source=/dev/null
    source "$config_file"
  fi

  # User-level config overrides system config and is always writable by the
  # current user without requiring sudo.
  local user_config_file="$HOME/.config/laravel-dev/config.env"
  if [[ -f "$user_config_file" ]]; then
    # shellcheck source=/dev/null
    source "$user_config_file"
  fi
}
