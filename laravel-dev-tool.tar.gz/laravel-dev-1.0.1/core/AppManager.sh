#!/usr/bin/env bash

set -euo pipefail

# Non-PHP apps (Next.js, Nuxt, Vite, Node, Django). Nginx proxies <domain> to
# the app's local port; the desktop app starts and stops the dev server.

APP_TYPES="next nuxt vite node django"

detect_project_type() {
  local dir="$1"

  if [[ -f "$dir/artisan" ]]; then
    echo "laravel"
  elif [[ -f "$dir/manage.py" ]]; then
    echo "django"
  elif [[ -f "$dir/package.json" ]]; then
    if grep -qE '"next"[[:space:]]*:' "$dir/package.json"; then
      echo "next"
    elif grep -qE '"nuxt"[[:space:]]*:' "$dir/package.json"; then
      echo "nuxt"
    elif grep -qE '"vite"[[:space:]]*:' "$dir/package.json"; then
      echo "vite"
    else
      echo "node"
    fi
  else
    echo ""
  fi
}

app_runtime() {
  case "$1" in
    django) echo "python" ;;
    laravel) echo "php-fpm" ;;
    *) echo "node" ;;
  esac
}

js_package_manager() {
  local dir="$1"
  if [[ -f "$dir/pnpm-lock.yaml" ]]; then echo "pnpm"
  elif [[ -f "$dir/yarn.lock" ]]; then echo "yarn"
  elif [[ -f "$dir/bun.lockb" || -f "$dir/bun.lock" ]]; then echo "bun"
  else echo "npm"
  fi
}

validate_app_type() {
  if [[ " $APP_TYPES " != *" $1 "* ]]; then
    echo "Error: unsupported app type '$1'. Use one of: $APP_TYPES"
    exit 1
  fi
}

validate_app_port() {
  if [[ ! "$1" =~ ^[0-9]+$ ]] || (( $1 < 1024 || $1 > 65535 )); then
    echo "Error: invalid port '$1' (use 1024-65535)."
    exit 1
  fi
}

create_nginx_proxy() {
  local name="$1"
  local port="$2"
  local domain="${3:-${name}.test}"
  local template="$BASE_DIR/config/nginx-proxy-template.conf"
  local config

  if [[ ! -f "$template" ]]; then
    echo "Error: nginx proxy template not found"
    exit 1
  fi

  config="$(get_nginx_config_path "$name")"
  ensure_nginx_include_exists
  sudo_cmd mkdir -p "$(dirname "$config")"
  sed -e "s#PROJECT_DOMAIN#$domain#g" -e "s#APP_PORT#$port#g" "$template" | sudo_cmd tee "$config" >/dev/null
  echo "Nginx: http://$domain -> 127.0.0.1:$port"
  activate_nginx_site "$name" "$config" "$domain"
}

link_app() {
  local name="$1"
  local path="$2"
  local type="${3:-}"
  local port="${4:-}"
  local domain="${5:-}"

  path="$(realpath "$path" 2>/dev/null || printf '%s' "$path")"
  if [[ ! -d "$path" ]]; then
    echo "Error: Path does not exist: $path"
    exit 1
  fi

  type="${type:-$(detect_project_type "$path")}"
  if [[ "$type" == "laravel" ]]; then
    link_project "$name" "$path" "" "$domain"
    return
  fi
  validate_app_type "$type"
  port="${port:-$(allocate_project_port)}"
  validate_app_port "$port"
  domain="${domain:-${name}.test}"

  echo "Linking $type app '$name' from '$path' on port $port..."
  create_nginx_proxy "$name" "$port" "$domain"

  write_project_record "$name" \
    "PROJECT_TYPE" "$type" \
    "RUNTIME" "$(app_runtime "$type")" \
    "PROJECT_PATH" "$path" \
    "DOMAIN" "$domain" \
    "PORT" "$port" \
    "RUN_MODE" "dev" \
    "RUN_COMMAND" "" \
    "PACKAGE_MANAGER" "$( [[ "$type" == "django" ]] && echo "" || js_package_manager "$path")" \
    "STATUS" "ready"

  echo "Successfully linked $type app: $name"
  echo "Start it from Laravel Dev, then open http://$domain"
}

# Scaffold a new app in the sites directory, install dependencies and link it.
create_app() {
  local type="$1"
  local name="$2"
  local port="${3:-}"
  local domain="${4:-}"
  local dir="$LARAVEL_SITES_DIR/$name"

  if [[ -e "$dir" ]]; then
    echo "Error: Project directory already exists: $dir"
    exit 1
  fi
  mkdir -p "$LARAVEL_SITES_DIR"

  case "$type" in
    next)
      command -v npx >/dev/null 2>&1 || { echo "Error: Node.js (npx) is not installed."; exit 1; }
      (cd "$LARAVEL_SITES_DIR" && CI=1 npx --yes create-next-app@latest "$name" --yes --skip-install --disable-git)
      (cd "$dir" && npm install)
      ;;
    nuxt)
      command -v npx >/dev/null 2>&1 || { echo "Error: Node.js (npx) is not installed."; exit 1; }
      (cd "$LARAVEL_SITES_DIR" && CI=1 npx --yes nuxi@latest init "$name" --template minimal \
        --packageManager npm --no-gitInit --no-install --modules=)
      (cd "$dir" && npm install)
      ;;
    django)
      command -v python3 >/dev/null 2>&1 || { echo "Error: python3 is not installed."; exit 1; }
      mkdir -p "$dir"
      python3 -m venv "$dir/.venv" || { rm -rf "$dir"; echo "Error: could not create a virtualenv (install python3-venv)."; exit 1; }
      "$dir/.venv/bin/pip" install --upgrade pip django
      "$dir/.venv/bin/django-admin" startproject config "$dir"
      "$dir/.venv/bin/pip" freeze >"$dir/requirements.txt"
      ;;
    *)
      echo "Error: cannot create apps of type '$type' (supported: next, nuxt, django)."
      exit 1
      ;;
  esac

  link_app "$name" "$dir" "$type" "$port" "$domain"
}

repair_app() {
  local name="$1"
  local port domain
  port="$(get_project_field "$name" "PORT" 2>/dev/null || true)"
  domain="$(get_project_field "$name" "DOMAIN" 2>/dev/null || true)"
  if [[ -z "$port" ]]; then
    echo "Error: no port recorded for '$name'. Unlink and link it again."
    exit 1
  fi
  create_nginx_proxy "$name" "$port" "${domain:-${name}.test}"
  echo "Repaired nginx proxy for: $name"
}
