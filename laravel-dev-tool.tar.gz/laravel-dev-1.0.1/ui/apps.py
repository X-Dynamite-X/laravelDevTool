"""Local non-PHP apps (Next.js, Nuxt, Vite, Node, Django).

Nginx proxies <name>.test to the app's port (see core/AppManager.sh); this
module starts and stops the app's own server. Processes run in their own
session and outlive a crash of the desktop app; a pid file plus a check of the
process's working directory tells us later whether it is still ours.
"""

import json
import os
import re
import signal
import socket
import subprocess
import time
from pathlib import Path

APP_TYPES = ("next", "nuxt", "vite", "node", "django")
TYPE_LABELS = {"laravel": "Laravel", "next": "Next.js", "nuxt": "Nuxt", "vite": "Vite", "node": "Node", "django": "Django"}

# {pm} = package manager, {port} = assigned port, {py} = project python.
DEFAULT_COMMANDS = {
    "next": {"dev": "{pm} run dev{sep} -p {port}", "prod": "{pm} run start{sep} -p {port}"},
    "nuxt": {"dev": "{pm} run dev{sep} --port {port}", "prod": "node .output/server/index.mjs"},
    "vite": {"dev": "{pm} run dev{sep} --port {port} --strictPort", "prod": "{pm} run preview{sep} --port {port} --strictPort"},
    "node": {"dev": "{pm} run dev", "prod": "{pm} start"},
    "django": {"dev": "{py} manage.py runserver 127.0.0.1:{port}", "prod": "{py} -m gunicorn --bind 127.0.0.1:{port} config.wsgi"},
}

# Lets node from nvm/fnm/volta work even though the desktop app has no shell profile.
NODE_PRELUDE = (
    'export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"; '
    '[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh" >/dev/null 2>&1; '
    '[ -d "$HOME/.volta/bin" ] && PATH="$HOME/.volta/bin:$PATH"; '
    '[ -d "$HOME/.local/share/fnm" ] && PATH="$HOME/.local/share/fnm:$PATH" && eval "$(fnm env 2>/dev/null)"; '
    '[ -d "$HOME/.bun/bin" ] && PATH="$HOME/.bun/bin:$PATH"; '
)


def detect_type(path):
    path = Path(path)
    if (path / "artisan").is_file():
        return "laravel"
    if (path / "manage.py").is_file():
        return "django"
    pkg = read_package(path)
    if pkg is None:
        return ""
    deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
    for name in ("next", "nuxt", "vite"):
        if name in deps:
            return name
    return "node"


def read_package(path):
    try:
        return json.loads((Path(path) / "package.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def package_manager(path):
    path = Path(path)
    if (path / "pnpm-lock.yaml").exists():
        return "pnpm"
    if (path / "yarn.lock").exists():
        return "yarn"
    if (path / "bun.lockb").exists() or (path / "bun.lock").exists():
        return "bun"
    return "npm"


def scripts(path):
    pkg = read_package(path) or {}
    return {k: v for k, v in (pkg.get("scripts") or {}).items() if isinstance(v, str)}


def venv_python(path):
    """The project's virtualenv python: inside the project or up to three folders above it."""
    current = Path(path).resolve()
    for _ in range(4):
        for name in (".venv", "venv", "env", ""):
            candidate = current / name if name else current
            if (candidate / "pyvenv.cfg").is_file() and (candidate / "bin" / "python").exists():
                return str(candidate / "bin" / "python")
        if current.parent == current:
            break
        current = current.parent
    return "python3"


def default_command(app_type, mode, path):
    template = DEFAULT_COMMANDS.get(app_type, DEFAULT_COMMANDS["node"]).get(mode, "")
    pm = package_manager(path)
    if app_type == "node" and mode == "dev" and "dev" not in scripts(path):
        template = "{pm} start"
    return template.replace("{pm}", pm).replace("{sep}", " --" if pm == "npm" else "")


def resolve_command(command, port, path):
    return command.replace("{port}", str(port)).replace("{py}", venv_python(path))


def port_is_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def allocate_port(used):
    for port in range(4100, 5000):
        if port not in used and port_is_free(port):
            return port
    raise ValueError("No free port between 4100 and 4999")


class AppProcesses:
    def __init__(self, runtime_dir):
        self.dir = Path(runtime_dir) / "projects"

    def _files(self, name):
        self.dir.mkdir(parents=True, exist_ok=True)
        os.chmod(self.dir, 0o700)
        return self.dir / f"{name}.pid", self.dir / f"{name}.log"

    def pid(self, name, path):
        pid_file, _ = self._files(name)
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 0)
            # Guard against pid reuse: the process must still run inside the project.
            if os.path.realpath(f"/proc/{pid}/cwd") != os.path.realpath(path):
                raise ProcessLookupError
            return pid
        except (OSError, ValueError):
            pid_file.unlink(missing_ok=True)
            return None

    def running(self, name, path):
        return self.pid(name, path) is not None

    def start(self, name, path, command, port, app_type):
        if self.running(name, path):
            return False
        if not port_is_free(int(port)):
            raise ValueError(f"Port {port} is already in use by another program.")
        pid_file, log_file = self._files(name)
        env = dict(os.environ)
        env.update({"PORT": str(port), "HOST": "127.0.0.1", "HOSTNAME": "127.0.0.1",
                    "NITRO_PORT": str(port), "NUXT_PORT": str(port), "BROWSER": "none",
                    "FORCE_COLOR": "0", "NO_COLOR": "1"})
        if app_type == "django":
            env["PYTHONUNBUFFERED"] = "1"
        resolved = resolve_command(command, port, path)
        with open(log_file, "wb") as log:
            log.write(f"$ {resolved}\n".encode())
            log.flush()
            proc = subprocess.Popen(
                ["bash", "-c", NODE_PRELUDE + "exec " + resolved], cwd=path, env=env,
                stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
            )
        pid_file.write_text(str(proc.pid))
        time.sleep(0.4)
        if proc.poll() is not None:
            pid_file.unlink(missing_ok=True)
            raise ValueError("The app exited immediately — open Logs to see why.")
        return True

    def stop(self, name, path):
        pid = self.pid(name, path)
        if pid is None:
            return False
        for sig, wait in ((signal.SIGTERM, 5.0), (signal.SIGKILL, 2.0)):
            try:
                os.killpg(pid, sig)
            except ProcessLookupError:
                break
            deadline = time.time() + wait
            while time.time() < deadline:
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(0.1)
            else:
                continue
            break
        self._files(name)[0].unlink(missing_ok=True)
        return True

    def log(self, name, lines=400):
        _, log_file = self._files(name)
        try:
            with open(log_file, "rb") as handle:
                handle.seek(0, os.SEEK_END)
                handle.seek(max(handle.tell() - 256 * 1024, 0))
                text = handle.read().decode("utf-8", errors="replace")
        except OSError:
            return None
        text = re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]", "", text)
        return "\n".join(text.splitlines()[-lines:])
