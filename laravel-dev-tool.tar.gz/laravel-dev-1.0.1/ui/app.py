#!/usr/bin/env python3
"""Laravel Dev desktop app.

A GTK window hosting a local HTML interface (ui/web). The interface talks to
this process through a WebKit script-message bridge, so there is no HTTP
server and no open port. Anything that touches the system (nginx, /etc/hosts,
supervisor, databases) is delegated to the laravel-dev CLI, which asks for the
sudo password through a GUI askpass dialog when it needs it.
"""

import fcntl
import json
import os
import pty
import re
import shlex
import shutil
import signal
import struct
import subprocess
import sys
import termios
import threading
import time
import uuid
from pathlib import Path

import apps
from remote import Remote, RemoteError

try:
    import gi

    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    try:
        gi.require_version("WebKit2", "4.1")
    except ValueError:
        gi.require_version("WebKit2", "4.0")
    from gi.repository import Gdk, Gio, GLib, Gtk, WebKit2
except (ImportError, ValueError):
    print("Missing GUI dependencies for the Laravel Dev app. Install one of:")
    print("  sudo apt install python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1")
    print("  sudo pacman -S python-gobject gtk3 webkit2gtk-4.1")
    print("  sudo dnf install python3-gobject gtk3 webkit2gtk4.1")
    sys.exit(1)

try:
    gi.require_version("AyatanaAppIndicator3", "0.1")
    from gi.repository import AyatanaAppIndicator3 as AppIndicator
except (ImportError, ValueError):
    try:
        gi.require_version("AppIndicator3", "0.1")
        from gi.repository import AppIndicator3 as AppIndicator
    except (ImportError, ValueError):
        AppIndicator = None


APP_ID = "dev.laravel.LaravelDev"
UI_DIR = Path(__file__).resolve().parent
BASE_DIR = Path(os.environ.get("LARAVEL_DEV_BASE_DIR") or UI_DIR.parent)
CLI = str(BASE_DIR / "bin" / "laravel-dev")
HOME = Path.home()
CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME") or HOME / ".config") / "laravel-dev"
REGISTRY_DIR = CONFIG_DIR / "projects.d"
USER_CONFIG = CONFIG_DIR / "config.env"
PREFS_FILE = CONFIG_DIR / "app.json"
AUTOSTART_FILE = Path(os.environ.get("XDG_CONFIG_HOME") or HOME / ".config") / "autostart" / "laravel-dev.desktop"

NEW_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9.-]*$")
NAME_RE = re.compile(r"^[A-Za-z0-9._-]+$")
DOMAIN_RE = re.compile(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")
REPO_RE = re.compile(r"^(https?://|ssh://|git@)\S+$")
UNIT_RE = re.compile(r"^(nginx|mysql|mariadb|redis|redis-server|supervisor|supervisord|php[0-9.]*-fpm)$")
ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(\x07|\x1b\\)|\x1b[()][A-Za-z0-9]|\x1b[=>]")

EDITORS = [
    ("code", "VS Code"), ("cursor", "Cursor"), ("windsurf", "Windsurf"), ("zed", "Zed"),
    ("codium", "VSCodium"), ("phpstorm", "PhpStorm"), ("subl", "Sublime Text"),
    ("kate", "Kate"), ("gnome-text-editor", "Text Editor"), ("gedit", "gedit"), ("mousepad", "Mousepad"),
]

SERVICES = [
    (("nginx",), "Nginx", "Web server"),
    (("mysql", "mariadb"), "Database", "MySQL / MariaDB"),
    (("redis-server", "redis"), "Redis", "Cache & queues"),
    (("supervisor", "supervisord"), "Supervisor", "Queue workers"),
]

PROCESSES = apps.AppProcesses(CONFIG_DIR / "runtime")

DEFAULT_PREFS = {"editor": "", "theme": "system", "close_to_tray": True, "default_php": ""}


# ── config ───────────────────────────────────────────────────────────────────

def parse_env_file(path):
    data = {}
    try:
        lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return data
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip().removeprefix("export ").strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] == '"':
            value = re.sub(r'\\([\\"$`])', r"\1", value[1:-1])
        elif len(value) >= 2 and value[0] == value[-1] == "'":
            value = value[1:-1]
        data[key] = value
    return data


def load_settings():
    settings = {
        "LARAVEL_SITES_DIR": str(HOME / "Sites"),
        "DB_TYPE": "mysql", "DB_HOST": "127.0.0.1", "DB_PORT": "3306",
        "DB_USER": "root", "DB_PASSWORD": "",
    }
    merged = {}
    merged.update(parse_env_file(BASE_DIR / "config" / "config.env"))
    merged.update(parse_env_file(USER_CONFIG))
    if merged.get("LARAVEL_SITES_DIR") or merged.get("SITES_DIR"):
        merged["LARAVEL_SITES_DIR"] = merged.get("LARAVEL_SITES_DIR") or merged["SITES_DIR"]
    for key in settings:
        if key in merged:
            settings[key] = merged[key]
    settings["LARAVEL_SITES_DIR"] = os.path.expanduser(
        settings["LARAVEL_SITES_DIR"].replace("${HOME}", str(HOME)).replace("$HOME", str(HOME))
    )
    return settings


def bash_quote(value):
    return '"' + re.sub(r'([\\"$`])', r"\\\1", value) + '"'


def save_settings(updates):
    """Rewrite only the managed keys in the user config, keeping everything else."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        lines = USER_CONFIG.read_text(encoding="utf-8").splitlines()
    except OSError:
        lines = ["# Laravel Dev user settings (managed by the desktop app)."]
    pending = dict(updates)
    out = []
    for line in lines:
        key = line.split("=", 1)[0].strip().removeprefix("export ").strip() if "=" in line else ""
        if key in pending:
            out.append(f"{key}={bash_quote(pending.pop(key))}")
        else:
            out.append(line)
    out.extend(f"{key}={bash_quote(value)}" for key, value in pending.items())
    USER_CONFIG.write_text("\n".join(out) + "\n", encoding="utf-8")
    os.chmod(USER_CONFIG, 0o600)


def load_prefs():
    prefs = dict(DEFAULT_PREFS)
    try:
        prefs.update(json.loads(PREFS_FILE.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    prefs["autostart"] = AUTOSTART_FILE.exists()
    return prefs


def save_prefs(prefs):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = {key: prefs.get(key, default) for key, default in DEFAULT_PREFS.items()}
    PREFS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    if prefs.get("autostart"):
        AUTOSTART_FILE.parent.mkdir(parents=True, exist_ok=True)
        AUTOSTART_FILE.write_text(
            "[Desktop Entry]\nType=Application\nName=Laravel Dev\n"
            f"Exec={shlex.quote(CLI)} app --hidden\nIcon=laravel-dev\n"
            "X-GNOME-Autostart-enabled=true\n",
            encoding="utf-8",
        )
    elif AUTOSTART_FILE.exists():
        AUTOSTART_FILE.unlink()


# ── system inspection ────────────────────────────────────────────────────────

def run_quiet(argv, timeout=10, cwd=None):
    try:
        res = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        return res.returncode, res.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return 1, ""


def php_versions():
    code, out = run_quiet([CLI, "php-versions"])
    versions = [v for v in out.splitlines() if re.fullmatch(r"\d+\.\d+", v.strip())] if code == 0 else []
    return versions or ["8.4"]


def php_binary(version):
    if version and shutil.which(f"php{version}"):
        return f"php{version}"
    return "php"


def nginx_sites():
    """Index every nginx site config by file name, server_name and project root,
    so sites created before the registry existed are still recognised."""
    index = {"file": {}, "domain": {}, "root": {}}
    for folder in ("/etc/nginx/sites-available", "/etc/nginx/conf.d", "/etc/nginx/http.d"):
        try:
            files = sorted(Path(folder).iterdir())
        except OSError:
            continue
        for conf in files:
            if not conf.is_file() or ".bak" in conf.name or ".backup" in conf.name:
                continue
            try:
                text = conf.read_text(errors="replace")
            except OSError:
                continue
            php = re.search(r"php(\d+\.\d+)-fpm\.sock", text)
            names = re.search(r"^\s*server_name\s+([^;]+);", text, re.M)
            root = re.search(r"^\s*root\s+([^;]+);", text, re.M)
            info = {
                "php": php.group(1) if php else "",
                "domain": names.group(1).split()[0].lower() if names else "",
                "root": root.group(1).strip() if root else "",
            }
            index["file"][conf.name.removesuffix(".conf")] = info
            if info["domain"]:
                index["domain"].setdefault(info["domain"], info)
            if info["root"]:
                index["root"].setdefault(os.path.realpath(info["root"].removesuffix("/public")), info)
    return index


def nginx_lookup(index, name, domain, path):
    return (index["domain"].get(domain)
            or index["root"].get(os.path.realpath(path))
            or index["file"].get(name))


def git_branch(path):
    try:
        head = (Path(path) / ".git" / "HEAD").read_text().strip()
    except OSError:
        return ""
    return head.removeprefix("ref: refs/heads/") if head.startswith("ref:") else head[:8]


def running_workers():
    code, out = run_quiet(["ps", "-eo", "args"])
    return [line for line in out.splitlines() if "artisan queue:work" in line] if code == 0 else []


def list_sites():
    settings = load_settings()
    sites_dir = Path(settings["LARAVEL_SITES_DIR"])
    workers = running_workers()
    nginx = nginx_sites()
    sites = []
    known_paths = set()

    for record_file in sorted(REGISTRY_DIR.glob("*.env")):
        record = parse_env_file(record_file)
        name = record.get("PROJECT_NAME") or record_file.stem
        path = record.get("PROJECT_PATH") or str(sites_dir / name)
        known_paths.add(os.path.realpath(path))
        domain = record.get("DOMAIN") or f"{name}.test"
        conf = nginx_lookup(nginx, name, domain, path) or {}
        site = site_entry(name, path, domain, True, workers, conf.get("php", ""), record.get("PROJECT_TYPE") or "laravel")
        if site["type"] != "laravel":
            site.update(app_state(name, path, site["type"], record))
        sites.append(site)

    if sites_dir.is_dir():
        for child in sorted(sites_dir.iterdir()):
            if not child.is_dir() or child.name.startswith(".") or os.path.realpath(child) in known_paths:
                continue
            kind = apps.detect_type(child)
            if not kind:
                continue
            # A Laravel folder nginx already serves (set up by an older version) counts as linked.
            conf = nginx_lookup(nginx, child.name, f"{child.name.lower()}.test", str(child)) if kind == "laravel" else None
            domain = conf["domain"] if conf and conf["domain"] else f"{child.name.lower()}.test"
            sites.append(site_entry(child.name, str(child), domain, bool(conf), workers, (conf or {}).get("php", ""), kind))

    sites.sort(key=lambda site: (not site["linked"], site["name"].lower()))
    return sites


def site_entry(name, path, domain, linked, workers, php="", kind="laravel"):
    exists = Path(path).is_dir()
    return {
        "type": kind,
        "type_label": apps.TYPE_LABELS.get(kind, kind.capitalize()),
        "name": name,
        "path": path,
        "display_path": path.replace(str(HOME), "~", 1),
        "domain": domain,
        "url": f"http://{domain}",
        "linked": linked,
        "exists": exists,
        "php": php,
        "branch": git_branch(path) if exists else "",
        "worker": any(f"{path}/artisan queue:work" in line for line in workers),
    }


def app_state(name, path, kind, record):
    mode = record.get("RUN_MODE") or "dev"
    command = record.get("RUN_COMMAND") or apps.default_command(kind, mode, path)
    return {
        "port": record.get("PORT") or "",
        "mode": mode,
        "command": command,
        "custom_command": bool(record.get("RUN_COMMAND")),
        "running": PROCESSES.running(name, path),
    }


def update_record(name, updates):
    """Same KEY="value" format as upsert_project_key in core/RegistryManager.sh."""
    record_file = REGISTRY_DIR / f"{name}.env"
    if not record_file.is_file():
        raise ValueError(f"{name} is not linked")
    lines = [line for line in record_file.read_text().splitlines()
             if line.split("=", 1)[0] not in updates]
    lines += [f'{key}="{value}"'.replace("\n", " ") if False else f'{key}="' + str(value).replace('"', '\\"') + '"'
              for key, value in updates.items()]
    record_file.write_text("\n".join(lines) + "\n")


def used_ports():
    ports = set()
    for record_file in REGISTRY_DIR.glob("*.env"):
        port = parse_env_file(record_file).get("PORT", "")
        if port.isdigit():
            ports.add(int(port))
    return ports


def find_site(name):
    for site in list_sites():
        if site["name"] == name:
            return site
    raise ValueError(f"Unknown site: {name}")


def site_details(name):
    site = find_site(name)
    path = Path(site["path"])
    details = dict(site)
    details["laravel"] = ""
    try:
        lock = json.loads((path / "composer.lock").read_text())
        for package in lock.get("packages", []):
            if package.get("name") == "laravel/framework":
                details["laravel"] = package.get("version", "").lstrip("v")
                break
    except (OSError, ValueError):
        pass

    if site["type"] != "laravel":
        details["scripts"] = apps.scripts(path) if site["type"] != "django" else {}
        details["package_manager"] = apps.package_manager(path) if site["type"] != "django" else ""
        details["python"] = apps.venv_python(path) if site["type"] == "django" else ""
        details["has_deps"] = (path / ("requirements.txt" if site["type"] == "django" else "package.json")).is_file()
        details["deps_installed"] = (path / "node_modules").is_dir() if site["type"] != "django" else details["python"] != "python3"
        details["default_commands"] = {m: apps.default_command(site["type"], m, path) for m in ("dev", "prod")}
    details["worker_configured"] = Path(f"/etc/supervisor/conf.d/laravel-dev-{name}.conf").exists()
    details["has_env"] = (path / ".env").is_file()
    details["git"] = None
    if (path / ".git").exists():
        code, out = run_quiet(["git", "-C", str(path), "status", "--porcelain=v1", "-b"])
        if code == 0:
            lines = out.splitlines()
            head = lines[0] if lines else ""
            ahead = re.search(r"ahead (\d+)", head)
            behind = re.search(r"behind (\d+)", head)
            details["git"] = {
                "branch": site["branch"],
                "upstream": "..." in head,
                "ahead": int(ahead.group(1)) if ahead else 0,
                "behind": int(behind.group(1)) if behind else 0,
                "changes": max(len(lines) - 1, 0),
            }
    return details


def list_services():
    code, out = run_quiet(["systemctl", "list-unit-files", "--type=service", "--no-legend", "--plain"])
    units = {line.split()[0].removesuffix(".service") for line in out.splitlines() if line.strip()} if code == 0 else set()

    rows = []
    for candidates, label, description in SERVICES:
        unit = next((u for u in candidates if u in units), None)
        if unit:
            rows.append({"unit": unit, "label": label, "description": description, "kind": "core" if label in ("Nginx", "Database") else "extra"})
    for unit in sorted(u for u in units if re.fullmatch(r"php[0-9.]*-fpm", u)):
        version = unit.removeprefix("php").removesuffix("-fpm") or "default"
        rows.append({"unit": unit, "label": f"PHP {version} FPM", "description": "PHP FastCGI", "kind": "core"})

    if rows:
        code, out = run_quiet(["systemctl", "is-active", *[row["unit"] for row in rows]])
        states = out.splitlines()
        for index, row in enumerate(rows):
            row["status"] = states[index].strip() if index < len(states) else "unknown"
    return rows


def detect_editors():
    return [{"bin": binary, "label": label} for binary, label in EDITORS if shutil.which(binary)]


def tail_file(path, lines=300):
    try:
        with open(path, "rb") as handle:
            handle.seek(0, os.SEEK_END)
            size = handle.tell()
            handle.seek(max(size - 256 * 1024, 0))
            data = handle.read().decode("utf-8", errors="replace")
    except OSError:
        return None
    return "\n".join(data.splitlines()[-lines:])


# ── background tasks ─────────────────────────────────────────────────────────

class Task:
    def __init__(self, title, argv, cwd=None, site=None):
        self.id = uuid.uuid4().hex[:10]
        self.title = title
        self.argv = argv
        self.cwd = cwd
        self.site = site
        self.proc = None
        self.status = "running"
        self.code = None
        self.started = time.time()

    def summary(self):
        return {"id": self.id, "title": self.title, "status": self.status, "code": self.code,
                "started": self.started, "site": self.site}


class TaskRunner:
    """Runs commands on a pseudo-terminal so sudo can cache its credentials
    for the whole command and tools print progress the way they do in a shell."""

    def __init__(self, emit):
        self.emit = emit
        self.tasks = {}

    def start(self, title, argv, cwd=None, site=None, env_extra=None, stdin_data=None):
        task = Task(title, argv, cwd, site)
        master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 50, 140, 0, 0))
        if stdin_data:
            # Secrets (e.g. a sudo password) are typed into the terminal; never echo them.
            attrs = termios.tcgetattr(slave)
            attrs[3] &= ~termios.ECHO
            termios.tcsetattr(slave, termios.TCSANOW, attrs)
        env = dict(env_extra or os.environ)
        env.update({
            "LARAVEL_DEV_BASE_DIR": str(BASE_DIR),
            "LARAVEL_DEV_GUI": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "COMPOSER_NO_INTERACTION": "1",
            "NO_COLOR": "1",
            "TERM": "dumb",
        })

        def make_controlling_tty():
            os.setsid()
            fcntl.ioctl(0, termios.TIOCSCTTY, 0)

        try:
            task.proc = subprocess.Popen(
                argv, stdin=slave, stdout=slave, stderr=slave, cwd=cwd, env=env,
                preexec_fn=make_controlling_tty, close_fds=True,
            )
        except OSError as exc:
            os.close(master)
            os.close(slave)
            raise ValueError(f"Could not start {argv[0]}: {exc}") from exc
        os.close(slave)
        if stdin_data:
            os.write(master, stdin_data)

        self.tasks[task.id] = task
        self.emit({"type": "task", "task": task.summary()})
        threading.Thread(target=self._pump, args=(task, master), daemon=True).start()
        return task

    def _pump(self, task, master):
        while True:
            try:
                chunk = os.read(master, 8192)
            except OSError:
                break
            if not chunk:
                break
            text = ANSI_RE.sub("", chunk.decode("utf-8", errors="replace"))
            if text:
                GLib.idle_add(self.emit, {"type": "output", "id": task.id, "text": text})
        os.close(master)
        task.code = task.proc.wait()
        if task.status == "running":
            task.status = "success" if task.code == 0 else "error"
        GLib.idle_add(self.emit, {"type": "task", "task": task.summary(), "done": True})

    def cancel(self, task_id):
        task = self.tasks.get(task_id)
        if task and task.status == "running":
            task.status = "cancelled"
            try:
                os.killpg(task.proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass

    def running(self):
        return [t for t in self.tasks.values() if t.status == "running"]


# ── actions ──────────────────────────────────────────────────────────────────

def require(pattern, value, label):
    value = (value or "").strip()
    if not pattern.fullmatch(value):
        raise ValueError(f"Invalid {label}: {value or '(empty)'}")
    return value


def write_git_token(token):
    """Hand a clone token to the CLI's git askpass helper without putting it on argv."""
    runtime = CONFIG_DIR / "runtime"
    runtime.mkdir(parents=True, exist_ok=True)
    os.chmod(runtime, 0o700)
    token_file = runtime / "git-token"
    fd = os.open(token_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as handle:
        handle.write(f"{int(time.time()) + 900}\n{token}\n")


def build_action(action, p):
    """Translate a UI request into (title, argv, cwd, site). All input is validated here."""
    versions = php_versions()

    def php(optional=False):
        version = (p.get("php") or "").strip()
        if optional and not version:
            return ""
        if version not in versions:
            raise ValueError(f"PHP {version or '(none)'} is not installed")
        return version

    def domain():
        value = (p.get("domain") or "").strip().lower()
        return require(DOMAIN_RE, value, "domain") if value else ""

    kind = (p.get("type") or "laravel").strip()
    if kind not in ("laravel", *apps.APP_TYPES):
        raise ValueError(f"Unsupported project type: {kind}")

    if action == "create":
        name = require(NEW_NAME_RE, p.get("name"), "site name")
        custom_domain = domain()
        if kind != "laravel":
            if kind not in ("next", "nuxt", "django"):
                raise ValueError("New projects can be Laravel, Next.js, Nuxt or Django")
            port = str(apps.allocate_port(used_ports()))
            return f"Create {apps.TYPE_LABELS[kind]} {name}", [CLI, "create-app", kind, name, port, custom_domain], None, name
        argv = [CLI, "create", name, php()] + ([custom_domain] if custom_domain else [])
        return f"Create {name}", argv, None, name

    if action == "link":
        name = require(NEW_NAME_RE, p.get("name"), "site name")
        path = os.path.realpath(os.path.expanduser((p.get("path") or "").strip()))
        if not os.path.isdir(path):
            raise ValueError("That folder does not exist.")
        if kind != "laravel":
            port = str(apps.allocate_port(used_ports()))
            return f"Link {name}", [CLI, "link-app", name, path, kind, port, domain()], None, name
        if not Path(path, "public", "index.php").is_file():
            raise ValueError("That folder has no public/index.php — pick a Laravel project root.")
        return f"Link {name}", [CLI, "link", name, path, php(), domain()], None, name

    if action == "clone":
        name = require(NEW_NAME_RE, p.get("name"), "site name")
        repo = require(REPO_RE, p.get("repo"), "repository URL")
        if (p.get("token") or "").strip():
            write_git_token(p["token"].strip())
        port = str(apps.allocate_port(used_ports()))
        return f"Clone {name}", [CLI, "git-clone", name, repo, php(), "", domain(), port], None, name

    if action in ("app-install", "app-build", "app-script", "manage"):
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        path = site["path"]
        if site["type"] == "django":
            py = apps.venv_python(path)
            if action == "app-install":
                if not Path(path, "requirements.txt").is_file():
                    raise ValueError("No requirements.txt in this project")
                return f"pip install · {site['name']}", [py, "-m", "pip", "install", "-r", "requirements.txt"], path, site["name"]
            if action == "manage":
                args = shlex.split(p.get("args") or "")
                if not args:
                    raise ValueError("Type a manage.py command, e.g. migrate")
                return f"manage.py {args[0]} · {site['name']}", [py, "manage.py", *args], path, site["name"]
            raise ValueError("Not available for Django projects")
        if site["type"] == "laravel":
            raise ValueError("Not available for Laravel projects")
        pm = apps.package_manager(path)
        if action == "app-install":
            argv = [pm, "install"]
        elif action == "app-build":
            argv = [pm, "run", "build"]
        elif action == "app-script":
            script = (p.get("script") or "").strip()
            if script not in apps.scripts(path):
                raise ValueError(f"package.json has no script called {script!r}")
            argv = [pm, "run", script]
        else:
            raise ValueError("manage.py is only for Django projects")
        return f"{' '.join(argv)} · {site['name']}", ["bash", "-c", apps.NODE_PRELUDE + 'exec "$@"', "ld", *argv], path, site["name"]

    if action in ("repair", "unlink", "delete", "diagnose", "worker-setup"):
        name = require(NAME_RE, p.get("name"), "site name")
        argv = [CLI, action, name]
        if action in ("repair", "worker-setup") and php(optional=True):
            argv.append(php())
        return f"{action.replace('-', ' ').capitalize()} {name}", argv, None, name

    if action == "worker":
        name = require(NAME_RE, p.get("name"), "site name")
        op = require(re.compile(r"start|stop|restart"), p.get("op"), "worker action")
        return f"{op.capitalize()} worker · {name}", [CLI, "worker", op, name], None, name

    if action == "service":
        unit = require(UNIT_RE, p.get("unit"), "service")
        op = require(re.compile(r"start|stop|restart"), p.get("op"), "service action")
        return f"{op.capitalize()} {unit}", [CLI, "service", op, unit], None, None

    if action == "services":
        op = require(re.compile(r"start|stop"), p.get("op"), "action")
        return f"{op.capitalize()} all services", [CLI, op], None, None

    if action == "git":
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        op = require(re.compile(r"fetch|pull|push"), p.get("op"), "git action")
        return f"Git {op} · {site['name']}", [CLI, f"git-{op}", site["path"]], None, site["name"]

    if action in ("artisan", "composer"):
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        args = shlex.split(p.get("args") or "")
        binary = php_binary(site["php"])
        if action == "artisan":
            if not args:
                raise ValueError("Type an artisan command, e.g. migrate")
            argv = [binary, "artisan", *args]
        else:
            composer = shutil.which("composer")
            if not composer:
                raise ValueError("composer is not installed")
            argv = [binary, composer, *(args or ["install"])]
        return f"{action} {' '.join(args) or 'install'} · {site['name']}", argv, site["path"], site["name"]

    raise ValueError(f"Unknown action: {action}")


def open_target(target, p, prefs):
    if target == "url":
        url = p.get("url", "")
        if not re.match(r"^https?://", url):
            raise ValueError("Only http(s) links can be opened")
        return spawn(["xdg-open", url])

    site = find_site(require(NAME_RE, p.get("name"), "site name"))
    path = site["path"]
    if target == "browser":
        return spawn(["xdg-open", site["url"]])
    if target == "folder":
        return spawn(["xdg-open", path])
    if target in ("editor", "env"):
        return open_in_editor(os.path.join(path, ".env") if target == "env" else path, prefs)
    if target == "terminal":
        return open_terminal(cwd=path)
    raise ValueError(f"Unknown target: {target}")


def open_in_editor(file_path, prefs):
    editor = prefs.get("editor") or ""
    allowed = {e["bin"] for e in detect_editors()}
    if editor not in allowed:
        editor = next(iter(e["bin"] for e in detect_editors()), "")
    return spawn([editor, file_path] if editor else ["xdg-open", file_path])


def open_terminal(cwd=None, command=None):
    """Open the user's terminal in `cwd`, optionally running `command` (argv list)."""
    cwd = cwd or str(HOME)
    if shutil.which("exo-open"):
        extra = [shlex.join(command)] if command else []
        return spawn(["exo-open", "--working-directory", cwd, "--launch", "TerminalEmulator", *extra])
    if shutil.which("gnome-terminal"):
        return spawn(["gnome-terminal", f"--working-directory={cwd}", *(["--", *command] if command else [])])
    if shutil.which("konsole"):
        return spawn(["konsole", "--workdir", cwd, *(["-e", *command] if command else [])])
    return spawn(["x-terminal-emulator", *(["-e", shlex.join(command)] if command else [])], cwd=cwd)


def spawn(argv, cwd=None):
    subprocess.Popen(argv, cwd=cwd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return True


# ── window ───────────────────────────────────────────────────────────────────

class LaravelDevApp(Gtk.Application):
    def __init__(self, start_hidden=False):
        super().__init__(application_id=APP_ID)
        self.start_hidden = start_hidden
        self.window = None
        self.webview = None
        self.indicator = None
        self.tray_sites_menu = None
        self.prefs = load_prefs()
        self.dialogs = set()
        self.runner = TaskRunner(self.emit)
        self.remote = Remote(CONFIG_DIR, UI_DIR, lambda event: GLib.idle_add(self.emit, event))

    # lifecycle
    def do_startup(self):
        Gtk.Application.do_startup(self)
        GLib.set_application_name("Laravel Dev")
        GLib.set_prgname("laravel-dev")
        self.hold()  # keep running in the tray when the window is hidden

    def do_activate(self):
        if self.window is None:
            self.build_window()
            self.build_tray()
            if self.start_hidden and self.indicator:
                return
        self.show_window()

    def show_window(self, *_):
        self.window.show_all()
        self.window.present()

    def quit_app(self, *_):
        for task in self.runner.running():
            self.runner.cancel(task.id)
        for site in list_sites():  # dev servers belong to the app's session
            if site.get("running"):
                PROCESSES.stop(site["name"], site["path"])
        self.release()
        self.quit()

    def build_window(self):
        self.window = Gtk.ApplicationWindow(application=self, title="Laravel Dev")
        self.window.set_default_size(1180, 760)
        self.window.set_size_request(860, 560)
        for icon in (BASE_DIR / "assets" / "laravel-dev.png", BASE_DIR / "assets" / "laravel-dev.svg"):
            if icon.is_file():
                try:
                    self.window.set_icon_from_file(str(icon))
                    break
                except GLib.Error:
                    pass
        self.window.connect("delete-event", self.on_close)

        content = WebKit2.UserContentManager()
        content.register_script_message_handler("ld")
        content.connect("script-message-received::ld", self.on_message)
        self.webview = WebKit2.WebView.new_with_user_content_manager(content)
        settings = self.webview.get_settings()
        settings.set_enable_developer_extras(bool(os.environ.get("LARAVEL_DEV_DEBUG")))
        settings.set_enable_write_console_messages_to_stdout(bool(os.environ.get("LARAVEL_DEV_DEBUG")))
        self.webview.connect("decide-policy", self.on_decide_policy)
        self.webview.connect("context-menu", lambda *_: not os.environ.get("LARAVEL_DEV_DEBUG"))
        bg = Gdk.RGBA()
        bg.parse("#f6f6f7")
        self.webview.set_background_color(bg)
        self.webview.load_uri((UI_DIR / "web" / "index.html").as_uri())
        self.window.add(self.webview)

    def on_close(self, *_):
        if self.indicator and self.prefs.get("close_to_tray", True):
            self.window.hide()
            return True
        self.quit_app()
        return True

    def on_decide_policy(self, _view, decision, kind):
        if kind in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            uri = decision.get_navigation_action().get_request().get_uri()
            if not uri.startswith("file://"):
                if re.match(r"^https?://", uri):
                    spawn(["xdg-open", uri])
                decision.ignore()
                return True
        return False

    # tray
    def build_tray(self):
        if AppIndicator is None:
            return
        icon = BASE_DIR / "assets" / "laravel-dev.png"
        self.indicator = AppIndicator.Indicator.new(
            "laravel-dev", str(icon) if icon.is_file() else "laravel-dev",
            AppIndicator.IndicatorCategory.APPLICATION_STATUS,
        )
        self.indicator.set_title("Laravel Dev")
        self.indicator.set_status(AppIndicator.IndicatorStatus.ACTIVE)

        menu = Gtk.Menu()

        def item(label, callback):
            entry = Gtk.MenuItem(label=label)
            entry.connect("activate", callback)
            menu.append(entry)
            return entry

        item("Open Laravel Dev", self.show_window)
        menu.append(Gtk.SeparatorMenuItem())
        sites_item = Gtk.MenuItem(label="Sites")
        self.tray_sites_menu = Gtk.Menu()
        sites_item.set_submenu(self.tray_sites_menu)
        menu.append(sites_item)
        menu.append(Gtk.SeparatorMenuItem())
        item("Start services", lambda *_: self.start_action("services", {"op": "start"}))
        item("Stop services", lambda *_: self.start_action("services", {"op": "stop"}))
        menu.append(Gtk.SeparatorMenuItem())
        item("Quit", self.quit_app)
        menu.show_all()
        self.indicator.set_menu(menu)
        self.refresh_tray_sites()

    def refresh_tray_sites(self, sites=None):
        if self.tray_sites_menu is None:
            return
        if sites is None:
            threading.Thread(target=lambda: GLib.idle_add(self.refresh_tray_sites, list_sites()), daemon=True).start()
            return False
        for child in self.tray_sites_menu.get_children():
            self.tray_sites_menu.remove(child)
        linked = [s for s in sites if s["linked"]]
        for site in linked:
            entry = Gtk.MenuItem(label=site["domain"])
            entry.connect("activate", lambda _w, url=site["url"]: spawn(["xdg-open", url]))
            self.tray_sites_menu.append(entry)
        if not linked:
            empty = Gtk.MenuItem(label="No sites yet")
            empty.set_sensitive(False)
            self.tray_sites_menu.append(empty)
        self.tray_sites_menu.show_all()
        return False

    # bridge
    def js(self, script):
        if self.webview is None:
            return
        if hasattr(self.webview, "evaluate_javascript"):  # WebKitGTK >= 2.40
            self.webview.evaluate_javascript(script, -1, None, None, None, None, None)
        else:
            self.webview.run_javascript(script, None, None, None)

    def emit(self, event):
        self.js(f"window.LD && window.LD.onEvent({json.dumps(event)})")
        if event.get("done"):
            self.on_task_done(event["task"])
        return False

    def on_task_done(self, task):
        if task.get("site") or task["title"].endswith("services"):
            self.refresh_tray_sites()
        if not self.window.is_active():
            note = Gio.Notification.new(task["title"])
            note.set_body({"success": "Finished successfully.", "cancelled": "Cancelled."}.get(task["status"], "Failed — open Laravel Dev for details."))
            self.send_notification(task["id"], note)

    def on_message(self, _manager, result):
        value = result.get_js_value() if hasattr(result, "get_js_value") else result
        try:
            message = json.loads(value.to_string())
            call_id, method, params = message["id"], message["method"], message.get("params") or {}
        except (ValueError, KeyError, TypeError):
            return

        def reply(payload):
            self.js(f"window.LD && window.LD.resolve({json.dumps(call_id)}, {json.dumps(payload)})")
            return False

        if method in ("pick_folder", "pick_file", "server_download", "server_upload"):
            # File dialogs answer later, from their "response" signal: a blocking
            # dialog.run() inside this WebKit callback loses the chosen path.
            def done(data):
                reply({"ok": True, "data": data})
            try:
                getattr(self, f"api_{method}")(params, done)
            except Exception as exc:  # noqa: BLE001 — surfaced to the UI
                reply({"ok": False, "error": str(exc)})
            return

        if method in ("run", "cancel", "save"):  # need the main thread
            try:
                reply({"ok": True, "data": getattr(self, f"api_{method}")(params)})
            except Exception as exc:  # noqa: BLE001 — surfaced to the UI
                reply({"ok": False, "error": str(exc)})
            return

        def work():
            try:
                payload = {"ok": True, "data": getattr(self, f"api_{method}")(params)}
            except AttributeError:
                payload = {"ok": False, "error": f"Unknown method {method}"}
            except Exception as exc:  # noqa: BLE001
                payload = {"ok": False, "error": str(exc)}
            GLib.idle_add(reply, payload)

        threading.Thread(target=work, daemon=True).start()

    def start_action(self, action, params):
        if action.startswith("remote-"):
            title, argv, env, data = self.remote.build_task(action, params)
            task = self.runner.start(title, argv, env_extra=env, stdin_data=data)
            return task.summary()
        title, argv, cwd, site = build_action(action, params)
        return self.runner.start(title, argv, cwd, site).summary()

    # API — every api_* method is callable from app.js
    def api_init(self, _p):
        return {
            "version": (BASE_DIR / "VERSION").read_text().strip() if (BASE_DIR / "VERSION").is_file() else "",
            "home": str(HOME),
            "settings": load_settings(),
            "prefs": self.prefs,
            "php_versions": php_versions(),
            "editors": detect_editors(),
            "tray": self.indicator is not None,
            "sites": list_sites(),
            "services": list_services(),
            "tasks": [t.summary() for t in self.runner.tasks.values()],
        }

    def api_sites(self, _p):
        return list_sites()

    def api_site(self, p):
        return site_details(require(NAME_RE, p.get("name"), "site name"))

    def api_services(self, _p):
        return list_services()

    def api_log(self, p):
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        log = tail_file(os.path.join(site["path"], "storage", "logs", "laravel.log"))
        return {"text": log if log is not None else "", "exists": log is not None}

    def api_clear_log(self, p):
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        log = Path(site["path"], "storage", "logs", "laravel.log")
        if log.is_file():
            log.write_text("")
        return True

    def api_open(self, p):
        return open_target(p.get("target"), p, self.prefs)

    def api_run(self, p):
        return self.start_action(p.get("action"), p.get("params") or {})

    def api_cancel(self, p):
        self.runner.cancel(p.get("id"))
        return True

    def choose(self, action, title, done, start=None, multiple=False, name=None, accept="Select"):
        """Open a native file dialog without blocking; done(paths) gets a list (empty if cancelled)."""
        dialog = Gtk.FileChooserNative.new(title, self.window, action, accept, "Cancel")
        dialog.set_modal(True)
        dialog.set_select_multiple(multiple)
        if action == Gtk.FileChooserAction.SAVE:
            dialog.set_do_overwrite_confirmation(True)
            if name:
                dialog.set_current_name(name)
        if start and os.path.isdir(start):
            dialog.set_current_folder(start)
            if os.path.basename(start.rstrip("/")).startswith("."):
                dialog.set_show_hidden(True)

        def on_response(chooser, response):
            paths = list(chooser.get_filenames()) if response == Gtk.ResponseType.ACCEPT else []
            self.dialogs.discard(chooser)
            GLib.idle_add(chooser.destroy)
            done(paths)

        self.dialogs.add(dialog)  # keep a reference until it answers
        dialog.connect("response", on_response)
        dialog.show()

    def api_pick_folder(self, p, done):
        start = os.path.expanduser(p.get("current") or "")
        while start and not os.path.isdir(start):
            start = os.path.dirname(start)
        self.choose(Gtk.FileChooserAction.SELECT_FOLDER, p.get("title") or "Choose a folder",
                    lambda paths: done(paths[0] if paths else ""), start=start or str(HOME))

    def api_detect(self, p):
        path = os.path.realpath(os.path.expanduser(p.get("path") or ""))
        return apps.detect_type(path) if os.path.isdir(path) else ""

    def _app_site(self, p):
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        if site["type"] in ("laravel", "") or not site["linked"]:
            raise ValueError("Only linked Next.js, Nuxt, Vite, Node and Django apps can be started here")
        if not site.get("port"):
            raise ValueError("No port recorded for this app — run Repair")
        return site

    def api_app_start(self, p):
        site = self._app_site(p)
        PROCESSES.start(site["name"], site["path"], site["command"], site["port"], site["type"])
        GLib.idle_add(self.refresh_tray_sites)
        return True

    def api_app_stop(self, p):
        site = self._app_site(p)
        PROCESSES.stop(site["name"], site["path"])
        GLib.idle_add(self.refresh_tray_sites)
        return True

    def api_app_restart(self, p):
        site = self._app_site(p)
        PROCESSES.stop(site["name"], site["path"])
        PROCESSES.start(site["name"], site["path"], site["command"], site["port"], site["type"])
        return True

    def api_app_log(self, p):
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        text = PROCESSES.log(site["name"])
        return {"text": text or "", "exists": text is not None}

    def api_app_config(self, p):
        site = self._app_site(p)
        mode = p.get("mode") if p.get("mode") in ("dev", "prod") else site["mode"]
        command = (p.get("command") or "").strip()
        if "\n" in command or len(command) > 500:
            raise ValueError("Invalid command")
        default = apps.default_command(site["type"], mode, site["path"])
        update_record(site["name"], {"RUN_MODE": mode, "RUN_COMMAND": "" if command in ("", default) else command})
        return True

    def api_pick_file(self, p, done):
        self.choose(Gtk.FileChooserAction.OPEN, p.get("title") or "Choose a file",
                    lambda paths: done(paths[0] if paths else ""),
                    start=os.path.expanduser(p.get("current") or str(HOME)))

    # remote servers
    def api_servers(self, _p):
        return {"servers": self.remote.list(), "ssh_hosts": self.remote.ssh_config_hosts()}

    def api_server_save(self, p):
        return self.remote.upsert(p)

    def api_server_remove(self, p):
        return self.remote.remove(p.get("id", ""))

    def api_server_info(self, p):
        return self.remote.info(p.get("id", ""))

    def api_server_disconnect(self, p):
        return self.remote.disconnect(p.get("id", ""))

    def api_server_sites(self, p):
        return self.remote.sites(p.get("id", ""))

    def api_server_ls(self, p):
        return self.remote.list_dir(p.get("id", ""), p.get("path") or "~", bool(p.get("hidden")))

    def api_server_log(self, p):
        return self.remote.tail_log(p.get("id", ""), p.get("path", ""))

    def api_server_file_op(self, p):
        return self.remote.file_op(p.get("id", ""), p.get("op"), p.get("path", ""), p.get("target", ""))

    def api_server_edit(self, p):
        local = self.remote.fetch_for_edit(p.get("id", ""), p.get("path", ""))
        return open_in_editor(local, self.prefs)

    def api_server_sudo(self, p):
        return self.remote.verify_sudo(p.get("id", ""), p.get("password") or "")

    def api_server_terminal(self, p):
        return open_terminal(command=self.remote.terminal_argv(p.get("id", ""), p.get("path", "")))

    def _transfer(self, label, work):
        def run():
            try:
                work()
                GLib.idle_add(self.emit, {"type": "transfer", "ok": True, "label": label})
            except (RemoteError, OSError) as exc:
                GLib.idle_add(self.emit, {"type": "transfer", "ok": False, "label": label, "error": str(exc)})
        threading.Thread(target=run, daemon=True).start()

    def api_server_download(self, p, done):
        server_id, remote_path, is_dir = p.get("id", ""), p.get("path", ""), bool(p.get("dir"))
        name = os.path.basename(remote_path.rstrip("/")) + (".tar.gz" if is_dir else "")

        def chosen(paths):
            if paths:
                self._transfer(f"Downloaded {name}", lambda: self.remote.download(server_id, remote_path, is_dir, paths[0]))
            done(bool(paths))

        downloads = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD)
        self.choose(Gtk.FileChooserAction.SAVE, "Save download", chosen, start=downloads, name=name, accept="Save")

    def api_server_upload(self, p, done):
        server_id, remote_dir = p.get("id", ""), p.get("dir", "").rstrip("/")

        def chosen(files):
            if files:
                def work():
                    for local in files:
                        remote_path = f"{remote_dir}/{os.path.basename(local)}"
                        self.remote.upload_bytes(server_id, remote_path, Path(local).read_bytes(), overwrite=False)
                self._transfer(f"Uploaded {len(files)} file{'s' if len(files) > 1 else ''}", work)
            done(len(files))

        self.choose(Gtk.FileChooserAction.OPEN, "Upload files", chosen, start=str(HOME), multiple=True, accept="Upload")

    def api_save(self, p):
        settings = p.get("settings") or {}
        updates = {}
        if "LARAVEL_SITES_DIR" in settings:
            sites_dir = os.path.expanduser(settings["LARAVEL_SITES_DIR"].strip())
            if not sites_dir.startswith("/"):
                raise ValueError("Sites directory must be an absolute path")
            updates["LARAVEL_SITES_DIR"] = updates["SITES_DIR"] = sites_dir
        if settings.get("DB_TYPE", "mysql") not in ("mysql", "mariadb", "pgsql", "sqlite"):
            raise ValueError("Unsupported database type")
        if settings.get("DB_PORT") and not str(settings["DB_PORT"]).isdigit():
            raise ValueError("Database port must be a number")
        for key in ("DB_TYPE", "DB_HOST", "DB_PORT", "DB_USER", "DB_PASSWORD"):
            if key in settings:
                updates[key] = str(settings[key]).strip() if key != "DB_PASSWORD" else str(settings[key])
        if updates:
            save_settings(updates)

        prefs = p.get("prefs")
        if prefs is not None:
            self.prefs.update({k: prefs[k] for k in (*DEFAULT_PREFS, "autostart") if k in prefs})
            save_prefs(self.prefs)
            self.prefs = load_prefs()
        return {"settings": load_settings(), "prefs": self.prefs}


def main():
    start_hidden = "--hidden" in sys.argv
    app = LaravelDevApp(start_hidden=start_hidden)
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    return app.run([sys.argv[0]])


if __name__ == "__main__":
    sys.exit(main())
