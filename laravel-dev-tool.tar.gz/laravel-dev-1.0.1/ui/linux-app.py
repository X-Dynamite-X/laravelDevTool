#!/usr/bin/env python3
import os
import signal
import socket
import subprocess
import sys
import time
from urllib.request import urlopen


def wait_for_http(url: str, timeout: float = 12.0) -> bool:
    start = time.time()
    while time.time() - start < timeout:
        try:
            with urlopen(url, timeout=1.5) as r:
                if 200 <= r.status < 500:
                    return True
        except Exception:
            time.sleep(0.25)
    return False


def can_bind(host: str, port: int) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def require_gui_runtime():
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        try:
            gi.require_version("WebKit2", "4.1")
        except ValueError:
            gi.require_version("WebKit2", "4.0")
        from gi.repository import Gtk, WebKit2
        return Gtk, WebKit2
    except Exception:
        print("Missing GUI dependencies for desktop app.")
        print("Install one of:")
        print("  sudo apt install python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1")
        print("  sudo apt install python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.0")
        return None, None


def run_webkit_app(url: str, server_proc):
    Gtk, WebKit2 = require_gui_runtime()
    if Gtk is None or WebKit2 is None:
        return 1

    win = Gtk.Window(title="Laravel Dev")
    win.set_default_size(1220, 820)
    icon_path = os.path.join(os.environ.get("LARAVEL_DEV_BASE_DIR", "/opt/laravel-dev"), "assets", "laravel-dev.png")
    if os.path.isfile(icon_path):
        try:
            win.set_icon_from_file(icon_path)
        except Exception:
            pass

    vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    toolbar.set_border_width(8)

    refresh_btn = Gtk.Button(label="Refresh")
    address = Gtk.Entry()
    address.set_text(url)

    webview = WebKit2.WebView()
    webview.load_uri(url)

    def on_refresh(_btn):
        webview.reload()

    def on_address_activate(entry):
        target = entry.get_text().strip()
        if target:
            webview.load_uri(target)

    def on_uri_changed(view, _param):
        uri = view.get_uri() or ""
        if uri:
            address.set_text(uri)

    def on_destroy(_w):
        if server_proc is not None:
            try:
                os.killpg(os.getpgid(server_proc.pid), signal.SIGTERM)
            except Exception:
                pass
        Gtk.main_quit()

    refresh_btn.connect("clicked", on_refresh)
    address.connect("activate", on_address_activate)
    webview.connect("notify::uri", on_uri_changed)
    win.connect("destroy", on_destroy)

    toolbar.pack_start(refresh_btn, False, False, 0)
    toolbar.pack_start(address, True, True, 0)

    vbox.pack_start(toolbar, False, False, 0)
    vbox.pack_start(webview, True, True, 0)
    win.add(vbox)

    win.show_all()
    Gtk.main()
    return 0


def main() -> int:
    base_dir = os.environ.get("LARAVEL_DEV_BASE_DIR", "/opt/laravel-dev")
    port = int(os.environ.get("WEB_PORT", "4040"))
    url = f"http://127.0.0.1:{port}"
    server_proc = None

    if can_bind("127.0.0.1", port):
        server_proc = subprocess.Popen(
            ["php", "-S", f"127.0.0.1:{port}", "-t", os.path.join(base_dir, "public")],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            preexec_fn=os.setsid,
        )

    if not wait_for_http(url, timeout=12.0):
        print(f"Failed to reach dashboard at {url}")
        if server_proc is not None:
            try:
                os.killpg(os.getpgid(server_proc.pid), signal.SIGTERM)
            except Exception:
                pass
        return 1

    return run_webkit_app(url, server_proc)


if __name__ == "__main__":
    sys.exit(main())
