"use strict";

/* ── icons (lucide-style paths) ─────────────────────────────────────────── */
const ICONS = {
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  server: '<rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><path d="M6 6h.01M6 18h.01"/>',
  settings: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  terminal: '<path d="m4 17 6-6-6-6M12 19h8"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  refresh: '<path d="M21 12a9 9 0 0 1-15.5 6.2L3 16M3 12a9 9 0 0 1 15.5-6.2L21 8M21 3v5h-5M3 21v-5h5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  play: '<path d="m7 4 13 8-13 8z"/>',
  stop: '<rect x="5" y="5" width="14" height="14" rx="2"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  browser: '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  code: '<path d="m16 18 6-6-6-6M8 6l-6 6 6 6"/>',
  folder: '<path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.7-.9l-.8-1.2A2 2 0 0 0 7.9 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z"/>',
  file: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
  branch: '<circle cx="6" cy="5" r="2.5"/><circle cx="6" cy="19" r="2.5"/><circle cx="18" cy="7" r="2.5"/><path d="M6 7.5v9M18 9.5c0 5-6 4-11 7.5"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  trash: '<path d="M3 6h18M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  unlink: '<path d="m18.8 13.4 1.7-1.7a5 5 0 0 0-7.1-7.1l-1.7 1.7M5.2 10.6l-1.7 1.7a5 5 0 0 0 7.1 7.1l1.7-1.7M8 2v3M2 8h3M16 22v-3M22 16h-3"/>',
  wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.8-3.8a6 6 0 0 1-7.9 7.9l-6.9 6.9a2.1 2.1 0 0 1-3-3l6.9-6.9a6 6 0 0 1 7.9-7.9z"/>',
  pulse: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
  zap: '<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
  cpu: '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
  sparkles: '<path d="m12 3 1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2z"/>',
  alert: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
  cloud: '<path d="M17.5 19H9a7 7 0 1 1 6.7-9h1.8a4.5 4.5 0 1 1 0 9z"/>',
  back: '<path d="m15 18-6-6 6-6"/>',
  up: '<path d="m18 15-6-6-6 6"/>',
  home: '<path d="m3 10 9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  rocket: '<path d="M4.5 16.5c-1.5 1.3-2 5-2 5s3.7-.5 5-2c.7-.8.7-2.1-.1-2.9a2.2 2.2 0 0 0-2.9-.1z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.9A12.9 12.9 0 0 1 22 2c0 2.7-.8 7.5-6 11a22.4 22.4 0 0 1-4 2z"/><path d="M9 12H4s.6-3 2-4c1.6-1.1 5 0 5 0M12 15v5s3-.6 4-2c1.1-1.6 0-5 0-5"/>',
  power: '<path d="M18.4 6.6a9 9 0 1 1-12.8 0M12 2v10"/>',
  key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
  rename: '<path d="M17 22h-1a4 4 0 0 1-4-4V6a4 4 0 0 1 4-4h1M7 22h1a4 4 0 0 0 4-4v-1M7 2h1a4 4 0 0 1 4 4v1"/>',
  eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
};

function icon(name, cls = "") {
  return `<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ""}</svg>`;
}

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

const NEW_NAME_RE = /^[a-z0-9][a-z0-9.-]*$/;
const DOMAIN_RE = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/;

/* ── bridge to ui/app.py ────────────────────────────────────────────────── */
const LD = {
  seq: 0,
  pending: new Map(),
  call(method, params = {}) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      const message = JSON.stringify({ id, method, params });
      if (window.webkit?.messageHandlers?.ld) {
        window.webkit.messageHandlers.ld.postMessage(message);
      } else {
        Demo.handle(id, method, params);
      }
    });
  },
  resolve(id, payload) {
    const entry = this.pending.get(id);
    if (!entry) return;
    this.pending.delete(id);
    payload.ok ? entry.resolve(payload.data) : entry.reject(new Error(payload.error || "Unknown error"));
  },
  onEvent(event) {
    if (event.type === "task") onTaskEvent(event.task, event.done);
    if (event.type === "output") onTaskOutput(event.id, event.text);
    window.Servers?.onEvent(event);
  },
};
window.LD = LD;

/* ── state ──────────────────────────────────────────────────────────────── */
const state = {
  view: "sites",
  filter: "",
  sites: [],
  services: [],
  phpVersions: [],
  settings: {},
  prefs: {},
  editors: [],
  tray: false,
  tasks: new Map(),
  output: new Map(),
  activeTask: null,
  drawer: { name: null, tab: "overview", details: null },
  loaded: false,
};

/* ── helpers ────────────────────────────────────────────────────────────── */
function avatarColor(name) {
  let hash = 0;
  for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  return `hsl(${hash % 360} 62% 52%)`;
}

function avatar(name, size = "") {
  return `<div class="avatar ${size}" style="background:${avatarColor(name)}">${esc(name[0] || "?")}</div>`;
}

function toast(type, title, detail = "") {
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.innerHTML = `${icon(type === "error" ? "alert" : "check")}<div><b>${esc(title)}</b>${detail ? `<small>${esc(detail)}</small>` : ""}</div>`;
  $("#toasts").append(el);
  setTimeout(() => { el.classList.add("leaving"); setTimeout(() => el.remove(), 220); }, type === "error" ? 6000 : 3500);
}

async function api(method, params) {
  try {
    return await LD.call(method, params);
  } catch (err) {
    toast("error", "Something went wrong", err.message);
    throw err;
  }
}

function copyText(text) {
  const area = document.createElement("textarea");
  area.value = text;
  document.body.append(area);
  area.select();
  document.execCommand("copy");
  area.remove();
  toast("success", "Copied to clipboard");
}

function timeAgo(ts) {
  const s = Math.max(0, Math.round(Date.now() / 1000 - ts));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  return `${Math.floor(s / 3600)}h ago`;
}

function phpOptions(selected) {
  return state.phpVersions.map((v) => `<option value="${esc(v)}" ${v === selected ? "selected" : ""}>PHP ${esc(v)}</option>`).join("");
}

function defaultPhp() {
  const pref = state.prefs.default_php;
  return state.phpVersions.includes(pref) ? pref : state.phpVersions[state.phpVersions.length - 1];
}

function slugify(value) {
  return value.toLowerCase().replace(/\.git$/, "").replace(/[^a-z0-9.-]+/g, "-").replace(/^[^a-z0-9]+|-+$/g, "");
}

function applyTheme() {
  const theme = state.prefs.theme || "system";
  if (theme === "system") document.documentElement.removeAttribute("data-theme");
  else document.documentElement.setAttribute("data-theme", theme);
}

/* ── navigation ─────────────────────────────────────────────────────────── */
function setView(view) {
  state.view = view;
  $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  $$(".view").forEach((v) => (v.hidden = v.id !== `view-${view}`));
  if (view === "services") refreshServices();
  if (view === "settings") renderSettings();
  if (view === "servers") window.Servers?.show();
}

/* ── sites ──────────────────────────────────────────────────────────────── */
function renderSites() {
  const body = $("#sites-body");
  const linked = state.sites.filter((s) => s.linked);
  const unlinked = state.sites.filter((s) => !s.linked);
  $("#nav-sites-count").textContent = linked.length || "";
  const dir = (state.settings.LARAVEL_SITES_DIR || "").replace(state.home, "~");
  $("#sites-subtitle").textContent = `${linked.length} ${linked.length === 1 ? "site" : "sites"} · served from ${dir}`;

  if (!state.loaded) {
    body.innerHTML = `<div class="site-list">${'<div class="skeleton"></div>'.repeat(4)}</div>`;
    return;
  }

  if (!state.sites.length) {
    body.innerHTML = `
      <div class="empty">
        <div class="empty-icon">${icon("sparkles")}</div>
        <h2>No sites yet</h2>
        <p>Create a fresh Laravel app, link a project you already have, or clone one from Git. Each gets its own <b>.test</b> domain.</p>
        <div class="actions">
          <button class="btn primary" data-add="new">${icon("plus")}New project</button>
          <button class="btn" data-add="link">${icon("folder")}Link folder</button>
          <button class="btn" data-add="clone">${icon("branch")}Clone repo</button>
        </div>
      </div>`;
    return;
  }

  const q = state.filter.trim().toLowerCase();
  const match = (s) => !q || [s.name, s.domain, s.path].some((v) => v.toLowerCase().includes(q));
  const shownLinked = linked.filter(match);
  const shownUnlinked = unlinked.filter(match);

  let html = "";
  if (shownLinked.length) html += `<div class="site-list">${shownLinked.map(siteRow).join("")}</div>`;
  if (shownUnlinked.length) {
    html += `<div class="group-label" style="margin-top:${shownLinked.length ? 24 : 0}px">${icon("folder")}Found in ${esc(dir)} but not linked</div>
             <div class="site-list">${shownUnlinked.map(siteRow).join("")}</div>`;
  }
  if (!html) html = `<div class="empty"><h2>No matches</h2><p>Nothing matches “${esc(state.filter)}”.</p></div>`;
  body.innerHTML = html;
}

function siteRow(site) {
  const selected = state.drawer.name === site.name ? "selected" : "";
  const chips = [];
  if (!site.exists) chips.push(`<span class="chip warn">${icon("alert")}Folder missing</span>`);
  if (site.linked && site.php) chips.push(`<span class="chip php">PHP ${esc(site.php)}</span>`);
  if (site.branch) chips.push(`<span class="chip branch">${icon("branch")}${esc(site.branch)}</span>`);
  if (site.worker) chips.push(`<span class="chip ok" title="Queue worker running"><span class="dot on"></span>Queue</span>`);

  const actions = site.linked
    ? `<button class="btn ghost icon-btn sm" data-open="browser" title="Open in browser">${icon("browser")}</button>
       <button class="btn ghost icon-btn sm" data-open="editor" title="Open in editor">${icon("code")}</button>
       <button class="btn ghost icon-btn sm" data-open="folder" title="Open folder">${icon("folder")}</button>
       <button class="btn ghost icon-btn sm" data-open="terminal" title="Open terminal">${icon("terminal")}</button>`
    : `<button class="btn sm" data-link-site>${icon("link")}Link</button>`;

  return `
    <div class="site-row ${selected} ${site.exists ? "" : "missing"}" data-site="${esc(site.name)}">
      ${avatar(site.name)}
      <div class="site-main">
        <div class="site-name">${esc(site.name)}</div>
        <div class="site-meta">
          ${site.linked ? `<a class="link" data-open="browser">${esc(site.domain)}</a><span class="sep">·</span>` : ""}
          <span class="path" title="${esc(site.path)}">${esc(site.display_path)}</span>
        </div>
      </div>
      <div class="site-chips">${chips.join("")}</div>
      <div class="site-actions">${actions}</div>
    </div>`;
}

async function refreshSites() {
  state.sites = await api("sites");
  state.loaded = true;
  renderSites();
  if (state.drawer.name) {
    if (state.sites.some((s) => s.name === state.drawer.name)) loadDrawer();
    else closeDrawer();
  }
}

function siteByName(name) {
  return state.sites.find((s) => s.name === name);
}

function openOn(target, name) {
  api("open", { target, name });
}

/* ── site drawer ────────────────────────────────────────────────────────── */
let logTimer = null;

function openDrawer(name, tab = "overview") {
  state.drawer = { name, tab, details: null };
  $("#site-drawer").classList.add("open");
  $("#site-drawer").setAttribute("aria-hidden", "false");
  $("#drawer-scrim").hidden = false;
  renderSites();
  renderDrawer();
  loadDrawer();
}

function closeDrawer() {
  state.drawer = { name: null, tab: "overview", details: null };
  clearInterval(logTimer);
  $("#site-drawer").classList.remove("open");
  $("#site-drawer").setAttribute("aria-hidden", "true");
  $("#drawer-scrim").hidden = true;
  renderSites();
}

async function loadDrawer() {
  const name = state.drawer.name;
  if (!name || !siteByName(name)?.linked) return;
  try {
    const details = await LD.call("site", { name });
    if (state.drawer.name === name) {
      state.drawer.details = details;
      renderDrawer();
    }
  } catch { /* site disappeared mid-refresh */ }
}

function renderDrawer() {
  const name = state.drawer.name;
  const site = state.drawer.details || siteByName(name);
  const el = $("#site-drawer");
  if (!site) return;
  clearInterval(logTimer);

  const header = `
    <div class="drawer-header">
      ${avatar(site.name, "lg")}
      <div style="min-width:0">
        <h2>${esc(site.name)}</h2>
        ${site.linked ? `<a class="link" data-open="browser">${esc(site.url)}</a>` : `<span class="muted">Not linked</span>`}
      </div>
      <button class="btn ghost icon-btn close" data-close-drawer title="Close (Esc)">${icon("x")}</button>
    </div>`;

  if (!site.linked) {
    el.innerHTML = `${header}
      <div class="drawer-body">
        <div class="card">
          <h3>${icon("link")}Link this project</h3>
          <p class="muted" style="margin-top:0">This Laravel project lives in your sites folder but isn't served yet. Linking sets up Nginx, a <b>${esc(site.domain)}</b> domain, a database and the <code>.env</code> file.</p>
          <button class="btn primary" data-link-site>${icon("link")}Link ${esc(site.name)}</button>
        </div>
      </div>`;
    return;
  }

  const tabs = ["overview", "logs"].concat(site.git ? ["git"] : []);
  if (!tabs.includes(state.drawer.tab)) state.drawer.tab = "overview";
  const tabLabels = { overview: "Overview", logs: "Logs", git: "Git" };

  el.innerHTML = `${header}
    <div class="drawer-body">
      <div class="quick-actions">
        <button class="quick-action" data-open="browser">${icon("browser")}Browser</button>
        <button class="quick-action" data-open="editor">${icon("code")}Editor</button>
        <button class="quick-action" data-open="folder">${icon("folder")}Folder</button>
        <button class="quick-action" data-open="terminal">${icon("terminal")}Terminal</button>
        <button class="quick-action" data-open="env">${icon("file")}.env</button>
      </div>
      <div class="tabs">${tabs.map((t) => `<button class="tab ${t === state.drawer.tab ? "active" : ""}" data-tab="${t}">${tabLabels[t]}</button>`).join("")}</div>
      <div id="drawer-tab"></div>
    </div>`;

  const pane = $("#drawer-tab", el);
  if (state.drawer.tab === "overview") pane.innerHTML = overviewTab(site);
  if (state.drawer.tab === "git") pane.innerHTML = gitTab(site);
  if (state.drawer.tab === "logs") {
    pane.innerHTML = `
      <div class="log-toolbar">
        <span class="muted">storage/logs/laravel.log · refreshes every 3s</span>
        <button class="btn sm" data-log="refresh">${icon("refresh")}Refresh</button>
        <button class="btn sm" data-log="clear">${icon("trash")}Clear</button>
      </div>
      <pre class="log-view" id="log-view">Loading…</pre>`;
    loadLog(true);
    logTimer = setInterval(() => loadLog(false), 3000);
  }
}

function overviewTab(site) {
  const loading = !state.drawer.details;
  const worker = loading
    ? `<span class="muted">Checking…</span>`
    : !site.worker_configured
      ? `<p class="muted" style="margin:0 0 10px">No queue worker yet. Laravel Dev can keep <code>queue:work</code> running with Supervisor.</p>
         <button class="btn sm" data-action="worker-setup">${icon("layers")}Set up worker</button>`
      : `<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
           <span class="dot ${site.worker ? "on" : "off"}"></span>${site.worker ? "Running" : "Stopped"}
         </div>
         <div class="btn-row">
           ${site.worker
             ? `<button class="btn sm" data-worker="restart">${icon("refresh")}Restart</button>
                <button class="btn sm" data-worker="stop">${icon("stop")}Stop</button>`
             : `<button class="btn sm" data-worker="start">${icon("play")}Start</button>`}
         </div>`;

  return `
    <div class="card">
      <dl class="info">
        <dt>Domain</dt><dd><a class="link text" data-open="browser">${esc(site.domain)}</a></dd>
        <dt>Path</dt><dd><span class="text selectable" title="${esc(site.path)}">${esc(site.display_path)}</span>
          <button class="btn ghost icon-btn sm" data-copy="${esc(site.path)}" title="Copy path">${icon("copy")}</button></dd>
        <dt>PHP</dt><dd>
          <form class="inline-form" data-php-form>
            <select name="php">${phpOptions(site.php || defaultPhp())}</select>
            <button class="btn sm" type="submit">Apply</button>
          </form></dd>
        ${site.laravel ? `<dt>Laravel</dt><dd>${esc(site.laravel)}</dd>` : ""}
        ${site.branch ? `<dt>Branch</dt><dd>${icon("branch")}${esc(site.branch)}</dd>` : ""}
      </dl>
    </div>

    <div class="card">
      <h3>${icon("terminal")}Artisan</h3>
      <div class="btn-row">
        <button class="btn sm" data-artisan="migrate">migrate</button>
        <button class="btn sm" data-artisan="migrate:fresh --seed" data-confirm="This drops every table in the database.">migrate:fresh --seed</button>
        <button class="btn sm" data-artisan="optimize:clear">optimize:clear</button>
        <button class="btn sm" data-artisan="storage:link">storage:link</button>
        <button class="btn sm" data-composer="install">composer install</button>
      </div>
      <form class="artisan-input" data-artisan-form>
        <span class="prefix">php artisan</span>
        <input name="args" placeholder="make:model Post -m" spellcheck="false">
        <button class="btn sm" type="submit">Run</button>
      </form>
    </div>

    <div class="card">
      <h3>${icon("layers")}Queue worker</h3>
      ${worker}
    </div>

    <div class="card danger-zone">
      <h3>${icon("wrench")}Maintenance</h3>
      <div class="row-item"><div><b>Repair</b><small>Rewrite Nginx config, fix permissions and .env.</small></div>
        <button class="btn sm" data-action="repair">${icon("wrench")}Repair</button></div>
      <div class="row-item"><div><b>Diagnose</b><small>Check folder, Nginx, hosts entry and HTTP response.</small></div>
        <button class="btn sm" data-action="diagnose">${icon("pulse")}Diagnose</button></div>
      <div class="row-item"><div><b>Unlink</b><small>Stop serving it. Files and database stay.</small></div>
        <button class="btn sm danger" data-action="unlink">${icon("unlink")}Unlink</button></div>
      <div class="row-item"><div><b>Delete</b><small>Removes the folder, database and config. Cannot be undone.</small></div>
        <button class="btn sm danger" data-action="delete">${icon("trash")}Delete</button></div>
    </div>`;
}

function gitTab(site) {
  const g = site.git;
  const sync = !g.upstream
    ? `<span class="chip">No upstream</span>`
    : g.ahead || g.behind
      ? `${g.behind ? `<span class="chip warn">${icon("download")}${g.behind} behind</span>` : ""}${g.ahead ? `<span class="chip php">${icon("upload")}${g.ahead} ahead</span>` : ""}`
      : `<span class="chip ok">${icon("check")}Up to date</span>`;
  return `
    <div class="card">
      <dl class="info">
        <dt>Branch</dt><dd>${icon("branch")}<b>${esc(g.branch)}</b></dd>
        <dt>Remote</dt><dd>${sync}</dd>
        <dt>Changes</dt><dd>${g.changes ? `<span class="chip warn">${g.changes} uncommitted</span>` : `<span class="muted">Working tree clean</span>`}</dd>
      </dl>
    </div>
    <div class="card">
      <h3>Sync</h3>
      <div class="btn-row">
        <button class="btn sm" data-git="fetch">${icon("refresh")}Fetch</button>
        <button class="btn sm" data-git="pull">${icon("download")}Pull</button>
        <button class="btn sm" data-git="push">${icon("upload")}Push</button>
        <button class="btn sm" data-open="terminal">${icon("terminal")}Terminal</button>
      </div>
    </div>`;
}

async function loadLog(scrollToEnd) {
  const view = $("#log-view");
  if (!view || !state.drawer.name) return;
  const atBottom = view.scrollHeight - view.scrollTop - view.clientHeight < 40;
  try {
    const log = await LD.call("log", { name: state.drawer.name });
    const current = $("#log-view");
    if (!current) return;
    current.innerHTML = log.exists && log.text
      ? log.text.split("\n").map((line) => {
          const cls = /\.(ERROR|CRITICAL|ALERT|EMERGENCY):/.test(line) ? "log-line-error" : /\.WARNING:/.test(line) ? "log-line-warning" : "";
          return cls ? `<span class="${cls}">${esc(line)}</span>` : esc(line);
        }).join("\n")
      : `<span style="opacity:.6">${log.exists ? "Log is empty." : "No laravel.log yet."}</span>`;
    if (scrollToEnd || atBottom) current.scrollTop = current.scrollHeight;
  } catch { /* ignore transient read errors */ }
}

/* ── tasks / activity ───────────────────────────────────────────────────── */
async function runAction(action, params = {}, { show = true } = {}) {
  try {
    const task = await LD.call("run", { action, params });
    state.activeTask = task.id;
    if (show) openActivity();
    return task;
  } catch (err) {
    toast("error", "Couldn't start", err.message);
    return null;
  }
}

function onTaskEvent(task, done) {
  state.tasks.set(task.id, task);
  if (!state.output.has(task.id)) state.output.set(task.id, "");
  if (!state.activeTask) state.activeTask = task.id;
  renderTasks();
  if (!done) return;

  if (task.status === "success") toast("success", task.title, "Finished successfully");
  else if (task.status === "error") toast("error", task.title, "Failed — see Activity for details");

  window.Servers?.onTaskDone(task);
  if (task.site) refreshSites();
  refreshServices();
}

function onTaskOutput(id, text) {
  let buffer = (state.output.get(id) || "") + text;
  buffer = buffer.replace(/\r\n/g, "\n").replace(/[^\n]*\r(?=[^\n])/g, "");
  if (buffer.length > 250000) buffer = buffer.slice(-200000);
  state.output.set(id, buffer);
  if (id === state.activeTask) renderTaskOutput();
}

function renderTasks() {
  const list = $("#task-list");
  const tasks = [...state.tasks.values()].sort((a, b) => b.started - a.started);
  const running = tasks.filter((t) => t.status === "running").length;
  const badge = $("#activity-badge");
  badge.hidden = running === 0;
  badge.textContent = running;
  badge.classList.toggle("spin", running > 0);

  list.innerHTML = tasks.length
    ? tasks.map((t) => `
        <li class="task ${t.id === state.activeTask ? "active" : ""}" data-task="${t.id}">
          <span class="status-icon ${t.status}">${t.status === "success" ? icon("check") : t.status === "running" ? "" : icon("x")}</span>
          <div><div class="task-title">${esc(t.title)}</div><div class="task-time">${timeAgo(t.started)}</div></div>
        </li>`).join("")
    : `<li class="empty-tasks">Commands you run show up here with their live output.</li>`;
  renderTaskOutput();
}

function renderTaskOutput() {
  const task = state.tasks.get(state.activeTask);
  const out = $("#task-output");
  const header = $("#task-output-header");
  if (!task) {
    header.innerHTML = "";
    out.textContent = "";
    return;
  }
  const label = { running: "Running…", success: "Completed", error: `Failed (exit ${task.code})`, cancelled: "Cancelled" }[task.status];
  header.innerHTML = `<b>${esc(task.title)}</b><span>· ${label}</span>
    ${task.status === "running" ? `<button class="btn sm" data-cancel="${task.id}">${icon("stop")}Cancel</button>` : ""}`;
  const stick = out.scrollHeight - out.scrollTop - out.clientHeight < 40;
  out.textContent = state.output.get(task.id) || (task.status === "running" ? "Waiting for output…" : "(no output)");
  if (stick) out.scrollTop = out.scrollHeight;
}

function openActivity() {
  $("#activity").classList.add("open");
  $("#activity").setAttribute("aria-hidden", "false");
  renderTasks();
  const out = $("#task-output");
  out.scrollTop = out.scrollHeight;
}

function closeActivity() {
  $("#activity").classList.remove("open");
  $("#activity").setAttribute("aria-hidden", "true");
}

/* ── services ───────────────────────────────────────────────────────────── */
const SERVICE_ICONS = { Nginx: "globe", Database: "database", Redis: "zap", Supervisor: "layers" };

async function refreshServices() {
  try {
    state.services = await LD.call("services");
  } catch { return; }
  renderServices();
}

function statusDot(status) {
  return `<span class="dot ${status === "active" ? "on" : status === "failed" ? "fail" : "off"}"></span>`;
}

function renderServices() {
  const core = state.services.filter((s) => s.kind === "core");
  $("#mini-services").innerHTML = core.length
    ? core.map((s) => `<div class="mini-service"><b>${esc(s.label.replace(" FPM", ""))}</b>${statusDot(s.status)}</div>`).join("")
    : `<div class="mini-service">No services detected</div>`;

  $("#service-grid").innerHTML = state.services.map((s) => {
    const active = s.status === "active";
    return `
      <div class="card service-card">
        <div class="service-top">
          <div class="service-icon">${icon(SERVICE_ICONS[s.label] || "cpu")}</div>
          <div><div class="service-name">${esc(s.label)}</div><div class="service-desc">${esc(s.description)} · <code>${esc(s.unit)}</code></div></div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="service-status" style="margin-left:0">${statusDot(s.status)}${esc(s.status)}</div>
        </div>
        <div class="btn-row">
          ${active
            ? `<button class="btn sm" data-service="restart" data-unit="${esc(s.unit)}">${icon("refresh")}Restart</button>
               <button class="btn sm" data-service="stop" data-unit="${esc(s.unit)}">${icon("stop")}Stop</button>`
            : `<button class="btn sm primary" data-service="start" data-unit="${esc(s.unit)}">${icon("play")}Start</button>`}
        </div>
      </div>`;
  }).join("") || `<p class="muted">No supported services found. Install nginx, MySQL/MariaDB and PHP-FPM, or rerun install.sh.</p>`;

  const fpm = Object.fromEntries(state.services.filter((s) => /^php[0-9.]*-fpm$/.test(s.unit)).map((s) => [s.unit.replace(/^php|-fpm$/g, ""), s.status]));
  $("#php-list").innerHTML = state.phpVersions.map((v) => `
    <div class="php-item">
      <b>${esc(v)}</b>
      <small>${fpm[v] ? `${statusDot(fpm[v])} FPM ${esc(fpm[v])}` : "CLI only"}</small>
      ${v === defaultPhp() ? `<span class="chip php">default</span>` : ""}
    </div>`).join("");
}

/* ── settings ───────────────────────────────────────────────────────────── */
function renderSettings() {
  const form = $("#settings-form");
  form.elements.default_php.innerHTML = phpOptions(defaultPhp());
  form.elements.editor.innerHTML = `<option value="">System default</option>` +
    state.editors.map((e) => `<option value="${esc(e.bin)}">${esc(e.label)}</option>`).join("");
  for (const [key, value] of Object.entries(state.settings)) if (form.elements[key]) form.elements[key].value = value;
  form.elements.editor.value = state.prefs.editor || "";
  form.elements.theme.value = state.prefs.theme || "system";
  form.elements.close_to_tray.checked = !!state.prefs.close_to_tray;
  form.elements.autostart.checked = !!state.prefs.autostart;
  $("#tray-row").hidden = !state.tray;
}

async function saveSettings() {
  const form = $("#settings-form");
  const f = form.elements;
  if (!f.LARAVEL_SITES_DIR.value.trim().startsWith("/") && !f.LARAVEL_SITES_DIR.value.trim().startsWith("~")) {
    f.LARAVEL_SITES_DIR.classList.add("invalid");
    toast("error", "Sites directory must be an absolute path");
    return;
  }
  f.LARAVEL_SITES_DIR.classList.remove("invalid");
  const settings = {};
  for (const key of ["LARAVEL_SITES_DIR", "DB_TYPE", "DB_HOST", "DB_PORT", "DB_USER", "DB_PASSWORD"]) settings[key] = f[key].value;
  const prefs = {
    default_php: f.default_php.value, editor: f.editor.value, theme: f.theme.value,
    close_to_tray: f.close_to_tray.checked, autostart: f.autostart.checked,
  };
  const saved = await api("save", { settings, prefs });
  state.settings = saved.settings;
  state.prefs = saved.prefs;
  applyTheme();
  renderSettings();
  refreshSites();
  toast("success", "Settings saved");
}

/* ── modals ─────────────────────────────────────────────────────────────── */
function openModal(html, onMount) {
  const root = $("#modal-root");
  root.innerHTML = html;
  root.hidden = false;
  onMount?.(root);
  setTimeout(() => $("input:not([type=hidden]), select", root)?.focus(), 30);
}

function closeModal() {
  $("#modal-root").hidden = true;
  $("#modal-root").innerHTML = "";
}

function confirmModal({ title, message, confirm = "Confirm", danger = false, requireText = "" }) {
  return new Promise((resolve) => {
    openModal(`
      <form class="modal sm" id="confirm-form">
        <div class="modal-header"><h2>${esc(title)}</h2></div>
        <div class="modal-body">
          <p style="margin:0">${message}</p>
          ${requireText ? `<label class="field"><span>Type <code>${esc(requireText)}</code> to confirm</span><input name="confirm" autocomplete="off" spellcheck="false"></label>` : ""}
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>Cancel</button>
          <button type="submit" class="btn ${danger ? "danger solid" : "primary"}" ${requireText ? "disabled" : ""}>${esc(confirm)}</button>
        </div>
      </form>`, (root) => {
      const form = $("#confirm-form", root);
      const submit = $("button[type=submit]", form);
      if (requireText) form.elements.confirm.addEventListener("input", (e) => (submit.disabled = e.target.value !== requireText));
      if (!requireText) setTimeout(() => submit.focus(), 40);
      form.addEventListener("submit", (e) => { e.preventDefault(); closeModal(); resolve(true); });
      $("[data-dismiss]", form).addEventListener("click", () => { closeModal(); resolve(false); });
    });
  });
}

function addSiteModal(mode = "new", prefill = {}) {
  openModal(`
    <form class="modal" id="add-form" novalidate>
      <div class="modal-header">
        <h2>Add a site</h2>
        <p>It will be served at its own local domain.</p>
      </div>
      <div class="modal-body">
        <div class="segmented">
          <button type="button" class="segment" data-mode="new">${icon("sparkles")}New Laravel app</button>
          <button type="button" class="segment" data-mode="link">${icon("folder")}Existing folder</button>
          <button type="button" class="segment" data-mode="clone">${icon("branch")}Git repository</button>
        </div>
        <label class="field" data-for="link"><span>Project folder</span>
          <span class="input-group" style="width:100%"><input name="path" placeholder="/home/you/code/my-app" spellcheck="false"><button type="button" class="btn" data-browse>Browse</button></span>
        </label>
        <label class="field" data-for="clone"><span>Repository URL</span><input name="repo" placeholder="https://github.com/acme/shop.git" spellcheck="false"></label>
        <label class="field"><span>Site name</span><input name="name" placeholder="my-app" spellcheck="false" maxlength="60"></label>
        <div class="grid-2">
          <label class="field"><span>PHP version</span><select name="php">${phpOptions(defaultPhp())}</select></label>
          <label class="field"><span>Domain <small>(optional)</small></span><input name="domain" placeholder="my-app.test" spellcheck="false"></label>
        </div>
        <label class="field" data-for="clone"><span>Access token <small>(private repos only)</small></span><input name="token" type="password" autocomplete="off"></label>
        <div class="domain-preview" id="domain-preview"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn" data-dismiss>Cancel</button>
        <button type="submit" class="btn primary" id="add-submit">Create</button>
      </div>
    </form>`, (root) => {
    const form = $("#add-form", root);
    const f = form.elements;
    let current = mode;
    let nameTouched = !!prefill.name;
    if (prefill.path) f.path.value = prefill.path;
    if (prefill.name) f.name.value = prefill.name;

    const update = () => {
      $$(".segment", form).forEach((b) => b.classList.toggle("active", b.dataset.mode === current));
      $$("[data-for]", form).forEach((el) => (el.hidden = el.dataset.for !== current));
      $("#add-submit").innerHTML = { new: `${icon("sparkles")}Create app`, link: `${icon("link")}Link site`, clone: `${icon("download")}Clone & link` }[current];
      const name = f.name.value.trim();
      const domain = f.domain.value.trim().toLowerCase() || (name ? `${name}.test` : "");
      f.domain.placeholder = name ? `${name}.test` : "my-app.test";
      $("#domain-preview").innerHTML = domain ? `Will be available at <b>http://${esc(domain)}</b>` : "";
    };

    const autoName = (source) => {
      if (nameTouched || !source) return;
      f.name.value = slugify(source.split("/").filter(Boolean).pop() || "");
      update();
    };

    $$(".segment", form).forEach((b) => b.addEventListener("click", () => { current = b.dataset.mode; update(); }));
    f.name.addEventListener("input", () => { nameTouched = true; f.name.value = f.name.value.toLowerCase().replace(/\s+/g, "-"); update(); });
    f.domain.addEventListener("input", update);
    f.path.addEventListener("input", () => autoName(f.path.value));
    f.repo.addEventListener("input", () => autoName(f.repo.value));
    $("[data-browse]", form).addEventListener("click", async () => {
      const path = await api("pick_folder", { title: "Choose a Laravel project", current: f.path.value || state.home });
      if (path) { f.path.value = path; autoName(path); }
    });
    $("[data-dismiss]", form).addEventListener("click", closeModal);

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      $$(".invalid", form).forEach((el) => el.classList.remove("invalid"));
      const params = { name: f.name.value.trim(), php: f.php.value, domain: f.domain.value.trim().toLowerCase() };
      const errors = [];
      if (!NEW_NAME_RE.test(params.name)) errors.push([f.name, "Use lowercase letters, numbers, dashes and dots."]);
      if (state.sites.some((s) => s.linked && s.name === params.name)) errors.push([f.name, `A site called “${params.name}” already exists.`]);
      if (params.domain && !DOMAIN_RE.test(params.domain)) errors.push([f.domain, "That doesn't look like a domain (e.g. shop.test)."]);
      if (current === "link") {
        params.path = f.path.value.trim();
        if (!params.path) errors.push([f.path, "Choose the project folder."]);
      }
      if (current === "clone") {
        params.repo = f.repo.value.trim();
        params.token = f.token.value;
        if (!/^(https?:\/\/|ssh:\/\/|git@)\S+$/.test(params.repo)) errors.push([f.repo, "Enter an https:// or git@ repository URL."]);
      }
      if (errors.length) {
        errors.forEach(([el]) => el.classList.add("invalid"));
        errors[0][0].focus();
        toast("error", errors[0][1]);
        return;
      }
      const task = await runAction(current === "new" ? "create" : current, params);
      if (task) closeModal();
    });

    update();
  });
}

/* ── events ─────────────────────────────────────────────────────────────── */
function siteFromEvent(target) {
  const row = target.closest("[data-site]");
  return row ? row.dataset.site : state.drawer.name;
}

document.addEventListener("click", async (e) => {
  const t = e.target;

  const nav = t.closest(".nav-item");
  if (nav) return setView(nav.dataset.view);

  const open = t.closest("[data-open]");
  if (open) { e.stopPropagation(); return openOn(open.dataset.open, siteFromEvent(open)); }

  const linkBtn = t.closest("[data-link-site]");
  if (linkBtn) {
    const site = siteByName(siteFromEvent(linkBtn));
    return addSiteModal("link", { path: site.path, name: slugify(site.name) });
  }

  const add = t.closest("[data-add]");
  if (add) return addSiteModal(add.dataset.add);

  const row = t.closest(".site-row[data-site]");
  if (row) return state.drawer.name === row.dataset.site ? closeDrawer() : openDrawer(row.dataset.site);

  if (t.closest("[data-close-drawer]") || t.id === "drawer-scrim") return closeDrawer();

  const tab = t.closest("[data-tab]");
  if (tab) { state.drawer.tab = tab.dataset.tab; return renderDrawer(); }

  const copy = t.closest("[data-copy]");
  if (copy) return copyText(copy.dataset.copy);

  const name = state.drawer.name;

  const action = t.closest("[data-action]");
  if (action) {
    const kind = action.dataset.action;
    if (kind === "delete") {
      const ok = await confirmModal({
        title: `Delete ${name}?`, danger: true, confirm: "Delete forever", requireText: name,
        message: `This permanently deletes <b>${esc(siteByName(name)?.display_path)}</b>, its database and its Nginx config.`,
      });
      if (!ok) return;
    }
    if (kind === "unlink") {
      const ok = await confirmModal({ title: `Unlink ${name}?`, confirm: "Unlink", message: "The site stops being served. Your files and database are kept and you can link it again later." });
      if (!ok) return;
    }
    if (kind === "delete" || kind === "unlink") closeDrawer();
    return runAction(kind, { name });
  }

  const worker = t.closest("[data-worker]");
  if (worker) return runAction("worker", { name, op: worker.dataset.worker }, { show: false });

  const git = t.closest("[data-git]");
  if (git) return runAction("git", { name, op: git.dataset.git });

  const artisan = t.closest("[data-artisan]");
  if (artisan) {
    if (artisan.dataset.confirm && !(await confirmModal({ title: `Run ${artisan.dataset.artisan}?`, message: esc(artisan.dataset.confirm), confirm: "Run", danger: true }))) return;
    return runAction("artisan", { name, args: artisan.dataset.artisan });
  }

  const composer = t.closest("[data-composer]");
  if (composer) return runAction("composer", { name, args: composer.dataset.composer });

  const log = t.closest("[data-log]");
  if (log) {
    if (log.dataset.log === "clear") await api("clear_log", { name });
    return loadLog(true);
  }

  const service = t.closest("[data-service]");
  if (service) return runAction("service", { unit: service.dataset.unit, op: service.dataset.service }, { show: false });

  const services = t.closest("[data-services]");
  if (services) return runAction("services", { op: services.dataset.services });

  const task = t.closest("[data-task]");
  if (task) { state.activeTask = task.dataset.task; renderTasks(); const out = $("#task-output"); out.scrollTop = out.scrollHeight; return; }

  const cancel = t.closest("[data-cancel]");
  if (cancel) return api("cancel", { id: cancel.dataset.cancel });

  const pick = t.closest("[data-pick]");
  if (pick) {
    const input = $("#settings-form").elements[pick.dataset.pick];
    const path = await api("pick_folder", { title: "Choose your sites directory", current: input.value });
    if (path) input.value = path;
  }
});

document.addEventListener("submit", (e) => {
  const form = e.target;
  if (form.matches("[data-php-form]")) {
    e.preventDefault();
    runAction("repair", { name: state.drawer.name, php: form.elements.php.value });
  }
  if (form.matches("[data-artisan-form]")) {
    e.preventDefault();
    const args = form.elements.args.value.trim().replace(/^(php\s+)?artisan\s+/, "");
    if (!args) return;
    runAction("artisan", { name: state.drawer.name, args });
    form.elements.args.value = "";
  }
  if (form.id === "settings-form") { e.preventDefault(); saveSettings(); }
});

$("#site-search").addEventListener("input", (e) => { state.filter = e.target.value; renderSites(); });
$("#add-site").addEventListener("click", () => addSiteModal("new"));
$("#refresh-sites").addEventListener("click", () => { refreshSites(); refreshServices(); });
$("#activity-toggle").addEventListener("click", () => ($("#activity").classList.contains("open") ? closeActivity() : openActivity()));
$("#activity-close").addEventListener("click", closeActivity);
$("#save-settings").addEventListener("click", saveSettings);

document.addEventListener("keydown", (e) => {
  const ctrl = e.ctrlKey || e.metaKey;
  if (e.key === "Escape") {
    if (!$("#modal-root").hidden) return closeModal();
    if ($("#activity").classList.contains("open")) return closeActivity();
    if ($("#site-drawer").classList.contains("open")) return closeDrawer();
  }
  if (!$("#modal-root").hidden) return;
  if (ctrl && e.key.toLowerCase() === "n") { e.preventDefault(); addSiteModal("new"); }
  if (ctrl && e.key.toLowerCase() === "f") { e.preventDefault(); setView("sites"); $("#site-search").focus(); }
  if (ctrl && e.key.toLowerCase() === "r") { e.preventDefault(); refreshSites(); refreshServices(); }
  if (ctrl && e.key === "`") { e.preventDefault(); $("#activity").classList.contains("open") ? closeActivity() : openActivity(); }
  if (ctrl && ["1", "2", "3", "4"].includes(e.key)) { e.preventDefault(); setView(["sites", "servers", "services", "settings"][+e.key - 1]); }
});

/* ── boot ───────────────────────────────────────────────────────────────── */
async function boot() {
  $$("[data-icon]").forEach((el) => (el.outerHTML = icon(el.dataset.icon)));
  renderSites();
  try {
    const init = await LD.call("init");
    Object.assign(state, {
      home: init.home, settings: init.settings, prefs: init.prefs, editors: init.editors,
      phpVersions: init.php_versions, tray: init.tray, sites: init.sites, services: init.services, loaded: true,
    });
    init.tasks.forEach((t) => onTaskEvent(t, false));
    $("#version").textContent = init.version ? `v${init.version}` : "";
  } catch (err) {
    state.loaded = true;
    toast("error", "Couldn't load", err.message);
  }
  applyTheme();
  renderSites();
  renderServices();
  renderTasks();

  setInterval(() => { if (document.visibilityState === "visible") refreshServices(); }, 10000);
  setInterval(() => { if (document.visibilityState === "visible" && !$("#activity").classList.contains("open")) renderTasks(); }, 30000);
}

/* ── demo backend: lets you open ui/web/index.html in a browser to work on the design ── */
const Demo = {
  sites: [
    { name: "shop", path: "/home/you/Sites/shop", display_path: "~/Sites/shop", domain: "shop.test", url: "http://shop.test", linked: true, exists: true, php: "8.4", branch: "main", worker: true },
    { name: "blog", path: "/home/you/Sites/blog", display_path: "~/Sites/blog", domain: "blog.test", url: "http://blog.test", linked: true, exists: true, php: "8.3", branch: "feature/comments", worker: false },
    { name: "crm-api", path: "/home/you/code/crm/api", display_path: "~/code/crm/api", domain: "api.crm.test", url: "http://api.crm.test", linked: true, exists: true, php: "8.4", branch: "", worker: false },
    { name: "playground", path: "/home/you/Sites/playground", display_path: "~/Sites/playground", domain: "playground.test", url: "http://playground.test", linked: false, exists: true, php: "", branch: "", worker: false },
  ],
  services: [
    { unit: "nginx", label: "Nginx", description: "Web server", kind: "core", status: "active" },
    { unit: "mariadb", label: "Database", description: "MySQL / MariaDB", kind: "core", status: "active" },
    { unit: "php8.4-fpm", label: "PHP 8.4 FPM", description: "PHP FastCGI", kind: "core", status: "active" },
    { unit: "redis-server", label: "Redis", description: "Cache & queues", kind: "extra", status: "inactive" },
    { unit: "supervisor", label: "Supervisor", description: "Queue workers", kind: "extra", status: "active" },
  ],
  handle(id, method, params) {
    const ok = (data) => setTimeout(() => LD.resolve(id, { ok: true, data }), 120);
    const site = this.sites.find((s) => s.name === params.name);
    switch (method) {
      case "init": return ok({ version: "1.1.0-demo", home: "/home/you", settings: { LARAVEL_SITES_DIR: "/home/you/Sites", DB_TYPE: "mysql", DB_HOST: "127.0.0.1", DB_PORT: "3306", DB_USER: "root", DB_PASSWORD: "" }, prefs: { theme: "system", close_to_tray: true, editor: "code", default_php: "8.4", autostart: false }, php_versions: ["8.3", "8.4"], editors: [{ bin: "code", label: "VS Code" }], tray: true, sites: this.sites, services: this.services, tasks: [] });
      case "sites": return ok(this.sites);
      case "services": return ok(this.services);
      case "site": return ok({ ...site, laravel: "12.3.0", worker_configured: site.name === "shop", has_env: true, git: site.branch ? { branch: site.branch, upstream: true, ahead: 1, behind: 2, changes: 3 } : null });
      case "log": return ok({ exists: true, text: "[2026-10-22 10:01:12] local.INFO: Order 1042 created\n[2026-10-22 10:02:40] local.WARNING: Slow query (1.2s)\n[2026-10-22 10:03:05] local.ERROR: Call to undefined method App\\Models\\Order::total()" });
      case "run": {
        const task = { id: String(Date.now()), title: `${params.action} ${params.params.name || params.params.unit || ""}`.trim(), status: "running", started: Date.now() / 1000 };
        ok(task);
        setTimeout(() => LD.onEvent({ type: "task", task }), 150);
        ["Creating project...\n", "Installing dependencies (lock file)\n", "  - Installing laravel/framework (v12.3.0)\n", "Configuring Nginx...\n", "Project Ready\n"].forEach((line, i) =>
          setTimeout(() => LD.onEvent({ type: "output", id: task.id, text: line }), 400 + i * 350));
        setTimeout(() => LD.onEvent({ type: "task", task: { ...task, status: "success", code: 0 }, done: true }), 2400);
        return;
      }
      case "save": return ok({ settings: params.settings, prefs: params.prefs });
      case "pick_folder": return ok("/home/you/code/new-app");
      default: return ok(true);
    }
  },
};

boot();
