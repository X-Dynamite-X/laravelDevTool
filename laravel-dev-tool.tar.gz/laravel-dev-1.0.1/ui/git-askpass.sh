#!/usr/bin/env bash

set -euo pipefail

PROMPT_TEXT="${1:-Authentication is required}"
TITLE="${LARAVEL_DEV_GIT_TITLE:-Laravel Dev - Git Authentication}"
DEFAULT_RUNTIME_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev/runtime"
RUNTIME_DIR="${LARAVEL_DEV_RUNTIME_DIR:-$DEFAULT_RUNTIME_DIR}"
TOKEN_FILE="${LARAVEL_DEV_GIT_TOKEN_FILE:-$RUNTIME_DIR/git-token}"
USERNAME="${LARAVEL_DEV_GIT_USERNAME:-x-access-token}"
TTL="${LARAVEL_DEV_GIT_TOKEN_TTL:-900}"

if ! mkdir -p "$RUNTIME_DIR" 2>/dev/null; then
  RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/laravel-dev-${UID:-$(id -u)}}"
  mkdir -p "$RUNTIME_DIR"
fi
chmod 700 "$RUNTIME_DIR" 2>/dev/null || true
TOKEN_FILE="${LARAVEL_DEV_GIT_TOKEN_FILE:-$RUNTIME_DIR/git-token}"

read_cached_token() {
  local expires_at="" token=""

  [[ -f "$TOKEN_FILE" ]] || return 1
  IFS= read -r expires_at <"$TOKEN_FILE" || true
  token="$(sed -n '2p' "$TOKEN_FILE" 2>/dev/null || true)"

  if [[ -z "$expires_at" || -z "$token" || "$expires_at" -le "$(date +%s)" ]]; then
    rm -f "$TOKEN_FILE"
    return 1
  fi

  printf '%s' "$token"
}

write_cached_token() {
  local token="$1"
  {
    printf '%s\n' "$(( $(date +%s) + TTL ))"
    printf '%s\n' "$token"
  } >"$TOKEN_FILE"
  chmod 600 "$TOKEN_FILE" 2>/dev/null || true
}

prompt_for_token() {
  local message="Enter your Git access token to continue this remote operation.

The token is stored only for this Laravel Dev session."

  if command -v zenity >/dev/null 2>&1; then
    zenity --password --title="$TITLE" --text="$message"
    return $?
  fi

  if command -v kdialog >/dev/null 2>&1; then
    kdialog --title "$TITLE" --password "$message"
    return $?
  fi

  if [[ -t 0 ]]; then
    printf 'Git token: ' >&2
    stty -echo
    IFS= read -r token
    stty echo
    printf '\n' >&2
    printf '%s' "$token"
    return 0
  fi

  return 1
}

if [[ "$PROMPT_TEXT" == *"Username"* ]]; then
  printf '%s' "$USERNAME"
  exit 0
fi

token="$(read_cached_token || true)"
if [[ -n "$token" ]]; then
  printf '%s' "$token"
  exit 0
fi

token="$(prompt_for_token || true)"
if [[ -z "$token" ]]; then
  echo "Git token prompt cancelled." >&2
  exit 1
fi

write_cached_token "$token"
printf '%s' "$token"
