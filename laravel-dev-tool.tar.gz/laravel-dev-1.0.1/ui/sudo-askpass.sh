#!/usr/bin/env bash

set -euo pipefail

PROMPT_TEXT="${1:-Authentication is required}"
TITLE="Laravel Dev - System Authentication"
MESSAGE="Enter your system password to continue privileged actions.

This password is used by sudo for your current user."

if command -v zenity >/dev/null 2>&1; then
  exec zenity --password --title="$TITLE" --text="$MESSAGE"
fi

if command -v kdialog >/dev/null 2>&1; then
  exec kdialog --title "$TITLE" --password "$MESSAGE"
fi

if command -v ssh-askpass >/dev/null 2>&1; then
  exec ssh-askpass "$PROMPT_TEXT"
fi

echo "No GUI askpass helper found (zenity/kdialog/ssh-askpass)." >&2
exit 1
