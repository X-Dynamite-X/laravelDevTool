#!/usr/bin/env bash
# SSH_ASKPASS helper for the desktop app. ssh passes the prompt as $1: a
# password / key passphrase request, or a host-key confirmation ("yes/no").

PROMPT="${1:-Password:}"
TITLE="Laravel Dev - SSH"

if [[ "$PROMPT" == *"(yes/no"* ]]; then
  if command -v zenity >/dev/null 2>&1; then
    zenity --question --title="$TITLE" --width=520 --ok-label="Trust and connect" --cancel-label="Cancel" \
      --text="$PROMPT" >/dev/null 2>&1 && echo yes || echo no
  elif command -v kdialog >/dev/null 2>&1; then
    kdialog --title "$TITLE" --yesno "$PROMPT" >/dev/null 2>&1 && echo yes || echo no
  else
    echo no
  fi
  exit 0
fi

if command -v zenity >/dev/null 2>&1; then
  exec zenity --entry --hide-text --title="$TITLE" --width=420 --text="$PROMPT"
fi
if command -v kdialog >/dev/null 2>&1; then
  exec kdialog --title "$TITLE" --password "$PROMPT"
fi
if command -v ssh-askpass >/dev/null 2>&1; then
  exec ssh-askpass "$PROMPT"
fi

echo "No GUI prompt available (install zenity)." >&2
exit 1
