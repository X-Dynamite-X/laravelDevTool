#!/usr/bin/env bash

set -euo pipefail

sudo rm -rf /opt/laravel-dev
sudo rm -f /usr/local/bin/laravel-dev
sudo rm -f /usr/share/applications/laravel-dev.desktop

echo "Laravel Dev removed"
