"""Linux window: GTK + WebKitGTK, with a tray icon when AppIndicator is available.

The interface talks to Backend through a WebKit script-message bridge, so
there is no HTTP server and no open port.
"""

import json
import os
import re
import sys
import threading
import urllib.parse
from pathlib import Path

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
try:
    gi.require_version("WebKit2", "4.1")
except ValueError:
    gi.require_version("WebKit2", "4.0")
from gi.repository import Gdk, Gio, GLib, Gtk, WebKit2  # noqa: E402

try:
    gi.require_version("AyatanaAppIndicator3", "0.1")
    from gi.repository import AyatanaAppIndicator3 as AppIndicator
except (ImportError, ValueError):
    try:
        gi.require_version("AppIndicator3", "0.1")
        from gi.repository import AppIndicator3 as AppIndicator
    except (ImportError, ValueError):
        AppIndicator = None

import osutil  # noqa: E402
import sites  # noqa: E402
from backend import Backend  # noqa: E402
from sites import BASE_DIR, UI_DIR  # noqa: E402

APP_ID = "dev.laravel.LaravelDev"
DIALOG_ACTIONS = {"folder": Gtk.FileChooserAction.SELECT_FOLDER, "open": Gtk.FileChooserAction.OPEN,
                  "save": Gtk.FileChooserAction.SAVE}
GH_RESERVED_OWNERS = {
    "about", "apps", "codespaces", "collections", "copilot", "discussions", "enterprise",
    "events", "explore", "features", "gist", "import", "issues", "join", "login", "logout",
    "marketplace", "new", "notifications", "organizations", "orgs", "pricing", "pulls",
    "search", "security", "sessions", "settings", "site", "sponsors", "stars", "topics",
    "trending", "users", "watching",
}


def _is_github_web_host(host: str) -> bool:
    h = (host or "").lower().split(":")[0]
    return h in ("github.com", "www.github.com", "gist.github.com") or h.endswith(".github.com")


def _is_cloudflare_web_host(host: str) -> bool:
    h = (host or "").lower().split(":")[0]
    return h in (
        "dash.cloudflare.com",
        "one.dash.cloudflare.com",
        "workers.cloudflare.com",
        "pages.cloudflare.com",
        "cloudflare.com",
        "www.cloudflare.com",
    ) or h.endswith((".cloudflare.com", ".cloudflareaccess.com", ".cloudflareclient.com"))


def _extract_gh_repo(uri: str) -> str:
    try:
        parsed = urllib.parse.urlparse(uri or "")
    except Exception:
        return ""
    host = (parsed.hostname or "").lower()
    if host not in ("github.com", "www.github.com"):
        return ""
    parts = [p for p in parsed.path.split("/") if p]
    if len(parts) < 2:
        return ""
    owner, repo = parts[0], parts[1]
    if owner.lower() in GH_RESERVED_OWNERS:
        return ""
    if repo.endswith(".git"):
        repo = repo[:-4]
    if not re.match(r"^[A-Za-z0-9._-]+$", owner) or not re.match(r"^[A-Za-z0-9._-]+$", repo):
        return ""
    return f"{owner}/{repo}"


class GtkShell(Gtk.Application):
    def __init__(self, start_hidden=False, initial_route=""):
        super().__init__(application_id=APP_ID)
        self.start_hidden = start_hidden
        self.initial_route = initial_route or ""
        self.window = None
        self.root_stack = None
        self.webview = None
        self._web_panes = {}
        self.gh_current_repo = ""
        self.indicator = None
        self.tray_sites_menu = None
        self.dialogs = set()
        self.has_tray = AppIndicator is not None
        self.backend = Backend(self)

    # shell interface used by Backend
    def post(self, fn, *args):
        def _call():
            try:
                fn(*args)
            except Exception as e:
                print("Error in post callback:", e)
            return False
        GLib.idle_add(_call)

    def eval_js(self, script):
        if self.webview is None:
            return
        def _exec():
            if self.webview is None:
                return False
            def on_js_done(view, result, *u):
                try:
                    view.run_javascript_finish(result)
                except Exception as e:
                    print(f"[SHELL_GTK] JS execution error: {e}")
            try:
                self.webview.run_javascript(script, None, on_js_done)
            except Exception as e:
                print(f"[SHELL_GTK] eval_js run_javascript error: {e}")
            return False
        GLib.idle_add(_exec)

    def is_active(self):
        return bool(self.window and self.window.is_active())

    def notify(self, title, body, task_id=""):
        try:
            note = Gio.Notification.new(title)
            note.set_body(body)
            self.send_notification(task_id or "laravel-dev", note)
        except Exception:
            osutil.send_desktop_notification(title, body)

    def choose(self, kind, title, done, start=None, multiple=False, name=None, accept="Select"):
        """Open a native file dialog without blocking; done(paths) gets a list (empty if cancelled)."""
        action = DIALOG_ACTIONS[kind]
        dialog = Gtk.FileChooserNative.new(title, self.window, action, accept, "Cancel")
        dialog.set_modal(True)
        dialog.set_select_multiple(multiple)
        if action == Gtk.FileChooserAction.SAVE:
            dialog.set_do_overwrite_confirmation(True)
            if name:
                dialog.set_current_name(name)
        if start and os.path.isdir(start):
            dialog.set_current_folder(start)
            if os.path.basename(start.rstrip("/")).startswith("."):
                dialog.set_show_hidden(True)

        def on_response(chooser, response):
            paths = list(chooser.get_filenames()) if response == Gtk.ResponseType.ACCEPT else []
            self.dialogs.discard(chooser)
            GLib.idle_add(chooser.destroy)
            done(paths)

        # File dialogs answer later, from their "response" signal: a blocking
        # dialog.run() inside the WebKit message callback loses the chosen path.
        def show():
            self.dialogs.add(dialog)  # keep a reference until it answers
            dialog.connect("response", on_response)
            dialog.show()
            return False

        GLib.idle_add(show)

    # lifecycle
    def do_startup(self):
        Gtk.Application.do_startup(self)
        GLib.set_application_name("Laravel Dev")
        GLib.set_prgname("laravel-dev")
        self.hold()  # keep running in the tray when the window is hidden
        nav_action = Gio.SimpleAction.new("navigate", GLib.VariantType.new("s"))
        nav_action.connect("activate", self._on_navigate_action)
        self.add_action(nav_action)

    def _on_navigate_action(self, _action, param):
        route = param.get_string() if param else ""
        if route:
            self.initial_route = route
        self.start_hidden = False
        self.do_activate()
        if route and self.webview is not None:
            self.eval_js(f"window.LD_navigateRoute && window.LD_navigateRoute({json.dumps(route)});")

    def do_activate(self):
        if self.window is None:
            self.build_window()
            self.build_tray()
            if self.start_hidden and self.indicator:
                return
        self.show_window()

    def show_window(self, *_):
        self.window.show_all()
        self.window.present()

    def quit_app(self, *_):
        self.backend.shutdown()
        self.release()
        self.quit()

    def build_window(self):
        self.window = Gtk.ApplicationWindow(application=self, title="Laravel Dev")
        self.window.set_default_size(1240, 780)
        self.window.set_size_request(860, 560)
        for icon in (BASE_DIR / "assets" / "laravel-dev.png", BASE_DIR / "assets" / "laravel-dev.svg"):
            if icon.is_file():
                try:
                    self.window.set_icon_from_file(str(icon))
                    break
                except GLib.Error:
                    pass
        self.window.connect("delete-event", self.on_close)

        # Memory: a local single-page UI needs no page cache, no disk cache and
        # no back/forward cache; this keeps WebKit's footprint small.
        context = WebKit2.WebContext.get_default()
        context.set_cache_model(WebKit2.CacheModel.DOCUMENT_VIEWER)

        content = WebKit2.UserContentManager()
        content.register_script_message_handler("ld")
        content.connect("script-message-received::ld", self.on_message)
        self.webview = WebKit2.WebView.new_with_user_content_manager(content)
        settings = self.webview.get_settings()
        debug = bool(os.environ.get("LARAVEL_DEV_DEBUG"))
        settings.set_enable_developer_extras(debug)
        settings.set_enable_write_console_messages_to_stdout(debug)
        settings.set_enable_page_cache(False)
        for setter in ("set_enable_webgl", "set_enable_media", "set_enable_webaudio", "set_enable_media_stream"):
            if hasattr(settings, setter):
                getattr(settings, setter)(False)
        self.webview.connect("decide-policy", self.on_decide_policy)
        self.webview.connect("context-menu", lambda *_: not debug)
        bg = Gdk.RGBA()
        bg.parse("#f6f6f7")
        self.webview.set_background_color(bg)
        base_uri = (UI_DIR / "web" / "index.html").as_uri()
        if self.initial_route:
            base_uri = f"{base_uri}#{self.initial_route}"
        self.webview.load_uri(base_uri)

        self.root_stack = Gtk.Stack()
        self.root_stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.root_stack.set_transition_duration(150)
        self.root_stack.add_named(self.webview, "main")

        for pane_key, stack_name in (("github", "github_web"), ("cloudflare", "cf_web")):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            self._web_panes[pane_key] = {"container": box, "stack_name": stack_name}
            self.root_stack.add_named(box, stack_name)
        self.root_stack.set_visible_child_name("main")

        self.window.add(self.root_stack)

    def _cf_dash_url(self, section: str = "") -> str:
        if section == "zero_trust":
            return "https://one.dash.cloudflare.com"
        if section == "tokens":
            return "https://dash.cloudflare.com/profile/api-tokens"
        acc_id = ""
        try:
            acc_id = self.backend.cf.get_active_account_id() or ""
        except Exception:
            acc_id = ""
        if acc_id and not acc_id.startswith("acc_") and len(acc_id) >= 16:
            base = f"https://dash.cloudflare.com/{acc_id}"
            return f"{base}/{section.lstrip('/')}" if section else base
        return f"https://dash.cloudflare.com/{section.lstrip('/')}" if section else "https://dash.cloudflare.com"

    def _ensure_web_pane(self, key: str):
        pane = self._web_panes.get(key)
        if not pane or pane.get("webview") is not None or pane.get("container") is None:
            return pane

        is_gh = key == "github"
        home_url = "https://github.com" if is_gh else self._cf_dash_url()
        pane["home_url"] = home_url
        pane["current_url"] = pane.get("current_url") or home_url

        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        toolbar.set_margin_start(8)
        toolbar.set_margin_end(8)
        toolbar.set_margin_top(6)
        toolbar.set_margin_bottom(6)

        back_to_app_btn = Gtk.Button(label="← Native Hub")
        back_to_app_btn.set_tooltip_text(
            "Return to Laravel Dev Native GitHub Hub" if is_gh else "Return to Laravel Dev Native Cloudflare Hub"
        )
        back_to_app_btn.connect("clicked", lambda *_: self._close_web_pane(key))
        toolbar.pack_start(back_to_app_btn, False, False, 0)

        back_btn = Gtk.Button(label="◀")
        back_btn.set_tooltip_text("Back")
        back_btn.set_sensitive(False)
        back_btn.connect("clicked", lambda *_: pane.get("webview") and pane["webview"].go_back())
        toolbar.pack_start(back_btn, False, False, 0)

        fwd_btn = Gtk.Button(label="▶")
        fwd_btn.set_tooltip_text("Forward")
        fwd_btn.set_sensitive(False)
        fwd_btn.connect("clicked", lambda *_: pane.get("webview") and pane["webview"].go_forward())
        toolbar.pack_start(fwd_btn, False, False, 0)

        reload_btn = Gtk.Button(label="↻")
        reload_btn.set_tooltip_text("Reload Page")
        reload_btn.connect("clicked", lambda *_: pane.get("webview") and pane["webview"].reload())
        toolbar.pack_start(reload_btn, False, False, 0)

        home_btn = Gtk.Button(label="GitHub Home" if is_gh else "Cloudflare Home")
        home_btn.connect(
            "clicked",
            lambda *_: pane.get("webview") and pane["webview"].load_uri(
                "https://github.com" if is_gh else self._cf_dash_url()
            ),
        )
        toolbar.pack_start(home_btn, False, False, 0)

        url_entry = Gtk.Entry()
        url_entry.set_text(pane["current_url"])
        url_entry.set_hexpand(True)
        url_entry.connect("activate", lambda entry: self._on_web_url_activate(key, entry))
        toolbar.pack_start(url_entry, True, True, 0)

        extras = {}
        if is_gh:
            repo_btn = Gtk.Button(label="Inspect in Native Hub")
            repo_btn.set_tooltip_text("Open this repository inside the Native GitHub Workspace")
            repo_btn.connect("clicked", self._on_gh_open_in_native)
            repo_btn.set_no_show_all(True)
            toolbar.pack_start(repo_btn, False, False, 0)

            clone_btn = Gtk.Button(label="Clone Repo")
            clone_btn.set_tooltip_text("Clone this repository into ~/Sites")
            clone_btn.connect("clicked", self._on_gh_clone_from_browser)
            clone_btn.set_no_show_all(True)
            toolbar.pack_start(clone_btn, False, False, 0)
            extras["repo_btn"] = repo_btn
            extras["clone_btn"] = clone_btn
        else:
            for lbl, sec, tip in (
                ("Workers", "workers-and-pages", "Jump to Workers & Pages"),
                ("R2", "r2/overview", "Jump to R2 Object Storage"),
                ("Zero Trust", "zero_trust", "Jump to Cloudflare Zero Trust Dashboard"),
                ("Tokens", "tokens", "Manage Cloudflare API Tokens"),
            ):
                qbtn = Gtk.Button(label=lbl)
                qbtn.set_tooltip_text(tip)
                qbtn.connect("clicked", lambda _b, s=sec: pane.get("webview") and pane["webview"].load_uri(self._cf_dash_url(s)))
                toolbar.pack_start(qbtn, False, False, 0)

        ext_btn = Gtk.Button(label="↗")
        ext_btn.set_tooltip_text("Open in External System Browser")
        ext_btn.connect("clicked", lambda *_: osutil.open_path(pane.get("current_url") or home_url))
        toolbar.pack_start(ext_btn, False, False, 0)

        profile_dir_name = "webkit-github" if is_gh else "webkit-cloudflare"
        data_dir = Path.home() / ".config" / "laravel-dev" / profile_dir_name
        try:
            data_dir.mkdir(parents=True, exist_ok=True)
            # Holds logged-in session cookies: keep it private to the user.
            try:
                os.chmod(data_dir, 0o700)
            except OSError:
                pass
            mgr = WebKit2.WebsiteDataManager(
                base_data_directory=str(data_dir / "data"),
                base_cache_directory=str(data_dir / "cache"),
            )
            ctx = WebKit2.WebContext.new_with_website_data_manager(mgr)
            ctx.set_cache_model(WebKit2.CacheModel.WEB_BROWSER)
            cookie_mgr = ctx.get_cookie_manager()
            cookie_mgr.set_persistent_storage(
                str(data_dir / "cookies.sqlite"),
                WebKit2.CookiePersistentStorage.SQLITE,
            )
            view = WebKit2.WebView.new_with_context(ctx)
        except Exception:
            view = WebKit2.WebView()

        w_settings = view.get_settings()
        debug = bool(os.environ.get("LARAVEL_DEV_DEBUG"))
        w_settings.set_enable_developer_extras(debug)
        if hasattr(w_settings, "set_enable_javascript"):
            w_settings.set_enable_javascript(True)
        if hasattr(w_settings, "set_enable_html5_local_storage"):
            w_settings.set_enable_html5_local_storage(True)

        view.connect("notify::uri", lambda *_: self._update_web_toolbar_state(key))
        view.connect("notify::estimated-load-progress", lambda v, _p: self._on_web_progress(key, v))
        view.connect("load-changed", lambda *_: self._update_web_toolbar_state(key))
        view.connect("decide-policy", lambda _v, d, kind: self._on_web_decide_policy(key, d, kind))

        pane.update({
            "webview": view,
            "url_entry": url_entry,
            "back_btn": back_btn,
            "fwd_btn": fwd_btn,
            "extras": extras,
        })

        container = pane["container"]
        container.pack_start(toolbar, False, False, 0)
        container.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 0)
        container.pack_start(view, True, True, 0)
        container.show_all()
        self._update_web_toolbar_state(key)
        return pane

    def _on_web_url_activate(self, key: str, entry):
        pane = self._web_panes.get(key)
        if not pane or pane.get("webview") is None:
            return
        raw = (entry.get_text() or "").strip()
        if not raw:
            return
        if not raw.startswith(("http://", "https://")):
            if key == "github":
                if raw.startswith("github.com"):
                    raw = f"https://{raw}"
                elif "/" in raw or re.match(r"^[A-Za-z0-9_.-]+$", raw):
                    raw = f"https://github.com/{raw.lstrip('/')}"
                else:
                    raw = f"https://github.com/search?q={urllib.parse.quote(raw)}"
            else:
                if "cloudflare.com" in raw or "cloudflareaccess.com" in raw:
                    raw = f"https://{raw}"
                else:
                    raw = self._cf_dash_url(raw.lstrip("/"))
        pane["webview"].load_uri(raw)

    def _on_web_progress(self, key: str, view):
        pane = self._web_panes.get(key)
        entry = pane.get("url_entry") if pane else None
        if entry is None:
            return
        prog = view.get_estimated_load_progress()
        entry.set_progress_fraction(0.0 if prog >= 0.99 else prog)

    def _update_web_toolbar_state(self, key: str):
        pane = self._web_panes.get(key)
        view = pane.get("webview") if pane else None
        if view is None:
            return
        uri = view.get_uri() or pane.get("current_url") or pane.get("home_url", "")
        pane["current_url"] = uri
        entry = pane.get("url_entry")
        if entry is not None and not entry.has_focus():
            entry.set_text(uri)
        if pane.get("back_btn") is not None:
            pane["back_btn"].set_sensitive(view.can_go_back())
        if pane.get("fwd_btn") is not None:
            pane["fwd_btn"].set_sensitive(view.can_go_forward())
        if key == "github":
            self.gh_current_repo = _extract_gh_repo(uri)
            extras = pane.get("extras") or {}
            repo_btn = extras.get("repo_btn")
            clone_btn = extras.get("clone_btn")
            has_repo = bool(self.gh_current_repo)
            if repo_btn is not None:
                if has_repo:
                    repo_btn.set_label(f"Inspect {self.gh_current_repo}")
                    repo_btn.show()
                else:
                    repo_btn.hide()
            if clone_btn is not None:
                if has_repo:
                    clone_btn.show()
                else:
                    clone_btn.hide()

    def _on_gh_open_in_native(self, *_):
        cur = (self._web_panes.get("github") or {}).get("current_url", "")
        repo = self.gh_current_repo or _extract_gh_repo(cur)
        self.close_github_browser()
        if repo:
            self.eval_js(f"window.GitHub && window.GitHub.openRepoFromBrowser && window.GitHub.openRepoFromBrowser({json.dumps(repo)})")

    def _on_gh_clone_from_browser(self, *_):
        cur = (self._web_panes.get("github") or {}).get("current_url", "")
        repo = self.gh_current_repo or _extract_gh_repo(cur)
        self.close_github_browser()
        if repo:
            self.eval_js(f"window.GitHub && window.GitHub.cloneFromBrowser && window.GitHub.cloneFromBrowser({json.dumps(repo)})")

    def _on_web_decide_policy(self, key: str, decision, kind):
        if kind == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION:
            pane = self._web_panes.get(key)
            view = pane.get("webview") if pane else None
            uri = decision.get_navigation_action().get_request().get_uri() or ""
            if uri.startswith(("http://", "https://")) and view is not None:
                host = urllib.parse.urlparse(uri).hostname or ""
                if key == "github":
                    stay_in_view = _is_github_web_host(host) or host.endswith("githubusercontent.com")
                else:
                    stay_in_view = _is_cloudflare_web_host(host) or host in ("github.com", "accounts.google.com", "appleid.apple.com")
                if stay_in_view:
                    view.load_uri(uri)
                else:
                    osutil.open_path(uri)
            decision.ignore()
            return True
        return False

    def _open_web_pane(self, key: str, url: str, default_url: str):
        def _open():
            target = (url or default_url).strip()
            if not target.startswith(("http://", "https://")):
                target = default_url
            pane = self._ensure_web_pane(key)
            if pane is not None:
                pane["current_url"] = target
                if pane.get("webview") is not None:
                    pane["webview"].load_uri(target)
                if self.root_stack is not None:
                    self.root_stack.set_visible_child_name(pane["stack_name"])
            self.show_window()
            return False
        GLib.idle_add(_open)

    def _close_web_pane(self, _key=None):
        def _close():
            if self.root_stack is not None:
                self.root_stack.set_visible_child_name("main")
            return False
        GLib.idle_add(_close)

    def _nav_web_pane(self, key: str, action: str = "reload", url: str = ""):
        def _nav():
            pane = self._ensure_web_pane(key)
            view = pane.get("webview") if pane else None
            if view is None:
                return False
            if action == "back" and view.can_go_back():
                view.go_back()
            elif action == "forward" and view.can_go_forward():
                view.go_forward()
            elif action in ("load", "goto") and url:
                if url.startswith(("http://", "https://")):
                    view.load_uri(url)
            else:
                view.reload()
            return False
        GLib.idle_add(_nav)

    def _get_web_pane_status(self, key: str, extra: dict | None = None) -> dict:
        pane = self._web_panes.get(key) or {}
        stack_name = pane.get("stack_name", "")
        visible = self.root_stack.get_visible_child_name() == stack_name if (self.root_stack and stack_name) else False
        res = {
            "ok": True,
            "supported": True,
            "embedded": True,
            "active": visible,
            "url": pane.get("current_url", ""),
        }
        if extra:
            res.update(extra)
        return res

    def open_github_browser(self, url="https://github.com"):
        self._open_web_pane("github", url, "https://github.com")

    def close_github_browser(self):
        self._close_web_pane("github")

    def nav_github_browser(self, action="reload", url=""):
        self._nav_web_pane("github", action=action, url=url)

    def get_github_browser_status(self):
        return self._get_web_pane_status("github", {"repo": self.gh_current_repo})

    def open_cf_browser(self, url="https://dash.cloudflare.com"):
        self._open_web_pane("cloudflare", url, self._cf_dash_url())

    def close_cf_browser(self):
        self._close_web_pane("cloudflare")

    def nav_cf_browser(self, action="reload", url=""):
        self._nav_web_pane("cloudflare", action=action, url=url)

    def get_cf_browser_status(self):
        return self._get_web_pane_status("cloudflare")

    def on_close(self, *_):
        if self.indicator and self.backend.prefs.get("close_to_tray", True):
            self.window.hide()
            return True
        self.quit_app()
        return True

    def on_decide_policy(self, _view, decision, kind):
        if kind in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            uri = decision.get_navigation_action().get_request().get_uri() or ""
            if kind == WebKit2.PolicyDecisionType.NAVIGATION_ACTION and (
                uri.startswith("file://")
                or uri in ("about:blank", "about:srcdoc")
                or uri.startswith("data:text/html")
            ):
                return False
            if re.match(r"^(https?://|mailto:)", uri):
                parsed = urllib.parse.urlparse(uri)
                host = parsed.hostname or ""
                if uri.startswith(("http://", "https://")) and not uri.endswith("#external"):
                    if _is_github_web_host(host):
                        self.open_github_browser(uri)
                        decision.ignore()
                        return True
                    if _is_cloudflare_web_host(host):
                        self.open_cf_browser(uri)
                        decision.ignore()
                        return True
                clean_uri = uri[:-9] if uri.endswith("#external") else uri
                osutil.open_path(clean_uri)
            decision.ignore()
            return True
        return False

    def on_message(self, _manager, result):
        value = result.get_js_value() if hasattr(result, "get_js_value") else result
        self.backend.handle(value.to_string())

    # tray
    def build_tray(self):
        if AppIndicator is None:
            return
        icon = BASE_DIR / "assets" / "laravel-dev.png"
        self.indicator = AppIndicator.Indicator.new(
            "laravel-dev", str(icon) if icon.is_file() else "laravel-dev",
            AppIndicator.IndicatorCategory.APPLICATION_STATUS,
        )
        self.indicator.set_title("Laravel Dev")
        self.indicator.set_status(AppIndicator.IndicatorStatus.ACTIVE)

        menu = Gtk.Menu()

        def item(label, callback):
            entry = Gtk.MenuItem(label=label)
            entry.connect("activate", callback)
            menu.append(entry)
            return entry

        item("Open Laravel Dev", self.show_window)
        item("API Client (Postman)", lambda *_: self._on_navigate_action(None, GLib.Variant.new_string("page=api-client")))
        item("Database Manager", lambda *_: self._on_navigate_action(None, GLib.Variant.new_string("page=database")))
        menu.append(Gtk.SeparatorMenuItem())
        sites_item = Gtk.MenuItem(label="Sites")
        self.tray_sites_menu = Gtk.Menu()
        sites_item.set_submenu(self.tray_sites_menu)
        menu.append(sites_item)
        if sites.MANAGED:
            menu.append(Gtk.SeparatorMenuItem())
            item("Start services", lambda *_: self.backend.start_action("services", {"op": "start"}))
            item("Stop services", lambda *_: self.backend.start_action("services", {"op": "stop"}))
        menu.append(Gtk.SeparatorMenuItem())
        item("Quit", self.quit_app)
        menu.show_all()
        self.indicator.set_menu(menu)
        self.refresh_tray()

    def refresh_tray(self, site_list=None):
        if self.tray_sites_menu is None:
            return False
        if site_list is None:
            threading.Thread(target=lambda: GLib.idle_add(self.refresh_tray, sites.list_sites()), daemon=True).start()
            return False
        for child in self.tray_sites_menu.get_children():
            self.tray_sites_menu.remove(child)
        linked = [s for s in site_list if s["linked"] and s.get("url")]
        for site in linked:
            entry = Gtk.MenuItem(label=site["domain"])
            entry.connect("activate", lambda _w, url=site["url"]: osutil.open_path(url))
            self.tray_sites_menu.append(entry)
        if not linked:
            empty = Gtk.MenuItem(label="No sites yet")
            empty.set_sensitive(False)
            self.tray_sites_menu.append(empty)
        self.tray_sites_menu.show_all()
        return False


def run(start_hidden=False, initial_route=""):
    shell = GtkShell(start_hidden=start_hidden, initial_route=initial_route)
    try:
        shell.register(None)
    except GLib.Error:
        return shell.run([sys.argv[0]])
    if shell.get_is_remote():
        shell.activate()
        if initial_route:
            try:
                shell.activate_action("navigate", GLib.Variant.new_string(initial_route))
            except GLib.Error:
                pass
        conn = shell.get_dbus_connection()
        if conn is not None:
            try:
                conn.flush_sync(None)
            except GLib.Error:
                pass
        return 0
    return shell.run([sys.argv[0]])
