#!/usr/bin/env python3
"""Lightweight HTTP Basic Auth reverse proxy for local share/tunnel endpoints."""

import argparse
import base64
import hmac
import http.client
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


HOP_BY_HOP = frozenset({
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
})


def make_handler(upstream_host: str, upstream_port: int, expected_user: str, expected_pass: str, host_header: str = ""):
    expected_pair = f"{expected_user}:{expected_pass}".encode("utf-8")

    class AuthProxyHandler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, format, *args):  # noqa: A003
            return

        def _authorized(self) -> bool:
            header = self.headers.get("Authorization", "")
            if not header.startswith("Basic "):
                return False
            token = header[6:].strip()
            try:
                decoded = base64.b64decode(token, validate=True)
            except Exception:
                return False
            return hmac.compare_digest(decoded, expected_pair)

        def _send_unauthorized(self):
            body = b"Authentication required."
            self.send_response(401, "Unauthorized")
            self.send_header("WWW-Authenticate", 'Basic realm="Laravel Dev Tunnel"')
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(body)

        def _read_chunked(self) -> bytes:
            chunks = []
            while True:
                line = self.rfile.readline(65537)
                try:
                    size = int(line.split(b";", 1)[0].strip() or b"0", 16)
                except ValueError:
                    break
                if size <= 0:
                    # Consume optional trailers up to the terminating blank line.
                    while self.rfile.readline(65537) not in (b"\r\n", b"\n", b""):
                        pass
                    break
                chunks.append(self.rfile.read(size))
                self.rfile.readline(65537)  # CRLF after each chunk
            return b"".join(chunks)

        def _forward(self):
            if not self._authorized():
                self._send_unauthorized()
                return

            length_raw = self.headers.get("Content-Length")
            body = b""
            if length_raw:
                try:
                    length = max(0, int(length_raw))
                except ValueError:
                    length = 0
                if length:
                    body = self.rfile.read(length)
            elif "chunked" in self.headers.get("Transfer-Encoding", "").lower():
                body = self._read_chunked()

            headers = {}
            for k, v in self.headers.items():
                if k.lower() in HOP_BY_HOP or k.lower() == "authorization":
                    continue
                headers[k] = v
            if host_header:
                headers["Host"] = host_header
            headers.setdefault("X-Forwarded-For", self.client_address[0])
            headers["Connection"] = "close"

            conn = http.client.HTTPConnection(upstream_host, upstream_port, timeout=30)
            try:
                conn.request(self.command, self.path, body=body or None, headers=headers)
                resp = conn.getresponse()
                resp_body = resp.read()
                self.send_response(resp.status, resp.reason)
                for k, v in resp.getheaders():
                    lk = k.lower()
                    if lk in HOP_BY_HOP or lk == "content-length":
                        continue
                    self.send_header(k, v)
                self.send_header("Content-Length", str(len(resp_body)))
                self.send_header("Connection", "close")
                self.end_headers()
                if self.command != "HEAD" and resp_body:
                    self.wfile.write(resp_body)
            except Exception as exc:
                err_body = f"Upstream connection error: {exc}".encode("utf-8")
                self.send_response(502, "Bad Gateway")
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(err_body)))
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(err_body)
            finally:
                conn.close()

        def do_GET(self): self._forward()
        def do_HEAD(self): self._forward()
        def do_POST(self): self._forward()
        def do_PUT(self): self._forward()
        def do_PATCH(self): self._forward()
        def do_DELETE(self): self._forward()
        def do_OPTIONS(self): self._forward()

    return AuthProxyHandler


def main() -> int:
    parser = argparse.ArgumentParser(description="Basic-Auth local reverse proxy for Laravel Dev tunnels")
    parser.add_argument("--upstream-host", default="127.0.0.1")
    parser.add_argument("--upstream-port", type=int, required=True)
    parser.add_argument("--host-header", default="")
    parser.add_argument("--listen-port", type=int, default=0)
    parser.add_argument("--port-file", default="")
    parser.add_argument("--creds-file", required=True)
    args = parser.parse_args()

    creds_path = Path(args.creds_file)
    creds_raw = creds_path.read_text(encoding="utf-8").strip()
    if ":" not in creds_raw:
        print("Invalid credentials format (expected user:pass).", file=sys.stderr)
        return 1
    user, password = creds_raw.split(":", 1)

    handler_cls = make_handler(args.upstream_host, args.upstream_port, user, password, args.host_header)
    server = ThreadingHTTPServer(("127.0.0.1", args.listen_port), handler_cls)
    actual_port = server.server_address[1]
    if args.port_file:
        Path(args.port_file).write_text(str(actual_port), encoding="utf-8")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
