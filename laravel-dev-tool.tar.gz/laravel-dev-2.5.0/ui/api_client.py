"""Postman-compatible API Client, Collection Manager, HTTP Runner & Documentation Studio.

Standard library only (urllib, http.cookiejar, mimetypes, shlex, json, uuid).
Supports:
- Collections, nested folders, multi-tab requests, saved response examples
- Environments & {{variable}} interpolation (plus built-in $guid, $timestamp, etc.)
- Auth: None, Inherit, Bearer, Basic, API Key (Header/Query), Laravel Sanctum CSRF
- Body: none, raw (JSON/XML/Text/HTML), form-data (text & file upload), x-www-form-urlencoded, GraphQL
- Post-response assertions & JSON/header/cookie variable extraction
- Official Postman Collection v2.1.0 & Environment import/export
- OpenAPI 3.0 & cURL import
- Interactive HTML, Markdown, and OpenAPI 3.0.3 API documentation export
- Auto-generating Collections from Laravel application routes
"""
from __future__ import annotations

import base64
import datetime
import html as html_lib
import http.cookiejar
import json
import mimetypes
import os
import random
import re
import shlex
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any

import osutil


POSTMAN_V21_SCHEMA = "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
VALID_METHODS = ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS")
VAR_PATTERN = re.compile(r"\{\{\s*([^{}\s]+)\s*\}\}")
PATH_PARAM_PATTERN = re.compile(r"(?::([a-zA-Z_][a-zA-Z0-9_]*)|\{([a-zA-Z_][a-zA-Z0-9_]*)\??\})")


def _now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def _atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}.{uuid.uuid4().hex[:6]}")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


# ── Storage Manager ───────────────────────────────────────────────────────────

class ApiClientStore:
    """File-backed persistence for collections, environments, and request history."""

    def __init__(self, base_dir: str | Path | None = None):
        root = Path(base_dir) if base_dir is not None else (osutil.config_dir() / "api_client")
        self.root = root
        self.collections_dir = self.root / "collections"
        self.envs_file = self.root / "environments.json"
        self.history_file = self.root / "history.json"

    # ── Collections ──

    def list_collections(self) -> list[dict]:
        cols: list[dict] = []
        if not self.collections_dir.is_dir():
            return cols
        for p in sorted(self.collections_dir.glob("*.json")):
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(data, dict) and data.get("id"):
                    cols.append(normalize_collection(data))
            except Exception:
                continue
        cols.sort(key=lambda c: (c.get("updated_at") or "", c.get("name") or ""), reverse=True)
        return cols

    def get_collection(self, collection_id: str) -> dict | None:
        safe = re.sub(r"[^a-zA-Z0-9_\-]", "", str(collection_id or ""))
        if not safe:
            return None
        path = self.collections_dir / f"{safe}.json"
        if not path.is_file():
            return None
        try:
            return normalize_collection(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            return None

    def save_collection(self, collection: dict) -> dict:
        col = normalize_collection(collection)
        if not col.get("id"):
            col["id"] = _new_id("col")
        safe = re.sub(r"[^a-zA-Z0-9_\-]", "", col["id"]) or _new_id("col")
        col["id"] = safe
        now = _now_iso()
        if not col.get("created_at"):
            col["created_at"] = now
        col["updated_at"] = now
        _atomic_write_json(self.collections_dir / f"{safe}.json", col)
        return col

    def delete_collection(self, collection_id: str) -> bool:
        safe = re.sub(r"[^a-zA-Z0-9_\-]", "", str(collection_id or ""))
        if not safe:
            return False
        path = self.collections_dir / f"{safe}.json"
        if path.is_file():
            path.unlink(missing_ok=True)
            return True
        return False

    # ── Environments ──

    def get_environments_state(self) -> dict:
        if self.envs_file.is_file():
            try:
                raw = json.loads(self.envs_file.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    envs = [normalize_environment(e) for e in raw.get("environments") or [] if isinstance(e, dict)]
                    return {
                        "active_env_id": str(raw.get("active_env_id") or ""),
                        "environments": envs,
                    }
            except Exception:
                pass
        return {"active_env_id": "", "environments": []}

    def save_environments_state(self, environments: list[dict], active_env_id: str = "") -> dict:
        clean = [normalize_environment(e) for e in (environments or []) if isinstance(e, dict)]
        ids = {e["id"] for e in clean}
        active = active_env_id if active_env_id in ids else (clean[0]["id"] if clean else "")
        state = {"active_env_id": active, "environments": clean}
        _atomic_write_json(self.envs_file, state)
        return state

    def upsert_environment(self, env: dict, activate: bool = False) -> dict:
        state = self.get_environments_state()
        envs = state["environments"]
        norm = normalize_environment(env)
        replaced = False
        for idx, existing in enumerate(envs):
            if existing["id"] == norm["id"] or (norm.get("site_name") and existing.get("site_name") == norm["site_name"]):
                norm["id"] = existing["id"]
                envs[idx] = norm
                replaced = True
                break
        if not replaced:
            envs.append(norm)
        active = norm["id"] if activate else state["active_env_id"]
        saved = self.save_environments_state(envs, active)
        return {"environment": norm, "state": saved}

    def set_env_variables(self, env_id: str, updates: dict[str, str]) -> dict | None:
        if not env_id or not updates:
            return None
        state = self.get_environments_state()
        target = None
        for env in state["environments"]:
            if env["id"] == env_id:
                target = env
                break
        if not target:
            return None
        by_key = {v["key"]: v for v in target["variables"] if v.get("key")}
        for k, val in updates.items():
            key_s = str(k).strip()
            if not key_s:
                continue
            if key_s in by_key:
                by_key[key_s]["value"] = str(val)
                by_key[key_s]["enabled"] = True
            else:
                entry = {"id": _new_id("var"), "key": key_s, "value": str(val), "enabled": True, "secret": False, "description": ""}
                target["variables"].append(entry)
                by_key[key_s] = entry
        target["updated_at"] = _now_iso()
        self.save_environments_state(state["environments"], state["active_env_id"])
        return target

    # ── History ──

    def list_history(self, limit: int = 100) -> list[dict]:
        if not self.history_file.is_file():
            return []
        try:
            items = json.loads(self.history_file.read_text(encoding="utf-8"))
            return items[:limit] if isinstance(items, list) else []
        except Exception:
            return []

    def append_history(self, entry: dict, max_items: int = 100) -> list[dict]:
        items = self.list_history(limit=max_items)
        items.insert(0, entry)
        items = items[:max_items]
        _atomic_write_json(self.history_file, items)
        return items

    def clear_history(self) -> None:
        _atomic_write_json(self.history_file, [])

    def get_full_state(self) -> dict:
        env_state = self.get_environments_state()
        return {
            "ok": True,
            "collections": self.list_collections(),
            "environments": env_state["environments"],
            "active_env_id": env_state["active_env_id"],
            "history": self.list_history(),
        }


# ── Normalizers ───────────────────────────────────────────────────────────────

def _norm_kv_list(rows: Any, extra_keys: tuple[str, ...] = ()) -> list[dict]:
    if not isinstance(rows, list):
        return []
    out = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        item = {
            "key": str(row.get("key") or ""),
            "value": str(row.get("value") if row.get("value") is not None else ""),
            "enabled": bool(row.get("enabled", not row.get("disabled", False))),
            "description": str(row.get("description") or ""),
        }
        for ek in extra_keys:
            if ek in row:
                item[ek] = row[ek]
        out.append(item)
    return out


def normalize_auth(auth: Any, default_type: str = "none") -> dict:
    if not isinstance(auth, dict) or not auth.get("type"):
        return {"type": default_type}
    atype = str(auth.get("type") or default_type).lower()
    if atype == "noauth":
        atype = "none"
    base: dict[str, Any] = {"type": atype}
    if atype == "bearer":
        base["token"] = str(auth.get("token") or "")
    elif atype == "basic":
        base["username"] = str(auth.get("username") or "")
        base["password"] = str(auth.get("password") or "")
    elif atype == "apikey":
        base["key"] = str(auth.get("key") or "X-API-Key")
        base["value"] = str(auth.get("value") or "")
        base["in"] = "query" if str(auth.get("in") or "header").lower() == "query" else "header"
    elif atype == "sanctum":
        base["csrf_url"] = str(auth.get("csrf_url") or "/sanctum/csrf-cookie")
        base["origin"] = str(auth.get("origin") or "")
        base["token"] = str(auth.get("token") or "")
    return base


def normalize_body(body: Any) -> dict:
    if not isinstance(body, dict):
        return {
            "mode": "none",
            "raw": "",
            "raw_type": "json",
            "formdata": [],
            "urlencoded": [],
            "graphql": {"query": "", "variables": ""},
        }
    mode = str(body.get("mode") or "none").lower()
    if mode not in ("none", "raw", "formdata", "urlencoded", "graphql"):
        mode = "none"
    raw_type = str(body.get("raw_type") or "json").lower()
    if raw_type not in ("json", "text", "xml", "html", "javascript"):
        raw_type = "json"
    formdata = []
    for row in (body.get("formdata") or []):
        if not isinstance(row, dict):
            continue
        ftype = "file" if str(row.get("type") or "text").lower() == "file" else "text"
        formdata.append({
            "key": str(row.get("key") or ""),
            "value": str(row.get("value") if row.get("value") is not None else ""),
            "type": ftype,
            "src": str(row.get("src") or ""),
            "enabled": bool(row.get("enabled", not row.get("disabled", False))),
            "description": str(row.get("description") or ""),
        })
    gql = body.get("graphql") if isinstance(body.get("graphql"), dict) else {}
    return {
        "mode": mode,
        "raw": str(body.get("raw") if body.get("raw") is not None else ""),
        "raw_type": raw_type,
        "formdata": formdata,
        "urlencoded": _norm_kv_list(body.get("urlencoded")),
        "graphql": {
            "query": str(gql.get("query") or ""),
            "variables": str(gql.get("variables") or ""),
        },
    }


def normalize_example(ex: Any) -> dict:
    if not isinstance(ex, dict):
        return {
            "id": _new_id("ex"),
            "name": "Example",
            "status": 200,
            "status_text": "OK",
            "headers": [],
            "body": "",
            "created_at": _now_iso(),
        }
    headers = []
    raw_headers = ex.get("headers") or []
    if isinstance(raw_headers, dict):
        headers = [{"key": str(k), "value": str(v)} for k, v in raw_headers.items()]
    elif isinstance(raw_headers, list):
        for h in raw_headers:
            if isinstance(h, dict) and h.get("key"):
                headers.append({"key": str(h.get("key")), "value": str(h.get("value") or "")})
    return {
        "id": str(ex.get("id") or _new_id("ex")),
        "name": str(ex.get("name") or f"{ex.get('status') or 200} Response"),
        "status": int(ex.get("status") or 200),
        "status_text": str(ex.get("status_text") or _http_reason(int(ex.get("status") or 200))),
        "headers": headers,
        "body": str(ex.get("body") if ex.get("body") is not None else ""),
        "created_at": str(ex.get("created_at") or _now_iso()),
    }


def normalize_item(item: Any) -> dict:
    if not isinstance(item, dict):
        item = {}
    itype = str(item.get("type") or ("folder" if isinstance(item.get("items"), list) else "request")).lower()
    if itype == "folder":
        return {
            "id": str(item.get("id") or _new_id("fld")),
            "type": "folder",
            "name": str(item.get("name") or "New Folder"),
            "description": str(item.get("description") or ""),
            "auth": normalize_auth(item.get("auth"), default_type="inherit"),
            "items": [normalize_item(child) for child in (item.get("items") or []) if isinstance(child, dict)],
        }
    method = str(item.get("method") or "GET").upper()
    if method not in VALID_METHODS:
        method = "GET"
    tests = []
    for t in (item.get("tests") or []):
        if isinstance(t, dict) and t.get("type"):
            tests.append({
                "type": str(t.get("type")),
                "target": str(t.get("target") or ""),
                "value": str(t.get("value") if t.get("value") is not None else ""),
                "enabled": bool(t.get("enabled", True)),
            })
    extractors = []
    for ext in (item.get("extractors") or []):
        if isinstance(ext, dict):
            extractors.append({
                "source": str(ext.get("source") or "json").lower(),
                "path": str(ext.get("path") or ""),
                "variable": str(ext.get("variable") or ""),
                "enabled": bool(ext.get("enabled", True)),
            })
    return {
        "id": str(item.get("id") or _new_id("req")),
        "type": "request",
        "name": str(item.get("name") or "New Request"),
        "description": str(item.get("description") or ""),
        "method": method,
        "url": str(item.get("url") or ""),
        "params": _norm_kv_list(item.get("params")),
        "path_variables": _norm_kv_list(item.get("path_variables")),
        "headers": _norm_kv_list(item.get("headers")),
        "auth": normalize_auth(item.get("auth"), default_type="inherit"),
        "body": normalize_body(item.get("body")),
        "tests": tests,
        "extractors": extractors,
        "examples": [normalize_example(e) for e in (item.get("examples") or []) if isinstance(e, dict)],
    }


def normalize_collection(col: Any) -> dict:
    if not isinstance(col, dict):
        col = {}
    return {
        "id": str(col.get("id") or _new_id("col")),
        "name": str(col.get("name") or "Untitled Collection"),
        "description": str(col.get("description") or ""),
        "site_name": str(col.get("site_name") or ""),
        "auth": normalize_auth(col.get("auth"), default_type="none"),
        "variables": _norm_kv_list(col.get("variables")),
        "items": [normalize_item(it) for it in (col.get("items") or []) if isinstance(it, dict)],
        "created_at": str(col.get("created_at") or _now_iso()),
        "updated_at": str(col.get("updated_at") or _now_iso()),
    }


def normalize_environment(env: Any) -> dict:
    if not isinstance(env, dict):
        env = {}
    variables = []
    for v in (env.get("variables") or []):
        if not isinstance(v, dict):
            continue
        variables.append({
            "id": str(v.get("id") or _new_id("var")),
            "key": str(v.get("key") or ""),
            "value": str(v.get("value") if v.get("value") is not None else ""),
            "enabled": bool(v.get("enabled", True)),
            "secret": bool(v.get("secret", False)),
            "description": str(v.get("description") or ""),
        })
    return {
        "id": str(env.get("id") or _new_id("env")),
        "name": str(env.get("name") or "New Environment"),
        "site_name": str(env.get("site_name") or ""),
        "variables": variables,
        "updated_at": str(env.get("updated_at") or _now_iso()),
    }


def _http_reason(code: int) -> str:
    reasons = {
        200: "OK", 201: "Created", 202: "Accepted", 204: "No Content",
        301: "Moved Permanently", 302: "Found", 304: "Not Modified",
        400: "Bad Request", 401: "Unauthorized", 403: "Forbidden",
        404: "Not Found", 405: "Method Not Allowed", 409: "Conflict",
        419: "Page Expired", 422: "Unprocessable Entity", 429: "Too Many Requests",
        500: "Internal Server Error", 502: "Bad Gateway", 503: "Service Unavailable",
    }
    return reasons.get(int(code or 0), "")


# ── Variable Substitution ─────────────────────────────────────────────────────

def _dynamic_var(name: str) -> str | None:
    if name == "$guid":
        return str(uuid.uuid4())
    if name == "$timestamp":
        return str(int(time.time()))
    if name == "$isoTimestamp":
        return _now_iso()
    if name == "$randomInt":
        return str(random.randint(0, 1000))
    if name == "$randomEmail":
        return f"user_{uuid.uuid4().hex[:6]}@example.test"
    if name == "$randomName":
        return f"User {random.randint(100, 999)}"
    return None


def interpolate(text: str, variables: dict[str, str]) -> str:
    if not text or "{{" not in text:
        return text

    def _replace(match: re.Match) -> str:
        key = match.group(1)
        if key in variables:
            return str(variables[key])
        dyn = _dynamic_var(key)
        if dyn is not None:
            return dyn
        return match.group(0)

    return VAR_PATTERN.sub(_replace, text)


def merge_variables(collection_vars: list[dict] | dict | None, env_vars: list[dict] | dict | None) -> dict[str, str]:
    merged: dict[str, str] = {}
    for source in (collection_vars, env_vars):
        if isinstance(source, dict):
            for k, v in source.items():
                if k:
                    merged[str(k)] = str(v)
        elif isinstance(source, list):
            for row in source:
                if isinstance(row, dict) and row.get("enabled", True) and row.get("key"):
                    merged[str(row["key"])] = str(row.get("value") if row.get("value") is not None else "")
    return merged


# ── Multipart Form-Data Builder ───────────────────────────────────────────────

def _build_multipart(fields: list[dict], variables: dict[str, str]) -> tuple[bytes, str]:
    boundary = f"----LaravelDevBoundary{uuid.uuid4().hex}"
    chunks: list[bytes] = []

    for row in fields:
        if not row.get("enabled", True):
            continue
        key = interpolate(str(row.get("key") or ""), variables).strip()
        if not key:
            continue
        safe_key = key.replace('"', '\\"')
        if row.get("type") == "file":
            src = interpolate(str(row.get("src") or row.get("value") or ""), variables).strip()
            if not src:
                continue
            fpath = Path(os.path.expanduser(src))
            if not fpath.is_file():
                raise ValueError(f"Upload file not found for field '{key}': {src}")
            filename = fpath.name.replace('"', '\\"')
            ctype = mimetypes.guess_type(fpath.name)[0] or "application/octet-stream"
            data = fpath.read_bytes()
            chunks.append(f"--{boundary}\r\n".encode("utf-8"))
            chunks.append(
                f'Content-Disposition: form-data; name="{safe_key}"; filename="{filename}"\r\n'
                f"Content-Type: {ctype}\r\n\r\n".encode("utf-8")
            )
            chunks.append(data)
            chunks.append(b"\r\n")
        else:
            val = interpolate(str(row.get("value") or ""), variables)
            chunks.append(f"--{boundary}\r\n".encode("utf-8"))
            chunks.append(f'Content-Disposition: form-data; name="{safe_key}"\r\n\r\n'.encode("utf-8"))
            chunks.append(val.encode("utf-8"))
            chunks.append(b"\r\n")

    chunks.append(f"--{boundary}--\r\n".encode("utf-8"))
    return b"".join(chunks), f"multipart/form-data; boundary={boundary}"


# ── JSON Path Helper & Assertions ─────────────────────────────────────────────

def resolve_json_path(data: Any, path: str) -> tuple[bool, Any]:
    """Resolve dot/bracket JSON paths like 'data.user.id' or 'items[0].name' or 'items.0.name'."""
    if not path:
        return True, data
    clean = path.strip()
    if clean.startswith("$."):
        clean = clean[2:]
    elif clean == "$":
        return True, data
    tokens = re.findall(r"[^.\[\]]+", clean)
    cur = data
    for tok in tokens:
        if isinstance(cur, dict):
            if tok in cur:
                cur = cur[tok]
            else:
                return False, None
        elif isinstance(cur, list):
            try:
                idx = int(tok)
                if -len(cur) <= idx < len(cur):
                    cur = cur[idx]
                else:
                    return False, None
            except ValueError:
                return False, None
        else:
            return False, None
    return True, cur


def run_assertions(tests: list[dict], response: dict) -> list[dict]:
    results = []
    status = int(response.get("status") or 0)
    duration = float(response.get("duration_ms") or 0)
    body_text = str(response.get("text") or "")
    parsed_json = response.get("json")
    headers_lower = {k.lower(): v for k, v in (response.get("headers") or {}).items()}

    for rule in tests or []:
        if not isinstance(rule, dict) or not rule.get("enabled", True):
            continue
        rtype = str(rule.get("type") or "")
        target = str(rule.get("target") or "").strip()
        expected = str(rule.get("value") if rule.get("value") is not None else "")

        if rtype == "status_equals":
            passed = str(status) == expected.strip()
            results.append({
                "type": rtype,
                "name": f"Status code is {expected}",
                "passed": passed,
                "actual": str(status),
                "expected": expected,
            })
        elif rtype == "status_2xx":
            passed = 200 <= status < 300
            results.append({
                "type": rtype,
                "name": "Status code is 2xx (Success)",
                "passed": passed,
                "actual": str(status),
                "expected": "200-299",
            })
        elif rtype == "response_time_lt":
            try:
                limit = float(expected)
                passed = duration < limit
            except ValueError:
                passed = False
            results.append({
                "type": rtype,
                "name": f"Response time < {expected}ms",
                "passed": passed,
                "actual": f"{duration}ms",
                "expected": f"< {expected}ms",
            })
        elif rtype == "body_contains":
            passed = expected in body_text
            results.append({
                "type": rtype,
                "name": f"Body contains '{expected}'",
                "passed": passed,
                "actual": "Found" if passed else "Not found",
                "expected": expected,
            })
        elif rtype == "header_exists":
            passed = target.lower() in headers_lower
            results.append({
                "type": rtype,
                "name": f"Header '{target}' exists",
                "passed": passed,
                "actual": headers_lower.get(target.lower(), "Missing"),
                "expected": "Present",
            })
        elif rtype == "json_path_exists":
            found, val = (resolve_json_path(parsed_json, target) if parsed_json is not None else (False, None))
            results.append({
                "type": rtype,
                "name": f"JSON path '{target}' exists",
                "passed": found,
                "actual": json.dumps(val, ensure_ascii=False)[:120] if found else "Missing",
                "expected": "Exists",
            })
        elif rtype == "json_path_equals":
            found, val = (resolve_json_path(parsed_json, target) if parsed_json is not None else (False, None))
            actual_str = "" if not found else (val if isinstance(val, str) else json.dumps(val, ensure_ascii=False))
            passed = found and actual_str == expected
            results.append({
                "type": rtype,
                "name": f"JSON '{target}' == '{expected}'",
                "passed": passed,
                "actual": actual_str if found else "Missing",
                "expected": expected,
            })
    return results


def run_extractors(extractors: list[dict], response: dict) -> dict[str, str]:
    extracted: dict[str, str] = {}
    parsed_json = response.get("json")
    headers_lower = {k.lower(): v for k, v in (response.get("headers") or {}).items()}
    cookies_by_name = {c["name"]: c["value"] for c in (response.get("cookies") or []) if isinstance(c, dict) and c.get("name")}

    for ext in extractors or []:
        if not isinstance(ext, dict) or not ext.get("enabled", True):
            continue
        var_name = str(ext.get("variable") or "").strip()
        path = str(ext.get("path") or "").strip()
        source = str(ext.get("source") or "json").lower()
        if not var_name or not path:
            continue
        if source == "json" and parsed_json is not None:
            found, val = resolve_json_path(parsed_json, path)
            if found and val is not None:
                extracted[var_name] = val if isinstance(val, str) else json.dumps(val, ensure_ascii=False)
        elif source == "header":
            val = headers_lower.get(path.lower())
            if val is not None:
                extracted[var_name] = str(val)
        elif source == "cookie":
            val = cookies_by_name.get(path)
            if val is not None:
                extracted[var_name] = str(val)
    return extracted


# ── HTTP Request Execution Engine ─────────────────────────────────────────────

class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _parse_set_cookies(raw_headers) -> list[dict]:
    cookies: list[dict] = []
    if not raw_headers:
        return cookies
    values = raw_headers.get_all("Set-Cookie") if hasattr(raw_headers, "get_all") else []
    for raw in values or []:
        parts = [p.strip() for p in str(raw).split(";") if p.strip()]
        if not parts or "=" not in parts[0]:
            continue
        name, val = parts[0].split("=", 1)
        entry = {
            "name": name.strip(),
            "value": val.strip(),
            "path": "/",
            "domain": "",
            "expires": "",
            "http_only": False,
            "secure": False,
            "same_site": "",
        }
        for attr in parts[1:]:
            if "=" in attr:
                ak, av = attr.split("=", 1)
                akl = ak.strip().lower()
                if akl == "path":
                    entry["path"] = av.strip()
                elif akl == "domain":
                    entry["domain"] = av.strip()
                elif akl in ("expires", "max-age"):
                    entry["expires"] = av.strip()
                elif akl == "samesite":
                    entry["same_site"] = av.strip()
            else:
                al = attr.lower()
                if al == "httponly":
                    entry["http_only"] = True
                elif al == "secure":
                    entry["secure"] = True
        cookies.append(entry)
    return cookies


def prepare_request(
    req_spec: dict,
    variables: dict[str, str] | None = None,
    inherited_auth: dict | None = None,
) -> dict:
    """Resolve URL, path params, query params, headers, auth, and body payload."""
    vars_map = variables or {}
    req = normalize_item({**req_spec, "type": "request"})
    method = req["method"]

    raw_url = interpolate(req["url"].strip(), vars_map)
    if not raw_url:
        raise ValueError("Request URL is required")
    if not re.match(r"^https?://", raw_url, re.IGNORECASE):
        raw_url = "http://" + raw_url

    # Replace path variables (:id or {id} / {id?})
    path_vars = {
        p["key"].strip(): interpolate(p["value"], vars_map)
        for p in req.get("path_variables", [])
        if p.get("key") and p.get("enabled", True)
    }
    parsed = urllib.parse.urlsplit(raw_url)

    def _sub_path(match: re.Match) -> str:
        pname = match.group(1) or match.group(2)
        if pname in path_vars and path_vars[pname] != "":
            return urllib.parse.quote(path_vars[pname], safe="")
        # Optional Laravel param {id?} -> remove segment if empty
        if match.group(0).endswith("?}"):
            return ""
        return match.group(0)

    resolved_path = PATH_PARAM_PATTERN.sub(_sub_path, parsed.path)
    resolved_path = re.sub(r"/{2,}", "/", resolved_path) if resolved_path else ""

    # Merge query string from URL + enabled params table
    query_pairs = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    # Only append params not already identical in raw URL if params list was explicitly provided
    enabled_params = [
        (interpolate(p["key"], vars_map), interpolate(p["value"], vars_map))
        for p in req.get("params", [])
        if p.get("enabled", True) and p.get("key")
    ]
    if req.get("params"):
        # When params table is populated, use enabled entries as authoritative (standard Postman behavior)
        query_pairs = enabled_params

    # Headers
    headers: dict[str, str] = {
        "User-Agent": "LaravelDev-APIClient/1.0",
        "Accept": "*/*",
    }
    for h in req.get("headers", []):
        if h.get("enabled", True) and h.get("key"):
            hk = interpolate(h["key"], vars_map).strip()
            hv = interpolate(h["value"], vars_map)
            if hk:
                headers[hk] = hv

    # Auth resolution
    auth = req.get("auth") or {"type": "inherit"}
    if auth.get("type") == "inherit":
        auth = normalize_auth(inherited_auth, default_type="none")
    atype = auth.get("type", "none")

    sanctum_cfg = None
    if atype == "bearer":
        tok = interpolate(auth.get("token", ""), vars_map).strip()
        if tok:
            headers["Authorization"] = f"Bearer {tok}"
    elif atype == "basic":
        user = interpolate(auth.get("username", ""), vars_map)
        pwd = interpolate(auth.get("password", ""), vars_map)
        b64 = base64.b64encode(f"{user}:{pwd}".encode("utf-8")).decode("ascii")
        headers["Authorization"] = f"Basic {b64}"
    elif atype == "apikey":
        ak = interpolate(auth.get("key", ""), vars_map).strip()
        av = interpolate(auth.get("value", ""), vars_map)
        if ak:
            if auth.get("in") == "query":
                query_pairs.append((ak, av))
            else:
                headers[ak] = av
    elif atype == "sanctum":
        sanctum_cfg = {
            "csrf_url": interpolate(auth.get("csrf_url") or "/sanctum/csrf-cookie", vars_map),
            "origin": interpolate(auth.get("origin") or f"{parsed.scheme}://{parsed.netloc}", vars_map),
            "token": interpolate(auth.get("token") or "", vars_map).strip(),
        }
        if sanctum_cfg["token"]:
            headers["Authorization"] = f"Bearer {sanctum_cfg['token']}"

    final_query = urllib.parse.urlencode(query_pairs, doseq=True)
    final_url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, resolved_path, final_query, parsed.fragment))

    # Body
    body_cfg = req.get("body") or {}
    mode = body_cfg.get("mode", "none")
    data: bytes | None = None
    body_preview = ""
    header_keys_lower = {k.lower() for k in headers}

    if method not in ("GET", "HEAD") or mode != "none":
        if mode == "raw":
            raw_text = interpolate(body_cfg.get("raw") or "", vars_map)
            data = raw_text.encode("utf-8")
            body_preview = raw_text
            if "content-type" not in header_keys_lower:
                ct_map = {
                    "json": "application/json",
                    "xml": "application/xml",
                    "html": "text/html",
                    "javascript": "application/javascript",
                    "text": "text/plain",
                }
                headers["Content-Type"] = ct_map.get(body_cfg.get("raw_type", "json"), "text/plain")
        elif mode == "urlencoded":
            pairs = [
                (interpolate(r["key"], vars_map), interpolate(r["value"], vars_map))
                for r in body_cfg.get("urlencoded", [])
                if r.get("enabled", True) and r.get("key")
            ]
            encoded = urllib.parse.urlencode(pairs)
            data = encoded.encode("utf-8")
            body_preview = encoded
            if "content-type" not in header_keys_lower:
                headers["Content-Type"] = "application/x-www-form-urlencoded"
        elif mode == "formdata":
            data, content_type = _build_multipart(body_cfg.get("formdata", []), vars_map)
            headers["Content-Type"] = content_type
            body_preview = f"<multipart/form-data ({len(data)} bytes)>"
        elif mode == "graphql":
            gql = body_cfg.get("graphql") or {}
            query_str = interpolate(gql.get("query") or "", vars_map)
            vars_str = interpolate(gql.get("variables") or "", vars_map).strip()
            gql_vars = {}
            if vars_str:
                try:
                    gql_vars = json.loads(vars_str)
                except Exception:
                    raise ValueError("GraphQL variables must be valid JSON")
            payload = json.dumps({"query": query_str, "variables": gql_vars})
            data = payload.encode("utf-8")
            body_preview = payload
            if "content-type" not in header_keys_lower:
                headers["Content-Type"] = "application/json"

    return {
        "method": method,
        "url": final_url,
        "headers": headers,
        "data": data,
        "body_preview": body_preview,
        "sanctum": sanctum_cfg,
        "tests": req.get("tests") or [],
        "extractors": req.get("extractors") or [],
    }


def execute_request(
    req_spec: dict,
    variables: dict[str, str] | None = None,
    inherited_auth: dict | None = None,
    timeout: float = 30.0,
    follow_redirects: bool = True,
    verify_ssl: bool | None = None,
) -> dict:
    """Execute an HTTP request and return complete response details, assertions, and extracted variables."""
    try:
        prepared = prepare_request(req_spec, variables=variables, inherited_auth=inherited_auth)
    except Exception as exc:
        return {"ok": False, "error": str(exc), "duration_ms": 0.0}

    url = prepared["url"]
    method = prepared["method"]
    headers = dict(prepared["headers"])
    data = prepared["data"]
    parsed = urllib.parse.urlsplit(url)

    # Local dev domains (.test, localhost, 127.0.0.1) often use self-signed certs
    if verify_ssl is None:
        host = (parsed.hostname or "").lower()
        verify_ssl = not (host in ("localhost", "127.0.0.1", "::1") or host.endswith(".test") or host.endswith(".local"))

    ssl_ctx = ssl.create_default_context() if verify_ssl else ssl._create_unverified_context()
    jar = http.cookiejar.CookieJar()
    handlers: list[Any] = [
        urllib.request.HTTPSHandler(context=ssl_ctx),
        urllib.request.HTTPCookieProcessor(jar),
    ]
    if not follow_redirects:
        handlers.append(_NoRedirectHandler())
    opener = urllib.request.build_opener(*handlers)

    # Laravel Sanctum CSRF handshake if enabled
    sanctum = prepared.get("sanctum")
    if sanctum:
        csrf_path = sanctum["csrf_url"]
        csrf_url = csrf_path if re.match(r"^https?://", csrf_path, re.I) else f"{parsed.scheme}://{parsed.netloc}/{csrf_path.lstrip('/')}"
        try:
            csrf_req = urllib.request.Request(
                csrf_url,
                headers={"Accept": "application/json", "Origin": sanctum["origin"], "Referer": sanctum["origin"]},
                method="GET",
            )
            with opener.open(csrf_req, timeout=min(timeout, 10.0)):
                pass
            for c in jar:
                if c.name == "XSRF-TOKEN":
                    headers["X-XSRF-TOKEN"] = urllib.parse.unquote(c.value)
                    break
            headers.setdefault("Origin", sanctum["origin"])
            headers.setdefault("Referer", sanctum["origin"])
            headers.setdefault("X-Requested-With", "XMLHttpRequest")
        except Exception as exc:
            return {"ok": False, "error": f"Sanctum CSRF cookie handshake failed ({csrf_url}): {exc}", "duration_ms": 0.0}

    t0 = time.perf_counter()
    http_req = urllib.request.Request(url=url, data=data, headers=headers, method=method)

    status = 0
    reason = ""
    resp_headers_obj = None
    raw_bytes = b""
    final_url = url

    try:
        with opener.open(http_req, timeout=timeout) as resp:
            dur_ms = round((time.perf_counter() - t0) * 1000, 1)
            status = resp.status
            reason = getattr(resp, "reason", "") or _http_reason(status)
            resp_headers_obj = resp.headers
            raw_bytes = resp.read()
            final_url = resp.geturl()
    except urllib.error.HTTPError as he:
        dur_ms = round((time.perf_counter() - t0) * 1000, 1)
        status = he.code
        reason = he.reason or _http_reason(status)
        resp_headers_obj = he.headers
        try:
            raw_bytes = he.read()
        except Exception:
            raw_bytes = b""
        final_url = he.geturl() or url
    except Exception as exc:
        dur_ms = round((time.perf_counter() - t0) * 1000, 1)
        return {
            "ok": False,
            "error": str(exc),
            "duration_ms": dur_ms,
            "resolved_request": {"method": method, "url": url, "headers": headers},
        }

    resp_headers = dict(resp_headers_obj.items()) if resp_headers_obj else {}
    cookies = _parse_set_cookies(resp_headers_obj)
    content_type = resp_headers_obj.get("Content-Type", "") if resp_headers_obj else ""
    text = raw_bytes.decode("utf-8", errors="replace")

    parsed_json = None
    if "json" in content_type.lower() or text.lstrip().startswith(("{", "[")):
        try:
            parsed_json = json.loads(text)
        except Exception:
            parsed_json = None

    result: dict[str, Any] = {
        "ok": True,
        "status": status,
        "status_text": reason,
        "duration_ms": dur_ms,
        "size_bytes": len(raw_bytes),
        "content_type": content_type,
        "headers": resp_headers,
        "cookies": cookies,
        "is_json": parsed_json is not None,
        "json": parsed_json,
        "text": text,
        "final_url": final_url,
        "timestamp": _now_iso(),
        "resolved_request": {
            "method": method,
            "url": url,
            "headers": headers,
            "body_preview": prepared["body_preview"][:4096],
        },
    }

    result["test_results"] = run_assertions(prepared["tests"], result)
    result["extracted_vars"] = run_extractors(prepared["extractors"], result)
    return result


# ── Code Snippet Generators ───────────────────────────────────────────────────

def generate_code_snippet(
    req_spec: dict,
    lang: str = "curl",
    variables: dict[str, str] | None = None,
    inherited_auth: dict | None = None,
) -> str:
    """Generate ready-to-copy client code (curl, fetch, axios, laravel, python, dart)."""
    try:
        prep = prepare_request(req_spec, variables=variables, inherited_auth=inherited_auth)
    except Exception:
        req = normalize_item({**req_spec, "type": "request"})
        prep = {
            "method": req["method"],
            "url": req["url"] or "http://localhost",
            "headers": {h["key"]: h["value"] for h in req["headers"] if h.get("enabled", True) and h.get("key")},
            "body_preview": req["body"].get("raw", "") if req["body"].get("mode") == "raw" else "",
            "data": None,
        }

    method = prep["method"]
    url = prep["url"]
    headers = {k: v for k, v in prep["headers"].items() if k.lower() != "user-agent"}
    body_text = prep.get("body_preview") or ""
    req_norm = normalize_item({**req_spec, "type": "request"})
    body_mode = req_norm["body"]["mode"]

    lang = (lang or "curl").lower()

    if lang == "curl":
        parts = [f"curl --location --request {method} {shlex.quote(url)}"]
        for k, v in headers.items():
            if body_mode == "formdata" and k.lower() == "content-type":
                continue
            parts.append(f"--header {shlex.quote(f'{k}: {v}')}")
        if body_mode == "formdata":
            for row in req_norm["body"]["formdata"]:
                if not row.get("enabled", True) or not row.get("key"):
                    continue
                if row.get("type") == "file":
                    parts.append(f"--form {shlex.quote(row['key'] + '=@' + (row.get('src') or '/path/to/file'))}")
                else:
                    parts.append(f"--form {shlex.quote(row['key'] + '=' + row.get('value', ''))}")
        elif body_mode == "urlencoded":
            for row in req_norm["body"]["urlencoded"]:
                if row.get("enabled", True) and row.get("key"):
                    parts.append(f"--data-urlencode {shlex.quote(row['key'] + '=' + row.get('value', ''))}")
        elif body_text and method not in ("GET", "HEAD"):
            parts.append(f"--data-raw {shlex.quote(body_text)}")
        return " \\\n  ".join(parts)

    if lang == "fetch":
        opts: dict[str, Any] = {"method": method}
        if headers:
            opts["headers"] = headers
        lines = [f"const response = await fetch({json.dumps(url)}, {{"]
        lines.append(f"  method: {json.dumps(method)},")
        if headers:
            lines.append(f"  headers: {json.dumps(headers, indent=4).replace(chr(10), chr(10) + '  ')},")
        if body_text and method not in ("GET", "HEAD") and body_mode != "formdata":
            if body_mode == "raw" and req_norm["body"].get("raw_type") == "json":
                try:
                    parsed_b = json.loads(body_text)
                    lines.append(f"  body: JSON.stringify({json.dumps(parsed_b, indent=2).replace(chr(10), chr(10) + '  ')}),")
                except Exception:
                    lines.append(f"  body: {json.dumps(body_text)},")
            else:
                lines.append(f"  body: {json.dumps(body_text)},")
        lines.append("});")
        lines.append("const data = await response.json();")
        lines.append("console.log(data);")
        return "\n".join(lines)

    if lang == "axios":
        lines = ["import axios from 'axios';", "", "const response = await axios({"]
        lines.append(f"  method: {json.dumps(method.lower())},")
        lines.append(f"  url: {json.dumps(url)},")
        if headers:
            lines.append(f"  headers: {json.dumps(headers, indent=4).replace(chr(10), chr(10) + '  ')},")
        if body_text and method not in ("GET", "HEAD") and body_mode != "formdata":
            try:
                parsed_b = json.loads(body_text)
                lines.append(f"  data: {json.dumps(parsed_b, indent=2).replace(chr(10), chr(10) + '  ')},")
            except Exception:
                lines.append(f"  data: {json.dumps(body_text)},")
        lines.append("});")
        lines.append("console.log(response.data);")
        return "\n".join(lines)

    if lang == "laravel":
        lines = ["use Illuminate\\Support\\Facades\\Http;", ""]
        chain = ["$response = Http"]
        if headers:
            h_pairs = ",\n    ".join(f"{json.dumps(k)} => {json.dumps(v)}" for k, v in headers.items())
            chain.append(f"::withHeaders([\n    {h_pairs},\n])")
        else:
            chain.append("::acceptJson()")
        m_lower = method.lower()
        if body_text and method not in ("GET", "HEAD") and body_mode == "raw":
            try:
                parsed_b = json.loads(body_text)
                if isinstance(parsed_b, dict):
                    b_pairs = ",\n    ".join(f"{json.dumps(k)} => {json.dumps(v)}" for k, v in parsed_b.items())
                    chain.append(f"->{m_lower}({json.dumps(url)}, [\n    {b_pairs},\n]);")
                else:
                    chain.append(f"->withBody({json.dumps(body_text)}, 'application/json')->{m_lower}({json.dumps(url)});")
            except Exception:
                chain.append(f"->withBody({json.dumps(body_text)}, 'text/plain')->{m_lower}({json.dumps(url)});")
        else:
            chain.append(f"->{m_lower}({json.dumps(url)});")
        lines.append("".join(chain))
        lines.append("")
        lines.append("dd($response->status(), $response->json());")
        return "\n".join(lines)

    if lang == "python":
        lines = ["import requests", ""]
        lines.append(f"url = {json.dumps(url)}")
        if headers:
            lines.append(f"headers = {json.dumps(headers, indent=2)}")
        args = [json.dumps(method), "url"]
        if headers:
            args.append("headers=headers")
        if body_text and method not in ("GET", "HEAD") and body_mode != "formdata":
            try:
                parsed_b = json.loads(body_text)
                lines.append(f"payload = {json.dumps(parsed_b, indent=2)}")
                args.append("json=payload")
            except Exception:
                lines.append(f"payload = {json.dumps(body_text)}")
                args.append("data=payload")
        lines.append(f"response = requests.request({', '.join(args)})")
        lines.append("print(response.status_code, response.text)")
        return "\n".join(lines)

    if lang == "dart":
        lines = ["import 'dart:convert';", "import 'package:http/http.dart' as http;", ""]
        lines.append(f"final uri = Uri.parse({json.dumps(url)});")
        lines.append(f"final request = http.Request({json.dumps(method)}, uri);")
        if headers:
            lines.append("request.headers.addAll({")
            for k, v in headers.items():
                lines.append(f"  {json.dumps(k)}: {json.dumps(v)},")
            lines.append("});")
        if body_text and method not in ("GET", "HEAD") and body_mode != "formdata":
            lines.append(f"request.body = {json.dumps(body_text)};")
        lines.append("final response = await request.send();")
        lines.append("print(await response.stream.bytesToString());")
        return "\n".join(lines)

    return generate_code_snippet(req_spec, "curl", variables=variables, inherited_auth=inherited_auth)


# ── Postman Collection v2.1.0 & Environment Export / Import ──────────────────

def _serialize_auth_v21(auth: dict | None) -> dict | None:
    if not isinstance(auth, dict):
        return None
    atype = auth.get("type", "none")
    if atype in ("inherit",):
        return None
    if atype == "none":
        return {"type": "noauth"}
    if atype == "bearer":
        return {"type": "bearer", "bearer": [{"key": "token", "value": auth.get("token", ""), "type": "string"}]}
    if atype == "basic":
        return {
            "type": "basic",
            "basic": [
                {"key": "username", "value": auth.get("username", ""), "type": "string"},
                {"key": "password", "value": auth.get("password", ""), "type": "string"},
            ],
        }
    if atype == "apikey":
        return {
            "type": "apikey",
            "apikey": [
                {"key": "key", "value": auth.get("key", "X-API-Key"), "type": "string"},
                {"key": "value", "value": auth.get("value", ""), "type": "string"},
                {"key": "in", "value": auth.get("in", "header"), "type": "string"},
            ],
        }
    if atype == "sanctum":
        # Represent Sanctum as bearer + custom metadata so Postman preserves token
        return {
            "type": "bearer",
            "bearer": [
                {"key": "token", "value": auth.get("token", ""), "type": "string"},
                {"key": "x_laravel_sanctum_csrf_url", "value": auth.get("csrf_url", "/sanctum/csrf-cookie"), "type": "string"},
            ],
        }
    return None


def _parse_auth_v21(raw_auth: Any) -> dict:
    if not isinstance(raw_auth, dict) or not raw_auth.get("type"):
        return {"type": "inherit"}
    atype = str(raw_auth.get("type")).lower()
    if atype in ("noauth", "none"):
        return {"type": "none"}

    def _kv_map(arr_or_dict: Any) -> dict[str, str]:
        if isinstance(arr_or_dict, dict):
            return {str(k): str(v) for k, v in arr_or_dict.items()}
        if isinstance(arr_or_dict, list):
            return {str(it.get("key")): str(it.get("value") or "") for it in arr_or_dict if isinstance(it, dict) and it.get("key")}
        return {}

    if atype == "bearer":
        kv = _kv_map(raw_auth.get("bearer"))
        if "x_laravel_sanctum_csrf_url" in kv:
            return {"type": "sanctum", "token": kv.get("token", ""), "csrf_url": kv.get("x_laravel_sanctum_csrf_url", "/sanctum/csrf-cookie")}
        return {"type": "bearer", "token": kv.get("token", "")}
    if atype == "basic":
        kv = _kv_map(raw_auth.get("basic"))
        return {"type": "basic", "username": kv.get("username", ""), "password": kv.get("password", "")}
    if atype == "apikey":
        kv = _kv_map(raw_auth.get("apikey"))
        return {"type": "apikey", "key": kv.get("key", "X-API-Key"), "value": kv.get("value", ""), "in": kv.get("in", "header")}
    return {"type": "none"}


def _serialize_url_v21(url_str: str, params: list[dict], path_vars: list[dict]) -> dict:
    raw = url_str or ""
    # Build query part into raw if not present
    enabled_q = [(p["key"], p["value"]) for p in params if p.get("enabled", True) and p.get("key")]
    parsed = urllib.parse.urlsplit(raw if "://" in raw else f"http://{raw}" if raw and not raw.startswith("{{") else raw)
    if enabled_q and "?" not in raw:
        qs = urllib.parse.urlencode(enabled_q)
        raw_full = f"{raw}?{qs}" if raw else f"?{qs}"
    else:
        raw_full = raw

    url_obj: dict[str, Any] = {"raw": raw_full}
    if "://" in raw:
        p = urllib.parse.urlsplit(raw)
        url_obj["protocol"] = p.scheme
        url_obj["host"] = p.netloc.split(".") if p.netloc else []
        url_obj["path"] = [seg for seg in p.path.split("/") if seg]
    elif raw.startswith("{{"):
        m = re.match(r"^(\{\{[^}]+\}\})(.*)$", raw)
        if m:
            host_var = m.group(1)
            rest = m.group(2).split("?", 1)[0]
            url_obj["host"] = [host_var]
            url_obj["path"] = [seg for seg in rest.split("/") if seg]

    if params:
        url_obj["query"] = [
            {
                "key": p["key"],
                "value": p["value"],
                "description": p.get("description", ""),
                "disabled": not p.get("enabled", True),
            }
            for p in params
            if p.get("key") or p.get("value")
        ]
    if path_vars:
        url_obj["variable"] = [
            {
                "key": v["key"],
                "value": v["value"],
                "description": v.get("description", ""),
            }
            for v in path_vars
            if v.get("key")
        ]
    return url_obj


def _serialize_tests_as_postman_event(tests: list[dict], extractors: list[dict]) -> list[dict]:
    lines: list[str] = []
    for t in tests or []:
        if not t.get("enabled", True):
            continue
        rt = t.get("type")
        target = t.get("target", "")
        val = t.get("value", "")
        if rt == "status_equals":
            lines.append(f'pm.test("Status code is {val}", function () {{ pm.response.to.have.status({val or 200}); }});')
        elif rt == "status_2xx":
            lines.append('pm.test("Status code is 2xx", function () { pm.expect(pm.response.code).to.be.within(200, 299); });')
        elif rt == "response_time_lt":
            lines.append(f'pm.test("Response time is less than {val}ms", function () {{ pm.expect(pm.response.responseTime).to.be.below({val or 500}); }});')
        elif rt == "body_contains":
            lines.append(f'pm.test("Body contains string", function () {{ pm.expect(pm.response.text()).to.include({json.dumps(val)}); }});')
        elif rt == "header_exists":
            lines.append(f'pm.test("Header {target} exists", function () {{ pm.response.to.have.header({json.dumps(target)}); }});')
        elif rt == "json_path_exists":
            lines.append(f'pm.test("JSON path {target} exists", function () {{ const d = pm.response.json(); pm.expect(d).to.have.nested.property({json.dumps(target)}); }});')
        elif rt == "json_path_equals":
            lines.append(f'pm.test("JSON path {target} equals {val}", function () {{ const d = pm.response.json(); pm.expect(String(pm.response.json())).to.not.be.empty; }});')
    for ext in extractors or []:
        if not ext.get("enabled", True) or not ext.get("variable") or not ext.get("path"):
            continue
        if ext.get("source", "json") == "json":
            accessor = "".join(f"[{json.dumps(p)}]" for p in re.findall(r"[^.\[\]]+", ext["path"]))
            lines.append(f'try {{ const _v = pm.response.json(){accessor}; if (_v !== undefined) pm.environment.set({json.dumps(ext["variable"])}, String(_v)); }} catch (e) {{}}')
    if not lines:
        return []
    return [{"listen": "test", "script": {"type": "text/javascript", "exec": lines}}]


def _serialize_item_v21(item: dict) -> dict:
    if item.get("type") == "folder":
        out: dict[str, Any] = {
            "name": item.get("name", "Folder"),
            "description": item.get("description", ""),
            "item": [_serialize_item_v21(c) for c in item.get("items", [])],
        }
        auth = _serialize_auth_v21(item.get("auth"))
        if auth:
            out["auth"] = auth
        return out

    body = item.get("body") or {}
    mode = body.get("mode", "none")
    pm_body: dict[str, Any] | None = None
    if mode == "raw":
        pm_body = {
            "mode": "raw",
            "raw": body.get("raw", ""),
            "options": {"raw": {"language": body.get("raw_type", "json")}},
        }
    elif mode == "urlencoded":
        pm_body = {
            "mode": "urlencoded",
            "urlencoded": [
                {
                    "key": r["key"],
                    "value": r["value"],
                    "description": r.get("description", ""),
                    "disabled": not r.get("enabled", True),
                    "type": "text",
                }
                for r in body.get("urlencoded", [])
            ],
        }
    elif mode == "formdata":
        pm_body = {
            "mode": "formdata",
            "formdata": [
                {
                    "key": r["key"],
                    "value": r["value"] if r.get("type") != "file" else None,
                    "src": r.get("src", "") if r.get("type") == "file" else None,
                    "type": r.get("type", "text"),
                    "description": r.get("description", ""),
                    "disabled": not r.get("enabled", True),
                }
                for r in body.get("formdata", [])
            ],
        }
    elif mode == "graphql":
        gql = body.get("graphql") or {}
        pm_body = {
            "mode": "graphql",
            "graphql": {"query": gql.get("query", ""), "variables": gql.get("variables", "")},
        }

    pm_request: dict[str, Any] = {
        "method": item.get("method", "GET"),
        "header": [
            {
                "key": h["key"],
                "value": h["value"],
                "description": h.get("description", ""),
                "disabled": not h.get("enabled", True),
                "type": "text",
            }
            for h in item.get("headers", [])
            if h.get("key")
        ],
        "url": _serialize_url_v21(item.get("url", ""), item.get("params", []), item.get("path_variables", [])),
        "description": item.get("description", ""),
    }
    if pm_body is not None:
        pm_request["body"] = pm_body
    auth = _serialize_auth_v21(item.get("auth"))
    if auth:
        pm_request["auth"] = auth

    responses = []
    for ex in item.get("examples", []):
        responses.append({
            "name": ex.get("name", "Example"),
            "originalRequest": pm_request,
            "status": ex.get("status_text") or _http_reason(ex.get("status", 200)),
            "code": int(ex.get("status") or 200),
            "_postman_previewlanguage": "json" if str(ex.get("body", "")).lstrip().startswith(("{", "[")) else "text",
            "header": [{"key": h["key"], "value": h["value"]} for h in ex.get("headers", [])],
            "body": ex.get("body", ""),
        })

    node: dict[str, Any] = {
        "name": item.get("name", "Request"),
        "request": pm_request,
        "response": responses,
    }
    events = _serialize_tests_as_postman_event(item.get("tests", []), item.get("extractors", []))
    if events:
        node["event"] = events
    return node


def export_postman_v21(collection: dict) -> dict:
    """Serialize internal collection to official Postman Collection v2.1.0 JSON."""
    col = normalize_collection(collection)
    out: dict[str, Any] = {
        "info": {
            "_postman_id": col["id"],
            "name": col["name"],
            "description": col.get("description", ""),
            "schema": POSTMAN_V21_SCHEMA,
        },
        "item": [_serialize_item_v21(it) for it in col.get("items", [])],
        "variable": [
            {
                "key": v["key"],
                "value": v["value"],
                "type": "string",
                "disabled": not v.get("enabled", True),
            }
            for v in col.get("variables", [])
            if v.get("key")
        ],
    }
    auth = _serialize_auth_v21(col.get("auth"))
    if auth and auth.get("type") != "noauth":
        out["auth"] = auth
    return out


def export_postman_environment(env: dict) -> dict:
    """Serialize internal environment to official Postman Environment JSON."""
    norm = normalize_environment(env)
    return {
        "id": norm["id"],
        "name": norm["name"],
        "values": [
            {
                "key": v["key"],
                "value": v["value"],
                "type": "secret" if v.get("secret") else "default",
                "enabled": bool(v.get("enabled", True)),
            }
            for v in norm.get("variables", [])
            if v.get("key")
        ],
        "_postman_variable_scope": "environment",
        "_postman_exported_at": _now_iso(),
        "_postman_exported_using": "Laravel Dev API Studio",
    }


def _extract_desc(val: Any) -> str:
    if isinstance(val, str):
        return val
    if isinstance(val, dict):
        return str(val.get("content") or "")
    return ""


def _parse_postman_item(raw_item: dict) -> dict:
    # Folder if it contains nested 'item' list and no 'request'
    if isinstance(raw_item.get("item"), list) and "request" not in raw_item:
        return {
            "id": _new_id("fld"),
            "type": "folder",
            "name": str(raw_item.get("name") or "Folder"),
            "description": _extract_desc(raw_item.get("description")),
            "auth": _parse_auth_v21(raw_item.get("auth")),
            "items": [_parse_postman_item(c) for c in raw_item.get("item", []) if isinstance(c, dict)],
        }

    req = raw_item.get("request")
    if isinstance(req, str):
        req = {"method": "GET", "url": req}
    elif not isinstance(req, dict):
        req = {}

    method = str(req.get("method") or "GET").upper()
    if method not in VALID_METHODS:
        method = "GET"

    # URL parsing (supports string or Postman v2.0/v2.1 object)
    raw_url_field = req.get("url")
    url_str = ""
    params: list[dict] = []
    path_vars: list[dict] = []

    if isinstance(raw_url_field, str):
        url_str = raw_url_field
    elif isinstance(raw_url_field, dict):
        url_str = str(raw_url_field.get("raw") or "")
        if not url_str:
            proto = raw_url_field.get("protocol") or "http"
            host = raw_url_field.get("host") or []
            host_s = ".".join(host) if isinstance(host, list) else str(host)
            path_parts = raw_url_field.get("path") or []
            path_s = "/".join(path_parts) if isinstance(path_parts, list) else str(path_parts)
            if host_s:
                prefix = host_s if host_s.startswith("{{") else f"{proto}://{host_s}"
                url_str = f"{prefix}/{path_s.lstrip('/')}" if path_s else prefix
        for q in raw_url_field.get("query") or []:
            if isinstance(q, dict):
                params.append({
                    "key": str(q.get("key") or ""),
                    "value": str(q.get("value") if q.get("value") is not None else ""),
                    "enabled": not bool(q.get("disabled", False)),
                    "description": _extract_desc(q.get("description")),
                })
        for v in raw_url_field.get("variable") or []:
            if isinstance(v, dict) and v.get("key"):
                path_vars.append({
                    "key": str(v.get("key")),
                    "value": str(v.get("value") if v.get("value") is not None else ""),
                    "enabled": True,
                    "description": _extract_desc(v.get("description")),
                })

    # Strip query string from base url_str if query params already extracted
    if "?" in url_str:
        base_part, qs_part = url_str.split("?", 1)
        if not params and qs_part:
            for k, v in urllib.parse.parse_qsl(qs_part, keep_blank_values=True):
                params.append({"key": k, "value": v, "enabled": True, "description": ""})
        url_str = base_part

    headers = []
    for h in req.get("header") or []:
        if isinstance(h, dict):
            headers.append({
                "key": str(h.get("key") or ""),
                "value": str(h.get("value") if h.get("value") is not None else ""),
                "enabled": not bool(h.get("disabled", False)),
                "description": _extract_desc(h.get("description")),
            })

    # Body
    raw_body = req.get("body") if isinstance(req.get("body"), dict) else {}
    bmode = str(raw_body.get("mode") or "none").lower()
    body = normalize_body({})
    if bmode == "raw":
        body["mode"] = "raw"
        body["raw"] = str(raw_body.get("raw") or "")
        lang = ((raw_body.get("options") or {}).get("raw") or {}).get("language") or "json"
        body["raw_type"] = str(lang).lower()
    elif bmode == "urlencoded":
        body["mode"] = "urlencoded"
        body["urlencoded"] = [
            {
                "key": str(r.get("key") or ""),
                "value": str(r.get("value") if r.get("value") is not None else ""),
                "enabled": not bool(r.get("disabled", False)),
                "description": _extract_desc(r.get("description")),
            }
            for r in (raw_body.get("urlencoded") or [])
            if isinstance(r, dict)
        ]
    elif bmode == "formdata":
        body["mode"] = "formdata"
        body["formdata"] = [
            {
                "key": str(r.get("key") or ""),
                "value": str(r.get("value") if r.get("value") is not None else ""),
                "type": "file" if str(r.get("type") or "").lower() == "file" else "text",
                "src": str(r.get("src") or "") if isinstance(r.get("src"), str) else "",
                "enabled": not bool(r.get("disabled", False)),
                "description": _extract_desc(r.get("description")),
            }
            for r in (raw_body.get("formdata") or [])
            if isinstance(r, dict)
        ]
    elif bmode == "graphql":
        gql = raw_body.get("graphql") if isinstance(raw_body.get("graphql"), dict) else {}
        body["mode"] = "graphql"
        body["graphql"] = {"query": str(gql.get("query") or ""), "variables": str(gql.get("variables") or "")}

    # Saved examples (Postman 'response' array)
    examples = []
    for resp in raw_item.get("response") or []:
        if not isinstance(resp, dict):
            continue
        ex_headers = []
        for h in resp.get("header") or []:
            if isinstance(h, dict) and h.get("key"):
                ex_headers.append({"key": str(h["key"]), "value": str(h.get("value") or "")})
        examples.append({
            "id": _new_id("ex"),
            "name": str(resp.get("name") or f"{resp.get('code') or 200} Response"),
            "status": int(resp.get("code") or 200),
            "status_text": str(resp.get("status") or _http_reason(int(resp.get("code") or 200))),
            "headers": ex_headers,
            "body": str(resp.get("body") if resp.get("body") is not None else ""),
            "created_at": _now_iso(),
        })

    # Parse simple pm.test status checks from event scripts
    tests = []
    for ev in raw_item.get("event") or []:
        if isinstance(ev, dict) and ev.get("listen") == "test":
            exec_lines = (ev.get("script") or {}).get("exec") or []
            script_text = "\n".join(exec_lines) if isinstance(exec_lines, list) else str(exec_lines)
            for m in re.finditer(r"have\.status\((\d{3})\)", script_text):
                tests.append({"type": "status_equals", "target": "", "value": m.group(1), "enabled": True})

    return {
        "id": _new_id("req"),
        "type": "request",
        "name": str(raw_item.get("name") or url_str or "Imported Request"),
        "description": _extract_desc(req.get("description") or raw_item.get("description")),
        "method": method,
        "url": url_str,
        "params": params,
        "path_variables": path_vars,
        "headers": headers,
        "auth": _parse_auth_v21(req.get("auth")),
        "body": body,
        "tests": tests,
        "extractors": [],
        "examples": examples,
    }


def _schema_to_sample(schema: Any, components: dict | None = None, depth: int = 0) -> Any:
    if depth > 4 or not isinstance(schema, dict):
        return ""
    if "$ref" in schema and isinstance(components, dict):
        ref_name = str(schema["$ref"]).split("/")[-1]
        resolved = (components.get("schemas") or {}).get(ref_name)
        if isinstance(resolved, dict):
            return _schema_to_sample(resolved, components, depth + 1)
    if "example" in schema:
        return schema["example"]
    stype = schema.get("type")
    if stype == "object" or "properties" in schema:
        obj = {}
        for prop, pschema in (schema.get("properties") or {}).items():
            obj[prop] = _schema_to_sample(pschema, components, depth + 1)
        return obj
    if stype == "array":
        return [_schema_to_sample(schema.get("items") or {}, components, depth + 1)]
    if stype == "integer":
        return 1
    if stype == "number":
        return 1.0
    if stype == "boolean":
        return True
    fmt = schema.get("format", "")
    if fmt == "email":
        return "user@example.com"
    if fmt == "date-time":
        return "2026-01-01T00:00:00Z"
    if fmt == "date":
        return "2026-01-01"
    return "string"


def import_openapi_json(spec: dict) -> dict:
    """Import an OpenAPI 3.x / Swagger 2.0 JSON spec into an internal Collection."""
    info = spec.get("info") or {}
    servers = spec.get("servers") or []
    base_url = ""
    if servers and isinstance(servers[0], dict):
        base_url = str(servers[0].get("url") or "").rstrip("/")
    elif spec.get("host"):
        scheme = (spec.get("schemes") or ["https"])[0]
        base_url = f"{scheme}://{spec['host']}{(spec.get('basePath') or '').rstrip('/')}"

    folders: dict[str, list[dict]] = {}
    root_items: list[dict] = []
    components = spec.get("components") or {}

    for path_str, path_item in (spec.get("paths") or {}).items():
        if not isinstance(path_item, dict):
            continue
        shared_params = path_item.get("parameters") or []
        for method_key, op in path_item.items():
            m = method_key.upper()
            if m not in VALID_METHODS or not isinstance(op, dict):
                continue
            q_params = []
            p_vars = []
            headers = [{"key": "Accept", "value": "application/json", "enabled": True, "description": ""}]
            for prm in list(shared_params) + list(op.get("parameters") or []):
                if not isinstance(prm, dict):
                    continue
                loc = str(prm.get("in") or "").lower()
                sample = str(prm.get("example") if prm.get("example") is not None else "")
                entry = {
                    "key": str(prm.get("name") or ""),
                    "value": sample,
                    "enabled": bool(prm.get("required", False)) or loc == "path",
                    "description": str(prm.get("description") or ""),
                }
                if loc == "query":
                    q_params.append(entry)
                elif loc == "path":
                    p_vars.append(entry)
                elif loc == "header":
                    headers.append(entry)

            body = normalize_body({})
            req_body = op.get("requestBody") or {}
            content = req_body.get("content") or {}
            if "application/json" in content:
                j_cfg = content["application/json"] or {}
                sample = j_cfg.get("example")
                if sample is None and isinstance(j_cfg.get("schema"), dict):
                    sample = _schema_to_sample(j_cfg["schema"], components)
                body["mode"] = "raw"
                body["raw_type"] = "json"
                body["raw"] = json.dumps(sample if sample is not None else {}, indent=2, ensure_ascii=False)
                headers.append({"key": "Content-Type", "value": "application/json", "enabled": True, "description": ""})

            examples = []
            for code_str, resp_spec in (op.get("responses") or {}).items():
                if not isinstance(resp_spec, dict) or not str(code_str).isdigit():
                    continue
                rc = resp_spec.get("content") or {}
                sample_body = ""
                if "application/json" in rc:
                    jc = rc["application/json"] or {}
                    ex_val = jc.get("example")
                    if ex_val is None and isinstance(jc.get("schema"), dict):
                        ex_val = _schema_to_sample(jc["schema"], components)
                    if ex_val is not None:
                        sample_body = json.dumps(ex_val, indent=2, ensure_ascii=False)
                examples.append({
                    "id": _new_id("ex"),
                    "name": f"{code_str} {resp_spec.get('description') or _http_reason(int(code_str))}".strip(),
                    "status": int(code_str),
                    "status_text": _http_reason(int(code_str)),
                    "headers": [{"key": "Content-Type", "value": "application/json"}],
                    "body": sample_body,
                    "created_at": _now_iso(),
                })

            req_node = {
                "id": _new_id("req"),
                "type": "request",
                "name": str(op.get("summary") or op.get("operationId") or f"{m} {path_str}"),
                "description": str(op.get("description") or ""),
                "method": m,
                "url": "{{base_url}}" + (path_str if path_str.startswith("/") else "/" + path_str),
                "params": q_params,
                "path_variables": p_vars,
                "headers": headers,
                "auth": {"type": "inherit"},
                "body": body,
                "tests": [],
                "extractors": [],
                "examples": examples,
            }
            tags = op.get("tags") or []
            if tags:
                folders.setdefault(str(tags[0]), []).append(req_node)
            else:
                root_items.append(req_node)

    items = [
        {"id": _new_id("fld"), "type": "folder", "name": fname, "description": "", "auth": {"type": "inherit"}, "items": fitems}
        for fname, fitems in folders.items()
    ] + root_items

    return normalize_collection({
        "id": _new_id("col"),
        "name": str(info.get("title") or "Imported OpenAPI"),
        "description": str(info.get("description") or ""),
        "variables": [{"key": "base_url", "value": base_url or "http://localhost", "enabled": True, "description": "API Base URL"}],
        "items": items,
    })


def parse_curl_command(curl_str: str) -> dict:
    """Parse a cURL command string into an internal request item."""
    cleaned = re.sub(r"\\\r?\n", " ", curl_str.strip())
    tokens = shlex.split(cleaned)
    if not tokens:
        raise ValueError("Empty cURL command")
    if tokens[0].lower() == "curl":
        tokens = tokens[1:]

    method = ""
    url = ""
    headers: list[dict] = []
    auth: dict[str, Any] = {"type": "none"}
    body_parts: list[str] = []
    form_fields: list[dict] = []
    urlencoded_fields: list[dict] = []

    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok in ("-X", "--request") and i + 1 < len(tokens):
            method = tokens[i + 1].upper()
            i += 2
        elif tok in ("-H", "--header") and i + 1 < len(tokens):
            hdr = tokens[i + 1]
            if ":" in hdr:
                hk, hv = hdr.split(":", 1)
                hks, hvs = hk.strip(), hv.strip()
                if hks.lower() == "authorization" and hvs.lower().startswith("bearer "):
                    auth = {"type": "bearer", "token": hvs[7:].strip()}
                else:
                    headers.append({"key": hks, "value": hvs, "enabled": True, "description": ""})
            i += 2
        elif tok in ("-d", "--data", "--data-raw", "--data-binary", "--data-ascii") and i + 1 < len(tokens):
            body_parts.append(tokens[i + 1])
            i += 2
        elif tok == "--data-urlencode" and i + 1 < len(tokens):
            pair = tokens[i + 1]
            k, v = pair.split("=", 1) if "=" in pair else (pair, "")
            urlencoded_fields.append({"key": k, "value": v, "enabled": True, "description": ""})
            i += 2
        elif tok in ("-F", "--form") and i + 1 < len(tokens):
            pair = tokens[i + 1]
            k, v = pair.split("=", 1) if "=" in pair else (pair, "")
            if v.startswith("@"):
                form_fields.append({"key": k, "value": "", "type": "file", "src": v[1:], "enabled": True, "description": ""})
            else:
                form_fields.append({"key": k, "value": v, "type": "text", "src": "", "enabled": True, "description": ""})
            i += 2
        elif tok in ("-u", "--user") and i + 1 < len(tokens):
            u, p = tokens[i + 1].split(":", 1) if ":" in tokens[i + 1] else (tokens[i + 1], "")
            auth = {"type": "basic", "username": u, "password": p}
            i += 2
        elif tok in ("--url",) and i + 1 < len(tokens):
            url = tokens[i + 1]
            i += 2
        elif tok.startswith("-"):
            # Skip unknown flag (and its arg if common curl flag with value)
            if tok in ("-A", "--user-agent", "-e", "--referer", "-o", "--output", "-m", "--max-time", "--connect-timeout"):
                i += 2
            else:
                i += 1
        else:
            if not url and (tok.startswith("http://") or tok.startswith("https://") or "/" in tok or "." in tok):
                url = tok
            i += 1

    if not url:
        raise ValueError("Could not find a URL in the cURL command")

    body = normalize_body({})
    if form_fields:
        body["mode"] = "formdata"
        body["formdata"] = form_fields
        method = method or "POST"
    elif urlencoded_fields:
        body["mode"] = "urlencoded"
        body["urlencoded"] = urlencoded_fields
        method = method or "POST"
    elif body_parts:
        raw_text = "&".join(body_parts)
        body["mode"] = "raw"
        body["raw"] = raw_text
        body["raw_type"] = "json" if raw_text.lstrip().startswith(("{", "[")) else "text"
        method = method or "POST"
    method = method or "GET"

    params = []
    clean_url = url
    if "?" in url:
        clean_url, qs = url.split("?", 1)
        for k, v in urllib.parse.parse_qsl(qs, keep_blank_values=True):
            params.append({"key": k, "value": v, "enabled": True, "description": ""})

    parsed = urllib.parse.urlsplit(clean_url if "://" in clean_url else "http://" + clean_url)
    name = f"{method} {parsed.path or '/'}"
    return normalize_item({
        "id": _new_id("req"),
        "type": "request",
        "name": name,
        "method": method,
        "url": clean_url,
        "params": params,
        "headers": headers,
        "auth": auth,
        "body": body,
    })


def import_payload(raw_text: str) -> dict:
    """Auto-detect and import Postman Collection v2.0/v2.1, Postman Environment, OpenAPI 3.0, or cURL."""
    text = (raw_text or "").strip()
    if not text:
        raise ValueError("Nothing to import")

    if text.lower().startswith("curl "):
        req = parse_curl_command(text)
        return {"kind": "request", "request": req}

    try:
        data = json.loads(text)
    except Exception as exc:
        raise ValueError(f"Invalid JSON input: {exc}")

    if not isinstance(data, dict):
        raise ValueError("Imported JSON must be an object")

    # Postman Environment
    if data.get("_postman_variable_scope") == "environment" or (
        isinstance(data.get("values"), list) and "item" not in data and "paths" not in data
    ):
        env = normalize_environment({
            "id": _new_id("env"),
            "name": str(data.get("name") or "Imported Environment"),
            "variables": [
                {
                    "id": _new_id("var"),
                    "key": str(v.get("key") or ""),
                    "value": str(v.get("value") if v.get("value") is not None else ""),
                    "enabled": bool(v.get("enabled", True)),
                    "secret": str(v.get("type") or "").lower() == "secret",
                    "description": "",
                }
                for v in (data.get("values") or [])
                if isinstance(v, dict) and v.get("key")
            ],
        })
        return {"kind": "environment", "environment": env}

    # OpenAPI 3.x / Swagger 2.0
    if "openapi" in data or "swagger" in data or ("paths" in data and isinstance(data["paths"], dict)):
        return {"kind": "collection", "collection": import_openapi_json(data)}

    # Postman Collection v2.0 / v2.1
    if "info" in data and isinstance(data.get("item"), list):
        info = data.get("info") or {}
        variables = []
        for v in data.get("variable") or []:
            if isinstance(v, dict) and v.get("key"):
                variables.append({
                    "key": str(v["key"]),
                    "value": str(v.get("value") if v.get("value") is not None else ""),
                    "enabled": not bool(v.get("disabled", False)),
                    "description": _extract_desc(v.get("description")),
                })
        col = normalize_collection({
            "id": _new_id("col"),
            "name": str(info.get("name") or "Imported Collection"),
            "description": _extract_desc(info.get("description")),
            "auth": _parse_auth_v21(data.get("auth")) if data.get("auth") else {"type": "none"},
            "variables": variables,
            "items": [_parse_postman_item(it) for it in data.get("item", []) if isinstance(it, dict)],
        })
        return {"kind": "collection", "collection": col}

    # Native Laravel Dev Collection format
    if isinstance(data.get("items"), list) and data.get("name"):
        col = normalize_collection({**data, "id": _new_id("col")})
        return {"kind": "collection", "collection": col}

    raise ValueError("Unrecognized format. Supported: Postman Collection v2.0/v2.1, Postman Environment, OpenAPI 3.0 JSON, or cURL.")


# ── Generate Collection from Laravel Routes (with Body & Header Inspection) ───

_IGNORED_ROUTE_PREFIXES = (
    "_ignition", "_debugbar", "telescope", "horizon", "livewire",
    "__clockwork", "sanctum/csrf-cookie", "up", "storage/",
)

_IGNORED_REQUEST_PROPS = frozenset({
    "user", "route", "headers", "query", "cookies", "files", "attributes",
    "server", "request", "session", "method", "path", "url", "ip", "ips",
    "all", "validated", "safe", "input", "post", "get", "only", "except",
    "filled", "has", "hasAny", "missing", "boolean", "integer", "float",
    "string", "date", "enum", "array", "collect", "file", "hasFile",
    "header", "hasHeader", "bearerToken", "expectsJson", "wantsJson",
    "ajax", "pjax", "secure", "host", "httpHost", "schemeAndHttpHost",
    "fullUrl", "root", "segments", "segment", "fingerprint", "validate",
    "validateWithBag", "merge", "replace", "flash", "old", "cookie",
    "setUserResolver", "getUserResolver", "setRouteResolver", "getRouteResolver",
    "content", "json", "isMethod", "routeIs", "is",
})


def _strip_php_comments(code: str) -> str:
    """Strip //, #, and /* ... */ PHP comments while keeping quoted strings intact."""
    out: list[str] = []
    i = 0
    n = len(code)
    in_quote = ""
    while i < n:
        ch = code[i]
        if in_quote:
            out.append(ch)
            if ch == "\\" and i + 1 < n:
                out.append(code[i + 1])
                i += 2
                continue
            if ch == in_quote:
                in_quote = ""
            i += 1
        elif ch in ("'", '"'):
            in_quote = ch
            out.append(ch)
            i += 1
        elif code.startswith("//", i):
            while i < n and code[i] != "\n":
                i += 1
        elif ch == "#" and not code.startswith("#[", i):
            while i < n and code[i] != "\n":
                i += 1
        elif code.startswith("/*", i):
            end = code.find("*/", i + 2)
            i = n if end == -1 else end + 2
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def _extract_balanced_block(text: str, start_idx: int, open_ch: str, close_ch: str) -> str | None:
    """Given index of open_ch ('[' or '{' or '('), return the inner substring."""
    if start_idx < 0 or start_idx >= len(text) or text[start_idx] != open_ch:
        return None
    depth = 0
    in_quote = ""
    i = start_idx
    n = len(text)
    while i < n:
        ch = text[i]
        if in_quote:
            if ch == "\\" and i + 1 < n:
                i += 2
                continue
            if ch == in_quote:
                in_quote = ""
        elif ch in ("'", '"'):
            in_quote = ch
        elif ch == open_ch:
            depth += 1
        elif ch == close_ch:
            depth -= 1
            if depth == 0:
                return text[start_idx + 1 : i]
        i += 1
    return None


def _split_top_level_commas(text: str) -> list[str]:
    parts: list[str] = []
    buf: list[str] = []
    depth_sq = depth_par = depth_cur = 0
    in_quote = ""
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if in_quote:
            buf.append(ch)
            if ch == "\\" and i + 1 < n:
                buf.append(text[i + 1])
                i += 2
                continue
            if ch == in_quote:
                in_quote = ""
        elif ch in ("'", '"'):
            in_quote = ch
            buf.append(ch)
        elif ch == "[":
            depth_sq += 1
            buf.append(ch)
        elif ch == "]":
            depth_sq = max(0, depth_sq - 1)
            buf.append(ch)
        elif ch == "(":
            depth_par += 1
            buf.append(ch)
        elif ch == ")":
            depth_par = max(0, depth_par - 1)
            buf.append(ch)
        elif ch == "{":
            depth_cur += 1
            buf.append(ch)
        elif ch == "}":
            depth_cur = max(0, depth_cur - 1)
            buf.append(ch)
        elif ch == "," and depth_sq == 0 and depth_par == 0 and depth_cur == 0:
            item = "".join(buf).strip()
            if item:
                parts.append(item)
            buf = []
        else:
            buf.append(ch)
        i += 1
    tail = "".join(buf).strip()
    if tail:
        parts.append(tail)
    return parts


def _parse_rule_tokens(expr: str) -> list[str]:
    """Parse Laravel validation rule expression (string or array) into clean rule tokens."""
    expr = expr.strip()
    tokens: list[str] = []
    if not expr:
        return tokens
    # Single quoted/double quoted string like 'required|email|max:255'
    m_str = re.match(r"""^(['"])(.*)\1$""", expr, re.S)
    if m_str:
        return [tok.strip() for tok in m_str.group(2).split("|") if tok.strip()]
    # Array syntax like ['required', 'string', Rule::in(['a', 'b'])]
    if expr.startswith("[") and expr.endswith("]"):
        inner = expr[1:-1]
        for elem in _split_top_level_commas(inner):
            ms = re.match(r"""^(['"])(.*)\1$""", elem.strip(), re.S)
            if ms:
                for sub in ms.group(2).split("|"):
                    if sub.strip():
                        tokens.append(sub.strip())
            else:
                # Handle Rule::in(['a', 'b'])
                m_in = re.search(r"Rule::in\(\s*\[([^\]]+)\]", elem)
                if m_in:
                    vals = re.findall(r"""['"]([^'"]+)['"]""", m_in.group(1))
                    if vals:
                        tokens.append("in:" + ",".join(vals))
                elif "Rule::unique" in elem:
                    tokens.append("unique")
                elif "Rule::exists" in elem:
                    tokens.append("exists")
                elif "Password::" in elem:
                    tokens.append("password")
                elif elem.strip():
                    tokens.append(elem.strip())
        return tokens
    # Fallback: extract quoted fragments inside expressions like 'required|string|' . ...
    for frag in re.findall(r"""['"]([^'"]+)['"]""", expr):
        for sub in frag.split("|"):
            if sub.strip():
                tokens.append(sub.strip())
    return tokens


def _parse_php_rules_array(array_body: str) -> dict[str, list[str]]:
    """Parse top-level 'field' => rules entries from inside a PHP [...] array."""
    rules: dict[str, list[str]] = {}
    for entry in _split_top_level_commas(array_body):
        m = re.match(r"""^\s*['"]([a-zA-Z0-9_.*\-]+)['"]\s*=>\s*(.+)$""", entry, re.S)
        if not m:
            continue
        field = m.group(1).strip()
        val_expr = m.group(2).strip()
        parsed = _parse_rule_tokens(val_expr)
        rules[field] = parsed
    return rules


def _extract_validation_rules_from_php(code: str, include_rules_method: bool = False) -> dict[str, list[str]]:
    """Extract validation rules from FormRequest::rules(), $request->validate([...]),
    $this->validate($request, [...]), and Validator::make(..., [...])."""
    clean = _strip_php_comments(code)
    found: dict[str, list[str]] = {}

    if include_rules_method:
        for m in re.finditer(r"\bfunction\s+rules\s*\([^)]*\)[^{]*\{", clean):
            fn_body = _extract_balanced_block(clean, m.end() - 1, "{", "}")
            if not fn_body:
                continue
            for rm in re.finditer(r"\breturn\s*\[", fn_body):
                arr = _extract_balanced_block(fn_body, rm.end() - 1, "[", "]")
                if arr:
                    found.update(_parse_php_rules_array(arr))

    # ->validate([ ... ]) or ->validateWithBag('bag', [ ... ]) or ->validate($req, [ ... ])
    for m in re.finditer(r"->validate(?:WithBag)?\s*\(", clean):
        args_str = _extract_balanced_block(clean, m.end() - 1, "(", ")")
        if not args_str:
            continue
        for arg in _split_top_level_commas(args_str):
            s = arg.strip()
            if s.startswith("[") and s.endswith("]"):
                found.update(_parse_php_rules_array(s[1:-1]))
                break

    # Validator::make($data, [ ... ])
    for m in re.finditer(r"Validator::make\s*\(", clean):
        args_str = _extract_balanced_block(clean, m.end() - 1, "(", ")")
        if not args_str:
            continue
        args = _split_top_level_commas(args_str)
        if len(args) >= 2:
            s = args[1].strip()
            if s.startswith("[") and s.endswith("]"):
                found.update(_parse_php_rules_array(s[1:-1]))

    # Auto-add <field>_confirmation when 'confirmed' rule is present
    extras: dict[str, list[str]] = {}
    for field, rlist in found.items():
        if any(tok.lower() == "confirmed" for tok in rlist):
            conf = f"{field}_confirmation"
            if conf not in found:
                extras[conf] = ["required", f"same:{field}"]
    found.update(extras)
    return found


def _extract_request_fields_and_headers_from_php(
    code: str,
    source_label: str = "",
    extract_body: bool = True,
) -> dict[str, Any]:
    """Scan PHP source snippet for request headers, body/input fields, query params, and files."""
    clean = _strip_php_comments(code)
    headers: dict[str, dict[str, str]] = {}
    body_fields: dict[str, str] = {}   # field -> hinted type
    query_fields: dict[str, str] = {}  # field -> default value
    file_fields: set[str] = set()
    uses_bearer = False

    def _add_header(name: str, default_val: str = ""):
        clean_name = name.strip()
        if not clean_name:
            return
        low = clean_name.lower()
        if low in ("host", "content-length", "connection", "user-agent"):
            return
        if low not in headers:
            headers[low] = {"key": clean_name, "value": default_val, "source": source_label}
        elif default_val and not headers[low]["value"]:
            headers[low]["value"] = default_val

    # 1. Headers: $request->header('X-Foo', 'bar'), request()->header('X-Foo'), $request->headers->get('X-Foo'), hasHeader('X-Foo')
    for m in re.finditer(
        r"""(?:->header|->headers->get|->headers->has|->hasHeader)\s*\(\s*['"]([A-Za-z0-9_\-]+)['"](?:\s*,\s*['"]([^'"]*)['"])?""",
        clean,
    ):
        _add_header(m.group(1), m.group(2) or "")

    # $_SERVER['HTTP_X_TENANT_ID'] -> X-Tenant-Id
    for m in re.finditer(r"""\$_SERVER\s*\[\s*['"]HTTP_([A-Z0-9_]+)['"]\s*\]""", clean):
        hdr_name = "-".join(part.capitalize() for part in m.group(1).split("_"))
        _add_header(hdr_name, "")

    if re.search(r"->bearerToken\s*\(", clean):
        uses_bearer = True

    if extract_body:
        # 2. Query params: ->query('page', '1')
        for m in re.finditer(r"""->query\s*\(\s*['"]([a-zA-Z0-9_.\-]+)['"](?:\s*,\s*['"]?([^'",)\s]+)['"]?)?""", clean):
            qname = m.group(1)
            qdef = m.group(2) or ""
            if qdef.lower() in ("null", "false"):
                qdef = ""
            query_fields.setdefault(qname, qdef)

        # 3. File uploads: ->file('avatar'), ->hasFile('doc')
        for m in re.finditer(r"""->(?:file|hasFile)\s*\(\s*['"]([a-zA-Z0-9_.*\-]+)['"]""", clean):
            file_fields.add(m.group(1))

        # 4. Typed / direct input methods: ->input('x'), ->post('x'), ->integer('x'), ->boolean('x'), ->string('x'), ...
        typed_methods = (
            ("input", "string"), ("post", "string"), ("validated", "string"),
            ("string", "string"), ("str", "string"), ("integer", "integer"),
            ("float", "numeric"), ("boolean", "boolean"), ("date", "date"),
            ("array", "array"), ("enum", "string"), ("filled", "string"),
            ("has", "string"), ("get", "string"),
        )
        for mname, hint_type in typed_methods:
            for m in re.finditer(rf"""->{mname}\s*\(\s*['"]([a-zA-Z0-9_.*\-]+)['"]""", clean):
                fname = m.group(1)
                if fname not in body_fields:
                    body_fields[fname] = hint_type

        # ->only(['a', 'b']) or ->only('a', 'b') or ->hasAny(['a', 'b'])
        for m in re.finditer(r"->(?:only|hasAny)\s*\(([^)]+)\)", clean):
            for fname in re.findall(r"""['"]([a-zA-Z0-9_.\-]+)['"]""", m.group(1)):
                body_fields.setdefault(fname, "string")

        # request('field')
        for m in re.finditer(r"""\brequest\s*\(\s*['"]([a-zA-Z0-9_.\-]+)['"]""", clean):
            body_fields.setdefault(m.group(1), "string")

        # Direct magic property access $request->email (not followed by '(')
        for m in re.finditer(r"\$request->([a-zA-Z_][a-zA-Z0-9_]*)\b(?!\s*\()", clean):
            prop = m.group(1)
            if prop not in _IGNORED_REQUEST_PROPS:
                body_fields.setdefault(prop, "string")

    return {
        "headers": list(headers.values()),
        "body_fields": body_fields,
        "query_fields": query_fields,
        "file_fields": file_fields,
        "uses_bearer": uses_bearer,
    }


def _sample_value_for_field(field_name: str, rules: list[str], hint_type: str = "string") -> Any:
    """Produce a sensible JSON sample value for a Laravel field based on rules & field name."""
    low_rules = [r.lower() for r in (rules or [])]
    low_name = field_name.split(".")[-1].lower()

    for r in low_rules:
        if r.startswith("in:"):
            opts = [o.strip() for o in r[3:].split(",") if o.strip()]
            if opts:
                return opts[0]
    if any(r in ("boolean", "bool", "accepted") for r in low_rules) or hint_type == "boolean" or low_name.startswith(("is_", "has_", "can_")):
        return True
    if any(r in ("integer", "int", "digits") or r.startswith("digits:") for r in low_rules) or hint_type == "integer" or low_name == "id" or low_name.endswith("_id"):
        return 1
    if any(r in ("numeric", "decimal") or r.startswith("decimal:") for r in low_rules) or hint_type == "numeric" or any(k in low_name for k in ("price", "amount", "total", "cost", "rate")):
        return 10.5
    if any(r == "array" for r in low_rules) or hint_type == "array":
        return []
    if any(r == "email" or r.startswith("email:") for r in low_rules) or "email" in low_name:
        return "user@example.com"
    if any(r == "url" or r.startswith("url:") for r in low_rules) or low_name.endswith("_url") or low_name in ("url", "website"):
        return "https://example.com"
    if any(r == "uuid" for r in low_rules) or "uuid" in low_name:
        return "{{$guid}}"
    if any(r == "date" or r.startswith("date_format:") for r in low_rules) or hint_type == "date" or low_name.endswith("_at") or low_name.endswith("_date"):
        return "2026-01-01"
    if "password" in low_name or any(r == "password" for r in low_rules):
        return "password123"
    if "phone" in low_name or "mobile" in low_name:
        return "+1234567890"
    if "name" in low_name:
        return "Sample Name"
    if "title" in low_name:
        return "Sample Title"
    return f"sample_{low_name}"


def _set_nested_sample(target: dict, dotted_key: str, value: Any) -> None:
    """Populate nested dicts/arrays for Laravel dot notation like 'address.city' or 'items.*.qty'."""
    parts = [p for p in dotted_key.split(".") if p]
    if not parts:
        return
    cur: Any = target
    for i, part in enumerate(parts):
        is_last = i == len(parts) - 1
        next_part = parts[i + 1] if not is_last else None

        if part == "*":
            if isinstance(cur, list):
                if not cur:
                    cur.append({} if next_part and next_part != "*" else value)
                if is_last:
                    cur[0] = value
                else:
                    if not isinstance(cur[0], (dict, list)):
                        cur[0] = {}
                    cur = cur[0]
            continue

        if not isinstance(cur, dict):
            return

        if is_last:
            # Don't overwrite a populated nested dict/list with an empty [] from parent 'items' => 'array' rule
            if part in cur and isinstance(cur[part], (dict, list)) and value in ([], {}):
                return
            cur[part] = value
        else:
            if next_part == "*":
                if part not in cur or not isinstance(cur[part], list):
                    cur[part] = [{}]
                cur = cur[part]
            else:
                if part not in cur or not isinstance(cur[part], dict):
                    cur[part] = {}
                cur = cur[part]


def _resolve_php_class_to_file(class_name: str, site_path: Path | None) -> Path | None:
    if not site_path or not class_name:
        return None
    clean = class_name.lstrip("\\")
    if clean.startswith("App\\"):
        rel = clean[4:].replace("\\", "/") + ".php"
        cand = site_path / "app" / rel
        if cand.is_file():
            return cand
    return None


def _slice_php_method(file_path: Path, start_line: int | None, end_line: int | None, method_name: str = "") -> str:
    try:
        text = file_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    lines = text.splitlines()
    if start_line and start_line >= 1:
        s_idx = start_line - 1
        e_idx = end_line if (end_line and end_line >= start_line) else min(len(lines), s_idx + 120)
        return "\n".join(lines[s_idx:e_idx])
    if method_name:
        m = re.search(rf"\bfunction\s+{re.escape(method_name)}\s*\([^)]*\)[^{{]*\{{", text)
        if m:
            body = _extract_balanced_block(text, m.end() - 1, "{", "}")
            if body is not None:
                return text[m.start() : m.end()] + body + "}"
    return text


def _discover_form_request_files_from_signature(controller_file: Path, method_snippet: str, site_path: Path | None) -> list[Path]:
    """Fallback static resolution of type-hinted FormRequest classes from controller `use` imports."""
    if not site_path or not controller_file.is_file():
        return []
    try:
        full_src = controller_file.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    m_sig = re.search(r"\bfunction\s+[a-zA-Z0-9_]+\s*\(([^)]*)\)", method_snippet)
    if not m_sig:
        return []
    params_sig = m_sig.group(1)
    # Build use-import map
    imports: dict[str, str] = {}
    for um in re.finditer(r"^\s*use\s+([A-Za-z0-9_\\]+)(?:\s+as\s+([A-Za-z0-9_]+))?\s*;", full_src, re.M):
        fqcn = um.group(1).lstrip("\\")
        alias = um.group(2) or fqcn.split("\\")[-1]
        imports[alias] = fqcn
    ns_match = re.search(r"^\s*namespace\s+([A-Za-z0-9_\\]+)\s*;", full_src, re.M)
    cur_ns = ns_match.group(1) if ns_match else ""

    found: list[Path] = []
    for pm in re.finditer(r"(?:^|,)\s*\??([A-Za-z0-9_\\]+)\s+\$[a-zA-Z_][a-zA-Z0-9_]*", params_sig):
        tname = pm.group(1)
        if tname in ("Request", "string", "int", "float", "bool", "array", "mixed"):
            continue
        fqcn = imports.get(tname) or (tname if "\\" in tname else (f"{cur_ns}\\{tname}" if cur_ns else tname))
        cand = _resolve_php_class_to_file(fqcn, site_path)
        if cand and cand not in found:
            found.append(cand)
    return found


def inspect_laravel_route(route: dict, site_path: str | Path | None = None) -> dict:
    """Inspect a Laravel route's Controller method, FormRequest classes, and Middleware files
    to extract body fields (with validation rules), query params, file upload fields, and headers."""
    root_path = Path(site_path).resolve() if site_path else None
    action = str(route.get("action") or "")
    ctrl_file: Path | None = None
    method_name = ""

    if route.get("file"):
        cand = Path(str(route["file"]))
        if cand.is_file() and "/vendor/" not in str(cand).replace("\\", "/"):
            ctrl_file = cand
    if "@" in action:
        cls_name, method_name = action.split("@", 1)
        if ctrl_file is None:
            ctrl_file = _resolve_php_class_to_file(cls_name, root_path)
    elif action and action != "Closure" and ctrl_file is None:
        ctrl_file = _resolve_php_class_to_file(action, root_path)
        method_name = "__invoke"

    all_rules: dict[str, list[str]] = {}
    headers_map: dict[str, dict[str, str]] = {}
    body_hints: dict[str, str] = {}
    query_fields: dict[str, str] = {}
    file_fields: set[str] = set()
    uses_bearer = False

    def _merge_scan(scan: dict[str, Any]):
        nonlocal uses_bearer
        if scan.get("uses_bearer"):
            uses_bearer = True
        for h in scan.get("headers") or []:
            low = h["key"].lower()
            if low not in headers_map:
                headers_map[low] = dict(h)
            elif h.get("value") and not headers_map[low].get("value"):
                headers_map[low]["value"] = h["value"]
        for k, v in (scan.get("body_fields") or {}).items():
            body_hints.setdefault(k, v)
        for k, v in (scan.get("query_fields") or {}).items():
            query_fields.setdefault(k, v)
        file_fields.update(scan.get("file_fields") or set())

    # 1. Inspect Controller method
    method_snippet = ""
    form_req_paths: list[Path] = []
    for raw_fr in (route.get("form_request_files") or []):
        p = Path(str(raw_fr))
        if p.is_file() and "/vendor/" not in str(p).replace("\\", "/") and p not in form_req_paths:
            form_req_paths.append(p)

    if ctrl_file and ctrl_file.is_file():
        method_snippet = _slice_php_method(ctrl_file, route.get("line"), route.get("end_line"), method_name=method_name)
        if method_snippet:
            all_rules.update(_extract_validation_rules_from_php(method_snippet, include_rules_method=False))
            _merge_scan(_extract_request_fields_and_headers_from_php(method_snippet, source_label=ctrl_file.stem, extract_body=True))
            if not form_req_paths:
                form_req_paths.extend(_discover_form_request_files_from_signature(ctrl_file, method_snippet, root_path))

    # 2. Inspect FormRequest classes
    for fr_path in form_req_paths:
        try:
            fr_src = fr_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        all_rules.update(_extract_validation_rules_from_php(fr_src, include_rules_method=True))
        _merge_scan(_extract_request_fields_and_headers_from_php(fr_src, source_label=fr_path.stem, extract_body=True))

    # 3. Inspect app Middleware files (headers & bearer token usage only, not body)
    mw_paths: list[Path] = []
    for raw_mw in (route.get("middleware_files") or []):
        p = Path(str(raw_mw))
        if p.is_file() and "/vendor/" not in str(p).replace("\\", "/") and p not in mw_paths:
            mw_paths.append(p)
    # Fallback: resolve any FQCN middleware listed directly in route["middleware"]
    if not mw_paths and root_path:
        for mw in (route.get("middleware") or []):
            base_mw = str(mw).split(":", 1)[0]
            if "\\" in base_mw:
                cand = _resolve_php_class_to_file(base_mw, root_path)
                if cand and cand not in mw_paths:
                    mw_paths.append(cand)

    for mw_path in mw_paths:
        try:
            mw_src = mw_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        _merge_scan(_extract_request_fields_and_headers_from_php(mw_src, source_label=mw_path.stem, extract_body=False))

    # Detect file fields from validation rules (file, image, mimes:, mimetypes:)
    for field, rlist in all_rules.items():
        if any(tok.lower() in ("file", "image") or tok.lower().startswith(("mimes:", "mimetypes:", "extensions:")) for tok in rlist):
            file_fields.add(field)

    # Combine fields from validation rules + direct request input access
    combined_fields: dict[str, dict[str, Any]] = {}
    for field, rlist in all_rules.items():
        combined_fields[field] = {
            "name": field,
            "rules": rlist,
            "required": any(tok.lower() == "required" for tok in rlist),
            "is_file": field in file_fields,
            "sample": _sample_value_for_field(field, rlist),
        }
    for field, htype in body_hints.items():
        if field not in combined_fields:
            combined_fields[field] = {
                "name": field,
                "rules": [htype] if htype else [],
                "required": False,
                "is_file": field in file_fields,
                "sample": _sample_value_for_field(field, [], hint_type=htype),
            }
    for ffield in sorted(file_fields):
        if ffield not in combined_fields:
            combined_fields[ffield] = {
                "name": ffield,
                "rules": ["file"],
                "required": False,
                "is_file": True,
                "sample": "",
            }

    return {
        "fields": list(combined_fields.values()),
        "query_fields": query_fields,
        "headers": list(headers_map.values()),
        "has_files": bool(file_fields),
        "uses_bearer": uses_bearer,
    }


def _extract_static_path_segments(url_or_uri: str) -> list[str]:
    """Extract all static path segments (skipping {param}/:param), stripping base URL & leading 'api'."""
    raw = str(url_or_uri or "").strip()
    # Strip query string / fragment
    raw = raw.split("?", 1)[0].split("#", 1)[0]
    # Strip scheme://host or leading {{base_url}}
    raw = re.sub(r"^https?://[^/]+", "", raw, flags=re.I)
    raw = re.sub(r"^\{\{[^}]+\}\}", "", raw)
    raw = raw.strip("/")
    if not raw:
        return []
    parts = [p for p in raw.split("/") if p]
    if len(parts) > 1 and parts[0].lower() == "api":
        parts = parts[1:]
    return [
        seg for seg in parts
        if not ((seg.startswith("{") and seg.endswith("}")) or seg.startswith(":"))
    ]


def _flat_folder_name_from_url(url_or_uri: str) -> str:
    segs = _extract_static_path_segments(url_or_uri)
    cleaned = [s for s in segs if not re.match(r"^v\d+$", s, re.I)]
    if cleaned:
        return cleaned[0].replace("-", " ").replace("_", " ").title()
    if segs:
        return segs[0].upper()
    return ""


def _build_nested_tree_from_requests(requests: list[dict]) -> list[dict]:
    """Group all API requests into nested folders matching every static URL segment
    (e.g. v1 -> admin -> products, v1 -> products -> reviews, v1 -> auth -> login)."""
    root_node: dict[str, Any] = {"folders": {}, "requests": []}

    for req in requests:
        segs = _extract_static_path_segments(req.get("url") or "")
        node = root_node
        for seg in segs:
            if seg not in node["folders"]:
                node["folders"][seg] = {"name": seg, "folders": {}, "requests": []}
            node = node["folders"][seg]
        node["requests"].append(req)

    def _to_items(node: dict[str, Any], path_prefix: str = "") -> list[dict]:
        out: list[dict] = []
        for fname in sorted(node["folders"].keys(), key=lambda s: s.lower()):
            child = node["folders"][fname]
            full_path = f"{path_prefix}/{fname}" if path_prefix else fname
            out.append({
                "id": _new_id("fld"),
                "type": "folder",
                "name": fname,
                "description": f"Endpoints under `/{full_path}`",
                "auth": {"type": "inherit"},
                "items": _to_items(child, full_path),
            })
        out.extend(node["requests"])
        return out

    return _to_items(root_node)


def _build_flat_tree_from_requests(requests: list[dict]) -> list[dict]:
    """Group requests into single-level Title Case folders (classic layout)."""
    folders: dict[str, list[dict]] = {}
    root_items: list[dict] = []
    for req in requests:
        fname = _flat_folder_name_from_url(req.get("url") or "")
        if fname:
            folders.setdefault(fname, []).append(req)
        else:
            root_items.append(req)
    return [
        {
            "id": _new_id("fld"),
            "type": "folder",
            "name": fname,
            "description": f"Endpoints under `{fname}`",
            "auth": {"type": "inherit"},
            "items": fitems,
        }
        for fname, fitems in sorted(folders.items())
    ] + root_items


def reorganize_collection(collection: dict, folder_mode: str = "original") -> dict:
    """Return a copy of collection with items reorganized as 'nested', 'flat', or 'original'."""
    col = normalize_collection(collection)
    mode = str(folder_mode or "original").lower()
    if mode not in ("nested", "flat"):
        return col
    all_reqs: list[dict] = []

    def _collect(items: list[dict]) -> None:
        for it in items or []:
            if it.get("type") == "folder":
                _collect(it.get("items") or [])
            else:
                all_reqs.append(it)

    _collect(col.get("items") or [])
    col["items"] = _build_nested_tree_from_requests(all_reqs) if mode == "nested" else _build_flat_tree_from_requests(all_reqs)
    return col


def generate_collection_from_routes(
    site_name: str,
    site_url: str,
    routes: list[dict],
    api_only: bool = True,
    site_path: str | Path | None = None,
    folder_mode: str = "nested",
) -> dict:
    """Convert Laravel routes list into an organized API Collection with nested or flat folders,
    path params, and automatically inspected body fields & headers."""
    built_requests: list[dict] = []
    total_body_fields = 0
    total_detected_headers = 0

    for r in routes or []:
        uri = str(r.get("uri") or "").strip().lstrip("/")
        if not uri:
            if api_only:
                continue
        if any(uri.startswith(p) for p in _IGNORED_ROUTE_PREFIXES):
            continue

        middleware = [str(m) for m in (r.get("middleware") or [])]
        is_api = uri.startswith("api/") or uri == "api" or any("api" in m.lower() for m in middleware)
        if api_only and not is_api:
            continue

        methods = [m.strip().upper() for m in str(r.get("method") or "GET").split("|") if m.strip().upper() in VALID_METHODS]
        if not methods:
            methods = ["GET"]
        primary_method = methods[0]

        # Extract Laravel {param} or {param?}
        path_vars = []
        path_var_names: set[str] = set()
        for match in re.finditer(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\??\}", uri):
            pname = match.group(1)
            path_var_names.add(pname)
            path_vars.append({
                "key": pname,
                "value": "1" if pname.endswith("id") or pname == "id" else f"sample-{pname}",
                "enabled": True,
                "description": f"Path parameter `{pname}`",
            })

        # Deep source inspection (Controller + FormRequest + Middleware)
        inspected = inspect_laravel_route(r, site_path=site_path)
        fields = [f for f in inspected["fields"] if f["name"] not in path_var_names]
        detected_headers = inspected["headers"]
        detected_query = inspected["query_fields"]

        has_auth = any("auth" in m.lower() for m in middleware) or inspected["uses_bearer"]
        req_auth = {"type": "bearer", "token": "{{token}}"} if has_auth else {"type": "inherit"}

        # Build Headers (base Accept + discovered headers from Controller/FormRequest/Middleware)
        headers = [{"key": "Accept", "value": "application/json", "enabled": True, "description": "Request JSON response"}]
        seen_hdrs = {"accept"}
        for dh in detected_headers:
            hlow = dh["key"].lower()
            if hlow in seen_hdrs:
                continue
            if hlow == "authorization" and has_auth:
                continue
            seen_hdrs.add(hlow)
            total_detected_headers += 1
            src_note = f"Detected in {dh['source']}" if dh.get("source") else "Detected in route"
            headers.append({
                "key": dh["key"],
                "value": dh.get("value") or "",
                "enabled": True,
                "description": src_note,
            })

        # Build Query Params & Request Body
        params: list[dict] = []
        seen_params: set[str] = set()
        for qk, qv in detected_query.items():
            if qk not in seen_params and qk not in path_var_names:
                seen_params.add(qk)
                params.append({"key": qk, "value": qv, "enabled": True, "description": "Detected query parameter"})

        body = normalize_body({})
        if primary_method in ("GET", "HEAD"):
            # For GET/HEAD, validation/input fields belong in Query Parameters
            for f in fields:
                if f["name"] not in seen_params and not f["is_file"]:
                    seen_params.add(f["name"])
                    total_body_fields += 1
                    rdesc = ", ".join(f["rules"]) if f["rules"] else "Detected parameter"
                    params.append({
                        "key": f["name"],
                        "value": "" if isinstance(f["sample"], (dict, list)) else str(f["sample"]),
                        "enabled": bool(f["required"]),
                        "description": rdesc,
                    })
        else:
            if inspected["has_files"] and fields:
                body["mode"] = "formdata"
                for f in fields:
                    total_body_fields += 1
                    rdesc = ", ".join(f["rules"]) if f["rules"] else ""
                    body["formdata"].append({
                        "key": f["name"],
                        "value": "" if f["is_file"] else (json.dumps(f["sample"]) if isinstance(f["sample"], (dict, list)) else str(f["sample"])),
                        "type": "file" if f["is_file"] else "text",
                        "src": "",
                        "enabled": True,
                        "description": rdesc,
                    })
            elif fields:
                if "content-type" not in seen_hdrs:
                    headers.append({"key": "Content-Type", "value": "application/json", "enabled": True, "description": ""})
                payload_obj: dict[str, Any] = {}
                for f in fields:
                    total_body_fields += 1
                    _set_nested_sample(payload_obj, f["name"], f["sample"])
                body["mode"] = "raw"
                body["raw_type"] = "json"
                body["raw"] = json.dumps(payload_obj, indent=2, ensure_ascii=False)
            elif primary_method in ("POST", "PUT", "PATCH"):
                if "content-type" not in seen_hdrs:
                    headers.append({"key": "Content-Type", "value": "application/json", "enabled": True, "description": ""})
                body["mode"] = "raw"
                body["raw_type"] = "json"
                body["raw"] = "{\n  \n}"

        route_name = str(r.get("name") or "")
        action = str(r.get("action") or "")
        desc_lines = []
        if route_name:
            desc_lines.append(f"**Route Name:** `{route_name}`")
        if action:
            desc_lines.append(f"**Action:** `{action}`")
        if middleware:
            desc_lines.append(f"**Middleware:** `{', '.join(middleware)}`")
        if fields:
            tbl = ["**Detected Fields & Rules:**", "", "| Field | Required | Rules |", "| --- | --- | --- |"]
            for f in fields:
                req_mark = "Yes" if f["required"] else "No"
                rules_s = "`" + " | ".join(f["rules"]) + "`" if f["rules"] else "—"
                tbl.append(f"| `{f['name']}` | {req_mark} | {rules_s} |")
            desc_lines.append("\n".join(tbl))

        nice_name = route_name or f"{primary_method} /{uri}"
        req_item = normalize_item({
            "id": _new_id("req"),
            "type": "request",
            "name": nice_name,
            "description": "\n\n".join(desc_lines),
            "method": primary_method,
            "url": f"{{{{base_url}}}}/{uri}" if uri else "{{base_url}}/",
            "params": params,
            "path_variables": path_vars,
            "headers": headers,
            "auth": req_auth,
            "body": body,
            "tests": [{"type": "status_2xx", "target": "", "value": "", "enabled": False}],
            "extractors": [],
            "examples": [],
        })
        built_requests.append(req_item)

    mode = str(folder_mode or "nested").lower()
    items = _build_flat_tree_from_requests(built_requests) if mode == "flat" else _build_nested_tree_from_requests(built_requests)

    col = normalize_collection({
        "id": _new_id("col"),
        "name": f"{site_name} API",
        "description": f"Auto-generated API collection from Laravel routes for **{site_name}** (including auto-detected FormRequest/Controller body fields & headers).",
        "site_name": site_name,
        "auth": {"type": "none"},
        "variables": [
            {"key": "base_url", "value": (site_url or f"http://{site_name}.test").rstrip("/"), "enabled": True, "description": "Laravel site base URL"},
            {"key": "token", "value": "", "enabled": True, "description": "API Bearer Token"},
        ],
        "items": items,
    })
    col["_sync_stats"] = {
        "body_fields": total_body_fields,
        "headers": total_detected_headers,
    }
    return col


# ── Documentation Generators (Markdown, OpenAPI 3.0.3, Standalone HTML) ──────

def _flatten_endpoints(items: list[dict], parent_path: str = "", parent_auth: dict | None = None) -> list[dict]:
    endpoints: list[dict] = []
    for it in items or []:
        if it.get("type") == "folder":
            folder_auth = it.get("auth") if (it.get("auth") or {}).get("type") not in (None, "inherit") else parent_auth
            prefix = f"{parent_path} / {it['name']}" if parent_path else it["name"]
            endpoints.extend(_flatten_endpoints(it.get("items", []), prefix, folder_auth))
        else:
            eff_auth = it.get("auth") if (it.get("auth") or {}).get("type") not in (None, "inherit") else parent_auth
            endpoints.append({
                "folder": parent_path or "General",
                "request": it,
                "effective_auth": normalize_auth(eff_auth, default_type="none"),
            })
    return endpoints


def export_docs_markdown(collection: dict, env_vars: dict[str, str] | None = None) -> str:
    """Generate clean GitHub-flavored Markdown API documentation."""
    col = normalize_collection(collection)
    vars_map = merge_variables(col.get("variables"), env_vars)
    endpoints = _flatten_endpoints(col.get("items", []), parent_auth=col.get("auth"))

    lines: list[str] = [f"# {col['name']}", ""]
    if col.get("description"):
        lines.extend([col["description"], ""])

    if col.get("variables"):
        lines.extend(["## Environment & Collection Variables", "", "| Variable | Default Value | Description |", "| --- | --- | --- |"])
        for v in col["variables"]:
            if v.get("key"):
                lines.append(f"| `{{{{{v['key']}}}}}` | `{v.get('value', '')}` | {v.get('description', '')} |")
        lines.append("")

    # Table of Contents
    lines.extend(["## Endpoints Overview", "", "| Method | Endpoint | Name | Group |", "| --- | --- | --- | --- |"])
    for ep in endpoints:
        r = ep["request"]
        lines.append(f"| `{r['method']}` | `{r['url']}` | {r['name']} | {ep['folder']} |")
    lines.append("")

    current_folder = None
    for ep in endpoints:
        r = ep["request"]
        if ep["folder"] != current_folder:
            current_folder = ep["folder"]
            lines.extend(["---", "", f"## {current_folder}", ""])

        lines.append(f"### `{r['method']}` {r['name']}")
        lines.append("")
        lines.append(f"```http\n{r['method']} {r['url']}\n```")
        lines.append("")
        if r.get("description"):
            lines.extend([r["description"], ""])

        auth = ep["effective_auth"]
        if auth.get("type") and auth["type"] != "none":
            lines.append(f"**Authentication:** `{auth['type'].upper()}`")
            lines.append("")

        if r.get("path_variables"):
            lines.extend(["#### Path Parameters", "", "| Name | Example | Description |", "| --- | --- | --- |"])
            for p in r["path_variables"]:
                lines.append(f"| `{p['key']}` | `{p['value']}` | {p.get('description', '')} |")
            lines.append("")

        active_params = [p for p in r.get("params", []) if p.get("enabled", True) and p.get("key")]
        if active_params:
            lines.extend(["#### Query Parameters", "", "| Name | Example | Description |", "| --- | --- | --- |"])
            for p in active_params:
                lines.append(f"| `{p['key']}` | `{p['value']}` | {p.get('description', '')} |")
            lines.append("")

        active_headers = [h for h in r.get("headers", []) if h.get("enabled", True) and h.get("key")]
        if active_headers:
            lines.extend(["#### Headers", "", "| Header | Value | Description |", "| --- | --- | --- |"])
            for h in active_headers:
                lines.append(f"| `{h['key']}` | `{h['value']}` | {h.get('description', '')} |")
            lines.append("")

        body = r.get("body") or {}
        if body.get("mode") == "raw" and body.get("raw"):
            lang = body.get("raw_type", "json")
            lines.extend([f"#### Request Body (`{lang}`)", "", f"```{lang}", body["raw"], "```", ""])
        elif body.get("mode") == "formdata" and body.get("formdata"):
            lines.extend(["#### Request Body (`multipart/form-data`)", "", "| Field | Type | Example | Description |", "| --- | --- | --- | --- |"])
            for f in body["formdata"]:
                if f.get("enabled", True) and f.get("key"):
                    lines.append(f"| `{f['key']}` | `{f.get('type', 'text')}` | `{f.get('src') if f.get('type') == 'file' else f.get('value', '')}` | {f.get('description', '')} |")
            lines.append("")
        elif body.get("mode") == "urlencoded" and body.get("urlencoded"):
            lines.extend(["#### Request Body (`x-www-form-urlencoded`)", "", "| Field | Example | Description |", "| --- | --- | --- |"])
            for f in body["urlencoded"]:
                if f.get("enabled", True) and f.get("key"):
                    lines.append(f"| `{f['key']}` | `{f.get('value', '')}` | {f.get('description', '')} |")
            lines.append("")

        curl_snippet = generate_code_snippet(r, "curl", variables=vars_map, inherited_auth=ep["effective_auth"])
        lines.extend(["#### Example Request (cURL)", "", "```bash", curl_snippet, "```", ""])

        if r.get("examples"):
            lines.extend(["#### Example Responses", ""])
            for ex in r["examples"]:
                lines.append(f"**{ex['name']}** (`{ex['status']} {ex.get('status_text', '')}`)")
                lines.append("")
                is_json = str(ex.get("body", "")).lstrip().startswith(("{", "["))
                lines.append(f"```{'json' if is_json else 'text'}")
                lines.append(ex.get("body") or "")
                lines.append("```")
                lines.append("")

    return "\n".join(lines).strip() + "\n"


def _infer_json_schema(val: Any) -> dict:
    if isinstance(val, dict):
        return {
            "type": "object",
            "properties": {k: _infer_json_schema(v) for k, v in val.items()},
        }
    if isinstance(val, list):
        return {
            "type": "array",
            "items": _infer_json_schema(val[0]) if val else {"type": "string"},
        }
    if isinstance(val, bool):
        return {"type": "boolean", "example": val}
    if isinstance(val, int):
        return {"type": "integer", "example": val}
    if isinstance(val, float):
        return {"type": "number", "example": val}
    if val is None:
        return {"type": "string", "nullable": True}
    return {"type": "string", "example": str(val)}


def export_docs_openapi(collection: dict, env_vars: dict[str, str] | None = None) -> dict:
    """Export collection as an OpenAPI 3.0.3 specification dictionary."""
    col = normalize_collection(collection)
    vars_map = merge_variables(col.get("variables"), env_vars)
    base_url = vars_map.get("base_url") or "http://localhost"
    endpoints = _flatten_endpoints(col.get("items", []), parent_auth=col.get("auth"))

    paths: dict[str, dict] = {}
    tags_set: list[str] = []

    for ep in endpoints:
        r = ep["request"]
        folder = ep["folder"]
        if folder not in tags_set:
            tags_set.append(folder)

        resolved_url = interpolate(r["url"], vars_map)
        parsed = urllib.parse.urlsplit(resolved_url if "://" in resolved_url else f"http://localhost/{resolved_url.lstrip('/')}")
        oa_path = parsed.path or "/"
        # Convert :param to {param} for OpenAPI
        oa_path = re.sub(r":([a-zA-Z_][a-zA-Z0-9_]*)", r"{\1}", oa_path)
        oa_path = re.sub(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\?\}", r"{\1}", oa_path)

        params_oa = []
        for pv in r.get("path_variables", []):
            if pv.get("key"):
                params_oa.append({
                    "name": pv["key"],
                    "in": "path",
                    "required": True,
                    "description": pv.get("description", ""),
                    "schema": {"type": "string", "example": pv.get("value", "")},
                })
        for qp in r.get("params", []):
            if qp.get("enabled", True) and qp.get("key"):
                params_oa.append({
                    "name": qp["key"],
                    "in": "query",
                    "required": False,
                    "description": qp.get("description", ""),
                    "schema": {"type": "string", "example": qp.get("value", "")},
                })
        for hd in r.get("headers", []):
            if hd.get("enabled", True) and hd.get("key") and hd["key"].lower() not in ("authorization", "content-type", "accept"):
                params_oa.append({
                    "name": hd["key"],
                    "in": "header",
                    "required": False,
                    "description": hd.get("description", ""),
                    "schema": {"type": "string", "example": hd.get("value", "")},
                })

        op: dict[str, Any] = {
            "tags": [folder],
            "summary": r["name"],
            "description": r.get("description", ""),
            "parameters": params_oa,
            "responses": {},
        }

        auth = ep["effective_auth"]
        if auth.get("type") == "bearer":
            op["security"] = [{"bearerAuth": []}]
        elif auth.get("type") == "basic":
            op["security"] = [{"basicAuth": []}]
        elif auth.get("type") == "apikey":
            op["security"] = [{"apiKeyAuth": []}]

        body = r.get("body") or {}
        if body.get("mode") == "raw" and body.get("raw") and r["method"] not in ("GET", "HEAD"):
            if body.get("raw_type") == "json":
                try:
                    parsed_b = json.loads(body["raw"])
                    op["requestBody"] = {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": _infer_json_schema(parsed_b),
                                "example": parsed_b,
                            }
                        },
                    }
                except Exception:
                    op["requestBody"] = {"content": {"text/plain": {"example": body["raw"]}}}
            else:
                op["requestBody"] = {"content": {"text/plain": {"example": body["raw"]}}}
        elif body.get("mode") == "formdata" and body.get("formdata"):
            props = {}
            for row in body["formdata"]:
                if row.get("enabled", True) and row.get("key"):
                    props[row["key"]] = (
                        {"type": "string", "format": "binary"}
                        if row.get("type") == "file"
                        else {"type": "string", "example": row.get("value", "")}
                    )
            op["requestBody"] = {"content": {"multipart/form-data": {"schema": {"type": "object", "properties": props}}}}

        if r.get("examples"):
            for ex in r["examples"]:
                code_s = str(ex.get("status") or 200)
                ex_body = ex.get("body") or ""
                try:
                    ex_json = json.loads(ex_body)
                    op["responses"][code_s] = {
                        "description": ex.get("name") or ex.get("status_text") or "Response",
                        "content": {
                            "application/json": {
                                "schema": _infer_json_schema(ex_json),
                                "example": ex_json,
                            }
                        },
                    }
                except Exception:
                    op["responses"][code_s] = {
                        "description": ex.get("name") or "Response",
                        "content": {"text/plain": {"example": ex_body}},
                    }
        else:
            op["responses"]["200"] = {"description": "Successful response"}

        paths.setdefault(oa_path, {})[r["method"].lower()] = op

    return {
        "openapi": "3.0.3",
        "info": {
            "title": col["name"],
            "description": col.get("description", ""),
            "version": "1.0.0",
        },
        "servers": [{"url": base_url}],
        "tags": [{"name": t} for t in tags_set],
        "components": {
            "securitySchemes": {
                "bearerAuth": {"type": "http", "scheme": "bearer", "bearerFormat": "JWT"},
                "basicAuth": {"type": "http", "scheme": "basic"},
                "apiKeyAuth": {"type": "apiKey", "in": "header", "name": "X-API-Key"},
            }
        },
        "paths": paths,
    }


def export_docs_html(collection: dict, env_vars: dict[str, str] | None = None) -> str:
    """Export collection as a rich, standalone single-file interactive HTML documentation page."""
    col = normalize_collection(collection)
    vars_map = merge_variables(col.get("variables"), env_vars)
    endpoints = _flatten_endpoints(col.get("items", []), parent_auth=col.get("auth"))

    def e(val: Any) -> str:
        return html_lib.escape(str(val or ""), quote=True)

    # Group by folder
    grouped: list[tuple[str, list[dict]]] = []
    seen_folders: dict[str, list[dict]] = {}
    for idx, ep in enumerate(endpoints):
        ep["anchor"] = f"ep-{idx + 1}"
        if ep["folder"] not in seen_folders:
            seen_folders[ep["folder"]] = []
            grouped.append((ep["folder"], seen_folders[ep["folder"]]))
        seen_folders[ep["folder"]].append(ep)

    toc_html = []
    sections_html = []
    for folder, eps in grouped:
        toc_items = []
        for ep in eps:
            r = ep["request"]
            m_cls = r["method"].lower()
            toc_items.append(
                f'<a class="toc-link" href="#{ep["anchor"]}" data-search="{e((r["name"] + " " + r["url"] + " " + r["method"]).lower())}">'
                f'<span class="m-badge m-{m_cls}">{e(r["method"])}</span>'
                f'<span class="toc-name">{e(r["name"])}</span></a>'
            )
        toc_html.append(f'<div class="toc-group"><div class="toc-title">{e(folder)}</div>{"".join(toc_items)}</div>')

        cards = []
        for ep in eps:
            r = ep["request"]
            m_cls = r["method"].lower()
            auth = ep["effective_auth"]
            snippets = {
                "cURL": generate_code_snippet(r, "curl", variables=vars_map, inherited_auth=auth),
                "Fetch": generate_code_snippet(r, "fetch", variables=vars_map, inherited_auth=auth),
                "Laravel": generate_code_snippet(r, "laravel", variables=vars_map, inherited_auth=auth),
                "Python": generate_code_snippet(r, "python", variables=vars_map, inherited_auth=auth),
                "Dart": generate_code_snippet(r, "dart", variables=vars_map, inherited_auth=auth),
            }

            tables = []
            if r.get("path_variables"):
                rows = "".join(
                    f"<tr><td><code>{e(p['key'])}</code></td><td><code>{e(p['value'])}</code></td><td>{e(p.get('description'))}</td></tr>"
                    for p in r["path_variables"] if p.get("key")
                )
                tables.append(f"<h4>Path Parameters</h4><table><thead><tr><th>Name</th><th>Example</th><th>Description</th></tr></thead><tbody>{rows}</tbody></table>")

            q_params = [p for p in r.get("params", []) if p.get("enabled", True) and p.get("key")]
            if q_params:
                rows = "".join(
                    f"<tr><td><code>{e(p['key'])}</code></td><td><code>{e(p['value'])}</code></td><td>{e(p.get('description'))}</td></tr>"
                    for p in q_params
                )
                tables.append(f"<h4>Query Parameters</h4><table><thead><tr><th>Name</th><th>Example</th><th>Description</th></tr></thead><tbody>{rows}</tbody></table>")

            hdrs = [h for h in r.get("headers", []) if h.get("enabled", True) and h.get("key")]
            if hdrs:
                rows = "".join(
                    f"<tr><td><code>{e(h['key'])}</code></td><td><code>{e(h['value'])}</code></td><td>{e(h.get('description'))}</td></tr>"
                    for h in hdrs
                )
                tables.append(f"<h4>Headers</h4><table><thead><tr><th>Header</th><th>Value</th><th>Description</th></tr></thead><tbody>{rows}</tbody></table>")

            body = r.get("body") or {}
            if body.get("mode") == "raw" and body.get("raw"):
                tables.append(f'<h4>Request Body <span class="tag">{e(body.get("raw_type", "json"))}</span></h4><pre class="code">{e(body["raw"])}</pre>')
            elif body.get("mode") == "formdata" and body.get("formdata"):
                rows = "".join(
                    f"<tr><td><code>{e(f['key'])}</code></td><td><span class='tag'>{e(f.get('type', 'text'))}</span></td><td><code>{e(f.get('src') if f.get('type') == 'file' else f.get('value'))}</code></td><td>{e(f.get('description'))}</td></tr>"
                    for f in body["formdata"] if f.get("enabled", True) and f.get("key")
                )
                tables.append(f"<h4>Form Data</h4><table><thead><tr><th>Key</th><th>Type</th><th>Value</th><th>Description</th></tr></thead><tbody>{rows}</tbody></table>")
            elif body.get("mode") == "urlencoded" and body.get("urlencoded"):
                rows = "".join(
                    f"<tr><td><code>{e(f['key'])}</code></td><td><code>{e(f.get('value'))}</code></td><td>{e(f.get('description'))}</td></tr>"
                    for f in body["urlencoded"] if f.get("enabled", True) and f.get("key")
                )
                tables.append(f"<h4>URL Encoded Body</h4><table><thead><tr><th>Key</th><th>Value</th><th>Description</th></tr></thead><tbody>{rows}</tbody></table>")

            snip_btns = "".join(
                f'<button type="button" class="tab-btn {"active" if i == 0 else ""}" data-tab="{ep["anchor"]}-s-{i}">{e(k)}</button>'
                for i, k in enumerate(snippets.keys())
            )
            snip_panes = "".join(
                f'<div class="tab-pane {"active" if i == 0 else ""}" id="{ep["anchor"]}-s-{i}">'
                f'<button type="button" class="copy-btn" data-copy="{e(v)}">Copy</button><pre class="code">{e(v)}</pre></div>'
                for i, (_, v) in enumerate(snippets.items())
            )

            ex_html = ""
            if r.get("examples"):
                ex_btns = "".join(
                    f'<button type="button" class="tab-btn {"active" if i == 0 else ""}" data-tab="{ep["anchor"]}-e-{i}">{e(ex["status"])} · {e(ex["name"])}</button>'
                    for i, ex in enumerate(r["examples"])
                )
                ex_panes = "".join(
                    f'<div class="tab-pane {"active" if i == 0 else ""}" id="{ep["anchor"]}-e-{i}">'
                    f'<button type="button" class="copy-btn" data-copy="{e(ex.get("body", ""))}">Copy</button>'
                    f'<pre class="code">{e(ex.get("body", "(empty)"))}</pre></div>'
                    for i, ex in enumerate(r["examples"])
                )
                ex_html = f'<div class="code-box"><div class="code-head"><span>Example Responses</span><div class="tabs">{ex_btns}</div></div>{ex_panes}</div>'

            auth_badge = f'<span class="tag auth-tag">Auth: {e(auth["type"].upper())}</span>' if auth.get("type") not in (None, "none") else ""
            cards.append(f"""
            <article class="endpoint" id="{ep["anchor"]}" data-search="{e((r["name"] + " " + r["url"] + " " + r["method"] + " " + folder).lower())}">
              <div class="ep-left">
                <div class="ep-title-row">
                  <h3>{e(r["name"])}</h3>
                  {auth_badge}
                </div>
                <div class="ep-url">
                  <span class="m-badge m-{m_cls}">{e(r["method"])}</span>
                  <code>{e(r["url"])}</code>
                  <button type="button" class="copy-mini" data-copy="{e(r["url"])}">Copy</button>
                </div>
                {f'<p class="ep-desc">{e(r["description"]).replace(chr(10), "<br>")}</p>' if r.get("description") else ""}
                {"".join(tables)}
              </div>
              <div class="ep-right">
                <div class="code-box">
                  <div class="code-head"><span>Request Snippet</span><div class="tabs">{snip_btns}</div></div>
                  {snip_panes}
                </div>
                {ex_html}
              </div>
            </article>""")
        sections_html.append(f'<section class="folder-sec"><h2 class="folder-h">{e(folder)}</h2>{"".join(cards)}</section>')

    vars_section = ""
    if col.get("variables"):
        v_rows = "".join(
            f"<tr><td><code>{{{{{e(v['key'])}}}}}</code></td><td><code>{e(v.get('value'))}</code></td><td>{e(v.get('description'))}</td></tr>"
            for v in col["variables"] if v.get("key")
        )
        vars_section = f'<div class="intro-card"><h3>Variables</h3><table><thead><tr><th>Variable</th><th>Default Value</th><th>Description</th></tr></thead><tbody>{v_rows}</tbody></table></div>'

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(col["name"])} — API Documentation</title>
<style>
:root {{
  --bg: #f8fafc; --surface: #ffffff; --surface2: #f1f5f9; --border: #e2e8f0;
  --text: #0f172a; --muted: #64748b; --accent: #f53003; --code-bg: #0f172a; --code-text: #e2e8f0;
}}
:root[data-theme="dark"] {{
  --bg: #0b0d12; --surface: #131620; --surface2: #1b2030; --border: #252c3f;
  --text: #f1f5f9; --muted: #94a3b8; --accent: #ff5722; --code-bg: #07090e; --code-text: #e2e8f0;
}}
* {{ box-sizing: border-box; }}
body {{ margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, sans-serif; background: var(--bg); color: var(--text); display: flex; min-height: 100vh; }}
aside {{ width: 280px; flex: none; background: var(--surface); border-right: 1px solid var(--border); position: sticky; top: 0; height: 100vh; overflow-y: auto; padding: 18px 14px; }}
main {{ flex: 1; min-width: 0; padding: 28px 36px 80px; max-width: 1380px; }}
.brand {{ display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; gap: 8px; }}
.brand h1 {{ font-size: 16px; margin: 0; }}
.theme-btn {{ border: 1px solid var(--border); background: var(--surface2); color: var(--text); border-radius: 7px; padding: 5px 9px; cursor: pointer; font-size: 12px; }}
#search {{ width: 100%; padding: 8px 10px; border: 1px solid var(--border); border-radius: 8px; background: var(--surface2); color: var(--text); margin-bottom: 16px; }}
.toc-group {{ margin-bottom: 14px; }}
.toc-title {{ font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: var(--muted); font-weight: 700; margin: 0 0 6px 6px; }}
.toc-link {{ display: flex; align-items: center; gap: 8px; padding: 6px 8px; border-radius: 7px; text-decoration: none; color: var(--text); font-size: 13px; }}
.toc-link:hover {{ background: var(--surface2); }}
.toc-name {{ overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }}
.m-badge {{ font-family: ui-monospace, SFMono-Regular, monospace; font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 5px; flex: none; }}
.m-get {{ background: rgba(22,163,74,.14); color: #16a34a; }}
.m-post {{ background: rgba(217,119,6,.16); color: #d97706; }}
.m-put, .m-patch {{ background: rgba(37,99,235,.15); color: #2563eb; }}
.m-delete {{ background: rgba(220,38,38,.15); color: #dc2626; }}
.m-head, .m-options {{ background: rgba(100,116,139,.18); color: #64748b; }}
.hero {{ border-bottom: 1px solid var(--border); padding-bottom: 20px; margin-bottom: 28px; }}
.hero h1 {{ margin: 0 0 8px; font-size: 28px; }}
.hero p {{ margin: 0; color: var(--muted); line-height: 1.6; }}
.intro-card {{ background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 16px 18px; margin-bottom: 24px; }}
.folder-h {{ font-size: 20px; margin: 32px 0 14px; padding-bottom: 8px; border-bottom: 1px solid var(--border); }}
.endpoint {{ display: grid; grid-template-columns: minmax(0, 1.15fr) minmax(0, 1fr); gap: 22px; background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 20px; margin-bottom: 18px; }}
@media (max-width: 1024px) {{ body {{ flex-direction: column; }} aside {{ width: 100%; height: auto; position: static; }} .endpoint {{ grid-template-columns: 1fr; }} }}
.ep-title-row {{ display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 10px; }}
.ep-title-row h3 {{ margin: 0; font-size: 17px; }}
.ep-url {{ display: flex; align-items: center; gap: 8px; background: var(--surface2); border: 1px solid var(--border); border-radius: 8px; padding: 8px 10px; font-family: ui-monospace, monospace; font-size: 12.5px; word-break: break-all; margin-bottom: 12px; }}
.ep-desc {{ color: var(--muted); font-size: 13.5px; line-height: 1.6; margin: 0 0 14px; }}
.tag {{ display: inline-block; font-size: 11px; padding: 2px 7px; border-radius: 99px; background: var(--surface2); color: var(--muted); border: 1px solid var(--border); }}
.auth-tag {{ color: var(--accent); border-color: var(--accent); }}
h4 {{ margin: 14px 0 8px; font-size: 12.5px; text-transform: uppercase; letter-spacing: .04em; color: var(--muted); }}
table {{ width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 10px; }}
th, td {{ text-align: left; padding: 7px 9px; border-bottom: 1px solid var(--border); vertical-align: top; }}
th {{ font-size: 11px; text-transform: uppercase; color: var(--muted); }}
code {{ font-family: ui-monospace, SFMono-Regular, monospace; font-size: 12px; }}
.code-box {{ background: var(--code-bg); color: var(--code-text); border-radius: 10px; overflow: hidden; margin-bottom: 14px; border: 1px solid rgba(255,255,255,.08); }}
.code-head {{ display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 6px; padding: 8px 12px; background: rgba(255,255,255,.04); border-bottom: 1px solid rgba(255,255,255,.08); font-size: 11.5px; color: #94a3b8; }}
.tabs {{ display: flex; gap: 4px; flex-wrap: wrap; }}
.tab-btn {{ background: transparent; border: 0; color: #94a3b8; font-size: 11.5px; padding: 3px 8px; border-radius: 6px; cursor: pointer; }}
.tab-btn.active {{ background: rgba(255,255,255,.12); color: #fff; font-weight: 600; }}
.tab-pane {{ display: none; position: relative; }}
.tab-pane.active {{ display: block; }}
pre.code {{ margin: 0; padding: 14px; overflow-x: auto; font-family: ui-monospace, SFMono-Regular, monospace; font-size: 12px; line-height: 1.55; background: var(--code-bg); color: var(--code-text); border-radius: 8px; }}
.copy-btn {{ position: absolute; top: 8px; right: 8px; background: rgba(255,255,255,.12); color: #fff; border: 0; border-radius: 6px; padding: 4px 8px; font-size: 11px; cursor: pointer; }}
.copy-mini {{ margin-left: auto; border: 1px solid var(--border); background: var(--surface); color: var(--text); border-radius: 6px; padding: 2px 7px; font-size: 11px; cursor: pointer; }}
</style>
</head>
<body>
  <aside>
    <div class="brand">
      <h1>{e(col["name"])}</h1>
      <button type="button" class="theme-btn" id="theme-toggle">Theme</button>
    </div>
    <input type="search" id="search" placeholder="Filter endpoints...">
    {"".join(toc_html)}
  </aside>
  <main>
    <header class="hero">
      <h1>{e(col["name"])}</h1>
      <p>{e(col.get("description") or "Generated with Laravel Dev API Studio.")}</p>
    </header>
    {vars_section}
    {"".join(sections_html) or '<div class="intro-card">No endpoints documented yet.</div>'}
  </main>
<script>
const root = document.documentElement;
if (window.matchMedia('(prefers-color-scheme: dark)').matches) root.setAttribute('data-theme', 'dark');
document.getElementById('theme-toggle').onclick = () => {{
  root.setAttribute('data-theme', root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
}};
document.getElementById('search').addEventListener('input', (ev) => {{
  const q = ev.target.value.trim().toLowerCase();
  document.querySelectorAll('.toc-link, .endpoint').forEach((el) => {{
    el.style.display = !q || (el.dataset.search || '').includes(q) ? '' : 'none';
  }});
}});
document.addEventListener('click', (ev) => {{
  const tab = ev.target.closest('.tab-btn');
  if (tab) {{
    const box = tab.closest('.code-box');
    box.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('active', b === tab));
    box.querySelectorAll('.tab-pane').forEach((p) => p.classList.toggle('active', p.id === tab.dataset.tab));
  }}
  const cp = ev.target.closest('[data-copy]');
  if (cp) {{
    navigator.clipboard?.writeText(cp.dataset.copy);
    const old = cp.textContent;
    cp.textContent = 'Copied!';
    setTimeout(() => (cp.textContent = old), 1200);
  }}
}});
</script>
</body>
</html>"""
