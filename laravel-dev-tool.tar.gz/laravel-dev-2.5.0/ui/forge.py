"""Forge Mode - Server provisioning, remote site management, and zero-downtime deployments.

Works over standard SSH through the existing Remote connection layer.
Provides:
  - Server provisioning (Nginx, PHP-FPM, MySQL/PostgreSQL, Redis, Supervisor, UFW)
  - Remote atomic site creation with isolated directories and Nginx vhost
  - Zero-downtime atomic deployments (releases, symlink swap, opcache clear, release pruning)
  - 1-click atomic rollbacks
  - SSL certificate automation via Certbot
  - Background queue workers (Supervisor) and Scheduler (Cron)
  - GitHub Deploy Key automation and Cloudflare DNS/purge integration
  - Production database pull with automatic local snapshot protection
"""

import base64
import json
import os
import re
import shlex
from pathlib import Path
from typing import Any

FORGE_SCRIPTS_DIR = Path(__file__).resolve().parent / "forge_scripts"

DOMAIN_RE = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$")
PHP_RE = re.compile(r"^\d+\.\d+$")
IDENT_RE = re.compile(r"^[a-zA-Z0-9_]{1,64}$")
VALID_STACKS = ("laravel", "node_ssr", "static", "python", "docker")
SAFE_TOOLS = {
    "nodejs": "nodejs",
    "node": "nodejs",
    "npm": "npm",
    "pm2": "pm2",
    "docker": "docker",
    "docker_compose": "docker",
    "python3": "python3-venv",
    "pip3": "python3-pip",
    "certbot": "certbot",
    "rsync": "rsync",
    "nginx": "nginx",
    "git": "git",
}


def validate_stack(stack: str) -> str:
    s = (stack or "laravel").strip().lower()
    if s not in VALID_STACKS:
        raise ValueError(f"Unsupported deployment stack: '{stack}'")
    return s


def build_recipe_defaults(stack: str) -> dict[str, Any]:
    s = validate_stack(stack)
    defaults = {
        "laravel": {
            "pre_build": "",
            "install_cmd": "composer install --no-dev --optimize-autoloader --prefer-dist --no-progress",
            "build_cmd": "if [ -f package.json ]; then npm ci || npm install; npm run build || true; fi",
            "migrate_cmd": "",
            "start_cmd": "",
            "post_deploy": "",
            "health_path": "/up",
            "health_status": 200,
            "auto_rollback": True,
            "shared_paths": ["storage"],
            "public_dir": "public",
        },
        "node_ssr": {
            "pre_build": "",
            "install_cmd": "",
            "build_cmd": "",
            "migrate_cmd": "",
            "start_cmd": "node .output/server/index.mjs",
            "post_deploy": "",
            "health_path": "/",
            "health_status": 200,
            "auto_rollback": True,
            "shared_paths": [],
            "public_dir": ".output/public",
        },
        "static": {
            "pre_build": "",
            "install_cmd": "",
            "build_cmd": "",
            "migrate_cmd": "",
            "start_cmd": "",
            "post_deploy": "",
            "health_path": "/",
            "health_status": 200,
            "auto_rollback": True,
            "shared_paths": [],
            "public_dir": "dist",
        },
        "python": {
            "pre_build": "",
            "install_cmd": "pip install -r requirements.txt",
            "build_cmd": "",
            "migrate_cmd": "",
            "start_cmd": "gunicorn --bind 127.0.0.1:$PORT config.wsgi:application",
            "post_deploy": "",
            "health_path": "/",
            "health_status": 200,
            "auto_rollback": True,
            "shared_paths": ["media"],
            "public_dir": "static",
        },
        "docker": {
            "pre_build": "",
            "install_cmd": "",
            "build_cmd": "",
            "migrate_cmd": "",
            "start_cmd": "docker compose up -d --build",
            "post_deploy": "",
            "health_path": "/",
            "health_status": 200,
            "auto_rollback": True,
            "shared_paths": [],
            "public_dir": "",
        },
    }
    return dict(defaults[s])


def validate_recipe(recipe: dict[str, Any] | None, stack: str = "laravel") -> dict[str, Any]:
    base = build_recipe_defaults(stack)
    if not isinstance(recipe, dict):
        return base
    for key in ("pre_build", "install_cmd", "build_cmd", "migrate_cmd", "start_cmd", "post_deploy", "health_path", "public_dir"):
        if key in recipe and recipe[key] is not None:
            base[key] = str(recipe[key]).strip()
    if "health_status" in recipe and recipe["health_status"] is not None:
        base["health_status"] = int(recipe["health_status"])
    if "auto_rollback" in recipe:
        base["auto_rollback"] = bool(recipe["auto_rollback"])
    if isinstance(recipe.get("shared_paths"), list):
        base["shared_paths"] = [
            str(x).strip().strip("/")
            for x in recipe["shared_paths"]
            if str(x).strip() and ".." not in str(x)
        ]
    return base


def validate_domain(domain: str) -> str:
    domain = (domain or "").strip()
    if not DOMAIN_RE.match(domain):
        raise ValueError(f"Invalid domain name: '{domain}'")
    return domain


def validate_php_version(php: str) -> str:
    php = (php or "8.3").strip()
    if not PHP_RE.match(php):
        raise ValueError(f"Invalid PHP version: '{php}'")
    return php


def validate_ident(val: str, label: str) -> str:
    val = (val or "").strip()
    if not IDENT_RE.match(val):
        raise ValueError(f"Invalid {label}: '{val}' (alphanumeric and underscores only)")
    return val


def get_provision_status(remote, server_id: str) -> dict[str, Any] | None:
    """Check if server has been provisioned with laravel-dev."""
    server = remote.get(server_id)
    code, out, _ = remote.run(server, '[ -f /etc/laravel-dev-provisioned.json ] && cat /etc/laravel-dev-provisioned.json || true')
    if code == 0 and out.strip():
        try:
            return json.loads(out)
        except Exception:
            pass
    return None


def list_releases(remote, server_id: str, app_dir: str) -> dict[str, Any]:
    """List releases in $APP_DIR/releases and current symlink target."""
    server = remote.get(server_id)
    script = r"""
APP="$1"
if [ ! -d "$APP/releases" ]; then
  exit 1
fi
CUR=""
if [ -L "$APP/current" ]; then
  CUR="$(basename "$(readlink -f "$APP/current" 2>/dev/null || echo '')")"
fi
printf 'current\t%s\n' "$CUR"
find "$APP/releases" -mindepth 1 -maxdepth 1 -type d -printf '%T@\t%f\n' 2>/dev/null | sort -nr
"""
    code, out, _ = remote.run(server, script, app_dir)
    if code != 0:
        return {"current": "", "releases": []}
    lines = out.strip().splitlines()
    cur = ""
    releases = []
    for line in lines:
        parts = line.split("\t")
        if parts[0] == "current":
            cur = parts[1] if len(parts) > 1 else ""
        elif len(parts) == 2:
            try:
                mtime, rel_id = float(parts[0]), parts[1]
                releases.append({"id": rel_id, "timestamp": mtime, "active": rel_id == cur})
            except ValueError:
                continue
    return {"current": cur, "releases": releases}


def _sudo_bash_s_cmd(prefix: str, data: bytes | None, args: list[str] | None = None) -> str:
    """Build a remote bash -s command that safely consumes a 1-line sudo password before reading script stdin."""
    tail = (" -- " + " ".join(shlex.quote(a) for a in args)) if args else ""
    if data:
        return f"read -r _ld_pw && printf '%s\\n' \"$_ld_pw\" | sudo -S -p '' -v && unset _ld_pw && sudo -n bash -s{tail}"
    return f"{prefix}bash -s{tail}"


def build_forge_task(remote, action: str, p: dict[str, Any]):
    """Build executable task tuple (title, argv, env, stdin_data) for forge actions."""
    server = remote.get(p.get("server", ""))
    label = server["name"]
    sudo_mode = p.get("sudo") or "password"

    # 1. forge-provision
    if action == "forge-provision":
        script_path = FORGE_SCRIPTS_DIR / "provision.sh"
        if not script_path.is_file():
            raise ValueError("Provisioning script missing from ui/forge_scripts/provision.sh")
        script_content = script_path.read_text(encoding="utf-8")
        prefix, data = remote.sudo_prefix(server["id"], sudo_mode)
        remote_cmd = _sudo_bash_s_cmd(prefix, data)
        return f"Provision Server · {label}", remote.command(server, remote_cmd), remote.env(), (data or b"") + script_content.encode("utf-8")

    # 2. forge-site-create
    if action == "forge-site-create":
        domain = validate_domain(p.get("domain", ""))
        php = validate_php_version(p.get("php", "8.3"))
        db_engine = (p.get("db_engine") or "mysql").strip().lower()
        if db_engine not in ("mysql", "mariadb", "pgsql", "postgresql", "none"):
            raise ValueError(f"Unsupported DB engine: {db_engine}")

        db_name = p.get("db_name", "").strip()
        db_user = p.get("db_user", "").strip()
        db_pass = p.get("db_pass", "").strip()
        if db_engine != "none":
            if not db_name:
                db_name = validate_ident(domain.replace(".", "_").replace("-", "_"), "database name")
            else:
                db_name = validate_ident(db_name, "database name")
            if not db_user:
                db_user = validate_ident(db_name[:16], "database user")
            else:
                db_user = validate_ident(db_user, "database user")
            if not db_pass:
                import secrets
                db_pass = secrets.token_hex(12)

        script_path = FORGE_SCRIPTS_DIR / "create_site.sh"
        script_content = script_path.read_text(encoding="utf-8")
        prefix, data = remote.sudo_prefix(server["id"], sudo_mode)
        args = [domain, php, db_name, db_user, db_pass, db_engine]
        remote_cmd = _sudo_bash_s_cmd(prefix, data, args)
        return f"Create Site {domain} · {label}", remote.command(server, remote_cmd), remote.env(), (data or b"") + script_content.encode("utf-8")

    # 3. forge-deploy
    if action == "forge-deploy":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        repo_url = (p.get("repo_url") or "").strip()
        if not repo_url:
            raise ValueError("Repository URL is required for atomic deployment")
        branch = (p.get("branch") or "main").strip()
        php = validate_php_version(p.get("php", "8.3"))

        script_path = FORGE_SCRIPTS_DIR / "deploy_atomic.sh"
        script_content = script_path.read_text(encoding="utf-8")
        args = [app_dir, repo_url, branch, php]
        remote_cmd = "bash -s -- " + " ".join(shlex.quote(a) for a in args)
        return f"Atomic Deploy {os.path.basename(app_dir)} · {label}", remote.command(server, remote_cmd, login=True), remote.env(), script_content.encode("utf-8")

    # 4. forge-rollback
    if action == "forge-rollback":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        target_rel = (p.get("release") or "").strip()
        php = validate_php_version(p.get("php", "8.3"))

        rollback_script = r"""
APP="$1"
TARGET="$2"
PHP_V="$3"

if [ ! -d "$APP/releases" ]; then
  echo "Error: No releases directory in $APP" >&2
  exit 1
fi

if [ -z "$TARGET" ]; then
  # Auto-select previous release
  CUR="$(basename "$(readlink -f "$APP/current" 2>/dev/null || echo '')")"
  PREV="$(find "$APP/releases" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | grep -v "^${CUR}$" | sort -r | head -n1 || true)"
  if [ -z "$PREV" ]; then
    echo "Error: No previous release found to rollback to." >&2
    exit 1
  fi
  TARGET="$PREV"
fi

TARGET_DIR="$APP/releases/$TARGET"
if [ ! -d "$TARGET_DIR" ]; then
  echo "Error: Target release $TARGET does not exist in $APP/releases" >&2
  exit 1
fi

echo "==> Rolling back to release $TARGET..."
ln -sfn "$TARGET_DIR" "$APP/current.tmp"
mv -Tf "$APP/current.tmp" "$APP/current"

PHP_BIN="$(command -v "php$PHP_V" || command -v php)"
"$PHP_BIN" "$TARGET_DIR/artisan" queue:restart || true
sudo -n systemctl reload "php${PHP_V}-fpm" || true

echo "==> Rollback complete! Active release is now $TARGET 🎉"
"""
        return f"Rollback {os.path.basename(app_dir)} · {label}", remote.command(server, rollback_script, app_dir, target_rel, php, login=True), remote.env(), None

    # 5. forge-ssl
    if action == "forge-ssl":
        domain = validate_domain(p.get("domain", ""))
        email = (p.get("email") or "").strip()
        email_arg = f"--email {shlex.quote(email)}" if email else "--register-unsafely-without-email"
        prefix, data = remote.sudo_prefix(server["id"], sudo_mode)
        script = f"""{prefix}certbot --nginx -d {shlex.quote(domain)} --redirect --non-interactive --agree-tos {email_arg}"""
        return f"Issue SSL for {domain} · {label}", remote.command(server, script), remote.env(), data

    # 6. forge-worker
    if action == "forge-worker":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        site_name = os.path.basename(app_dir).replace(".", "_")
        queue = (p.get("queue") or "default").strip()
        numprocs = int(p.get("numprocs") or 1)
        if numprocs < 1 or numprocs > 32:
            numprocs = 1
        php = validate_php_version(p.get("php", "8.3"))

        prefix, data = remote.sudo_prefix(server["id"], sudo_mode)
        sudo_run = "sudo -n " if data else prefix
        auth_head = "read -r _ld_pw && printf '%s\\n' \"$_ld_pw\" | sudo -S -p '' -v && unset _ld_pw\n" if data else ""
        script = f"""{auth_head}APP_DIR={shlex.quote(app_dir)}
WORK_DIR="$APP_DIR"
[ -L "$APP_DIR/current" ] && WORK_DIR="$APP_DIR/current"
LOG_FILE="$APP_DIR/storage/logs/worker.log"
[ -L "$APP_DIR/current" ] && [ -d "$APP_DIR/shared/storage/logs" ] && LOG_FILE="$APP_DIR/shared/storage/logs/worker.log"
mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
cat << EOF | {sudo_run}tee /etc/supervisor/conf.d/{site_name}-worker.conf >/dev/null
[program:{site_name}-worker]
process_name=%(program_name)s_%(process_num)02d
command=php{php} ${{WORK_DIR}}/artisan queue:work --sleep=3 --tries=3 --max-time=3600 --queue={queue}
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
user=www-data
numprocs={numprocs}
redirect_stderr=true
stdout_logfile=${{LOG_FILE}}
stopwaitsecs=3600
EOF
{sudo_run}supervisorctl reread
{sudo_run}supervisorctl update
{sudo_run}supervisorctl restart {site_name}-worker:*
echo "==> Supervisor worker configured and started."
"""
        return f"Configure Worker {site_name} · {label}", remote.command(server, script), remote.env(), data

    # 7. forge-cron
    if action == "forge-cron":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        php = validate_php_version(p.get("php", "8.3"))
        op = p.get("op", "enable")  # enable or disable

        if op == "disable":
            script = f"""
crontab -l 2>/dev/null | grep -v "laravel-dev:{os.path.basename(app_dir)}" | crontab - || true
echo "==> Scheduler cron removed."
"""
        else:
            script = f"""
APP_DIR={shlex.quote(app_dir)}
WORK_DIR="$APP_DIR"
[ -L "$APP_DIR/current" ] && WORK_DIR="$APP_DIR/current"
CRON_LINE="* * * * * cd $WORK_DIR && php{php} artisan schedule:run >> /dev/null 2>&1 # laravel-dev:{os.path.basename(app_dir)}"
(crontab -l 2>/dev/null | grep -v "laravel-dev:{os.path.basename(app_dir)}"; printf '%s\\n' "$CRON_LINE") | crontab -
echo "==> Scheduler cron active (running every minute)."
"""
        return f"Scheduler {op.capitalize()} {os.path.basename(app_dir)} · {label}", remote.command(server, script, login=True), remote.env(), None

    # 8. forge-deploy-key
    if action == "forge-deploy-key":
        domain = validate_domain(p.get("domain", ""))
        key_name = f"ld_{domain.replace('.', '_')}"
        script = f"""
mkdir -p ~/.ssh && chmod 700 ~/.ssh
KEY_FILE="$HOME/.ssh/{key_name}"
if [ ! -f "$KEY_FILE" ]; then
  ssh-keygen -t ed25519 -N "" -f "$KEY_FILE" -C "laravel-dev-{domain}" >/dev/null
fi
# Update ~/.ssh/config to map host
if ! grep -q "Host gh-{domain}" ~/.ssh/config 2>/dev/null; then
  cat << 'EOF' >> ~/.ssh/config

Host gh-{domain}
  HostName github.com
  User git
  IdentityFile ~/.ssh/{key_name}
  IdentitiesOnly yes
  StrictHostKeyChecking accept-new
EOF
  chmod 600 ~/.ssh/config
fi
cat "$KEY_FILE.pub"
"""
        return f"Generate Deploy Key {domain} · {label}", remote.command(server, script, login=True), remote.env(), None

    # 9. forge-db-pull
    if action == "forge-db-pull":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        local_site = (p.get("local_site") or "").strip()
        exclude = (p.get("exclude") or "sessions,jobs,telescope_entries").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        if not local_site:
            raise ValueError("Target local site name is required to pull database safely")

        # Command runs db_dump.sh on remote server and streams output
        script_path = FORGE_SCRIPTS_DIR / "db_dump.sh"
        script_content = script_path.read_text(encoding="utf-8")
        args = [app_dir, exclude]
        remote_cmd = "bash -s -- " + " ".join(shlex.quote(a) for a in args)
        return f"DB Pull {os.path.basename(app_dir)} -> {local_site} · {label}", remote.command(server, remote_cmd, login=True), remote.env(), script_content.encode("utf-8")

    # 10. forge-universal-site-create
    if action == "forge-universal-site-create":
        domain = validate_domain(p.get("domain", ""))
        stack = validate_stack(p.get("stack", "laravel"))
        app_dir = (p.get("app_dir") or p.get("path") or f"/var/www/{domain}").strip()
        if not (app_dir.startswith("/") or app_dir.startswith("~/")):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        port = str(int(p.get("port") or (8000 if stack == "python" else 3000)))
        public_dir = (p.get("public_dir") or ("public" if stack == "laravel" else "dist")).strip()
        php = validate_php_version(p.get("php", "8.3"))
        db_engine = p.get("db_engine", "none")
        db_name = p.get("db_name", "").strip()
        db_user = p.get("db_user", "").strip()
        db_pass = p.get("db_pass", "").strip()
        db_host = (p.get("db_host") or "127.0.0.1").strip()
        db_port = str(p.get("db_port") or "").strip()
        db_mode = (p.get("db_mode") or "create").strip()
        if db_mode not in ("create", "existing"):
            db_mode = "create"
        deploy_layout = (p.get("deploy_layout") or "inplace").strip()
        if deploy_layout not in ("atomic", "inplace"):
            deploy_layout = "inplace"
        if db_engine != "none":
            db_name = validate_ident(db_name or domain.replace(".", "_").replace("-", "_"), "database name")
            db_user = validate_ident(db_user or db_name[:16], "database user")

        script_content = (FORGE_SCRIPTS_DIR / "create_universal_site.sh").read_text(encoding="utf-8")
        prefix, data = ("", None)
        if sudo_mode != "root" and app_dir.startswith("/var/www"):
            prefix, data = remote.sudo_prefix(server["id"], sudo_mode)
        elif sudo_mode == "nopasswd":
            prefix = "sudo -n "
        args = [domain, stack, app_dir, port, public_dir, php, db_engine, db_name, db_user, db_pass, db_host, db_port, db_mode, deploy_layout]
        remote_cmd = _sudo_bash_s_cmd(prefix, data, args)
        return f"Create {stack.upper()} Site {domain} · {label}", remote.command(server, remote_cmd), remote.env(), (data or b"") + script_content.encode("utf-8")

    # 11. forge-universal-deploy
    if action == "forge-universal-deploy":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not (app_dir.startswith("/") or app_dir.startswith("~/")):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        stack = validate_stack(p.get("stack", "laravel"))
        source_mode = (p.get("source_mode") or "git").strip()
        if source_mode not in ("git", "local_source", "local_artifact"):
            raise ValueError(f"Invalid source_mode: '{source_mode}'")
        deploy_layout = (p.get("deploy_layout") or "inplace").strip()
        if deploy_layout not in ("atomic", "inplace"):
            raise ValueError(f"Invalid deploy_layout: '{deploy_layout}'")
        repo_url = (p.get("repo_url") or "").strip()
        if source_mode == "git" and not repo_url:
            raise ValueError("Repository URL is required when deploying from Git")
        branch = (p.get("branch") or "main").strip()
        release_id = (p.get("release_id") or "").strip()
        port = str(int(p.get("port") or (8000 if stack == "python" else 3000)))
        php = validate_php_version(p.get("php", "8.3"))
        health_path = str(p.get("health_path") if p.get("health_path") is not None else "/").strip()
        auto_rollback = "1" if p.get("auto_rollback", True) else "0"
        recipe = validate_recipe(p.get("recipe"), stack=stack)
        recipe_b64 = base64.b64encode(json.dumps(recipe).encode("utf-8")).decode("ascii")

        script_content = (FORGE_SCRIPTS_DIR / "deploy_universal.sh").read_text(encoding="utf-8")
        args = [
            app_dir, stack, source_mode, deploy_layout, repo_url, branch,
            release_id, port, php, health_path, auto_rollback, recipe_b64,
        ]
        remote_cmd = "bash -s -- " + " ".join(shlex.quote(a) for a in args)
        return f"Deploy ({stack}) {os.path.basename(app_dir)} · {label}", remote.command(server, remote_cmd, login=True), remote.env(), script_content.encode("utf-8")

    # 12. forge-universal-rollback
    if action == "forge-universal-rollback":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not (app_dir.startswith("/") or app_dir.startswith("~/")):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        target_rel = (p.get("release") or "").strip()
        php = validate_php_version(p.get("php", "8.3"))
        slug = re.sub(r"[^A-Za-z0-9_-]", "_", os.path.basename(app_dir.rstrip("/")))
        rollback_script = r"""
APP="$1"
case "$APP" in "~/"*) APP="$HOME/${APP#\~/}" ;; esac
TARGET="$2"
PHP_V="$3"
APP_SLUG="$4"
if [ -d "$APP/releases" ] && [ -L "$APP/current" ]; then
  if [ -z "$TARGET" ]; then
    CUR="$(basename "$(readlink -f "$APP/current" 2>/dev/null || echo '')")"
    PREV="$(find "$APP/releases" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | grep -v "^${CUR}$" | sort -r | head -n1 || true)"
    [ -z "$PREV" ] && { echo "Error: No previous release found to rollback to." >&2; exit 1; }
    TARGET="$PREV"
  fi
  TARGET_DIR="$APP/releases/$TARGET"
  [ -d "$TARGET_DIR" ] || { echo "Error: Release $TARGET does not exist." >&2; exit 1; }
  echo "==> Rolling back $APP to $TARGET..."
  ln -sfn "$TARGET_DIR" "$APP/current.tmp"
  mv -Tf "$APP/current.tmp" "$APP/current"
  cd "$APP/current"
elif [ -d "$APP/.git" ]; then
  cd "$APP"
  if [ -z "$TARGET" ] && [ -f "$APP/.ld-last-deploy" ]; then
    TARGET="$(cat "$APP/.ld-last-deploy" 2>/dev/null || true)"
  fi
  [ -z "$TARGET" ] && TARGET="HEAD~1"
  echo "==> Rolling back Git commit in $APP to $TARGET..."
  git reset --hard "$TARGET"
else
  echo "Error: No Git repository or release history found in $APP" >&2
  exit 1
fi
if [ -f artisan ]; then
  PHP_BIN="$(command -v "php$PHP_V" || command -v php)"
  "$PHP_BIN" artisan queue:restart || true
  sudo -n systemctl reload "php${PHP_V}-fpm" || sudo -n systemctl reload php-fpm || true
elif [ -f docker-compose.yml ] || [ -f docker-compose.yaml ] || [ -f compose.yml ] || [ -f compose.yaml ]; then
  docker compose -p "$APP_SLUG" up -d --build --remove-orphans || true
elif command -v pm2 >/dev/null 2>&1 && pm2 describe "$APP_SLUG" >/dev/null 2>&1; then
  pm2 reload "$APP_SLUG" --update-env || pm2 restart "$APP_SLUG" || true
elif systemctl list-unit-files "laravel-dev-${APP_SLUG}.service" --no-legend 2>/dev/null | grep -q .; then
  sudo -n systemctl restart "laravel-dev-${APP_SLUG}.service" || systemctl restart "laravel-dev-${APP_SLUG}.service" || true
fi
echo "==> Rollback complete! Active state is now $TARGET"
"""
        return f"Rollback {os.path.basename(app_dir)} · {label}", remote.command(server, rollback_script, app_dir, target_rel, php, slug, login=True), remote.env(), None

    # 13. forge-install-tools
    if action == "forge-install-tools":
        requested = p.get("tools") or []
        clean_tools = [SAFE_TOOLS[t] for t in requested if t in SAFE_TOOLS]
        if not clean_tools:
            raise ValueError("No valid installable tools selected")
        install_pm2 = "pm2" in clean_tools
        install_docker = "docker" in clean_tools
        apt_pkgs = [t for t in clean_tools if t not in ("pm2", "docker")]
        if install_docker and "docker.io" not in apt_pkgs:
            apt_pkgs.extend(["docker.io", "docker-compose-plugin"])
        if "nodejs" in apt_pkgs and "npm" not in apt_pkgs:
            apt_pkgs.append("npm")
        prefix, data = remote.sudo_prefix(server["id"], p.get("sudo", "password"))
        apt_str = " ".join(sorted(set(apt_pkgs)))
        script = f"""
set -e
if command -v apt-get >/dev/null 2>&1; then
  {'[ -n "' + apt_str + '" ] && ' + prefix + 'apt-get update && ' + prefix + 'DEBIAN_FRONTEND=noninteractive apt-get install -y ' + apt_str if apt_str else 'true'}
elif command -v dnf >/dev/null 2>&1; then
  {'[ -n "' + apt_str + '" ] && ' + prefix + 'dnf install -y ' + apt_str.replace('docker.io docker-compose-plugin', 'docker docker-compose-plugin') if apt_str else 'true'}
fi
{'if ! command -v pm2 >/dev/null 2>&1; then command -v npm >/dev/null 2>&1 || true; ' + prefix + 'npm install -g pm2; fi' if install_pm2 else ''}
{'if command -v systemctl >/dev/null 2>&1; then ' + prefix + 'systemctl enable --now docker || true; fi' if install_docker else ''}
echo "==> Tool installation complete."
"""
        return f"Install Server Tools · {label}", remote.command(server, script, login=True), remote.env(), data

    raise ValueError(f"Unknown forge action: {action}")
