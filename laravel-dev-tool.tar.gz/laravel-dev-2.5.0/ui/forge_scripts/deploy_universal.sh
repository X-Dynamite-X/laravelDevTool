#!/usr/bin/env bash
# ui/forge_scripts/deploy_universal.sh - Zero-downtime universal deploy across stacks + health check + auto-rollback
set -euo pipefail
{
exec </dev/null

APP_DIR="${1:-}"
STACK="${2:-laravel}"
SOURCE_MODE="${3:-git}"          # git | local_source | local_artifact
DEPLOY_LAYOUT="${4:-inplace}"    # inplace | atomic
REPO_URL="${5:-}"
BRANCH="${6:-main}"
RELEASE_ID="${7:-}"
PORT="${8:-3000}"
PHP_VERSION="${9:-8.3}"
HEALTH_PATH="${10:-/}"
AUTO_ROLLBACK="${11:-1}"
RECIPE_B64="${12:-}"

if [ -z "$APP_DIR" ]; then
  echo "Error: APP_DIR is required." >&2
  exit 1
fi

export GIT_TERMINAL_PROMPT=0
export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh" >/dev/null 2>&1 || true
for p in "$HOME/.volta/bin" "$HOME/.bun/bin" "$HOME/.local/bin" /usr/local/bin; do
  [ -d "$p" ] && PATH="$p:$PATH"
done

APP_SLUG="$(basename "$APP_DIR" | tr -c 'A-Za-z0-9_-' '_')"
DOMAIN_HOST="$(basename "$APP_DIR")"
[ -z "$RELEASE_ID" ] && RELEASE_ID="$(date +%Y%m%d%H%M%S)"

# Configure SSH Deploy Key & non-interactive git transport
KEY_FILE="$HOME/.ssh/ld_${DOMAIN_HOST//./_}"
ORIG_REPO_URL="$REPO_URL"
if [ -f "$KEY_FILE" ]; then
  export GIT_SSH_COMMAND="ssh -i \"$KEY_FILE\" -o IdentitiesOnly=yes -o BatchMode=yes -o StrictHostKeyChecking=accept-new"
  if [[ "$REPO_URL" =~ ^https?://github\.com/([^/]+/[^/.]+)(\.git)?$ ]]; then
    REPO_URL="git@github.com:${BASH_REMATCH[1]}.git"
  fi
else
  export GIT_SSH_COMMAND="${GIT_SSH_COMMAND:-ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new}"
fi

git_clone_safe() {
  local url="$1"
  local br="$2"
  local dest="$3"
  if git clone --depth 1 --branch "$br" "$url" "$dest"; then
    return 0
  fi
  if [ "$url" != "$ORIG_REPO_URL" ] && [ -n "$ORIG_REPO_URL" ]; then
    echo "==> SSH clone failed; retrying with $ORIG_REPO_URL..."
    rm -rf "$dest"
    GIT_SSH_COMMAND="ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new" git clone --depth 1 --branch "$br" "$ORIG_REPO_URL" "$dest"
    return $?
  fi
  return 1
}

# Decode optional JSON recipe via python3 (always available on Linux hosts or fallback gracefully)
PRE_BUILD=""
INSTALL_CMD=""
BUILD_CMD=""
MIGRATE_CMD=""
START_CMD=""
POST_DEPLOY=""
SHARED_PATHS=""
PUBLIC_DIR=""
HEALTH_STATUS="200"

if [ -n "$RECIPE_B64" ] && command -v python3 >/dev/null 2>&1; then
  eval "$(python3 -c '
import base64, json, shlex, sys
try:
    raw = base64.b64decode(sys.argv[1]).decode("utf-8")
    d = json.loads(raw) if raw else {}
except Exception:
    d = {}
for env_k, json_k in (
    ("PRE_BUILD", "pre_build"),
    ("INSTALL_CMD", "install_cmd"),
    ("BUILD_CMD", "build_cmd"),
    ("MIGRATE_CMD", "migrate_cmd"),
    ("START_CMD", "start_cmd"),
    ("POST_DEPLOY", "post_deploy"),
    ("PUBLIC_DIR", "public_dir"),
    ("HEALTH_STATUS", "health_status"),
):
    if d.get(json_k) is not None and str(d.get(json_k)) != "":
        print(f"{env_k}={shlex.quote(str(d[json_k]))}")
if isinstance(d.get("shared_paths"), list):
    print("SHARED_PATHS=" + shlex.quote(" ".join(str(x).strip() for x in d["shared_paths"] if str(x).strip())))
' "$RECIPE_B64")"
fi

echo "==> Universal Deploy: $DOMAIN_HOST ($STACK · $SOURCE_MODE · $DEPLOY_LAYOUT)"

PREV_RELEASE=""
PREV_HEAD=""
REL_DIR="$APP_DIR"

if [ "$DEPLOY_LAYOUT" = "atomic" ]; then
  mkdir -p "$APP_DIR/releases" "$APP_DIR/shared"
  [ "$STACK" = "laravel" ] && mkdir -p "$APP_DIR/shared/storage"
  if [ -L "$APP_DIR/current" ]; then
    PREV_RELEASE="$(readlink -f "$APP_DIR/current" 2>/dev/null || true)"
  fi
  REL_DIR="$APP_DIR/releases/$RELEASE_ID"

  if [ "$SOURCE_MODE" = "git" ]; then
    if [ -z "$REPO_URL" ]; then
      echo "Error: Repository URL is required for Git source mode." >&2
      exit 1
    fi
    echo "==> Cloning $REPO_URL ($BRANCH) into $REL_DIR..."
    git_clone_safe "$REPO_URL" "$BRANCH" "$REL_DIR"
  else
    if [ ! -d "$REL_DIR" ]; then
      echo "Error: Uploaded release directory missing: $REL_DIR" >&2
      exit 1
    fi
    echo "==> Using uploaded release directory $REL_DIR"
  fi
else
  # Standard in-place directory deploy (/var/www/<project>/<all files>)
  mkdir -p "$APP_DIR"
  REL_DIR="$APP_DIR"

  # If this directory previously used atomic layout (releases/ + shared/ + current), migrate to clean in-place
  if [ -L "$APP_DIR/current" ] || [ -d "$APP_DIR/releases" ] || [ -d "$APP_DIR/shared" ]; then
    echo "==> Migrating $APP_DIR from atomic releases to standard in-place directory..."
    if [ -f "$APP_DIR/shared/.env" ] && { [ ! -f "$APP_DIR/.env" ] || [ -L "$APP_DIR/.env" ]; }; then
      rm -f "$APP_DIR/.env"
      cp -p "$APP_DIR/shared/.env" "$APP_DIR/.env"
    fi
    if [ -L "$APP_DIR/storage" ]; then
      rm -f "$APP_DIR/storage"
    fi
    if [ -d "$APP_DIR/shared/storage" ] && [ ! -d "$APP_DIR/storage" ]; then
      mv "$APP_DIR/shared/storage" "$APP_DIR/storage" 2>/dev/null || cp -a "$APP_DIR/shared/storage" "$APP_DIR/storage" 2>/dev/null || true
    fi
    rm -rf "$APP_DIR/current" "$APP_DIR/releases" "$APP_DIR/shared" 2>/dev/null || true
    if [ -f "/etc/nginx/sites-available/$DOMAIN_HOST" ] && grep -q "$APP_DIR/current" "/etc/nginx/sites-available/$DOMAIN_HOST" 2>/dev/null; then
      if [ "$(id -u)" -eq 0 ]; then
        sed -i "s|$APP_DIR/current|$APP_DIR|g" "/etc/nginx/sites-available/$DOMAIN_HOST" && systemctl reload nginx || true
      elif sudo -n true 2>/dev/null; then
        sudo -n sed -i "s|$APP_DIR/current|$APP_DIR|g" "/etc/nginx/sites-available/$DOMAIN_HOST" && sudo -n systemctl reload nginx || true
      fi
    fi
  fi

  if [ -d "$REL_DIR/.git" ]; then
    PREV_HEAD="$(git -C "$REL_DIR" rev-parse HEAD 2>/dev/null || true)"
    [ -n "$PREV_HEAD" ] && echo "$PREV_HEAD" > "$REL_DIR/.ld-last-deploy" 2>/dev/null || true
    if [ "$SOURCE_MODE" = "git" ]; then
      echo "==> Pulling latest $BRANCH in-place at $REL_DIR..."
      git -C "$REL_DIR" fetch origin "$BRANCH" --depth 1 || true
      git -C "$REL_DIR" checkout -f "$BRANCH" 2>/dev/null || git -C "$REL_DIR" checkout -b "$BRANCH" "origin/$BRANCH" 2>/dev/null || true
      git -C "$REL_DIR" reset --hard "origin/$BRANCH" 2>/dev/null || git -C "$REL_DIR" pull --ff-only
    fi
  elif [ "$SOURCE_MODE" = "git" ] && [ -n "$REPO_URL" ]; then
    echo "==> Cloning $REPO_URL ($BRANCH) into $REL_DIR..."
    TMP_CLONE="$REL_DIR/.tmp_clone_$$"
    rm -rf "$TMP_CLONE"
    git_clone_safe "$REPO_URL" "$BRANCH" "$TMP_CLONE"
    if [ -f "$REL_DIR/.env" ]; then
      cp -p "$REL_DIR/.env" "$REL_DIR/.env.ld_keep"
    fi
    cp -a "$TMP_CLONE"/. "$REL_DIR/"
    rm -rf "$TMP_CLONE"
    if [ -f "$REL_DIR/.env.ld_keep" ]; then
      mv -f "$REL_DIR/.env.ld_keep" "$REL_DIR/.env"
    fi
  fi
fi

# Link shared .env & persistent directories in atomic layout
if [ "$DEPLOY_LAYOUT" = "atomic" ]; then
  if [ -f "$APP_DIR/shared/.env" ]; then
    ln -sfn "$APP_DIR/shared/.env" "$REL_DIR/.env"
  fi
  if [ -z "$SHARED_PATHS" ] && [ "$STACK" = "laravel" ]; then
    SHARED_PATHS="storage"
  fi
  for sp in $SHARED_PATHS; do
    [ -z "$sp" ] && continue
    mkdir -p "$APP_DIR/shared/$sp"
    rm -rf "$REL_DIR/$sp"
    mkdir -p "$(dirname "$REL_DIR/$sp")"
    ln -sfn "$APP_DIR/shared/$sp" "$REL_DIR/$sp"
  done
fi

cd "$REL_DIR"

# 1. Pre-build hook
if [ -n "$PRE_BUILD" ]; then
  echo "==> Running pre-build hook..."
  bash -lc "$PRE_BUILD"
fi

# 2. Stack Install & Build Steps
detect_js_pm() {
  if [ -f pnpm-lock.yaml ]; then echo "pnpm"
  elif [ -f yarn.lock ]; then echo "yarn"
  elif [ -f bun.lockb ] || [ -f bun.lock ]; then echo "bun"
  else echo "npm"; fi
}

if [ "$STACK" = "laravel" ]; then
  PHP_BIN="$(command -v "php$PHP_VERSION" || command -v php)"
  COMPOSER_BIN="$(command -v composer || true)"
  export COMPOSER_NO_INTERACTION=1 COMPOSER_ALLOW_SUPERUSER=1
  STORAGE_BASE="$REL_DIR/storage"
  ENV_TARGET="$REL_DIR/.env"
  if [ "$DEPLOY_LAYOUT" = "atomic" ]; then
    STORAGE_BASE="$APP_DIR/shared/storage"
    ENV_TARGET="$APP_DIR/shared/.env"
  fi
  mkdir -p "$STORAGE_BASE/app/public" \
           "$STORAGE_BASE/framework/cache/data" \
           "$STORAGE_BASE/framework/sessions" \
           "$STORAGE_BASE/framework/views" \
           "$STORAGE_BASE/logs" \
           "$REL_DIR/bootstrap/cache" 2>/dev/null || true
  if [ ! -f .env ] && [ -f .env.example ]; then
    cp .env.example .env
  fi
  if [ -f .env ]; then
    if grep -q '^CACHE_DRIVER=file$' .env 2>/dev/null; then
      sed -i 's/^CACHE_DRIVER=file$/CACHE_DRIVER=redis/' .env 2>/dev/null || true
    fi
    if ! grep -q '^CACHE_STORE=' .env 2>/dev/null; then
      echo "CACHE_STORE=redis" >> .env
    fi
    if ! grep -q '^REDIS_HOST=' .env 2>/dev/null; then
      printf "REDIS_HOST=127.0.0.1\nREDIS_PASSWORD=null\nREDIS_PORT=6379\n" >> .env
    fi
    if grep -qE '^DB_CONNECTION=(mysql|mariadb)' .env 2>/dev/null && grep -qE '^DATABASE_URL=' .env 2>/dev/null; then
      grep -vE '^DATABASE_URL=' .env > .env.tmp && mv -f .env.tmp .env || true
    fi
    # Ensure local MySQL user & database match .env before migrations
    _env_val() { grep -E "^${1}=" .env 2>/dev/null | tail -n1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'$//" | tr -d '\r'; }
    _dbc="$(_env_val DB_CONNECTION)"
    _dbh="$(_env_val DB_HOST)"
    _dbp="$(_env_val DB_PORT)"
    _dbn="$(_env_val DB_DATABASE)"
    _dbu="$(_env_val DB_USERNAME)"
    _dbw="$(_env_val DB_PASSWORD)"
    if { [ "$_dbc" = "mysql" ] || [ "$_dbc" = "mariadb" ]; } && { [ "$_dbh" = "127.0.0.1" ] || [ "$_dbh" = "localhost" ]; } && [ -n "$_dbn" ] && [ -n "$_dbu" ]; then
      if command -v mysql >/dev/null 2>&1 && ! MYSQL_PWD="$_dbw" mysql -h 127.0.0.1 -P "${_dbp:-3306}" -u "$_dbu" -e "SELECT 1" "$_dbn" >/dev/null 2>&1; then
        _mysql_root=""
        if [ "$(id -u)" -eq 0 ]; then _mysql_root="mysql"
        elif sudo -n mysql -e "SELECT 1" >/dev/null 2>&1; then _mysql_root="sudo -n mysql"; fi
        if [ -n "$_mysql_root" ]; then
          $_mysql_root -e "CREATE DATABASE IF NOT EXISTS \`$_dbn\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null || true
          for _h in localhost 127.0.0.1; do
            $_mysql_root -e "CREATE USER IF NOT EXISTS '$_dbu'@'$_h' IDENTIFIED BY '$_dbw';" 2>/dev/null || true
            $_mysql_root -e "ALTER USER '$_dbu'@'$_h' IDENTIFIED BY '$_dbw';" 2>/dev/null || true
            $_mysql_root -e "GRANT ALL PRIVILEGES ON \`$_dbn\`.* TO '$_dbu'@'$_h';" 2>/dev/null || true
          done
          $_mysql_root -e "FLUSH PRIVILEGES;" 2>/dev/null || true
        fi
      fi
    fi
  fi
  if [ ! -d vendor ] || [ "$SOURCE_MODE" != "local_artifact" ]; then
    if [ -n "$INSTALL_CMD" ]; then
      echo "==> Installing dependencies..."
      bash -lc "$INSTALL_CMD"
    elif [ -n "$COMPOSER_BIN" ] && [ -f composer.json ]; then
      echo "==> Installing Composer dependencies..."
      "$PHP_BIN" "$COMPOSER_BIN" install --no-dev --optimize-autoloader --prefer-dist --no-progress --no-interaction
    fi
  fi
  if grep -qE '^APP_KEY=\s*$' .env 2>/dev/null; then
    "$PHP_BIN" artisan key:generate --force --no-interaction || true
  fi
  if [ "$SOURCE_MODE" != "local_artifact" ]; then
    if [ -n "$BUILD_CMD" ]; then
      echo "==> Running build step..."
      bash -lc "$BUILD_CMD"
    elif [ -f package.json ] && command -v npm >/dev/null 2>&1; then
      if grep -q '"build"[[:space:]]*:' package.json; then
        echo "==> Building frontend assets..."
        npm ci || npm install
        npm run build
      fi
    fi
  fi
  echo "==> Running Laravel migrations & cache optimization..."
  if [ -n "$MIGRATE_CMD" ]; then
    bash -lc "$MIGRATE_CMD" || echo "Warning: custom migrate_cmd failed" >&2
  else
    "$PHP_BIN" artisan migrate --force --no-interaction || echo "Warning: artisan migrate failed" >&2
  fi
  "$PHP_BIN" artisan optimize --no-interaction || "$PHP_BIN" artisan optimize || true
  if id www-data >/dev/null 2>&1; then
    chgrp -R www-data "$STORAGE_BASE" "$REL_DIR/bootstrap/cache" 2>/dev/null || true
    chmod -R ug+rwX "$STORAGE_BASE" "$REL_DIR/bootstrap/cache" 2>/dev/null || true
    [ -f "$ENV_TARGET" ] && chmod 640 "$ENV_TARGET" 2>/dev/null || true
  fi

elif [ "$STACK" = "node_ssr" ] || [ "$STACK" = "static" ]; then
  PM="$(detect_js_pm)"
  if [ "$SOURCE_MODE" != "local_artifact" ]; then
    if [ -n "$INSTALL_CMD" ]; then
      echo "==> Installing Node dependencies..."
      bash -lc "$INSTALL_CMD"
    elif [ -f package.json ]; then
      echo "==> Installing Node dependencies ($PM)..."
      if [ "$PM" = "npm" ] && [ -f package-lock.json ]; then npm ci; else "$PM" install; fi
    fi
    if [ -n "$BUILD_CMD" ]; then
      echo "==> Building application..."
      bash -lc "$BUILD_CMD"
    elif [ -f package.json ] && grep -q '"build"[[:space:]]*:' package.json; then
      echo "==> Running $PM run build..."
      "$PM" run build
    fi
  else
    echo "==> Artifact mode: skipping remote build step."
    if [ "$STACK" = "node_ssr" ] && [ -f package.json ] && [ ! -d node_modules ] && [ ! -d .output/server/node_modules ]; then
      echo "==> Installing production runtime dependencies..."
      if [ "$PM" = "npm" ]; then npm install --omit=dev || npm install; else "$PM" install --prod || "$PM" install; fi
    fi
  fi

elif [ "$STACK" = "python" ]; then
  VENV_DIR="$APP_DIR/shared/.venv"
  [ "$DEPLOY_LAYOUT" = "inplace" ] && VENV_DIR="$REL_DIR/.venv"
  PY_BIN="python3"
  if [ ! -x "$VENV_DIR/bin/python" ]; then
    echo "==> Creating Python virtual environment in $VENV_DIR..."
    python3 -m venv "$VENV_DIR"
  fi
  PY_BIN="$VENV_DIR/bin/python"
  if [ -n "$INSTALL_CMD" ]; then
    echo "==> Running Python install step..."
    PATH="$VENV_DIR/bin:$PATH" bash -lc "$INSTALL_CMD"
  elif [ -f requirements.txt ]; then
    echo "==> Installing requirements.txt..."
    "$PY_BIN" -m pip install --upgrade pip >/dev/null || true
    "$PY_BIN" -m pip install -r requirements.txt
  fi
  if [ -n "$BUILD_CMD" ]; then
    echo "==> Running Python build step..."
    PATH="$VENV_DIR/bin:$PATH" bash -lc "$BUILD_CMD"
  fi
  if [ -n "$MIGRATE_CMD" ]; then
    echo "==> Running Python migration step..."
    PATH="$VENV_DIR/bin:$PATH" bash -lc "$MIGRATE_CMD" || true
  elif [ -f manage.py ]; then
    echo "==> Running Django migrate & collectstatic..."
    "$PY_BIN" manage.py migrate --noinput || true
    "$PY_BIN" manage.py collectstatic --noinput || true
  fi

elif [ "$STACK" = "docker" ]; then
  if ! command -v docker >/dev/null 2>&1; then
    echo "Error: Docker is not installed on the server." >&2
    exit 1
  fi
  if [ ! -f docker-compose.yml ] && [ ! -f docker-compose.yaml ] && [ ! -f compose.yml ] && [ ! -f compose.yaml ]; then
    if [ -f Dockerfile ]; then
      cat <<EOF > docker-compose.yml
services:
  app:
    build: .
    restart: unless-stopped
    ports:
      - "127.0.0.1:${PORT}:${PORT}"
    env_file:
      - .env
EOF
    else
      echo "Error: Neither Dockerfile nor docker-compose.yml found in $REL_DIR" >&2
      exit 1
    fi
  fi
  echo "==> Validating Docker configuration..."
  docker compose -p "$APP_SLUG" config >/dev/null
fi

reload_runtime() {
  local TARGET_DIR="$1"
  cd "$TARGET_DIR"
  if [ "$STACK" = "laravel" ]; then
    local PBIN
    PBIN="$(command -v "php$PHP_VERSION" || command -v php)"
    "$PBIN" artisan queue:restart || true
    if command -v systemctl >/dev/null 2>&1; then
      if [ "$(id -u)" -eq 0 ]; then
        systemctl reload "php${PHP_VERSION}-fpm" || systemctl reload php-fpm || true
      else
        sudo -n systemctl reload "php${PHP_VERSION}-fpm" || sudo -n systemctl reload php-fpm || true
      fi
    fi
  elif [ "$STACK" = "node_ssr" ]; then
    local CMD="${START_CMD:-node .output/server/index.mjs}"
    [ -f package.json ] && [ -z "$START_CMD" ] && [ ! -f .output/server/index.mjs ] && CMD="npm start"
    export PORT="$PORT"
    if command -v pm2 >/dev/null 2>&1; then
      pm2 delete "$APP_SLUG" >/dev/null 2>&1 || true
      PORT="$PORT" pm2 start bash --name "$APP_SLUG" --cwd "$TARGET_DIR" -- -lc "$CMD"
      pm2 save >/dev/null 2>&1 || true
    else
      echo "Warning: PM2 is not installed. Run '$CMD' on port $PORT or install PM2." >&2
    fi
  elif [ "$STACK" = "python" ]; then
    local UNIT="laravel-dev-${APP_SLUG}.service"
    local VENV_BIN="$APP_DIR/shared/.venv/bin"
    [ "$DEPLOY_LAYOUT" = "inplace" ] && VENV_BIN="$TARGET_DIR/.venv/bin"
    local CMD="${START_CMD:-gunicorn --bind 127.0.0.1:$PORT config.wsgi:application}"
    if command -v systemctl >/dev/null 2>&1 && { [ "$(id -u)" -eq 0 ] || sudo -n true 2>/dev/null; }; then
      local SUDO=""
      [ "$(id -u)" -ne 0 ] && SUDO="sudo -n "
      if [ ! -f "/etc/systemd/system/$UNIT" ]; then
        ${SUDO}tee "/etc/systemd/system/$UNIT" >/dev/null <<UNITFILE
[Unit]
Description=Laravel Dev Python App ($APP_SLUG)
After=network.target

[Service]
Type=simple
WorkingDirectory=$TARGET_DIR
Environment=PORT=$PORT
Environment=PATH=$VENV_BIN:/usr/local/bin:/usr/bin:/bin
ExecStart=/bin/bash -lc '$CMD'
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNITFILE
        ${SUDO}systemctl daemon-reload
        ${SUDO}systemctl enable "$UNIT" >/dev/null 2>&1 || true
      fi
      ${SUDO}systemctl restart "$UNIT"
    elif command -v pm2 >/dev/null 2>&1; then
      pm2 delete "$APP_SLUG" >/dev/null 2>&1 || true
      PORT="$PORT" PATH="$VENV_BIN:$PATH" pm2 start bash --name "$APP_SLUG" --cwd "$TARGET_DIR" -- -lc "$CMD"
      pm2 save >/dev/null 2>&1 || true
    fi
  elif [ "$STACK" = "docker" ]; then
    docker compose -p "$APP_SLUG" up -d --build --remove-orphans
  elif [ "$STACK" = "static" ]; then
    if command -v systemctl >/dev/null 2>&1; then
      if [ "$(id -u)" -eq 0 ]; then systemctl reload nginx || true; else sudo -n systemctl reload nginx || true; fi
    fi
  fi
}

# 3. Atomic Symlink Switch
if [ "$DEPLOY_LAYOUT" = "atomic" ]; then
  echo "==> Switching active symlink to release $RELEASE_ID..."
  ln -sfn "$REL_DIR" "$APP_DIR/current.tmp"
  mv -Tf "$APP_DIR/current.tmp" "$APP_DIR/current"
  ACTIVE_DIR="$APP_DIR/current"
else
  ACTIVE_DIR="$REL_DIR"
fi

# 4. Reload Runtime
echo "==> Starting / reloading $STACK runtime..."
RUNTIME_OK=1
if ! reload_runtime "$ACTIVE_DIR"; then
  RUNTIME_OK=0
fi

# 5. Optional Post-Deploy Hook
if [ "$RUNTIME_OK" -eq 1 ] && [ -n "$POST_DEPLOY" ]; then
  echo "==> Running post-deploy hook..."
  (cd "$ACTIVE_DIR" && bash -lc "$POST_DEPLOY") || RUNTIME_OK=0
fi

# 6. HTTP Health Check & Auto-Rollback
run_health_check() {
  [ -z "$HEALTH_PATH" ] && return 0
  if [ "$STACK" = "static" ]; then
    local chk_url="http://127.0.0.1${HEALTH_PATH}"
    curl -fsS --max-time 6 -H "Host: $DOMAIN_HOST" "$chk_url" >/dev/null 2>&1 && return 0
    return 0
  fi
  local target_url="http://127.0.0.1:${PORT}${HEALTH_PATH}"
  [ "$STACK" = "laravel" ] && target_url="http://127.0.0.1${HEALTH_PATH}"
  echo "==> Checking application health: $target_url (expecting HTTP 2xx/3xx)..."
  for attempt in 1 2 3 4 5; do
    if [ "$STACK" = "laravel" ]; then
      code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 -H "Host: $DOMAIN_HOST" "$target_url" || echo "000")
    else
      code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "$target_url" || echo "000")
    fi
    if [ "$code" -ge 200 ] 2>/dev/null && [ "$code" -lt 400 ] 2>/dev/null; then
      echo "==> Health check passed (HTTP $code)."
      return 0
    fi
    if [ "$STACK" = "laravel" ] && [ "$code" -ge 400 ] 2>/dev/null && [ "$code" -lt 500 ] 2>/dev/null; then
      echo "==> Health check passed (HTTP $code — Nginx & PHP-FPM responding)."
      return 0
    fi
    sleep 2
  done
  echo "Error: Health check failed after 5 attempts (last HTTP status: ${code:-000})." >&2
  return 1
}

if [ "$RUNTIME_OK" -eq 0 ] || ! run_health_check; then
  if [ "$AUTO_ROLLBACK" = "1" ]; then
    echo "==> [AUTO-ROLLBACK] Reverting to previous healthy state..." >&2
    if [ "$DEPLOY_LAYOUT" = "atomic" ] && [ -n "$PREV_RELEASE" ] && [ -d "$PREV_RELEASE" ]; then
      ln -sfn "$PREV_RELEASE" "$APP_DIR/current.tmp"
      mv -Tf "$APP_DIR/current.tmp" "$APP_DIR/current"
      reload_runtime "$APP_DIR/current" || true
      echo "==> [AUTO-ROLLBACK] Restored release $(basename "$PREV_RELEASE")." >&2
      exit 42
    elif [ "$DEPLOY_LAYOUT" = "inplace" ] && [ -n "$PREV_HEAD" ] && [ -d "$APP_DIR/.git" ]; then
      git -C "$APP_DIR" reset --hard "$PREV_HEAD" || true
      reload_runtime "$APP_DIR" || true
      echo "==> [AUTO-ROLLBACK] Reset git HEAD to $PREV_HEAD." >&2
      exit 42
    fi
  fi
  exit 1
fi

# 7. Release Pruning (keep latest 5)
if [ "$DEPLOY_LAYOUT" = "atomic" ] && [ -d "$APP_DIR/releases" ]; then
  echo "==> Pruning old releases (keeping latest 5)..."
  CUR_NAME="$(basename "$(readlink -f "$APP_DIR/current" 2>/dev/null || echo '')")"
  find "$APP_DIR/releases" -mindepth 1 -maxdepth 1 -type d -printf '%T@\t%f\n' 2>/dev/null \
    | sort -nr | awk '{print $2}' | tail -n +6 | while read -r old; do
      [ "$old" != "$CUR_NAME" ] && rm -rf "$APP_DIR/releases/$old"
    done || true
fi

if [ "$STACK" = "docker" ]; then
  docker image prune -f >/dev/null 2>&1 || true
fi

echo "==> Deployment complete! Release $RELEASE_ID is live."
exit 0
}
