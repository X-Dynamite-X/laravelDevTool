#!/usr/bin/env bash
# ui/forge_scripts/create_universal_site.sh - Unified multi-stack remote site scaffold & Nginx setup
set -euo pipefail
{
exec </dev/null

DOMAIN="${1:-}"
STACK="${2:-laravel}"
APP_DIR="${3:-}"
PORT="${4:-3000}"
PUBLIC_DIR="${5:-dist}"
PHP_VERSION="${6:-8.3}"
DB_ENGINE="${7:-none}"
DB_NAME="${8:-}"
DB_USER="${9:-}"
DB_PASS="${10:-}"
DB_HOST="${11:-127.0.0.1}"
DB_PORT_ARG="${12:-}"
DB_MODE="${13:-create}"
DEPLOY_LAYOUT="${14:-inplace}"

if [ -z "$DOMAIN" ]; then
  echo "Error: DOMAIN is required." >&2
  exit 1
fi

[ -z "$APP_DIR" ] && APP_DIR="/var/www/$DOMAIN"
DEPLOY_USER="${SUDO_USER:-$(id -un)}"
WEB_USER="www-data"
id www-data >/dev/null 2>&1 || WEB_USER="$DEPLOY_USER"

echo "==> Scaffolding $STACK site $DOMAIN at $APP_DIR ($DEPLOY_LAYOUT)..."
mkdir -p "$APP_DIR"

if [ "$DEPLOY_LAYOUT" = "atomic" ]; then
  mkdir -p "$APP_DIR/releases" "$APP_DIR/shared"
  if [ "$STACK" = "laravel" ]; then
    mkdir -p "$APP_DIR/shared/storage/app/public" \
             "$APP_DIR/shared/storage/framework/cache/data" \
             "$APP_DIR/shared/storage/framework/sessions" \
             "$APP_DIR/shared/storage/framework/views" \
             "$APP_DIR/shared/storage/logs"
  elif [ "$STACK" = "python" ]; then
    mkdir -p "$APP_DIR/shared/media"
  fi
  SITE_ROOT_BASE="$APP_DIR/current"
  ENV_FILE="$APP_DIR/shared/.env"
  STORAGE_ROOT="$APP_DIR/shared/storage"
else
  # Standard in-place layout: /var/www/<domain>/<all project files>
  # Migrate from previous atomic structure if it existed on this directory
  if [ -f "$APP_DIR/shared/.env" ] && { [ ! -f "$APP_DIR/.env" ] || [ -L "$APP_DIR/.env" ]; }; then
    rm -f "$APP_DIR/.env"
    cp -p "$APP_DIR/shared/.env" "$APP_DIR/.env"
  fi
  if [ -L "$APP_DIR/storage" ]; then
    rm -f "$APP_DIR/storage"
  fi
  if [ -d "$APP_DIR/shared/storage" ] && [ ! -d "$APP_DIR/storage" ]; then
    mv "$APP_DIR/shared/storage" "$APP_DIR/storage" 2>/dev/null || cp -a "$APP_DIR/shared/storage" "$APP_DIR/storage" 2>/dev/null || true
  fi
  if [ -L "$APP_DIR/current" ] || [ -d "$APP_DIR/releases" ] || [ -d "$APP_DIR/shared" ]; then
    rm -rf "$APP_DIR/current" "$APP_DIR/releases" "$APP_DIR/shared" 2>/dev/null || true
  fi

  if [ "$STACK" = "laravel" ]; then
    mkdir -p "$APP_DIR/storage/app/public" \
             "$APP_DIR/storage/framework/cache/data" \
             "$APP_DIR/storage/framework/sessions" \
             "$APP_DIR/storage/framework/views" \
             "$APP_DIR/storage/logs" \
             "$APP_DIR/bootstrap/cache" \
             "$APP_DIR/public"
  elif [ "$STACK" = "python" ]; then
    mkdir -p "$APP_DIR/media"
  fi
  SITE_ROOT_BASE="$APP_DIR"
  ENV_FILE="$APP_DIR/.env"
  STORAGE_ROOT="$APP_DIR/storage"
fi

# Configure Nginx vhost if nginx directory exists and we have permissions
NGINX_DIR="/etc/nginx"
if [ -d "$NGINX_DIR/sites-available" ] && [ -w "$NGINX_DIR/sites-available" ]; then
  VHOST_AVAIL="$NGINX_DIR/sites-available/$DOMAIN"
  VHOST_ENAB="$NGINX_DIR/sites-enabled/$DOMAIN"

  if [ "$STACK" = "laravel" ]; then
    PHP_SOCK="/run/php/php${PHP_VERSION}-fpm.sock"
    [ ! -S "$PHP_SOCK" ] && PHP_SOCK="/run/php-fpm/www.sock"
    cat <<NGINX > "$VHOST_AVAIL"
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN www.$DOMAIN;
    root $SITE_ROOT_BASE/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
    index index.php index.html;
    charset utf-8;
    client_max_body_size 64M;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }
    error_page 404 /index.php;

    location ~ \.php\$ {
        fastcgi_pass unix:$PHP_SOCK;
        fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_hide_header X-Powered-By;
    }

    location ~ /\.(?!well-known).* { deny all; }
}
NGINX
  elif [ "$STACK" = "static" ]; then
    STATIC_ROOT="$SITE_ROOT_BASE/$PUBLIC_DIR"
    if [ -z "$PUBLIC_DIR" ] || [ "$PUBLIC_DIR" = "." ]; then
      STATIC_ROOT="$SITE_ROOT_BASE"
    fi
    cat <<NGINX > "$VHOST_AVAIL"
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN www.$DOMAIN;
    root $STATIC_ROOT;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
    index index.html index.htm;
    charset utf-8;

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff2?)$ {
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }

    location ~ /\.(?!well-known).* { deny all; }
}
NGINX
  else
    # node_ssr, python, docker -> reverse proxy to 127.0.0.1:$PORT
    cat <<NGINX > "$VHOST_AVAIL"
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN www.$DOMAIN;
    client_max_body_size 64M;

    location / {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }

    location ~ /\.(?!well-known).* { deny all; }
}
NGINX
  fi

  [ -d "$NGINX_DIR/sites-enabled" ] && ln -sfn "$VHOST_AVAIL" "$VHOST_ENAB"
  if nginx -t >/dev/null 2>&1; then
    systemctl reload nginx || true
    echo "==> Nginx vhost configured ($STACK) and reloaded."
  else
    echo "Warning: Nginx config test reported issues. Inspect $VHOST_AVAIL" >&2
  fi
else
  echo "==> Skipping /etc/nginx configuration (no Nginx or no root/write access)."
fi

# Initialize or reuse existing password from .env when DB_PASS is blank
if [ "$DB_ENGINE" != "none" ] && [ -n "$DB_NAME" ] && [ -n "$DB_USER" ] && [ -z "$DB_PASS" ]; then
  if [ -f "$ENV_FILE" ]; then
    EXISTING_PASS="$(grep -E '^DB_PASSWORD=' "$ENV_FILE" 2>/dev/null | tail -n1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'$//" | tr -d '\r' || true)"
    if [ -n "$EXISTING_PASS" ] && [ "$EXISTING_PASS" != "null" ]; then
      DB_PASS="$EXISTING_PASS"
    fi
  fi
  if [ -z "$DB_PASS" ]; then
    DB_PASS="$(openssl rand -hex 12 2>/dev/null || head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n' | head -c 24)"
  fi
fi

# Database setup when requested
DB_URL=""
DB_PORT="3306"
[ "$DB_ENGINE" = "pgsql" ] || [ "$DB_ENGINE" = "postgresql" ] && DB_PORT="5432"
[ -n "$DB_PORT_ARG" ] && DB_PORT="$DB_PORT_ARG"

if [ "$DB_ENGINE" != "none" ] && [ -n "$DB_NAME" ] && [ -n "$DB_USER" ]; then
  if [ "$DB_ENGINE" = "mysql" ] || [ "$DB_ENGINE" = "mariadb" ]; then
    DB_URL="mysql://${DB_USER}:${DB_PASS}@${DB_HOST}:${DB_PORT}/${DB_NAME}"
    if [ "$DB_MODE" != "existing" ] && command -v mysql >/dev/null 2>&1; then
      echo "==> Configuring database ($DB_ENGINE: $DB_NAME)..."
      mysql -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" || true
      if [ -n "$DB_PASS" ]; then
        for db_host_target in localhost 127.0.0.1; do
          mysql -e "CREATE USER IF NOT EXISTS '$DB_USER'@'$db_host_target' IDENTIFIED BY '$DB_PASS';" || true
          mysql -e "ALTER USER '$DB_USER'@'$db_host_target' IDENTIFIED BY '$DB_PASS';" || true
          mysql -e "GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'$db_host_target';" || true
        done
      else
        for db_host_target in localhost 127.0.0.1; do
          mysql -e "CREATE USER IF NOT EXISTS '$DB_USER'@'$db_host_target';" || true
          mysql -e "GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'$db_host_target';" || true
        done
      fi
      mysql -e "FLUSH PRIVILEGES;" || true
      echo "==> MySQL database $DB_NAME ready."
    fi
  elif [ "$DB_ENGINE" = "pgsql" ] || [ "$DB_ENGINE" = "postgresql" ]; then
    DB_URL="postgresql://${DB_USER}:${DB_PASS}@${DB_HOST}:${DB_PORT}/${DB_NAME}"
    if [ "$DB_MODE" != "existing" ] && command -v psql >/dev/null 2>&1; then
      echo "==> Configuring database ($DB_ENGINE: $DB_NAME)..."
      sudo -u postgres psql -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '$DB_USER') THEN CREATE ROLE \"$DB_USER\" WITH LOGIN PASSWORD '$DB_PASS'; END IF; END \$\$;" || true
      sudo -u postgres psql -c "ALTER ROLE \"$DB_USER\" WITH PASSWORD '$DB_PASS';" || true
      sudo -u postgres psql -c "SELECT 'CREATE DATABASE \"$DB_NAME\" OWNER \"$DB_USER\"' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '$DB_NAME')\gexec" || true
      sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE \"$DB_NAME\" TO \"$DB_USER\";" || true
      echo "==> PostgreSQL database $DB_NAME ready."
    fi
  fi
fi

upsert_env_key() {
  local k="$1" v="$2" f="$3"
  if grep -qE "^${k}=" "$f" 2>/dev/null; then
    grep -vE "^${k}=" "$f" > "${f}.tmp" && mv -f "${f}.tmp" "$f"
  fi
  printf '%s=%s\n' "$k" "$v" >> "$f"
}

# Initialize shared/.env if missing
if [ ! -f "$ENV_FILE" ]; then
  cat <<ENV > "$ENV_FILE"
APP_NAME="$DOMAIN"
APP_ENV=production
APP_URL=http://$DOMAIN
NODE_ENV=production
PORT=$PORT
ENV
  if [ "$STACK" = "laravel" ]; then
    cat <<ENV >> "$ENV_FILE"
APP_KEY=
APP_DEBUG=false
LOG_CHANNEL=stack
CACHE_STORE=redis
CACHE_DRIVER=redis
SESSION_DRIVER=redis
QUEUE_CONNECTION=redis
REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379
ENV
  fi
  chmod 640 "$ENV_FILE" 2>/dev/null || true
  echo "==> Initialized $ENV_FILE"
fi

if [ "$DB_ENGINE" != "none" ] && [ -n "$DB_NAME" ] && [ -f "$ENV_FILE" ]; then
  upsert_env_key "DB_CONNECTION" "$DB_ENGINE" "$ENV_FILE"
  upsert_env_key "DB_HOST" "$DB_HOST" "$ENV_FILE"
  upsert_env_key "DB_PORT" "$DB_PORT" "$ENV_FILE"
  upsert_env_key "DB_DATABASE" "$DB_NAME" "$ENV_FILE"
  upsert_env_key "DB_USERNAME" "$DB_USER" "$ENV_FILE"
  upsert_env_key "DB_PASSWORD" "$DB_PASS" "$ENV_FILE"
  if [ "$STACK" = "laravel" ]; then
    if grep -qE '^DATABASE_URL=' "$ENV_FILE" 2>/dev/null; then
      grep -vE '^DATABASE_URL=' "$ENV_FILE" > "${ENV_FILE}.tmp" && mv -f "${ENV_FILE}.tmp" "$ENV_FILE"
    fi
  elif [ -n "$DB_URL" ]; then
    upsert_env_key "DATABASE_URL" "\"$DB_URL\"" "$ENV_FILE"
  fi
  echo "==> Synchronized database credentials in $ENV_FILE"
fi

chown -R "$DEPLOY_USER:$WEB_USER" "$APP_DIR" 2>/dev/null || chown -R "$DEPLOY_USER:$DEPLOY_USER" "$APP_DIR" 2>/dev/null || true
[ -f "$ENV_FILE" ] && chmod 640 "$ENV_FILE" 2>/dev/null || true
if [ "$STACK" = "laravel" ] && [ -d "$STORAGE_ROOT" ]; then
  chmod -R ug+rwX "$STORAGE_ROOT" 2>/dev/null || true
fi

echo "==> Universal site scaffold complete for $DOMAIN ($STACK)!"
exit 0
}
