"""macOS / Windows window: the system web view through pywebview (WKWebView on
macOS, Edge WebView2 on Windows, WebKitGTK or Qt on Linux), so no browser
engine is bundled and memory stays low."""

import os
import threading

import webview

import osutil

from backend import Backend
from sites import UI_DIR


def _dialog_types():
    kinds = getattr(webview, "FileDialog", None)
    if kinds is not None:  # pywebview >= 5
        return {"folder": kinds.FOLDER, "open": kinds.OPEN, "save": kinds.SAVE}
    return {"folder": webview.FOLDER_DIALOG, "open": webview.OPEN_DIALOG, "save": webview.SAVE_DIALOG}


class Bridge:
    """Exposed to JavaScript as window.pywebview.api."""

    def __init__(self, shell):
        self._shell = shell

    def post(self, message):
        self._shell.backend.handle(message)


class WebviewShell:
    has_tray = False

    def __init__(self, start_hidden=False, initial_route=""):
        self.start_hidden = start_hidden
        self.initial_route = initial_route or ""
        self.window = None
        self._web_windows = {}
        self._web_urls = {"github": "https://github.com", "cloudflare": "https://dash.cloudflare.com"}
        self.ready = threading.Event()
        self.backend = Backend(self)

    def _open_web_window(self, key: str, title: str, url: str, default_url: str, bg: str = "#0d1117"):
        target = (url or default_url).strip()
        if not target.startswith(("http://", "https://")):
            target = default_url
        self._web_urls[key] = target
        try:
            existing = self._web_windows.get(key)
            if existing is not None:
                try:
                    existing.load_url(target)
                    return {"ok": True}
                except Exception:
                    self._web_windows.pop(key, None)
            win = webview.create_window(
                title,
                url=target,
                width=1240,
                height=780,
                min_size=(860, 560),
                background_color=bg,
            )
            self._web_windows[key] = win

            def _on_closed():
                self._web_windows.pop(key, None)

            win.events.closed += _on_closed
            return {"ok": True}
        except Exception:
            osutil.open_path(target)
            return {"ok": True, "external": True}

    def _close_web_window(self, key: str):
        win = self._web_windows.pop(key, None)
        if win is not None:
            try:
                win.destroy()
            except Exception:
                pass

    def _nav_web_window(self, key: str, action: str = "reload", url: str = ""):
        win = self._web_windows.get(key)
        if win is None:
            return
        try:
            if action in ("load", "goto") and url.startswith(("http://", "https://")):
                win.load_url(url)
                self._web_urls[key] = url
            elif action == "reload" and hasattr(win, "evaluate_js"):
                win.evaluate_js("location.reload()")
        except Exception:
            pass

    def open_github_browser(self, url="https://github.com"):
        return self._open_web_window("github", "GitHub — Laravel Dev", url, "https://github.com", "#0d1117")

    def close_github_browser(self):
        self._close_web_window("github")

    def nav_github_browser(self, action="reload", url=""):
        self._nav_web_window("github", action=action, url=url)

    def get_github_browser_status(self):
        return {
            "ok": True,
            "supported": True,
            "embedded": False,
            "active": "github" in self._web_windows,
            "url": self._web_urls.get("github", "https://github.com"),
            "repo": "",
        }

    def open_cf_browser(self, url="https://dash.cloudflare.com"):
        return self._open_web_window("cloudflare", "Cloudflare — Laravel Dev", url, "https://dash.cloudflare.com", "#0f172a")

    def close_cf_browser(self):
        self._close_web_window("cloudflare")

    def nav_cf_browser(self, action="reload", url=""):
        self._nav_web_window("cloudflare", action=action, url=url)

    def get_cf_browser_status(self):
        return {
            "ok": True,
            "supported": True,
            "embedded": False,
            "active": "cloudflare" in self._web_windows,
            "url": self._web_urls.get("cloudflare", "https://dash.cloudflare.com"),
        }

    # shell interface used by Backend
    def post(self, fn, *args):
        fn(*args)  # pywebview calls are thread-safe

    def eval_js(self, script):
        if self.window is not None and self.ready.is_set():
            try:
                self.window.evaluate_js(script)
            except Exception:  # noqa: BLE001 — window closing
                pass

    def is_active(self):
        return True

    def notify(self, title, body, task_id=""):
        osutil.send_desktop_notification(title, body)

    def refresh_tray(self, *_):
        return False

    def choose(self, kind, title, done, start=None, multiple=False, name=None, accept="Select"):
        def ask():
            try:
                result = self.window.create_file_dialog(
                    _dialog_types()[kind], directory=start if start and os.path.isdir(start) else "",
                    allow_multiple=multiple, save_filename=name or "")
            except Exception:  # noqa: BLE001
                result = None
            if isinstance(result, str):
                result = [result]
            done(list(result or []))
        threading.Thread(target=ask, daemon=True).start()

    def run(self):
        base_url = (UI_DIR / "web" / "index.html").as_uri()
        if self.initial_route:
            base_url = f"{base_url}#{self.initial_route}"
        self.window = webview.create_window(
            "Laravel Dev", url=base_url, js_api=Bridge(self),
            # No tray icon here, so a hidden window could never be shown again: ignore --hidden.
            width=1240, height=780, min_size=(860, 560), background_color="#f6f6f7",
        )
        self.window.events.loaded += self.ready.set
        self.window.events.closed += self.backend.shutdown
        webview.start(debug=bool(os.environ.get("LARAVEL_DEV_DEBUG")))
        return 0


def run(start_hidden=False, initial_route=""):
    return WebviewShell(start_hidden=start_hidden, initial_route=initial_route).run()
