#!/usr/bin/env python3
"""System-wide keyboard shortcuts that open Laravel Dev pages from anywhere.

They are registered as the desktop's own custom shortcuts (GNOME through gsettings, Xfce
through xfconf), so they work on X11 and Wayland and the app needs no key grabber. Nothing
is registered until the user asks, and a key that is already taken is never replaced.

    laravel-dev shortcuts [status|install|remove] [--json]
"""
from __future__ import annotations

import ast
import json
import os
import shutil
import subprocess
import sys

# id, English, Arabic, keys (GTK accelerator), page
ACTIONS = (
    ("open", "Open Laravel Dev", "فتح Laravel Dev", "<Alt><Super>d", "sites"),
    ("tinker", "Tinker", "Tinker", "<Alt><Super>t", "tinker"),
    ("logs", "Logs", "السجلات", "<Alt><Super>g", "logs"),
    ("mail", "Mail", "البريد", "<Alt><Super>m", "mail"),
    ("database", "Database", "قواعد البيانات", "<Alt><Super>b", "database"),
    ("new", "New site", "موقع جديد", "<Alt><Super>n", "new"),
)
MARK = " app --page="

GNOME_SCHEMA = "org.gnome.settings-daemon.plugins.media-keys"
GNOME_BASE = "/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/"
XFCE = ("xfconf-query", "-c", "xfce4-keyboard-shortcuts")
XFCE_BASE = "/commands/custom/"


def _run(*argv: str) -> str:
    proc = subprocess.run(argv, capture_output=True, text=True, timeout=10)
    if proc.returncode != 0:
        raise OSError((proc.stderr or proc.stdout).strip() or f"{argv[0]} failed")
    return proc.stdout.strip()


def normalize(accel: str) -> str:
    """Same keys, same text: '<Super><Alt>T' and '<Alt><Super>t' are one shortcut."""
    mods, key = [], accel
    while key.startswith("<") and ">" in key:
        mod, key = key[1:].split(">", 1)
        mod = mod.lower()
        mods.append({"primary": "ctrl", "control": "ctrl", "mod4": "super", "mod1": "alt"}.get(mod, mod))
    return "+".join(sorted(set(mods)) + [key.lower()])


def pretty(accel: str) -> str:
    return "+".join(part.capitalize() for part in normalize(accel).split("+"))


def command(page: str) -> str:
    cli = shutil.which("laravel-dev") or os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "bin", "laravel-dev")
    return f"{cli}{MARK}{page}"


class Gnome:
    name = "GNOME"

    @staticmethod
    def paths() -> list[str]:
        raw = _run("gsettings", "get", GNOME_SCHEMA, "custom-keybindings").removeprefix("@as ")
        return list(ast.literal_eval(raw) if raw else [])

    @staticmethod
    def _key(path: str) -> str:
        return f"{GNOME_SCHEMA}.custom-keybinding:{path}"

    def bindings(self) -> dict[str, str]:
        """{normalized keys: what uses them}"""
        out = {}
        for path in self.paths():
            keys = ast.literal_eval(_run("gsettings", "get", self._key(path), "binding"))
            out[normalize(keys)] = ast.literal_eval(_run("gsettings", "get", self._key(path), "command"))
        for schema in ("org.gnome.desktop.wm.keybindings", "org.gnome.shell.keybindings", "org.gnome.mutter.keybindings"):
            try:
                lines = _run("gsettings", "list-recursively", schema).splitlines()
            except OSError:
                continue
            for line in lines:
                _schema, key, value = line.split(" ", 2)
                try:
                    for accel in ast.literal_eval(value.removeprefix("@as ")):
                        out.setdefault(normalize(accel), key)
                except (ValueError, SyntaxError, TypeError):
                    continue
        return out

    def add(self, ident: str, label: str, keys: str, cmd: str) -> None:
        path = f"{GNOME_BASE}laravel-dev-{ident}/"
        for field, value in (("name", f"Laravel Dev: {label}"), ("command", cmd), ("binding", keys)):
            _run("gsettings", "set", self._key(path), field, value)
        paths = self.paths()
        if path not in paths:
            _run("gsettings", "set", GNOME_SCHEMA, "custom-keybindings", str(paths + [path]))

    def remove_all(self) -> None:
        paths = self.paths()
        ours = [p for p in paths if p.startswith(f"{GNOME_BASE}laravel-dev-")]
        if not ours:
            return
        _run("gsettings", "set", GNOME_SCHEMA, "custom-keybindings", str([p for p in paths if p not in ours]))
        for path in ours:
            _run("gsettings", "reset-recursively", self._key(path))


class Xfce:
    name = "Xfce"

    @staticmethod
    def _props() -> dict[str, str]:
        out = {}
        for line in _run(*XFCE, "-l", "-v").splitlines():
            prop, _, value = line.partition(" ")
            out[prop.strip()] = value.strip()
        return out

    def bindings(self) -> dict[str, str]:
        out = {}
        for prop, value in self._props().items():
            for base in (XFCE_BASE, "/xfwm4/custom/"):
                if prop.startswith(base) and prop != base + "override":
                    out[normalize(prop[len(base):])] = value
        return out

    def add(self, _ident: str, _label: str, keys: str, cmd: str) -> None:
        if self._props().get(XFCE_BASE + "override") != "true":
            # Without it Xfce ignores custom shortcuts; turning it on here would hide its defaults.
            raise OSError("Open Xfce's Settings → Keyboard → Application Shortcuts once, then try again.")
        _run(*XFCE, "-p", XFCE_BASE + keys, "-n", "-t", "string", "-s", cmd)

    def remove_all(self) -> None:
        for prop, value in self._props().items():
            if prop.startswith(XFCE_BASE) and MARK in value and "laravel-dev" in value:
                _run(*XFCE, "-p", prop, "-r")


def desktop():
    current = os.environ.get("XDG_CURRENT_DESKTOP", "").upper()
    if "XFCE" in current and shutil.which("xfconf-query"):
        return Xfce()
    if any(d in current for d in ("GNOME", "UNITY", "BUDGIE")) and shutil.which("gsettings"):
        return Gnome()
    return None


def status() -> dict:
    de = desktop()
    used = de.bindings() if de else {}
    rows = []
    for ident, label, label_ar, keys, page in ACTIONS:
        owner = used.get(normalize(keys), "")
        mine = MARK + page in owner and "laravel-dev" in owner
        rows.append({"id": ident, "label": label, "label_ar": label_ar, "keys": pretty(keys), "command": command(page),
                     "installed": mine, "conflict": "" if mine else owner})
    return {"ok": True, "supported": de is not None, "desktop": de.name if de else os.environ.get("XDG_CURRENT_DESKTOP", ""),
            "installed": any(r["installed"] for r in rows), "shortcuts": rows}


def install() -> dict:
    de = desktop()
    if de is None:
        raise OSError("Shortcuts can be added automatically on GNOME and Xfce. On other desktops, add the listed commands "
                      "in the keyboard settings.")
    de.remove_all()  # an older copy may use another path or keys
    used = de.bindings()
    for ident, label, _ar, keys, page in ACTIONS:
        if normalize(keys) not in used:
            de.add(ident, label, keys, command(page))
    return status()


def remove() -> dict:
    de = desktop()
    if de is not None:
        de.remove_all()
    return status()


def main(argv: list[str]) -> int:
    as_json = "--json" in argv
    words = [a for a in argv if not a.startswith("-")]
    op = words[0] if words else "status"
    if op not in ("status", "install", "remove"):
        print("Usage: laravel-dev shortcuts [status|install|remove] [--json]", file=sys.stderr)
        return 1
    try:
        res = {"status": status, "install": install, "remove": remove}[op]()
    except (OSError, subprocess.SubprocessError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    if as_json:
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0
    if not res["supported"]:
        print(f"Desktop '{res['desktop']}' is not handled automatically. Add these commands in its keyboard settings:")
    for row in res["shortcuts"]:
        state = "on" if row["installed"] else f"taken by: {row['conflict']}" if row["conflict"] else "off"
        print(f"  {row['keys']:<14} {row['label']:<18} {state:<10} {row['command'] if not res['supported'] else ''}".rstrip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
