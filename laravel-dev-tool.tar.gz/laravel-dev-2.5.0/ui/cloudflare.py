"""Cloudflare API Integration Client for Laravel Dev Tool.
Provides lightweight, dependency-free interactions with Cloudflare REST API v4 & GraphQL:
Token verification, Zones, DNS records, SSL/TLS & Edge settings, Cache purging,
Analytics, WAF/Firewall/IP Access/Page Rules, R2 Object Storage, Named Tunnels & Ingress,
Workers, KV Namespaces, Pages, D1 Databases, Turnstile Widgets, and Email Routing.
"""

from __future__ import annotations

import datetime
import json
import os
from pathlib import Path
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

try:
    from osutil import private_file
except ImportError:
    from ui.osutil import private_file

CF_API_BASE = "https://api.cloudflare.com/client/v4"
CF_GRAPHQL_URL = "https://api.cloudflare.com/client/v4/graphql"


def _config_dirs() -> tuple[Path, Path]:
    uid = os.getuid() if hasattr(os, "getuid") else 1000
    candidates = [
        Path.home() / ".config" / "laravel-dev",
        Path(f"/tmp/laravel-dev-{uid}"),
    ]
    writable_dir = candidates[-1]
    for d in candidates:
        try:
            d.mkdir(parents=True, exist_ok=True)
            test_file = d / ".cf_write_test"
            test_file.touch()
            test_file.unlink(missing_ok=True)
            writable_dir = d
            break
        except OSError:
            continue

    writable_file = writable_dir / "cloudflare.json"

    # If writable_dir is fallback, copy existing primary config if present
    if writable_dir != candidates[0]:
        primary_file = candidates[0] / "cloudflare.json"
        if primary_file.is_file() and not writable_file.is_file():
            try:
                writable_file.write_text(primary_file.read_text(encoding="utf-8"), encoding="utf-8")
                try:
                    os.chmod(writable_file, 0o600)
                except OSError:
                    pass
            except OSError:
                pass

    return writable_dir, writable_file


def analyze_cf_error(
    error_message: str,
    error_code: int = 0,
    status_code: int = 0,
    endpoint: str = "",
    account_id: str = "",
) -> dict[str, str]:
    """Analyze Cloudflare error and return user-friendly cause, guidance, and direct dashboard URL."""
    msg = error_message.lower().strip()
    dash_base = f"https://dash.cloudflare.com/{account_id}" if account_id else "https://dash.cloudflare.com"

    # 1. R2 Not Enabled on Account
    if (
        error_code in (10042, 10043)
        or "enable r2" in msg
        or ("r2" in endpoint and status_code in (400, 403) and ("enable" in msg or "dashboard" in msg))
    ):
        return {
            "category": "service_inactive",
            "key": "r2_activation_required",
            "title": "Cloudflare R2 Activation Required in Dashboard",
            "explanation": "Cloudflare R2 is not yet enabled on your account. Your API token is valid, but Cloudflare requires you to enable R2 and accept terms once via the Cloudflare Dashboard before API access is permitted.",
            "action": "Click the button below to visit Cloudflare Dashboard and enable R2 (includes 10 GB/month free storage with zero egress fees).",
            "title_ar": "تفعيل خدمة R2 مطلوب عبر لوحة التحكم",
            "explanation_ar": "خدمة Cloudflare R2 غير مفعّلة بعد في حسابك. رمز الـ API سليم، لكن منصة Cloudflare تفرض تفعيل الخدمة لمرة واحدة أولاً وقبول الشروط قبل السماح لأي اتصال API باستعراض أو إنشاء الـ Buckets.",
            "action_ar": "ادخل إلى لوحة Cloudflare واضغط على 'Enable R2' للموافقة على الشروط (خدمة R2 مجانية وتتضمن 10GB شهرياً بدون أي رسوم نقل بيانات).",
            "url": f"https://dash.cloudflare.com/{account_id}/r2/overview" if account_id else "https://dash.cloudflare.com",
            "required_perm": "Workers R2 Storage: Edit",
        }

    # 2. Missing Permissions / Unauthorized
    if (
        status_code in (401, 403)
        or error_code in (10000, 9109, 9106, 9107, 6003)
        or "unauthorized" in msg
        or "permission" in msg
        or "actor does not have permission" in msg
    ):
        if "/dns_records" in endpoint:
            perm = "Zone > DNS > Edit"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/purge_cache" in endpoint:
            perm = "Zone > Cache Purge > Purge"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/email/routing" in endpoint:
            perm = "Zone > Email Routing Rules > Edit"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/rulesets" in endpoint or "/firewall" in endpoint or "/pagerules" in endpoint or "/bot_management" in endpoint:
            perm = "Zone > Firewall Services / Page Rules > Edit"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/ssl" in endpoint:
            perm = "Zone > SSL and Certificates > Edit"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/settings" in endpoint:
            perm = "Zone > Zone Settings > Edit"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/workers" in endpoint:
            perm = "Account > Workers Scripts > Edit"
            scope_hint = "All Accounts"
            scope_hint_ar = "All Accounts"
        elif "/storage/kv" in endpoint:
            perm = "Account > Workers KV Storage > Edit"
            scope_hint = "All Accounts"
            scope_hint_ar = "All Accounts"
        elif "/pages/" in endpoint:
            perm = "Account > Cloudflare Pages > Edit"
            scope_hint = "All Accounts"
            scope_hint_ar = "All Accounts"
        elif "/d1/" in endpoint:
            perm = "Account > D1 > Edit"
            scope_hint = "All Accounts"
            scope_hint_ar = "All Accounts"
        elif "/challenges/widgets" in endpoint:
            perm = "Account > Turnstile > Edit"
            scope_hint = "All Accounts"
            scope_hint_ar = "All Accounts"
        elif "/graphql" in endpoint:
            perm = "Zone > Analytics > Read"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/r2" in endpoint:
            perm = "Account > Workers R2 Storage > Edit"
            scope_hint = "All Accounts"
            scope_hint_ar = "All Accounts"
        elif "/cfd_tunnel" in endpoint:
            perm = "Account > Cloudflare Tunnel > Edit"
            scope_hint = "All Accounts"
            scope_hint_ar = "All Accounts"
        elif "/zones" in endpoint:
            perm = "Zone > Zone > Read"
            scope_hint = "All Zones"
            scope_hint_ar = "All Zones"
        elif "/user/tokens" in endpoint:
            perm = "User > API Tokens > Read (Valid Active Token)"
            scope_hint = "User Profile"
            scope_hint_ar = "حساب المستخدم"
        else:
            perm = "Required service permissions"
            scope_hint = "All Accounts or All Zones"
            scope_hint_ar = "All Accounts أو All Zones"

        return {
            "category": "missing_permission",
            "key": "missing_permission",
            "title": f"Missing API Token Permission ({perm})",
            "explanation": f"The active API token does not have sufficient permissions to perform this operation. Cloudflare rejected the request because [{perm}] permission is missing for [{scope_hint}].",
            "action": f"Go to Cloudflare Dashboard > My Profile > API Tokens, click 'Edit' next to your active token, add the [{perm}] permission, and save.",
            "title_ar": f"نقص في صلاحيات رمز الـ API ({perm})",
            "explanation_ar": f"رمز الـ API الحالي لا يملك صلاحية كافية لتنفيذ هذه العملية. ترفض Cloudflare هذا الطلب لنقص الصلاحية: [{perm}] ضمن النطاق [{scope_hint_ar}].",
            "action_ar": f"انتقل إلى Cloudflare Dashboard > My Profile > API Tokens، واضغط 'Edit' بجانب التوكن الحالي وقم بإضافة صلاحية [{perm}] ثم احفظ التعديل.",
            "url": "https://dash.cloudflare.com/profile/api-tokens",
            "required_perm": perm,
        }

    # 3. DNS Record Conflict
    if (
        error_code in (1001, 81044, 81057, 81058, 81053)
        or "already exists" in msg
        or "conflict" in msg
    ):
        return {
            "category": "dns_conflict",
            "key": "dns_record_conflict",
            "title": "DNS Record Conflict (Already Exists)",
            "explanation": "A DNS record with the same name or a conflicting type already exists (for example, creating a CNAME record when an A record already exists for the same hostname).",
            "action": "Delete or edit the existing record first in the 'Domains & DNS' tab, or use a different subdomain name.",
            "title_ar": "تعارض في سجلات الـ DNS (Record Conflict)",
            "explanation_ar": "يوجد سجل DNS سابق بنفس الاسم أو بنوع يتعارض معه (مثل محاولة إنشاء سجل CNAME بينما يوجد سجل A مسبق لنفس الاسم).",
            "action_ar": "احذف أو عدّل السجل القديم أولاً من تبويب 'Domains & DNS'، أو استخدم اسماً فرعياً (Subdomain) مختلفاً.",
            "url": dash_base,
            "required_perm": "",
        }

    # 4. DNS Validation Error
    if (
        error_code in (1004, 9003, 81040)
        or "invalid ipv4" in msg
        or "invalid ip" in msg
        or "content for" in msg
    ):
        return {
            "category": "validation_error",
            "key": "dns_invalid_content",
            "title": "Invalid DNS Record Content or Format",
            "explanation": "The value entered in the content field does not match the chosen record type (e.g. an A record requires a valid IPv4 address like 192.0.2.1).",
            "action": "Ensure the record type is correct and enter a valid IP address or target without extra spaces.",
            "title_ar": "صيغة بيانات السجل غير صحيحة (Invalid DNS Content)",
            "explanation_ar": "القيمة المدخلة في حقل المحتوى لا تطابق نوع السجل المختار (سجل A يتطلب عنوان IPv4 صالح مثل 192.0.2.1).",
            "action_ar": "تأكد من اختيار نوع السجل الصحيح وكتابة عنوان IP صالح بدون مسافات إضافية.",
            "url": dash_base,
            "required_perm": "",
        }

    # 5. Pending Nameservers
    if (
        error_code in (10001, 10002)
        or "pending" in msg
        or "not active" in msg
    ):
        return {
            "category": "zone_pending",
            "key": "zone_nameservers_pending",
            "title": "Domain Nameservers Pending Activation",
            "explanation": "The domain is not active on Cloudflare yet because the authoritative nameservers have not been updated or propagated at your domain registrar.",
            "action": "Ensure your domain registrar's nameservers are set to Cloudflare's assigned nameservers. DNS propagation may take up to 24-48 hours.",
            "title_ar": "النطاق قيد انتظار خوادم الأسماء (Nameservers Pending)",
            "explanation_ar": "النطاق لم يصبح نشطاً بالكامل على شبكة Cloudflare بعد، ولا تزال خوادم الأسماء (Nameservers) بحاجة للتحديث لدى الشركة المسجلة للنطاق.",
            "action_ar": "تأكد من تغيير خوادم الأسماء (Nameservers) عند مسجل النطاق لتطابق خوادم Cloudflare، وقد يستغرق انتشار الـ DNS بضع ساعات.",
            "url": "https://dash.cloudflare.com",
            "required_perm": "",
        }

    # 6. Zero Trust Central Tunnels Setup
    if "/cfd_tunnel" in endpoint and (status_code in (400, 403, 404) or "team" in msg or "tunnel" in msg):
        return {
            "category": "zero_trust_setup",
            "key": "zero_trust_setup",
            "title": "Zero Trust Team Setup Required",
            "explanation": "Named Cloudflare Tunnels require an initial one-time Cloudflare Zero Trust team setup on your account (free for up to 50 users).",
            "action": "Open the Zero Trust dashboard and complete the initial team name onboarding step.",
            "title_ar": "خدمة Zero Trust تتطلب الإعداد الأولي لمرة واحدة",
            "explanation_ar": "أنفاق Zero Trust المسمّاة تتطلب أن تكون خدمة Cloudflare Zero Trust مهيأة لحسابك (الخدمة مجانية حتى 50 مستخدم).",
            "action_ar": "ادخل إلى لوحة تحكم Zero Trust وأكمل خطوة إعداد اسم الفريق (Team Name) لمرة واحدة.",
            "url": "https://one.dash.cloudflare.com/",
            "required_perm": "Account > Cloudflare Tunnel: Edit",
        }

    # 7. Rate Limiting
    if status_code == 429 or "rate limit" in msg or error_code == 10013:
        return {
            "category": "rate_limited",
            "key": "rate_limit_exceeded",
            "title": "Cloudflare API Rate Limit Exceeded",
            "explanation": "Too many requests were sent to the Cloudflare API in a short period of time.",
            "action": "Please wait 30-60 seconds before retrying.",
            "title_ar": "تم تجاوز حد الطلبات المؤقت (Rate Limit Exceeded)",
            "explanation_ar": "تم إرسال عدد كبير من الطلبات خلال فترة وجيزة إلى خوادم Cloudflare API.",
            "action_ar": "يرجى الانتظار لمدة 30-60 ثانية قبل إعادة المحاولة.",
            "url": dash_base,
            "required_perm": "",
        }

    # 8. R2 Bucket Name Validation
    if "bucket" in msg and ("name" in msg or "invalid" in msg or "character" in msg):
        return {
            "category": "validation_error",
            "key": "r2_invalid_bucket_name",
            "title": "Invalid R2 Bucket Name",
            "explanation": "Cloudflare R2 bucket names must consist of lowercase letters, numbers, and hyphens only, with length between 3 and 63 characters.",
            "action": "Choose a bucket name with only lowercase letters and numbers (e.g., my-app-uploads).",
            "title_ar": "اسم الـ Bucket غير متوافق مع معايير R2",
            "explanation_ar": "تشترط Cloudflare R2 أن يتكون اسم الـ Bucket من أحرف إنجليزية صغيرة (lowercase) وأرقام وشرطات فقط، وبطول بين 3 و 63 حرفاً.",
            "action_ar": "اختر اسماً يحتوي فقط على أحرف صغيرة وأرقام (مثال: my-app-uploads).",
            "url": f"https://dash.cloudflare.com/{account_id}/r2/overview" if account_id else "https://dash.cloudflare.com",
            "required_perm": "",
        }

    # 9. Generic Fallback
    return {
        "category": "api_error",
        "key": "generic_api_error",
        "title": "Cloudflare API Server Error",
        "explanation": error_message,
        "action": "Check your Cloudflare Dashboard to verify your account status and resources.",
        "title_ar": "خطأ من خادم Cloudflare",
        "explanation_ar": error_message,
        "action_ar": "راجع لوحة تحكم Cloudflare للتحقق من حالة الحساب والموارد.",
        "url": dash_base,
        "required_perm": "",
    }


class CloudflareClient:
    """Manages authentication, Vault-protected storage, and API requests to Cloudflare v4."""

    def __init__(self, config_dir: Path | None = None, vault: Any = None):
        self._explicit_config_dir = config_dir is not None
        if config_dir:
            self.config_dir = Path(config_dir).resolve()
            self.config_file = self.config_dir / "cloudflare.json"
        else:
            self.config_dir, self.config_file = _config_dirs()
        self.vault = vault
        self._cached_creds: dict[str, Any] | None = None
        self._cached_vault_unlocked: bool | None = None

    # ── Token Encryption & Vault Integration ─────────────────────────────────

    @staticmethod
    def _mask_token(tok: str) -> str:
        if not tok:
            return ""
        if tok.startswith("enc:"):
            return "****"
        return f"{tok[:4]}...{tok[-4:]}" if len(tok) >= 8 else "***"

    def _decrypt_stored_token(self, raw_tok: str) -> tuple[str, bool]:
        """Decrypt token if Vault-protected. Returns (token, vault_locked)."""
        if not raw_tok:
            return "", False
        if raw_tok.startswith("enc:"):
            if self.vault is None or not self.vault.is_unlocked():
                return "", True
            try:
                return self.vault.decrypt(raw_tok), False
            except Exception:
                return "", True
        return raw_tok, False

    def rekey_secrets(self, old_vault_key: bytes | None, new_vault_key: bytes | None) -> None:
        """Vault migrator hook: encrypt, decrypt, or re-encrypt stored Cloudflare tokens."""
        from cryptography.fernet import Fernet

        old_f = Fernet(old_vault_key) if old_vault_key else None
        new_f = Fernet(new_vault_key) if new_vault_key else None

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        changed = False
        for acc in accounts:
            if not isinstance(acc, dict):
                continue
            tok = acc.get("token", "")
            if not tok or not isinstance(tok, str):
                continue
            if tok.startswith("enc:"):
                if not old_f:
                    continue
                try:
                    plain = old_f.decrypt(tok[4:].encode("ascii")).decode("utf-8")
                except Exception:
                    continue
            else:
                plain = tok

            if plain and not acc.get("token_hint"):
                acc["token_hint"] = self._mask_token(plain)

            if new_f:
                acc["token"] = "enc:" + new_f.encrypt(plain.encode("utf-8")).decode("ascii")
            else:
                acc["token"] = plain
            changed = True

        if changed:
            self._save_raw_config(cfg)
        self._cached_creds = None

    # ── Credentials & Multi-Account Local Storage ────────────────────────────

    def _load_raw_config(self) -> dict[str, Any]:
        """Load raw json from config file with auto-migration from legacy format."""
        if not self.config_file.is_file():
            if not self._explicit_config_dir:
                primary_file = Path.home() / ".config" / "laravel-dev" / "cloudflare.json"
                if primary_file.is_file():
                    try:
                        return json.loads(primary_file.read_text(encoding="utf-8"))
                    except Exception:
                        pass
            return {"active_account_id": "", "accounts": []}

        try:
            data = json.loads(self.config_file.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return {"active_account_id": "", "accounts": []}

            # Migration: if old single-account format (has 'token' but no 'accounts')
            if "accounts" not in data or not isinstance(data.get("accounts"), list):
                legacy_tok = data.get("token", "")
                accounts = []
                if legacy_tok:
                    acc_id = data.get("account_id") or "default"
                    acc_name = data.get("account_name") or "Default Account"
                    accounts.append({
                        "account_id": acc_id,
                        "account_name": acc_name,
                        "token": legacy_tok,
                        "token_hint": self._mask_token(legacy_tok),
                        "email": data.get("email", ""),
                        "updated_at": data.get("updated_at", int(time.time())),
                    })
                data["accounts"] = accounts
                data["active_account_id"] = accounts[0]["account_id"] if accounts else ""

            return data
        except Exception:
            return {"active_account_id": "", "accounts": []}

    def _save_raw_config(self, data: dict[str, Any]) -> bool:
        """Write config securely to file and invalidate credentials cache."""
        self.config_dir.mkdir(parents=True, exist_ok=True)
        active_id = data.get("active_account_id", "")
        accounts = data.get("accounts", [])

        active_acc = None
        for a in accounts:
            if a.get("account_id") == active_id:
                active_acc = a
                break
        if not active_acc and accounts:
            active_acc = accounts[0]
            data["active_account_id"] = active_acc.get("account_id", "")

        if active_acc:
            data["token"] = active_acc.get("token", "")
            data["account_id"] = active_acc.get("account_id", "")
            data["account_name"] = active_acc.get("account_name", "")
            data["email"] = active_acc.get("email", "")
        else:
            data["token"] = ""
            data["account_id"] = ""
            data["account_name"] = ""
            data["email"] = ""

        self._cached_creds = None
        self._cached_vault_unlocked = None

        try:
            self.config_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
            private_file(self.config_file)
            return True
        except OSError:
            return False

    def load_credentials(self) -> dict[str, Any]:
        """Load credentials for the currently active Cloudflare account (decrypting if Vault-protected)."""
        unlocked_now = self.vault.is_unlocked() if self.vault is not None else True
        if self._cached_creds is not None and self._cached_vault_unlocked == unlocked_now:
            if self._cached_creds.get("token") or self._cached_creds.get("vault_locked"):
                return self._cached_creds

        cfg = self._load_raw_config()
        active_id = cfg.get("active_account_id", "")
        accounts = cfg.get("accounts", [])

        active_acc = None
        for a in accounts:
            if a.get("account_id") == active_id:
                active_acc = a
                break
        if not active_acc and accounts:
            active_acc = accounts[0]

        if active_acc:
            raw_tok = active_acc.get("token", "")
            plain_tok, vault_locked = self._decrypt_stored_token(raw_tok)
            self._cached_creds = {
                "token": plain_tok,
                "account_id": active_acc.get("account_id", ""),
                "account_name": active_acc.get("account_name", ""),
                "email": active_acc.get("email", ""),
                "vault_locked": vault_locked,
            }
            self._cached_vault_unlocked = unlocked_now
            return self._cached_creds

        self._cached_creds = {
            "token": "",
            "account_id": "",
            "account_name": "",
            "email": "",
            "vault_locked": False,
        }
        self._cached_vault_unlocked = unlocked_now
        return self._cached_creds

    def get_active_account_id(self) -> str:
        """Return the active account ID."""
        creds = self.load_credentials()
        return creds.get("account_id", "")

    def list_stored_accounts(self) -> list[dict[str, Any]]:
        """List all locally configured Cloudflare accounts."""
        cfg = self._load_raw_config()
        active_id = cfg.get("active_account_id", "")
        result = []
        for a in cfg.get("accounts", []):
            acc_id = a.get("account_id", "")
            raw_tok = a.get("token", "")
            plain_tok, locked = self._decrypt_stored_token(raw_tok)
            masked = a.get("token_hint") or self._mask_token(plain_tok or raw_tok)
            result.append({
                "account_id": acc_id,
                "account_name": a.get("account_name") or "Unnamed Account",
                "email": a.get("email", ""),
                "token_preview": masked,
                "is_active": (acc_id == active_id or (not active_id and len(result) == 0)),
                "vault_locked": locked,
                "updated_at": a.get("updated_at", 0),
            })
        return result

    def save_credentials(
        self,
        token: str,
        account_id: str = "",
        account_name: str = "",
        email: str = "",
        make_active: bool = True,
    ) -> bool:
        """Save or add an account to local config (encrypting token if Vault is enabled)."""
        plain_token = token.strip()
        account_id = account_id.strip()
        account_name = account_name.strip()
        email = email.strip()

        if not plain_token:
            return False

        if not account_id:
            account_id = f"acc_{int(time.time())}"

        stored_token = plain_token
        if self.vault is not None and self.vault.is_enabled():
            if not self.vault.is_unlocked():
                return False
            stored_token = self.vault.encrypt(plain_token)
        token_hint = self._mask_token(plain_token)

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])

        found = False
        for a in accounts:
            if a.get("account_id") == account_id:
                a["token"] = stored_token
                a["token_hint"] = token_hint
                if account_name:
                    a["account_name"] = account_name
                if email:
                    a["email"] = email
                a["updated_at"] = int(time.time())
                found = True
                break

        if not found:
            accounts.append({
                "account_id": account_id,
                "account_name": account_name or "Cloudflare Account",
                "token": stored_token,
                "token_hint": token_hint,
                "email": email,
                "updated_at": int(time.time()),
            })

        cfg["accounts"] = accounts
        if make_active or not cfg.get("active_account_id"):
            cfg["active_account_id"] = account_id

        return self._save_raw_config(cfg)

    def switch_account(self, account_identifier: str) -> dict[str, Any]:
        """Switch active account by ID or account name."""
        target = account_identifier.strip().lower()
        if not target:
            return {"ok": False, "error": "Account identifier is required."}

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        matched = None

        # Try exact ID match first
        for a in accounts:
            if a.get("account_id", "").lower() == target:
                matched = a
                break
        # Try name match
        if not matched:
            for a in accounts:
                if a.get("account_name", "").lower() == target:
                    matched = a
                    break

        if not matched:
            return {"ok": False, "error": f"Account '{account_identifier}' not found."}

        cfg["active_account_id"] = matched["account_id"]
        self._cached_creds = None
        self._save_raw_config(cfg)
        return {
            "ok": True,
            "account_id": matched["account_id"],
            "account_name": matched.get("account_name", ""),
        }

    def remove_account(self, account_identifier: str) -> dict[str, Any]:
        """Remove a stored account by ID or name."""
        target = account_identifier.strip().lower()
        if not target:
            return {"ok": False, "error": "Account identifier is required."}

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        remaining = []
        removed = None

        for a in accounts:
            if a.get("account_id", "").lower() == target or a.get("account_name", "").lower() == target:
                removed = a
            else:
                remaining.append(a)

        if not removed:
            return {"ok": False, "error": f"Account '{account_identifier}' not found."}

        cfg["accounts"] = remaining
        if cfg.get("active_account_id") == removed.get("account_id"):
            cfg["active_account_id"] = remaining[0]["account_id"] if remaining else ""

        self._cached_creds = None
        self._save_raw_config(cfg)
        return {
            "ok": True,
            "removed_id": removed["account_id"],
            "removed_name": removed.get("account_name", ""),
            "remaining_count": len(remaining),
            "new_active_id": cfg.get("active_account_id", ""),
        }

    def clear_credentials(self) -> bool:
        """Clear all saved Cloudflare accounts."""
        self._cached_creds = {"token": "", "account_id": "", "account_name": "", "email": ""}
        try:
            self.config_file.unlink(missing_ok=True)
            return True
        except OSError:
            return False

    # ── HTTP Request Helpers ─────────────────────────────────────────────────

    def _resolve_auth_token(self, override_token: str | None = None) -> tuple[str, dict[str, Any] | None]:
        """Return (token, error_dict) checking Vault lock state and token presence."""
        if override_token is not None:
            return override_token, None
        creds = self.load_credentials()
        if creds.get("vault_locked"):
            return "", {
                "ok": False,
                "vault_locked": True,
                "error": "Credential vault is locked. Unlock Vault to access your Cloudflare token.",
                "cause_category": "vault_locked",
                "cause_key": "vault_locked",
                "cause_title": "Credential Vault is Locked",
                "cause_explanation": "Your Cloudflare API Token is encrypted with the Credential Vault. Unlock the Vault in Settings to use Cloudflare features.",
                "cause_action": "Open Vault unlock prompt or Settings -> Credential Vault and enter your master passphrase.",
                "cause_title_ar": "خزنة المفاتيح مقفلة (Vault Locked)",
                "cause_explanation_ar": "رمز Cloudflare API Token مشفر داخل خزنة المفاتيح. قم بفتح قفل الخزنة للوصول إلى خدمات Cloudflare.",
                "cause_action_ar": "افتح خزنة المفاتيح عبر كلمة المرور الرئيسية من الإعدادات.",
                "dashboard_url": "https://dash.cloudflare.com/profile/api-tokens",
            }
        token = creds.get("token", "")
        if not token:
            return "", {
                "ok": False,
                "error": "Cloudflare API token not configured",
                "cause_category": "missing_token",
                "cause_key": "missing_token",
                "cause_title": "Cloudflare API Token Not Configured",
                "cause_explanation": "An API Token is required to communicate with your Cloudflare account.",
                "cause_action": "Use 'laravel-dev cf auth' or connect your token via the Cloudflare section in the application UI.",
                "cause_title_ar": "لم يتم إدخال رمز Cloudflare API Token",
                "cause_explanation_ar": "التطبيق يحتاج إلى API Token للاتصال بحسابك في Cloudflare.",
                "cause_action_ar": "استخدم 'laravel-dev cf auth' أو اربط التوكن من خلال واجهة التطبيق.",
                "dashboard_url": "https://dash.cloudflare.com/profile/api-tokens",
            }
        return token, None

    def _format_http_error(self, e: urllib.error.HTTPError, endpoint: str) -> dict[str, Any]:
        """Read, close, and transform a Cloudflare HTTPError into an enriched error dict."""
        try:
            try:
                raw = e.read().decode("utf-8", errors="replace")
            except Exception:
                raw = ""
        finally:
            try:
                e.close()
            except Exception:
                pass
        err_msg = f"HTTP {e.code}"
        err_code = 0
        errors_list = []
        try:
            parsed = json.loads(raw)
            errors_list = parsed.get("errors", [])
            if errors_list and isinstance(errors_list, list):
                first_err = errors_list[0]
                err_msg = first_err.get("message") or err_msg
                err_code = first_err.get("code") or 0
        except Exception:
            if raw:
                err_msg = f"{err_msg}: {raw[:200]}"

        acc_id = self.load_credentials().get("account_id", "")
        diag = analyze_cf_error(
            error_message=err_msg,
            error_code=err_code,
            status_code=e.code,
            endpoint=endpoint,
            account_id=acc_id,
        )

        return {
            "ok": False,
            "error": err_msg,
            "error_code": err_code,
            "status_code": e.code,
            "errors": errors_list,
            "cause_category": diag["category"],
            "cause_key": diag.get("key", "api_error"),
            "cause_title": diag["title"],
            "cause_explanation": diag["explanation"],
            "cause_action": diag["action"],
            "cause_title_ar": diag.get("title_ar", diag["title"]),
            "cause_explanation_ar": diag.get("explanation_ar", diag["explanation"]),
            "cause_action_ar": diag.get("action_ar", diag["action"]),
            "dashboard_url": diag["url"],
            "required_perm": diag.get("required_perm", ""),
        }

    def _http_send(
        self,
        url: str,
        method: str = "GET",
        body_bytes: bytes | None = None,
        content_type: str = "application/json",
        override_token: str | None = None,
        timeout: int = 15,
        endpoint_hint: str = "",
        raw_response: bool = False,
    ) -> dict[str, Any]:
        """Shared HTTP transport helper for REST v4 JSON, GraphQL, and raw text payloads."""
        token, auth_err = self._resolve_auth_token(override_token)
        if auth_err:
            return auth_err

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": content_type,
            "User-Agent": "Laravel-Dev-Tool/1.0",
        }
        req = urllib.request.Request(url, data=body_bytes, headers=headers, method=method)
        ctx = ssl.create_default_context()
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                if raw_response:
                    return {"ok": True, "raw": raw}
                payload = json.loads(raw) if raw.strip() else {}
                if endpoint_hint == "/graphql" or "data" in payload and "success" not in payload:
                    errs = payload.get("errors") or []
                    if errs:
                        msg = errs[0].get("message", "GraphQL error") if isinstance(errs[0], dict) else str(errs[0])
                        return {"ok": False, "error": msg, "errors": errs}
                    return {"ok": True, "data": payload.get("data")}
                return {
                    "ok": payload.get("success", False),
                    "result": payload.get("result"),
                    "errors": payload.get("errors", []),
                    "messages": payload.get("messages", []),
                    "result_info": payload.get("result_info", {}),
                }
        except urllib.error.HTTPError as e:
            return self._format_http_error(e, endpoint_hint or url)
        except urllib.error.URLError as e:
            return {
                "ok": False,
                "error": f"Network connection failed: {e.reason}",
                "status_code": 0,
                "cause_category": "network_error",
                "cause_key": "network_error",
                "cause_title": "Unable to Connect to Cloudflare (Network Error)",
                "cause_explanation": "Could not connect to the Internet or reach api.cloudflare.com.",
                "cause_action": "Check your network connection and verify firewall allows connections to api.cloudflare.com.",
                "cause_title_ar": "تعذر الاتصال بخوادم Cloudflare (Network Error)",
                "cause_explanation_ar": "فشل الاتصال بالإنترنت أو تعذر الوصول إلى خوادم Cloudflare API.",
                "cause_action_ar": "تأكد من اتصال جهازك بالإنترنت وأن جدار الحماية لا يحظر الاتصال بـ api.cloudflare.com.",
                "dashboard_url": "https://www.cloudflarestatus.com",
            }
        except Exception as e:
            return {
                "ok": False,
                "error": str(e),
                "cause_category": "unexpected_error",
                "cause_key": "unexpected_error",
                "cause_title": "Unexpected Error",
                "cause_explanation": str(e),
                "cause_action": "Retry the operation or inspect application logs.",
                "cause_title_ar": "خطأ غير متوقع",
                "cause_explanation_ar": str(e),
                "cause_action_ar": "أعد المحاولة أو تحقق من سجلات النظام.",
            }

    def _request(
        self,
        endpoint: str,
        method: str = "GET",
        data: dict[str, Any] | list[Any] | None = None,
        override_token: str | None = None,
        timeout: int = 15,
    ) -> dict[str, Any]:
        """Perform a JSON HTTP request to Cloudflare API v4 with enriched error diagnostics."""
        url = f"{CF_API_BASE}{endpoint}" if endpoint.startswith("/") else f"{CF_API_BASE}/{endpoint}"
        body_bytes = json.dumps(data).encode("utf-8") if data is not None else None
        return self._http_send(
            url,
            method=method,
            body_bytes=body_bytes,
            override_token=override_token,
            timeout=timeout,
            endpoint_hint=endpoint,
        )

    def _request_raw(
        self,
        endpoint: str,
        method: str = "GET",
        body_text: str | None = None,
        content_type: str = "text/plain; charset=utf-8",
        timeout: int = 15,
    ) -> dict[str, Any]:
        """Perform a raw text HTTP request (used for Cloudflare Workers KV values)."""
        url = f"{CF_API_BASE}{endpoint}" if endpoint.startswith("/") else f"{CF_API_BASE}/{endpoint}"
        body_bytes = body_text.encode("utf-8") if body_text is not None else None
        return self._http_send(
            url,
            method=method,
            body_bytes=body_bytes,
            content_type=content_type,
            timeout=timeout,
            endpoint_hint=endpoint,
            raw_response=(method == "GET"),
        )

    def _graphql(self, query: str, variables: dict[str, Any] | None = None, timeout: int = 20) -> dict[str, Any]:
        """Execute a GraphQL query against Cloudflare Analytics API."""
        body_bytes = json.dumps({"query": query, "variables": variables or {}}).encode("utf-8")
        return self._http_send(
            CF_GRAPHQL_URL,
            method="POST",
            body_bytes=body_bytes,
            timeout=timeout,
            endpoint_hint="/graphql",
        )

    def _require_account_id(self) -> tuple[str, dict[str, Any] | None]:
        """Return active account_id or (empty, diagnostic error response)."""
        creds = self.load_credentials()
        if creds.get("vault_locked"):
            _, err = self._resolve_auth_token()
            return "", err
        acc_id = creds.get("account_id", "")
        if not acc_id:
            return "", self._missing_account_id_res()
        return acc_id, None

    # ── Token Verification & Accounts ────────────────────────────────────────

    def verify_token(self, token: str) -> dict[str, Any]:
        """Verify validity and status of an API Token."""
        res = self._request("/user/tokens/verify", method="GET", override_token=token)
        if not res.get("ok"):
            return {
                "ok": False,
                "valid": False,
                "error": res.get("error", "Token verification failed. Please check the token permissions."),
                "error_code": res.get("error_code", 0),
                "status_code": res.get("status_code", 0),
                "cause_category": "invalid_token",
                "cause_key": "invalid_token",
                "cause_title": res.get("cause_title", "Invalid or Unauthorized API Token"),
                "cause_explanation": res.get("cause_explanation", "Cloudflare API rejected this token. It may be mistyped, revoked, or expired."),
                "cause_action": res.get("cause_action", "Ensure you copied the entire token without extra spaces, and check its permissions on Cloudflare."),
                "cause_title_ar": res.get("cause_title_ar", "رمز الـ API غير صالح أو تنقصه الصلاحية"),
                "cause_explanation_ar": res.get("cause_explanation_ar", "فشل التحقق من صلاحية رمز Cloudflare API."),
                "cause_action_ar": res.get("cause_action_ar", "تأكد من نسخ الرمز بالكامل وبدون مسافات، ومن صلاحيات الـ API Token."),
                "dashboard_url": res.get("dashboard_url", "https://dash.cloudflare.com/profile/api-tokens"),
                "required_perm": res.get("required_perm", "User > API Tokens > Read"),
            }

        result = res.get("result", {})
        status = result.get("status", "")
        is_active = status.lower() == "active"

        if not is_active:
            return {
                "ok": False,
                "valid": False,
                "status": status,
                "error": f"Token status is '{status}'. It must be 'active'.",
                "cause_category": "inactive_token",
                "cause_key": "inactive_token",
                "cause_title": f"API Token Inactive (Status: {status})",
                "cause_explanation": f"The current token status is '{status}'. The token must be active to perform API requests.",
                "cause_action": "Activate the token or create a new active token in Cloudflare Dashboard.",
                "cause_title_ar": "رمز الـ API غير نشط (Inactive Token)",
                "cause_explanation_ar": f"حالة الرمز الحالية هي '{status}' وليست نشطة (Active). قد يكون الرمز معطلاً أو منتهي الصلاحية.",
                "cause_action_ar": "تأكد من تفعيل التوكن أو قم بإنشاء توكن جديد من لوحة تحكم Cloudflare.",
                "dashboard_url": "https://dash.cloudflare.com/profile/api-tokens",
                "required_perm": "",
            }

        # Try to discover accessible accounts
        acc_res = self._request("/accounts?page=1&per_page=20", method="GET", override_token=token)
        accounts = acc_res.get("result", []) if acc_res.get("ok") else []

        return {
            "ok": True,
            "valid": True,
            "status": status,
            "token_id": result.get("id", ""),
            "accounts": [
                {"id": a.get("id"), "name": a.get("name"), "type": a.get("type", "standard")}
                for a in accounts if isinstance(a, dict)
            ],
        }

    def get_status(self) -> dict[str, Any]:
        """Return the current authentication status, active account, and stored accounts count."""
        creds = self.load_credentials()
        has_token = bool(creds.get("token"))
        vault_locked = bool(creds.get("vault_locked"))
        stored = self.list_stored_accounts()
        if not has_token:
            return {
                "configured": False,
                "vault_locked": vault_locked,
                "token_masked": "",
                "account_id": creds.get("account_id", "") if vault_locked else "",
                "account_name": creds.get("account_name", "") if vault_locked else "",
                "accounts": stored,
                "total_accounts": len(stored),
            }

        tok = creds["token"]
        masked = self._mask_token(tok)
        return {
            "configured": True,
            "vault_locked": False,
            "token_masked": masked,
            "account_id": creds.get("account_id", ""),
            "account_name": creds.get("account_name", ""),
            "accounts": stored,
            "total_accounts": len(stored),
        }

    def list_accounts(self) -> dict[str, Any]:
        """List accessible Cloudflare accounts."""
        res = self._request("/accounts?page=1&per_page=50", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "accounts": res.get("result", [])}

    # ── Zones & Domains ──────────────────────────────────────────────────────

    def list_zones(self, page: int = 1, per_page: int = 50) -> dict[str, Any]:
        """List domains/zones under the account."""
        creds = self.load_credentials()
        acc_id = creds.get("account_id")
        endpoint = f"/zones?page={page}&per_page={per_page}"
        if acc_id:
            endpoint += f"&account.id={acc_id}"

        res = self._request(endpoint, method="GET")
        if not res.get("ok"):
            # Fallback without account filter if permission scope is zone-level
            res = self._request(f"/zones?page={page}&per_page={per_page}", method="GET")
            if not res.get("ok"):
                return res

        zones = []
        for z in (res.get("result") or []):
            if isinstance(z, dict):
                zones.append({
                    "id": z.get("id"),
                    "name": z.get("name"),
                    "status": z.get("status"),
                    "paused": z.get("paused", False),
                    "type": z.get("type", "full"),
                    "plan": (z.get("plan") or {}).get("name", "Free"),
                    "name_servers": z.get("name_servers", []),
                })
        return {"ok": True, "zones": zones, "result_info": res.get("result_info", {})}

    # ── DNS Records Management ───────────────────────────────────────────────

    def list_dns_records(self, zone_id: str, record_type: str = "", name: str = "", page: int = 1) -> dict[str, Any]:
        """List DNS records for a zone."""
        endpoint = f"/zones/{zone_id}/dns_records?page={page}&per_page=100"
        if record_type:
            endpoint += f"&type={record_type.upper()}"
        if name:
            endpoint += f"&name={name}"

        res = self._request(endpoint, method="GET")
        if not res.get("ok"):
            return res

        records = []
        for r in (res.get("result") or []):
            if isinstance(r, dict):
                records.append({
                    "id": r.get("id"),
                    "zone_id": r.get("zone_id"),
                    "type": r.get("type"),
                    "name": r.get("name"),
                    "content": r.get("content"),
                    "proxiable": r.get("proxiable", False),
                    "proxied": r.get("proxied", False),
                    "ttl": r.get("ttl", 1),
                    "priority": r.get("priority"),
                    "comment": r.get("comment", ""),
                })
        return {"ok": True, "records": records, "result_info": res.get("result_info", {})}

    def create_dns_record(
        self,
        zone_id: str,
        record_type: str,
        name: str,
        content: str,
        proxied: bool = False,
        ttl: int = 1,
        priority: int | None = None,
        comment: str = "",
    ) -> dict[str, Any]:
        """Create a new DNS record."""
        data: dict[str, Any] = {
            "type": record_type.upper().strip(),
            "name": name.strip(),
            "content": content.strip(),
            "ttl": ttl if ttl > 1 else 1,
            "proxied": bool(proxied),
        }
        if comment:
            data["comment"] = comment
        if priority is not None and data["type"] in ("MX", "SRV"):
            data["priority"] = priority

        return self._request(f"/zones/{zone_id}/dns_records", method="POST", data=data)

    def update_dns_record(
        self,
        zone_id: str,
        record_id: str,
        record_type: str,
        name: str,
        content: str,
        proxied: bool = False,
        ttl: int = 1,
        priority: int | None = None,
        comment: str = "",
    ) -> dict[str, Any]:
        """Update an existing DNS record."""
        data: dict[str, Any] = {
            "type": record_type.upper().strip(),
            "name": name.strip(),
            "content": content.strip(),
            "ttl": ttl if ttl > 1 else 1,
            "proxied": bool(proxied),
        }
        if comment:
            data["comment"] = comment
        if priority is not None and data["type"] in ("MX", "SRV"):
            data["priority"] = priority

        return self._request(f"/zones/{zone_id}/dns_records/{record_id}", method="PUT", data=data)

    def toggle_dns_proxy(self, zone_id: str, record_id: str, proxied: bool) -> dict[str, Any]:
        """Toggle proxy status for a DNS record."""
        return self._request(f"/zones/{zone_id}/dns_records/{record_id}", method="PATCH", data={"proxied": proxied})

    def delete_dns_record(self, zone_id: str, record_id: str) -> dict[str, Any]:
        """Delete a DNS record."""
        return self._request(f"/zones/{zone_id}/dns_records/{record_id}", method="DELETE")

    # ── Cache & Edge Controls ────────────────────────────────────────────────

    def purge_cache(self, zone_id: str, purge_everything: bool = True, files: list[str] | None = None) -> dict[str, Any]:
        """Purge CDN cache for a zone."""
        data: dict[str, Any] = {}
        if purge_everything:
            data["purge_everything"] = True
        elif files:
            data["files"] = files
        else:
            data["purge_everything"] = True

        res = self._request(f"/zones/{zone_id}/purge_cache", method="POST", data=data)
        if res.get("ok"):
            return {"ok": True, "message": "Cache successfully purged."}
        return res

    def get_dev_mode(self, zone_id: str) -> dict[str, Any]:
        """Get Development Mode status for a zone."""
        res = self._request(f"/zones/{zone_id}/settings/development_mode", method="GET")
        if not res.get("ok"):
            return res
        result = res.get("result", {})
        val = result.get("value", "off")
        time_remaining = result.get("time_remaining", 0)
        return {"ok": True, "value": val, "enabled": val == "on", "time_remaining": time_remaining}

    def set_dev_mode(self, zone_id: str, enable: bool) -> dict[str, Any]:
        """Toggle Development Mode on or off for a zone."""
        value = "on" if enable else "off"
        res = self._request(f"/zones/{zone_id}/settings/development_mode", method="PATCH", data={"value": value})
        if not res.get("ok"):
            return res
        return {"ok": True, "enabled": enable, "value": value}

    def get_security_level(self, zone_id: str) -> dict[str, Any]:
        """Get current security level for a zone."""
        res = self._request(f"/zones/{zone_id}/settings/security_level", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "level": (res.get("result") or {}).get("value", "medium")}

    def set_security_level(self, zone_id: str, level: str) -> dict[str, Any]:
        """Set security level ('essentially_off', 'low', 'medium', 'high', 'under_attack')."""
        valid_levels = ("essentially_off", "low", "medium", "high", "under_attack")
        if level not in valid_levels:
            return {"ok": False, "error": f"Invalid level. Choose from: {', '.join(valid_levels)}"}

        res = self._request(f"/zones/{zone_id}/settings/security_level", method="PATCH", data={"value": level})
        if not res.get("ok"):
            return res
        return {"ok": True, "level": level}

    def _missing_account_id_res(self) -> dict[str, Any]:
        return {
            "ok": False,
            "error": "Account ID is required for Cloudflare R2 and Named Tunnels operations.",
            "cause_category": "missing_account_id",
            "cause_key": "missing_account_id",
            "cause_title": "Cloudflare Account ID Required",
            "cause_explanation": "Cloudflare R2 and Named Tunnels operations require a 32-character Account ID.",
            "cause_action": "Select the correct account from the switcher or link your account again to auto-discover your Account ID.",
            "cause_title_ar": "معرّف الحساب (Account ID) غير متوفر",
            "cause_explanation_ar": "عمليات R2 وأنفاق Zero Trust تتطلب ربط معرّف الحساب (Account ID) المكون من 32 خانة.",
            "cause_action_ar": "تأكد من اختيار الحساب الصحيح، أو أعد ربط الحساب عبر 'Add Account' لإعادة جلب معرّف الحساب تلقائياً.",
            "dashboard_url": "https://dash.cloudflare.com",
            "required_perm": "Account > Workers R2 Storage / Cloudflare Tunnel",
        }

    # ── Cloudflare R2 Object Storage ─────────────────────────────────────────

    def list_r2_buckets(self) -> dict[str, Any]:
        """List R2 buckets under the active account."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        res = self._request(f"/accounts/{acc_id}/r2/buckets", method="GET")
        if not res.get("ok"):
            return res

        buckets = []
        for b in ((res.get("result") or {}).get("buckets", [])):
            if isinstance(b, dict):
                buckets.append({
                    "name": b.get("name"),
                    "creation_date": b.get("creation_date"),
                    "location": b.get("location", "auto"),
                })
        return {
            "ok": True,
            "buckets": buckets,
            "account_id": acc_id,
            "endpoint": f"https://{acc_id}.r2.cloudflarestorage.com",
        }

    def create_r2_bucket(self, name: str, location_hint: str = "") -> dict[str, Any]:
        """Create a new R2 bucket."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        data: dict[str, Any] = {"name": name.strip()}
        if location_hint:
            data["locationHint"] = location_hint

        res = self._request(f"/accounts/{acc_id}/r2/buckets", method="POST", data=data)
        if res.get("ok"):
            return {
                "ok": True,
                "name": name,
                "endpoint": f"https://{acc_id}.r2.cloudflarestorage.com",
            }
        return res

    def delete_r2_bucket(self, name: str) -> dict[str, Any]:
        """Delete an R2 bucket."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        return self._request(f"/accounts/{acc_id}/r2/buckets/{name.strip()}", method="DELETE")

    # ── Cloudflare Central Tunnels (Zero Trust) ──────────────────────────────

    def list_account_tunnels(self) -> dict[str, Any]:
        """List Named Tunnels created under the active account."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        res = self._request(f"/accounts/{acc_id}/cfd_tunnel?is_deleted=false", method="GET")
        if not res.get("ok"):
            return res

        tunnels = []
        for t in (res.get("result") or []):
            if isinstance(t, dict):
                conns = t.get("connections", [])
                tunnels.append({
                    "id": t.get("id"),
                    "name": t.get("name"),
                    "status": t.get("status"),
                    "created_at": t.get("created_at"),
                    "connections_count": len(conns),
                    "remote_config": t.get("remote_config", False),
                })
        return {"ok": True, "tunnels": tunnels}

    def create_account_tunnel(self, name: str) -> dict[str, Any]:
        """Create a new Named Tunnel in Cloudflare account."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        # Cloudflare requires a 32+ character tunnel secret
        import secrets
        secret = secrets.token_urlsafe(32)

        data = {
            "name": name.strip(),
            "tunnel_secret": secret,
            "config_src": "cloudflare",
        }
        res = self._request(f"/accounts/{acc_id}/cfd_tunnel", method="POST", data=data)
        if not res.get("ok"):
            return res

        tunnel_id = (res.get("result") or {}).get("id")
        # Fetch tunnel token
        tok_res = self.get_tunnel_token(tunnel_id) if tunnel_id else {"ok": False}
        token = tok_res.get("token", "") if tok_res.get("ok") else ""

        return {
            "ok": True,
            "id": tunnel_id,
            "name": name,
            "token": token,
        }

    def get_tunnel_token(self, tunnel_id: str) -> dict[str, Any]:
        """Fetch the credentials token for a Named Tunnel."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        res = self._request(f"/accounts/{acc_id}/cfd_tunnel/{tunnel_id}/token", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "token": res.get("result", "")}

    def resolve_zone_id(self, zone_name_or_id: str) -> str | None:
        """Resolve a domain name or zone ID to a verified 32-char zone ID."""
        target = zone_name_or_id.strip()
        if not target:
            return None
        if len(target) == 32 and all(c in "0123456789abcdefABCDEF" for c in target):
            return target
        res = self.list_zones()
        if res.get("ok"):
            for z in res.get("zones", []):
                if z.get("name", "").lower() == target.lower() or z.get("id", "").lower() == target.lower():
                    return z.get("id")
        return None

    def delete_account_tunnel(self, tunnel_id: str) -> dict[str, Any]:
        """Delete a Named Tunnel from Cloudflare account."""
        acc_id, err = self._require_account_id()
        if err:
            return err

        return self._request(f"/accounts/{acc_id}/cfd_tunnel/{urllib.parse.quote(tunnel_id.strip(), safe='')}", method="DELETE")

    def get_tunnel_config(self, tunnel_id: str) -> dict[str, Any]:
        """Get remote-managed ingress rules configuration for a Named Tunnel."""
        acc_id, err = self._require_account_id()
        if err:
            return err

        tid = urllib.parse.quote(tunnel_id.strip(), safe="")
        res = self._request(f"/accounts/{acc_id}/cfd_tunnel/{tid}/configurations", method="GET")
        if not res.get("ok"):
            if res.get("status_code") == 404:
                return {"ok": True, "ingress": [], "warp_routing": False, "version": 0}
            return res
        result = res.get("result") or {}
        cfg = result.get("config") or {}
        return {
            "ok": True,
            "ingress": cfg.get("ingress") or [],
            "warp_routing": bool((cfg.get("warp-routing") or {}).get("enabled", False)),
            "version": result.get("version", 0),
        }

    def update_tunnel_config(self, tunnel_id: str, ingress: list[dict[str, Any]], warp_routing: bool = False) -> dict[str, Any]:
        """Update remote-managed ingress rules for a Named Tunnel (adds default 404 catch-all if omitted)."""
        acc_id, err = self._require_account_id()
        if err:
            return err

        clean_ingress: list[dict[str, Any]] = []
        has_catchall = False
        for rule in ingress:
            if not isinstance(rule, dict):
                continue
            service = str(rule.get("service") or "").strip()
            hostname = str(rule.get("hostname") or "").strip()
            path_val = str(rule.get("path") or "").strip()
            if not service:
                continue
            entry: dict[str, Any] = {"service": service}
            if hostname:
                entry["hostname"] = hostname
            else:
                has_catchall = True
            if path_val:
                entry["path"] = path_val
            clean_ingress.append(entry)

        if not has_catchall:
            clean_ingress.append({"service": "http_status:404"})

        tid = urllib.parse.quote(tunnel_id.strip(), safe="")
        payload = {"config": {"ingress": clean_ingress, "warp-routing": {"enabled": bool(warp_routing)}}}
        res = self._request(f"/accounts/{acc_id}/cfd_tunnel/{tid}/configurations", method="PUT", data=payload)
        if not res.get("ok"):
            return res
        return {"ok": True, "ingress": clean_ingress}

    # ── Zones Lifecycle ──────────────────────────────────────────────────────

    def create_zone(self, name: str, zone_type: str = "full", jump_start: bool = True) -> dict[str, Any]:
        """Add a new domain/zone to the active Cloudflare account."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        data = {
            "name": name.strip().lower(),
            "account": {"id": acc_id},
            "jump_start": bool(jump_start),
            "type": zone_type if zone_type in ("full", "partial", "secondary") else "full",
        }
        res = self._request("/zones", method="POST", data=data)
        if not res.get("ok"):
            return res
        z = res.get("result") or {}
        return {
            "ok": True,
            "zone": {
                "id": z.get("id"),
                "name": z.get("name"),
                "status": z.get("status"),
                "name_servers": z.get("name_servers", []),
                "type": z.get("type", "full"),
            },
        }

    def get_zone_details(self, zone_id: str) -> dict[str, Any]:
        """Get full details for a single zone including nameservers and plan."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}", method="GET")
        if not res.get("ok"):
            return res
        z = res.get("result") or {}
        return {
            "ok": True,
            "zone": {
                "id": z.get("id"),
                "name": z.get("name"),
                "status": z.get("status"),
                "paused": z.get("paused", False),
                "type": z.get("type", "full"),
                "plan": (z.get("plan") or {}).get("name", "Free"),
                "name_servers": z.get("name_servers", []),
                "original_name_servers": z.get("original_name_servers", []),
                "created_on": z.get("created_on", ""),
            },
        }

    def zone_activation_check(self, zone_id: str) -> dict[str, Any]:
        """Trigger Cloudflare to re-check nameservers for a pending zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/activation_check", method="PUT", data={})
        if not res.get("ok"):
            return res
        return {"ok": True, "result": res.get("result")}

    def delete_zone(self, zone_id: str) -> dict[str, Any]:
        """Delete a zone from Cloudflare."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        return self._request(f"/zones/{zid}", method="DELETE")

    # ── SSL/TLS, Edge Performance & Certificates ─────────────────────────────

    def get_zone_settings_bundle(self, zone_id: str) -> dict[str, Any]:
        """Fetch all zone settings (SSL, HTTPS, TLS, Cache, Speed, Protection) in one request."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/settings", method="GET")
        if not res.get("ok"):
            return res
        items = res.get("result") or []
        settings_map: dict[str, Any] = {}
        for item in items:
            if isinstance(item, dict) and item.get("id"):
                settings_map[item["id"]] = item.get("value")
        return {"ok": True, "settings": settings_map, "raw": items}

    def update_zone_setting(self, zone_id: str, setting_id: str, value: Any) -> dict[str, Any]:
        """Update an individual zone setting via /zones/{id}/settings/{setting_id}."""
        allowed_settings = {
            "ssl", "always_use_https", "automatic_https_rewrites", "min_tls_version",
            "tls_1_3", "opportunistic_encryption", "http3", "0rtt", "brotli",
            "early_hints", "cache_level", "browser_cache_ttl", "always_online",
            "development_mode", "security_level", "hotlink_protection",
            "email_obfuscation", "ipv6", "websockets", "challenge_ttl",
        }
        sid = setting_id.strip()
        if sid not in allowed_settings:
            return {"ok": False, "error": f"Unsupported setting '{sid}'"}
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/settings/{sid}", method="PATCH", data={"value": value})
        if not res.get("ok"):
            return res
        r = res.get("result") or {}
        return {"ok": True, "id": r.get("id", sid), "value": r.get("value", value)}

    def get_universal_ssl(self, zone_id: str) -> dict[str, Any]:
        """Get Universal SSL enabled status and certificate authority."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/ssl/universal/settings", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "universal": res.get("result") or {}}

    def set_universal_ssl(self, zone_id: str, enabled: bool) -> dict[str, Any]:
        """Enable or disable Universal SSL for a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/ssl/universal/settings", method="PATCH", data={"enabled": bool(enabled)})
        if not res.get("ok"):
            return res
        return {"ok": True, "universal": res.get("result") or {}}

    def list_certificate_packs(self, zone_id: str) -> dict[str, Any]:
        """List SSL/TLS edge certificate packs for a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/ssl/certificate_packs?status=all", method="GET")
        if not res.get("ok"):
            return res
        packs = []
        for p in (res.get("result") or []):
            if isinstance(p, dict):
                packs.append({
                    "id": p.get("id"),
                    "type": p.get("type", ""),
                    "status": p.get("status", ""),
                    "hosts": p.get("hosts", []),
                    "certificate_authority": p.get("certificate_authority", ""),
                    "validity_days": p.get("validity_days", 0),
                })
        return {"ok": True, "packs": packs}

    # ── Zone Analytics (GraphQL) ─────────────────────────────────────────────

    def get_zone_analytics(self, zone_id: str, days: int = 7) -> dict[str, Any]:
        """Fetch daily HTTP requests, cached requests, bandwidth, and threat stats via GraphQL."""
        days = max(1, min(int(days or 7), 30))
        today = datetime.datetime.now(datetime.timezone.utc).date()
        start = today - datetime.timedelta(days=days)
        query = """
        query ZoneHttpAnalytics($zoneTag: string!, $since: string!, $until: string!) {
          viewer {
            zones(filter: {zoneTag: $zoneTag}) {
              httpRequests1dGroups(
                limit: 31
                orderBy: [date_ASC]
                filter: {date_geq: $since, date_leq: $until}
              ) {
                dimensions { date }
                sum { requests cachedRequests bytes cachedBytes threats pageViews }
                uniq { uniques }
              }
            }
          }
        }
        """
        res = self._graphql(
            query,
            variables={"zoneTag": zone_id.strip(), "since": start.isoformat(), "until": today.isoformat()},
        )
        if not res.get("ok"):
            return res
        zones = ((res.get("data") or {}).get("viewer") or {}).get("zones") or []
        groups = (zones[0].get("httpRequests1dGroups") or []) if zones else []

        series = []
        totals = {"requests": 0, "cached_requests": 0, "bytes": 0, "cached_bytes": 0, "threats": 0, "uniques": 0}
        for g in groups:
            s = g.get("sum") or {}
            u = g.get("uniq") or {}
            dt = ((g.get("dimensions") or {}).get("date")) or ""
            req_n = int(s.get("requests") or 0)
            creq_n = int(s.get("cachedRequests") or 0)
            byt = int(s.get("bytes") or 0)
            cbyt = int(s.get("cachedBytes") or 0)
            thr = int(s.get("threats") or 0)
            uni = int(u.get("uniques") or 0)
            totals["requests"] += req_n
            totals["cached_requests"] += creq_n
            totals["bytes"] += byt
            totals["cached_bytes"] += cbyt
            totals["threats"] += thr
            totals["uniques"] += uni
            series.append({
                "date": dt,
                "requests": req_n,
                "cached_requests": creq_n,
                "bytes": byt,
                "cached_bytes": cbyt,
                "threats": thr,
                "uniques": uni,
            })

        req_total = totals["requests"]
        totals["cache_hit_ratio"] = round((totals["cached_requests"] / req_total) * 100, 1) if req_total else 0.0
        return {"ok": True, "days": days, "totals": totals, "series": series}

    # ── Firewall: IP Access Rules, Custom WAF, Bot Mode & Page Rules ─────────

    def list_ip_access_rules(self, zone_id: str, page: int = 1) -> dict[str, Any]:
        """List IP / CIDR / Country / ASN firewall access rules for a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/firewall/access_rules/rules?page={int(page)}&per_page=50", method="GET")
        if not res.get("ok"):
            return res
        rules = []
        for r in (res.get("result") or []):
            if isinstance(r, dict):
                cfg = r.get("configuration") or {}
                rules.append({
                    "id": r.get("id"),
                    "mode": r.get("mode", "block"),
                    "target": cfg.get("target", "ip"),
                    "value": cfg.get("value", ""),
                    "notes": r.get("notes", ""),
                    "created_on": r.get("created_on", ""),
                })
        return {"ok": True, "rules": rules}

    def create_ip_access_rule(self, zone_id: str, mode: str, target: str, value: str, notes: str = "") -> dict[str, Any]:
        """Create an IP / Country / ASN access rule on a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        payload = {
            "mode": mode.strip(),
            "configuration": {"target": target.strip(), "value": value.strip()},
            "notes": notes.strip(),
        }
        return self._request(f"/zones/{zid}/firewall/access_rules/rules", method="POST", data=payload)

    def delete_ip_access_rule(self, zone_id: str, rule_id: str) -> dict[str, Any]:
        """Delete an IP access rule."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        rid = urllib.parse.quote(rule_id.strip(), safe="")
        return self._request(f"/zones/{zid}/firewall/access_rules/rules/{rid}", method="DELETE")

    def get_waf_custom_rules(self, zone_id: str) -> dict[str, Any]:
        """Get custom WAF ruleset entrypoint rules (http_request_firewall_custom)."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/rulesets/phases/http_request_firewall_custom/entrypoint", method="GET")
        if not res.get("ok"):
            if res.get("status_code") == 404:
                return {"ok": True, "ruleset_id": "", "rules": []}
            return res
        result = res.get("result") or {}
        return {"ok": True, "ruleset_id": result.get("id", ""), "rules": result.get("rules") or []}

    def save_waf_custom_rules(self, zone_id: str, rules: list[dict[str, Any]]) -> dict[str, Any]:
        """Replace custom WAF ruleset entrypoint rules on a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        clean_rules = []
        for r in rules:
            if not isinstance(r, dict):
                continue
            item = {
                "expression": str(r.get("expression") or "").strip(),
                "action": str(r.get("action") or "block").strip(),
                "description": str(r.get("description") or "").strip(),
                "enabled": bool(r.get("enabled", True)),
            }
            if r.get("id"):
                item["id"] = str(r["id"])
            if item["expression"]:
                clean_rules.append(item)
        res = self._request(
            f"/zones/{zid}/rulesets/phases/http_request_firewall_custom/entrypoint",
            method="PUT",
            data={"rules": clean_rules},
        )
        if not res.get("ok"):
            return res
        result = res.get("result") or {}
        return {"ok": True, "ruleset_id": result.get("id", ""), "rules": result.get("rules") or []}

    def add_waf_custom_rule(self, zone_id: str, description: str, expression: str, action: str = "block", enabled: bool = True) -> dict[str, Any]:
        """Append a new custom WAF rule to the zone's entrypoint ruleset."""
        cur = self.get_waf_custom_rules(zone_id)
        if not cur.get("ok"):
            return cur
        rules = list(cur.get("rules") or [])
        rules.append({
            "description": description.strip(),
            "expression": expression.strip(),
            "action": action.strip() or "block",
            "enabled": bool(enabled),
        })
        return self.save_waf_custom_rules(zone_id, rules)

    def delete_waf_custom_rule(self, zone_id: str, rule_id: str) -> dict[str, Any]:
        """Remove a rule by id from the zone's custom WAF ruleset."""
        cur = self.get_waf_custom_rules(zone_id)
        if not cur.get("ok"):
            return cur
        rules = [r for r in (cur.get("rules") or []) if r.get("id") != rule_id]
        return self.save_waf_custom_rules(zone_id, rules)

    def get_bot_management(self, zone_id: str) -> dict[str, Any]:
        """Get Bot Fight Mode settings for a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/bot_management", method="GET")
        if not res.get("ok"):
            return res
        r = res.get("result") or {}
        return {"ok": True, "fight_mode": bool(r.get("fight_mode", False)), "raw": r}

    def set_bot_management(self, zone_id: str, fight_mode: bool) -> dict[str, Any]:
        """Toggle Bot Fight Mode on/off."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/bot_management", method="PUT", data={"fight_mode": bool(fight_mode)})
        if not res.get("ok"):
            return res
        r = res.get("result") or {}
        return {"ok": True, "fight_mode": bool(r.get("fight_mode", fight_mode))}

    def list_page_rules(self, zone_id: str) -> dict[str, Any]:
        """List Page Rules (redirects, cache rules, security overrides) for a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/pagerules?status=active,disabled", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "rules": res.get("result") or []}

    def create_page_rule(
        self,
        zone_id: str,
        url_pattern: str,
        actions: list[dict[str, Any]],
        status: str = "active",
        priority: int = 1,
    ) -> dict[str, Any]:
        """Create a Page Rule for URL pattern routing/caching/forwarding."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        data = {
            "targets": [{"target": "url", "constraint": {"operator": "matches", "value": url_pattern.strip()}}],
            "actions": actions,
            "priority": max(1, int(priority)),
            "status": "active" if status == "active" else "disabled",
        }
        return self._request(f"/zones/{zid}/pagerules", method="POST", data=data)

    def delete_page_rule(self, zone_id: str, rule_id: str) -> dict[str, Any]:
        """Delete a Page Rule."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        rid = urllib.parse.quote(rule_id.strip(), safe="")
        return self._request(f"/zones/{zid}/pagerules/{rid}", method="DELETE")

    # ── R2 Enhanced (Managed Domain & CORS) ──────────────────────────────────

    def get_r2_managed_domain(self, bucket_name: str) -> dict[str, Any]:
        """Check public r2.dev managed subdomain status for an R2 bucket."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        bname = urllib.parse.quote(bucket_name.strip(), safe="")
        res = self._request(f"/accounts/{acc_id}/r2/buckets/{bname}/domains/managed", method="GET")
        if not res.get("ok"):
            return res
        r = res.get("result") or {}
        return {"ok": True, "enabled": bool(r.get("enabled", False)), "domain": r.get("domain", "")}

    def set_r2_managed_domain(self, bucket_name: str, enabled: bool) -> dict[str, Any]:
        """Enable or disable public r2.dev subdomain access for an R2 bucket."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        bname = urllib.parse.quote(bucket_name.strip(), safe="")
        res = self._request(f"/accounts/{acc_id}/r2/buckets/{bname}/domains/managed", method="PUT", data={"enabled": bool(enabled)})
        if not res.get("ok"):
            return res
        r = res.get("result") or {}
        return {"ok": True, "enabled": bool(r.get("enabled", enabled)), "domain": r.get("domain", "")}

    def get_r2_cors(self, bucket_name: str) -> dict[str, Any]:
        """Fetch CORS rules for an R2 bucket."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        bname = urllib.parse.quote(bucket_name.strip(), safe="")
        res = self._request(f"/accounts/{acc_id}/r2/buckets/{bname}/cors", method="GET")
        if not res.get("ok"):
            if res.get("status_code") == 404:
                return {"ok": True, "rules": []}
            return res
        return {"ok": True, "rules": (res.get("result") or {}).get("rules") or []}

    def set_r2_cors(self, bucket_name: str, rules: list[dict[str, Any]]) -> dict[str, Any]:
        """Set CORS policy rules for an R2 bucket."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        bname = urllib.parse.quote(bucket_name.strip(), safe="")
        return self._request(f"/accounts/{acc_id}/r2/buckets/{bname}/cors", method="PUT", data={"rules": rules})

    # ── Workers & Zone Routes ────────────────────────────────────────────────

    def list_workers_scripts(self) -> dict[str, Any]:
        """List deployed Workers scripts and workers.dev subdomain."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        res = self._request(f"/accounts/{acc_id}/workers/scripts", method="GET")
        if not res.get("ok"):
            return res
        sub_res = self._request(f"/accounts/{acc_id}/workers/subdomain", method="GET")
        subdomain = ((sub_res.get("result") or {}).get("subdomain")) if sub_res.get("ok") else ""
        scripts = []
        for s in (res.get("result") or []):
            if isinstance(s, dict):
                scripts.append({
                    "id": s.get("id"),
                    "etag": s.get("etag", ""),
                    "created_on": s.get("created_on", ""),
                    "modified_on": s.get("modified_on", ""),
                    "usage_model": s.get("usage_model", "standard"),
                    "url": f"https://{s.get('id')}.{subdomain}.workers.dev" if subdomain else "",
                })
        return {"ok": True, "scripts": scripts, "subdomain": subdomain}

    def delete_worker_script(self, script_name: str) -> dict[str, Any]:
        """Delete a Worker script from the account."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        sname = urllib.parse.quote(script_name.strip(), safe="")
        return self._request(f"/accounts/{acc_id}/workers/scripts/{sname}", method="DELETE")

    def list_worker_routes(self, zone_id: str) -> dict[str, Any]:
        """List Worker URL trigger routes bound to a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/workers/routes", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "routes": res.get("result") or []}

    def create_worker_route(self, zone_id: str, pattern: str, script: str) -> dict[str, Any]:
        """Bind a Worker script to a zone URL route pattern."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        data: dict[str, Any] = {"pattern": pattern.strip()}
        if script.strip():
            data["script"] = script.strip()
        return self._request(f"/zones/{zid}/workers/routes", method="POST", data=data)

    def delete_worker_route(self, zone_id: str, route_id: str) -> dict[str, Any]:
        """Remove a Worker route from a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        rid = urllib.parse.quote(route_id.strip(), safe="")
        return self._request(f"/zones/{zid}/workers/routes/{rid}", method="DELETE")

    # ── Workers KV Namespaces & Key-Value Editor ─────────────────────────────

    def list_kv_namespaces(self, page: int = 1, per_page: int = 50) -> dict[str, Any]:
        """List Workers KV namespaces."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        res = self._request(f"/accounts/{acc_id}/storage/kv/namespaces?page={int(page)}&per_page={int(per_page)}", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "namespaces": res.get("result") or []}

    def create_kv_namespace(self, title: str) -> dict[str, Any]:
        """Create a Workers KV namespace."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        return self._request(f"/accounts/{acc_id}/storage/kv/namespaces", method="POST", data={"title": title.strip()})

    def delete_kv_namespace(self, namespace_id: str) -> dict[str, Any]:
        """Delete a Workers KV namespace."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        nid = urllib.parse.quote(namespace_id.strip(), safe="")
        return self._request(f"/accounts/{acc_id}/storage/kv/namespaces/{nid}", method="DELETE")

    def list_kv_keys(self, namespace_id: str, prefix: str = "", limit: int = 100) -> dict[str, Any]:
        """List keys inside a Workers KV namespace."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        nid = urllib.parse.quote(namespace_id.strip(), safe="")
        qs = f"?limit={max(10, min(int(limit), 1000))}"
        if prefix.strip():
            qs += f"&prefix={urllib.parse.quote(prefix.strip(), safe='')}"
        res = self._request(f"/accounts/{acc_id}/storage/kv/namespaces/{nid}/keys{qs}", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "keys": res.get("result") or []}

    def get_kv_value(self, namespace_id: str, key_name: str) -> dict[str, Any]:
        """Read UTF-8 text value for a KV key."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        nid = urllib.parse.quote(namespace_id.strip(), safe="")
        kname = urllib.parse.quote(key_name, safe="")
        res = self._request_raw(f"/accounts/{acc_id}/storage/kv/namespaces/{nid}/values/{kname}", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "key": key_name, "value": res.get("raw", "")}

    def put_kv_value(self, namespace_id: str, key_name: str, value: str) -> dict[str, Any]:
        """Write or overwrite a KV entry."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        nid = urllib.parse.quote(namespace_id.strip(), safe="")
        kname = urllib.parse.quote(key_name, safe="")
        return self._request_raw(
            f"/accounts/{acc_id}/storage/kv/namespaces/{nid}/values/{kname}",
            method="PUT",
            body_text=value,
        )

    def delete_kv_value(self, namespace_id: str, key_name: str) -> dict[str, Any]:
        """Delete a KV key from a namespace."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        nid = urllib.parse.quote(namespace_id.strip(), safe="")
        kname = urllib.parse.quote(key_name, safe="")
        return self._request(f"/accounts/{acc_id}/storage/kv/namespaces/{nid}/values/{kname}", method="DELETE")

    # ── Cloudflare Pages ─────────────────────────────────────────────────────

    def list_pages_projects(self) -> dict[str, Any]:
        """List Cloudflare Pages projects on the account."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        res = self._request(f"/accounts/{acc_id}/pages/projects", method="GET")
        if not res.get("ok"):
            return res
        projects = []
        for p in (res.get("result") or []):
            if isinstance(p, dict):
                latest = p.get("latest_deployment") or {}
                projects.append({
                    "name": p.get("name"),
                    "subdomain": p.get("subdomain"),
                    "domains": p.get("domains") or [],
                    "production_branch": p.get("production_branch", "main"),
                    "created_on": p.get("created_on", ""),
                    "latest_status": ((latest.get("latest_stage") or {}).get("status")) or "",
                    "latest_url": latest.get("url", ""),
                })
        return {"ok": True, "projects": projects}

    def list_pages_deployments(self, project_name: str) -> dict[str, Any]:
        """List recent deployments for a Cloudflare Pages project."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        pname = urllib.parse.quote(project_name.strip(), safe="")
        res = self._request(f"/accounts/{acc_id}/pages/projects/{pname}/deployments", method="GET")
        if not res.get("ok"):
            return res
        deployments = []
        for d in (res.get("result") or []):
            if isinstance(d, dict):
                deployments.append({
                    "id": d.get("id"),
                    "short_id": d.get("short_id"),
                    "environment": d.get("environment", "production"),
                    "url": d.get("url", ""),
                    "created_on": d.get("created_on", ""),
                    "status": ((d.get("latest_stage") or {}).get("status")) or "",
                    "branch": ((d.get("deployment_trigger") or {}).get("metadata") or {}).get("branch", ""),
                    "commit_message": ((d.get("deployment_trigger") or {}).get("metadata") or {}).get("commit_message", ""),
                })
        return {"ok": True, "deployments": deployments}

    def create_pages_deployment(self, project_name: str) -> dict[str, Any]:
        """Trigger a new Cloudflare Pages deployment for the production branch."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        pname = urllib.parse.quote(project_name.strip(), safe="")
        return self._request(f"/accounts/{acc_id}/pages/projects/{pname}/deployments", method="POST", data={})

    def retry_pages_deployment(self, project_name: str, deployment_id: str) -> dict[str, Any]:
        """Retry an existing Cloudflare Pages deployment."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        pname = urllib.parse.quote(project_name.strip(), safe="")
        did = urllib.parse.quote(deployment_id.strip(), safe="")
        return self._request(f"/accounts/{acc_id}/pages/projects/{pname}/deployments/{did}/retry", method="POST", data={})

    def rollback_pages_deployment(self, project_name: str, deployment_id: str) -> dict[str, Any]:
        """Roll back production to an earlier successful Pages deployment."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        pname = urllib.parse.quote(project_name.strip(), safe="")
        did = urllib.parse.quote(deployment_id.strip(), safe="")
        return self._request(f"/accounts/{acc_id}/pages/projects/{pname}/deployments/{did}/rollback", method="POST", data={})

    # ── Cloudflare D1 Serverless SQL ─────────────────────────────────────────

    def list_d1_databases(self) -> dict[str, Any]:
        """List D1 SQLite databases on the account."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        res = self._request(f"/accounts/{acc_id}/d1/database?page=1&per_page=50", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "databases": res.get("result") or []}

    def create_d1_database(self, name: str, primary_location_hint: str = "") -> dict[str, Any]:
        """Create a new Cloudflare D1 database."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        data: dict[str, Any] = {"name": name.strip()}
        if primary_location_hint.strip():
            data["primary_location_hint"] = primary_location_hint.strip()
        return self._request(f"/accounts/{acc_id}/d1/database", method="POST", data=data)

    def delete_d1_database(self, database_id: str) -> dict[str, Any]:
        """Delete a Cloudflare D1 database."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        did = urllib.parse.quote(database_id.strip(), safe="")
        return self._request(f"/accounts/{acc_id}/d1/database/{did}", method="DELETE")

    def query_d1_database(self, database_id: str, sql: str, params: list[Any] | None = None) -> dict[str, Any]:
        """Execute an interactive SQL query against a Cloudflare D1 database."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        did = urllib.parse.quote(database_id.strip(), safe="")
        data: dict[str, Any] = {"sql": sql}
        if params:
            data["params"] = params
        res = self._request(f"/accounts/{acc_id}/d1/database/{did}/query", method="POST", data=data, timeout=25)
        if not res.get("ok"):
            return res
        statements = res.get("result") or []
        first = statements[0] if (isinstance(statements, list) and statements) else {}
        return {
            "ok": True,
            "results": first.get("results", []),
            "meta": first.get("meta", {}),
            "statements": statements,
        }

    # ── Cloudflare Turnstile (CAPTCHA-Free Challenge) ────────────────────────

    def list_turnstile_widgets(self) -> dict[str, Any]:
        """List Turnstile widgets on the account."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        res = self._request(f"/accounts/{acc_id}/challenges/widgets", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "widgets": res.get("result") or []}

    def create_turnstile_widget(self, name: str, domains: list[str], mode: str = "managed") -> dict[str, Any]:
        """Create a Turnstile widget and return sitekey + secret."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        clean_domains = [d.strip() for d in domains if d and d.strip()]
        data = {
            "name": name.strip(),
            "domains": clean_domains,
            "mode": mode if mode in ("managed", "non-interactive", "invisible") else "managed",
        }
        return self._request(f"/accounts/{acc_id}/challenges/widgets", method="POST", data=data)

    def delete_turnstile_widget(self, sitekey: str) -> dict[str, Any]:
        """Delete a Turnstile widget by sitekey."""
        acc_id, err = self._require_account_id()
        if err:
            return err
        skey = urllib.parse.quote(sitekey.strip(), safe="")
        return self._request(f"/accounts/{acc_id}/challenges/widgets/{skey}", method="DELETE")

    # ── Email Routing ────────────────────────────────────────────────────────

    def get_email_routing_status(self, zone_id: str) -> dict[str, Any]:
        """Get Email Routing status for a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/email/routing", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "routing": res.get("result") or {}}

    def list_email_routing_rules(self, zone_id: str) -> dict[str, Any]:
        """List Email Routing forwarding/drop rules on a zone."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        res = self._request(f"/zones/{zid}/email/routing/rules", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "rules": res.get("result") or []}

    def create_email_routing_rule(
        self,
        zone_id: str,
        name: str,
        custom_address: str,
        forward_to: str,
        enabled: bool = True,
    ) -> dict[str, Any]:
        """Create an Email Routing rule forwarding custom_address -> destination."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        data = {
            "name": name.strip() or f"Forward {custom_address}",
            "enabled": bool(enabled),
            "matchers": [{"type": "literal", "field": "to", "value": custom_address.strip()}],
            "actions": [{"type": "forward", "value": [forward_to.strip()]}],
        }
        return self._request(f"/zones/{zid}/email/routing/rules", method="POST", data=data)

    def toggle_email_routing_rule(
        self,
        zone_id: str,
        rule_id: str,
        enabled: bool,
        name: str,
        custom_address: str,
        forward_to: str,
    ) -> dict[str, Any]:
        """Update/toggle an existing Email Routing rule."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        rid = urllib.parse.quote(rule_id.strip(), safe="")
        data = {
            "name": name.strip() or f"Forward {custom_address}",
            "enabled": bool(enabled),
            "matchers": [{"type": "literal", "field": "to", "value": custom_address.strip()}],
            "actions": [{"type": "forward", "value": [forward_to.strip()]}],
        }
        return self._request(f"/zones/{zid}/email/routing/rules/{rid}", method="PUT", data=data)

    def delete_email_routing_rule(self, zone_id: str, rule_id: str) -> dict[str, Any]:
        """Delete an Email Routing rule."""
        zid = urllib.parse.quote(zone_id.strip(), safe="")
        rid = urllib.parse.quote(rule_id.strip(), safe="")
        return self._request(f"/zones/{zid}/email/routing/rules/{rid}", method="DELETE")


# ── Command Line Interface ───────────────────────────────────────────────────

def _colorize(text: str, color_code: str, is_tty: bool = True) -> str:
    if not is_tty:
        return text
    return f"\033[{color_code}m{text}\033[0m"


def _print_table(headers: list[str], rows: list[list[str]], is_tty: bool = True) -> None:
    if not rows:
        print("  (None)")
        return
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, val in enumerate(row):
            if i < len(col_widths):
                col_widths[i] = max(col_widths[i], len(str(val)))
    header_str = "  ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
    sep_str = "  ".join("-" * col_widths[i] for i in range(len(headers)))
    print(_colorize(header_str, "1;36", is_tty))
    print(_colorize(sep_str, "90", is_tty))
    for row in rows:
        line = "  ".join(str(row[i]).ljust(col_widths[i]) if i < len(row) else "".ljust(col_widths[i]) for i in range(len(headers)))
        print(line)


def _print_error_card(res: dict[str, Any], is_tty: bool = True) -> None:
    import sys
    raw_err = res.get("error", "Unknown error")
    title = res.get("cause_title", "")
    expl = res.get("cause_explanation", "")
    act = res.get("cause_action", "")
    url = res.get("dashboard_url", "")
    perm = res.get("required_perm", "")

    title_ar = res.get("cause_title_ar", "")
    expl_ar = res.get("cause_explanation_ar", "")
    act_ar = res.get("cause_action_ar", "")

    print(_colorize(f"\n✖ Error: {raw_err}", "1;31", is_tty), file=sys.stderr)
    if title:
        print(_colorize(f"  [Root Cause] {title}", "1;33", is_tty), file=sys.stderr)
    if expl:
        print(f"  {expl}", file=sys.stderr)
    if perm:
        print(_colorize(f"  Required API Permission: {perm}", "1;36", is_tty), file=sys.stderr)
    if act:
        print(_colorize(f"  [Suggested Fix] {act}", "1;32", is_tty), file=sys.stderr)
    if url:
        print(_colorize(f"  Dashboard Link: {url}", "4;34", is_tty), file=sys.stderr)

    if title_ar and title_ar != title:
        print(_colorize(f"  (عربي) {title_ar}: {act_ar or expl_ar}", "90", is_tty), file=sys.stderr)

    print(file=sys.stderr)


def main(argv: list[str] | None = None) -> int:
    import sys

    if argv is None:
        argv = sys.argv[1:]

    is_json = "--json" in argv
    clean_argv = [a for a in argv if a != "--json"]
    cmd = clean_argv[0] if clean_argv else "status"
    is_tty = sys.stdout.isatty() and not is_json

    cf = CloudflareClient()

    def respond(data: dict[str, Any]) -> int:
        if is_json:
            print(json.dumps(data, indent=2))
            return 0 if data.get("ok", True) else 1
        return 0 if data.get("ok", True) else 1

    try:
        if cmd == "status":
            st = cf.get_status()
            if is_json:
                print(json.dumps(st, indent=2))
                return 0
            print(_colorize("Cloudflare Account Status", "1;34", is_tty))
            print("=" * 35)
            if st.get("configured"):
                print(f"  Active Account: {_colorize(st.get('account_name', 'N/A'), '1;32', is_tty)} ({st.get('account_id', 'N/A')})")
                print(f"  Token:          {st.get('token_masked') or st.get('token_preview', 'N/A')}")
                print(f"  Status:         {_colorize('Connected', '1;32', is_tty)}")
                tot = st.get("total_accounts", 1)
                if tot > 1:
                    print(f"  Total Accounts: {tot} linked (use 'laravel-dev cf accounts' or 'laravel-dev cf switch')")
            else:
                print(f"  Status:         {_colorize('Not Configured', '1;33', is_tty)}")
                print("  Run 'laravel-dev cloudflare auth' to connect your API token.")
            return 0

        elif cmd in ("accounts", "account-list"):
            accs = cf.list_stored_accounts()
            if is_json:
                print(json.dumps({"ok": True, "accounts": accs}, indent=2))
                return 0
            if not accs:
                print(_colorize("No Cloudflare accounts linked.", "1;33", is_tty))
                print("Run 'laravel-dev cf auth' to add an account.")
                return 0
            print(_colorize(f"Linked Cloudflare Accounts ({len(accs)} total):", "1;34", is_tty))
            rows = [
                [
                    "✔ Active" if a.get("is_active") else "",
                    a.get("account_name", ""),
                    a.get("account_id", ""),
                    a.get("token_preview", ""),
                ]
                for a in accs
            ]
            _print_table(["Status", "Account Name", "Account ID", "Token"], rows, is_tty)
            return 0

        elif cmd in ("switch", "use"):
            target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target:
                print(_colorize("Usage: laravel-dev cloudflare switch <account_id_or_name>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = cf.switch_account(target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Switched active Cloudflare account to: {res.get('account_name')} ({res.get('account_id')})", "1;32", is_tty))
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd in ("remove", "rm"):
            target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target:
                print(_colorize("Usage: laravel-dev cloudflare remove <account_id_or_name>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = cf.remove_account(target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Removed account: {res.get('removed_name')} ({res.get('removed_id')})", "1;32", is_tty))
                if res.get("remaining_count"):
                    print(f"  Active account is now: {res.get('new_active_id')}")
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd == "auth":
            token = clean_argv[1] if len(clean_argv) > 1 and not clean_argv[1].startswith("--") else ""
            custom_name = ""
            for i, a in enumerate(clean_argv):
                if a == "--name" and i + 1 < len(clean_argv):
                    custom_name = clean_argv[i + 1]

            if not token:
                if is_tty:
                    import getpass
                    token = getpass.getpass("Enter Cloudflare API Token: ").strip()
                else:
                    token = sys.stdin.read().strip()
            if not token:
                msg = "API token cannot be empty."
                if is_json:
                    print(json.dumps({"ok": False, "error": msg}))
                else:
                    print(_colorize(f"Error: {msg}", "1;31", is_tty), file=sys.stderr)
                return 1

            verify = cf.verify_token(token)
            if not verify.get("valid"):
                if is_json:
                    print(json.dumps(verify, indent=2))
                else:
                    _print_error_card(verify, is_tty)
                return 1

            accounts = verify.get("accounts", [])
            acc_id = accounts[0]["id"] if accounts else ""
            acc_name = custom_name or (accounts[0]["name"] if accounts else "Cloudflare Account")
            cf.save_credentials(token, account_id=acc_id, account_name=acc_name, make_active=True)

            if is_json:
                print(json.dumps({"ok": True, "account_id": acc_id, "account_name": acc_name}))
            else:
                print(_colorize("✔ Cloudflare API token verified and saved successfully!", "1;32", is_tty))
                if acc_name:
                    print(f"  Active Account: {acc_name} ({acc_id})")
                print("  You can add more accounts at any time with 'laravel-dev cf auth' and switch between them with 'laravel-dev cf switch'.")
            return 0

        elif cmd in ("logout", "disconnect"):
            cf.clear_credentials()
            if is_json:
                print(json.dumps({"ok": True}))
            else:
                print(_colorize("✔ Cloudflare credentials removed.", "1;32", is_tty))
            return 0

        elif cmd in ("zones", "domains"):
            res = cf.list_zones()
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if not res.get("ok"):
                _print_error_card(res, is_tty)
                return 1
            zones = res.get("zones", [])
            print(_colorize(f"Found {len(zones)} zone(s):", "1;34", is_tty))
            rows = [
                [z.get("name", ""), z.get("status", ""), z.get("plan", ""), z.get("id", ""), ",".join(z.get("name_servers", [])[:2])]
                for z in zones
            ]
            _print_table(["Domain", "Status", "Plan", "Zone ID", "Nameservers"], rows, is_tty)
            return 0

        elif cmd == "dns":
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            target_zone = clean_argv[2] if len(clean_argv) > 2 else ""

            if not target_zone:
                print(_colorize("Usage: laravel-dev cloudflare dns <list|add|delete|proxy> <zone> ...", "1;33", is_tty), file=sys.stderr)
                return 1

            zone_id = cf.resolve_zone_id(target_zone)
            if not zone_id:
                print(_colorize(f"Error: Could not resolve zone '{target_zone}'.", "1;31", is_tty), file=sys.stderr)
                return 1

            if sub == "list":
                res = cf.list_dns_records(zone_id)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                recs = res.get("records", [])
                print(_colorize(f"DNS records for {target_zone} ({len(recs)} total):", "1;34", is_tty))
                rows = [
                    [r.get("type", ""), r.get("name", ""), r.get("content", ""), "✔ Proxied" if r.get("proxied") else "DNS only", str(r.get("ttl", "")), r.get("id", "")]
                    for r in recs
                ]
                _print_table(["Type", "Name", "Content", "Proxy", "TTL", "Record ID"], rows, is_tty)
                return 0

            elif sub == "add":
                # args: dns add <zone> <type> <name> <content> [--proxied] [--ttl N]
                rtype = clean_argv[3] if len(clean_argv) > 3 else "A"
                rname = clean_argv[4] if len(clean_argv) > 4 else ""
                rcontent = clean_argv[5] if len(clean_argv) > 5 else ""
                proxied = "--proxied" in argv
                ttl = 1
                for i, a in enumerate(clean_argv):
                    if a == "--ttl" and i + 1 < len(clean_argv):
                        try:
                            ttl = int(clean_argv[i + 1])
                        except ValueError:
                            pass
                if not rname or not rcontent:
                    print(_colorize("Usage: laravel-dev cloudflare dns add <zone> <type> <name> <content> [--proxied] [--ttl N]", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.create_dns_record(zone_id, rtype, rname, rcontent, ttl=ttl, proxied=proxied)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ DNS record created: {rtype} {rname} -> {rcontent}", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "delete":
                rec_id = clean_argv[3] if len(clean_argv) > 3 else ""
                if not rec_id:
                    print(_colorize("Usage: laravel-dev cloudflare dns delete <zone> <record_id>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.delete_dns_record(zone_id, rec_id)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ DNS record {rec_id} deleted.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "proxy":
                rec_id = clean_argv[3] if len(clean_argv) > 3 else ""
                val = clean_argv[4].lower() if len(clean_argv) > 4 else "on"
                proxied = val in ("on", "true", "1", "yes")
                if not rec_id:
                    print(_colorize("Usage: laravel-dev cloudflare dns proxy <zone> <record_id> <on|off>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.toggle_dns_proxy(zone_id, rec_id, proxied)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ DNS record {rec_id} proxy set to: {'Proxied' if proxied else 'DNS only'}", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd == "purge":
            # args: purge <zone> [--all] [file1 file2 ...]
            target_zone = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target_zone:
                print(_colorize("Usage: laravel-dev cloudflare purge <zone> [--all | files...]", "1;33", is_tty), file=sys.stderr)
                return 1
            zone_id = cf.resolve_zone_id(target_zone)
            if not zone_id:
                print(_colorize(f"Error: Could not resolve zone '{target_zone}'.", "1;31", is_tty), file=sys.stderr)
                return 1
            purge_everything = "--all" in argv or len(clean_argv) <= 2
            files = [f for f in clean_argv[2:] if not f.startswith("--")] if not purge_everything else None
            res = cf.purge_cache(zone_id, purge_everything=purge_everything, files=files)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                mode = "entire cache" if purge_everything else f"{len(files or [])} files"
                print(_colorize(f"✔ Cloudflare cache purged successfully ({mode}) for {target_zone}!", "1;32", is_tty))
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd in ("dev-mode", "devmode"):
            target_zone = clean_argv[1] if len(clean_argv) > 1 else ""
            val = clean_argv[2].lower() if len(clean_argv) > 2 else ""
            if not target_zone:
                print(_colorize("Usage: laravel-dev cloudflare dev-mode <zone> [on|off|status]", "1;33", is_tty), file=sys.stderr)
                return 1
            zone_id = cf.resolve_zone_id(target_zone)
            if not zone_id:
                print(_colorize(f"Error: Could not resolve zone '{target_zone}'.", "1;31", is_tty), file=sys.stderr)
                return 1

            if val in ("on", "enable", "true", "1"):
                res = cf.set_dev_mode(zone_id, True)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Development Mode turned ON for {target_zone} (cache bypassed for 3 hours).", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1
            elif val in ("off", "disable", "false", "0"):
                res = cf.set_dev_mode(zone_id, False)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Development Mode turned OFF for {target_zone}.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1
            else:
                res = cf.get_dev_mode(zone_id)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    dm = res.get("dev_mode")
                    rem = res.get("time_remaining", 0)
                    state_str = _colorize("ON", "1;32", is_tty) if dm else _colorize("OFF", "1;33", is_tty)
                    extra = f" ({rem // 60}m remaining)" if dm and rem else ""
                    print(f"Development Mode for {target_zone}: {state_str}{extra}")
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd == "security":
            target_zone = clean_argv[1] if len(clean_argv) > 1 else ""
            level = clean_argv[2].lower() if len(clean_argv) > 2 else ""
            if not target_zone:
                print(_colorize("Usage: laravel-dev cloudflare security <zone> [essentially_off|low|medium|high|under_attack]", "1;33", is_tty), file=sys.stderr)
                return 1
            zone_id = cf.resolve_zone_id(target_zone)
            if not zone_id:
                print(_colorize(f"Error: Could not resolve zone '{target_zone}'.", "1;31", is_tty), file=sys.stderr)
                return 1
            if level:
                res = cf.set_security_level(zone_id, level)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Security level for {target_zone} set to: {level}", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1
            else:
                res = cf.get_security_level(zone_id)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(f"Security level for {target_zone}: {_colorize(res.get('level', 'N/A'), '1;32', is_tty)}")
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd == "r2":
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "list":
                res = cf.list_r2_buckets()
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                b = res.get("buckets", [])
                print(_colorize(f"Cloudflare R2 Buckets ({len(b)} total):", "1;34", is_tty))
                rows = [[item.get("name", ""), item.get("jurisdiction", "default"), item.get("created_at", "")] for item in b]
                _print_table(["Bucket Name", "Jurisdiction", "Created At"], rows, is_tty)
                return 0

            elif sub == "create":
                name = clean_argv[2] if len(clean_argv) > 2 else ""
                loc = clean_argv[3] if len(clean_argv) > 3 else ""
                if not name:
                    print(_colorize("Usage: laravel-dev cloudflare r2 create <bucket_name> [location_hint]", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.create_r2_bucket(name, location_hint=loc)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ R2 Bucket '{name}' created successfully!", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "delete":
                name = clean_argv[2] if len(clean_argv) > 2 else ""
                if not name:
                    print(_colorize("Usage: laravel-dev cloudflare r2 delete <bucket_name>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.delete_r2_bucket(name)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ R2 Bucket '{name}' deleted.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "env":
                # args: r2 env <project> <bucket> [access_key] [secret_key]
                proj = clean_argv[2] if len(clean_argv) > 2 else ""
                bucket = clean_argv[3] if len(clean_argv) > 3 else ""
                access_key = clean_argv[4] if len(clean_argv) > 4 else ""
                secret_key = clean_argv[5] if len(clean_argv) > 5 else ""
                if not proj or not bucket:
                    print(_colorize("Usage: laravel-dev cloudflare r2 env <project_path_or_name> <bucket> [access_key] [secret_key]", "1;33", is_tty), file=sys.stderr)
                    return 1
                env_file = Path(proj) / ".env" if Path(proj).is_dir() else Path.home() / "Sites" / proj / ".env"
                if not env_file.is_file():
                    # Check current dir
                    if (Path.cwd() / ".env").is_file():
                        env_file = Path.cwd() / ".env"
                    else:
                        print(_colorize(f"Error: Could not locate .env for '{proj}'.", "1;31", is_tty), file=sys.stderr)
                        return 1
                acc_id = cf.load_credentials().get("account_id", "")
                endpoint = f"https://{acc_id}.r2.cloudflaredstorage.com" if acc_id else ""
                updates = {
                    "FILESYSTEM_DISK": "r2",
                    "R2_BUCKET": bucket,
                }
                if endpoint:
                    updates["R2_ENDPOINT"] = endpoint
                if access_key:
                    updates["R2_ACCESS_KEY_ID"] = access_key
                if secret_key:
                    updates["R2_SECRET_ACCESS_KEY"] = secret_key

                import re
                lines = env_file.read_text(encoding="utf-8").splitlines()
                existing_keys = set()
                new_lines = []
                for line in lines:
                    m = re.match(r"^([A-Za-z0-9_]+)=", line)
                    if m and m.group(1) in updates:
                        k = m.group(1)
                        existing_keys.add(k)
                        new_lines.append(f"{k}={updates[k]}")
                    else:
                        new_lines.append(line)
                for k, v in updates.items():
                    if k not in existing_keys:
                        new_lines.append(f"{k}={v}")
                env_file.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
                print(_colorize(f"✔ R2 configuration written to {env_file}:", "1;32", is_tty))
                for k in updates:
                    print(f"  {k}={updates[k]}")
                return 0

        elif cmd in ("tunnels", "tunnel"):
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "list":
                res = cf.list_account_tunnels()
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                tuns = res.get("tunnels", [])
                print(_colorize(f"Cloudflare Named Tunnels ({len(tuns)} total):", "1;34", is_tty))
                rows = [[t.get("name", ""), t.get("status", ""), str(t.get("connections", 0)), t.get("id", ""), t.get("created_at", "")] for t in tuns]
                _print_table(["Name", "Status", "Connections", "Tunnel ID", "Created At"], rows, is_tty)
                return 0

            elif sub == "create":
                name = clean_argv[2] if len(clean_argv) > 2 else ""
                if not name:
                    print(_colorize("Usage: laravel-dev cloudflare tunnel create <name>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.create_account_tunnel(name)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Named Tunnel '{name}' created!", "1;32", is_tty))
                    print(f"  Tunnel ID: {res.get('id')}")
                    if res.get("token"):
                        print(f"  Token:     {res.get('token')}")
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "token":
                tid = clean_argv[2] if len(clean_argv) > 2 else ""
                if not tid:
                    print(_colorize("Usage: laravel-dev cloudflare tunnel token <tunnel_id>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.get_tunnel_token(tid)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(res.get("token", ""))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "delete":
                tid = clean_argv[2] if len(clean_argv) > 2 else ""
                if not tid:
                    print(_colorize("Usage: laravel-dev cloudflare tunnel delete <tunnel_id>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.delete_account_tunnel(tid)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Tunnel {tid} deleted.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

        else:
            print(_colorize(f"Unknown command '{cmd}'.", "1;31", is_tty), file=sys.stderr)
            print("Available commands: status, auth, logout, zones, dns, purge, dev-mode, security, r2, tunnels", file=sys.stderr)
            return 1

    except KeyboardInterrupt:
        print("\nAborted.")
        return 130
    except Exception as exc:
        if is_json:
            print(json.dumps({"ok": False, "error": str(exc)}))
        else:
            print(_colorize(f"Fatal error: {exc}", "1;31", is_tty), file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
