"""Vite & Asset Watcher Supervisor Engine for Laravel Dev.

Supervises `composer run dev` / `npm run dev` / Vite processes in the background per site,
capturing Hot Module Replacement (HMR) build logs, port detection, readiness wait,
and idle auto-shutdown after inactivity.
"""
from __future__ import annotations

import collections
import json
import os
import re
import signal
import socket
import subprocess
import threading
import time
from pathlib import Path
from typing import Any


IDLE_SECONDS = 900
ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
# Vite's own line ("➜  Local:   http://localhost:5173/"). `composer run dev` also prints
# artisan serve's address, which is not the dev server.
LOCAL_URL_RE = re.compile(r"Local:\s+https?://[^\s:/]+:(\d+)")


def _port_open(port: int) -> bool:
    for host in ("127.0.0.1", "::1"):  # Vite may listen on IPv6 only
        try:
            with socket.create_connection((host, port), timeout=0.25):
                return True
        except OSError:
            continue
    return False


def port_in_use_by_browser(port: int) -> bool:
    """True while something is connected to the port: a page with Vite keeps a socket open."""
    want = f"{port:04X}"
    for table in ("/proc/net/tcp", "/proc/net/tcp6"):
        try:
            rows = Path(table).read_text().splitlines()[1:]
        except OSError:
            continue
        for row in rows:
            cols = row.split()
            if len(cols) > 3 and cols[3] == "01" and cols[1].rsplit(":", 1)[-1] == want:
                return True
    return False


class ViteSiteWatcher:
    def __init__(self, site_path: str):
        self.site_path = os.path.realpath(site_path)
        self.process: subprocess.Popen[str] | None = None
        self.pid: int | None = None
        self.port: int = 5173
        self.logs: collections.deque[str] = collections.deque(maxlen=300)
        self.thread: threading.Thread | None = None
        self.running: bool = False
        self.ready: bool = False
        self.last_activity: float = time.time()
        self.lock = threading.RLock()

    def has_frontend(self) -> bool:
        p = Path(self.site_path)
        pkg = p / "package.json"
        composer = p / "composer.json"

        # Check composer.json for scripts.dev
        if composer.is_file():
            try:
                cdata = json.loads(composer.read_text(encoding="utf-8", errors="replace"))
                if "dev" in cdata.get("scripts", {}):
                    return True
            except Exception:
                pass

        # Check package.json
        if pkg.is_file():
            try:
                data = json.loads(pkg.read_text(encoding="utf-8", errors="replace"))
                scripts = data.get("scripts", {})
                return "dev" in scripts or "watch" in scripts  # the scripts detect_dev_command() runs
            except Exception:
                pass
        return False

    def detect_dev_command(self) -> list[str]:
        p = Path(self.site_path)
        # Check composer.json first
        composer = p / "composer.json"
        if composer.is_file():
            try:
                cdata = json.loads(composer.read_text(encoding="utf-8", errors="replace"))
                if "dev" in cdata.get("scripts", {}):
                    return ["composer", "run", "dev"]
            except Exception:
                pass

        # Check package.json
        pkg = p / "package.json"
        if pkg.is_file():
            try:
                data = json.loads(pkg.read_text(encoding="utf-8", errors="replace"))
                scripts = data.get("scripts", {})
                if "dev" in scripts:
                    return ["npm", "run", "dev"]
                if "watch" in scripts:
                    return ["npm", "run", "watch"]
            except Exception:
                pass
        return ["npm", "run", "dev"]

    def is_alive(self) -> bool:
        with self.lock:
            if self.process and self.process.poll() is None:
                self.running = True
                return True
            self.running = False
            self.ready = False
            return False

    def touch_activity(self) -> None:
        with self.lock:
            self.last_activity = time.time()

    def hot_port(self) -> int | None:
        """Port in public/hot: Laravel's Vite plugin writes that file once the server is up,
        and removes it when it stops. A left-over file points at a closed port."""
        try:
            url = (Path(self.site_path) / "public" / "hot").read_text(encoding="utf-8", errors="replace").strip()
        except OSError:
            return None
        m = re.match(r"https?://(?:\[[^\]]+\]|[^\s:/]+):(\d+)", url)
        return int(m.group(1)) if m and _port_open(int(m.group(1))) else None

    def is_idle(self, timeout_seconds: int = IDLE_SECONDS) -> bool:
        if self.ready and port_in_use_by_browser(self.port):
            self.touch_activity()
        with self.lock:
            return (time.time() - self.last_activity) > timeout_seconds

    def wait_ready(self, timeout: float = 10.0) -> bool:
        """Waits until this project's dev server is up. Another project may be using the default
        port, so an open port alone proves nothing: wait for its own output or public/hot."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if not self.is_alive():
                return False
            hot = self.hot_port()
            with self.lock:
                if hot:
                    self.port, self.ready = hot, True
                if self.ready and _port_open(self.port):
                    return True
            time.sleep(0.2)
        return False

    def start(self) -> dict[str, Any]:
        _ensure_reaper_started()
        with self.lock:
            if self.is_alive():
                self.last_activity = time.time()
                return {"ok": True, "running": True, "pid": self.pid, "port": self.port, "ready": self.ready}

            cmd = self.detect_dev_command()

            try:
                self.logs.clear()
                self.logs.append(f"[{time.strftime('%H:%M:%S')}] Starting dev server: {' '.join(cmd)}")
                self.ready = False
                self.last_activity = time.time()

                self.process = subprocess.Popen(
                    cmd,
                    cwd=self.site_path,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    preexec_fn=os.setsid if hasattr(os, "setsid") else None,
                )
                self.pid = self.process.pid
                self.running = True

                def _reader():
                    assert self.process and self.process.stdout
                    for line in iter(self.process.stdout.readline, ""):
                        stripped = ANSI_RE.sub("", line).rstrip()
                        if stripped:
                            with self.lock:
                                self.logs.append(stripped)
                                m = LOCAL_URL_RE.search(stripped)
                                if m:
                                    self.port = int(m.group(1))
                                    self.ready = True
                    with self.lock:
                        self.running = False
                        self.ready = False
                        self.logs.append(f"[{time.strftime('%H:%M:%S')}] Process exited.")

                self.thread = threading.Thread(target=_reader, daemon=True, name=f"vite-{Path(self.site_path).name}")
                self.thread.start()

                # Give it a brief moment to initialize
                time.sleep(0.3)
                return {"ok": True, "running": True, "pid": self.pid, "port": self.port, "ready": self.ready}
            except Exception as e:
                self.running = False
                self.ready = False
                self.logs.append(f"Error starting dev server: {e}")
                return {"ok": False, "error": str(e)}

    def ensure_running(self, wait: bool = True, timeout: float = 10.0) -> dict[str, Any]:
        """Auto-starts dev server if not running, touches activity, and optionally waits for readiness."""
        self.touch_activity()
        if not self.is_alive():
            hot = self.hot_port()
            if hot:  # started by hand in a terminal: use it, don't start a second one
                return {"ok": True, "running": True, "external": True, "pid": None, "port": hot, "ready": True}
            res = self.start()
            if not res.get("ok"):
                return res

        ready = self.wait_ready(timeout) if wait else self.ready
        with self.lock:
            return {
                "ok": True,
                "running": self.running,
                "pid": self.pid,
                "port": self.port,
                "ready": ready,
                "last_activity": self.last_activity,
            }

    def stop(self) -> dict[str, Any]:
        with self.lock:
            if not self.process:
                return {"ok": True, "message": "Not running"}

            try:
                if hasattr(os, "killpg") and self.pid:
                    os.killpg(os.getpgid(self.pid), signal.SIGTERM)
                else:
                    self.process.terminate()

                time.sleep(0.4)
                if self.process.poll() is None:
                    if hasattr(os, "killpg") and self.pid:
                        os.killpg(os.getpgid(self.pid), signal.SIGKILL)
                    else:
                        self.process.kill()

                self.running = False
                self.ready = False
                self.logs.append(f"[{time.strftime('%H:%M:%S')}] Watcher stopped.")
                return {"ok": True, "message": "Watcher stopped"}
            except Exception as e:
                return {"ok": False, "error": str(e)}

    def get_status(self) -> dict[str, Any]:
        alive = self.is_alive()
        # If not alive internally, scan if an external npm run dev / vite is running in this dir
        if not alive:
            try:
                res = subprocess.run(["ps", "-eo", "pid,args"], capture_output=True, text=True, timeout=2)
                for line in res.stdout.splitlines():
                    if ("vite" in line or "npm run dev" in line or "composer run dev" in line) and self.site_path in line:
                        parts = line.strip().split(None, 1)
                        if parts:
                            alive = True
                            self.pid = int(parts[0])
                            break
            except Exception:
                pass

        with self.lock:
            return {
                "ok": True,
                "has_frontend": self.has_frontend(),
                "running": alive,
                "ready": self.ready,
                "pid": self.pid if alive else None,
                "port": self.port,
                "last_activity": self.last_activity,
                "logs": list(self.logs),
            }


# Singleton manager
_WATCHERS: dict[str, ViteSiteWatcher] = {}
_WATCHERS_LOCK = threading.Lock()


def get_watcher(site_path: str) -> ViteSiteWatcher:
    norm = os.path.realpath(site_path)
    with _WATCHERS_LOCK:
        if norm not in _WATCHERS:
            _WATCHERS[norm] = ViteSiteWatcher(norm)
        return _WATCHERS[norm]


def get_vite_status(site_path: str) -> dict[str, Any]:
    return get_watcher(site_path).get_status()


def start_vite(site_path: str) -> dict[str, Any]:
    return get_watcher(site_path).start()


def stop_vite(site_path: str) -> dict[str, Any]:
    return get_watcher(site_path).stop()


def ensure_vite_running(site_path: str, wait: bool = True, timeout: float = 10.0) -> dict[str, Any]:
    return get_watcher(site_path).ensure_running(wait=wait, timeout=timeout)


def touch_vite_activity(site_path: str) -> None:
    get_watcher(site_path).touch_activity()


def has_dev_server(site_path: str) -> bool:
    return get_watcher(site_path).has_frontend()


def stop_all() -> None:
    """The app is closing: its dev servers belong to its session."""
    with _WATCHERS_LOCK:
        watchers = list(_WATCHERS.values())
    for w in watchers:
        if w.is_alive():
            w.stop()


# Background Idle Reaper
_REAPER_THREAD: threading.Thread | None = None


def _idle_reaper_loop():
    while True:
        try:
            time.sleep(60)
            with _WATCHERS_LOCK:
                watchers = list(_WATCHERS.values())
            for w in watchers:
                if w.is_alive() and w.is_idle():
                    w.logs.append(f"[{time.strftime('%H:%M:%S')}] Auto-stopped dev server after 15m idle.")
                    w.stop()
        except Exception:
            pass


def _ensure_reaper_started():
    global _REAPER_THREAD
    with _WATCHERS_LOCK:
        if _REAPER_THREAD is None:
            _REAPER_THREAD = threading.Thread(target=_idle_reaper_loop, daemon=True, name="vite-idle-reaper")
            _REAPER_THREAD.start()
