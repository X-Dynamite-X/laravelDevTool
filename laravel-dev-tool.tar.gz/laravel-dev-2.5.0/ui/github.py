#!/usr/bin/env python3
"""GitHub Hub Manager for Laravel Dev.

Manages GitHub authentication, multi-account storage, repositories, pull requests,
issues, GitHub Actions workflows, and local Laravel site publishing via GitHub REST API v3.
"""

from __future__ import annotations

import base64
import http.client
import io
import json
import os
import re
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

try:
    from osutil import private_file
except ImportError:
    try:
        from ui.osutil import private_file
    except ImportError:
        def private_file(p: Path) -> Path:
            p.parent.mkdir(parents=True, exist_ok=True)
            if not p.exists():
                p.touch()
            try:
                os.chmod(p, 0o600)
            except OSError:
                pass
            return p

GH_API_BASE = "https://api.github.com"


def _config_dirs() -> tuple[Path, Path]:
    uid = os.getuid() if hasattr(os, "getuid") else 1000
    candidates = [
        Path.home() / ".config" / "laravel-dev",
        Path(f"/tmp/laravel-dev-{uid}"),
    ]
    writable_dir = candidates[-1]
    for d in candidates:
        try:
            d.mkdir(parents=True, exist_ok=True)
            test_file = d / ".gh_write_test"
            test_file.touch()
            test_file.unlink(missing_ok=True)
            writable_dir = d
            break
        except OSError:
            continue

    writable_file = writable_dir / "github.json"

    # If fallback dir, sync from primary if exists
    if writable_dir != candidates[0]:
        primary_file = candidates[0] / "github.json"
        if primary_file.is_file() and not writable_file.is_file():
            try:
                writable_file.write_text(primary_file.read_text(encoding="utf-8"), encoding="utf-8")
                try:
                    os.chmod(writable_file, 0o600)
                except OSError:
                    pass
            except OSError:
                pass

    return writable_dir, writable_file


def analyze_gh_error(
    error_message: str,
    error_code: int = 0,
    status_code: int = 0,
    endpoint: str = "",
    username: str = "",
) -> dict[str, str]:
    """Analyze GitHub API errors and return bilingual root cause, fix, and direct dashboard URL."""
    msg = error_message.lower().strip()
    gh_base = f"https://github.com/{username}" if username else "https://github.com"

    # 1. Bad Credentials / Unauthorized
    if (
        status_code == 401
        or "bad credentials" in msg
        or "requires authentication" in msg
        or "token expired" in msg
    ):
        return {
            "category": "bad_credentials",
            "key": "bad_credentials",
            "title": "Invalid or Expired GitHub Personal Access Token",
            "explanation": "GitHub rejected this Personal Access Token. It may have expired, been revoked, or mistyped.",
            "action": "Generate a new Personal Access Token (Classic or Fine-grained) in your GitHub settings and reconnect.",
            "title_ar": "رمز الوصول الشخصي (PAT) غير صالح أو منتهي الصلاحية",
            "explanation_ar": "رفضت منصة GitHub رمز الـ API الحالي. قد يكون الرمز منتهي الصلاحية أو تم إبطاله أو نسخه بشكل غير صحيح.",
            "action_ar": "قم بإنشاء رمز وصول شخصي (Personal Access Token) جديد من إعدادات GitHub وانسخه للتطبيق.",
            "url": "https://github.com/settings/tokens/new?scopes=repo,workflow,read:org,user:email",
            "required_perm": "repo, workflow, read:org, user:email",
        }

    # 2. Rate Limit Exceeded
    if (
        status_code in (403, 429)
        and ("rate limit" in msg or "api rate limit exceeded" in msg)
    ):
        return {
            "category": "rate_limited",
            "key": "rate_limit_exceeded",
            "title": "GitHub API Rate Limit Exceeded (5,000 req/hr)",
            "explanation": "You have reached GitHub's rate limit. Authenticated requests allow up to 5,000 requests per hour.",
            "action": "Please wait a few minutes for your rate limit quota to refresh automatically.",
            "title_ar": "تم تجاوز حد طلبات GitHub API المؤقت",
            "explanation_ar": "تم تجاوز الحد الأقصى المسموح به للطلبات (5000 طلب/ساعة للرموز الموثقة).",
            "action_ar": "يرجى الانتظار بضع دقائق حتى يتم تجديد رصيد الطلبات تلقائياً.",
            "url": "https://docs.github.com/rest/overview/resources-in-the-rest-api#rate-limiting",
            "required_perm": "",
        }

    # 3. Missing Scopes / Permissions
    if (
        status_code == 403
        or "resource not accessible" in msg
        or "must have admin rights" in msg
        or "scope" in msg
        or "permission" in msg
    ):
        if "workflow" in endpoint or "actions" in endpoint or "workflow" in msg:
            perm = "workflow"
            perm_desc = "GitHub Actions Workflows"
        elif "keys" in endpoint or "ssh" in msg:
            perm = "admin:public_key, repo"
            perm_desc = "SSH and Deploy Keys"
        elif "org" in endpoint or "orgs" in endpoint:
            perm = "read:org, admin:org"
            perm_desc = "Organization Access"
        else:
            perm = "repo"
            perm_desc = "Full Control of Repositories"

        return {
            "category": "missing_scope",
            "key": "missing_scope",
            "title": f"Missing Required Token Scope ({perm})",
            "explanation": f"Your GitHub token does not have permission for {perm_desc}. GitHub rejected the request because the [{perm}] scope is not granted.",
            "action": f"Edit your token at GitHub Settings > Developer settings > Personal access tokens, enable the [{perm}] checkbox, and save.",
            "title_ar": f"نقص في صلاحية الرمز المطلوبة ({perm})",
            "explanation_ar": f"رمز GitHub الحالي يفتقر لصلاحية [{perm}] الضرورية للقيام بهذه العملية.",
            "action_ar": f"انتقل إلى إعدادات الرموز في GitHub وقم بتفعيل خيار [{perm}] ثم احفظ التعديل.",
            "url": "https://github.com/settings/tokens",
            "required_perm": perm,
        }

    # 4. Repository Name Conflict / Already Exists
    if (
        status_code == 422
        and ("already exists" in msg or "name already exists" in msg)
    ):
        return {
            "category": "repo_conflict",
            "key": "repo_already_exists",
            "title": "Repository Already Exists",
            "explanation": "A repository with this name already exists under your account or organization.",
            "action": "Choose a different repository name, or link the existing repository instead.",
            "title_ar": "اسم المستودع موجود مسبقاً (Repository Already Exists)",
            "explanation_ar": "يوجد مستودع سابق بنفس هذا الاسم مسجل تحت حسابك أو منظمتك على GitHub.",
            "action_ar": "اختر اسماً آخر للمستودع، أو قم بربط المستودع الموجود مسبقاً.",
            "url": f"https://github.com/{username}?tab=repositories" if username else "https://github.com",
            "required_perm": "",
        }

    # 5. Not Found (404) - often indicates missing repo scope for private repos
    if status_code == 404:
        return {
            "category": "not_found",
            "key": "not_found",
            "title": "Resource Not Found or Access Denied",
            "explanation": "The repository or resource was not found. If this is a private repository, ensure your API token has the 'repo' scope granted.",
            "action": "Check the repository owner and name, and verify your token has 'repo' scope for private repositories.",
            "title_ar": "المستودع غير موجود أو لا تملك صلاحية الوصول إليه",
            "explanation_ar": "تعذر العثور على المستودع. إن كان المستودع خاصاً (Private)، تأكد من أن رمز الـ API يملك صلاحية 'repo'.",
            "action_ar": "تحقق من صحة اسم المستودع، ومن تفعيل صلاحية 'repo' للوصول للمستودعات الخاصة.",
            "url": "https://github.com/settings/tokens",
            "required_perm": "repo",
        }

    # 6. Merge Conflict (409 / 405)
    if status_code in (405, 409) or "conflict" in msg or "not mergeable" in msg:
        return {
            "category": "merge_conflict",
            "key": "merge_conflict",
            "title": "Pull Request Has Merge Conflicts",
            "explanation": "This pull request cannot be merged automatically because there are conflicting changes between the base and head branches.",
            "action": "Pull the latest base branch locally, resolve conflicts, and push to the feature branch before merging.",
            "title_ar": "تعارض في الدمج (Merge Conflict)",
            "explanation_ar": "لا يمكن دمج طلب السحب تلقائياً لوجود تعارض في الملفات بين الفرعين.",
            "action_ar": "قم بحل التعارضات محلياً ثم ارفع التعديلات للفرع لإتمام الدمج.",
            "url": gh_base,
            "required_perm": "",
        }

    # 7. Generic Fallback
    return {
        "category": "api_error",
        "key": "generic_api_error",
        "title": "GitHub API Error",
        "explanation": error_message,
        "action": "Check GitHub Status or verify your repository settings.",
        "title_ar": "خطأ من منصة GitHub",
        "explanation_ar": error_message,
        "action_ar": "راجع إعدادات المستودع أو حالة منصة GitHub.",
        "url": gh_base,
        "required_perm": "",
    }


class _PooledResponse:
    """A fully read HTTP response with the few urlopen() features GitHubClient uses."""

    def __init__(self, status: int, headers: Any, body: bytes):
        self.status = status
        self.headers = headers
        self._body = io.BytesIO(body)

    def read(self, n: int = -1) -> bytes:
        return self._body.read(n)

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        return False


class _HttpsPool:
    """Keep-alive HTTPS connections.

    urllib opens a new TCP+TLS connection for every call, which is most of the time a
    GitHub request takes. Opening one repository needs several requests, so reuse connections.
    """

    IDLE_SECONDS = 50
    MAX_IDLE = 8

    def __init__(self):
        self._lock = threading.Lock()
        self._idle: dict[str, list[tuple[http.client.HTTPSConnection, float]]] = {}
        self._ctx: ssl.SSLContext | None = None

    def context(self) -> ssl.SSLContext:
        with self._lock:
            if self._ctx is None:
                self._ctx = ssl.create_default_context()
            return self._ctx

    def _take(self, host: str) -> http.client.HTTPSConnection | None:
        stale = []
        found = None
        with self._lock:
            conns = self._idle.get(host, [])
            while conns:
                conn, since = conns.pop()
                if time.monotonic() - since < self.IDLE_SECONDS:
                    found = conn
                    break
                stale.append(conn)
        for conn in stale:
            conn.close()
        return found

    def _give(self, host: str, conn: http.client.HTTPSConnection) -> None:
        with self._lock:
            conns = self._idle.setdefault(host, [])
            if len(conns) < self.MAX_IDLE:
                conns.append((conn, time.monotonic()))
                return
        conn.close()

    @staticmethod
    def _proxied(host: str) -> bool:
        proxies = urllib.request.getproxies()
        return bool(proxies.get("https") or proxies.get("all")) and not urllib.request.proxy_bypass(host)

    def urlopen(self, req: urllib.request.Request, timeout: float = 15, context: Any = None) -> Any:
        """Same contract as urllib.request.urlopen (raises HTTPError / URLError)."""
        parts = urllib.parse.urlsplit(req.full_url)
        host = parts.netloc
        if parts.scheme != "https" or self._proxied(parts.hostname or ""):
            return urllib.request.urlopen(req, timeout=timeout, context=context or self.context())

        method = req.get_method()
        path = parts.path or "/"
        if parts.query:
            path += "?" + parts.query
        headers = dict(req.header_items())
        # A reused connection may have been closed by the server. Only a read can be repeated safely.
        conn = self._take(host) if method in ("GET", "HEAD") else None
        while True:
            reused = conn is not None
            if conn is None:
                conn = http.client.HTTPSConnection(host, timeout=timeout, context=self.context())
            try:
                if conn.sock is not None:
                    conn.sock.settimeout(timeout)
                conn.request(method, path, body=req.data, headers=headers)
                resp = conn.getresponse()
                body = resp.read()
                break
            except TimeoutError as exc:
                conn.close()
                raise urllib.error.URLError("timed out") from exc
            except (OSError, http.client.HTTPException) as exc:
                conn.close()
                if reused:
                    conn = None
                    continue
                raise urllib.error.URLError(exc) from exc
        if resp.will_close:
            conn.close()
        else:
            self._give(host, conn)

        if resp.status in (301, 302, 303, 307, 308) and method in ("GET", "HEAD"):
            # Renamed repositories: let urllib follow it.
            return urllib.request.urlopen(req, timeout=timeout, context=self.context())
        if resp.status >= 300:
            raise urllib.error.HTTPError(req.full_url, resp.status, resp.reason, resp.headers, io.BytesIO(body))
        return _PooledResponse(resp.status, resp.headers, body)


_HTTPS_POOL = _HttpsPool()


def _urlopen(req: urllib.request.Request, timeout: float = 15, context: Any = None) -> Any:
    return _HTTPS_POOL.urlopen(req, timeout=timeout, context=context)


GIT_TIMEOUT = 8  # seconds, local read-only git commands
GIT_NET_TIMEOUT = 600  # seconds, clone and push


def _git_env(token: str = "") -> dict[str, str]:
    """Environment for git: never prompt, and authenticate github.com without ever putting
    the token in the command line or in .git/config."""
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
    if token:
        basic = base64.b64encode(f"x-access-token:{token}".encode()).decode("ascii")
        env.update({
            "GIT_CONFIG_COUNT": "1",
            "GIT_CONFIG_KEY_0": "http.https://github.com/.extraheader",
            "GIT_CONFIG_VALUE_0": f"Authorization: Basic {basic}",
        })
    return env


def _run_git(args: list[str], cwd: Path | None = None, timeout: float = GIT_TIMEOUT, token: str = "") -> subprocess.CompletedProcess[str]:
    """Run git with a timeout; failures come back as a non-zero return code, never an exception."""
    cmd = ["git"] + (["-C", str(cwd)] if cwd else []) + args
    try:
        return subprocess.run(cmd, capture_output=True, text=True, errors="replace", check=False,
                              stdin=subprocess.DEVNULL, timeout=timeout, env=_git_env(token))
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, 124, "", f"git timed out after {int(timeout)} seconds")
    except OSError as exc:
        return subprocess.CompletedProcess(cmd, 127, "", str(exc))


class _NoAuthRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Strip GitHub Authorization headers when following cross-origin redirects (e.g., job logs)."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        new_req = super().redirect_request(req, fp, code, msg, headers, newurl)
        if new_req is not None:
            new_req.headers.pop("Authorization", None)
            new_req.unredirected_hdrs.pop("Authorization", None)
        return new_req


def _image_mime(raw: bytes) -> str:
    """Image type from the bytes themselves; empty when this is not an image we show."""
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if raw.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if raw.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return "image/webp"
    if raw[4:12] in (b"ftypavif", b"ftypavis"):
        return "image/avif"
    if raw.startswith(b"BM"):
        return "image/bmp"
    if raw.startswith(b"\x00\x00\x01\x00"):
        return "image/x-icon"
    head = raw[:4096].lstrip(b"\xef\xbb\xbf").lstrip()
    if head.startswith(b"<") and re.search(rb"<svg[\s>]", head, re.I):
        return "image/svg+xml"
    return ""


def _parse_link_header(link_hdr: str) -> dict[str, int]:
    """Parse RFC 5988 Link header pagination page numbers (next, prev, last, first)."""
    pages: dict[str, int] = {}
    if not link_hdr:
        return pages
    for part in link_hdr.split(","):
        m = re.search(r'<([^>]+)>;\s*rel="([^"]+)"', part.strip())
        if not m:
            continue
        url, rel = m.group(1), m.group(2)
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        page_vals = q.get("page")
        if page_vals and page_vals[0].isdigit():
            pages[rel] = int(page_vals[0])
    return pages


def _split_repo(owner_or_full: str, repo: str = "") -> tuple[str, str]:
    """Normalize 'owner/repo' or (owner, repo) into safe stripped segments."""
    if "/" in owner_or_full and not repo:
        owner, name = owner_or_full.split("/", 1)
    else:
        owner, name = owner_or_full, repo
    # Encode each segment so values like "../x" or "a?b" cannot alter the API endpoint.
    def _seg(v: str) -> str:
        v = v.strip()
        if v in (".", ".."):
            return v.replace(".", "%2E")
        return urllib.parse.quote(v, safe="-_.")

    return _seg(owner), _seg(name)


def _encode_repo_path(path: str) -> str:
    """URL-encode a repository file path while preserving '/' directory separators."""
    cleaned = (path or "").strip().lstrip("/")
    return urllib.parse.quote(cleaned, safe="/")


class GitHubClient:
    """Manages GitHub authentication, multi-account storage, and REST API v3 / GraphQL operations."""

    def __init__(self, config_dir: Path | None = None, vault: Any = None):
        self._explicit_config_dir = config_dir is not None
        if config_dir:
            self.config_dir = Path(config_dir).resolve()
            self.config_file = self.config_dir / "github.json"
        else:
            self.config_dir, self.config_file = _config_dirs()
        self.vault = vault
        self._cached_creds: dict[str, Any] | None = None
        self._cached_vault_unlocked: bool | None = None
        self._etag_cache: dict[str, tuple[str, Any, dict[str, str], dict[str, str], dict[str, int], float]] = {}
        self._last_rate_limit: tuple[str, dict[str, str]] | None = None

    # ── Token Encryption & Vault Integration ─────────────────────────────────

    @staticmethod
    def _mask_token(tok: str) -> str:
        if not tok:
            return ""
        if tok.startswith("enc:"):
            return "****"
        return f"{tok[:4]}...{tok[-4:]}" if len(tok) >= 12 else "****"

    def _decrypt_stored_token(self, raw_tok: str) -> tuple[str, bool]:
        """Decrypt token if Vault-protected. Returns (token, vault_locked)."""
        if not raw_tok:
            return "", False
        if raw_tok.startswith("enc:"):
            if self.vault is None or not self.vault.is_unlocked():
                return "", True
            try:
                return self.vault.decrypt(raw_tok), False
            except Exception:
                return "", True
        return raw_tok, False

    def rekey_secrets(self, old_vault_key: bytes | None, new_vault_key: bytes | None) -> None:
        """Vault migrator hook: encrypt, decrypt, or re-encrypt stored GitHub tokens."""
        from cryptography.fernet import Fernet

        old_f = Fernet(old_vault_key) if old_vault_key else None
        new_f = Fernet(new_vault_key) if new_vault_key else None

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        changed = False
        for acc in accounts:
            if not isinstance(acc, dict):
                continue
            tok = acc.get("token", "")
            if not tok or not isinstance(tok, str):
                continue
            if tok.startswith("enc:"):
                if not old_f:
                    continue
                try:
                    plain = old_f.decrypt(tok[4:].encode("ascii")).decode("utf-8")
                except Exception:
                    continue
            else:
                plain = tok

            if plain and not acc.get("token_hint"):
                acc["token_hint"] = self._mask_token(plain)

            if new_f:
                acc["token"] = "enc:" + new_f.encrypt(plain.encode("utf-8")).decode("ascii")
            else:
                acc["token"] = plain
            changed = True

        if changed:
            self._save_raw_config(cfg)
        self._cached_creds = None

    # ── Multi-Account Storage ────────────────────────────────────────────────

    def _load_raw_config(self) -> dict[str, Any]:
        if not self.config_file.is_file():
            if not self._explicit_config_dir:
                primary_file = Path.home() / ".config" / "laravel-dev" / "github.json"
                if primary_file.is_file():
                    try:
                        return json.loads(primary_file.read_text(encoding="utf-8"))
                    except Exception:
                        pass
            return {"active_account_id": "", "accounts": []}

        try:
            return json.loads(self.config_file.read_text(encoding="utf-8"))
        except Exception:
            return {"active_account_id": "", "accounts": []}

    def _save_raw_config(self, data: dict[str, Any]) -> bool:
        try:
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            self.config_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
            # chmod after writing: the file may not exist before the first save.
            private_file(self.config_file)
            self._cached_creds = None
            return True
        except OSError:
            # Fallback path
            uid = os.getuid() if hasattr(os, "getuid") else 1000
            fallback_dir = Path(f"/tmp/laravel-dev-{uid}")
            fallback_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
            try:
                os.chmod(fallback_dir, 0o700)
            except OSError:
                pass
            self.config_dir = fallback_dir
            self.config_file = fallback_dir / "github.json"
            try:
                self.config_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
                private_file(self.config_file)
                self._cached_creds = None
                return True
            except OSError:
                return False

    def load_credentials(self) -> dict[str, Any]:
        """Return credentials for the currently active GitHub account."""
        unlocked_now = self.vault.is_unlocked() if self.vault is not None else True
        if self._cached_creds is not None and self._cached_vault_unlocked == unlocked_now:
            return self._cached_creds

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        active_id = cfg.get("active_account_id", "")

        active_acc: dict[str, Any] | None = None
        for a in accounts:
            if a.get("account_id") == active_id:
                active_acc = a
                break
        if not active_acc and accounts:
            active_acc = accounts[0]
            active_id = active_acc.get("account_id", "")

        if active_acc:
            raw_tok = active_acc.get("token", "")
            plain_tok, vault_locked = self._decrypt_stored_token(raw_tok)
            hint = active_acc.get("token_hint") or self._mask_token(plain_tok or raw_tok)
            self._cached_creds = {
                "token": plain_tok,
                "token_hint": hint,
                "vault_locked": vault_locked,
                "account_id": active_acc.get("account_id", ""),
                "account_name": active_acc.get("account_name", ""),
                "username": active_acc.get("username", ""),
                "avatar_url": active_acc.get("avatar_url", ""),
                "email": active_acc.get("email", ""),
                "scopes": active_acc.get("scopes", []),
                "is_active": True,
            }
        else:
            self._cached_creds = {
                "token": "",
                "token_hint": "",
                "vault_locked": False,
                "account_id": "",
                "account_name": "",
                "username": "",
                "avatar_url": "",
                "email": "",
                "scopes": [],
                "is_active": False,
            }
        self._cached_vault_unlocked = unlocked_now
        return self._cached_creds

    def get_active_account_id(self) -> str:
        """Return the active GitHub account ID."""
        creds = self.load_credentials()
        return creds.get("account_id", "")

    def list_stored_accounts(self) -> list[dict[str, Any]]:
        """Return list of all saved GitHub accounts."""
        cfg = self._load_raw_config()
        active_id = cfg.get("active_account_id", "")
        accounts = []
        for a in cfg.get("accounts", []):
            raw_tok = a.get("token", "")
            preview = a.get("token_hint") or self._mask_token(raw_tok)
            accounts.append({
                "account_id": a.get("account_id", ""),
                "account_name": a.get("account_name", ""),
                "username": a.get("username", ""),
                "name": a.get("name", ""),
                "avatar_url": a.get("avatar_url", ""),
                "email": a.get("email", ""),
                "scopes": a.get("scopes", []),
                "token_preview": preview,
                "encrypted": bool(isinstance(raw_tok, str) and raw_tok.startswith("enc:")),
                "is_active": a.get("account_id") == active_id,
            })
        return accounts

    def save_credentials(
        self,
        token: str,
        username: str = "",
        account_name: str = "",
        avatar_url: str = "",
        email: str = "",
        scopes: list[str] | None = None,
        make_active: bool = True,
    ) -> bool:
        """Save a new GitHub account or update an existing one (Vault-encrypted when enabled)."""
        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        account_id = username.strip().lower() or f"gh_{len(accounts) + 1}"

        existing_idx = -1
        for idx, acc in enumerate(accounts):
            if acc.get("account_id") == account_id or (
                username and acc.get("username", "").lower() == username.lower()
            ):
                existing_idx = idx
                break

        plain_token = token.strip()
        token_hint = self._mask_token(plain_token)
        stored_token = plain_token
        if self.vault is not None and self.vault.is_enabled() and plain_token:
            stored_token = self.vault.encrypt(plain_token)

        entry = {
            "account_id": account_id,
            "account_name": account_name.strip() or username or "GitHub Account",
            "username": username.strip(),
            "avatar_url": avatar_url.strip(),
            "email": email.strip(),
            "token": stored_token,
            "token_hint": token_hint,
            "scopes": scopes or [],
        }

        if existing_idx >= 0:
            accounts[existing_idx] = entry
        else:
            accounts.append(entry)

        cfg["accounts"] = accounts
        if make_active or not cfg.get("active_account_id") or len(accounts) == 1:
            cfg["active_account_id"] = account_id

        self._cached_creds = None
        return self._save_raw_config(cfg)

    def switch_account(self, identifier: str) -> dict[str, Any]:
        """Switch active GitHub account by account_id, username, or account_name."""
        target = identifier.strip().lower()
        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])

        matched = None
        for a in accounts:
            if (
                a.get("account_id", "").lower() == target
                or a.get("username", "").lower() == target
                or a.get("account_name", "").lower() == target
            ):
                matched = a
                break

        if not matched:
            return {"ok": False, "error": f"Account '{identifier}' not found in stored GitHub accounts."}

        cfg["active_account_id"] = matched["account_id"]
        self._cached_creds = None
        self._save_raw_config(cfg)
        return {
            "ok": True,
            "account_id": matched["account_id"],
            "account_name": matched.get("account_name", ""),
            "username": matched.get("username", ""),
        }

    def remove_account(self, identifier: str) -> dict[str, Any]:
        """Remove a stored GitHub account."""
        target = identifier.strip().lower()
        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])

        remaining = []
        removed = None
        for a in accounts:
            if (
                a.get("account_id", "").lower() == target
                or a.get("username", "").lower() == target
                or a.get("account_name", "").lower() == target
            ):
                removed = a
            else:
                remaining.append(a)

        if not removed:
            return {"ok": False, "error": f"Account '{identifier}' not found."}

        cfg["accounts"] = remaining
        if cfg.get("active_account_id") == removed.get("account_id"):
            cfg["active_account_id"] = remaining[0]["account_id"] if remaining else ""

        self._cached_creds = None
        self._save_raw_config(cfg)
        return {
            "ok": True,
            "removed_id": removed["account_id"],
            "removed_name": removed.get("account_name", ""),
            "remaining_count": len(remaining),
            "new_active_id": cfg.get("active_account_id", ""),
        }

    def clear_credentials(self) -> bool:
        """Clear all stored GitHub accounts."""
        self._cached_creds = None
        try:
            self.config_file.unlink(missing_ok=True)
            return True
        except OSError:
            return False

    # ── HTTP Request Helper ──────────────────────────────────────────────────

    def _get_token_and_error(self, override_token: str | None = None) -> tuple[str, dict[str, Any] | None]:
        """Resolve active token or return a structured diagnostic error if missing or vault-locked."""
        if override_token is not None:
            tok = override_token.strip()
            if tok:
                return tok, None
        creds = self.load_credentials()
        tok = creds.get("token", "")
        if tok:
            return tok, None
        if creds.get("vault_locked"):
            return "", {
                "ok": False,
                "error": "Credential vault is locked. Unlock Vault to access your GitHub token.",
                "cause_category": "vault_locked",
                "cause_key": "vault_locked",
                "cause_title": "Credential Vault Is Locked",
                "cause_explanation": "Your GitHub token is encrypted inside the Credential Vault and cannot be read until unlocked.",
                "cause_action": "Go to Settings → Credential Vault and enter your master password to unlock it.",
                "cause_title_ar": "الخزينة المشفرة مقفلة (Vault Locked)",
                "cause_explanation_ar": "رمز GitHub الخاص بك مشفر داخل خزينة الاعتمادات ولا يمكن استخدامه قبل فتح القفل.",
                "cause_action_ar": "انتقل إلى الإعدادات ← خزينة الاعتمادات وأدخل كلمة المرور الرئيسية لفتحها.",
                "dashboard_url": "",
            }
        return "", {
            "ok": False,
            "error": "GitHub Personal Access Token not configured",
            "cause_category": "missing_token",
            "cause_key": "missing_token",
            "cause_title": "GitHub API Token Not Configured",
            "cause_explanation": "A GitHub Personal Access Token is required to communicate with the GitHub API.",
            "cause_action": "Run 'laravel-dev gh auth' or connect your token via the GitHub section in the application UI.",
            "cause_title_ar": "لم يتم إدخال رمز GitHub API Token",
            "cause_explanation_ar": "التطبيق يحتاج إلى Personal Access Token للاتصال بحسابك في GitHub.",
            "cause_action_ar": "استخدم 'laravel-dev gh auth' أو اربط التوكن من خلال قسم GitHub بالواجهة.",
            "dashboard_url": "https://github.com/settings/tokens",
        }

    def _request(
        self,
        endpoint: str,
        method: str = "GET",
        data: dict[str, Any] | None = None,
        override_token: str | None = None,
        timeout: int = 15,
        accept: str = "application/vnd.github+json",
        raw_response: bool = False,
        use_cache: bool = False,
        extra_headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Perform an HTTP request to GitHub REST API v3 with ETag cache, pagination & diagnostics."""
        token, tok_err = self._get_token_and_error(override_token)
        if tok_err:
            return tok_err

        if endpoint.startswith("https://"):
            url = endpoint
        else:
            url = f"{GH_API_BASE}{endpoint}" if endpoint.startswith("/") else f"{GH_API_BASE}/{endpoint}"

        headers = {
            "Accept": accept,
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "Laravel-Dev-Tool/1.0",
        }
        if data is not None:
            headers["Content-Type"] = "application/json"
        if extra_headers:
            headers.update(extra_headers)

        account_id = self.get_active_account_id() if override_token is None else "_override"
        cache_key = f"{account_id}|{method}|{url}|{accept}"
        if method == "GET" and use_cache and cache_key in self._etag_cache:
            etag = self._etag_cache[cache_key][0]
            if etag:
                headers["If-None-Match"] = etag

        body_bytes = json.dumps(data).encode("utf-8") if data is not None else None
        req = urllib.request.Request(url, data=body_bytes, headers=headers, method=method)

        try:
            with _urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                if raw_response:
                    payload: Any = raw
                else:
                    payload = json.loads(raw) if raw.strip() else {}
                scopes_header = resp.headers.get("X-OAuth-Scopes", "")
                scopes = [s.strip() for s in scopes_header.split(",") if s.strip()]
                rate_limit = {
                    "limit": resp.headers.get("X-RateLimit-Limit", "5000"),
                    "remaining": resp.headers.get("X-RateLimit-Remaining", "5000"),
                    "reset": resp.headers.get("X-RateLimit-Reset", "0"),
                }
                if override_token is None:
                    self._last_rate_limit = (account_id, rate_limit)
                pagination = _parse_link_header(resp.headers.get("Link", ""))
                etag_val = resp.headers.get("ETag", "")
                if method == "GET" and use_cache and etag_val:
                    self._etag_cache[cache_key] = (etag_val, payload, scopes, rate_limit, pagination, time.time())
                return {
                    "ok": True,
                    "data": payload,
                    "scopes": scopes,
                    "rate_limit": rate_limit,
                    "pagination": pagination,
                }
        except urllib.error.HTTPError as e:
            try:
                if e.code == 304 and cache_key in self._etag_cache:
                    _, payload, scopes, rate_limit, pagination, _ = self._etag_cache[cache_key]
                    return {
                        "ok": True,
                        "data": payload,
                        "scopes": scopes,
                        "rate_limit": rate_limit,
                        "pagination": pagination,
                        "cached": True,
                    }
                raw = e.read().decode("utf-8", errors="replace")
            finally:
                try:
                    e.close()
                except Exception:
                    pass
            err_msg = f"HTTP {e.code}"
            err_code = 0
            try:
                parsed = json.loads(raw)
                err_msg = parsed.get("message") or err_msg
            except Exception:
                err_msg = f"{err_msg}: {raw[:200]}"

            username = self.load_credentials().get("username", "")
            diag = analyze_gh_error(
                error_message=err_msg,
                error_code=err_code,
                status_code=e.code,
                endpoint=endpoint,
                username=username,
            )

            return {
                "ok": False,
                "error": err_msg,
                "status_code": e.code,
                "cause_category": diag["category"],
                "cause_key": diag.get("key", "api_error"),
                "cause_title": diag["title"],
                "cause_explanation": diag["explanation"],
                "cause_action": diag["action"],
                "cause_title_ar": diag.get("title_ar", diag["title"]),
                "cause_explanation_ar": diag.get("explanation_ar", diag["explanation"]),
                "cause_action_ar": diag.get("action_ar", diag["action"]),
                "dashboard_url": diag["url"],
                "required_perm": diag.get("required_perm", ""),
            }
        except urllib.error.URLError as e:
            return {
                "ok": False,
                "error": f"Network connection failed: {e.reason}",
                "status_code": 0,
                "cause_category": "network_error",
                "cause_key": "network_error",
                "cause_title": "Unable to Connect to GitHub (Network Error)",
                "cause_explanation": "Could not connect to the Internet or reach api.github.com.",
                "cause_action": "Check your network connection and verify firewall allows connections to api.github.com.",
                "cause_title_ar": "تعذر الاتصال بخوادم GitHub (Network Error)",
                "cause_explanation_ar": "فشل الاتصال بالإنترنت أو تعذر الوصول إلى خوادم GitHub API.",
                "cause_action_ar": "تأكد من اتصال جهازك بالإنترنت وأن جدار الحماية لا يحظر الاتصال بـ api.github.com.",
                "dashboard_url": "https://www.githubstatus.com",
            }
        except Exception as e:
            return {
                "ok": False,
                "error": str(e),
                "cause_category": "unexpected_error",
                "cause_key": "unexpected_error",
                "cause_title": "Unexpected Error",
                "cause_explanation": str(e),
                "cause_action": "Retry the operation or inspect application logs.",
                "cause_title_ar": "خطأ غير متوقع",
                "cause_explanation_ar": str(e),
                "cause_action_ar": "أعد المحاولة أو تحقق من سجلات النظام.",
            }

    def _download_redirect_text(self, endpoint: str, max_bytes: int = 512_000, timeout: int = 20) -> dict[str, Any]:
        """Fetch raw text from a GitHub endpoint that redirects to a pre-signed blob URL (e.g., job logs)."""
        res = self._download_bytes(endpoint, max_bytes=max_bytes, timeout=timeout)
        if not res.get("ok"):
            return res
        return {"ok": True, "text": res["raw"].decode("utf-8", errors="replace"), "truncated": res["truncated"]}

    def _download_bytes(
        self, endpoint: str, max_bytes: int, timeout: int = 20, accept: str = "application/vnd.github+json"
    ) -> dict[str, Any]:
        """Fetch at most `max_bytes` of a file, without sending the token to another host."""
        token, tok_err = self._get_token_and_error()
        if tok_err:
            return tok_err
        url = f"{GH_API_BASE}{endpoint}" if endpoint.startswith("/") else f"{GH_API_BASE}/{endpoint}"
        headers = {
            "Accept": accept,
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "Laravel-Dev-Tool/1.0",
        }
        req = urllib.request.Request(url, headers=headers, method="GET")
        opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=_HTTPS_POOL.context()),
            _NoAuthRedirectHandler(),
        )
        try:
            with opener.open(req, timeout=timeout) as resp:
                raw_bytes = resp.read(max_bytes + 1)
                truncated = len(raw_bytes) > max_bytes
                if truncated:
                    raw_bytes = raw_bytes[:max_bytes]
                return {"ok": True, "raw": raw_bytes, "truncated": truncated}
        except urllib.error.HTTPError as e:
            with e:
                raw = e.read().decode("utf-8", errors="replace")
            return {"ok": False, "error": f"HTTP {e.code}: {raw[:200]}", "status_code": e.code}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def graphql(self, query: str, variables: dict[str, Any] | None = None, timeout: int = 20) -> dict[str, Any]:
        """Execute a GitHub GraphQL v4 query."""
        res = self._request("/graphql", method="POST", data={"query": query, "variables": variables or {}}, timeout=timeout)
        if not res.get("ok"):
            return res
        payload = res.get("data") or {}
        if isinstance(payload, dict) and payload.get("errors"):
            errs = payload["errors"]
            msg = "; ".join(str(e.get("message", e)) for e in errs if isinstance(e, dict)) or "GraphQL error"
            return {"ok": False, "error": msg, "errors": errs}
        return {"ok": True, "data": (payload.get("data") if isinstance(payload, dict) else payload)}

    # ── Token Verification & User Discovery ──────────────────────────────────

    def verify_token(self, token: str) -> dict[str, Any]:
        """Verify Personal Access Token against /user and return profile and scopes."""
        res = self._request("/user", method="GET", override_token=token)
        if not res.get("ok"):
            return {
                "ok": False,
                "valid": False,
                "error": res.get("error", "Token verification failed."),
                "status_code": res.get("status_code", 0),
                "cause_category": res.get("cause_category", "invalid_token"),
                "cause_key": res.get("cause_key", "invalid_token"),
                "cause_title": res.get("cause_title", "Invalid or Unauthorized GitHub API Token"),
                "cause_explanation": res.get("cause_explanation", "GitHub rejected this token."),
                "cause_action": res.get("cause_action", "Check your token permissions and generate a new token if needed."),
                "cause_title_ar": res.get("cause_title_ar", "رمز الـ API غير صالح"),
                "cause_explanation_ar": res.get("cause_explanation_ar", "رفضت GitHub هذا الرمز."),
                "cause_action_ar": res.get("cause_action_ar", "تأكد من صلاحيات الرمز وانسخه بشكل صحيح."),
                "dashboard_url": res.get("dashboard_url", "https://github.com/settings/tokens"),
                "required_perm": "repo, workflow, read:org",
            }

        data = res.get("data", {})
        scopes = res.get("scopes", [])
        return {
            "ok": True,
            "valid": True,
            "username": data.get("login", ""),
            "name": data.get("name", "") or data.get("login", ""),
            "avatar_url": data.get("avatar_url", ""),
            "email": data.get("email", ""),
            "bio": data.get("bio", ""),
            "public_repos": data.get("public_repos", 0),
            "total_private_repos": data.get("total_private_repos", 0),
            "followers": data.get("followers", 0),
            "following": data.get("following", 0),
            "plan": (data.get("plan") or {}).get("name", "free"),
            "scopes": scopes,
            "rate_limit": res.get("rate_limit", {}),
        }

    def get_status(self) -> dict[str, Any]:
        """Return the current authentication status and active account info."""
        creds = self.load_credentials()
        vault_locked = bool(creds.get("vault_locked"))
        has_token = bool(creds.get("token"))
        stored = self.list_stored_accounts()
        if not has_token:
            return {
                "configured": False,
                "vault_locked": vault_locked,
                "account_id": creds.get("account_id", "") if vault_locked else "",
                "username": creds.get("username", "") if vault_locked else "",
                "accounts": stored,
                "total_accounts": len(stored),
            }

        tok = creds.get("token", "")
        masked = creds.get("token_hint") or self._mask_token(tok)

        limit = self._last_rate_limit
        rate = limit[1] if limit and limit[0] == creds.get("account_id", "") else {}

        def _num(key: str) -> int | None:
            val = str(rate.get(key, ""))
            return int(val) if val.isdigit() else None

        return {
            "configured": True,
            "vault_locked": False,
            "rate_limit_remaining": _num("remaining"),
            "rate_limit_total": _num("limit"),
            "account_id": creds.get("account_id", ""),
            "account_name": creds.get("account_name", ""),
            "username": creds.get("username", ""),
            "avatar_url": creds.get("avatar_url", ""),
            "email": creds.get("email", ""),
            "scopes": creds.get("scopes", []),
            "token_masked": masked,
            "accounts": stored,
            "total_accounts": len(stored),
        }

    # ── Repositories Management ──────────────────────────────────────────────

    @staticmethod
    def _format_repo(r: dict[str, Any]) -> dict[str, Any]:
        """Normalize a GitHub repository payload into a consistent dict."""
        return {
            "id": r.get("id"),
            "name": r.get("name"),
            "full_name": r.get("full_name"),
            "owner": (r.get("owner") or {}).get("login"),
            "owner_avatar": (r.get("owner") or {}).get("avatar_url"),
            "private": r.get("private", False),
            "visibility": r.get("visibility") or ("private" if r.get("private") else "public"),
            "fork": r.get("fork", False),
            "archived": r.get("archived", False),
            "html_url": r.get("html_url"),
            "clone_url": r.get("clone_url"),
            "ssh_url": r.get("ssh_url"),
            "homepage": r.get("homepage") or "",
            "description": r.get("description") or "",
            "language": r.get("language") or "",
            "topics": r.get("topics") or [],
            "license": ((r.get("license") or {}).get("spdx_id") or (r.get("license") or {}).get("name") or ""),
            "default_branch": r.get("default_branch") or "main",
            "stargazers_count": r.get("stargazers_count", 0),
            "watchers_count": r.get("subscribers_count") if r.get("subscribers_count") is not None else r.get("watchers_count", 0),
            "forks_count": r.get("forks_count", 0),
            "open_issues_count": r.get("open_issues_count", 0),
            "has_issues": r.get("has_issues", True),
            "has_projects": r.get("has_projects", True),
            "has_wiki": r.get("has_wiki", False),
            "permissions": r.get("permissions") or {},
            "parent_full_name": ((r.get("parent") or {}).get("full_name") or ""),
            "updated_at": r.get("updated_at"),
            "pushed_at": r.get("pushed_at"),
            "created_at": r.get("created_at"),
        }

    def list_repos(
        self,
        visibility: str = "all",
        affiliation: str = "owner,collaborator,organization_member",
        sort: str = "updated",
        direction: str = "desc",
        page: int = 1,
        per_page: int = 50,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List repositories accessible to the active user (including org repos)."""
        qp: dict[str, Any] = {
            "visibility": visibility,
            "affiliation": affiliation,
            "sort": sort,
            "direction": direction,
            "page": page,
            "per_page": per_page,
        }
        params = urllib.parse.urlencode({k: v for k, v in qp.items() if v})
        res = self._request(f"/user/repos?{params}", method="GET", use_cache=True)
        if not res.get("ok"):
            return res

        repos = [self._format_repo(r) for r in (res.get("data") or []) if isinstance(r, dict)]
        out: dict[str, Any] = {
            "ok": True,
            "repos": repos,
            "page": page,
            "pagination": res.get("pagination", {}),
        }
        if res.get("cached"):
            out["cached"] = True
        return out

    def create_repo(
        self,
        name: str,
        description: str = "",
        private: bool = True,
        auto_init: bool = False,
        gitignore_template: str = "",
        license_template: str = "",
    ) -> dict[str, Any]:
        """Create a new GitHub repository."""
        data: dict[str, Any] = {
            "name": name.strip(),
            "description": description.strip(),
            "private": bool(private),
            "auto_init": bool(auto_init),
        }
        if gitignore_template:
            data["gitignore_template"] = gitignore_template
        if license_template:
            data["license_template"] = license_template

        res = self._request("/user/repos", method="POST", data=data)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {
            "ok": True,
            "name": d.get("name"),
            "full_name": d.get("full_name"),
            "html_url": d.get("html_url"),
            "clone_url": d.get("clone_url"),
            "ssh_url": d.get("ssh_url"),
            "default_branch": d.get("default_branch", "main"),
        }

    def delete_repo(self, owner_or_full_name: str, repo_name: str = "") -> dict[str, Any]:
        """Delete a GitHub repository."""
        if "/" in owner_or_full_name and not repo_name:
            owner, name = owner_or_full_name.split("/", 1)
        else:
            owner = owner_or_full_name
            name = repo_name

        return self._request(f"/repos/{owner.strip()}/{name.strip()}", method="DELETE")

    def get_repo(self, owner: str, repo: str) -> dict[str, Any]:
        """Get normalized + raw repository details."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}", method="GET", use_cache=True)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        if isinstance(d, dict):
            res["repo"] = self._format_repo(d)
        return res

    def list_branches(self, owner: str, repo: str, per_page: int = 100) -> dict[str, Any]:
        """List branches of a repository."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/branches?per_page={per_page}", method="GET")
        if not res.get("ok"):
            return res
        raw_list = [b for b in (res.get("data") or []) if isinstance(b, dict)]
        branches = [b.get("name") for b in raw_list if b.get("name")]
        branch_details = [
            {
                "name": b.get("name"),
                "protected": bool(b.get("protected")),
                "sha": (b.get("commit") or {}).get("sha", ""),
            }
            for b in raw_list
        ]
        return {"ok": True, "branches": branches, "branch_details": branch_details}

    def list_tags(self, owner: str, repo: str, page: int = 1, per_page: int = 30) -> dict[str, Any]:
        """List git tags for a repository."""
        o, r = _split_repo(owner, repo)
        params = urllib.parse.urlencode({"page": page, "per_page": per_page})
        res = self._request(f"/repos/{o}/{r}/tags?{params}", method="GET")
        if not res.get("ok"):
            return res
        tags = [
            {
                "name": t.get("name"),
                "sha": (t.get("commit") or {}).get("sha", ""),
                "tarball_url": t.get("tarball_url"),
                "zipball_url": t.get("zipball_url"),
            }
            for t in (res.get("data") or [])
            if isinstance(t, dict)
        ]
        return {"ok": True, "tags": tags, "pagination": res.get("pagination", {})}

    def get_repo_languages(self, owner: str, repo: str) -> dict[str, Any]:
        """Return language breakdown bytes for a repository."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/languages", method="GET", use_cache=True)
        if not res.get("ok"):
            return res
        langs = res.get("data") if isinstance(res.get("data"), dict) else {}
        total = sum(v for v in langs.values() if isinstance(v, (int, float))) or 1
        breakdown = [
            {"name": k, "bytes": v, "pct": round((v / total) * 100, 1)}
            for k, v in langs.items()
            if isinstance(v, (int, float))
        ]
        out: dict[str, Any] = {"ok": True, "languages": langs, "breakdown": breakdown}
        if res.get("cached"):
            out["cached"] = True
        return out

    def get_repo_contents(
        self,
        owner: str,
        repo: str,
        path: str = "",
        ref: str = "",
    ) -> dict[str, Any]:
        """Browse a repository directory or read a file via Contents API."""
        o, r = _split_repo(owner, repo)
        enc_path = _encode_repo_path(path)
        ep = f"/repos/{o}/{r}/contents/{enc_path}" if enc_path else f"/repos/{o}/{r}/contents"
        if ref:
            ep += f"?{urllib.parse.urlencode({'ref': ref.strip()})}"
        res = self._request(ep, method="GET")
        if not res.get("ok"):
            return res
        data = res.get("data")
        if isinstance(data, list):
            entries = [
                {
                    "name": e.get("name"),
                    "path": e.get("path"),
                    "type": e.get("type"),  # "dir", "file", "symlink", "submodule"
                    "size": e.get("size", 0),
                    "sha": e.get("sha"),
                    "html_url": e.get("html_url"),
                    "download_url": e.get("download_url"),
                }
                for e in data
                if isinstance(e, dict)
            ]
            entries.sort(key=lambda e: (0 if e["type"] == "dir" else 1, (e["name"] or "").lower()))
            return {"ok": True, "kind": "dir", "path": path.strip("/"), "entries": entries}

        if isinstance(data, dict):
            raw_b64 = data.get("content", "") or ""
            encoding = data.get("encoding", "")
            text = ""
            is_binary = False
            if encoding == "base64" and raw_b64:
                try:
                    raw_bytes = base64.b64decode(raw_b64)
                    if b"\x00" in raw_bytes[:4096]:
                        is_binary = True
                    else:
                        text = raw_bytes.decode("utf-8", errors="replace")
                except Exception:
                    is_binary = True
            fname = data.get("name", "")
            is_markdown = fname.lower().endswith((".md", ".markdown", ".mdx"))
            return {
                "ok": True,
                "kind": "file",
                "name": fname,
                "path": data.get("path", path),
                "sha": data.get("sha", ""),
                "size": data.get("size", 0),
                "encoding": encoding,
                "content": text,
                "is_binary": is_binary,
                "is_markdown": is_markdown,
                "html_url": data.get("html_url", ""),
                "download_url": data.get("download_url", ""),
            }
        return {"ok": True, "kind": "unknown", "data": data}

    MAX_IMAGE_BYTES = 8 * 1024 * 1024

    def get_repo_image(self, owner: str, repo: str, path: str, ref: str = "") -> dict[str, Any]:
        """One image of a repository as a data: URI. Works for private repositories too."""
        o, r = _split_repo(owner, repo)
        enc_path = _encode_repo_path(path)
        if not enc_path:
            return {"ok": False, "error": "File path is required."}
        ep = f"/repos/{o}/{r}/contents/{enc_path}"
        if ref.strip():
            ep += f"?{urllib.parse.urlencode({'ref': ref.strip()})}"
        res = self._download_bytes(ep, max_bytes=self.MAX_IMAGE_BYTES, accept="application/vnd.github.raw+json")
        if not res.get("ok"):
            return res
        if res["truncated"]:
            return {"ok": False, "error": "This image is too large to show (over 8 MB)."}
        mime = _image_mime(res["raw"])
        if not mime:
            return {"ok": False, "error": "This file is not an image."}
        data = base64.b64encode(res["raw"]).decode("ascii")
        return {"ok": True, "path": path, "mime": mime, "size": len(res["raw"]), "data_uri": f"data:{mime};base64,{data}"}

    def get_repo_readme(self, owner: str, repo: str, ref: str = "", render_html: bool = True) -> dict[str, Any]:
        """Fetch repository README metadata, raw text, and optional GitHub-rendered HTML."""
        o, r = _split_repo(owner, repo)
        ep = f"/repos/{o}/{r}/readme"
        if ref:
            ep += f"?{urllib.parse.urlencode({'ref': ref.strip()})}"
        res = self._request(ep, method="GET")
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        raw_text = ""
        if d.get("encoding") == "base64" and d.get("content"):
            try:
                raw_text = base64.b64decode(d["content"]).decode("utf-8", errors="replace")
            except Exception:
                raw_text = ""
        html = ""
        if render_html and raw_text:
            rendered = self.render_markdown(raw_text, context_repo=f"{o}/{r}")
            if rendered.get("ok"):
                html = rendered.get("html", "")
        return {
            "ok": True,
            "name": d.get("name", "README.md"),
            "path": d.get("path", "README.md"),
            "sha": d.get("sha", ""),
            "html_url": d.get("html_url", ""),
            "content": raw_text,
            "html": html,
        }

    def get_repo_tree(self, owner: str, repo: str, ref: str = "main", recursive: bool = True) -> dict[str, Any]:
        """Fetch the full repository Git tree for fast tree navigation and quick file finding."""
        o, r = _split_repo(owner, repo)
        tree_ref = urllib.parse.quote(ref.strip() or "main", safe="")
        q = "?recursive=1" if recursive else ""
        res = self._request(f"/repos/{o}/{r}/git/trees/{tree_ref}{q}", method="GET", use_cache=True)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        items = [
            {
                "path": item.get("path"),
                "type": item.get("type"),  # "blob" or "tree"
                "size": item.get("size", 0),
                "sha": item.get("sha"),
            }
            for item in (d.get("tree") or [])
            if isinstance(item, dict)
        ]
        out: dict[str, Any] = {"ok": True, "sha": d.get("sha"), "truncated": bool(d.get("truncated")), "tree": items}
        if res.get("cached"):
            out["cached"] = True
        return out

    def render_markdown(self, text: str, context_repo: str = "", mode: str = "gfm") -> dict[str, Any]:
        """Render GitHub Flavored Markdown into HTML via GitHub Markdown API."""
        payload: dict[str, Any] = {"text": text or "", "mode": mode}
        if context_repo and "/" in context_repo:
            payload["context"] = context_repo.strip()
        res = self._request(
            "/markdown",
            method="POST",
            data=payload,
            accept="text/html",
            raw_response=True,
        )
        if not res.get("ok"):
            return res
        return {"ok": True, "html": res.get("data", "")}

    def update_or_create_file(
        self,
        owner: str,
        repo: str,
        path: str,
        content: str,
        message: str,
        branch: str = "",
        sha: str = "",
    ) -> dict[str, Any]:
        """Create or update a file inside a repository via GitHub Contents API."""
        o, r = _split_repo(owner, repo)
        enc_path = _encode_repo_path(path)
        if not enc_path:
            return {"ok": False, "error": "File path is required."}
        if not message.strip():
            return {"ok": False, "error": "Commit message is required."}
        b64 = base64.b64encode((content or "").encode("utf-8")).decode("ascii")
        data: dict[str, Any] = {
            "message": message.strip(),
            "content": b64,
        }
        if branch.strip():
            data["branch"] = branch.strip()
        if sha.strip():
            data["sha"] = sha.strip()
        res = self._request(f"/repos/{o}/{r}/contents/{enc_path}", method="PUT", data=data)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        content_meta = d.get("content") or {}
        commit_meta = d.get("commit") or {}
        return {
            "ok": True,
            "path": content_meta.get("path", path),
            "sha": content_meta.get("sha", ""),
            "commit_sha": commit_meta.get("sha", ""),
            "html_url": content_meta.get("html_url", ""),
        }

    def delete_file(
        self,
        owner: str,
        repo: str,
        path: str,
        message: str,
        sha: str,
        branch: str = "",
    ) -> dict[str, Any]:
        """Delete a file from a repository via GitHub Contents API."""
        o, r = _split_repo(owner, repo)
        enc_path = _encode_repo_path(path)
        if not enc_path or not sha.strip():
            return {"ok": False, "error": "Both file path and current blob SHA are required."}
        data: dict[str, Any] = {
            "message": (message or f"Delete {path}").strip(),
            "sha": sha.strip(),
        }
        if branch.strip():
            data["branch"] = branch.strip()
        res = self._request(f"/repos/{o}/{r}/contents/{enc_path}", method="DELETE", data=data)
        if not res.get("ok"):
            return res
        commit_meta = (res.get("data") or {}).get("commit") or {}
        return {"ok": True, "commit_sha": commit_meta.get("sha", "")}

    @staticmethod
    def _format_commit(c: dict[str, Any]) -> dict[str, Any]:
        commit_obj = c.get("commit") or {}
        author_meta = commit_obj.get("author") or {}
        gh_author = c.get("author") or {}
        msg = commit_obj.get("message") or ""
        return {
            "sha": c.get("sha"),
            "short_sha": (c.get("sha") or "")[:7],
            "message": msg,
            "headline": msg.splitlines()[0] if msg else "",
            "author_name": author_meta.get("name") or gh_author.get("login") or "",
            "author_login": gh_author.get("login") or "",
            "author_avatar": gh_author.get("avatar_url") or "",
            "date": author_meta.get("date") or "",
            "html_url": c.get("html_url") or "",
        }

    @staticmethod
    def _format_diff_files(files: list[Any]) -> list[dict[str, Any]]:
        out = []
        for f in (files or []):
            if not isinstance(f, dict):
                continue
            out.append({
                "filename": f.get("filename"),
                "previous_filename": f.get("previous_filename", ""),
                "status": f.get("status"),
                "additions": f.get("additions", 0),
                "deletions": f.get("deletions", 0),
                "changes": f.get("changes", 0),
                "patch": f.get("patch") or "",
                "blob_url": f.get("blob_url") or "",
            })
        return out

    def list_commits(
        self,
        owner: str,
        repo: str,
        sha: str = "",
        path: str = "",
        page: int = 1,
        per_page: int = 30,
    ) -> dict[str, Any]:
        """List commit history for a repository branch/ref or file path."""
        o, r = _split_repo(owner, repo)
        qp: dict[str, Any] = {"page": page, "per_page": per_page}
        if sha.strip():
            qp["sha"] = sha.strip()
        if path.strip():
            qp["path"] = path.strip()
        params = urllib.parse.urlencode(qp)
        res = self._request(f"/repos/{o}/{r}/commits?{params}", method="GET")
        if not res.get("ok"):
            return res
        commits = [self._format_commit(c) for c in (res.get("data") or []) if isinstance(c, dict)]
        return {"ok": True, "commits": commits, "page": page, "pagination": res.get("pagination", {})}

    def get_commit_detail(self, owner: str, repo: str, sha: str) -> dict[str, Any]:
        """Fetch full commit metadata, stats, and file diffs."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/commits/{urllib.parse.quote(sha.strip(), safe='')}", method="GET")
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        summary = self._format_commit(d)
        summary["stats"] = d.get("stats") or {}
        summary["parents"] = [(p.get("sha") or "")[:7] for p in (d.get("parents") or []) if isinstance(p, dict)]
        summary["files"] = self._format_diff_files(d.get("files") or [])
        return {"ok": True, "commit": summary}

    def compare_refs(self, owner: str, repo: str, base: str, head: str) -> dict[str, Any]:
        """Compare two refs/branches/SHAs (base...head)."""
        o, r = _split_repo(owner, repo)
        b = urllib.parse.quote(base.strip(), safe="")
        h = urllib.parse.quote(head.strip(), safe="")
        res = self._request(f"/repos/{o}/{r}/compare/{b}...{h}", method="GET")
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        commits = [self._format_commit(c) for c in (d.get("commits") or []) if isinstance(c, dict)]
        return {
            "ok": True,
            "status": d.get("status"),
            "ahead_by": d.get("ahead_by", 0),
            "behind_by": d.get("behind_by", 0),
            "total_commits": d.get("total_commits", len(commits)),
            "html_url": d.get("html_url", ""),
            "commits": commits,
            "files": self._format_diff_files(d.get("files") or []),
        }

    def list_releases(self, owner: str, repo: str, page: int = 1, per_page: int = 20) -> dict[str, Any]:
        """List releases for a repository."""
        o, r = _split_repo(owner, repo)
        params = urllib.parse.urlencode({"page": page, "per_page": per_page})
        res = self._request(f"/repos/{o}/{r}/releases?{params}", method="GET")
        if not res.get("ok"):
            return res
        releases = []
        for rel in (res.get("data") or []):
            if not isinstance(rel, dict):
                continue
            releases.append({
                "id": rel.get("id"),
                "tag_name": rel.get("tag_name"),
                "name": rel.get("name") or rel.get("tag_name"),
                "body": rel.get("body") or "",
                "draft": bool(rel.get("draft")),
                "prerelease": bool(rel.get("prerelease")),
                "target_commitish": rel.get("target_commitish") or "",
                "author": (rel.get("author") or {}).get("login") or "",
                "author_avatar": (rel.get("author") or {}).get("avatar_url") or "",
                "html_url": rel.get("html_url") or "",
                "published_at": rel.get("published_at") or rel.get("created_at") or "",
                "assets": [
                    {
                        "id": a.get("id"),
                        "name": a.get("name"),
                        "size": a.get("size", 0),
                        "download_count": a.get("download_count", 0),
                        "browser_download_url": a.get("browser_download_url"),
                    }
                    for a in (rel.get("assets") or [])
                    if isinstance(a, dict)
                ],
            })
        return {"ok": True, "releases": releases, "pagination": res.get("pagination", {})}

    def create_release(
        self,
        owner: str,
        repo: str,
        tag_name: str,
        name: str = "",
        body: str = "",
        draft: bool = False,
        prerelease: bool = False,
        target_commitish: str = "",
        generate_release_notes: bool = True,
    ) -> dict[str, Any]:
        """Create a GitHub release."""
        o, r = _split_repo(owner, repo)
        data: dict[str, Any] = {
            "tag_name": tag_name.strip(),
            "name": (name or tag_name).strip(),
            "body": body.strip(),
            "draft": bool(draft),
            "prerelease": bool(prerelease),
            "generate_release_notes": bool(generate_release_notes and not body.strip()),
        }
        if target_commitish.strip():
            data["target_commitish"] = target_commitish.strip()
        res = self._request(f"/repos/{o}/{r}/releases", method="POST", data=data)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {"ok": True, "id": d.get("id"), "tag_name": d.get("tag_name"), "html_url": d.get("html_url")}

    def delete_release(self, owner: str, repo: str, release_id: int) -> dict[str, Any]:
        """Delete a GitHub release by ID."""
        o, r = _split_repo(owner, repo)
        return self._request(f"/repos/{o}/{r}/releases/{int(release_id)}", method="DELETE")

    def list_contributors(self, owner: str, repo: str, per_page: int = 30) -> dict[str, Any]:
        """List top contributors for a repository."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/contributors?per_page={per_page}", method="GET")
        if not res.get("ok"):
            return res
        contributors = [
            {
                "login": c.get("login"),
                "avatar_url": c.get("avatar_url"),
                "html_url": c.get("html_url"),
                "contributions": c.get("contributions", 0),
            }
            for c in (res.get("data") or [])
            if isinstance(c, dict)
        ]
        return {"ok": True, "contributors": contributors}

    def is_repo_starred(self, owner: str, repo: str) -> dict[str, Any]:
        """Check if the active user has starred a repository (204 = True, 404 = False)."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/user/starred/{o}/{r}", method="GET")
        if res.get("ok"):
            return {"ok": True, "starred": True}
        if res.get("status_code") == 404:
            return {"ok": True, "starred": False}
        return res

    def star_repo(self, owner: str, repo: str) -> dict[str, Any]:
        """Star a repository."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/user/starred/{o}/{r}", method="PUT")
        if res.get("ok"):
            return {"ok": True, "starred": True}
        return res

    def unstar_repo(self, owner: str, repo: str) -> dict[str, Any]:
        """Unstar a repository."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/user/starred/{o}/{r}", method="DELETE")
        if res.get("ok"):
            return {"ok": True, "starred": False}
        return res

    def fork_repo(self, owner: str, repo: str, organization: str = "") -> dict[str, Any]:
        """Fork a repository into the active user's account or an organization."""
        o, r = _split_repo(owner, repo)
        data: dict[str, Any] = {}
        if organization.strip():
            data["organization"] = organization.strip()
        res = self._request(f"/repos/{o}/{r}/forks", method="POST", data=data)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {"ok": True, "repo": self._format_repo(d) if isinstance(d, dict) else d}

    def update_repo_settings(self, owner: str, repo: str, updates: dict[str, Any]) -> dict[str, Any]:
        """Update repository settings (name, description, homepage, private, archived, default_branch, features)."""
        o, r = _split_repo(owner, repo)
        allowed = {
            "name", "description", "homepage", "private", "visibility",
            "default_branch", "has_issues", "has_projects", "has_wiki",
            "archived", "allow_squash_merge", "allow_merge_commit", "allow_rebase_merge",
        }
        payload = {k: v for k, v in (updates or {}).items() if k in allowed}
        if not payload:
            return {"ok": False, "error": "No valid repository fields to update."}
        res = self._request(f"/repos/{o}/{r}", method="PATCH", data=payload)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {"ok": True, "repo": self._format_repo(d) if isinstance(d, dict) else d}

    def list_repo_webhooks(self, owner: str, repo: str) -> dict[str, Any]:
        """List repository webhooks."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/hooks?per_page=50", method="GET")
        if not res.get("ok"):
            return res
        hooks = [
            {
                "id": h.get("id"),
                "name": h.get("name"),
                "active": bool(h.get("active")),
                "events": h.get("events") or [],
                "url": (h.get("config") or {}).get("url") or "",
                "content_type": (h.get("config") or {}).get("content_type") or "json",
                "updated_at": h.get("updated_at") or "",
            }
            for h in (res.get("data") or [])
            if isinstance(h, dict)
        ]
        return {"ok": True, "hooks": hooks}

    def create_repo_webhook(
        self,
        owner: str,
        repo: str,
        url: str,
        events: list[str] | None = None,
        secret: str = "",
        active: bool = True,
    ) -> dict[str, Any]:
        """Create a repository webhook."""
        o, r = _split_repo(owner, repo)
        config: dict[str, Any] = {"url": url.strip(), "content_type": "json", "insecure_ssl": "0"}
        if secret:
            config["secret"] = secret
        data = {
            "name": "web",
            "active": bool(active),
            "events": events or ["push"],
            "config": config,
        }
        res = self._request(f"/repos/{o}/{r}/hooks", method="POST", data=data)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {"ok": True, "id": d.get("id"), "url": (d.get("config") or {}).get("url", url)}

    def delete_repo_webhook(self, owner: str, repo: str, hook_id: int) -> dict[str, Any]:
        """Delete a repository webhook."""
        o, r = _split_repo(owner, repo)
        return self._request(f"/repos/{o}/{r}/hooks/{int(hook_id)}", method="DELETE")

    def list_collaborators(self, owner: str, repo: str, per_page: int = 50) -> dict[str, Any]:
        """List repository collaborators."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/collaborators?per_page={per_page}", method="GET")
        if not res.get("ok"):
            return res
        collabs = [
            {
                "login": c.get("login"),
                "avatar_url": c.get("avatar_url"),
                "html_url": c.get("html_url"),
                "role_name": c.get("role_name") or "",
                "permissions": c.get("permissions") or {},
            }
            for c in (res.get("data") or [])
            if isinstance(c, dict)
        ]
        return {"ok": True, "collaborators": collabs}

    def list_dependabot_alerts(self, owner: str, repo: str, state: str = "open", per_page: int = 30) -> dict[str, Any]:
        """List Dependabot security alerts for a repository."""
        o, r = _split_repo(owner, repo)
        params = urllib.parse.urlencode({"state": state, "per_page": per_page})
        res = self._request(f"/repos/{o}/{r}/dependabot/alerts?{params}", method="GET")
        if not res.get("ok"):
            return res
        alerts = []
        for a in (res.get("data") or []):
            if not isinstance(a, dict):
                continue
            adv = a.get("security_advisory") or {}
            dep = a.get("dependency") or {}
            pkg = dep.get("package") or {}
            alerts.append({
                "number": a.get("number"),
                "state": a.get("state"),
                "severity": adv.get("severity") or (a.get("security_vulnerability") or {}).get("severity") or "unknown",
                "summary": adv.get("summary") or "",
                "cve_id": adv.get("cve_id") or "",
                "ghsa_id": adv.get("ghsa_id") or "",
                "package_name": pkg.get("name") or "",
                "ecosystem": pkg.get("ecosystem") or "",
                "manifest_path": dep.get("manifest_path") or "",
                "html_url": a.get("html_url") or "",
                "created_at": a.get("created_at") or "",
            })
        return {"ok": True, "alerts": alerts}

    # ── Pull Requests Management ─────────────────────────────────────────────

    def list_pulls(
        self,
        owner: str,
        repo: str,
        state: str = "open",
        page: int = 1,
        per_page: int = 30,
    ) -> dict[str, Any]:
        """List pull requests for a repository."""
        params = urllib.parse.urlencode({"state": state, "page": page, "per_page": per_page})
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/pulls?{params}", method="GET")
        if not res.get("ok"):
            return res

        pulls = []
        for p in (res.get("data") or []):
            if isinstance(p, dict):
                pulls.append({
                    "id": p.get("id"),
                    "number": p.get("number"),
                    "title": p.get("title"),
                    "state": p.get("state"),
                    "user": (p.get("user") or {}).get("login"),
                    "user_avatar": (p.get("user") or {}).get("avatar_url"),
                    "html_url": p.get("html_url"),
                    "head": (p.get("head") or {}).get("ref"),
                    "base": (p.get("base") or {}).get("ref"),
                    "created_at": p.get("created_at"),
                    "updated_at": p.get("updated_at"),
                    "draft": p.get("draft", False),
                })
        return {"ok": True, "pulls": pulls, "page": page}

    def create_pull(
        self,
        owner: str,
        repo: str,
        title: str,
        head: str,
        base: str = "main",
        body: str = "",
    ) -> dict[str, Any]:
        """Create a new pull request."""
        data = {
            "title": title.strip(),
            "head": head.strip(),
            "base": base.strip(),
            "body": body.strip(),
        }
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/pulls", method="POST", data=data)
        if not res.get("ok"):
            return res
        p = res.get("data") or {}
        return {
            "ok": True,
            "number": p.get("number"),
            "title": p.get("title"),
            "html_url": p.get("html_url"),
        }

    def merge_pull(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        merge_method: str = "merge",
        commit_title: str = "",
        commit_message: str = "",
    ) -> dict[str, Any]:
        """Merge a pull request ('merge', 'squash', or 'rebase')."""
        data: dict[str, Any] = {"merge_method": merge_method}
        if commit_title:
            data["commit_title"] = commit_title
        if commit_message:
            data["commit_message"] = commit_message

        res = self._request(
            f"/repos/{owner.strip()}/{repo.strip()}/pulls/{pull_number}/merge",
            method="PUT",
            data=data,
        )
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {
            "ok": True,
            "sha": d.get("sha"),
            "merged": d.get("merged", True),
            "message": d.get("message", "Pull request merged"),
        }

    def close_pull(self, owner: str, repo: str, pull_number: int) -> dict[str, Any]:
        """Close a pull request."""
        return self._request(
            f"/repos/{owner.strip()}/{repo.strip()}/pulls/{pull_number}",
            method="PATCH",
            data={"state": "closed"},
        )

    def get_pull_detail(self, owner: str, repo: str, pull_number: int) -> dict[str, Any]:
        """Get full details for a single pull request."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/pulls/{int(pull_number)}", method="GET")
        if not res.get("ok"):
            return res
        p = res.get("data") or {}
        labels = [
            {"name": lb.get("name"), "color": lb.get("color", "")}
            for lb in (p.get("labels") or [])
            if isinstance(lb, dict)
        ]
        head_obj = p.get("head") or {}
        base_obj = p.get("base") or {}
        return {
            "ok": True,
            "pull": {
                "id": p.get("id"),
                "number": p.get("number"),
                "title": p.get("title"),
                "body": p.get("body") or "",
                "state": p.get("state"),
                "merged": bool(p.get("merged")),
                "mergeable": p.get("mergeable"),
                "mergeable_state": p.get("mergeable_state") or "",
                "draft": bool(p.get("draft")),
                "user": (p.get("user") or {}).get("login"),
                "user_avatar": (p.get("user") or {}).get("avatar_url"),
                "html_url": p.get("html_url"),
                "head": head_obj.get("ref"),
                "head_sha": head_obj.get("sha"),
                "head_repo": (head_obj.get("repo") or {}).get("full_name"),
                "base": base_obj.get("ref"),
                "base_sha": base_obj.get("sha"),
                "commits_count": p.get("commits", 0),
                "additions": p.get("additions", 0),
                "deletions": p.get("deletions", 0),
                "changed_files": p.get("changed_files", 0),
                "comments": p.get("comments", 0),
                "review_comments": p.get("review_comments", 0),
                "labels": labels,
                "assignees": [a.get("login") for a in (p.get("assignees") or []) if isinstance(a, dict)],
                "requested_reviewers": [
                    rv.get("login") for rv in (p.get("requested_reviewers") or []) if isinstance(rv, dict)
                ],
                "created_at": p.get("created_at"),
                "updated_at": p.get("updated_at"),
                "merged_at": p.get("merged_at"),
                "merged_by": (p.get("merged_by") or {}).get("login"),
            },
        }

    def list_pull_commits(self, owner: str, repo: str, pull_number: int, page: int = 1, per_page: int = 50) -> dict[str, Any]:
        """List commits inside a pull request."""
        o, r = _split_repo(owner, repo)
        params = urllib.parse.urlencode({"page": page, "per_page": per_page})
        res = self._request(f"/repos/{o}/{r}/pulls/{int(pull_number)}/commits?{params}", method="GET")
        if not res.get("ok"):
            return res
        commits = [self._format_commit(c) for c in (res.get("data") or []) if isinstance(c, dict)]
        return {"ok": True, "commits": commits, "pagination": res.get("pagination", {})}

    def list_pull_files(self, owner: str, repo: str, pull_number: int, page: int = 1, per_page: int = 100) -> dict[str, Any]:
        """List changed files and patch diffs for a pull request."""
        o, r = _split_repo(owner, repo)
        params = urllib.parse.urlencode({"page": page, "per_page": per_page})
        res = self._request(f"/repos/{o}/{r}/pulls/{int(pull_number)}/files?{params}", method="GET")
        if not res.get("ok"):
            return res
        return {
            "ok": True,
            "files": self._format_diff_files(res.get("data") or []),
            "pagination": res.get("pagination", {}),
        }

    def list_pull_reviews(self, owner: str, repo: str, pull_number: int) -> dict[str, Any]:
        """List reviews on a pull request."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/pulls/{int(pull_number)}/reviews?per_page=50", method="GET")
        if not res.get("ok"):
            return res
        reviews = [
            {
                "id": rv.get("id"),
                "user": (rv.get("user") or {}).get("login"),
                "user_avatar": (rv.get("user") or {}).get("avatar_url"),
                "state": rv.get("state"),
                "body": rv.get("body") or "",
                "submitted_at": rv.get("submitted_at") or "",
                "html_url": rv.get("html_url") or "",
            }
            for rv in (res.get("data") or [])
            if isinstance(rv, dict)
        ]
        return {"ok": True, "reviews": reviews}

    def create_pull_review(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        event: str = "COMMENT",
        body: str = "",
        comments: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Submit a pull request review ('APPROVE', 'REQUEST_CHANGES', or 'COMMENT')."""
        o, r = _split_repo(owner, repo)
        norm_event = (event or "COMMENT").strip().upper()
        if norm_event not in ("APPROVE", "REQUEST_CHANGES", "COMMENT"):
            norm_event = "COMMENT"
        data: dict[str, Any] = {"event": norm_event}
        if body.strip():
            data["body"] = body.strip()
        if comments:
            data["comments"] = comments
        res = self._request(f"/repos/{o}/{r}/pulls/{int(pull_number)}/reviews", method="POST", data=data)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {"ok": True, "id": d.get("id"), "state": d.get("state"), "html_url": d.get("html_url")}

    def update_pull_branch(self, owner: str, repo: str, pull_number: int, expected_head_sha: str = "") -> dict[str, Any]:
        """Update a pull request branch with latest base branch changes."""
        o, r = _split_repo(owner, repo)
        data: dict[str, Any] = {}
        if expected_head_sha.strip():
            data["expected_head_sha"] = expected_head_sha.strip()
        return self._request(
            f"/repos/{o}/{r}/pulls/{int(pull_number)}/update-branch",
            method="PUT",
            data=data or None,
        )

    def list_check_runs(self, owner: str, repo: str, ref: str) -> dict[str, Any]:
        """List CI check runs for a commit SHA or branch ref."""
        o, r = _split_repo(owner, repo)
        safe_ref = urllib.parse.quote(ref.strip(), safe="")
        res = self._request(f"/repos/{o}/{r}/commits/{safe_ref}/check-runs?per_page=50", method="GET")
        if not res.get("ok"):
            return res
        runs = [
            {
                "id": cr.get("id"),
                "name": cr.get("name"),
                "status": cr.get("status"),
                "conclusion": cr.get("conclusion"),
                "html_url": cr.get("html_url"),
                "app_name": ((cr.get("app") or {}).get("name") or ""),
                "started_at": cr.get("started_at"),
                "completed_at": cr.get("completed_at"),
            }
            for cr in ((res.get("data") or {}).get("check_runs") or [])
            if isinstance(cr, dict)
        ]
        return {"ok": True, "check_runs": runs, "total_count": (res.get("data") or {}).get("total_count", len(runs))}

    # ── Issues Management ────────────────────────────────────────────────────

    def list_issues(
        self,
        owner: str,
        repo: str,
        state: str = "open",
        page: int = 1,
        per_page: int = 30,
    ) -> dict[str, Any]:
        """List issues for a repository."""
        params = urllib.parse.urlencode({"state": state, "page": page, "per_page": per_page})
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/issues?{params}", method="GET")
        if not res.get("ok"):
            return res

        issues = []
        for i in (res.get("data") or []):
            if isinstance(i, dict) and "pull_request" not in i:  # Filter out PRs
                labels = [l.get("name") for l in i.get("labels", []) if isinstance(l, dict)]
                issues.append({
                    "id": i.get("id"),
                    "number": i.get("number"),
                    "title": i.get("title"),
                    "state": i.get("state"),
                    "user": (i.get("user") or {}).get("login"),
                    "user_avatar": (i.get("user") or {}).get("avatar_url"),
                    "html_url": i.get("html_url"),
                    "labels": labels,
                    "comments": i.get("comments", 0),
                    "created_at": i.get("created_at"),
                    "updated_at": i.get("updated_at"),
                })
        return {"ok": True, "issues": issues, "page": page}

    def create_issue(
        self,
        owner: str,
        repo: str,
        title: str,
        body: str = "",
        labels: list[str] | None = None,
        assignees: list[str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a new issue."""
        data: dict[str, Any] = {
            "title": title.strip(),
            "body": body.strip(),
        }
        if labels:
            data["labels"] = labels
        if assignees:
            data["assignees"] = assignees

        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/issues", method="POST", data=data)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {
            "ok": True,
            "number": d.get("number"),
            "title": d.get("title"),
            "html_url": d.get("html_url"),
        }

    def close_issue(
        self,
        owner: str,
        repo: str,
        issue_number: int,
        state: str = "closed",
        state_reason: str = "completed",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Close or reopen an issue."""
        target_state = "open" if str(state).strip().lower() == "open" else "closed"
        data: dict[str, Any] = {"state": target_state}
        if target_state == "closed" and state_reason:
            data["state_reason"] = state_reason
        elif target_state == "open" and kwargs.get("state_reason") == "reopened":
            data["state_reason"] = "reopened"
        return self._request(
            f"/repos/{owner.strip()}/{repo.strip()}/issues/{issue_number}",
            method="PATCH",
            data=data,
        )

    def get_issue_detail(self, owner: str, repo: str, issue_number: int) -> dict[str, Any]:
        """Get full details for a single issue (works on PR issue metadata too)."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/issues/{int(issue_number)}", method="GET")
        if not res.get("ok"):
            return res
        i = res.get("data") or {}
        labels = [
            {"name": lb.get("name"), "color": lb.get("color", "")}
            for lb in (i.get("labels") or [])
            if isinstance(lb, dict)
        ]
        return {
            "ok": True,
            "issue": {
                "id": i.get("id"),
                "number": i.get("number"),
                "title": i.get("title"),
                "body": i.get("body") or "",
                "state": i.get("state"),
                "state_reason": i.get("state_reason") or "",
                "user": (i.get("user") or {}).get("login"),
                "user_avatar": (i.get("user") or {}).get("avatar_url"),
                "html_url": i.get("html_url"),
                "labels": labels,
                "assignees": [a.get("login") for a in (i.get("assignees") or []) if isinstance(a, dict)],
                "milestone": (i.get("milestone") or {}).get("title") or "",
                "comments": i.get("comments", 0),
                "locked": bool(i.get("locked")),
                "created_at": i.get("created_at"),
                "updated_at": i.get("updated_at"),
                "closed_at": i.get("closed_at"),
            },
        }

    def list_issue_comments(self, owner: str, repo: str, issue_number: int, page: int = 1, per_page: int = 50) -> dict[str, Any]:
        """List comments on an issue or pull request conversation."""
        o, r = _split_repo(owner, repo)
        params = urllib.parse.urlencode({"page": page, "per_page": per_page})
        res = self._request(f"/repos/{o}/{r}/issues/{int(issue_number)}/comments?{params}", method="GET")
        if not res.get("ok"):
            return res
        comments = [
            {
                "id": c.get("id"),
                "user": (c.get("user") or {}).get("login"),
                "user_avatar": (c.get("user") or {}).get("avatar_url"),
                "author_association": c.get("author_association") or "",
                "body": c.get("body") or "",
                "created_at": c.get("created_at"),
                "updated_at": c.get("updated_at"),
                "html_url": c.get("html_url") or "",
            }
            for c in (res.get("data") or [])
            if isinstance(c, dict)
        ]
        return {"ok": True, "comments": comments, "pagination": res.get("pagination", {})}

    def create_issue_comment(self, owner: str, repo: str, issue_number: int, body: str) -> dict[str, Any]:
        """Add a comment to an issue or pull request conversation."""
        o, r = _split_repo(owner, repo)
        text = (body or "").strip()
        if not text:
            return {"ok": False, "error": "Comment body cannot be empty."}
        res = self._request(
            f"/repos/{o}/{r}/issues/{int(issue_number)}/comments",
            method="POST",
            data={"body": text},
        )
        if not res.get("ok"):
            return res
        c = res.get("data") or {}
        return {
            "ok": True,
            "comment": {
                "id": c.get("id"),
                "user": (c.get("user") or {}).get("login"),
                "user_avatar": (c.get("user") or {}).get("avatar_url"),
                "body": c.get("body") or text,
                "created_at": c.get("created_at"),
                "html_url": c.get("html_url") or "",
            },
        }

    def update_issue(
        self,
        owner: str,
        repo: str,
        issue_number: int,
        title: str | None = None,
        body: str | None = None,
        state: str | None = None,
        state_reason: str | None = None,
        labels: list[str] | None = None,
        assignees: list[str] | None = None,
    ) -> dict[str, Any]:
        """Edit an issue's title, body, state, labels, or assignees."""
        o, r = _split_repo(owner, repo)
        data: dict[str, Any] = {}
        if title is not None:
            data["title"] = title.strip()
        if body is not None:
            data["body"] = body
        if state is not None:
            data["state"] = "open" if str(state).strip().lower() == "open" else "closed"
        if state_reason is not None:
            data["state_reason"] = state_reason
        if labels is not None:
            data["labels"] = labels
        if assignees is not None:
            data["assignees"] = assignees
        return self._request(f"/repos/{o}/{r}/issues/{int(issue_number)}", method="PATCH", data=data)

    def list_repo_labels(self, owner: str, repo: str, per_page: int = 50) -> dict[str, Any]:
        """List repository issue/PR labels."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/labels?per_page={per_page}", method="GET")
        if not res.get("ok"):
            return res
        labels = [
            {
                "name": lb.get("name"),
                "color": lb.get("color", ""),
                "description": lb.get("description") or "",
            }
            for lb in (res.get("data") or [])
            if isinstance(lb, dict)
        ]
        return {"ok": True, "labels": labels}

    # ── GitHub Actions & CI/CD ───────────────────────────────────────────────

    def list_workflow_runs(
        self,
        owner: str,
        repo: str,
        branch: str = "",
        event: str = "",
        status: str = "",
        page: int = 1,
        per_page: int = 30,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List GitHub Actions workflow runs for a repository."""
        qp: dict[str, Any] = {"page": page, "per_page": per_page}
        if branch:
            qp["branch"] = branch
        if event:
            qp["event"] = event
        if status:
            qp["status"] = status
        params = urllib.parse.urlencode(qp)
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/actions/runs?{params}", method="GET")
        if not res.get("ok"):
            return res

        data = res.get("data") or {}
        runs = []
        for r in data.get("workflow_runs", []):
            if isinstance(r, dict):
                runs.append({
                    "id": r.get("id"),
                    "name": r.get("name"),
                    "display_title": r.get("display_title") or r.get("name"),
                    "run_number": r.get("run_number"),
                    "head_branch": r.get("head_branch"),
                    "head_sha": (r.get("head_sha") or "")[:7],
                    "event": r.get("event"),
                    "status": r.get("status"),
                    "conclusion": r.get("conclusion"),
                    "html_url": r.get("html_url"),
                    "actor": (r.get("actor") or {}).get("login"),
                    "actor_avatar": (r.get("actor") or {}).get("avatar_url"),
                    "created_at": r.get("created_at"),
                    "updated_at": r.get("updated_at"),
                })
        return {"ok": True, "runs": runs, "total_count": data.get("total_count", len(runs))}

    def list_workflows(self, owner: str, repo: str) -> dict[str, Any]:
        """List GitHub Actions workflow definitions in a repository."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/actions/workflows?per_page=50", method="GET")
        if not res.get("ok"):
            return res
        wfs = [
            {
                "id": w.get("id"),
                "name": w.get("name"),
                "path": w.get("path"),
                "state": w.get("state"),
                "html_url": w.get("html_url"),
            }
            for w in ((res.get("data") or {}).get("workflows") or [])
            if isinstance(w, dict)
        ]
        return {"ok": True, "workflows": wfs}

    def list_workflow_jobs(self, owner: str, repo: str, run_id: int) -> dict[str, Any]:
        """List jobs and steps inside a GitHub Actions workflow run."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/actions/runs/{int(run_id)}/jobs?per_page=50", method="GET")
        if not res.get("ok"):
            return res
        jobs = []
        for j in ((res.get("data") or {}).get("jobs") or []):
            if not isinstance(j, dict):
                continue
            steps = [
                {
                    "name": s.get("name"),
                    "number": s.get("number"),
                    "status": s.get("status"),
                    "conclusion": s.get("conclusion"),
                    "started_at": s.get("started_at"),
                    "completed_at": s.get("completed_at"),
                }
                for s in (j.get("steps") or [])
                if isinstance(s, dict)
            ]
            jobs.append({
                "id": j.get("id"),
                "name": j.get("name"),
                "status": j.get("status"),
                "conclusion": j.get("conclusion"),
                "runner_name": j.get("runner_name") or "",
                "started_at": j.get("started_at"),
                "completed_at": j.get("completed_at"),
                "html_url": j.get("html_url") or "",
                "steps": steps,
            })
        return {"ok": True, "jobs": jobs}

    def get_job_logs(self, owner: str, repo: str, job_id: int) -> dict[str, Any]:
        """Download plain text logs for a GitHub Actions job (strips Auth on Azure redirect)."""
        o, r = _split_repo(owner, repo)
        return self._download_redirect_text(f"/repos/{o}/{r}/actions/jobs/{int(job_id)}/logs")

    def rerun_workflow(self, owner: str, repo: str, run_id: int, failed_only: bool = False) -> dict[str, Any]:
        """Re-run an entire workflow run or only its failed jobs."""
        o, r = _split_repo(owner, repo)
        suffix = "/rerun-failed-jobs" if failed_only else "/rerun"
        res = self._request(f"/repos/{o}/{r}/actions/runs/{int(run_id)}{suffix}", method="POST")
        if not res.get("ok"):
            return res
        return {"ok": True, "message": "Workflow re-run triggered."}

    def cancel_workflow_run(self, owner: str, repo: str, run_id: int) -> dict[str, Any]:
        """Cancel a queued or in-progress workflow run."""
        o, r = _split_repo(owner, repo)
        return self._request(f"/repos/{o}/{r}/actions/runs/{int(run_id)}/cancel", method="POST")

    def list_run_artifacts(self, owner: str, repo: str, run_id: int) -> dict[str, Any]:
        """List artifacts produced by a workflow run."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/actions/runs/{int(run_id)}/artifacts?per_page=30", method="GET")
        if not res.get("ok"):
            return res
        artifacts = [
            {
                "id": a.get("id"),
                "name": a.get("name"),
                "size_in_bytes": a.get("size_in_bytes", 0),
                "expired": bool(a.get("expired")),
                "created_at": a.get("created_at"),
                "expires_at": a.get("expires_at"),
                "archive_download_url": a.get("archive_download_url"),
            }
            for a in ((res.get("data") or {}).get("artifacts") or [])
            if isinstance(a, dict)
        ]
        return {"ok": True, "artifacts": artifacts}

    def trigger_workflow(
        self,
        owner: str,
        repo: str,
        workflow_id: str = "",
        workflow_id_or_file: str = "",
        ref: str = "main",
        inputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Trigger a GitHub Actions workflow dispatch."""
        target_wf = (workflow_id or workflow_id_or_file).strip()
        data = {
            "ref": ref.strip(),
            "inputs": inputs or {},
        }
        res = self._request(
            f"/repos/{owner.strip()}/{repo.strip()}/actions/workflows/{target_wf}/dispatches",
            method="POST",
            data=data,
        )
        if not res.get("ok"):
            return res
        return {"ok": True, "message": f"Workflow {target_wf} triggered on branch '{ref}'."}

    # ── SSH & Deploy Keys ────────────────────────────────────────────────────

    def list_ssh_keys(self) -> dict[str, Any]:
        """List public SSH keys linked to the GitHub account."""
        res = self._request("/user/keys", method="GET")
        if not res.get("ok"):
            return res
        keys = []
        for k in (res.get("data") or []):
            if isinstance(k, dict):
                keys.append({
                    "id": k.get("id"),
                    "title": k.get("title"),
                    "key": k.get("key"),
                    "created_at": k.get("created_at"),
                })
        return {"ok": True, "keys": keys}

    def add_deploy_key(
        self,
        owner: str,
        repo: str,
        title: str,
        key: str,
        read_only: bool = True,
    ) -> dict[str, Any]:
        """Add an SSH Deploy Key to a repository."""
        data = {
            "title": title.strip(),
            "key": key.strip(),
            "read_only": bool(read_only),
        }
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/keys", method="POST", data=data)
        if not res.get("ok"):
            err_msg = str(res.get("error") or "").lower()
            if res.get("status_code") == 422 and ("already in use" in err_msg or "validation failed" in err_msg):
                return {"ok": True, "already_exists": True, "title": title}
            return res
        return {"ok": True, "id": (res.get("data") or {}).get("id"), "title": title}

    def list_deploy_keys(self, owner: str, repo: str) -> dict[str, Any]:
        """List SSH Deploy Keys configured on a repository."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/keys?per_page=50", method="GET")
        if not res.get("ok"):
            return res
        keys = [
            {
                "id": k.get("id"),
                "title": k.get("title"),
                "key": k.get("key"),
                "read_only": bool(k.get("read_only")),
                "verified": bool(k.get("verified", True)),
                "created_at": k.get("created_at") or "",
            }
            for k in (res.get("data") or [])
            if isinstance(k, dict)
        ]
        return {"ok": True, "keys": keys}

    def delete_deploy_key(self, owner: str, repo: str, key_id: int) -> dict[str, Any]:
        """Remove an SSH Deploy Key from a repository."""
        o, r = _split_repo(owner, repo)
        return self._request(f"/repos/{o}/{r}/keys/{int(key_id)}", method="DELETE")

    # ── Notifications, Organizations, Search, Gists & Feed ───────────────────

    def list_notifications(
        self,
        all_notifs: bool = False,
        participating: bool = False,
        page: int = 1,
        per_page: int = 30,
    ) -> dict[str, Any]:
        """List notifications across the user's GitHub account."""
        params = urllib.parse.urlencode({
            "all": str(bool(all_notifs)).lower(),
            "participating": str(bool(participating)).lower(),
            "page": page,
            "per_page": per_page,
        })
        res = self._request(f"/notifications?{params}", method="GET")
        if not res.get("ok"):
            return res
        notifs = []
        for n in (res.get("data") or []):
            if not isinstance(n, dict):
                continue
            subj = n.get("subject") or {}
            repo_obj = n.get("repository") or {}
            subj_url = subj.get("url") or ""
            subj_num = None
            m_num = re.search(r"/(\d+)$", subj_url)
            if m_num:
                subj_num = int(m_num.group(1))
            notifs.append({
                "id": n.get("id"),
                "unread": bool(n.get("unread")),
                "reason": n.get("reason") or "",
                "updated_at": n.get("updated_at") or "",
                "subject_title": subj.get("title") or "",
                "subject_type": subj.get("type") or "",
                "subject_url": subj_url,
                "subject_number": subj_num,
                "repo_full_name": repo_obj.get("full_name") or "",
                "repo_private": bool(repo_obj.get("private")),
                "html_url": f"https://github.com/{repo_obj.get('full_name', '')}",
            })
        return {"ok": True, "notifications": notifs, "pagination": res.get("pagination", {})}

    def mark_notification_read(self, thread_id: str) -> dict[str, Any]:
        """Mark a single notification thread as read."""
        return self._request(f"/notifications/threads/{urllib.parse.quote(str(thread_id).strip(), safe='')}", method="PATCH")

    def mark_all_notifications_read(self) -> dict[str, Any]:
        """Mark all notifications as read."""
        return self._request("/notifications", method="PUT", data={})

    def list_orgs(self) -> dict[str, Any]:
        """List organizations for the authenticated user."""
        res = self._request("/user/orgs?per_page=50", method="GET")
        if not res.get("ok"):
            return res
        orgs = [
            {
                "id": o.get("id"),
                "login": o.get("login"),
                "avatar_url": o.get("avatar_url") or "",
                "description": o.get("description") or "",
            }
            for o in (res.get("data") or [])
            if isinstance(o, dict)
        ]
        return {"ok": True, "orgs": orgs}

    def list_org_repos(
        self,
        org: str,
        repo_type: str = "all",
        sort: str = "updated",
        page: int = 1,
        per_page: int = 30,
    ) -> dict[str, Any]:
        """List repositories inside a GitHub organization."""
        safe_org = urllib.parse.quote(org.strip(), safe="")
        params = urllib.parse.urlencode({"type": repo_type, "sort": sort, "page": page, "per_page": per_page})
        res = self._request(f"/orgs/{safe_org}/repos?{params}", method="GET")
        if not res.get("ok"):
            return res
        repos = [self._format_repo(r) for r in (res.get("data") or []) if isinstance(r, dict)]
        return {"ok": True, "repos": repos, "pagination": res.get("pagination", {})}

    def list_org_members(self, org: str, page: int = 1, per_page: int = 50) -> dict[str, Any]:
        """List members of a GitHub organization."""
        safe_org = urllib.parse.quote(org.strip(), safe="")
        params = urllib.parse.urlencode({"page": page, "per_page": per_page})
        res = self._request(f"/orgs/{safe_org}/members?{params}", method="GET")
        if not res.get("ok"):
            return res
        members = [
            {
                "login": m.get("login"),
                "avatar_url": m.get("avatar_url") or "",
                "html_url": m.get("html_url") or "",
                "type": m.get("type") or "User",
            }
            for m in (res.get("data") or [])
            if isinstance(m, dict)
        ]
        return {"ok": True, "members": members}

    def search_github(
        self,
        kind: str,
        q: str,
        sort: str = "",
        order: str = "desc",
        page: int = 1,
        per_page: int = 25,
    ) -> dict[str, Any]:
        """Global GitHub search across repositories, code, issues, users, or commits."""
        allowed_kinds = ("repositories", "code", "issues", "users", "commits")
        target = kind.strip().lower() if kind else "repositories"
        if target not in allowed_kinds:
            return {"ok": False, "error": f"Unsupported search type '{kind}'."}
        if not (q or "").strip():
            return {"ok": False, "error": "Search query 'q' is required."}
        qp: dict[str, Any] = {"q": q.strip(), "page": page, "per_page": per_page}
        if sort:
            qp["sort"] = sort
            qp["order"] = order
        params = urllib.parse.urlencode(qp)
        accept = "application/vnd.github.text-match+json" if target == "code" else "application/vnd.github+json"
        res = self._request(f"/search/{target}?{params}", method="GET", accept=accept)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        raw_items = d.get("items") or []
        items: list[dict[str, Any]] = []
        if target == "repositories":
            items = [self._format_repo(r) for r in raw_items if isinstance(r, dict)]
        elif target == "code":
            for it in raw_items:
                if not isinstance(it, dict):
                    continue
                r_obj = it.get("repository") or {}
                items.append({
                    "name": it.get("name"),
                    "path": it.get("path"),
                    "sha": it.get("sha"),
                    "html_url": it.get("html_url"),
                    "repo_full_name": r_obj.get("full_name"),
                    "text_matches": [tm.get("fragment") for tm in (it.get("text_matches") or []) if isinstance(tm, dict)],
                })
        elif target == "issues":
            for it in raw_items:
                if not isinstance(it, dict):
                    continue
                repo_url = it.get("repository_url") or ""
                repo_full = "/".join(repo_url.split("/")[-2:]) if "/" in repo_url else ""
                items.append({
                    "number": it.get("number"),
                    "title": it.get("title"),
                    "state": it.get("state"),
                    "is_pull": "pull_request" in it,
                    "repo_full_name": repo_full,
                    "user": (it.get("user") or {}).get("login"),
                    "comments": it.get("comments", 0),
                    "updated_at": it.get("updated_at"),
                    "html_url": it.get("html_url"),
                })
        elif target == "users":
            for it in raw_items:
                if isinstance(it, dict):
                    items.append({
                        "login": it.get("login"),
                        "avatar_url": it.get("avatar_url"),
                        "type": it.get("type"),
                        "html_url": it.get("html_url"),
                    })
        elif target == "commits":
            for it in raw_items:
                if not isinstance(it, dict):
                    continue
                row = self._format_commit(it)
                row["repo_full_name"] = (it.get("repository") or {}).get("full_name") or ""
                items.append(row)
        return {
            "ok": True,
            "kind": target,
            "total_count": d.get("total_count", len(items)),
            "incomplete_results": bool(d.get("incomplete_results")),
            "items": items,
            "pagination": res.get("pagination", {}),
        }

    def list_gists(self, page: int = 1, per_page: int = 30) -> dict[str, Any]:
        """List Gists owned by the authenticated user."""
        params = urllib.parse.urlencode({"page": page, "per_page": per_page})
        res = self._request(f"/gists?{params}", method="GET")
        if not res.get("ok"):
            return res
        gists = []
        for g in (res.get("data") or []):
            if not isinstance(g, dict):
                continue
            files = list((g.get("files") or {}).keys())
            gists.append({
                "id": g.get("id"),
                "description": g.get("description") or "",
                "public": bool(g.get("public")),
                "files": files,
                "comments": g.get("comments", 0),
                "html_url": g.get("html_url") or "",
                "created_at": g.get("created_at") or "",
                "updated_at": g.get("updated_at") or "",
            })
        return {"ok": True, "gists": gists, "pagination": res.get("pagination", {})}

    def get_gist(self, gist_id: str) -> dict[str, Any]:
        """Fetch full Gist metadata and file contents."""
        res = self._request(f"/gists/{urllib.parse.quote(gist_id.strip(), safe='')}", method="GET")
        if not res.get("ok"):
            return res
        g = res.get("data") or {}
        files_out = {}
        for fname, fmeta in (g.get("files") or {}).items():
            if isinstance(fmeta, dict):
                files_out[fname] = {
                    "filename": fmeta.get("filename", fname),
                    "language": fmeta.get("language") or "",
                    "size": fmeta.get("size", 0),
                    "content": fmeta.get("content") or "",
                }
        return {
            "ok": True,
            "gist": {
                "id": g.get("id"),
                "description": g.get("description") or "",
                "public": bool(g.get("public")),
                "html_url": g.get("html_url") or "",
                "files": files_out,
                "updated_at": g.get("updated_at") or "",
            },
        }

    def create_gist(self, files: dict[str, str], description: str = "", public: bool = False) -> dict[str, Any]:
        """Create a new GitHub Gist."""
        payload_files = {
            fname: {"content": content}
            for fname, content in (files or {}).items()
            if fname.strip() and content
        }
        if not payload_files:
            return {"ok": False, "error": "At least one non-empty file is required for a Gist."}
        res = self._request(
            "/gists",
            method="POST",
            data={"description": description.strip(), "public": bool(public), "files": payload_files},
        )
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {"ok": True, "id": d.get("id"), "html_url": d.get("html_url")}

    def update_gist(
        self,
        gist_id: str,
        files: dict[str, str | None] | None = None,
        description: str | None = None,
    ) -> dict[str, Any]:
        """Update a GitHub Gist's description or file contents."""
        data: dict[str, Any] = {}
        if description is not None:
            data["description"] = description
        if files is not None:
            data["files"] = {
                fname: (None if content is None else {"content": content})
                for fname, content in files.items()
            }
        return self._request(f"/gists/{urllib.parse.quote(gist_id.strip(), safe='')}", method="PATCH", data=data)

    def get_user_profile(self, username: str = "") -> dict[str, Any]:
        """Fetch authenticated user profile or a specific GitHub user's profile."""
        ep = f"/users/{urllib.parse.quote(username.strip(), safe='')}" if username.strip() else "/user"
        res = self._request(ep, method="GET")
        if not res.get("ok"):
            return res
        u = res.get("data") or {}
        return {
            "ok": True,
            "user": {
                "login": u.get("login"),
                "name": u.get("name") or "",
                "avatar_url": u.get("avatar_url") or "",
                "bio": u.get("bio") or "",
                "company": u.get("company") or "",
                "location": u.get("location") or "",
                "blog": u.get("blog") or "",
                "email": u.get("email") or "",
                "twitter_username": u.get("twitter_username") or "",
                "public_repos": u.get("public_repos", 0),
                "public_gists": u.get("public_gists", 0),
                "followers": u.get("followers", 0),
                "following": u.get("following", 0),
                "html_url": u.get("html_url") or "",
                "created_at": u.get("created_at") or "",
            },
        }

    def list_starred_repos(self, username: str = "", page: int = 1, per_page: int = 30) -> dict[str, Any]:
        """List starred repositories for the active user or specified username."""
        params = urllib.parse.urlencode({"page": page, "per_page": per_page})
        if username.strip():
            ep = f"/users/{urllib.parse.quote(username.strip(), safe='')}/starred?{params}"
        else:
            ep = f"/user/starred?{params}"
        res = self._request(ep, method="GET")
        if not res.get("ok"):
            return res
        repos = [self._format_repo(r) for r in (res.get("data") or []) if isinstance(r, dict)]
        return {"ok": True, "repos": repos, "pagination": res.get("pagination", {})}

    def list_user_events(self, username: str = "", received: bool = True, page: int = 1, per_page: int = 30) -> dict[str, Any]:
        """List received feed events or user public activity events."""
        target = username.strip() or self.load_credentials().get("username", "")
        if not target:
            return {"ok": False, "error": "Username not available for events feed."}
        safe_u = urllib.parse.quote(target, safe="")
        params = urllib.parse.urlencode({"page": page, "per_page": per_page})
        kind = "received_events" if received else "events"
        res = self._request(f"/users/{safe_u}/{kind}?{params}", method="GET")
        if not res.get("ok"):
            return res
        events = []
        for ev in (res.get("data") or []):
            if not isinstance(ev, dict):
                continue
            actor = ev.get("actor") or {}
            repo_obj = ev.get("repo") or {}
            payload = ev.get("payload") or {}
            summary = ""
            etype = ev.get("type") or ""
            if etype == "PushEvent":
                ref_name = (payload.get("ref") or "").replace("refs/heads/", "")
                cnt = payload.get("size") or len(payload.get("commits") or [])
                summary = f"pushed {cnt} commit(s) to {ref_name}" if ref_name else "pushed commits"
            elif etype == "PullRequestEvent":
                pr_obj = payload.get("pull_request") or {}
                summary = f"{payload.get('action', '')} PR #{pr_obj.get('number', '')}: {pr_obj.get('title', '')}".strip()
            elif etype == "IssuesEvent":
                iss_obj = payload.get("issue") or {}
                summary = f"{payload.get('action', '')} issue #{iss_obj.get('number', '')}: {iss_obj.get('title', '')}".strip()
            elif etype == "CreateEvent":
                summary = f"created {payload.get('ref_type', '')} {payload.get('ref', '')}".strip()
            elif etype == "WatchEvent":
                summary = "starred repository"
            elif etype == "ForkEvent":
                summary = "forked repository"
            elif etype == "ReleaseEvent":
                rel_obj = payload.get("release") or {}
                summary = f"published release {rel_obj.get('tag_name', '')}".strip()
            else:
                summary = payload.get("action") or etype
            events.append({
                "id": ev.get("id"),
                "type": etype,
                "actor": actor.get("login") or "",
                "actor_avatar": actor.get("avatar_url") or "",
                "repo_name": repo_obj.get("name") or "",
                "summary": summary,
                "created_at": ev.get("created_at") or "",
            })
        return {"ok": True, "events": events, "pagination": res.get("pagination", {})}

    # ── Local Laravel Sites & Git Integration ────────────────────────────────

    def resolve_site_dir(self, site_name_or_path: str) -> Path | None:
        """Resolve site name or path to a directory."""
        target = Path(site_name_or_path).resolve()
        if target.is_dir():
            return target

        sites_dir = Path.home() / "Sites"
        cand = sites_dir / site_name_or_path
        if cand.is_dir():
            return cand

        # Try /var/www
        cand_var = Path("/var/www") / site_name_or_path
        if cand_var.is_dir():
            return cand_var

        return None

    def get_site_git_status(self, site_name_or_path: str) -> dict[str, Any]:
        """Inspect git status for a local site directory."""
        sdir = self.resolve_site_dir(site_name_or_path)
        if not sdir:
            return {"ok": False, "error": f"Site directory '{site_name_or_path}' not found."}

        # In a worktree or submodule ".git" is a file.
        if not (sdir / ".git").exists():
            return {
                "ok": True,
                "is_git": False,
                "path": str(sdir),
                "remote_url": "",
                "branch": "",
                "clean": True,
                "unpushed": 0,
            }

        remote_url = _run_git(["config", "--get", "remote.origin.url"], sdir).stdout.strip()
        # One command gives the branch, the ahead count and the changed files.
        st = _run_git(["status", "--porcelain=v2", "--branch"], sdir)
        if st.returncode != 0:
            return {"ok": False, "error": (st.stderr or "git status failed").strip()}
        branch, unpushed, clean = "main", 0, True
        for line in st.stdout.splitlines():
            if line.startswith("# branch.head "):
                branch = line[len("# branch.head "):]
            elif line.startswith("# branch.ab "):
                m_ab = re.search(r"\+(\d+)", line)
                unpushed = int(m_ab.group(1)) if m_ab else 0
            elif line and not line.startswith("#"):
                clean = False

        # Parse owner and repo name from remote url
        repo_owner = ""
        repo_name = ""
        m = re.search(r"github\.com[:/]([^/\s]+)/([^/\s]+?)(?:\.git)?/?$", remote_url)
        if m:
            repo_owner, repo_name = m.group(1), m.group(2)

        return {
            "ok": True,
            "is_git": True,
            "path": str(sdir),
            "remote_url": remote_url,
            "repo_owner": repo_owner,
            "repo_name": repo_name,
            "repo_full_name": f"{repo_owner}/{repo_name}" if repo_owner and repo_name else "",
            "branch": branch,
            "clean": clean,
            "unpushed": unpushed,
        }

    def publish_site(
        self,
        site_name_or_path: str,
        repo_name: str = "",
        private: bool = True,
        description: str = "",
    ) -> dict[str, Any]:
        """Publish a local site to a new GitHub repository (init, create, remote, push)."""
        sdir = self.resolve_site_dir(site_name_or_path)
        if not sdir:
            return {"ok": False, "error": f"Site directory '{site_name_or_path}' not found."}

        rname = repo_name.strip() or sdir.name
        creds = self.load_credentials()
        token = creds.get("token")
        if not token:
            return {"ok": False, "error": "GitHub Personal Access Token not configured."}

        # 1. Create repo on GitHub
        create_res = self.create_repo(
            name=rname,
            description=description or f"Laravel application {rname}",
            private=private,
            auto_init=False,
        )
        if not create_res.get("ok"):
            return create_res

        clone_url = create_res.get("clone_url", "")
        html_url = create_res.get("html_url", "")
        owner = creds.get("username", "")

        # 2. Local git orchestration
        def run_cmd(args: list[str]) -> subprocess.CompletedProcess[str]:
            return _run_git(args[1:], sdir, timeout=120)

        if not (sdir / ".git").exists():
            run_cmd(["git", "init", "-b", "main"])

        # Check default gitignore
        gitignore = sdir / ".gitignore"
        if not gitignore.exists():
            default_gi = "/node_modules\n/public/build\n/public/hot\n/public/storage\n/storage/*.key\n/vendor\n.env\n.env.backup\n.phpunit.result.cache\nHomestead.json\nHomestead.yaml\npm2.json\nauth.json\n"
            try:
                gitignore.write_text(default_gi, encoding="utf-8")
            except OSError:
                pass

        # Commit initial changes if no commits
        head_check = run_cmd(["git", "rev-parse", "HEAD"])
        if head_check.returncode != 0:
            run_cmd(["git", "add", "."])
            run_cmd(["git", "commit", "-m", "Initial commit from Laravel Dev Tool"])

        clean_remote = f"https://github.com/{owner}/{rname}.git"
        if run_cmd(["git", "remote", "set-url", "origin", clean_remote]).returncode != 0:
            run_cmd(["git", "remote", "add", "origin", clean_remote])

        # Push whatever branch is checked out (not every project uses main/master).
        branch = run_cmd(["git", "symbolic-ref", "--short", "HEAD"]).stdout.strip() or "main"
        push_res = _run_git(["push", "-u", "origin", branch], sdir, timeout=GIT_NET_TIMEOUT, token=token)

        return {
            "ok": True,
            "name": rname,
            "owner": owner,
            "full_name": f"{owner}/{rname}",
            "html_url": html_url,
            "clone_url": clone_url,
            "push_success": push_res.returncode == 0,
            "push_output": push_res.stdout or push_res.stderr,
        }

    def link_site(self, site_name_or_path: str, repo_full_name: str) -> dict[str, Any]:
        """Bind an existing local site to an existing GitHub repository."""
        sdir = self.resolve_site_dir(site_name_or_path)
        if not sdir:
            return {"ok": False, "error": f"Site directory '{site_name_or_path}' not found."}

        target_repo = repo_full_name.strip()
        if "/" not in target_repo:
            return {"ok": False, "error": "Repo full name must be in format 'owner/repo'."}

        def run_cmd(args: list[str]) -> subprocess.CompletedProcess[str]:
            return _run_git(args[1:], sdir, timeout=30)

        if not (sdir / ".git").exists():
            run_cmd(["git", "init", "-b", "main"])

        remote_url = f"https://github.com/{target_repo}.git"
        run_cmd(["git", "remote", "remove", "origin"])
        res = run_cmd(["git", "remote", "add", "origin", remote_url])

        return {
            "ok": res.returncode == 0,
            "remote_url": remote_url,
            "repo_full_name": target_repo,
        }

    def clone_repo(self, repo_full_name: str, target_dir_or_name: str = "") -> dict[str, Any]:
        """Clone a GitHub repository into local Laravel Sites directory."""
        creds = self.load_credentials()
        token = creds.get("token")
        if not token:
            return {"ok": False, "error": "GitHub Personal Access Token not configured."}

        repo_part = repo_full_name.strip()
        if "/" not in repo_part:
            owner = creds.get("username", "")
            if not owner:
                return {"ok": False, "error": "Repo full name must be in format 'owner/repo'."}
            repo_part = f"{owner}/{repo_part}"

        repo_name = repo_part.split("/")[-1]
        sites_dir = Path.home() / "Sites"
        sites_dir.mkdir(parents=True, exist_ok=True)

        if target_dir_or_name:
            t = Path(target_dir_or_name).expanduser()
            dest = t if t.is_absolute() else (sites_dir / target_dir_or_name)
        else:
            dest = sites_dir / repo_name
        if dest.exists() and any(dest.iterdir()):
            return {"ok": False, "error": f"Destination directory '{dest}' already exists and is not empty."}

        res = _run_git(["clone", f"https://github.com/{repo_part}.git", str(dest)], timeout=GIT_NET_TIMEOUT, token=token)
        if res.returncode != 0:
            return {"ok": False, "error": f"Clone failed: {res.stderr or res.stdout}"}

        return {
            "ok": True,
            "destination": str(dest),
            "site_name": dest.name,
            "repo_full_name": repo_part,
        }

    # ── CI/CD Workflows, Actions Secrets/Variables & Environments ────────────

    @staticmethod
    def _validate_env_key_name(name: str, kind: str = "key") -> str:
        clean = (name or "").strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", clean):
            raise ValueError(f"Invalid {kind} name '{name}': use letters, digits, and underscores only (cannot start with a digit).")
        if clean.upper().startswith("GITHUB_"):
            raise ValueError(f"{kind.capitalize()} name '{clean}' cannot start with 'GITHUB_' (reserved by GitHub Actions).")
        return clean

    @staticmethod
    def _seal_secret(public_key_b64: str, secret_value: str) -> str:
        """Encrypt a secret value using GitHub's Libsodium X25519 SealedBox public key."""
        try:
            from nacl import encoding, public
        except ImportError as exc:
            raise RuntimeError(
                "PyNaCl (python3-nacl) is required to encrypt GitHub Actions Secrets. "
                "Install it with: sudo apt install python3-nacl (or pip install pynacl)."
            ) from exc
        pub = public.PublicKey(public_key_b64.encode("utf-8"), encoding.Base64Encoder())
        box = public.SealedBox(pub)
        encrypted = box.encrypt((secret_value or "").encode("utf-8"))
        return base64.b64encode(encrypted).decode("utf-8")

    def _actions_scope_prefix(self, owner: str, repo: str, env_name: str = "") -> str:
        o, r = _split_repo(owner, repo)
        env_clean = (env_name or "").strip()
        if env_clean:
            enc_env = urllib.parse.quote(env_clean, safe="")
            return f"/repos/{o}/{r}/environments/{enc_env}"
        return f"/repos/{o}/{r}/actions"

    def get_repo_capabilities(self, owner: str, repo: str) -> dict[str, Any]:
        """Inspect user permissions & token scopes on a repository to guard write controls."""
        o, r = _split_repo(owner, repo)
        repo_res = self.get_repo(o, r)
        if not repo_res.get("ok"):
            return repo_res
        meta = repo_res.get("repo") or {}
        perms = meta.get("permissions") or {}
        admin = bool(perms.get("admin"))
        maintain = bool(perms.get("maintain"))
        push = bool(perms.get("push"))
        role = "admin" if admin else "maintain" if maintain else "write" if push else "read"

        status = self.get_status()
        scopes = status.get("scopes") or []
        token_raw = (self.load_credentials().get("token") or "").strip()
        is_classic = token_raw.startswith(("ghp_", "gho_")) or bool(scopes)

        can_push_code = bool(admin or maintain or push)
        missing_scopes = []
        if is_classic:
            has_workflow_scope = "workflow" in scopes
            if can_push_code and not has_workflow_scope:
                missing_scopes.append("workflow")
            if not any(s in scopes for s in ("repo", "public_repo")):
                missing_scopes.append("repo")
        else:
            has_workflow_scope = True  # Fine-grained PATs do not emit X-OAuth-Scopes

        can_manage_secrets = bool(admin or maintain)
        can_manage_variables = bool(admin or maintain)

        # Lightweight probe for Actions Secrets/Variables access when user has admin/maintain
        if can_manage_secrets:
            probe = self._request(f"/repos/{o}/{r}/actions/secrets?per_page=1", method="GET")
            if not probe.get("ok") and probe.get("status_code") in (403, 404):
                can_manage_secrets = False

        if can_manage_variables:
            probe_v = self._request(f"/repos/{o}/{r}/actions/variables?per_page=1", method="GET")
            if not probe_v.get("ok") and probe_v.get("status_code") in (403, 404):
                can_manage_variables = False

        can_edit_workflows = bool(can_push_code and has_workflow_scope)
        reason = ""
        if not can_push_code:
            reason = "You have read-only access to this repository. Push or Admin permissions are required."
        elif not can_manage_secrets:
            reason = "Admin or Maintainer permissions (with Actions/Secrets token access) are required to manage Actions Secrets & Variables."
        elif "workflow" in missing_scopes:
            reason = "Your classic GitHub token is missing the 'workflow' scope needed to create/update .github/workflows/*.yml files."

        return {
            "ok": True,
            "role": role,
            "permissions": perms,
            "scopes": scopes,
            "is_classic_token": is_classic,
            "can_push_code": can_push_code,
            "can_edit_workflows": can_edit_workflows,
            "can_manage_secrets": can_manage_secrets,
            "can_manage_variables": can_manage_variables,
            "can_manage_environments": bool(admin),
            "missing_scopes": missing_scopes,
            "read_only_reason": reason,
        }

    def list_repo_secrets(self, owner: str, repo: str, env_name: str = "") -> dict[str, Any]:
        """List Actions secrets for a repository or a deployment environment (metadata only)."""
        prefix = self._actions_scope_prefix(owner, repo, env_name)
        res = self._request(f"{prefix}/secrets?per_page=100", method="GET")
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        secrets = [
            {"name": s.get("name", ""), "created_at": s.get("created_at", ""), "updated_at": s.get("updated_at", "")}
            for s in (d.get("secrets") or [])
            if isinstance(s, dict)
        ]
        return {"ok": True, "secrets": secrets, "total_count": d.get("total_count", len(secrets)), "env": env_name or ""}

    def upsert_repo_secret(self, owner: str, repo: str, name: str, value: str, env_name: str = "") -> dict[str, Any]:
        """Encrypt with Libsodium SealedBox and create or update a repository or environment Actions secret."""
        clean_name = self._validate_env_key_name(name, "secret")
        prefix = self._actions_scope_prefix(owner, repo, env_name)
        pk_res = self._request(f"{prefix}/secrets/public-key", method="GET")
        if not pk_res.get("ok"):
            return pk_res
        pk_data = pk_res.get("data") or {}
        key_id = str(pk_data.get("key_id") or "")
        pub_key = str(pk_data.get("key") or "")
        if not key_id or not pub_key:
            return {"ok": False, "error": "Failed to retrieve GitHub Actions public encryption key."}
        try:
            sealed = self._seal_secret(pub_key, value)
        except Exception as exc:
            return {"ok": False, "error": str(exc)}
        put_res = self._request(
            f"{prefix}/secrets/{urllib.parse.quote(clean_name, safe='')}",
            method="PUT",
            data={"encrypted_value": sealed, "key_id": key_id},
        )
        if not put_res.get("ok"):
            return put_res
        return {"ok": True, "name": clean_name, "env": env_name or ""}

    def delete_repo_secret(self, owner: str, repo: str, name: str, env_name: str = "") -> dict[str, Any]:
        """Delete a repository or environment Actions secret."""
        clean_name = self._validate_env_key_name(name, "secret")
        prefix = self._actions_scope_prefix(owner, repo, env_name)
        return self._request(f"{prefix}/secrets/{urllib.parse.quote(clean_name, safe='')}", method="DELETE")

    def list_repo_variables(self, owner: str, repo: str, env_name: str = "") -> dict[str, Any]:
        """List plain Actions variables for a repository or deployment environment."""
        prefix = self._actions_scope_prefix(owner, repo, env_name)
        res = self._request(f"{prefix}/variables?per_page=100", method="GET")
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        variables = [
            {
                "name": v.get("name", ""),
                "value": v.get("value", ""),
                "created_at": v.get("created_at", ""),
                "updated_at": v.get("updated_at", ""),
            }
            for v in (d.get("variables") or [])
            if isinstance(v, dict)
        ]
        return {"ok": True, "variables": variables, "total_count": d.get("total_count", len(variables)), "env": env_name or ""}

    def upsert_repo_variable(self, owner: str, repo: str, name: str, value: str, env_name: str = "") -> dict[str, Any]:
        """Create or update a plain Actions variable (PATCH existing or POST new)."""
        clean_name = self._validate_env_key_name(name, "variable")
        prefix = self._actions_scope_prefix(owner, repo, env_name)
        payload = {"name": clean_name, "value": str(value if value is not None else "")}
        enc_name = urllib.parse.quote(clean_name, safe="")
        patch_res = self._request(f"{prefix}/variables/{enc_name}", method="PATCH", data=payload)
        if patch_res.get("ok"):
            return {"ok": True, "name": clean_name, "value": payload["value"], "updated": True, "env": env_name or ""}
        if patch_res.get("status_code") == 404:
            post_res = self._request(f"{prefix}/variables", method="POST", data=payload)
            if post_res.get("ok"):
                return {"ok": True, "name": clean_name, "value": payload["value"], "created": True, "env": env_name or ""}
            return post_res
        return patch_res

    def delete_repo_variable(self, owner: str, repo: str, name: str, env_name: str = "") -> dict[str, Any]:
        """Delete a repository or environment Actions variable."""
        clean_name = self._validate_env_key_name(name, "variable")
        prefix = self._actions_scope_prefix(owner, repo, env_name)
        return self._request(f"{prefix}/variables/{urllib.parse.quote(clean_name, safe='')}", method="DELETE")

    def list_environments(self, owner: str, repo: str) -> dict[str, Any]:
        """List GitHub deployment environments (e.g. production, staging)."""
        o, r = _split_repo(owner, repo)
        res = self._request(f"/repos/{o}/{r}/environments?per_page=50", method="GET")
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        envs = [
            {
                "id": e.get("id"),
                "name": e.get("name", ""),
                "html_url": e.get("html_url", ""),
                "updated_at": e.get("updated_at", ""),
            }
            for e in (d.get("environments") or [])
            if isinstance(e, dict)
        ]
        return {"ok": True, "environments": envs, "total_count": d.get("total_count", len(envs))}

    def upsert_environment(self, owner: str, repo: str, env_name: str) -> dict[str, Any]:
        """Create or update a deployment environment on GitHub."""
        o, r = _split_repo(owner, repo)
        clean_env = (env_name or "").strip()
        if not clean_env:
            return {"ok": False, "error": "Environment name is required."}
        enc_env = urllib.parse.quote(clean_env, safe="")
        res = self._request(f"/repos/{o}/{r}/environments/{enc_env}", method="PUT", data={})
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {"ok": True, "name": d.get("name", clean_env), "id": d.get("id")}

    def delete_environment(self, owner: str, repo: str, env_name: str) -> dict[str, Any]:
        """Delete a deployment environment on GitHub."""
        o, r = _split_repo(owner, repo)
        clean_env = (env_name or "").strip()
        if not clean_env:
            return {"ok": False, "error": "Environment name is required."}
        return self._request(f"/repos/{o}/{r}/environments/{urllib.parse.quote(clean_env, safe='')}", method="DELETE")

    def inspect_repo_cicd(self, owner: str, repo: str, ref: str = "") -> dict[str, Any]:
        """Detect stack from remote repo files and list existing workflow YAMLs."""
        o, r = _split_repo(owner, repo)
        branch_ref = (ref or "").strip()
        if not branch_ref:
            meta_res = self.get_repo(o, r)
            branch_ref = (meta_res.get("repo") or {}).get("default_branch") or "main"

        tree_res = self.get_repo_tree(o, r, ref=branch_ref, recursive=False)
        root_names: set[str] = set()
        if tree_res.get("ok"):
            root_names = {str(it.get("path") or "") for it in (tree_res.get("tree") or [])}

        stack = "static"
        framework = "html"
        health_path = "/"
        if "artisan" in root_names:
            stack, framework, health_path = "laravel", "laravel", "/up"
        elif "docker-compose.yml" in root_names or "docker-compose.yaml" in root_names or "compose.yml" in root_names or "Dockerfile" in root_names:
            stack, framework, health_path = "docker", "docker", "/"
        elif "package.json" in root_names:
            stack, framework, health_path = "node_ssr", "node", "/"
            pkg_res = self.get_repo_contents(o, r, "package.json", ref=branch_ref)
            if pkg_res.get("ok") and pkg_res.get("content"):
                low = pkg_res["content"].lower()
                if '"nuxt"' in low:
                    stack, framework = "node_ssr", "nuxt"
                elif '"next"' in low:
                    stack, framework = "node_ssr", "next"
                elif '"vite"' in low or '"react-scripts"' in low:
                    stack, framework = "static", "vite"
        elif "manage.py" in root_names:
            stack, framework = "python", "django"
        elif "requirements.txt" in root_names or "pyproject.toml" in root_names:
            stack, framework = "python", "fastapi"

        workflows = []
        wf_dir = self.get_repo_contents(o, r, ".github/workflows", ref=branch_ref)
        if wf_dir.get("ok") and wf_dir.get("kind") == "dir":
            workflows = [
                {"name": e.get("name"), "path": e.get("path"), "sha": e.get("sha")}
                for e in (wf_dir.get("entries") or [])
                if e.get("type") == "file"
            ]

        yaml_preview = self.build_cicd_workflow_yaml(
            stack=stack,
            branch=branch_ref,
            strategy="ci_build_upload",
            environment="",
            health_path=health_path,
        )
        return {
            "ok": True,
            "ref": branch_ref,
            "stack": stack,
            "framework": framework,
            "workflows": workflows,
            "default_yaml": yaml_preview,
        }

    @staticmethod
    def build_cicd_workflow_yaml(
        stack: str = "laravel",
        branch: str = "main",
        strategy: str = "ci_build_upload",
        environment: str = "",
        health_path: str = "/",
        php_version: str = "8.3",
        node_version: str = "20",
        framework: str = "",
    ) -> str:
        """Generate a production GitHub Actions CI/CD deploy workflow tailored to the app stack."""
        s = (stack or "laravel").strip().lower()
        br = (branch or "main").strip()
        strat = (strategy or "ci_build_upload").strip()
        env_line = f"    environment: {environment.strip()}\n" if (environment or "").strip() else ""
        hp = (health_path or "/").strip()

        if strat == "vps_git_pull":
            remote_cmd = (
                'APP="${{ vars.DEPLOY_PATH }}"; mkdir -p "$APP"; '
                f'REPO_URL="${{{{ vars.GIT_REPO_URL }}}}"; [ -z "$REPO_URL" ] && REPO_URL="https://github.com/${{{{ github.repository }}}}.git"; '
                'PREV=""; [ -d "$APP/.git" ] && PREV="$(git -C "$APP" rev-parse HEAD 2>/dev/null || true)"; '
                f'if [ -d "$APP/.git" ]; then cd "$APP" && git fetch --depth 1 origin "{br}" && git reset --hard "origin/{br}"; '
                f'else [ -f "$APP/.env" ] && cp -p "$APP/.env" "$APP/.env.keep_$$" || true; '
                f'git clone --depth 1 --branch "{br}" "$REPO_URL" "$APP/.tmp_clone_$$" && cp -a "$APP/.tmp_clone_$$/." "$APP/" && rm -rf "$APP/.tmp_clone_$$"; '
                '[ -f "$APP/.env.keep_$$" ] && mv -f "$APP/.env.keep_$$" "$APP/.env" || true; cd "$APP"; fi; '
            )
            if s == "laravel":
                remote_cmd += (
                    'mkdir -p storage/app/public storage/framework/cache/data storage/framework/sessions storage/framework/views storage/logs bootstrap/cache; '
                    'composer install --no-dev --optimize-autoloader --no-interaction; '
                    'if [ -f package.json ]; then npm ci || npm install; npm run build || true; fi; '
                    'php artisan migrate --force || true; php artisan optimize || true; '
                )
            elif s in ("node_ssr", "static"):
                remote_cmd += 'if [ -f package-lock.json ]; then npm ci; else npm install; fi; npm run build; '
            elif s == "python":
                remote_cmd += (
                    'python3 -m venv "$APP/.venv"; '
                    '[ -f requirements.txt ] && "$APP/.venv/bin/pip" install -r requirements.txt; '
                    '[ -f manage.py ] && "$APP/.venv/bin/python" manage.py migrate --noinput || true; '
                )
            elif s == "docker":
                remote_cmd += 'docker compose up -d --build --remove-orphans; '

            reload_cmd = _build_ci_reload_snippet(s, php_version, escape_dollars=False)
            health_cmd = _build_ci_health_snippet(s, hp, escape_dollars=False)
            return f"""name: Laravel Dev CI/CD Deploy

on:
  push:
    branches: ["{br}"]
  workflow_dispatch:

jobs:
  deploy:
    runs-on: ubuntu-latest
{env_line}    steps:
      - name: Configure SSH & Deploy on VPS
        env:
          SSH_KEY: ${{{{ secrets.VPS_SSH_KEY }}}}
          VPS_HOST: ${{{{ secrets.VPS_HOST }}}}
          VPS_USER: ${{{{ secrets.VPS_USER }}}}
          VPS_PORT: ${{{{ secrets.VPS_PORT }}}}
        run: |
          set -euo pipefail
          PORT="${{VPS_PORT:-22}}"
          install -m 700 -d ~/.ssh
          printf '%s\\n' "$SSH_KEY" > ~/.ssh/deploy_key
          chmod 600 ~/.ssh/deploy_key
          ssh-keyscan -p "$PORT" -H "$VPS_HOST" >> ~/.ssh/known_hosts 2>/dev/null || true
          ssh -i ~/.ssh/deploy_key -p "$PORT" -o StrictHostKeyChecking=accept-new "$VPS_USER@$VPS_HOST" bash -s <<'REMOTE_EOF'
          set -euo pipefail
          export APP_PORT="${{{{ vars.PORT || '3000' }}}}"
          {remote_cmd}
          {reload_cmd}
          {health_cmd}
          REMOTE_EOF
"""

        # Default strategy: ci_build_upload (builds on GitHub Runner -> uploads tarball over SSH directly to $DEPLOY_PATH)
        setup_steps = ""
        build_steps = ""
        if s == "laravel":
            setup_steps = f"""      - name: Setup PHP {php_version}
        uses: shivammathur/setup-php@v2
        with:
          php-version: "{php_version}"
          extensions: mbstring, xml, curl, zip
      - name: Setup Node {node_version}
        uses: actions/setup-node@v4
        with:
          node-version: "{node_version}"
          cache: npm
"""
            build_steps = """      - name: Install Dependencies & Build
        run: |
          composer install --no-dev --optimize-autoloader --prefer-dist --no-interaction
          if [ -f package.json ]; then
            if [ -f package-lock.json ]; then npm ci; else npm install; fi
            npm run build || true
          fi
"""
        elif s in ("node_ssr", "static"):
            setup_steps = f"""      - name: Setup Node {node_version}
        uses: actions/setup-node@v4
        with:
          node-version: "{node_version}"
          cache: npm
"""
            build_steps = """      - name: Install & Build
        run: |
          if [ -f pnpm-lock.yaml ]; then
            corepack enable && pnpm install --frozen-lockfile && pnpm run build
          elif [ -f yarn.lock ]; then
            yarn install --frozen-lockfile && yarn build
          else
            if [ -f package-lock.json ]; then npm ci; else npm install; fi
            npm run build
          fi
"""
        elif s == "python":
            setup_steps = """      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.12"
"""
            build_steps = """      - name: Validate Python Project
        run: |
          python -m pip install --upgrade pip
          if [ -f requirements.txt ]; then pip install -r requirements.txt; fi
"""

        reload_cmd = _build_ci_reload_snippet(s, php_version, escape_dollars=True)
        health_cmd = _build_ci_health_snippet(s, hp, escape_dollars=True)
        remote_post_extract = ""
        if s == "laravel":
            remote_post_extract = (
                'cd "\\$APP" && mkdir -p storage/app/public storage/framework/cache/data storage/framework/sessions storage/framework/views storage/logs bootstrap/cache && '
                'php artisan migrate --force || true && php artisan optimize || true; '
            )
        elif s == "node_ssr":
            remote_post_extract = 'cd "\\$APP" && if [ -f package.json ] && [ ! -d node_modules ] && [ ! -d .output/server/node_modules ]; then npm install --omit=dev || true; fi; '
        elif s == "python":
            remote_post_extract = (
                'python3 -m venv "\\$APP/.venv"; cd "\\$APP"; '
                '[ -f requirements.txt ] && "\\$APP/.venv/bin/pip" install -r requirements.txt; '
                '[ -f manage.py ] && "\\$APP/.venv/bin/python" manage.py migrate --noinput || true; '
            )
        elif s == "docker":
            remote_post_extract = 'cd "\\$APP" && docker compose up -d --build --remove-orphans; '

        tar_excludes = "--exclude=.git --exclude=.env --exclude=storage --exclude=.venv --exclude=__pycache__"
        if s in ("node_ssr", "static"):
            tar_excludes += " --exclude=node_modules"

        return f"""name: Laravel Dev CI/CD Deploy

on:
  push:
    branches: ["{br}"]
  workflow_dispatch:

jobs:
  deploy:
    runs-on: ubuntu-latest
{env_line}    steps:
      - name: Checkout Source
        uses: actions/checkout@v4

{setup_steps}{build_steps}      - name: Package Release Artifact
        run: tar -czf /tmp/release.tar.gz {tar_excludes} .

      - name: Upload & Deploy on VPS
        env:
          SSH_KEY: ${{{{ secrets.VPS_SSH_KEY }}}}
          VPS_HOST: ${{{{ secrets.VPS_HOST }}}}
          VPS_USER: ${{{{ secrets.VPS_USER }}}}
          VPS_PORT: ${{{{ secrets.VPS_PORT }}}}
          DEPLOY_PATH: ${{{{ vars.DEPLOY_PATH }}}}
          APP_PORT: ${{{{ vars.PORT || '3000' }}}}
          APP_DOMAIN: ${{{{ vars.APP_DOMAIN }}}}
        run: |
          set -euo pipefail
          PORT="${{VPS_PORT:-22}}"
          install -m 700 -d ~/.ssh
          printf '%s\\n' "$SSH_KEY" > ~/.ssh/deploy_key
          chmod 600 ~/.ssh/deploy_key
          ssh-keyscan -p "$PORT" -H "$VPS_HOST" >> ~/.ssh/known_hosts 2>/dev/null || true

          ssh -i ~/.ssh/deploy_key -p "$PORT" -o StrictHostKeyChecking=accept-new "$VPS_USER@$VPS_HOST" \\
            "mkdir -p '$DEPLOY_PATH'"
          scp -i ~/.ssh/deploy_key -P "$PORT" -o StrictHostKeyChecking=accept-new \\
            /tmp/release.tar.gz "$VPS_USER@$VPS_HOST:$DEPLOY_PATH/.release.tar.gz"

          ssh -i ~/.ssh/deploy_key -p "$PORT" -o StrictHostKeyChecking=accept-new "$VPS_USER@$VPS_HOST" bash -s <<REMOTE_EOF
          set -euo pipefail
          APP="$DEPLOY_PATH"
          tar -xzf "\\$APP/.release.tar.gz" -C "\\$APP" && rm -f "\\$APP/.release.tar.gz"
          {remote_post_extract}
          {reload_cmd}
          {health_cmd}
          REMOTE_EOF
"""


def _build_ci_reload_snippet(stack: str, php_version: str = "8.3", escape_dollars: bool = False) -> str:
    d = "\\$" if escape_dollars else "$"
    if stack == "laravel":
        return (
            f'cd "{d}APP" && php artisan queue:restart || true; '
            f'sudo -n systemctl reload "php{php_version}-fpm" || sudo -n systemctl reload php-fpm || true;'
        )
    if stack == "node_ssr":
        return (
            f'APP_SLUG="{d}(basename "{d}APP" | tr -c "A-Za-z0-9_-" "_")"; '
            f'export PORT="${{APP_PORT:-3000}}"; '
            f'if command -v pm2 >/dev/null 2>&1; then '
            f'pm2 reload "{d}APP_SLUG" --update-env || pm2 start npm --name "{d}APP_SLUG" --cwd "{d}APP" -- start; pm2 save || true; fi;'
        )
    if stack == "python":
        return (
            f'APP_SLUG="{d}(basename "{d}APP" | tr -c "A-Za-z0-9_-" "_")"; '
            f'sudo -n systemctl restart "laravel-dev-{d}{{APP_SLUG}}.service" || true;'
        )
    if stack == "docker":
        return f'cd "{d}APP" && docker compose up -d --build --remove-orphans;'
    return 'sudo -n systemctl reload nginx || true;'


def _build_ci_health_snippet(stack: str, health_path: str = "/", escape_dollars: bool = False) -> str:
    hp = (health_path or "/").strip()
    if not hp or stack == "static":
        return ""
    d = "\\$" if escape_dollars else "$"
    target = f'http://127.0.0.1:${{APP_PORT:-3000}}{hp}' if stack in ("node_ssr", "python", "docker") else f'http://127.0.0.1{hp}'
    return (
        f'sleep 2; if ! curl -fsS --max-time 8 "{target}" >/dev/null 2>&1; then '
        'echo "Health check failed!"; '
        f'[ -n "{d}{{PREV:-}}" ] && [ -d "{d}APP/.git" ] && git -C "{d}APP" reset --hard "{d}PREV" || true; exit 1; fi;'
    )


# ── Terminal Output Helpers ──────────────────────────────────────────────────

def _colorize(text: str, color_code: str, is_tty: bool = True) -> str:
    if not is_tty or not color_code:
        return text
    return f"\033[{color_code}m{text}\033[0m"


def _print_table(headers: list[str], rows: list[list[str]], is_tty: bool = True) -> None:
    if not headers or not rows:
        return
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, val in enumerate(row):
            if i < len(col_widths):
                col_widths[i] = max(col_widths[i], len(str(val)))
    header_str = "  ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
    sep_str = "  ".join("-" * col_widths[i] for i in range(len(headers)))
    print(_colorize(header_str, "1;36", is_tty))
    print(_colorize(sep_str, "90", is_tty))
    for row in rows:
        line = "  ".join(str(row[i]).ljust(col_widths[i]) if i < len(row) else "".ljust(col_widths[i]) for i in range(len(headers)))
        print(line)


def _print_error_card(res: dict[str, Any], is_tty: bool = True) -> None:
    raw_err = res.get("error", "Unknown error")
    title = res.get("cause_title", "")
    expl = res.get("cause_explanation", "")
    act = res.get("cause_action", "")
    url = res.get("dashboard_url", "")
    perm = res.get("required_perm", "")

    title_ar = res.get("cause_title_ar", "")
    expl_ar = res.get("cause_explanation_ar", "")
    act_ar = res.get("cause_action_ar", "")

    print(_colorize(f"\n✖ Error: {raw_err}", "1;31", is_tty), file=sys.stderr)
    if title:
        print(_colorize(f"  [Root Cause] {title}", "1;33", is_tty), file=sys.stderr)
    if expl:
        print(f"  {expl}", file=sys.stderr)
    if perm:
        print(_colorize(f"  Required Token Scope: {perm}", "1;36", is_tty), file=sys.stderr)
    if act:
        print(_colorize(f"  [Suggested Fix] {act}", "1;32", is_tty), file=sys.stderr)
    if url:
        print(_colorize(f"  Dashboard Link: {url}", "4;34", is_tty), file=sys.stderr)

    if title_ar and title_ar != title:
        print(_colorize(f"  (عربي) {title_ar}: {act_ar or expl_ar}", "90", is_tty), file=sys.stderr)

    print(file=sys.stderr)


# ── Main CLI Dispatch ────────────────────────────────────────────────────────

def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    is_json = "--json" in argv
    clean_argv = [a for a in argv if a != "--json"]
    cmd = clean_argv[0] if clean_argv else "status"
    is_tty = sys.stdout.isatty() and not is_json

    gh = GitHubClient()

    try:
        if cmd == "status":
            st = gh.get_status()
            if is_json:
                print(json.dumps(st, indent=2))
                return 0
            print(_colorize("GitHub Account Status", "1;34", is_tty))
            print("=" * 35)
            if st.get("configured"):
                print(f"  Active User:    {_colorize(st.get('username', 'N/A'), '1;32', is_tty)} ({st.get('account_name', '')})")
                print(f"  Email:          {st.get('email') or 'N/A'}")
                print(f"  Token:          {st.get('token_masked')}")
                scopes = ", ".join(st.get("scopes", [])) or "No explicit scopes"
                print(f"  Scopes:         {_colorize(scopes, '1;36', is_tty)}")
                print(f"  Status:         {_colorize('Connected', '1;32', is_tty)}")
                tot = st.get("total_accounts", 1)
                if tot > 1:
                    print(f"  Total Accounts: {tot} linked (use 'laravel-dev gh accounts' or 'laravel-dev gh switch')")
            else:
                print(f"  Status:         {_colorize('Not Configured', '1;33', is_tty)}")
                print("  Run 'laravel-dev gh auth' to connect your Personal Access Token.")
            return 0

        elif cmd in ("accounts", "account-list"):
            accs = gh.list_stored_accounts()
            if is_json:
                print(json.dumps({"ok": True, "accounts": accs}, indent=2))
                return 0
            if not accs:
                print(_colorize("No GitHub accounts linked.", "1;33", is_tty))
                print("Run 'laravel-dev gh auth' to connect an account.")
                return 0
            print(_colorize(f"Linked GitHub Accounts ({len(accs)} total):", "1;34", is_tty))
            rows = [
                [
                    "✔ Active" if a.get("is_active") else "",
                    a.get("username", ""),
                    a.get("account_name", ""),
                    a.get("email", ""),
                    a.get("token_preview", ""),
                ]
                for a in accs
            ]
            _print_table(["Status", "Username", "Label", "Email", "Token"], rows, is_tty)
            return 0

        elif cmd in ("switch", "use"):
            target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target:
                print(_colorize("Usage: laravel-dev gh switch <username_or_label>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = gh.switch_account(target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Switched active GitHub account to: {res.get('username')} ({res.get('account_name')})", "1;32", is_tty))
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd in ("remove", "rm"):
            target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target:
                print(_colorize("Usage: laravel-dev gh remove <username_or_label>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = gh.remove_account(target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Removed account: {res.get('removed_name')} ({res.get('removed_id')})", "1;32", is_tty))
                if res.get("remaining_count"):
                    print(f"  Active account is now: {res.get('new_active_id')}")
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd == "auth":
            token = clean_argv[1] if len(clean_argv) > 1 and not clean_argv[1].startswith("--") else ""
            custom_name = ""
            for i, a in enumerate(clean_argv):
                if a == "--name" and i + 1 < len(clean_argv):
                    custom_name = clean_argv[i + 1]

            if not token:
                if is_tty:
                    import getpass
                    token = getpass.getpass("Enter GitHub Personal Access Token (PAT): ").strip()
                else:
                    token = sys.stdin.read().strip()
            if not token:
                print(_colorize("Error: API token cannot be empty.", "1;31", is_tty), file=sys.stderr)
                return 1

            verify = gh.verify_token(token)
            if not verify.get("valid"):
                if is_json:
                    print(json.dumps(verify, indent=2))
                else:
                    _print_error_card(verify, is_tty)
                return 1

            username = verify.get("username", "")
            name = custom_name or verify.get("name", "") or username
            gh.save_credentials(
                token=token,
                username=username,
                account_name=name,
                avatar_url=verify.get("avatar_url", ""),
                email=verify.get("email", ""),
                scopes=verify.get("scopes", []),
                make_active=True,
            )

            if is_json:
                print(json.dumps({"ok": True, "username": username, "account_name": name}))
            else:
                print(_colorize(f"✔ GitHub account connected successfully: {username} ({name})!", "1;32", is_tty))
                scopes_str = ", ".join(verify.get("scopes", [])) or "none"
                print(f"  Scopes granted: {_colorize(scopes_str, '1;36', is_tty)}")
            return 0

        elif cmd in ("logout", "disconnect"):
            gh.clear_credentials()
            if is_json:
                print(json.dumps({"ok": True}))
            else:
                print(_colorize("✔ GitHub credentials removed.", "1;32", is_tty))
            return 0

        elif cmd in ("repos", "repo-list"):
            vis = "all"
            for a in clean_argv:
                if a in ("public", "private", "forks"):
                    vis = a
            res = gh.list_repos(visibility=vis)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if not res.get("ok"):
                _print_error_card(res, is_tty)
                return 1
            repos = res.get("repos", [])
            print(_colorize(f"GitHub Repositories ({len(repos)} total):", "1;34", is_tty))
            rows = [
                [
                    r.get("full_name", ""),
                    "Private" if r.get("private") else "Public",
                    r.get("language") or "-",
                    f"⭐ {r.get('stargazers_count', 0)}",
                    r.get("default_branch", "main"),
                    (r.get("updated_at") or "")[:10],
                ]
                for r in repos
            ]
            _print_table(["Repository", "Visibility", "Lang", "Stars", "Branch", "Updated"], rows, is_tty)
            return 0

        elif cmd in ("repo", "repository"):
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "create":
                name = clean_argv[2] if len(clean_argv) > 2 else ""
                if not name:
                    print(_colorize("Usage: laravel-dev gh repo create <name> [--public] [--desc '...']", "1;33", is_tty), file=sys.stderr)
                    return 1
                is_public = "--public" in argv
                desc = ""
                for i, a in enumerate(clean_argv):
                    if a == "--desc" and i + 1 < len(clean_argv):
                        desc = clean_argv[i + 1]

                res = gh.create_repo(name=name, description=desc, private=not is_public)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Repository '{res.get('full_name')}' created successfully!", "1;32", is_tty))
                    print(f"  URL: {res.get('html_url')}")
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "delete":
                target = clean_argv[2] if len(clean_argv) > 2 else ""
                if not target:
                    print(_colorize("Usage: laravel-dev gh repo delete <owner/repo>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = gh.delete_repo(target)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Repository '{target}' deleted.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "clone":
                target = clean_argv[2] if len(clean_argv) > 2 else ""
                dest = clean_argv[3] if len(clean_argv) > 3 else ""
                if not target:
                    print(_colorize("Usage: laravel-dev gh repo clone <owner/repo> [target_dir]", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = gh.clone_repo(target, dest)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Cloned '{target}' successfully to: {res.get('destination')}", "1;32", is_tty))
                    print(f"  Registered as site '{res.get('site_name')}'")
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd in ("pr", "pulls", "pull-request"):
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "list":
                repo_target = clean_argv[2] if len(clean_argv) > 2 and "/" in clean_argv[2] else ""
                if not repo_target:
                    print(_colorize("Usage: laravel-dev gh pr list <owner/repo> [--state open|closed|all]", "1;33", is_tty), file=sys.stderr)
                    return 1
                owner, repo = repo_target.split("/", 1)
                st_filter = "open"
                for a in clean_argv:
                    if a in ("closed", "all"):
                        st_filter = a
                res = gh.list_pulls(owner, repo, state=st_filter)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                prs = res.get("pulls", [])
                print(_colorize(f"Pull Requests for {repo_target} ({len(prs)} total):", "1;34", is_tty))
                rows = [
                    [f"#{p.get('number')}", p.get("title", ""), p.get("user", ""), f"{p.get('head')} -> {p.get('base')}", p.get("state", "")]
                    for p in prs
                ]
                _print_table(["#", "Title", "Author", "Branches", "State"], rows, is_tty)
                return 0

            elif sub == "merge":
                repo_target = clean_argv[2] if len(clean_argv) > 2 else ""
                num_str = clean_argv[3] if len(clean_argv) > 3 else ""
                if not repo_target or not num_str.isdigit():
                    print(_colorize("Usage: laravel-dev gh pr merge <owner/repo> <pr_number> [--squash|--rebase]", "1;33", is_tty), file=sys.stderr)
                    return 1
                method = "squash" if "--squash" in argv else ("rebase" if "--rebase" in argv else "merge")
                owner, repo = repo_target.split("/", 1)
                res = gh.merge_pull(owner, repo, int(num_str), merge_method=method)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Pull request #{num_str} merged successfully ({method})!", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd in ("issues", "issue"):
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "list":
                repo_target = clean_argv[2] if len(clean_argv) > 2 and "/" in clean_argv[2] else ""
                if not repo_target:
                    print(_colorize("Usage: laravel-dev gh issues list <owner/repo> [--state open|closed]", "1;33", is_tty), file=sys.stderr)
                    return 1
                owner, repo = repo_target.split("/", 1)
                st_filter = "closed" if "--closed" in argv else "open"
                res = gh.list_issues(owner, repo, state=st_filter)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                issues = res.get("issues", [])
                print(_colorize(f"Issues for {repo_target} ({len(issues)} total):", "1;34", is_tty))
                rows = [
                    [f"#{i.get('number')}", i.get("title", ""), i.get("user", ""), ",".join(i.get("labels", [])), i.get("state", "")]
                    for i in issues
                ]
                _print_table(["#", "Title", "Author", "Labels", "State"], rows, is_tty)
                return 0

        elif cmd in ("actions", "runs"):
            repo_target = clean_argv[1] if len(clean_argv) > 1 and "/" in clean_argv[1] else ""
            if not repo_target:
                print(_colorize("Usage: laravel-dev gh actions <owner/repo>", "1;33", is_tty), file=sys.stderr)
                return 1
            owner, repo = repo_target.split("/", 1)
            res = gh.list_workflow_runs(owner, repo)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if not res.get("ok"):
                _print_error_card(res, is_tty)
                return 1
            runs = res.get("runs", [])
            print(_colorize(f"GitHub Actions runs for {repo_target} ({len(runs)} total):", "1;34", is_tty))
            rows = [
                [
                    str(r.get("id")),
                    r.get("name", ""),
                    r.get("head_branch", ""),
                    r.get("conclusion") or r.get("status", ""),
                    (r.get("created_at") or "")[:19].replace("T", " "),
                ]
                for r in runs
            ]
            _print_table(["Run ID", "Workflow", "Branch", "Status", "Started"], rows, is_tty)
            return 0

        elif cmd == "publish":
            site_target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not site_target:
                print(_colorize("Usage: laravel-dev gh publish <site_name_or_path> [--public] [--name 'repo_name']", "1;33", is_tty), file=sys.stderr)
                return 1
            is_public = "--public" in argv
            custom_repo = ""
            for i, a in enumerate(clean_argv):
                if a == "--name" and i + 1 < len(clean_argv):
                    custom_repo = clean_argv[i + 1]

            res = gh.publish_site(site_target, repo_name=custom_repo, private=not is_public)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Site '{site_target}' published to GitHub successfully!", "1;32", is_tty))
                print(f"  Repository: {res.get('full_name')}")
                print(f"  URL:        {res.get('html_url')}")
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd == "link":
            site_target = clean_argv[1] if len(clean_argv) > 1 else ""
            repo_target = clean_argv[2] if len(clean_argv) > 2 else ""
            if not site_target or not repo_target:
                print(_colorize("Usage: laravel-dev gh link <site_name_or_path> <owner/repo>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = gh.link_site(site_target, repo_target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Site '{site_target}' linked to GitHub repository '{repo_target}'!", "1;32", is_tty))
                return 0
            _print_error_card(res, is_tty)
            return 1

        else:
            print(_colorize(f"Unknown command '{cmd}'.", "1;31", is_tty), file=sys.stderr)
            print("Available commands: status, auth, logout, accounts, switch, remove, repos, repo, pr, issues, actions, publish, link", file=sys.stderr)
            return 1

    except KeyboardInterrupt:
        print("\nAborted.")
        return 130
    except Exception as exc:
        if is_json:
            print(json.dumps({"ok": False, "error": str(exc)}))
        else:
            print(_colorize(f"Fatal error: {exc}", "1;31", is_tty), file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
