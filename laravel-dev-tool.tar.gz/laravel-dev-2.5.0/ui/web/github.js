"use strict";

/* ── GitHub Hub: Centralized GitHub Management for Laravel Dev ──
   Manages Multi-Account GitHub PATs, Repositories, Pull Requests, Issues,
   Actions / CI Workflows, and 1-Click Local Laravel Site Publishing. */

const GitHub = (() => {
  const S = {
    status: {
      configured: false,
      username: "",
      account_name: "",
      avatar_url: "",
      email: "",
      scopes: [],
      rate_limit_remaining: null,
      rate_limit_total: null,
      total_accounts: 0,
    },
    tab: "overview", // overview | repos | pulls | issues | actions | sites
    accounts: [],
    activeAccountId: "",
    repos: [],
    reposFilter: "all", // all | public | private | forks
    reposSearch: "",
    reposSort: "updated", // updated | stars | name
    selectedRepo: "", // e.g. "owner/repo"
    pulls: [],
    pullsFilter: "open", // open | closed | all
    issues: [],
    issuesFilter: "open", // open | closed
    actions: [],
    workflows: [],
    sites: [],
    sitesGitStatus: {}, // siteName -> gitStatus
    errorObj: null,
    reposErrorObj: null,
    pullsErrorObj: null,
    issuesErrorObj: null,
    actionsErrorObj: null,
    sitesErrorObj: null,
    loadingPulls: false,
    loadingIssues: false,
    loadingActions: false,
    loadingRepos: false,
    loadingSites: false,
    error: "",
    unreadNotifs: 0,
  };

  const view = () => $("#view-github");

  async function init() {
    window.GitHubExplorer?.setRenderCallback?.(render);
    await refreshStatus();
    if (S.status.configured) {
      loadRepos();
      loadUnreadBadge();
    }
    window.addEventListener("langchange", () => {
      const root = view();
      if (root && !root.hidden) {
        render();
      }
    });
  }

  async function loadUnreadBadge() {
    try {
      const res = await LD.call("gh_notifications", { all: false, per_page: 20 });
      if (res && res.ok) {
        S.unreadNotifs = (res.notifications || []).filter((n) => n.unread).length;
        const root = view();
        if (root && !root.hidden) render();
      }
    } catch (_) {}
  }

  function openRepoFromBrowser(repoFullName) {
    if (!repoFullName) return;
    if (window.App && typeof window.App.setView === "function") {
      window.App.setView("github");
    }
    S.tab = "repos";
    window.GitHubExplorer?.openRepo?.(repoFullName, "code");
  }

  function cloneFromBrowser(repoFullName) {
    if (!repoFullName) return;
    openCloneRepoModal(repoFullName);
  }

  async function show() {
    if (!S.status.configured) {
      await refreshStatus();
    }
    if (S.status.configured && !S.repos.length) {
      await loadRepos();
    }
    render();
  }

  async function refreshStatus() {
    try {
      const res = await LD.call("gh_status");
      S.status = res || { configured: false };
      if (S.status.configured) {
        await loadAccounts();
      }
    } catch (e) {
      S.status = { configured: false };
      S.error = e.message || String(e);
    }
  }

  async function loadAccounts() {
    try {
      const res = await LD.call("gh_accounts");
      if (res && res.ok) {
        S.accounts = res.accounts || [];
        S.activeAccountId = res.active_id || "";
      }
    } catch (e) {
      console.warn("Failed to load GitHub accounts:", e);
    }
  }

  async function switchAccount(accountId) {
    if (!accountId) return;
    try {
      const res = await LD.call("gh_switch_account", { account_id: accountId });
      if (res && res.ok) {
        toast("success", "Switched GitHub Account", res.username || accountId);
        await refreshStatus();
        await loadRepos();
        if (S.tab === "pulls") await loadPulls();
        else if (S.tab === "issues") await loadIssues();
        else if (S.tab === "actions") await loadActions();
        else if (S.tab === "sites") await loadSitesGitStatus();
        render();
      } else {
        toast("error", "Failed to switch account", res?.error || "Unknown error");
      }
    } catch (err) {
      toast("error", "Account Switch Error", err.message || String(err));
    }
  }

  async function loadRepos() {
    S.loadingRepos = true;
    S.reposErrorObj = null;
    try {
      const res = await LD.call("gh_repos", { visibility: "all" });
      if (res && res.ok) {
        S.repos = res.repos || [];
        if (!S.selectedRepo && S.repos.length > 0) {
          S.selectedRepo = S.repos[0].full_name;
        }
      } else {
        S.reposErrorObj = res;
      }
    } catch (e) {
      S.reposErrorObj = { error: e.message || String(e) };
    } finally {
      S.loadingRepos = false;
      render();
    }
  }

  async function loadPulls(repo) {
    const target = repo || S.selectedRepo;
    if (!target || !target.includes("/")) return;
    const [owner, name] = target.split("/");
    S.loadingPulls = true;
    S.pullsErrorObj = null;
    render();
    try {
      const res = await LD.call("gh_pulls", { owner, repo: name, state: S.pullsFilter });
      if (res && res.ok) {
        S.pulls = res.pulls || [];
      } else {
        S.pullsErrorObj = res;
      }
    } catch (e) {
      S.pullsErrorObj = { error: e.message || String(e) };
    } finally {
      S.loadingPulls = false;
      render();
    }
  }

  async function loadIssues(repo) {
    const target = repo || S.selectedRepo;
    if (!target || !target.includes("/")) return;
    const [owner, name] = target.split("/");
    S.loadingIssues = true;
    S.issuesErrorObj = null;
    render();
    try {
      const res = await LD.call("gh_issues", { owner, repo: name, state: S.issuesFilter });
      if (res && res.ok) {
        S.issues = res.issues || [];
      } else {
        S.issuesErrorObj = res;
      }
    } catch (e) {
      S.issuesErrorObj = { error: e.message || String(e) };
    } finally {
      S.loadingIssues = false;
      render();
    }
  }

  async function loadActions(repo) {
    const target = repo || S.selectedRepo;
    if (!target || !target.includes("/")) return;
    const [owner, name] = target.split("/");
    S.loadingActions = true;
    S.actionsErrorObj = null;
    render();
    try {
      const [res, wfRes] = await Promise.all([
        LD.call("gh_actions", { owner, repo: name }),
        LD.call("gh_workflows", { owner, repo: name }).catch(() => null),
      ]);
      if (res && res.ok) {
        S.actions = res.runs || [];
      } else {
        S.actionsErrorObj = res;
      }
      S.workflows = wfRes?.ok ? (wfRes.workflows || []) : [];
    } catch (e) {
      S.actionsErrorObj = { error: e.message || String(e) };
    } finally {
      S.loadingActions = false;
      render();
    }
  }

  async function loadSitesGitStatus() {
    S.loadingSites = true;
    S.sitesErrorObj = null;
    const sites = state.sites || [];
    S.sites = sites;
    render();

    try {
      await Promise.all(
        sites.map(async (site) => {
          try {
            const res = await LD.call("gh_site_git_status", { site: site.name });
            if (res && res.ok) {
              S.sitesGitStatus[site.name] = res;
            }
          } catch (e) {
            console.warn(`Git status check failed for site ${site.name}:`, e);
          }
        })
      );
    } finally {
      S.loadingSites = false;
      render();
    }
  }

  // ── Smart Bilingual Error Banner ───────────────────────────────────────────
  function renderErrorBanner(err, retryBtnId = "") {
    if (!err || (!err.error && !err.cause_title)) return "";
    const isAr = (window.I18N && window.I18N.getLang && window.I18N.getLang() === "ar");

    const rawTitle = (isAr ? err.cause_title_ar : null) || err.cause_title;
    const title = rawTitle || t("gh_err_notice", "GitHub Notice");

    const rawExplanation = (isAr ? err.cause_explanation_ar : null) || err.cause_explanation;
    const explanation = rawExplanation || err.error || t("gh_err_default", "An error occurred while communicating with GitHub API.");

    const rawAction = (isAr ? err.cause_action_ar : null) || err.cause_action;
    const action = rawAction || "";

    const url = err.dashboard_url || "";
    const perm = err.required_perm || "";
    const code = err.error_code || err.status_code || "";

    const lblCause = t("gh_err_cause", "Root Cause:");
    const lblPerm = t("gh_err_required_scope", "Required Token Scope:");
    const lblAction = t("gh_err_suggested_action", "Suggested Fix:");
    const lblOpenGh = t("gh_err_open_github", "Open on GitHub");
    const lblRetry = t("gh_err_retry", "Retry");

    return `
      <div class="card" style="margin:0 0 16px 0;padding:16px 20px;border-inline-start:4px solid var(--red);background:var(--surface);display:flex;flex-direction:column;gap:12px;box-shadow:var(--shadow-sm)">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:10px">
          <div style="display:flex;align-items:center;gap:12px">
            <div style="width:38px;height:38px;border-radius:10px;background:rgba(239, 68, 68, 0.12);color:var(--red);display:grid;place-items:center;flex-shrink:0">
              ${icon("alert")}
            </div>
            <div>
              <b style="font-size:14px;color:var(--red);display:block">${esc(title)}</b>
              <div class="muted sm" style="font-family:var(--mono);font-size:11px;margin-top:2px">
                ${code ? `Status: ${esc(code)} · ` : ""}${esc(err.error || title)}
              </div>
            </div>
          </div>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            ${url ? `
              <a href="${esc(url)}" target="_blank" rel="noopener noreferrer" class="btn sm ghost" style="display:inline-flex;align-items:center;gap:6px;color:var(--accent)">
                ${icon("browser")}<span>${esc(lblOpenGh)}</span>
              </a>
            ` : ""}
            ${retryBtnId ? `
              <button class="btn sm" id="${esc(retryBtnId)}" style="display:inline-flex;align-items:center;gap:6px">
                ${icon("refresh")}<span>${esc(lblRetry)}</span>
              </button>
            ` : ""}
          </div>
        </div>

        <div style="background:var(--bg);padding:12px 14px;border-radius:8px;font-size:13px;line-height:1.55;display:flex;flex-direction:column;gap:8px">
          <div>
            <span class="muted" style="font-weight:600;margin-inline-end:6px">${esc(lblCause)}</span>
            <span>${esc(explanation)}</span>
          </div>
          ${perm ? `
            <div>
              <span class="muted" style="font-weight:600;margin-inline-end:6px">${esc(lblPerm)}</span>
              <code style="background:rgba(245, 48, 3, 0.1);color:var(--red);padding:2px 8px;border-radius:4px;font-family:var(--mono);font-size:12px;font-weight:600">${esc(perm)}</code>
            </div>
          ` : ""}
          ${action ? `
            <div style="color:var(--green)">
              <span style="font-weight:600;margin-inline-end:6px">${esc(lblAction)}</span>
              <span>${esc(action)}</span>
            </div>
          ` : ""}
        </div>
      </div>
    `;
  }

  // ── Render Entrypoint ──────────────────────────────────────────────────────
  function render() {
    const root = view();
    if (!root) return;

    if (!S.status.configured) {
      renderSetup(root);
    } else {
      renderHub(root);
    }
  }

  // ── Setup View (Connect GitHub Account) ─────────────────────────────────────
  function renderSetup(root) {
    const tokenHelpUrl = "https://github.com/settings/tokens/new?scopes=repo,workflow,read:org,admin:public_key&description=Laravel+Dev+Tool";

    root.innerHTML = `
      <header class="view-header">
        <div>
          <h1>${icon("git", "mr-2")}<span data-i18n="github">GitHub</span></h1>
          <p class="subtitle" data-i18n="gh_subtitle">Connect your GitHub Personal Access Token to manage repositories, PRs, CI workflows, and 1-click site publishing.</p>
        </div>
        <div class="header-actions" style="display:flex;gap:8px;align-items:center;">
          <button type="button" class="btn sm" id="gh-setup-live-web-btn">
            ${icon("globe")}<span>${window.t ? window.t("gh_live_web_btn", "Open Live GitHub Web") : "Open Live GitHub Web"}</span>
          </button>
        </div>
      </header>

      <div class="view-body" style="max-width:760px;margin:24px auto;">
        ${S.status.vault_locked ? `
          <div class="card" style="padding:16px;margin-bottom:16px;border-inline-start:4px solid var(--accent);display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
            <div>
              <b>🔒 Credential Vault Locked (${esc(S.status.username || "Saved Account")})</b>
              <p class="muted sm" style="margin:6px 0 0 0;">Unlock your Credential Vault to access your encrypted GitHub Personal Access Token.</p>
            </div>
            <button type="button" class="btn sm primary" id="gh-unlock-vault-btn">${icon("key")}<span>Unlock Vault</span></button>
          </div>
        ` : ""}
        ${S.errorObj ? renderErrorBanner(S.errorObj) : ""}

        <div class="card" style="padding:28px;">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:20px;">
            <div style="width:48px;height:48px;border-radius:12px;background:var(--accent);color:#fff;display:grid;place-items:center;font-size:24px;">
              ${icon("git")}
            </div>
            <div>
              <h2 style="margin:0;font-size:18px;">${window.t ? window.t("gh_connect_btn", "Connect GitHub") : "Connect GitHub"}</h2>
              <div class="muted sm">Fast & secure direct API access via Personal Access Token (PAT).</div>
            </div>
          </div>

          <form id="gh-auth-form" style="display:flex;flex-direction:column;gap:18px;">
            <div class="form-group">
              <label for="gh-token-input" style="font-weight:600;display:flex;justify-content:space-between;align-items:center;">
                <span data-i18n="gh_token_label">Personal Access Token (classic or fine-grained)</span>
                <a href="${tokenHelpUrl}" target="_blank" rel="noopener noreferrer" class="sm muted" style="color:var(--accent);display:inline-flex;align-items:center;gap:4px;">
                  ${icon("browser")}<span>Generate token with recommended scopes</span>
                </a>
              </label>
              <input type="password" id="gh-token-input" class="input" placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" autocomplete="off" required style="font-family:var(--mono);" />
              <div class="muted sm" style="margin-top:4px;">
                Recommended scopes: <code>repo</code>, <code>workflow</code>, <code>read:org</code>, <code>admin:public_key</code>.
              </div>
            </div>

            <div class="form-group">
              <label for="gh-name-input" style="font-weight:600;" data-i18n="gh_custom_name">Custom Account Label (optional)</label>
              <input type="text" id="gh-name-input" class="input" placeholder="e.g. Personal, Work, Freelance" />
            </div>

            <div style="background:var(--bg);padding:14px 16px;border-radius:8px;font-size:13px;line-height:1.5;">
              <b style="display:block;margin-bottom:6px;">Multi-Account Support:</b>
              You can connect multiple GitHub accounts (e.g. personal and client organizations) and switch between them at any time.
            </div>

            <div style="display:flex;gap:12px;margin-top:6px;">
              <button type="submit" class="btn primary" id="gh-connect-submit" style="display:inline-flex;align-items:center;gap:8px;">
                ${icon("check")}<span>${window.t ? window.t("gh_connect_btn", "Connect GitHub") : "Connect GitHub"}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    `;

    $("#gh-setup-live-web-btn")?.addEventListener("click", () => {
      LD.call("gh_browser_open", { url: "https://github.com/login" });
    });

    $("#gh-unlock-vault-btn")?.addEventListener("click", async () => {
      const pw = prompt("Enter Vault Master Password:");
      if (!pw) return;
      try {
        await LD.call("vault_unlock", { password: pw });
        toast("success", "Vault Unlocked");
        await refresh();
      } catch (err) {
        toast("error", "Vault Unlock Failed", err.message);
      }
    });

    $("#gh-auth-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const token = $("#gh-token-input")?.value.trim();
      const label = $("#gh-name-input")?.value.trim();
      if (!token) return;

      const submitBtn = $("#gh-connect-submit");
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Verifying...</span>`;
      }

      try {
        const verify = await LD.call("gh_verify_token", { token });
        if (!verify.valid) {
          S.errorObj = verify;
          render();
          return;
        }

        const username = verify.username || "";
        const saveRes = await LD.call("gh_save_credentials", {
          token,
          username,
          account_name: label || verify.name || username,
          avatar_url: verify.avatar_url || "",
          email: verify.email || "",
          scopes: verify.scopes || [],
        });

        if (saveRes.ok) {
          S.errorObj = null;
          await refreshStatus();
          await loadRepos();
          render();
          toast("success", "GitHub connected successfully", username);
        } else {
          S.errorObj = saveRes;
          render();
        }
      } catch (err) {
        S.errorObj = { error: err.message || String(err) };
        render();
      }
    });
  }

  // ── Main Hub View ──────────────────────────────────────────────────────────
  const ghStr = (k, fb) => (window.t ? window.t(k, fb) : fb);

  function renderHub(root) {
    const user = S.status.username || "GitHub User";
    const label = S.status.account_name || user;
    const avatar = S.status.avatar_url || "";
    const totalAccs = S.accounts.length || S.status.total_accounts || 1;
    const langColors = window.GitHubExplorer?.LANG_COLORS || {};

    root.innerHTML = `
      <header class="view-header gh-hub-header">
        <div class="gh-identity">
          ${avatar ? `
            <img src="${esc(avatar)}" alt="${esc(user)}" class="gh-avatar" />
          ` : `
            <div class="gh-avatar-fallback">${esc(user[0].toUpperCase())}</div>
          `}
          <div class="gh-identity-meta">
            <div class="gh-identity-row">
              <h1>${esc(user)}</h1>
              ${label !== user ? `<span class="chip sm">${esc(label)}</span>` : ""}
              ${S.status.rate_limit_remaining !== null ? `
                <span class="chip sm muted mono" title="${esc(ghStr("gh_rate_limit", "API Rate Limit Remaining"))}">
                  ${S.status.rate_limit_remaining}/${S.status.rate_limit_total || 5000} API
                </span>
              ` : ""}
            </div>
            <p class="subtitle">
              ${S.status.email ? `<span>${esc(S.status.email)} · </span>` : ""}
              <span>${totalAccs > 1 ? `${totalAccs} ${esc(ghStr("gh_accounts_linked", "accounts linked"))}` : esc(ghStr("gh_connected", "Connected"))}</span>
            </p>
          </div>
        </div>

        <div class="gh-header-controls">
          <form id="gh-topbar-search-form" class="gh-search-pill">
            <span class="gh-search-ic">${icon("search")}</span>
            <input type="text" id="gh-topbar-search-input" class="input sm" placeholder="${esc(ghStr("gh_search_placeholder", "Search GitHub…"))}" value="${esc(window.GitHubExplorer?.state?.searchQuery || "")}" />
          </form>

          <button type="button" class="btn sm ${S.unreadNotifs > 0 ? "primary" : "ghost"}" id="gh-notif-pill" title="${esc(ghStr("gh_tab_notifications", "Notifications"))}">
            ${icon("mail")}
            ${S.unreadNotifs > 0 ? `<span class="chip sm">${S.unreadNotifs}</span>` : ""}
          </button>

          <button type="button" class="btn sm" id="gh-live-web-btn" title="${esc(ghStr("gh_live_web_tip", "Open Full GitHub Website inside App"))}">
            ${icon("globe")}<span>${esc(ghStr("gh_live_web_btn", "Live GitHub Web"))}</span>
          </button>

          <div class="gh-account-pill">
            <span class="gh-account-pill-label">${icon("git")}</span>
            <select id="gh-account-select" aria-label="GitHub Account">
              ${S.accounts.map((a) => `
                <option value="${esc(a.account_id)}" ${a.is_active ? "selected" : ""}>
                  ${esc(a.account_name || a.username)} ${a.is_active ? "✔" : ""}
                </option>
              `).join("")}
            </select>
            <button type="button" class="btn xs ghost" id="btn-gh-add-account" title="${esc(ghStr("gh_add_account", "Add Another GitHub Account"))}">${icon("plus")}</button>
            <button type="button" class="btn xs ghost" id="btn-gh-manage-accounts" title="${esc(ghStr("gh_manage_accounts", "Manage Accounts"))}">${icon("settings")}</button>
            <button type="button" class="btn xs ghost danger" id="gh-disconnect-btn" title="${esc(ghStr("gh_disconnect", "Disconnect Account"))}">${icon("unlink")}</button>
          </div>

          <button type="button" class="btn sm primary" id="gh-new-repo-btn">
            ${icon("plus")}<span>${esc(ghStr("gh_new_repo", "New Repo"))}</span>
          </button>

          <button type="button" class="btn sm icon-btn ghost" id="gh-refresh-btn" title="${esc(ghStr("refresh", "Refresh"))}">
            ${icon("refresh")}
          </button>
        </div>
      </header>

      <div class="gh-sub-nav">
        <button class="tab-btn ${S.tab === "overview" ? "active" : ""}" data-tab="overview">
          ${icon("home")}<span>${esc(ghStr("gh_tab_overview", "Overview"))}</span>
        </button>
        <button class="tab-btn ${S.tab === "repos" ? "active" : ""}" data-tab="repos">
          ${icon("folder")}<span>${esc(ghStr("gh_tab_repos", "Repositories"))}</span>
          <span class="chip sm">${S.repos.length}</span>
        </button>
        <button class="tab-btn ${S.tab === "notifications" ? "active" : ""}" data-tab="notifications">
          ${icon("alert")}<span>${esc(ghStr("gh_tab_notifications", "Notifications"))}</span>
          ${S.unreadNotifs > 0 ? `<span class="chip sm primary">${S.unreadNotifs}</span>` : ""}
        </button>
        <button class="tab-btn ${S.tab === "pulls" ? "active" : ""}" data-tab="pulls">
          ${icon("branch")}<span>${esc(ghStr("gh_tab_pulls", "Pull Requests"))}</span>
        </button>
        <button class="tab-btn ${S.tab === "issues" ? "active" : ""}" data-tab="issues">
          ${icon("bug")}<span>${esc(ghStr("gh_tab_issues", "Issues"))}</span>
        </button>
        <button class="tab-btn ${S.tab === "actions" ? "active" : ""}" data-tab="actions">
          ${icon("play")}<span>${esc(ghStr("gh_tab_actions", "Actions & CI"))}</span>
        </button>
        <button class="tab-btn ${S.tab === "gists" ? "active" : ""}" data-tab="gists">
          ${icon("code")}<span>${esc(ghStr("gh_tab_gists", "Gists"))}</span>
        </button>
        <button class="tab-btn ${S.tab === "search" ? "active" : ""}" data-tab="search">
          ${icon("search")}<span>${esc(ghStr("gh_tab_search", "Search"))}</span>
        </button>
        <button class="tab-btn ${S.tab === "profile" ? "active" : ""}" data-tab="profile">
          ${icon("globe")}<span>${esc(ghStr("gh_tab_profile", "Profile & Orgs"))}</span>
        </button>
        <button class="tab-btn ${S.tab === "sites" ? "active" : ""}" data-tab="sites">
          ${icon("rocket")}<span>${esc(ghStr("gh_tab_sites", "Local Sites"))}</span>
          <span class="chip sm">${(state.sites || []).length}</span>
        </button>
      </div>

      <div class="view-body gh-hub-body">
        ${S.tab === "overview" ? renderOverviewTab() : ""}
        ${S.tab === "repos" ? (window.GitHubExplorer?.state?.activeRepo
          ? window.GitHubExplorer.renderRepoWorkspace(S, { renderPullsTab, renderIssuesTab, renderActionsTab })
          : renderReposTab(langColors)) : ""}
        ${S.tab === "notifications" ? (window.GitHubExplorer ? window.GitHubExplorer.renderNotificationsTab() : "") : ""}
        ${S.tab === "pulls" ? renderPullsTab() : ""}
        ${S.tab === "issues" ? renderIssuesTab() : ""}
        ${S.tab === "actions" ? renderActionsTab() : ""}
        ${S.tab === "gists" ? (window.GitHubExplorer ? window.GitHubExplorer.renderGistsTab() : "") : ""}
        ${S.tab === "search" ? (window.GitHubExplorer ? window.GitHubExplorer.renderSearchTab() : "") : ""}
        ${S.tab === "profile" ? (window.GitHubExplorer ? window.GitHubExplorer.renderProfileTab() : "") : ""}
        ${S.tab === "sites" ? renderSitesTab() : ""}
      </div>
    `;

    bindHubEvents(root);
  }

  // ── Tab 1: Overview ────────────────────────────────────────────────────────
  function renderOverviewTab() {
    const totalRepos = S.repos.length;
    const publicRepos = S.repos.filter((r) => !r.private).length;
    const privateRepos = S.repos.filter((r) => r.private).length;
    const forkRepos = S.repos.filter((r) => r.fork).length;
    const totalStars = S.repos.reduce((acc, r) => acc + (r.stargazers_count || 0), 0);
    const scopes = S.status.scopes || [];

    return `
      <div class="gh-stack">
        ${S.errorObj ? renderErrorBanner(S.errorObj) : ""}

        <div class="gh-stat-grid">
          <div class="card gh-stat-card accent-neutral">
            <span class="gh-stat-label">${icon("folder")} ${esc(ghStr("gh_total_repos", "Total Repositories"))}</span>
            <b class="gh-stat-val">${totalRepos}</b>
          </div>
          <div class="card gh-stat-card accent-green">
            <span class="gh-stat-label">${icon("globe")} ${esc(ghStr("gh_public_repos", "Public Repos"))}</span>
            <b class="gh-stat-val" style="color:var(--green)">${publicRepos}</b>
          </div>
          <div class="card gh-stat-card accent-primary">
            <span class="gh-stat-label">${icon("lock")} ${esc(ghStr("gh_private_repos", "Private Repos"))}</span>
            <b class="gh-stat-val" style="color:var(--accent)">${privateRepos}</b>
          </div>
          <div class="card gh-stat-card accent-purple">
            <span class="gh-stat-label">${icon("branch")} ${esc(ghStr("gh_forks", "Forks"))}</span>
            <b class="gh-stat-val">${forkRepos}</b>
          </div>
          <div class="card gh-stat-card accent-gold">
            <span class="gh-stat-label">${icon("sparkles")} ${esc(ghStr("gh_total_stars", "Total Stars"))}</span>
            <b class="gh-stat-val" style="color:var(--yellow, #eab308)">${totalStars}</b>
          </div>
        </div>

        <div class="grid-2">
          <div class="card gh-panel">
            <h3>${icon("rocket")} ${esc(ghStr("gh_quick_actions", "Quick Actions"))}</h3>
            <div class="gh-quick-actions">
              <button type="button" class="btn sm primary" id="ov-new-repo">
                ${icon("plus")}<span>${esc(ghStr("gh_create_repo", "Create Repository"))}</span>
              </button>
              <button type="button" class="btn sm" id="ov-publish-site">
                ${icon("upload")}<span>${esc(ghStr("gh_publish_site", "Publish Local Site"))}</span>
              </button>
              <button type="button" class="btn sm ghost" id="ov-switch-account">
                ${icon("settings")}<span>${esc(ghStr("gh_manage_accounts", "Manage Accounts"))} (${S.accounts.length})</span>
              </button>
              <button type="button" class="btn sm ghost" id="ov-open-web">
                ${icon("globe")}<span>${esc(ghStr("gh_live_web_btn", "Live GitHub Web"))}</span>
              </button>
            </div>
          </div>

          <div class="card gh-panel">
            <h3>${icon("key")} ${esc(ghStr("gh_token_scopes", "Active Token Scopes"))}</h3>
            <div class="gh-scopes-list">
              ${scopes.length ? scopes.map((s) => `
                <span class="chip sm gh-scope-chip">${esc(s)}</span>
              `).join("") : `<span class="muted sm">${esc(ghStr("gh_no_scopes", "Fine-grained token or no explicit OAuth scopes reported."))}</span>`}
            </div>
          </div>
        </div>

        ${window.GitHubExplorer ? window.GitHubExplorer.renderFeedSection(S.status.username || "") : ""}
      </div>
    `;
  }

  // ── Tab 2: Repositories ────────────────────────────────────────────────────
  function renderReposTab(langColors = {}) {
    let list = [...S.repos];
    if (S.reposFilter === "public") list = list.filter((r) => !r.private);
    if (S.reposFilter === "private") list = list.filter((r) => r.private);
    if (S.reposFilter === "forks") list = list.filter((r) => r.fork);

    if (S.reposSearch) {
      const q = S.reposSearch.toLowerCase();
      list = list.filter((r) => r.name.toLowerCase().includes(q) || (r.description || "").toLowerCase().includes(q) || (r.language || "").toLowerCase().includes(q));
    }

    if (S.reposSort === "stars") {
      list.sort((a, b) => (b.stargazers_count || 0) - (a.stargazers_count || 0));
    } else if (S.reposSort === "name") {
      list.sort((a, b) => (a.name || "").localeCompare(b.name || ""));
    } else {
      list.sort((a, b) => String(b.updated_at || "").localeCompare(String(a.updated_at || "")));
    }

    return `
      <div class="gh-stack">
        ${S.reposErrorObj ? renderErrorBanner(S.reposErrorObj, "repos-retry-btn") : ""}

        <div class="gh-repos-toolbar card">
          <div class="gh-filter-pills">
            <button type="button" class="btn sm ${S.reposFilter === "all" ? "primary" : "ghost"}" data-repofilter="all">${esc(ghStr("gh_all_repos", "All"))} (${S.repos.length})</button>
            <button type="button" class="btn sm ${S.reposFilter === "public" ? "primary" : "ghost"}" data-repofilter="public">${esc(ghStr("gh_public", "Public"))}</button>
            <button type="button" class="btn sm ${S.reposFilter === "private" ? "primary" : "ghost"}" data-repofilter="private">${esc(ghStr("gh_private", "Private"))}</button>
            <button type="button" class="btn sm ${S.reposFilter === "forks" ? "primary" : "ghost"}" data-repofilter="forks">${esc(ghStr("gh_forks", "Forks"))}</button>
          </div>

          <div class="gh-repos-controls">
            <select id="repos-sort-select" class="input sm">
              <option value="updated" ${S.reposSort === "updated" ? "selected" : ""}>${esc(ghStr("gh_sort_updated", "Recently Updated"))}</option>
              <option value="stars" ${S.reposSort === "stars" ? "selected" : ""}>${esc(ghStr("gh_sort_stars", "Most Stars"))}</option>
              <option value="name" ${S.reposSort === "name" ? "selected" : ""}>${esc(ghStr("gh_sort_name", "Name (A–Z)"))}</option>
            </select>
            <input type="text" id="repos-search-input" class="input sm" placeholder="${esc(ghStr("gh_search_repos", "Filter repos or language…"))}" value="${esc(S.reposSearch)}" />
            <button type="button" class="btn sm primary" id="tab-new-repo-btn">
              ${icon("plus")}<span>${esc(ghStr("gh_new_repo", "New Repo"))}</span>
            </button>
          </div>
        </div>

        ${S.loadingRepos ? `
          <div class="card gh-empty-card">
            <div class="muted">${icon("refresh", "spin")} Loading repositories…</div>
          </div>
        ` : list.length === 0 ? `
          <div class="card gh-empty-card">
            <div class="muted" style="margin-bottom:12px;">No repositories match the current filter.</div>
            <button type="button" class="btn sm primary" id="empty-new-repo-btn">${icon("plus")}<span>${esc(ghStr("gh_create_repo", "Create Repository"))}</span></button>
          </div>
        ` : `
          <div class="gh-repo-grid">
            ${list.map((r) => {
              const langColor = langColors[r.language] || "var(--accent)";
              return `
                <div class="card gh-repo-card">
                  <div class="gh-repo-card-top">
                    <div class="gh-repo-card-head">
                      <a href="#" class="btn-open-repo-ws gh-repo-title" data-repo="${esc(r.full_name)}">
                        ${icon(r.private ? "lock" : "folder")}<span>${esc(r.name)}</span>
                      </a>
                      <span class="chip sm ${r.private ? "gh-vis-private" : "gh-vis-public"}">
                        ${r.private ? esc(ghStr("gh_private", "Private")) : esc(ghStr("gh_public", "Public"))}
                      </span>
                    </div>
                    <p class="gh-repo-desc muted sm">
                      ${esc(r.description || "No description provided.")}
                    </p>
                  </div>

                  <div>
                    <div class="gh-repo-meta muted">
                      ${r.language ? `<span class="gh-lang-pill"><i class="gh-lang-dot" style="background:${langColor}"></i>${esc(r.language)}</span>` : ""}
                      <span>★ ${r.stargazers_count || 0}</span>
                      <span>🍴 ${r.forks_count || 0}</span>
                      <span class="gh-repo-updated">${(r.updated_at || "").slice(0, 10)}</span>
                    </div>

                    <div class="gh-repo-actions">
                      <button type="button" class="btn xs primary btn-open-repo-ws" data-repo="${esc(r.full_name)}">
                        ${icon("code")}<span>${esc(ghStr("gh_explore", "Explore"))}</span>
                      </button>
                      <button type="button" class="btn xs ghost btn-open-repo-cicd" data-repo="${esc(r.full_name)}" title="CI/CD, Secrets &amp; VPS Linker">
                        ${icon("rocket")}<span>CI/CD &amp; VPS</span>
                      </button>
                      <button type="button" class="btn xs ghost btn-clone-repo" data-repo="${esc(r.full_name)}">
                        ${icon("download")}<span>${esc(ghStr("gh_clone", "Clone"))}</span>
                      </button>
                      <button type="button" class="btn xs ghost btn-view-pulls" data-repo="${esc(r.full_name)}">
                        ${icon("branch")}<span>PRs</span>
                      </button>
                      <button type="button" class="btn xs ghost btn-view-issues" data-repo="${esc(r.full_name)}">
                        ${icon("bug")}<span>Issues</span>
                      </button>
                      <a href="${esc(r.html_url)}" target="_blank" rel="noopener noreferrer" class="btn xs ghost gh-repo-ext" title="Open on GitHub">
                        ${icon("browser")}
                      </a>
                      <button type="button" class="btn xs ghost danger btn-delete-repo" data-repo="${esc(r.full_name)}" title="Delete Repository">
                        ${icon("trash")}
                      </button>
                    </div>
                  </div>
                </div>
              `;
            }).join("")}
          </div>
        `}
      </div>
    `;
  }

  // ── Tab 3: Pull Requests ───────────────────────────────────────────────────
  function renderPullsTab() {
    return `
      <div style="display:flex;flex-direction:column;gap:16px;">
        ${S.pullsErrorObj ? renderErrorBanner(S.pullsErrorObj, "pulls-retry-btn") : ""}

        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
          <!-- Repo Selector & Filters -->
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <label style="font-weight:600;font-size:13px;">Repository:</label>
            <select id="pulls-repo-select" class="input sm" style="width:240px;">
              ${S.repos.map((r) => `
                <option value="${esc(r.full_name)}" ${r.full_name === S.selectedRepo ? "selected" : ""}>
                  ${esc(r.full_name)}
                </option>
              `).join("")}
            </select>

            <div style="display:flex;gap:4px;">
              <button class="btn sm ${S.pullsFilter === "open" ? "primary" : "ghost"}" data-prfilter="open">Open</button>
              <button class="btn sm ${S.pullsFilter === "closed" ? "primary" : "ghost"}" data-prfilter="closed">Closed</button>
              <button class="btn sm ${S.pullsFilter === "all" ? "primary" : "ghost"}" data-prfilter="all">All</button>
            </div>
          </div>

          <button class="btn sm primary" id="new-pr-btn">
            ${icon("plus")}<span>New Pull Request</span>
          </button>
        </div>

        <!-- Pull Requests List -->
        ${S.loadingPulls ? `
          <div class="card" style="padding:32px;text-align:center;">
            <div class="muted">${icon("refresh", "spin")} Loading pull requests…</div>
          </div>
        ` : S.pulls.length === 0 ? `
          <div class="card" style="padding:32px;text-align:center;">
            <div class="muted">No pull requests found for this repository.</div>
          </div>
        ` : `
          <div style="display:flex;flex-direction:column;gap:8px;">
            ${S.pulls.map((p) => `
              <div class="card" style="padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                <div style="display:flex;align-items:center;gap:12px;">
                  <span class="chip sm" style="font-family:var(--mono);${p.state === "open" ? "background:rgba(34,197,94,0.1);color:var(--green);" : "background:rgba(168,85,247,0.1);color:#a855f7;"}">
                    #${p.number}
                  </span>
                  <div>
                    <a href="#" class="btn-open-pr-ws" data-repo="${esc(S.selectedRepo)}" data-pr="${p.number}" style="font-weight:600;color:var(--text);text-decoration:none;">
                      ${esc(p.title)}
                    </a>
                    <div class="muted sm" style="margin-top:2px;font-size:12px;">
                      by <b>${esc(p.user)}</b> · <code>${esc(p.head)}</code> &rarr; <code>${esc(p.base)}</code> · ${(p.created_at || "").slice(0, 10)}
                    </div>
                  </div>
                </div>

                <div style="display:flex;gap:8px;align-items:center;">
                  <button class="btn xs ghost btn-open-pr-ws" data-repo="${esc(S.selectedRepo)}" data-pr="${p.number}">Inspect</button>
                  ${p.state === "open" ? `
                    <button class="btn xs primary btn-merge-pr" data-repo="${esc(S.selectedRepo)}" data-pr="${p.number}">
                      ${icon("check")}<span>Merge</span>
                    </button>
                    <button class="btn xs ghost btn-close-pr" data-repo="${esc(S.selectedRepo)}" data-pr="${p.number}">
                      ${icon("x")}<span>Close</span>
                    </button>
                  ` : `
                    <span class="chip sm muted">${esc(p.state)}</span>
                  `}
                  <a href="${esc(p.html_url)}" target="_blank" rel="noopener noreferrer" class="btn xs ghost">
                    ${icon("browser")}
                  </a>
                </div>
              </div>
            `).join("")}
          </div>
        `}
      </div>
    `;
  }

  // ── Tab 4: Issues ──────────────────────────────────────────────────────────
  function renderIssuesTab() {
    return `
      <div style="display:flex;flex-direction:column;gap:16px;">
        ${S.issuesErrorObj ? renderErrorBanner(S.issuesErrorObj, "issues-retry-btn") : ""}

        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
          <!-- Repo Selector & Filters -->
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <label style="font-weight:600;font-size:13px;">Repository:</label>
            <select id="issues-repo-select" class="input sm" style="width:240px;">
              ${S.repos.map((r) => `
                <option value="${esc(r.full_name)}" ${r.full_name === S.selectedRepo ? "selected" : ""}>
                  ${esc(r.full_name)}
                </option>
              `).join("")}
            </select>

            <div style="display:flex;gap:4px;">
              <button class="btn sm ${S.issuesFilter === "open" ? "primary" : "ghost"}" data-issuefilter="open">Open</button>
              <button class="btn sm ${S.issuesFilter === "closed" ? "primary" : "ghost"}" data-issuefilter="closed">Closed</button>
            </div>
          </div>

          <button class="btn sm primary" id="new-issue-btn">
            ${icon("plus")}<span>New Issue</span>
          </button>
        </div>

        <!-- Issues List -->
        ${S.loadingIssues ? `
          <div class="card" style="padding:32px;text-align:center;">
            <div class="muted">${icon("refresh", "spin")} Loading issues…</div>
          </div>
        ` : S.issues.length === 0 ? `
          <div class="card" style="padding:32px;text-align:center;">
            <div class="muted">No issues found for this repository.</div>
          </div>
        ` : `
          <div style="display:flex;flex-direction:column;gap:8px;">
            ${S.issues.map((i) => `
              <div class="card" style="padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                <div style="display:flex;align-items:center;gap:12px;">
                  <span class="chip sm" style="font-family:var(--mono);${i.state === "open" ? "background:rgba(34,197,94,0.1);color:var(--green);" : "background:rgba(239,68,68,0.1);color:var(--red);" }">
                    #${i.number}
                  </span>
                  <div>
                    <a href="#" class="btn-open-issue-ws" data-repo="${esc(S.selectedRepo)}" data-issue="${i.number}" style="font-weight:600;color:var(--text);text-decoration:none;">
                      ${esc(i.title)}
                    </a>
                    <div class="muted sm" style="margin-top:2px;font-size:12px;display:flex;align-items:center;gap:8px;">
                      <span>by <b>${esc(i.user)}</b> · ${(i.created_at || "").slice(0, 10)}</span>
                      ${(i.labels || []).map((l) => `<span class="chip sm" style="font-size:10px;">${esc(l)}</span>`).join("")}
                    </div>
                  </div>
                </div>

                <div style="display:flex;gap:8px;align-items:center;">
                  <button class="btn xs ghost btn-open-issue-ws" data-repo="${esc(S.selectedRepo)}" data-issue="${i.number}">Thread</button>
                  ${i.state === "open" ? `
                    <button class="btn xs ghost btn-close-issue" data-repo="${esc(S.selectedRepo)}" data-issue="${i.number}">
                      ${icon("check")}<span>Close</span>
                    </button>
                  ` : `
                    <button class="btn xs ghost btn-reopen-issue" data-repo="${esc(S.selectedRepo)}" data-issue="${i.number}">
                      ${icon("refresh")}<span>Reopen</span>
                    </button>
                  `}
                  <a href="${esc(i.html_url)}" target="_blank" rel="noopener noreferrer" class="btn xs ghost">
                    ${icon("browser")}
                  </a>
                </div>
              </div>
            `).join("")}
          </div>
        `}
      </div>
    `;
  }

  // ── Tab 5: Actions / CI Workflows ──────────────────────────────────────────
  function renderActionsTab() {
    return `
      <div style="display:flex;flex-direction:column;gap:16px;">
        ${S.actionsErrorObj ? renderErrorBanner(S.actionsErrorObj, "actions-retry-btn") : ""}

        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
          <!-- Repo Selector -->
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <label style="font-weight:600;font-size:13px;">Repository:</label>
            <select id="actions-repo-select" class="input sm" style="width:240px;">
              ${S.repos.map((r) => `
                <option value="${esc(r.full_name)}" ${r.full_name === S.selectedRepo ? "selected" : ""}>
                  ${esc(r.full_name)}
                </option>
              `).join("")}
            </select>
          </div>

          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <button class="btn sm ghost" id="actions-open-cicd-btn" ${S.selectedRepo ? "" : "disabled"}>
              ${icon("rocket")}<span>${esc(ghStr("gh_cicd_setup_btn", "Configure CI/CD & VPS"))}</span>
            </button>
            <button class="btn sm" id="trigger-workflow-btn">
              ${icon("play")}<span>Run Workflow</span>
            </button>
          </div>
        </div>

        ${S.workflows.length ? `
          <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
            <span class="muted sm">Workflows:</span>
            ${S.workflows.map((wf) => `<span class="chip sm" title="${esc(wf.path)}">${esc(wf.name)} <small class="muted">(${esc(wf.state)})</small></span>`).join("")}
          </div>
        ` : ""}

        <!-- Workflow Runs List -->
        ${S.loadingActions ? `
          <div class="card" style="padding:32px;text-align:center;">
            <div class="muted">${icon("refresh", "spin")} Loading workflow runs…</div>
          </div>
        ` : S.actions.length === 0 ? `
          <div class="card" style="padding:32px;text-align:center;">
            <div class="muted">No GitHub Actions workflow runs recorded for this repository.</div>
          </div>
        ` : `
          <div style="display:flex;flex-direction:column;gap:8px;">
            ${S.actions.map((r) => {
              const conclusion = r.conclusion || r.status || "queued";
              const isSuccess = conclusion === "success";
              const isFailure = ["failure", "timed_out"].includes(conclusion);
              const color = isSuccess ? "var(--green)" : isFailure ? "var(--red)" : "var(--accent)";
              return `
                <div class="card" style="padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                  <div style="display:flex;align-items:center;gap:12px;">
                    <div style="width:10px;height:10px;border-radius:50%;background:${color};"></div>
                    <div>
                      <a href="#" class="btn-open-run-ws" data-repo="${esc(S.selectedRepo)}" data-run="${r.id}" style="font-weight:600;color:var(--text);text-decoration:none;">${esc(r.name)}</a>
                      <div class="muted sm" style="margin-top:2px;font-size:12px;">
                        commit on <code>${esc(r.head_branch || "main")}</code> · event: <code>${esc(r.event || "push")}</code> · ${(r.created_at || "").replace("T", " ").slice(0, 19)}
                      </div>
                    </div>
                  </div>

                  <div style="display:flex;gap:8px;align-items:center;">
                    <span class="chip sm" style="color:${color};text-transform:capitalize;">${esc(conclusion)}</span>
                    <button class="btn xs ghost btn-open-run-ws" data-repo="${esc(S.selectedRepo)}" data-run="${r.id}">Jobs &amp; Logs</button>
                    <a href="${esc(r.html_url)}" target="_blank" rel="noopener noreferrer" class="btn xs ghost">
                      ${icon("browser")}<span>View Run</span>
                    </a>
                  </div>
                </div>
              `;
            }).join("")}
          </div>
        `}
      </div>
    `;
  }

  // ── Tab 6: Local Sites & 1-Click Publishing ────────────────────────────────
  function renderSitesTab() {
    const sites = state.sites || [];

    return `
      <div style="display:flex;flex-direction:column;gap:16px;">
        ${S.sitesErrorObj ? renderErrorBanner(S.sitesErrorObj, "sites-retry-btn") : ""}

        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
          <div>
            <h3 style="margin:0;font-size:16px;">Local Laravel Sites Git Status</h3>
            <div class="muted sm">Inspect git state, link existing repositories, or publish local sites to GitHub with 1-click.</div>
          </div>
          <button class="btn sm ghost" id="sites-refresh-git-btn">
            ${icon("refresh")}<span>Refresh Git Status</span>
          </button>
        </div>

        ${S.loadingSites ? `
          <div class="card" style="padding:32px;text-align:center;">
            <div class="muted">${icon("refresh", "spin")} Checking git status across local sites…</div>
          </div>
        ` : sites.length === 0 ? `
          <div class="card" style="padding:32px;text-align:center;">
            <div class="muted">No local Laravel sites detected.</div>
          </div>
        ` : `
          <div style="display:flex;flex-direction:column;gap:10px;">
            ${sites.map((site) => {
              const git = S.sitesGitStatus[site.name] || {};
              const isGit = git.is_git;
              const hasRemote = isGit && Boolean(git.remote_url);
              const repoFull = git.repo_full_name || "";

              return `
                <div class="card" style="padding:16px 20px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;">
                  <div style="display:flex;align-items:center;gap:14px;">
                    <div style="width:40px;height:40px;border-radius:10px;background:rgba(245, 48, 3, 0.08);color:#f53003;display:grid;place-items:center;font-weight:700;">
                      ${icon("rocket")}
                    </div>
                    <div>
                      <div style="display:flex;align-items:center;gap:8px;">
                        <b style="font-size:15px;">${esc(site.name)}</b>
                        ${site.php ? `<span class="chip sm">PHP ${esc(site.php)}</span>` : ""}
                        ${hasRemote ? `
                          <span class="chip sm" style="background:rgba(59,130,246,0.1);color:var(--accent);font-family:var(--mono);">
                            ${esc(repoFull || "linked")}
                          </span>
                        ` : isGit ? `
                          <span class="chip sm muted">local git only</span>
                        ` : `
                          <span class="chip sm muted">not a git repo</span>
                        `}
                      </div>
                      <div class="muted sm" style="margin-top:3px;font-size:12px;">
                        ${isGit ? `
                          Branch: <code>${esc(git.branch || "main")}</code> · 
                          ${git.clean ? `<span style="color:var(--green);">Working tree clean</span>` : `<span style="color:var(--yellow, #eab308);">Uncommitted changes</span>`}
                          ${git.unpushed > 0 ? ` · <span style="color:var(--accent);">${git.unpushed} unpushed</span>` : ""}
                        ` : `No .git directory found.`}
                      </div>
                    </div>
                  </div>

                  <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                    ${hasRemote ? `
                      <a href="https://github.com/${esc(repoFull)}" target="_blank" rel="noopener noreferrer" class="btn sm ghost">
                        ${icon("browser")}<span>View on GitHub</span>
                      </a>
                    ` : `
                      <button class="btn sm primary btn-publish-site" data-site="${esc(site.name)}">
                        ${icon("upload")}<span>1-Click Publish to GitHub</span>
                      </button>
                      <button class="btn sm ghost btn-link-site" data-site="${esc(site.name)}">
                        ${icon("link")}<span>Link Existing Repo</span>
                      </button>
                    `}
                  </div>
                </div>
              `;
            }).join("")}
          </div>
        `}
      </div>
    `;
  }

  // ── Event Bindings ─────────────────────────────────────────────────────────
  function bindHubEvents(root) {
    // 1. Tab switching (global hub nav only — excludes nested repo workspace tabs)
    $$(".sub-nav > .tab-btn[data-tab]", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        S.tab = btn.dataset.tab;
        if (S.tab === "repos" && window.GitHubExplorer?.state?.activeRepo) {
          window.GitHubExplorer.state.activeRepo = "";
        }
        render();
        if (S.tab === "pulls") loadPulls();
        else if (S.tab === "issues") loadIssues();
        else if (S.tab === "actions") loadActions();
        else if (S.tab === "sites") loadSitesGitStatus();
        else if (S.tab === "notifications") window.GitHubExplorer?.loadNotifications?.();
        else if (S.tab === "gists") window.GitHubExplorer?.loadGists?.();
        else if (S.tab === "profile") window.GitHubExplorer?.loadProfileAndOrgs?.();
      });
    });

    $("#gh-topbar-search-form", root)?.addEventListener("submit", (e) => {
      e.preventDefault();
      const q = $("#gh-topbar-search-input", root)?.value.trim();
      if (!q) return;
      S.tab = "search";
      render();
      window.GitHubExplorer?.runGlobalSearch?.(q, window.GitHubExplorer?.state?.searchKind || "repositories");
    });

    $("#gh-notif-pill", root)?.addEventListener("click", () => {
      S.tab = "notifications";
      render();
      window.GitHubExplorer?.loadNotifications?.();
    });

    $("#gh-live-web-btn", root)?.addEventListener("click", async () => {
      const targetRepo = window.GitHubExplorer?.state?.activeRepo || S.selectedRepo;
      const url = targetRepo ? `https://github.com/${targetRepo}` : "https://github.com";
      const st = await LD.call("gh_browser_status").catch(() => null);
      if (st?.active) {
        await LD.call("gh_browser_nav", { action: "goto", url });
      }
      await LD.call("gh_browser_open", { url });
    });

    $("#ov-open-web", root)?.addEventListener("click", () => {
      LD.call("gh_browser_open", { url: S.status.username ? `https://github.com/${S.status.username}` : "https://github.com" });
    });

    // 2. Account Switcher Dropdown (in header)
    $("#gh-account-select", root)?.addEventListener("change", (e) => {
      switchAccount(e.target.value);
    });

    // 3. Add Account & Manage Accounts Buttons
    $("#btn-gh-add-account", root)?.addEventListener("click", () => openAddAccountModal());
    $("#btn-gh-manage-accounts", root)?.addEventListener("click", () => openAccountsModal());
    $("#ov-switch-account", root)?.addEventListener("click", () => openAccountsModal());

    // 4. New Repo Buttons
    $("#gh-new-repo-btn", root)?.addEventListener("click", () => openNewRepoModal());
    $("#ov-new-repo", root)?.addEventListener("click", () => openNewRepoModal());
    $("#tab-new-repo-btn", root)?.addEventListener("click", () => openNewRepoModal());
    $("#empty-new-repo-btn", root)?.addEventListener("click", () => openNewRepoModal());

    // 5. Publish Site from Overview
    $("#ov-publish-site", root)?.addEventListener("click", () => {
      S.tab = "sites";
      render();
      loadSitesGitStatus();
    });

    // 6. Refresh & Disconnect
    $("#gh-refresh-btn", root)?.addEventListener("click", async () => {
      await refreshStatus();
      await loadRepos();
      if (S.tab === "pulls") await loadPulls();
      else if (S.tab === "issues") await loadIssues();
      else if (S.tab === "actions") await loadActions();
      else if (S.tab === "sites") await loadSitesGitStatus();
      render();
      toast("info", "GitHub Data Refreshed");
    });

    $("#gh-disconnect-btn", root)?.addEventListener("click", async () => {
      const ok = await confirmModal({
        title: ghStr("gh_disconnect", "Disconnect GitHub Account?"),
        message: "Remove the active GitHub token from local storage?",
        confirm: ghStr("gh_disconnect", "Disconnect"),
        danger: true,
      });
      if (!ok) return;
      await LD.call("gh_disconnect");
      S.status = { configured: false };
      S.repos = [];
      render();
      toast("info", "GitHub Account Disconnected");
    });

    $("#repos-sort-select", root)?.addEventListener("change", (e) => {
      S.reposSort = e.target.value || "updated";
      render();
    });

    // 7. Repos Filters & Search
    $$("[data-repofilter]", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        S.reposFilter = btn.dataset.repofilter;
        render();
      });
    });

    $("#repos-search-input", root)?.addEventListener("input", (e) => {
      S.reposSearch = e.target.value;
      render();
      $("#repos-search-input", view())?.focus();
    });

    // 8. Repos Card Actions
    $$(".btn-clone-repo", root).forEach((btn) => {
      btn.addEventListener("click", () => openCloneRepoModal(btn.dataset.repo));
    });

    $$(".btn-view-pulls", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        S.selectedRepo = btn.dataset.repo;
        S.tab = "pulls";
        render();
        loadPulls();
      });
    });

    $$(".btn-view-issues", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        S.selectedRepo = btn.dataset.repo;
        S.tab = "issues";
        render();
        loadIssues();
      });
    });

    $$(".btn-delete-repo", root).forEach((btn) => {
      btn.addEventListener("click", () => openDeleteRepoModal(btn.dataset.repo));
    });

    // 9. Pulls Controls
    $("#pulls-repo-select", root)?.addEventListener("change", (e) => {
      S.selectedRepo = e.target.value;
      loadPulls();
    });

    $$("[data-prfilter]", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        S.pullsFilter = btn.dataset.prfilter;
        render();
        loadPulls();
      });
    });

    $("#new-pr-btn", root)?.addEventListener("click", () => openNewPRModal());

    $$(".btn-merge-pr", root).forEach((btn) => {
      btn.addEventListener("click", () => openMergePRModal(btn.dataset.repo, btn.dataset.pr));
    });

    $$(".btn-close-pr", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm(`Are you sure you want to close PR #${btn.dataset.pr}?`)) return;
        const [owner, name] = btn.dataset.repo.split("/");
        await LD.call("gh_close_pull", { owner, repo: name, pull_number: parseInt(btn.dataset.pr, 10) });
        toast("success", "Pull Request Closed", `#${btn.dataset.pr}`);
        loadPulls();
      });
    });

    // 10. Issues Controls
    $("#issues-repo-select", root)?.addEventListener("change", (e) => {
      S.selectedRepo = e.target.value;
      loadIssues();
    });

    $$("[data-issuefilter]", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        S.issuesFilter = btn.dataset.issuefilter;
        render();
        loadIssues();
      });
    });

    $("#new-issue-btn", root)?.addEventListener("click", () => openNewIssueModal());

    $$(".btn-close-issue", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm(`Close issue #${btn.dataset.issue}?`)) return;
        const [owner, name] = btn.dataset.repo.split("/");
        await LD.call("gh_close_issue", { owner, repo: name, issue_number: parseInt(btn.dataset.issue, 10), state: "closed" });
        toast("success", "Issue Closed", `#${btn.dataset.issue}`);
        loadIssues();
      });
    });

    $$(".btn-reopen-issue", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        const [owner, name] = btn.dataset.repo.split("/");
        await LD.call("gh_close_issue", { owner, repo: name, issue_number: parseInt(btn.dataset.issue, 10), state: "open" });
        toast("success", "Issue Reopened", `#${btn.dataset.issue}`);
        loadIssues();
      });
    });

    // 11. Actions Controls
    $("#actions-repo-select", root)?.addEventListener("change", (e) => {
      S.selectedRepo = e.target.value;
      loadActions();
    });

    $("#trigger-workflow-btn", root)?.addEventListener("click", () => openTriggerWorkflowModal());

    // 12. Sites Controls
    $("#sites-refresh-git-btn", root)?.addEventListener("click", () => loadSitesGitStatus());

    $$(".btn-publish-site", root).forEach((btn) => {
      btn.addEventListener("click", () => openPublishSiteModal(btn.dataset.site));
    });

    $$(".btn-link-site", root).forEach((btn) => {
      btn.addEventListener("click", () => openLinkSiteModal(btn.dataset.site));
    });

    // 13. Retry Buttons
    $("#repos-retry-btn", root)?.addEventListener("click", () => loadRepos());
    $("#pulls-retry-btn", root)?.addEventListener("click", () => loadPulls());
    $("#issues-retry-btn", root)?.addEventListener("click", () => loadIssues());
    $("#actions-retry-btn", root)?.addEventListener("click", () => loadActions());
    $("#sites-retry-btn", root)?.addEventListener("click", () => loadSitesGitStatus());

    // 14. Workspace & Explorer Drill-Down Bindings
    $$(".btn-open-repo-ws", root).forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const repoFull = btn.dataset.repo;
        if (!repoFull) return;
        S.selectedRepo = repoFull;
        S.tab = "repos";
        window.GitHubExplorer?.openRepo?.(repoFull, "code");
      });
    });

    $$(".btn-open-repo-cicd", root).forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const repoFull = btn.dataset.repo;
        if (!repoFull) return;
        S.selectedRepo = repoFull;
        S.tab = "repos";
        window.GitHubExplorer?.openRepo?.(repoFull, "cicd");
      });
    });

    $("#actions-open-cicd-btn", root)?.addEventListener("click", () => {
      if (!S.selectedRepo) return;
      S.tab = "repos";
      window.GitHubExplorer?.openRepo?.(S.selectedRepo, "cicd");
    });

    $$(".btn-open-pr-ws", root).forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        S.tab = "repos";
        window.GitHubExplorer?.openPullDetail?.(btn.dataset.repo, btn.dataset.pr);
      });
    });

    $$(".btn-open-issue-ws", root).forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        S.tab = "repos";
        window.GitHubExplorer?.openIssueDetail?.(btn.dataset.repo, btn.dataset.issue);
      });
    });

    $$(".btn-open-run-ws", root).forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        S.tab = "repos";
        window.GitHubExplorer?.openRunDetail?.(btn.dataset.repo, btn.dataset.run);
      });
    });

    window.GitHubExplorer?.bindEvents?.(root, {
      openCloneModal: openCloneRepoModal,
      openMergePRModal: openMergePRModal,
      switchToRepoWorkspace: (repoFull, customFn) => {
        if (!repoFull) return;
        S.selectedRepo = repoFull;
        S.tab = "repos";
        if (typeof customFn === "function") {
          customFn();
        } else {
          window.GitHubExplorer?.openRepo?.(repoFull, "code");
        }
      },
    });
  }

  // ── Modals (Using Native app.js openModal on #modal-root) ───────────────────

  // 1. Add Account Standalone Modal
  function openAddAccountModal() {
    openModal(`
      <div class="modal card" style="max-width:540px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>Add GitHub Account</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="modal-add-acc-standalone" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Personal Access Token (PAT) <small style="color:var(--red);">*</small></label>
            <input type="password" id="add-acc-pat" class="input" placeholder="ghp_xxxxxxxxxxxxxxxxxxxx" required autocomplete="off" style="font-family:var(--mono);" />
            <small class="muted" style="display:block;margin-top:4px;">
              Recommended scopes: <code>repo</code>, <code>workflow</code>, <code>read:org</code>.
            </small>
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Account Label (optional)</label>
            <input type="text" id="add-acc-lbl" class="input" placeholder="e.g. Work Org, Client Project, Freelance" />
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="add-acc-submit">
              ${icon("check")}<span>Verify &amp; Connect</span>
            </button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#modal-add-acc-standalone", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const token = $("#add-acc-pat", mRoot)?.value.trim();
        const label = $("#add-acc-lbl", mRoot)?.value.trim();
        if (!token) return;

        const submitBtn = $("#add-acc-submit", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Verifying…</span>`;
        }

        try {
          const verify = await LD.call("gh_verify_token", { token });
          if (!verify.valid) {
            alert(verify.error || "Token verification failed. Please check token permissions.");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = `${icon("check")}<span>Verify &amp; Connect</span>`;
            }
            return;
          }

          await LD.call("gh_save_credentials", {
            token,
            username: verify.username || "",
            account_name: label || verify.name || verify.username,
            avatar_url: verify.avatar_url || "",
            email: verify.email || "",
            scopes: verify.scopes || [],
          });

          closeModal();
          await refreshStatus();
          await loadRepos();
          render();
          toast("success", "GitHub Account Added", verify.username);
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `${icon("check")}<span>Verify &amp; Connect</span>`;
          }
        }
      });
    });
  }

  // 2. Manage Accounts Modal
  function openAccountsModal() {
    const title = window.t ? window.t("gh_manage_accounts", "Manage GitHub Accounts") : "Manage GitHub Accounts";

    const accountsListHtml = S.accounts.map((a) => `
      <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-radius:8px;background:var(--bg);margin-bottom:8px;">
        <div style="display:flex;align-items:center;gap:12px;">
          <div style="width:36px;height:36px;border-radius:50%;background:var(--accent);color:#fff;display:grid;place-items:center;font-weight:700;">
            ${esc((a.username || "U")[0].toUpperCase())}
          </div>
          <div>
            <div style="display:flex;align-items:center;gap:6px;">
              <b>${esc(a.username)}</b>
              ${a.account_name && a.account_name !== a.username ? `<span class="chip sm">${esc(a.account_name)}</span>` : ""}
              ${a.is_active ? `<span class="chip sm" style="background:rgba(34,197,94,0.1);color:var(--green);">Active</span>` : ""}
            </div>
            <div class="muted sm" style="font-family:var(--mono);font-size:11px;">
              ${esc(a.token_preview || "")} ${a.email ? `· ${esc(a.email)}` : ""}
            </div>
          </div>
        </div>

        <div style="display:flex;gap:6px;">
          ${!a.is_active ? `
            <button type="button" class="btn xs primary btn-switch-gh-acc" data-id="${esc(a.account_id)}">Switch</button>
          ` : ""}
          <button type="button" class="btn xs ghost btn-remove-gh-acc" data-id="${esc(a.account_id)}" style="color:var(--red);" title="Remove">${icon("trash")}</button>
        </div>
      </div>
    `).join("");

    openModal(`
      <div class="modal card" style="max-width:560px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>${esc(title)}</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <div class="modal-body" style="padding:16px;">
          <div style="margin-bottom:16px;">
            ${accountsListHtml || `<div class="muted sm">No accounts linked.</div>`}
          </div>

          <div style="border-top:1px solid var(--border);padding-top:14px;margin-top:14px;">
            <h4 style="margin:0 0 10px 0;font-size:14px;">Add Another Account</h4>
            <form id="modal-add-acc-form" style="display:flex;flex-direction:column;gap:10px;">
              <input type="password" id="modal-add-acc-token" class="input sm" placeholder="Personal Access Token (PAT)" required autocomplete="off" style="font-family:var(--mono);" />
              <input type="text" id="modal-add-acc-label" class="input sm" placeholder="Account Label (optional, e.g. Work Org)" />
              <button type="submit" class="btn sm primary" style="align-self:flex-start;">Add &amp; Connect</button>
            </form>
          </div>
        </div>
        <div class="modal-footer" style="display:flex;justify-content:flex-end;padding:12px 16px;border-top:1px solid var(--border);">
          <button type="button" class="btn" data-dismiss>Close</button>
        </div>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);

      $$(".btn-switch-gh-acc", mRoot).forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.dataset.id;
          closeModal();
          await switchAccount(id);
        });
      });

      $$(".btn-remove-gh-acc", mRoot).forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.dataset.id;
          if (!confirm("Are you sure you want to remove this GitHub account from the tool?")) return;
          const res = await LD.call("gh_remove_account", { account_id: id });
          if (res.ok) {
            closeModal();
            await refreshStatus();
            await loadRepos();
            render();
            toast("success", "Account Removed");
          }
        });
      });

      $("#modal-add-acc-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const token = $("#modal-add-acc-token", mRoot)?.value.trim();
        const label = $("#modal-add-acc-label", mRoot)?.value.trim();
        if (!token) return;

        const verify = await LD.call("gh_verify_token", { token });
        if (!verify.valid) {
          alert(verify.error || "Token verification failed");
          return;
        }

        await LD.call("gh_save_credentials", {
          token,
          username: verify.username || "",
          account_name: label || verify.name || verify.username,
          avatar_url: verify.avatar_url || "",
          email: verify.email || "",
          scopes: verify.scopes || [],
        });

        closeModal();
        await refreshStatus();
        await loadRepos();
        render();
        toast("success", "GitHub Account Added", verify.username);
      });
    });
  }

  // 3. New Repository Modal
  function openNewRepoModal() {
    openModal(`
      <div class="modal card" style="max-width:560px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>Create New GitHub Repository</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="new-repo-form" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Repository Name</label>
            <input type="text" id="new-repo-name" class="input" placeholder="e.g. awesome-laravel-app" required style="font-family:var(--mono);" />
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Description (optional)</label>
            <input type="text" id="new-repo-desc" class="input" placeholder="Brief project description" />
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;display:block;margin-bottom:6px;">Visibility</label>
            <div style="display:flex;gap:16px;">
              <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
                <input type="radio" name="new-repo-vis" value="private" checked />
                <span>Private</span>
              </label>
              <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
                <input type="radio" name="new-repo-vis" value="public" />
                <span>Public</span>
              </label>
            </div>
          </div>

          <div class="form-group">
            <label style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;">
              <input type="checkbox" id="new-repo-init" />
              <span>Initialize with a README</span>
            </label>
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="new-repo-submit">Create Repository</button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#new-repo-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const name = $("#new-repo-name", mRoot)?.value.trim();
        const desc = $("#new-repo-desc", mRoot)?.value.trim();
        const isPrivate = $("input[name='new-repo-vis']:checked", mRoot)?.value === "private";
        const autoInit = $("#new-repo-init", mRoot)?.checked;
        if (!name) return;

        const submitBtn = $("#new-repo-submit", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Creating…</span>`;
        }

        try {
          const res = await LD.call("gh_create_repo", {
            name,
            description: desc,
            private: isPrivate,
            auto_init: autoInit,
          });

          if (res && res.ok) {
            closeModal();
            await loadRepos();
            toast("success", "Repository Created", name);
          } else {
            alert(res.error || "Failed to create repository");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.textContent = "Create Repository";
            }
          }
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Create Repository";
          }
        }
      });
    });
  }

  // 4. Clone Repository Modal
  function openCloneRepoModal(repoFullName) {
    const defaultSiteName = (repoFullName || "").split("/").pop();
    openModal(`
      <div class="modal card" style="max-width:560px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>Clone to Local Sites</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="clone-repo-form" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <p class="muted sm" style="line-height:1.5;">
            This will clone <code>${esc(repoFullName)}</code> into your local Sites directory (<code>~/Sites/${esc(defaultSiteName)}</code>) and register it as an active local site.
          </p>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Target Site Name</label>
            <input type="text" id="clone-site-name" class="input" value="${esc(defaultSiteName)}" required style="font-family:var(--mono);" />
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="clone-repo-submit">Clone &amp; Register</button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#clone-repo-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const siteName = $("#clone-site-name", mRoot)?.value.trim();
        if (!siteName) return;

        const submitBtn = $("#clone-repo-submit", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Cloning…</span>`;
        }

        try {
          const res = await LD.call("gh_clone_repo", {
            repo_full_name: repoFullName,
            target_dir: siteName,
          });

          if (res && res.ok) {
            closeModal();
            if (typeof refreshSites === "function") refreshSites();
            toast("success", "Cloned to Sites Folder", siteName);
          } else {
            alert(res.error || "Failed to clone repository");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.textContent = "Clone & Register";
            }
          }
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Clone & Register";
          }
        }
      });
    });
  }

  // 5. Delete Repository Modal
  function openDeleteRepoModal(repoFullName) {
    openModal(`
      <div class="modal card" style="max-width:560px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>Delete Repository</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="delete-repo-form" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <div style="background:rgba(239,68,68,0.1);border-inline-start:4px solid var(--red);padding:12px 14px;border-radius:6px;font-size:13px;line-height:1.5;color:var(--red);">
            <b>Warning:</b> This action cannot be undone. This will permanently delete <code>${esc(repoFullName)}</code>.
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Please type <code>${esc(repoFullName)}</code> to confirm:</label>
            <input type="text" id="confirm-repo-name" class="input" placeholder="${esc(repoFullName)}" required autocomplete="off" style="font-family:var(--mono);" />
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn" id="confirm-delete-btn" style="background:var(--red);color:#fff;" disabled>
              I understand, delete this repository
            </button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#confirm-repo-name", mRoot)?.addEventListener("input", (e) => {
        const match = e.target.value.trim() === repoFullName;
        const btn = $("#confirm-delete-btn", mRoot);
        if (btn) btn.disabled = !match;
      });

      $("#delete-repo-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const submitBtn = $("#confirm-delete-btn", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Deleting…</span>`;
        }

        try {
          const res = await LD.call("gh_delete_repo", { full_name: repoFullName });
          if (res && res.ok) {
            closeModal();
            await loadRepos();
            toast("success", "Repository Deleted", repoFullName);
          } else {
            alert(res.error || "Failed to delete repository");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.textContent = "I understand, delete this repository";
            }
          }
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "I understand, delete this repository";
          }
        }
      });
    });
  }

  // 6. New Pull Request Modal
  function openNewPRModal() {
    const [owner, name] = (S.selectedRepo || "").split("/");
    openModal(`
      <div class="modal card" style="max-width:580px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>Create Pull Request (${esc(S.selectedRepo)})</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="new-pr-form" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Title</label>
            <input type="text" id="new-pr-title" class="input" placeholder="e.g. Implement user authentication" required />
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
            <div class="form-group">
              <label style="font-weight:600;font-size:13px;">Head Branch (compare)</label>
              <input type="text" id="new-pr-head" class="input sm" placeholder="feature-branch" required style="font-family:var(--mono);" />
            </div>
            <div class="form-group">
              <label style="font-weight:600;font-size:13px;">Base Branch (into)</label>
              <input type="text" id="new-pr-base" class="input sm" value="main" required style="font-family:var(--mono);" />
            </div>
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Description</label>
            <textarea id="new-pr-body" class="input" rows="4" placeholder="Describe the changes..."></textarea>
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="new-pr-submit">Create Pull Request</button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#new-pr-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const prTitle = $("#new-pr-title", mRoot)?.value.trim();
        const head = $("#new-pr-head", mRoot)?.value.trim();
        const base = $("#new-pr-base", mRoot)?.value.trim();
        const body = $("#new-pr-body", mRoot)?.value.trim();
        if (!prTitle || !head) return;

        const submitBtn = $("#new-pr-submit", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Creating…</span>`;
        }

        try {
          const res = await LD.call("gh_create_pull", {
            owner,
            repo: name,
            title: prTitle,
            head,
            base,
            body,
          });

          if (res && res.ok) {
            closeModal();
            await loadPulls();
            toast("success", "Pull Request Created", `#${res.number || ""}`);
          } else {
            alert(res.error || "Failed to create pull request");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.textContent = "Create Pull Request";
            }
          }
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Create Pull Request";
          }
        }
      });
    });
  }

  // 7. Merge Pull Request Modal
  function openMergePRModal(repoFullName, prNumber) {
    const [owner, name] = repoFullName.split("/");
    openModal(`
      <div class="modal card" style="max-width:560px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>Merge Pull Request #${esc(prNumber)}</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="merge-pr-form" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <div class="form-group">
            <label style="font-weight:600;font-size:13px;display:block;margin-bottom:6px;">Merge Method</label>
            <div style="display:flex;flex-direction:column;gap:8px;">
              <label style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="radio" name="merge-method" value="merge" checked />
                <span><b>Create a merge commit</b> · All commits will be added to the base branch.</span>
              </label>
              <label style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="radio" name="merge-method" value="squash" />
                <span><b>Squash and merge</b> · Combines commits into one commit.</span>
              </label>
              <label style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="radio" name="merge-method" value="rebase" />
                <span><b>Rebase and merge</b> · Commits will be rebased and added.</span>
              </label>
            </div>
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Commit Title (optional)</label>
            <input type="text" id="merge-commit-title" class="input sm" placeholder="Merge pull request #${prNumber}" />
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Commit Message (optional)</label>
            <textarea id="merge-commit-msg" class="input sm" rows="3"></textarea>
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="merge-pr-submit">Confirm Merge</button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#merge-pr-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const method = $("input[name='merge-method']:checked", mRoot)?.value || "merge";
        const cTitle = $("#merge-commit-title", mRoot)?.value.trim();
        const cMsg = $("#merge-commit-msg", mRoot)?.value.trim();

        const submitBtn = $("#merge-pr-submit", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Merging…</span>`;
        }

        try {
          const res = await LD.call("gh_merge_pull", {
            owner,
            repo: name,
            pull_number: parseInt(prNumber, 10),
            merge_method: method,
            commit_title: cTitle,
            commit_message: cMsg,
          });

          if (res && res.ok) {
            closeModal();
            await loadPulls();
            toast("success", "Pull Request Merged", `#${prNumber}`);
          } else {
            alert(res.error || "Failed to merge pull request");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.textContent = "Confirm Merge";
            }
          }
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Confirm Merge";
          }
        }
      });
    });
  }

  // 8. New Issue Modal
  function openNewIssueModal() {
    const [owner, name] = (S.selectedRepo || "").split("/");
    openModal(`
      <div class="modal card" style="max-width:560px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>Create New Issue (${esc(S.selectedRepo)})</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="new-issue-form" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Title</label>
            <input type="text" id="new-issue-title" class="input" placeholder="Issue title" required />
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Description</label>
            <textarea id="new-issue-body" class="input" rows="4" placeholder="Describe the issue..."></textarea>
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Labels (comma separated, optional)</label>
            <input type="text" id="new-issue-labels" class="input sm" placeholder="bug, enhancement, documentation" />
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="new-issue-submit">Submit Issue</button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#new-issue-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const iTitle = $("#new-issue-title", mRoot)?.value.trim();
        const iBody = $("#new-issue-body", mRoot)?.value.trim();
        const labelsRaw = $("#new-issue-labels", mRoot)?.value.trim();
        const labels = labelsRaw ? labelsRaw.split(",").map((l) => l.trim()).filter(Boolean) : [];
        if (!iTitle) return;

        const submitBtn = $("#new-issue-submit", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Submitting…</span>`;
        }

        try {
          const res = await LD.call("gh_create_issue", {
            owner,
            repo: name,
            title: iTitle,
            body: iBody,
            labels,
          });

          if (res && res.ok) {
            closeModal();
            await loadIssues();
            toast("success", "Issue Submitted", `#${res.number || ""}`);
          } else {
            alert(res.error || "Failed to create issue");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.textContent = "Submit Issue";
            }
          }
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Submit Issue";
          }
        }
      });
    });
  }

  // 9. Trigger Workflow Modal
  function openTriggerWorkflowModal() {
    const [owner, name] = (S.selectedRepo || "").split("/");
    openModal(`
      <div class="modal card" style="max-width:540px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>Run Workflow (${esc(S.selectedRepo)})</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="trigger-wf-form" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Workflow File or ID</label>
            <input type="text" id="trigger-wf-id" class="input" placeholder="e.g. tests.yml or main.yml" required style="font-family:var(--mono);" />
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Branch / Git Ref</label>
            <input type="text" id="trigger-wf-ref" class="input sm" value="main" required style="font-family:var(--mono);" />
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="trigger-wf-submit">
              ${icon("play")}<span>Run Workflow</span>
            </button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#trigger-wf-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const wfId = $("#trigger-wf-id", mRoot)?.value.trim();
        const ref = $("#trigger-wf-ref", mRoot)?.value.trim();
        if (!wfId) return;

        const submitBtn = $("#trigger-wf-submit", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Running…</span>`;
        }

        try {
          const res = await LD.call("gh_trigger_workflow", {
            owner,
            repo: name,
            workflow_id: wfId,
            ref,
          });

          if (res && res.ok) {
            closeModal();
            await loadActions();
            toast("success", "Workflow Triggered", wfId);
          } else {
            alert(res.error || "Failed to trigger workflow. Ensure the workflow has workflow_dispatch enabled.");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = `${icon("play")}<span>Run Workflow</span>`;
            }
          }
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `${icon("play")}<span>Run Workflow</span>`;
          }
        }
      });
    });
  }

  // 10. 1-Click Publish Site Modal
  function openPublishSiteModal(siteName) {
    openModal(`
      <div class="modal card" style="max-width:560px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>1-Click Publish '${esc(siteName)}' to GitHub</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="publish-site-form" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <p class="muted sm" style="line-height:1.5;">
            This will automatically initialize git, configure standard Laravel <code>.gitignore</code>, create a repository under your active GitHub account, push your code, and link the remote.
          </p>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Repository Name</label>
            <input type="text" id="pub-repo-name" class="input" value="${esc(siteName)}" required style="font-family:var(--mono);" />
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Description (optional)</label>
            <input type="text" id="pub-repo-desc" class="input" value="Laravel application ${esc(siteName)}" />
          </div>

          <div class="form-group">
            <label style="font-weight:600;font-size:13px;display:block;margin-bottom:6px;">Visibility</label>
            <div style="display:flex;gap:16px;">
              <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
                <input type="radio" name="pub-vis" value="private" checked />
                <span>Private</span>
              </label>
              <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
                <input type="radio" name="pub-vis" value="public" />
                <span>Public</span>
              </label>
            </div>
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="pub-submit-btn">
              ${icon("upload")}<span>Publish Now</span>
            </button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#publish-site-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const rName = $("#pub-repo-name", mRoot)?.value.trim();
        const rDesc = $("#pub-repo-desc", mRoot)?.value.trim();
        const isPriv = $("input[name='pub-vis']:checked", mRoot)?.value === "private";
        if (!rName) return;

        const submitBtn = $("#pub-submit-btn", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Publishing…</span>`;
        }

        try {
          const res = await LD.call("gh_publish_site", {
            site: siteName,
            repo_name: rName,
            private: isPriv,
            description: rDesc,
          });

          if (res && res.ok) {
            closeModal();
            await loadRepos();
            await loadSitesGitStatus();
            render();
            toast("success", "Published to GitHub", siteName);
          } else {
            alert(res.error || "Failed to publish site to GitHub");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = `${icon("upload")}<span>Publish Now</span>`;
            }
          }
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `${icon("upload")}<span>Publish Now</span>`;
          }
        }
      });
    });
  }

  // 11. Link Existing Repo Modal
  function openLinkSiteModal(siteName) {
    const reposOptionsHtml = S.repos.map((r) => `<option value="${esc(r.full_name)}">`).join("");

    openModal(`
      <div class="modal card" style="max-width:540px;">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;">
          <h2>Link '${esc(siteName)}' to GitHub Repo</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="link-site-form" style="padding:18px;display:flex;flex-direction:column;gap:14px;">
          <div class="form-group">
            <label style="font-weight:600;font-size:13px;">Select or Enter Repository (owner/repo)</label>
            <input type="text" id="link-repo-input" class="input" list="link-repos-datalist" placeholder="e.g. ${esc(S.status.username || "owner")}/${esc(siteName)}" required style="font-family:var(--mono);" />
            <datalist id="link-repos-datalist">
              ${reposOptionsHtml}
            </datalist>
          </div>

          <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:12px;border-top:1px solid var(--border);">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="link-repo-submit">Link Repository</button>
          </div>
        </form>
      </div>
    `, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#link-site-form", mRoot)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const targetRepo = $("#link-repo-input", mRoot)?.value.trim();
        if (!targetRepo || !targetRepo.includes("/")) {
          alert("Repository must be in format 'owner/repo'");
          return;
        }

        const submitBtn = $("#link-repo-submit", mRoot);
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh", "spin")}<span>Linking…</span>`;
        }

        try {
          const res = await LD.call("gh_link_site", {
            site: siteName,
            repo_full_name: targetRepo,
          });

          if (res && res.ok) {
            closeModal();
            await loadSitesGitStatus();
            render();
            toast("success", "Site Linked to Repository", targetRepo);
          } else {
            alert(res.error || "Failed to link site");
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.textContent = "Link Repository";
            }
          }
        } catch (err) {
          alert(err.message || String(err));
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Link Repository";
          }
        }
      });
    });
  }

  return {
    init,
    show,
    refreshStatus,
    openRepoFromBrowser,
    cloneFromBrowser,
  };
})();

window.GitHub = GitHub;
document.addEventListener("DOMContentLoaded", () => GitHub.init());
