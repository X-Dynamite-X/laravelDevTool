/**
 * ui/web/diff_viewer.js - Unified & Split Diff Viewer for laravel-dev-tool.
 */
"use strict";

const DiffViewer = {
  _esc(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  },

  parsePatchLines(patchText) {
    if (!patchText || !String(patchText).trim()) return [];
    const rawLines = String(patchText).split("\n");
    const parsed = [];
    let oldLine = 0;
    let newLine = 0;
    const hunkRe = /^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@/;

    for (const raw of rawLines) {
      if (raw.startsWith("+++") || raw.startsWith("---") || raw.startsWith("diff ") || raw.startsWith("index ")) {
        parsed.push({ kind: "meta", oldNum: "", newNum: "", text: raw });
        continue;
      }
      const match = hunkRe.exec(raw);
      if (match) {
        oldLine = parseInt(match[1], 10);
        newLine = parseInt(match[2], 10);
        parsed.push({ kind: "hunk", oldNum: "…", newNum: "…", text: raw });
        continue;
      }
      if (raw.startsWith("+")) {
        parsed.push({ kind: "add", oldNum: "", newNum: newLine++, text: raw.slice(1), prefix: "+" });
      } else if (raw.startsWith("-")) {
        parsed.push({ kind: "del", oldNum: oldLine++, newNum: "", text: raw.slice(1), prefix: "-" });
      } else if (raw.startsWith("\\")) {
        parsed.push({ kind: "meta", oldNum: "", newNum: "", text: raw });
      } else {
        const clean = raw.startsWith(" ") ? raw.slice(1) : raw;
        parsed.push({ kind: "ctx", oldNum: oldLine++, newNum: newLine++, text: clean, prefix: " " });
      }
    }
    return parsed;
  },

  renderUnifiedTable(lines) {
    if (!lines.length) {
      return '<div class="diff-empty">No textual diff available (binary file or large diff).</div>';
    }
    return `<table class="diff-table unified"><tbody>${lines.map((row) => {
      if (row.kind === "hunk" || row.kind === "meta") {
        return `<tr class="diff-row ${row.kind}"><td class="diff-ln"></td><td class="diff-ln"></td><td class="diff-code">${this._esc(row.text)}</td></tr>`;
      }
      return `<tr class="diff-row ${row.kind}">
        <td class="diff-ln">${row.oldNum}</td>
        <td class="diff-ln">${row.newNum}</td>
        <td class="diff-code"><span class="diff-sign">${row.prefix || " "}</span>${this._esc(row.text)}</td>
      </tr>`;
    }).join("")}</tbody></table>`;
  },

  renderSplitTable(lines) {
    if (!lines.length) {
      return '<div class="diff-empty">No textual diff available (binary file or large diff).</div>';
    }
    const rows = [];
    let i = 0;
    while (i < lines.length) {
      const cur = lines[i];
      if (cur.kind === "hunk" || cur.kind === "meta") {
        rows.push(`<tr class="diff-row ${cur.kind}"><td colspan="4" class="diff-code">${this._esc(cur.text)}</td></tr>`);
        i += 1;
        continue;
      }
      if (cur.kind === "ctx") {
        rows.push(`<tr class="diff-row ctx">
          <td class="diff-ln">${cur.oldNum}</td><td class="diff-code">${this._esc(cur.text)}</td>
          <td class="diff-ln">${cur.newNum}</td><td class="diff-code">${this._esc(cur.text)}</td>
        </tr>`);
        i += 1;
        continue;
      }
      const dels = [];
      const adds = [];
      while (i < lines.length && lines[i].kind === "del") dels.push(lines[i++]);
      while (i < lines.length && lines[i].kind === "add") adds.push(lines[i++]);
      const pairCount = Math.max(dels.length, adds.length);
      for (let k = 0; k < pairCount; k++) {
        const left = dels[k];
        const right = adds[k];
        rows.push(`<tr class="diff-row split-pair">
          <td class="diff-ln ${left ? "del" : "empty"}">${left ? left.oldNum : ""}</td>
          <td class="diff-code ${left ? "del" : "empty"}">${left ? `<span class="diff-sign">-</span>${this._esc(left.text)}` : ""}</td>
          <td class="diff-ln ${right ? "add" : "empty"}">${right ? right.newNum : ""}</td>
          <td class="diff-code ${right ? "add" : "empty"}">${right ? `<span class="diff-sign">+</span>${this._esc(right.text)}` : ""}</td>
        </tr>`);
      }
    }
    return `<table class="diff-table split"><tbody>${rows.join("")}</tbody></table>`;
  },

  renderDiff(diffText, mode = "unified") {
    if (!diffText || !String(diffText).trim()) {
      return '<div class="diff-empty">No changes detected</div>';
    }
    const parsed = this.parsePatchLines(diffText);
    return `<div class="diff-container">${
      mode === "split" ? this.renderSplitTable(parsed) : this.renderUnifiedTable(parsed)
    }</div>`;
  },

  renderFiles(files, options = {}) {
    const mode = options.mode === "split" ? "split" : "unified";
    const list = Array.isArray(files) ? files : [];
    if (!list.length) {
      return '<div class="diff-empty card" style="padding:24px;text-align:center;">No changed files to display.</div>';
    }
    return list.map((file, idx) => {
      const status = file.status || "modified";
      const badgeCls = status === "added" ? "green" : status === "removed" ? "red" : "accent";
      const patchHtml = file.patch
        ? this.renderDiff(file.patch, mode)
        : '<div class="diff-empty">Binary file, empty diff, or patch omitted by GitHub API.</div>';
      const title = file.previous_filename
        ? `${this._esc(file.previous_filename)} → ${this._esc(file.filename)}`
        : this._esc(file.filename || `file-${idx + 1}`);
      return `
        <details class="card diff-file-card" ${idx < 8 ? "open" : ""}>
          <summary class="diff-file-head">
            <span class="diff-file-name">${title}</span>
            <span class="diff-file-meta">
              <span class="chip sm" style="color:var(--${badgeCls});">${this._esc(status)}</span>
              <span style="color:var(--green);font-family:var(--mono);font-size:12px;">+${file.additions || 0}</span>
              <span style="color:var(--red);font-family:var(--mono);font-size:12px;">-${file.deletions || 0}</span>
            </span>
          </summary>
          <div class="diff-file-body">${patchHtml}</div>
        </details>`;
    }).join("");
  },
};

window.DiffViewer = DiffViewer;
