"use strict";

/* Remote servers over SSH: overview, services, Laravel sites and a file manager.
   Uses the helpers defined in app.js (icon, esc, api, toast, modals, drawer). */

const Servers = (() => {
  const S = {
    list: [],
    sshHosts: [],
    current: null, // server id
    tab: "overview",
    info: null,
    infoError: "",
    sites: null,
    files: { path: "", entries: [], hidden: false, loading: false, error: "" },
    site: null, // remote site open in the drawer
    siteTab: "actions",
    provisionStatus: null,
    releases: null,
    preflight: null,
    loaded: false,
  };
  let logTimer = null;

  const view = () => $("#view-servers");
  const server = () => S.list.find((s) => s.id === S.current);
  const address = (s) => `${s.user ? `${s.user}@` : ""}${s.host}${s.port && s.port !== "22" ? `:${s.port}` : ""}`;

  // What every remote task needs to know about a site.
  const sitePayload = (site) => ({ path: site.path, php: site.php, type: site.type || "laravel", pm2: site.pm2 ? site.pm2.id : null, unit: site.unit || "" });

  function mapSiteTypeToStack(type) {
    const t0 = String(type || "laravel").toLowerCase();
    if (t0 === "laravel") return "laravel";
    if (t0 === "django" || t0 === "fastapi" || t0 === "python") return "python";
    if (t0 === "vite" || t0 === "react" || t0 === "vue" || t0 === "static") return "static";
    if (t0 === "docker") return "docker";
    return "node_ssr";
  }

  const DEPLOY_STEPS = {
    laravel: "<code>git pull</code>, <code>composer install --no-dev</code>, <code>migrate --force</code>, <code>optimize</code> and <code>queue:restart</code>",
    django: "<code>git pull</code>, <code>pip install -r requirements.txt</code>, <code>migrate</code>, <code>collectstatic</code>, then restarts the app",
    fastapi: "<code>git pull</code>, <code>pip install -r requirements.txt</code>, then restarts systemd / uvicorn",
    docker: "builds & recreates containers via <code>docker compose up -d --build</code>",
    static: "installs deps, builds static assets, swaps atomic symlink cleanly",
    node: "<code>git pull</code>, installs dependencies (npm ci / pnpm / yarn / bun), <code>run build</code>, then restarts the app",
  };

  function runnerLabel(site) {
    if (site.pm2) return `pm2 · ${esc(site.pm2.name)} (${esc(site.pm2.status || "?")})`;
    if (site.unit) return `systemd · ${esc(site.unit)} (${esc(site.unit_status || "?")})`;
    return "";
  }

  function fmtBytes(n) {
    if (!n) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.min(Math.floor(Math.log(n) / Math.log(1024)), units.length - 1);
    return `${(n / 1024 ** i).toFixed(i ? 1 : 0)} ${units[i]}`;
  }

  function fmtUptime(sec) {
    sec = Number(sec) || 0;
    const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
    return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m`;
  }

  function fmtDate(ts) {
    const d = new Date(ts * 1000);
    return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }) + " " +
      d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
  }

  function joinPath(dir, name) {
    return (dir.endsWith("/") ? dir : dir + "/") + name;
  }

  function parentPath(path) {
    const parts = path.replace(/\/+$/, "").split("/");
    parts.pop();
    return parts.join("/") || "/";
  }

  /* ── data ─────────────────────────────────────────────── */
  async function loadList() {
    try {
      const data = await LD.call("servers");
      S.list = data.servers;
      S.sshHosts = data.ssh_hosts;
    } catch (err) {
      toast("error", "Couldn't load servers", err.message);
    }
    S.loaded = true;
    $("#nav-servers-count").textContent = S.list.length || "";
  }

  async function open(id, tab = "overview") {
    S.current = id;
    S.tab = tab;
    S.info = null;
    S.infoError = "";
    S.sites = null;
    S.files = { path: "", entries: [], hidden: S.files.hidden, loading: false, error: "" };
    render();
    await loadInfo();
  }

  async function loadInfo() {
    const id = S.current;
    try {
      const info = await LD.call("server_info", { id });
      if (S.current !== id) return;
      S.info = info;
      S.infoError = "";
      const entry = server();
      if (entry) entry.connected = true;
      try {
        const pStatus = await LD.call("forge_provision_status", { server: id });
        if (S.current === id) S.provisionStatus = pStatus.status;
      } catch {}
      if (S.tab === "sites" && !S.sites) loadSites();
      if (S.tab === "files" && !S.files.path) loadFiles(info.home || "~");
    } catch (err) {
      if (S.current !== id) return;
      S.infoError = err.message;
    }
    render();
  }

  async function loadSites() {
    const id = S.current;
    try {
      const sites = await LD.call("server_sites", { id });
      if (S.current === id) S.sites = sites;
    } catch (err) {
      if (S.current === id) S.sites = { error: err.message };
    }
    render();
  }

  async function loadFiles(path) {
    const id = S.current;
    S.files.loading = true;
    renderBody();
    try {
      const res = await LD.call("server_ls", { id, path, hidden: S.files.hidden });
      if (S.current !== id) return;
      Object.assign(S.files, { path: res.path, entries: res.entries, error: "" });
    } catch (err) {
      if (S.current === id) S.files.error = err.message;
    }
    S.files.loading = false;
    renderBody();
  }

  /* ── tasks (with the sudo-password round trip) ─────────── */
  async function runRemote(action, params, show = true) {
    const payload = { server: S.current, sudo: S.info?.sudo, ...params };
    try {
      const task = await LD.call("run", { action, params: payload });
      state.activeTask = task.id;
      if (show) openActivity();
    } catch (err) {
      if (err.message === "SUDO_PASSWORD_REQUIRED") {
        if (await askSudo()) return runRemote(action, params, show);
        return;
      }
      toast("error", "Couldn't start", err.message);
    }
  }

  function askSudo() {
    const s = server();
    return new Promise((resolve) => {
      openModal(`
        <form class="modal sm" id="sudo-form">
          <div class="modal-header"><h2>Sudo password</h2>
            <p>Needed to manage services on <b>${esc(s.name)}</b>. Kept in memory until you disconnect or quit.</p></div>
          <div class="modal-body">
            <label class="field"><span>Password for ${esc(S.info?.user || s.user || "your user")}</span><input name="password" type="password" autocomplete="off"></label>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary">Unlock</button>
          </div>
        </form>`, (root) => {
        const form = $("#sudo-form", root);
        $("[data-dismiss]", form).addEventListener("click", () => { closeModal(); resolve(false); });
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          const button = $("button[type=submit]", form);
          button.disabled = true;
          try {
            await LD.call("server_sudo", { id: S.current, password: form.elements.password.value });
            closeModal();
            resolve(true);
          } catch (err) {
            button.disabled = false;
            form.elements.password.classList.add("invalid");
            form.elements.password.select();
            toast("error", err.message);
          }
        });
      });
    });
  }

  /* ── rendering ────────────────────────────────────────── */
  function render() {
    if (state.view !== "servers") return;
    if (!S.current || !server()) return renderList();
    renderServer();
  }

  function renderList() {
    S.current = null;
    const importChips = S.sshHosts.length
      ? `<div class="import-hosts"><span class="muted">From ~/.ssh/config:</span>
          ${S.sshHosts.map((h) => `<button class="btn sm" data-srv-import="${esc(h)}">${icon("plus")}${esc(h)}</button>`).join("")}</div>`
      : "";

    let body;
    if (!S.loaded) {
      body = `<div class="site-list">${'<div class="skeleton"></div>'.repeat(2)}</div>`;
    } else if (!S.list.length) {
      body = `
        <div class="empty">
          <div class="empty-icon">${icon("cloud")}</div>
          <h2>Manage your servers over SSH</h2>
          <p>Connect a VPS to see its health, restart services, deploy Laravel sites and edit files — nothing is installed on the server.</p>
          <div class="actions"><button class="btn primary" data-srv-add>${icon("plus")}Add server</button></div>
          ${importChips}
        </div>`;
    } else {
      body = `
        <div class="server-grid">
          ${S.list.map((s) => `
            <div class="card server-card" data-srv-open="${esc(s.id)}">
              <div class="server-top">
                <div class="service-icon">${icon("server")}</div>
                <div style="min-width:0">
                  <div class="service-name">${esc(s.name)}</div>
                  <div class="service-desc mono">${esc(address(s))}</div>
                </div>
                <span class="service-status"><span class="dot ${s.connected ? "on" : "off"}"></span>${s.connected ? "Connected" : "Idle"}</span>
              </div>
              <div class="btn-row">
                <button class="btn sm primary" data-srv-open="${esc(s.id)}">Open</button>
                <button class="btn sm" data-srv-terminal="${esc(s.id)}">${icon("terminal")}SSH</button>
                <button class="btn sm" data-srv-files="${esc(s.id)}">${icon("folder")}Files</button>
              </div>
            </div>`).join("")}
        </div>
        ${importChips}`;
    }

    view().innerHTML = `
      <header class="view-header">
        <div><h1>Servers</h1><p class="subtitle">Remote machines managed over SSH.</p></div>
        <div class="header-actions">
          <button class="btn icon-btn" data-srv-reload title="Refresh">${icon("refresh")}</button>
          <button class="btn primary" data-srv-add>${icon("plus")}Add server</button>
        </div>
      </header>
      <div class="view-body">${body}</div>`;
  }

  function renderServer() {
    const s = server();
    const status = S.info ? `<span class="chip ok"><span class="dot on"></span>Connected</span>`
      : S.infoError ? `<span class="chip warn">${icon("alert")}Not connected</span>`
      : `<span class="chip"><span class="status-icon running" style="width:12px;height:12px"></span>Connecting…</span>`;
    view().innerHTML = `
      <header class="view-header">
        <div class="server-title">
          <button class="btn ghost icon-btn" data-srv-back title="All servers">${icon("back")}</button>
          <div>
            <h1>${esc(s.name)} ${status}</h1>
            <p class="subtitle mono">${esc(address(s))}${S.info?.os ? ` · ${esc(S.info.os)}` : ""}</p>
          </div>
        </div>
        <div class="header-actions">
          <button class="btn" data-srv-terminal="${esc(s.id)}">${icon("terminal")}SSH terminal</button>
          <button class="btn icon-btn" data-srv-edit title="Edit server">${icon("edit")}</button>
          <button class="btn icon-btn" data-srv-disconnect title="Disconnect">${icon("power")}</button>
        </div>
      </header>
      <div class="view-body">
        <div class="tabs">
          ${["overview", "sites", "files"].map((t) => `<button class="tab ${t === S.tab ? "active" : ""}" data-srv-tab="${t}">${{ overview: "Overview", sites: "Sites", files: "Files" }[t]}</button>`).join("")}
        </div>
        <div id="srv-body"></div>
      </div>`;
    renderBody();
  }

  function renderBody() {
    const el = $("#srv-body");
    if (!el) return;
    if (S.infoError) {
      el.innerHTML = `
        <div class="card error-card">
          <h3>${icon("alert")}Couldn't connect</h3>
          <pre class="log-view" style="height:auto;min-height:0">${esc(S.infoError)}</pre>
          <div class="btn-row" style="margin-top:12px">
            <button class="btn primary sm" data-srv-retry>${icon("refresh")}Try again</button>
            <button class="btn sm" data-srv-edit>${icon("edit")}Edit connection</button>
          </div>
          <p class="muted" style="margin-bottom:0">Password, passphrase and new host-key prompts open in a separate dialog. Key-based login via ssh-agent works automatically.</p>
        </div>`;
      return;
    }
    if (!S.info) {
      el.innerHTML = `<div class="connecting"><span class="status-icon running"></span>Connecting to ${esc(server().host)}…</div>`;
      return;
    }
    if (S.tab === "overview") el.innerHTML = overview();
    if (S.tab === "sites") el.innerHTML = sitesTab();
    if (S.tab === "files") el.innerHTML = filesTab();
  }

  function meter(label, used, total, detail) {
    const pct = total ? Math.round((used / total) * 100) : 0;
    const level = pct > 90 ? "bad" : pct > 75 ? "warn" : "";
    return `
      <div class="card stat">
        <div class="stat-label">${label}</div>
        <div class="stat-value">${pct}<small>%</small></div>
        <div class="meter ${level}"><span style="width:${pct}%"></span></div>
        <div class="stat-detail">${detail}</div>
      </div>`;
  }

  function overview() {
    const i = S.info;
    const load = (i.load || "").split(" ");
    const cpuPct = i.cpus ? Math.min(100, Math.round((parseFloat(load[0]) / Number(i.cpus)) * 100)) : 0;
    const sudoLabel = { root: "Logged in as root", nopasswd: "Passwordless sudo", password: i.sudo_cached ? "Sudo unlocked" : "Sudo asks for a password" }[i.sudo];
    const provisionBanner = S.provisionStatus ? `
      <div class="card" style="border-left:4px solid var(--ok);margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;padding:12px 16px;">
        <div><strong>${icon("check")} ${t("srv_provisioned_title", "Server Provisioned (Forge Mode)")}</strong>
          <span class="muted" style="margin-inline-start:8px">${t("srv_provisioned_at", "Provisioned on")} ${esc(S.provisionStatus.provisioned_at?.split("T")[0] || "")}</span>
        </div>
        <span class="chip ok">${icon("check")} Ready</span>
      </div>` : `
      <div class="card" style="border:1px dashed var(--accent);margin-bottom:16px;padding:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
        <div>
          <h3 style="margin:0 0 4px 0;display:flex;align-items:center;gap:8px;">${icon("zap")} ${t("srv_provision_cta", "Provision this server (Forge Mode)")}</h3>
          <p class="muted" style="margin:0;font-size:13px">${t("srv_provision_desc", "Automate server setup with 1-click: Nginx, PHP 8.3 & 8.4, MySQL/MariaDB, Redis, Supervisor, Node LTS, Composer, and UFW firewall.")}</p>
        </div>
        <button class="btn primary sm" data-forge-provision>${icon("play")} ${t("srv_provision_btn", "Provision Server")}</button>
      </div>`;

    return `
      <div class="stat-grid">
        <div class="card stat">
          <div class="stat-label">CPU load</div>
          <div class="stat-value">${esc(load[0] || "–")}</div>
          <div class="meter ${cpuPct > 90 ? "bad" : cpuPct > 75 ? "warn" : ""}"><span style="width:${cpuPct}%"></span></div>
          <div class="stat-detail">${esc(i.cpus || "?")} cores · 5m ${esc(load[1] || "–")} · 15m ${esc(load[2] || "–")}</div>
        </div>
        ${meter("Memory", Number(i.mem_used), Number(i.mem_total), `${fmtBytes(Number(i.mem_used))} of ${fmtBytes(Number(i.mem_total))}`)}
        ${meter("Disk /", Number(i.disk_used), Number(i.disk_total), `${fmtBytes(Number(i.disk_used))} of ${fmtBytes(Number(i.disk_total))}`)}
        <div class="card stat">
          <div class="stat-label">Uptime</div>
          <div class="stat-value">${esc(fmtUptime(i.uptime))}</div>
          <div class="stat-detail" style="margin-top:auto">${esc(i.hostname || "")}</div>
        </div>
      </div>

      ${provisionBanner}

      <div class="two-col">
        <div class="card">
          <h3>${icon("server")}Services <span class="right"><button class="btn ghost sm" data-srv-retry title="Refresh">${icon("refresh")}</button></span></h3>
          <div class="service-rows">
            ${i.units.length ? i.units.map((u) => `
              <div class="service-row">
                ${statusDot(u.status)}<span class="mono">${esc(u.unit)}</span><span class="muted">${esc(u.status)}</span>
                <span class="row-actions">
                  ${u.status === "active"
                    ? `<button class="btn ghost sm" data-srv-service="restart" data-unit="${esc(u.unit)}">${icon("refresh")}Restart</button>
                       <button class="btn ghost sm" data-srv-service="stop" data-unit="${esc(u.unit)}">${icon("stop")}Stop</button>`
                    : `<button class="btn ghost sm" data-srv-service="start" data-unit="${esc(u.unit)}">${icon("play")}Start</button>`}
                </span>
              </div>`).join("") : `<p class="muted">No known services (nginx, apache, mysql, php-fpm, redis…) found.</p>`}
          </div>
        </div>
        <div class="card">
          <h3>${icon("cpu")}System</h3>
          <dl class="info">
            <dt>OS</dt><dd><span class="text">${esc(i.os || "–")}</span></dd>
            <dt>Kernel</dt><dd class="mono">${esc(i.kernel || "–")}</dd>
            <dt>User</dt><dd>${esc(i.user)}</dd>
            <dt>Privileges</dt><dd>${esc(sudoLabel)}</dd>
            <dt>PHP</dt><dd>${esc(i.php || "not installed")}</dd>
            <dt>Tools</dt><dd>${["git", "composer"].map((t) => `<span class="chip ${i[t] ? "ok" : ""}">${t}</span>`).join("")}</dd>
          </dl>
        </div>
      </div>`;
  }

  function sitesTab() {
    if (!S.sites) return `<div class="connecting"><span class="status-icon running"></span>Looking for sites (nginx, pm2, /var/www, home folders)…</div>`;
    if (S.sites.error) return `<div class="card error-card"><h3>${icon("alert")}Couldn't scan sites</h3><p class="muted">${esc(S.sites.error)}</p></div>`;

    const toolbar = `
      <div class="sites-toolbar" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;gap:10px;flex-wrap:wrap;">
        <span class="muted">${(S.sites && S.sites.length) ? `${S.sites.length} ${t("srv_sites_found", "site(s) found")}` : ""}</span>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button class="btn sm" data-universal-preflight>${icon("shield")} ${t("srv_preflight_btn", "Pre-Flight Check")}</button>
          <button class="btn primary sm" data-forge-new-site>${icon("rocket")} ${t("srv_deploy_any_app", "Deploy Any App")}</button>
        </div>
      </div>`;

    if (!S.sites.length) return `${toolbar}<div class="empty"><div class="empty-icon">${icon("globe")}</div><h2>No sites found</h2><p>Laravel, Next.js, Nuxt, Vite, Python, and Docker projects are discovered from nginx configs, pm2 processes, and folders under /var/www, /srv and home directories.</p><button class="btn" data-srv-tab="files">${icon("folder")}Browse files</button></div>`;
    return `${toolbar}<div class="site-list">${S.sites.map((site, idx) => {
      const chips = [];
      if (site.down) chips.push(`<span class="chip warn">Maintenance</span>`);
      if (site.is_atomic) chips.push(`<span class="chip ok">Atomic</span>`);
      if (site.type && site.type !== "laravel") chips.push(typeChip(site));
      if (site.php) chips.push(`<span class="chip php">PHP ${esc(site.php)}</span>`);
      const running = site.pm2 ? site.pm2.status === "online" : site.unit ? site.unit_status === "active" : null;
      if (running !== null) chips.push(`<span class="chip ${running ? "ok" : "warn"}"><span class="dot ${running ? "on" : "off"}"></span>${site.pm2 ? "pm2" : "systemd"}</span>`);
      if (site.branch) chips.push(`<span class="chip branch">${icon("branch")}${esc(site.branch)}</span>`);
      return `
        <div class="site-row" data-rsite="${idx}">
          ${avatar(site.name)}
          <div class="site-main">
            <div class="site-name">${esc(site.name)}</div>
            <div class="site-meta">
              ${site.url ? `<a class="link" data-srv-url="${esc(site.url)}">${esc(site.domains[0])}</a><span class="sep">·</span>` : ""}
              <span class="path mono">${esc(site.path)}</span>
            </div>
          </div>
          <div class="site-chips">${chips.join("")}</div>
          <div class="site-actions">
            <button class="btn sm" data-srv-deploy="${idx}">${icon("rocket")}Deploy</button>
          </div>
        </div>`;
    }).join("")}</div>`;
  }

  function filesTab() {
    const f = S.files;
    const crumbs = [];
    let acc = "";
    for (const part of (f.path || "/").split("/").filter(Boolean)) {
      acc += "/" + part;
      crumbs.push(`<button class="crumb" data-srv-cd="${esc(acc)}">${esc(part)}</button>`);
    }
    const rows = f.entries.map((e, idx) => `
      <tr data-rfile="${idx}" class="${e.dir ? "is-dir" : ""}">
        <td class="name"><div>${icon(e.dir ? "folder" : "file")}<span>${esc(e.name)}</span>${e.link ? `<span class="chip">link</span>` : ""}</div></td>
        <td class="muted num">${e.dir ? "—" : fmtBytes(e.size)}</td>
        <td class="muted">${fmtDate(e.mtime)}</td>
        <td class="muted mono">${esc(e.mode)}</td>
        <td class="muted">${esc(e.owner)}</td>
        <td class="row-actions">
          ${e.dir ? "" : `<button class="btn ghost icon-btn sm" data-rf="edit" title="Open in editor">${icon("edit")}</button>`}
          <button class="btn ghost icon-btn sm" data-rf="download" title="Download">${icon("download")}</button>
          <button class="btn ghost icon-btn sm" data-rf="rename" title="Rename / move">${icon("rename")}</button>
          <button class="btn ghost icon-btn sm danger" data-rf="delete" title="Delete">${icon("trash")}</button>
        </td>
      </tr>`).join("");
    return `
      <div class="file-toolbar">
        <button class="btn icon-btn sm" data-srv-cd="${esc(parentPath(f.path || "/"))}" title="Up">${icon("up")}</button>
        <button class="btn icon-btn sm" data-srv-cd="${esc(S.info.home || "~")}" title="Home">${icon("home")}</button>
        <div class="crumbs"><button class="crumb" data-srv-cd="/">/</button>${crumbs.join('<span class="sep">/</span>')}</div>
        <button class="btn sm ${f.hidden ? "active-toggle" : ""}" data-srv-hidden title="Show hidden files">${icon("eye")}Hidden</button>
        <button class="btn icon-btn sm" data-srv-cd="${esc(f.path)}" title="Refresh">${icon("refresh")}</button>
        <button class="btn sm" data-srv-new="folder">${icon("folder")}New folder</button>
        <button class="btn sm" data-srv-new="file">${icon("file")}New file</button>
        <button class="btn sm primary" data-srv-upload>${icon("upload")}Upload</button>
      </div>
      ${f.error ? `<div class="card error-card"><p style="margin:0">${esc(f.error)}</p></div>` : ""}
      <div class="card file-card ${f.loading ? "loading" : ""}">
        <table class="files">
          <thead><tr><th>Name</th><th>Size</th><th>Modified</th><th>Mode</th><th>Owner</th><th></th></tr></thead>
          <tbody>${rows || `<tr><td colspan="6" class="muted" style="padding:20px">${f.loading ? "Loading…" : "Empty folder"}</td></tr>`}</tbody>
        </table>
      </div>
      <p class="muted file-hint">Files open in your editor; every save is uploaded back to the server automatically.</p>`;
  }

  /* ── remote site drawer ───────────────────────────────── */
  function openSite(idx) {
    S.site = S.sites[idx];
    S.siteTab = "actions";
    state.drawer = { name: null, tab: "overview", details: null, currentKey: null };
    const el = $("#site-drawer");
    el.classList.add("open");
    el.setAttribute("aria-hidden", "false");
    renderSite();
  }

  function renderSite() {
    const site = S.site;
    clearInterval(logTimer);
    const laravel = (site.type || "laravel") === "laravel";
    const tabs = laravel
      ? ["actions", "deployments", "workers", "cron", "ssl", "database", "env", "logs"]
      : ["actions", "deployments", "ssl", "database", "env", "logs"];
    const tabLabels = {
      actions: t("srv_actions", "Actions"),
      deployments: t("srv_deployments", "Deployments"),
      workers: t("srv_workers", "Workers"),
      cron: t("srv_cron", "Cron"),
      ssl: t("srv_ssl", "SSL"),
      database: t("srv_database", "Database"),
      env: t("srv_env", "Environment"),
      logs: t("srv_logs", "Logs"),
    };

    const el = $("#site-drawer");
    el.innerHTML = `
      <div class="drawer-header">
        ${avatar(site.name, "lg")}
        <div style="min-width:0">
          <h2>${esc(site.name)}</h2>
          ${site.url ? `<a class="link" data-srv-url="${esc(site.url)}">${esc(site.url)}</a>` : `<span class="muted">No domain in nginx</span>`}
        </div>
        <button class="btn ghost icon-btn close" data-close-drawer title="Close (Esc)">${icon("x")}</button>
      </div>
      <div class="drawer-body">
        <div class="quick-actions">
          <button class="quick-action" data-rsa="browser" ${site.url ? "" : "disabled"}>${icon("browser")}Browser</button>
          <button class="quick-action" data-rsa="files">${icon("folder")}Files</button>
          <button class="quick-action" data-rsa="terminal">${icon("terminal")}SSH here</button>
          <button class="quick-action" data-rsite-tab="env">${icon("env")}Variables</button>
          <button class="quick-action" data-rsa="database">${icon("database")}Database</button>
        </div>
        <div class="tabs" style="overflow-x:auto;white-space:nowrap;">
          ${tabs.map((tKey) => `<button class="tab ${tKey === S.siteTab ? "active" : ""}" data-rsite-tab="${tKey}">${tabLabels[tKey] || tKey}</button>`).join("")}
        </div>
        <div id="rsite-tab"></div>
      </div>`;

    el.classList.toggle("wide", S.siteTab === "env" || S.siteTab === "deployments");
    const pane = $("#rsite-tab", el);
    if (S.siteTab === "env") {
      const laravelSite = (site.type || "laravel") === "laravel";
      EnvEditor.mount(pane, { server: S.current, path: site.path }, {
        afterSave: () => [
          ...(laravelSite ? [{ label: "Rebuild config cache", run: () => runRemote("remote-artisan", { path: site.path, php: site.php, args: "config:cache" }) }] : []),
          ...(site.pm2 || site.unit ? [{ label: "Restart app", run: () => runRemote("remote-restart", sitePayload(site)) }] : []),
          { label: "Deploy", run: () => runRemote("remote-deploy", sitePayload(site)) },
        ],
      });
      return;
    }
    if (S.siteTab === "logs") {
      pane.innerHTML = `
        <div class="log-toolbar"><span class="muted">${site.type === "laravel" ? "storage/logs/laravel.log" : site.pm2 ? "pm2 logs" : site.unit ? `journalctl -u ${esc(site.unit)}` : "Logs"} · refreshes every 5s</span>
          <button class="btn sm" data-rsa="log-refresh">${icon("refresh")}Refresh</button></div>
        <pre class="log-view" id="rlog-view">Loading…</pre>`;
      loadLog(true);
      logTimer = setInterval(() => loadLog(false), 5000);
      return;
    }
    if (S.siteTab === "deployments") {
      pane.innerHTML = `<div class="connecting"><span class="status-icon running"></span>${t("srv_loading_releases", "Loading releases…")}</div>`;
      Promise.all([
        LD.call("forge_list_releases", { server: S.current, path: site.path }),
        LD.call("deploy_recipe_get", { server: S.current, path: site.path, site_name: site.name }).catch(() => ({ entry: {} })),
      ]).then(([res, recRes]) => {
        if (S.siteTab !== "deployments") return;
        const rels = res.releases || [];
        const cur = res.current || "";
        const entry = (recRes && recRes.entry) || {};
        const recipe = entry.recipe || {};
        const stack = entry.stack || mapSiteTypeToStack(site.type);
        const layout = entry.deploy_layout === "atomic" ? "inplace" : (entry.deploy_layout || "inplace");
        const sourceMode = entry.source_mode || "git";
        const defaultHealth = recipe.health_path != null ? recipe.health_path : (stack === "laravel" ? "/up" : "/");
        const defaultPort = entry.port || site.port || (stack === "python" ? 8000 : 3000);
        const localSites = state.sites || [];
        const matchedLocal = localSites.find((s) => s.path === entry.local_path || s.name === entry.site_name);
        const localOpts = `<option value="">— ${t("srv_select_local", "Select local site or custom folder")} —</option>`
          + localSites.map((s) => `<option value="${esc(s.name)}" ${(matchedLocal && matchedLocal.name === s.name) ? "selected" : ""}>${esc(s.name)} (${esc(s.type || "app")})</option>`).join("");

        pane.innerHTML = `
          <div class="card">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px;">
              <h3 style="margin:0">${icon("rocket")} ${t("srv_universal_deploy_title", "Universal Zero-Downtime Deployment")}</h3>
              <div style="display:flex;gap:6px;flex-wrap:wrap;">
                <button class="btn sm ghost" data-universal-preflight>${icon("shield")} ${t("srv_preflight_btn", "Pre-Flight Check")}</button>
                <button class="btn sm ghost" data-universal-env-sync>${icon("env")} ${t("srv_env_sync_btn", "Sync .env")}</button>
              </div>
            </div>
            <p class="muted" style="margin-top:0">${t("srv_universal_deploy_desc", "Deploy from Git or directly from your machine using isolated atomic releases, automatic health verification, and instant rollback.")}</p>

            <div class="grid-3" style="margin-top:10px;">
              <label class="field" style="margin:0;"><span>${t("srv_stack_label", "App Stack")}</span>
                <select id="fd-stack" class="input sm">
                  <option value="laravel" ${stack === "laravel" ? "selected" : ""}>Laravel / PHP</option>
                  <option value="node_ssr" ${stack === "node_ssr" ? "selected" : ""}>Node SSR (Next / Nuxt / Nest / Express)</option>
                  <option value="static" ${stack === "static" ? "selected" : ""}>Static SPA (Vite / React / Vue)</option>
                  <option value="python" ${stack === "python" ? "selected" : ""}>Python (Django / FastAPI)</option>
                  <option value="docker" ${stack === "docker" ? "selected" : ""}>Docker / Compose</option>
                </select>
              </label>
              <label class="field" style="margin:0;"><span>${t("srv_source_mode_label", "Deploy Source")}</span>
                <select id="fd-source-mode" class="input sm">
                  <option value="git" ${sourceMode === "git" ? "selected" : ""}>${t("srv_src_git", "Git Pull on Server")}</option>
                  <option value="local_source" ${sourceMode === "local_source" ? "selected" : ""}>${t("srv_src_local_upload", "Upload Local Folder (Build on VPS)")}</option>
                  <option value="local_artifact" ${sourceMode === "local_artifact" ? "selected" : ""}>${t("srv_src_local_artifact", "Build Locally -> Upload Artifact")}</option>
                </select>
              </label>
              <label class="field" style="margin:0;"><span>${t("srv_layout_label", "Deploy Layout")}</span>
                <select id="fd-layout" class="input sm">
                  <option value="inplace" ${layout === "inplace" ? "selected" : ""}>${t("srv_layout_inplace", "Direct Folder (/var/www/project)")}</option>
                  <option value="atomic" ${layout === "atomic" ? "selected" : ""}>${t("srv_layout_atomic", "Atomic Releases (releases/current)")}</option>
                </select>
              </label>
            </div>

            <div id="fd-git-box" style="display:${sourceMode === "git" ? "grid" : "none"};grid-template-columns:1fr 120px;gap:8px;margin-top:10px;">
              <label class="field" style="margin:0;"><span>${t("srv_repo_label", "Git Repository URL")}</span><input id="fd-repo" class="input sm" placeholder="git@github.com:owner/repo.git" spellcheck="false" value="${esc(entry.repo_url || site.repo || "")}"></label>
              <label class="field" style="margin:0;"><span>${t("srv_branch_label", "Branch")}</span><input id="fd-branch" class="input sm" value="${esc(entry.branch || site.branch || "main")}" spellcheck="false"></label>
            </div>

            <div id="fd-local-box" style="display:${sourceMode === "git" ? "none" : "block"};margin-top:10px;">
              <div class="grid-2" style="gap:8px;">
                <label class="field" style="margin:0;"><span>${t("srv_local_site_label", "Local Workspace Site")}</span><select id="fd-local-site" class="input sm">${localOpts}</select></label>
                <label class="field" style="margin:0;"><span>${t("srv_local_path_label", "Or Custom Local Path")}</span>
                  <div style="display:flex;gap:6px;">
                    <input id="fd-local-path" class="input sm" placeholder="/path/to/project" spellcheck="false" value="${esc(entry.local_path || "")}">
                    <button type="button" class="btn sm" id="fd-inspect-btn">${t("srv_inspect_btn", "Inspect")}</button>
                  </div>
                </label>
              </div>
              <div id="fd-artifact-cmd-wrap" style="display:${sourceMode === "local_artifact" ? "block" : "none"};margin-top:8px;">
                <label class="field" style="margin:0;"><span>${t("srv_local_build_cmd", "Local Build Command (runs on your machine before upload)")}</span>
                  <input id="fd-local-build" class="input sm mono" placeholder="npm run build" spellcheck="false" value="${esc(recipe.build_cmd || "npm run build")}">
                </label>
              </div>
            </div>

            <div class="grid-3" style="margin-top:10px;align-items:end;">
              <label class="field" style="margin:0;"><span>${t("srv_port_label", "App Port")}</span><input id="fd-port" class="input sm mono" type="number" min="80" max="65535" value="${esc(String(defaultPort))}"></label>
              <label class="field" style="margin:0;"><span>${t("srv_health_path_label", "Health Check URL")}</span><input id="fd-health-path" class="input sm mono" value="${esc(defaultHealth)}" placeholder="/up or /" spellcheck="false"></label>
              <label class="checkbox" style="margin:0 0 6px 0;"><input type="checkbox" id="fd-auto-rollback" ${recipe.auto_rollback !== false ? "checked" : ""}><span>${t("srv_auto_rollback_label", "Auto-rollback on failure")}</span></label>
            </div>

            <details style="margin-top:12px;">
              <summary class="muted" style="cursor:pointer;font-size:13px;">${t("srv_recipe_summary", "Customize Pipeline Recipe (Build / Migrate / Start / Shared)")}</summary>
              <div class="grid-2" style="gap:8px;margin-top:10px;">
                <label class="field" style="margin:0;"><span>Install Command</span><input id="fd-rec-install" class="input sm mono" value="${esc(recipe.install_cmd || "")}" placeholder="Auto per stack"></label>
                <label class="field" style="margin:0;"><span>Build Command</span><input id="fd-rec-build" class="input sm mono" value="${esc(recipe.build_cmd || "")}" placeholder="Auto per stack"></label>
                <label class="field" style="margin:0;"><span>Migrate Command</span><input id="fd-rec-migrate" class="input sm mono" value="${esc(recipe.migrate_cmd || "")}" placeholder="Optional"></label>
                <label class="field" style="margin:0;"><span>Start / Entry Command</span><input id="fd-rec-start" class="input sm mono" value="${esc(recipe.start_cmd || "")}" placeholder="pm2 / uvicorn / docker"></label>
                <label class="field" style="margin:0;"><span>Public Output Dir</span><input id="fd-rec-public" class="input sm mono" value="${esc(recipe.public_dir || "")}" placeholder="public or dist"></label>
                <label class="field" style="margin:0;"><span>Shared Paths (comma-sep)</span><input id="fd-rec-shared" class="input sm mono" value="${esc((recipe.shared_paths || []).join(", "))}" placeholder="storage, uploads"></label>
              </div>
              <label class="checkbox" style="margin-top:8px;">
                <input type="checkbox" id="fd-save-repo-recipe">
                <span>${t("srv_save_repo_recipe", "Also write .laravel-dev-deploy.json inside local project folder")}</span>
              </label>
            </details>

            <div class="btn-row" style="margin-top:14px;">
              <button class="btn primary sm" data-universal-site-deploy>${icon("rocket")} ${t("srv_deploy_btn", "Deploy Now")}</button>
              <button class="btn sm" data-universal-save-recipe>${icon("check")} ${t("srv_save_recipe_btn", "Save Recipe")}</button>
            </div>
          </div>

          <div class="card" style="margin-top:16px;">
            <h3>${icon("history")} ${t("srv_rollback_title", "Release History & Rollback")}</h3>
            ${cur ? `<div style="margin-bottom:12px;">${t("srv_active_release", "Active Release")}: <span class="chip ok">${esc(cur)}</span></div>` : ""}
            ${rels.length ? `
              <table class="files" style="width:100%;">
                <thead><tr><th>Release ID</th><th>Date</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                  ${rels.map((r) => `
                    <tr>
                      <td class="mono font-semibold">${esc(r.id)}</td>
                      <td class="muted">${fmtDate(r.timestamp)}</td>
                      <td>${r.active ? `<span class="chip ok">Current</span>` : `<span class="chip">Stored</span>`}</td>
                      <td>${r.active ? "—" : `<button class="btn sm ghost" data-forge-do-rollback="${esc(r.id)}">${icon("refresh")} ${t("srv_rollback_btn", "Rollback")}</button>`}</td>
                    </tr>
                  `).join("")}
                </tbody>
              </table>` : `<p class="muted">Direct directory mode (<span class="mono">${esc(site.path)}</span>) — project files live directly in the site folder without duplicate release copies.</p>`}
          </div>`;

        const srcSel = $("#fd-source-mode", pane);
        srcSel?.addEventListener("change", () => {
          const mode = srcSel.value;
          $("#fd-git-box", pane).style.display = mode === "git" ? "grid" : "none";
          $("#fd-local-box", pane).style.display = mode === "git" ? "none" : "block";
          $("#fd-artifact-cmd-wrap", pane).style.display = mode === "local_artifact" ? "block" : "none";
        });
        $("#fd-local-site", pane)?.addEventListener("change", async (ev) => {
          const val = ev.target.value;
          if (!val) return;
          try {
            const det = await LD.call("deploy_inspect_local", { local_site: val });
            if (det && det.ok) {
              $("#fd-local-path", pane).value = det.path || "";
              if (det.stack) $("#fd-stack", pane).value = det.stack;
              if (det.port) $("#fd-port", pane).value = det.port;
              if (det.health_path) $("#fd-health-path", pane).value = det.health_path;
              if (det.install_cmd) $("#fd-rec-install", pane).value = det.install_cmd;
              if (det.build_cmd) $("#fd-rec-build", pane).value = det.build_cmd;
              if (det.local_build_cmd) $("#fd-local-build", pane).value = det.local_build_cmd;
              if (det.start_cmd) $("#fd-rec-start", pane).value = det.start_cmd;
              if (det.public_dir) $("#fd-rec-public", pane).value = det.public_dir;
            }
          } catch {}
        });
        $("#fd-inspect-btn", pane)?.addEventListener("click", async () => {
          const localSite = $("#fd-local-site", pane)?.value || "";
          const localPath = $("#fd-local-path", pane)?.value?.trim() || "";
          try {
            const det = await LD.call("deploy_inspect_local", { local_site: localSite, local_path: localPath });
            if (!det || !det.ok) return toast("error", "Inspection failed", det?.error || "Folder not found");
            $("#fd-local-path", pane).value = det.path || localPath;
            if (det.stack) $("#fd-stack", pane).value = det.stack;
            if (det.port) $("#fd-port", pane).value = det.port;
            if (det.health_path) $("#fd-health-path", pane).value = det.health_path;
            if (det.install_cmd) $("#fd-rec-install", pane).value = det.install_cmd;
            if (det.build_cmd) $("#fd-rec-build", pane).value = det.build_cmd;
            if (det.local_build_cmd) $("#fd-local-build", pane).value = det.local_build_cmd;
            if (det.start_cmd) $("#fd-rec-start", pane).value = det.start_cmd;
            if (det.public_dir) $("#fd-rec-public", pane).value = det.public_dir;
            toast("success", `Detected ${det.framework || det.stack}`, `Suggested port ${det.port}`);
          } catch (err) {
            toast("error", "Inspection failed", err.message);
          }
        });
      }).catch((err) => {
        pane.innerHTML = `<div class="card error-card"><p>${esc(err.message)}</p></div>`;
      });
      return;
    }
    if (S.siteTab === "workers") {
      pane.innerHTML = `
        <div class="card">
          <h3>${icon("cpu")} ${t("srv_worker_title", "Background Queue Workers (Supervisor)")}</h3>
          <p class="muted" style="margin-top:0">${t("srv_worker_desc", "Manages persistent queue workers using Supervisor running under the web user.")}</p>
          <div style="display:grid;grid-template-columns:1fr 120px auto;gap:8px;align-items:end;margin-top:12px;">
            <label class="field" style="margin:0;"><span>${t("srv_worker_queue", "Queue Name(s)")}</span><input id="fw-queue" class="input sm" value="default" spellcheck="false"></label>
            <label class="field" style="margin:0;"><span>${t("srv_worker_procs", "Number of Processes")}</span><input id="fw-procs" class="input sm" type="number" min="1" max="16" value="1"></label>
            <button class="btn primary sm" data-forge-save-worker>${icon("play")} ${t("srv_worker_save_btn", "Save & Start Worker")}</button>
          </div>
        </div>`;
      return;
    }
    if (S.siteTab === "cron") {
      const cronDir = site.is_atomic ? `${site.path}/current` : site.path;
      pane.innerHTML = `
        <div class="card">
          <h3>${icon("clock")} ${t("srv_cron_title", "Laravel Scheduler (Cron)")}</h3>
          <p class="muted" style="margin-top:0">${t("srv_cron_desc", "Executes the Laravel scheduled console commands every minute.")}</p>
          <pre class="log-view" style="height:auto;min-height:0;padding:8px 12px;margin:12px 0;">* * * * * cd ${esc(cronDir)} && php artisan schedule:run >> /dev/null 2>&1</pre>
          <div class="btn-row">
            <button class="btn primary sm" data-forge-cron="enable">${icon("play")} ${t("srv_cron_enable_btn", "Enable Scheduler")}</button>
            <button class="btn sm danger" data-forge-cron="disable">${icon("stop")} ${t("srv_cron_disable_btn", "Disable Scheduler")}</button>
          </div>
        </div>`;
      return;
    }
    if (S.siteTab === "ssl") {
      pane.innerHTML = `
        <div class="card">
          <h3>${icon("shield")} ${t("srv_ssl_title", "Automated SSL Certificate (Let's Encrypt)")}</h3>
          <p class="muted" style="margin-top:0">${t("srv_ssl_desc", "Obtains and renews free SSL certificates via Certbot for Nginx.")}</p>
          <div style="margin:12px 0;">
            <span class="muted">Domain:</span> <strong>${esc(site.domains[0] || site.name)}</strong>
            ${site.ssl ? `<span class="chip ok" style="margin-inline-start:8px">${icon("check")} SSL Active</span>` : `<span class="chip warn" style="margin-inline-start:8px">HTTP Only</span>`}
          </div>
          <div style="display:flex;gap:8px;align-items:end;margin-top:12px;">
            <label class="field" style="margin:0;flex:1;"><span>${t("srv_ssl_email", "Contact Email")}</span><input id="fssl-email" class="input sm" type="email" placeholder="admin@example.com"></label>
            <button class="btn primary sm" data-forge-issue-ssl>${icon("shield")} ${t("srv_ssl_issue_btn", "Issue Certificate")}</button>
          </div>
        </div>`;
      return;
    }
    if (S.siteTab === "database") {
      const localSites = (state.sites || []).map((s) => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join("");
      pane.innerHTML = `
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">
            <div>
              <h3 style="margin:0;">${icon("database")} ${t("srv_db_conn_title", "Database Connection & Server Provisioning")}</h3>
              <p class="muted" style="margin:4px 0 0">${t("srv_db_conn_desc", "Enter existing database credentials or create/sync the database and user directly on the server.")}</p>
            </div>
            <button class="btn sm" id="sdb-open-mgr-btn">${icon("database")} ${t("srv_db_open_mgr", "Open in Database Manager")}</button>
          </div>
          <div id="sdb-env-badge" class="muted mono" style="font-size:11px;margin-top:6px;">Loading .env database settings…</div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:12px;">
            <label class="field" style="margin:0;"><span>${t("srv_db_engine_label", "Database Engine")}</span>
              <select id="sdb-driver" class="input sm">
                <option value="mysql">MySQL / MariaDB</option>
                <option value="pgsql">PostgreSQL</option>
              </select>
            </label>
            <label class="field" style="margin:0;"><span>${t("srv_db_host_label", "DB Host")}</span>
              <input id="sdb-host" class="input sm mono" value="127.0.0.1" placeholder="127.0.0.1">
            </label>
            <label class="field" style="margin:0;"><span>${t("srv_db_port_label", "DB Port")}</span>
              <input id="sdb-port" class="input sm mono" value="3306" placeholder="3306">
            </label>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px;">
            <label class="field" style="margin:0;">
              <span style="display:flex;justify-content:space-between;align-items:center;">
                <span>${t("srv_db_name_req", "Database Name")}</span>
                <select id="sdb-existing-dbs" class="input sm" style="width:auto;height:22px;padding:0 6px;font-size:11px;">
                  <option value="">${t("srv_db_pick_existing", "— Pick existing on server —")}</option>
                </select>
              </span>
              <input id="sdb-name" class="input sm mono" placeholder="my_app_db" spellcheck="false">
            </label>
            <label class="field" style="margin:0;"><span>${t("srv_db_user_label", "Database Username")}</span>
              <input id="sdb-user" class="input sm mono" placeholder="my_app_user" spellcheck="false">
            </label>
          </div>
          <div style="display:grid;grid-template-columns:1fr auto;gap:8px;align-items:end;margin-top:10px;">
            <label class="field" style="margin:0;"><span>${t("srv_db_pass_label", "Database Password")}</span>
              <input id="sdb-pass" class="input sm mono" type="password" placeholder="Enter password or click Generate" spellcheck="false">
            </label>
            <div class="btn-row" style="margin:0;">
              <button type="button" class="btn sm" id="sdb-toggle-pass">${t("srv_db_show_pass", "Show")}</button>
              <button type="button" class="btn sm" id="sdb-gen-pass">${icon("key")} ${t("srv_db_gen_pass", "Generate")}</button>
            </div>
          </div>
          <div class="btn-row" style="margin-top:14px;gap:8px;flex-wrap:wrap;">
            <button type="button" class="btn primary sm" data-sdb-save="create">${icon("check")} ${t("srv_db_create_and_save", "Create / Sync on Server & Save .env")}</button>
            <button type="button" class="btn sm" data-sdb-save="env_only">${icon("file")} ${t("srv_db_save_env_only", "Save Credentials to .env Only")}</button>
          </div>
        </div>

        <div class="card">
          <h3>${icon("database")} ${t("srv_db_pull_title", "Pull Production Database to Local")}</h3>
          <p class="muted" style="margin-top:0">${t("srv_db_pull_desc", "Dumps the remote database via SSH and imports it directly into your local development database.")}</p>
          <div class="notice" style="margin:12px 0;">${icon("shield")} <span>${t("srv_db_safety_notice", "Safety First: A complete local database snapshot will be created automatically before importing.")}</span></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px;">
            <label class="field"><span>${t("srv_db_target_local", "Local Target Site")}</span><select id="fdb-local-site" class="input sm">${localSites}</select></label>
            <label class="field"><span>${t("srv_db_exclude", "Exclude Tables")}</span><input id="fdb-exclude" class="input sm" value="sessions,jobs,telescope_entries"></label>
          </div>
          <div class="btn-row" style="margin-top:12px;">
            <button class="btn primary sm" data-forge-pull-db>${icon("download")} ${t("srv_db_pull_btn", "Pull Database Now")}</button>
          </div>
        </div>`;

      (async () => {
        try {
          const info = await LD.call("server_db_info", { server: S.current, path: site.path });
          if (!pane.isConnected) return;
          const drvEl = $("#sdb-driver", pane);
          const hostEl = $("#sdb-host", pane);
          const portEl = $("#sdb-port", pane);
          const nameEl = $("#sdb-name", pane);
          const userEl = $("#sdb-user", pane);
          const passEl = $("#sdb-pass", pane);
          const badgeEl = $("#sdb-env-badge", pane);
          const pickerEl = $("#sdb-existing-dbs", pane);
          if (!drvEl) return;
          drvEl.value = info.driver === "pgsql" ? "pgsql" : "mysql";
          hostEl.value = info.host || "127.0.0.1";
          portEl.value = info.port || (drvEl.value === "pgsql" ? "5432" : "3306");
          nameEl.value = info.database || "";
          userEl.value = info.user || "";
          passEl.value = info.password || "";
          badgeEl.textContent = info.env_path ? `.env file: ${info.env_path}` : "";

          const syncDbPicker = () => {
            const list = drvEl.value === "pgsql" ? (info.pgsql_databases || []) : (info.mysql_databases || []);
            pickerEl.innerHTML = `<option value="">${t("srv_db_pick_existing", "— Pick existing on server —")} (${list.length})</option>` +
              list.map((d) => `<option value="${esc(d)}">${esc(d)}</option>`).join("");
          };
          syncDbPicker();
          drvEl.addEventListener("change", () => {
            portEl.value = drvEl.value === "pgsql" ? "5432" : "3306";
            syncDbPicker();
          });
          pickerEl.addEventListener("change", () => {
            if (pickerEl.value) {
              nameEl.value = pickerEl.value;
              if (!userEl.value) userEl.value = pickerEl.value.slice(0, 28);
            }
          });
        } catch (err) {
          const badgeEl = $("#sdb-env-badge", pane);
          if (badgeEl) badgeEl.textContent = `Could not load .env database info: ${err.message}`;
        }
      })();

      $("#sdb-toggle-pass", pane)?.addEventListener("click", (ev) => {
        const inp = $("#sdb-pass", pane);
        if (!inp) return;
        const show = inp.type === "password";
        inp.type = show ? "text" : "password";
        ev.currentTarget.textContent = show ? t("srv_db_hide_pass", "Hide") : t("srv_db_show_pass", "Show");
      });
      $("#sdb-gen-pass", pane)?.addEventListener("click", () => {
        const inp = $("#sdb-pass", pane);
        if (!inp) return;
        const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
        let out = "";
        for (let i = 0; i < 20; i++) out += chars[Math.floor(Math.random() * chars.length)];
        inp.value = out;
        inp.type = "text";
        const btn = $("#sdb-toggle-pass", pane);
        if (btn) btn.textContent = t("srv_db_hide_pass", "Hide");
      });
      $$("[data-sdb-save]", pane).forEach((btn) => {
        btn.addEventListener("click", async () => {
          const mode = btn.dataset.sdbSave;
          const driver = $("#sdb-driver", pane).value;
          const host = $("#sdb-host", pane).value.trim() || "127.0.0.1";
          const port = $("#sdb-port", pane).value.trim() || (driver === "pgsql" ? "5432" : "3306");
          const database = $("#sdb-name", pane).value.trim();
          const user = $("#sdb-user", pane).value.trim() || database.slice(0, 28);
          const password = $("#sdb-pass", pane).value;
          if (!database) return toast("error", "Database name required", "Enter a database name first.");
          btn.disabled = true;
          try {
            const res = await LD.call("server_db_configure", {
              server: S.current,
              path: site.path,
              driver,
              host,
              port,
              database,
              user,
              password,
              mode,
            });
            if (res.password && !$("#sdb-pass", pane).value) {
              $("#sdb-pass", pane).value = res.password;
            }
            if (res.user && !$("#sdb-user", pane).value) {
              $("#sdb-user", pane).value = res.user;
            }
            toast(
              "success",
              mode === "create" ? "Database provisioned & .env updated" : "Database credentials saved to .env",
              `${res.database} (${res.user}@${res.host}:${res.port})`
            );
          } catch (err) {
            toast("error", "Database configuration failed", err.message);
          } finally {
            btn.disabled = false;
          }
        });
      });
      $("#sdb-open-mgr-btn", pane)?.addEventListener("click", async () => {
        try {
          toast("success", "Opening the database through SSH…");
          const target = await LD.call("server_db", { id: S.current, path: site.path });
          closeDrawer();
          setView("database");
          Database.open(target.conn, target.database);
        } catch (err) {
          toast("error", "Couldn't open the database", err.message);
        }
      });
      return;
    }
    const django = site.type === "django";
    const commands = laravel ? `
          <button class="btn sm" data-rsa="pull">${icon("download")}git pull</button>
          <button class="btn sm" data-rsa="composer">composer install</button>
          <button class="btn sm" data-ra="migrate --force">migrate</button>
          <button class="btn sm" data-ra="optimize:clear">optimize:clear</button>
          <button class="btn sm" data-ra="queue:restart">queue:restart</button>
          <button class="btn sm" data-rsa="${site.down ? "up" : "down"}">${site.down ? "Bring back up" : "Maintenance mode"}</button>` : `
          <button class="btn sm" data-rsa="pull">${icon("download")}git pull</button>
          <button class="btn sm" data-rsa="install">${django ? "pip install" : "Install dependencies"}</button>
          ${django ? `<button class="btn sm" data-rm="migrate --noinput">migrate</button>
                      <button class="btn sm" data-rm="collectstatic --noinput">collectstatic</button>`
                   : `<button class="btn sm" data-rsa="build">Build</button>`}
          ${site.pm2 || site.unit ? `<button class="btn sm" data-rsa="restart">${icon("refresh")}Restart</button>` : ""}`;
    const input = laravel
      ? `<form class="artisan-input" data-rartisan><span class="prefix">php artisan</span><input name="args" placeholder="about" spellcheck="false"><button class="btn sm" type="submit">Run</button></form>`
      : django
        ? `<form class="artisan-input" data-rmanage><span class="prefix">manage.py</span><input name="args" placeholder="showmigrations" spellcheck="false"><button class="btn sm" type="submit">Run</button></form>`
        : "";

    pane.innerHTML = `
      <div class="card">
        <dl class="info">
          <dt>Path</dt><dd><span class="text mono selectable" title="${esc(site.path)}">${esc(site.path)}</span>
            <button class="btn ghost icon-btn sm" data-copy="${esc(site.path)}" title="Copy path">${icon("copy")}</button></dd>
          <dt>Type</dt><dd>${laravel ? `<span class="chip type" style="--type:${TYPES.laravel.color}">Laravel</span>` : typeChip(site)}</dd>
          ${site.domains.length ? `<dt>Domains</dt><dd><span class="text">${esc(site.domains.join(", "))}</span></dd>` : ""}
          ${site.php ? `<dt>PHP</dt><dd>${esc(site.php)}</dd>` : ""}
          ${site.port ? `<dt>Port</dt><dd class="mono">${esc(site.port)}</dd>` : ""}
          ${runnerLabel(site) ? `<dt>Runs with</dt><dd>${runnerLabel(site)}</dd>` : ""}
          ${site.branch ? `<dt>Branch</dt><dd>${icon("branch")}${esc(site.branch)}</dd>` : ""}
          ${laravel ? `<dt>Status</dt><dd>${site.down ? `<span class="chip warn">Maintenance mode</span>` : `<span class="chip ok">Live</span>`}</dd>` : ""}
        </dl>
      </div>

      <div class="card deploy-card">
        <h3>${icon("rocket")}Deploy</h3>
        <p class="muted" style="margin-top:0">Runs ${DEPLOY_STEPS[site.type] || DEPLOY_STEPS.node}.</p>
        ${!laravel && !site.pm2 && !site.unit && !site.is_atomic && !["static", "vite", "react", "vue", "docker"].includes(site.type || "") ? `<div class="notice">${icon("alert")}<span>No pm2 process or systemd unit runs this app, so deploy can't restart it.</span></div>` : ""}
        <button class="btn primary" data-rsa="deploy">${icon("rocket")}Deploy now</button>
      </div>

      <div class="card">
        <h3>${icon("terminal")}Commands</h3>
        <div class="btn-row">${commands}</div>
        ${input}
      </div>`;
  }

  async function loadLog(scrollToEnd) {
    const view = $("#rlog-view");
    if (!view || !S.site || !$("#site-drawer").classList.contains("open")) {
      clearInterval(logTimer); // drawer closed: stop polling the server
      return;
    }
    const atBottom = view.scrollHeight - view.scrollTop - view.clientHeight < 40;
    try {
      const log = await LD.call("server_log", { id: S.current, ...sitePayload(S.site) });
      const current = $("#rlog-view");
      if (!current) return;
      current.innerHTML = log.exists && log.text
        ? log.text.split("\n").map((line) => {
            const cls = /\.(ERROR|CRITICAL|ALERT|EMERGENCY):/.test(line) ? "log-line-error" : /\.WARNING:/.test(line) ? "log-line-warning" : "";
            return cls ? `<span class="${cls}">${esc(line)}</span>` : esc(line);
          }).join("\n")
        : `<span style="opacity:.6">${esc(log.hint || (log.exists ? "Log is empty." : "No log yet."))}</span>`;
      if (scrollToEnd || atBottom) current.scrollTop = current.scrollHeight;
    } catch (err) {
      const current = $("#rlog-view");
      if (current) current.textContent = err.message;
    }
  }

  /* ── server form ──────────────────────────────────────── */
  async function serverModal(existing = {}) {
    const sshEnv = await LD.call("ssh_environment").catch(() => ({
      local_user: "", keys: [], config_hosts: [], agent_active: false, agent_keys: [],
    }));
    const configHosts = sshEnv.config_hosts || [];
    const discKeys = sshEnv.keys || [];
    const localUser = sshEnv.local_user || "";
    const curAuth = existing.auth_mode || "auto";
    const curKey = existing.key || "";
    const keyMatched = discKeys.some((k) => k.path === curKey);
    const keySelectVal = !curKey ? "" : (keyMatched ? curKey : "__custom__");
    const userChips = Array.from(new Set([localUser, "root", "ubuntu", "forge", "deploy"].filter(Boolean)));
    const agentBadge = sshEnv.agent_active
      ? (sshEnv.agent_keys?.length
        ? `<span class="ssh-agent-pill ok">${icon("key")} ${esc(t("ssh_agent_running"))} (${sshEnv.agent_keys.length})</span>`
        : `<span class="ssh-agent-pill">${icon("key")} ${esc(t("ssh_agent_empty"))}</span>`)
      : `<span class="ssh-agent-pill">${icon("info")} ${esc(t("ssh_agent_inactive"))}</span>`;

    openModal(`
      <form class="modal" id="server-form" novalidate>
        <div class="modal-header">
          <h2>${esc(existing.id ? t("srv_edit_title") : t("srv_add_title"))}</h2>
          <p>${esc(t("srv_modal_sub"))}</p>
        </div>
        <div class="modal-body">
          ${configHosts.length ? `
          <label class="field">
            <span>${esc(t("ssh_config_import"))}</span>
            <select class="input" data-ssh-config-pick>
              <option value="">${esc(t("ssh_config_select"))}</option>
              ${configHosts.map((h) => `<option value="${esc(h.alias)}">${esc(h.alias)}${h.hostname ? ` → ${esc(h.hostname)}` : ""}${h.user ? ` (${esc(h.user)})` : ""}${h.saved ? " ✓" : ""}</option>`).join("")}
            </select>
          </label>` : ""}
          <label class="field"><span>${esc(t("srv_name_label"))}</span><input name="name" placeholder="Production" value="${esc(existing.name || "")}"></label>
          <div class="grid-2">
            <label class="field"><span>${esc(t("srv_host_label"))}</span><input name="host" placeholder="203.0.113.10" spellcheck="false" value="${esc(existing.host || "")}"></label>
            <label class="field"><span>${esc(t("srv_port_label"))}</span><input name="port" placeholder="22" inputmode="numeric" value="${esc(existing.port || "")}"></label>
          </div>
          <label class="field">
            <span>${esc(t("ssh_auth_mode"))}</span>
            <div class="seg" role="group" data-auth-seg>
              <button type="button" class="seg-btn ${curAuth === "auto" ? "active" : ""}" data-auth-val="auto">${esc(t("ssh_auth_auto"))}</button>
              <button type="button" class="seg-btn ${curAuth === "key" ? "active" : ""}" data-auth-val="key">${esc(t("ssh_auth_key"))}</button>
              <button type="button" class="seg-btn ${curAuth === "password" ? "active" : ""}" data-auth-val="password">${esc(t("ssh_auth_password"))}</button>
            </div>
            <input type="hidden" name="auth_mode" value="${esc(curAuth)}">
            <small class="ssh-auth-hint" data-auth-hint></small>
          </label>
          <label class="field" data-user-field>
            <span>${esc(t("ssh_user_label"))} <small data-user-opt>(${esc(t("ssh_user_optional"))})</small></span>
            <input name="user" placeholder="${esc(localUser || "forge")}" spellcheck="false" value="${esc(existing.user || "")}">
            ${userChips.length ? `<div class="ssh-quick-chips">${userChips.map((u) => `<button type="button" class="ssh-chip-btn" data-user-chip="${esc(u)}">${esc(u)}</button>`).join("")}</div>` : ""}
          </label>
          <label class="field" data-key-field>
            <span>${esc(t("ssh_key_label"))}</span>
            <select class="input" data-key-select style="margin-bottom:6px">
              <option value="" ${keySelectVal === "" ? "selected" : ""}>${esc(t("ssh_key_auto_opt"))}</option>
              ${discKeys.map((k) => `<option value="${esc(k.path)}" ${keySelectVal === k.path ? "selected" : ""}>${esc(k.name)} (${esc(k.type)}${k.has_pub ? "" : ", no .pub"})</option>`).join("")}
              <option value="__custom__" ${keySelectVal === "__custom__" ? "selected" : ""}>${esc(t("ssh_key_custom_opt"))}</option>
            </select>
            <span class="input-group" style="width:100%;display:${keySelectVal === "__custom__" ? "flex" : "none"}" data-key-custom-row>
              <input name="key" placeholder="~/.ssh/id_ed25519" spellcheck="false" value="${esc(curKey)}">
              <button type="button" class="btn" data-pick-key>${esc(t("ssh_browse"))}</button>
            </span>
            <div>${agentBadge}</div>
          </label>
          <div class="ssh-inline-test">
            <button type="button" class="btn sm" data-test-ssh>${icon("check")} ${esc(t("ssh_test_btn"))}</button>
            <div class="ssh-inline-result muted" data-ssh-test-out></div>
          </div>
        </div>
        <div class="modal-footer">
          ${existing.id ? `<button type="button" class="btn danger" data-remove style="margin-right:auto">${icon("trash")}Remove</button>` : ""}
          <button type="button" class="btn" data-dismiss>${esc(t("cancel"))}</button>
          <button type="submit" class="btn primary">${existing.id ? esc(t("save")) : `${icon("plus")}${esc(t("srv_add_connect"))}`}</button>
        </div>
      </form>`, (root) => {
      const form = $("#server-form", root);
      const f = form.elements;
      const hintEl = $("[data-auth-hint]", form);
      const keySelect = $("[data-key-select]", form);
      const customKeyRow = $("[data-key-custom-row]", form);
      const keyField = $("[data-key-field]", form);
      const testOut = $("[data-ssh-test-out]", form);

      function syncAuthUI(mode) {
        f.auth_mode.value = mode;
        $$("[data-auth-val]", form).forEach((btn) => btn.classList.toggle("active", btn.dataset.authVal === mode));
        const hints = { auto: t("ssh_auth_auto_hint"), key: t("ssh_auth_key_hint"), password: t("ssh_auth_password_hint") };
        hintEl.textContent = hints[mode] || "";
        keyField.style.display = mode === "password" ? "none" : "";
      }

      syncAuthUI(curAuth);

      $$("[data-auth-val]", form).forEach((btn) => {
        btn.addEventListener("click", () => syncAuthUI(btn.dataset.authVal));
      });

      $("[data-ssh-config-pick]", form)?.addEventListener("change", (e) => {
        const picked = configHosts.find((h) => h.alias === e.target.value);
        if (!picked) return;
        f.host.value = picked.alias;
        if (!existing.name && !f.name.dataset.touched) f.name.value = picked.alias;
        f.port.value = picked.port || "";
        f.user.value = picked.user || "";
        if (picked.identityfile) {
          const matched = discKeys.some((k) => k.path === picked.identityfile);
          keySelect.value = matched ? picked.identityfile : "__custom__";
          customKeyRow.style.display = matched ? "none" : "flex";
          f.key.value = picked.identityfile;
          syncAuthUI("key");
        } else {
          keySelect.value = "";
          customKeyRow.style.display = "none";
          f.key.value = "";
          syncAuthUI("auto");
        }
      });

      $$("[data-user-chip]", form).forEach((chip) => {
        chip.addEventListener("click", () => { f.user.value = chip.dataset.userChip; });
      });

      keySelect.addEventListener("change", () => {
        const val = keySelect.value;
        if (val === "__custom__") {
          customKeyRow.style.display = "flex";
          f.key.focus();
        } else {
          customKeyRow.style.display = "none";
          f.key.value = val;
        }
      });

      f.host.addEventListener("input", () => { if (!existing.name && !f.name.dataset.touched) f.name.value = f.host.value; });
      f.name.addEventListener("input", () => (f.name.dataset.touched = "1"));
      $("[data-dismiss]", form).addEventListener("click", closeModal);
      $("[data-pick-key]", form).addEventListener("click", async () => {
        const path = await api("pick_file", { title: t("ssh_key_label"), current: "~/.ssh" });
        if (path) {
          f.key.value = path;
          keySelect.value = "__custom__";
          customKeyRow.style.display = "flex";
        }
      });
      $("[data-test-ssh]", form).addEventListener("click", async () => {
        testOut.className = "ssh-inline-result muted";
        testOut.innerHTML = `${icon("loader", "spin")} <span>${esc(t("ssh_testing"))}</span>`;
        try {
          const res = await LD.call("server_test", {
            id: existing.id,
            host: f.host.value,
            port: f.port.value,
            user: f.user.value,
            key: f.key.value,
            auth_mode: f.auth_mode.value,
          });
          testOut.className = "ssh-inline-result ok";
          testOut.innerHTML = `${icon("check")} <span>OK (${res.ms}ms · ${esc(res.auth_mode || f.auth_mode.value)})</span>`;
        } catch (err) {
          testOut.className = "ssh-inline-result err";
          testOut.innerHTML = `${icon("alert")} <span>${esc(err.message)}</span>`;
        }
      });
      $("[data-remove]", form)?.addEventListener("click", async () => {
        closeModal();
        if (!(await confirmModal({ title: `Remove ${existing.name}?`, danger: true, confirm: "Remove", message: "Only the saved connection is removed. Nothing changes on the server." }))) return;
        await api("server_remove", { id: existing.id });
        S.current = null;
        await loadList();
        render();
      });
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const saved = await LD.call("server_save", {
            id: existing.id,
            name: f.name.value,
            host: f.host.value,
            port: f.port.value,
            user: f.user.value,
            key: f.key.value,
            auth_mode: f.auth_mode.value,
          });
          closeModal();
          await loadList();
          open(saved.id, S.tab);
        } catch (err) {
          toast("error", err.message);
        }
      });
    });
  }

  function collectDrawerDeployPayload() {
    const pane = $("#rsite-tab");
    const stack = $("#fd-stack", pane)?.value || mapSiteTypeToStack(S.site?.type);
    const source_mode = $("#fd-source-mode", pane)?.value || "git";
    const deploy_layout = $("#fd-layout", pane)?.value || "inplace";
    const repo_url = $("#fd-repo", pane)?.value?.trim() || "";
    const branch = $("#fd-branch", pane)?.value?.trim() || "main";
    const local_site = $("#fd-local-site", pane)?.value || "";
    const local_path = $("#fd-local-path", pane)?.value?.trim() || "";
    const port = +($("#fd-port", pane)?.value || (stack === "python" ? 8000 : 3000));
    const health_path = $("#fd-health-path", pane)?.value?.trim() ?? (stack === "laravel" ? "/up" : "/");
    const auto_rollback = !!$("#fd-auto-rollback", pane)?.checked;
    const local_build_cmd = $("#fd-local-build", pane)?.value?.trim() || "";
    const sharedRaw = $("#fd-rec-shared", pane)?.value || "";
    const shared_paths = sharedRaw.split(",").map((x) => x.trim()).filter(Boolean);
    const public_dir = $("#fd-rec-public", pane)?.value?.trim() || "";
    const recipe = {
      install_cmd: $("#fd-rec-install", pane)?.value?.trim() || "",
      build_cmd: $("#fd-rec-build", pane)?.value?.trim() || "",
      migrate_cmd: $("#fd-rec-migrate", pane)?.value?.trim() || "",
      start_cmd: $("#fd-rec-start", pane)?.value?.trim() || "",
      public_dir,
      shared_paths,
      health_path,
      auto_rollback,
    };
    return {
      path: S.site.path,
      site_name: S.site.name,
      domain: (S.site.domains && S.site.domains[0]) || S.site.name,
      php: S.site.php || "8.3",
      stack,
      source_mode,
      deploy_layout,
      repo_url,
      branch,
      local_site,
      local_path,
      port,
      public_dir,
      health_path,
      auto_rollback,
      local_build_cmd,
      save_to_repo: !!$("#fd-save-repo-recipe", pane)?.checked,
      recipe,
    };
  }

  async function startUniversalDeploy(payload) {
    const full = { server: S.current, sudo: S.info?.sudo, ...payload };
    try {
      const task = await LD.call("deploy_universal_start", full);
      state.activeTask = task.id;
      openActivity();
      return task;
    } catch (err) {
      if (err.message === "SUDO_PASSWORD_REQUIRED") {
        if (await askSudo()) return startUniversalDeploy(payload);
        return null;
      }
      toast("error", "Couldn't start deploy", err.message);
      return null;
    }
  }

  /* ── pre-flight modal ─────────────────────────────────── */
  async function openPreFlightModal(prefStack = "", prefPath = "/var/www") {
    openModal(`
      <div class="modal">
        <div class="modal-header">
          <h2>${icon("shield")} ${t("srv_preflight_title", "VPS Pre-Flight & Readiness Check")}</h2>
          <p>${esc(server()?.name || "")} · <span class="mono">${esc(prefPath)}</span></p>
        </div>
        <div class="modal-body" id="pf-modal-body">
          <div class="connecting"><span class="status-icon running"></span>${t("srv_preflight_scanning", "Scanning tools, RAM, swap, ports and permissions…")}</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>${t("close", "Close")}</button>
        </div>
      </div>`, async (root) => {
      $("[data-dismiss]", root).addEventListener("click", closeModal);
      const body = $("#pf-modal-body", root);
      try {
        const res = await LD.call("remote_preflight", { server: S.current, stack: prefStack, path: prefPath });
        S.preflight = res;
        const tools = res.tools || {};
        const sys = res.sys || {};
        const installable = ["node", "npm", "pm2", "composer", "python3", "docker", "certbot", "nginx", "git"];
        const isInstalled = (v) => Boolean(v && (typeof v === "object" ? v.installed : v));
        const toolVer = (v) => (v && typeof v === "object" ? (v.version || (v.installed ? "Installed" : "")) : String(v || ""));
        const missingList = installable.filter((k) => !isInstalled(tools[k]) && k !== "npm");
        const toolChips = Object.entries(tools).map(([k, v]) => {
          const ok = isInstalled(v);
          return `
          <div class="pf-tool-item ${ok ? "ok" : "missing"}">
            <span class="mono">${esc(k)}</span>
            <span class="chip ${ok ? "ok" : "warn"}">${ok ? esc(toolVer(v).slice(0, 18)) : t("srv_missing", "Missing")}</span>
          </div>`;
        }).join("");
        const checkRows = (res.checks || []).map((c) => {
          const ok = c.status === "ok" || c.status === "pass";
          return `
          <div class="notice ${!ok ? "danger" : ""}" style="margin:6px 0;padding:8px 10px;">
            ${icon(ok ? "check" : "alert")}
            <span><b>${esc(c.label || c.id)}:</b> ${esc(c.detail || "")}</span>
          </div>`;
        }).join("");

        body.innerHTML = `
          <div class="grid-3" style="margin-bottom:12px;">
            <div class="card" style="padding:10px;"><div class="muted">RAM</div><strong>${esc(sys.ram_mb || "?")} MB</strong> <span class="muted">(Swap: ${esc(sys.swap_mb || 0)} MB)</span></div>
            <div class="card" style="padding:10px;"><div class="muted">Disk Free</div><strong>${esc(sys.disk_free || "?")}</strong></div>
            <div class="card" style="padding:10px;"><div class="muted">${t("srv_suggested_port", "Suggested Free Port")}</div><strong class="mono">${esc(res.suggested_port || 3000)}</strong></div>
          </div>
          ${checkRows}
          ${(res.recommendations || []).length ? `<div class="card" style="margin-top:10px;padding:10px;"><strong>${t("srv_recommendations", "Recommendations")}</strong><ul style="margin:6px 0 0 18px;padding:0;">${res.recommendations.map((r) => `<li>${esc(r)}</li>`).join("")}</ul></div>` : ""}
          <h4 style="margin:14px 0 6px 0;">${t("srv_installed_tools", "Detected Server Runtimes & Tools")}</h4>
          <div class="pf-tools-grid">${toolChips}</div>
          ${missingList.length ? `
            <div class="card" style="margin-top:12px;padding:12px;">
              <strong>${t("srv_install_missing_tools", "Install Missing Tools on VPS")}</strong>
              <div style="display:flex;gap:12px;flex-wrap:wrap;margin:8px 0;">
                ${missingList.map((tl) => `<label class="checkbox"><input type="checkbox" name="pf_tool" value="${esc(tl)}"><span class="mono">${esc(tl)}</span></label>`).join("")}
              </div>
              <button type="button" class="btn primary sm" id="pf-install-btn">${icon("download")} ${t("srv_install_selected_btn", "Install Selected Tools")}</button>
            </div>` : ""}`;

        $("#pf-install-btn", body)?.addEventListener("click", async () => {
          const picked = Array.from(body.querySelectorAll('input[name="pf_tool"]:checked')).map((x) => x.value);
          if (!picked.length) return toast("error", "Select at least one tool");
          closeModal();
          await runRemote("forge-install-tools", { tools: picked });
        });
      } catch (err) {
        body.innerHTML = `<div class="card error-card"><p>${esc(err.message)}</p></div>`;
      }
    });
  }

  /* ── side-by-side .env sync modal ─────────────────────── */
  async function openEnvSyncModal(site) {
    const localSites = state.sites || [];
    const localOpts = `<option value="">— ${t("srv_paste_env", "Select local site or paste .env below")} —</option>`
      + localSites.map((s) => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join("");

    openModal(`
      <div class="modal">
        <div class="modal-header">
          <h2>${icon("env")} ${t("srv_env_sync_title", "Sync .env Side-by-Side")}</h2>
          <p>${esc(site.name)} · <span class="mono">${esc(site.path)}</span></p>
        </div>
        <div class="modal-body">
          <div class="grid-2" style="gap:8px;align-items:end;">
            <label class="field" style="margin:0;"><span>${t("srv_local_site_label", "Local Project Source")}</span>
              <select id="es-local-site" class="input sm">${localOpts}</select>
            </label>
            <button type="button" class="btn sm primary" id="es-compare-btn">${icon("refresh")} ${t("srv_compare_env_btn", "Compare .env")}</button>
          </div>
          <details style="margin-top:8px;">
            <summary class="muted" style="cursor:pointer;font-size:12px;">${t("srv_paste_local_env", "Or paste local .env content manually")}</summary>
            <textarea id="es-raw-text" class="input mono sm" rows="4" style="margin-top:6px;" placeholder="APP_URL=https://example.com&#10;STRIPE_KEY=sk_live_..."></textarea>
          </details>
          <div id="es-diff-box" style="margin-top:12px;">
            <p class="muted">${t("srv_env_diff_hint", "Choose a local project or paste .env, then click Compare to preview missing/changed variables before syncing. A backup is saved automatically on the server.")}</p>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>${t("cancel", "Cancel")}</button>
          <button type="button" class="btn primary" id="es-push-btn" disabled>${icon("upload")} ${t("srv_push_env_btn", "Push Selected Keys")}</button>
        </div>
      </div>`, (root) => {
      $("[data-dismiss]", root).addEventListener("click", closeModal);
      const diffBox = $("#es-diff-box", root);
      const pushBtn = $("#es-push-btn", root);

      async function runDiff() {
        const local_site = $("#es-local-site", root).value;
        const local_env_text = $("#es-raw-text", root).value;
        diffBox.innerHTML = `<div class="connecting"><span class="status-icon running"></span>${t("srv_comparing_env", "Comparing local & remote .env…")}</div>`;
        try {
          const res = await LD.call("deploy_env_diff", { server: S.current, path: site.path, local_site, local_env_text });
          if (!res.ok) throw new Error(res.error || "Compare failed");
          const missing = res.missing_on_server || [];
          const diff = res.different_on_server || [];
          if (!missing.length && !diff.length) {
            diffBox.innerHTML = `<div class="notice">${icon("check")}<span>${t("srv_env_in_sync", "All local keys already match")} (${res.same_count || 0} keys).</span></div>`;
            pushBtn.disabled = true;
            return;
          }
          diffBox.innerHTML = `
            <div class="muted" style="margin-bottom:8px;">Remote file: <span class="mono">${esc(res.remote_env_path || ".env")}</span> · Same: ${res.same_count || 0}</div>
            <table class="files" style="width:100%;">
              <thead><tr><th></th><th>Key</th><th>Status</th><th>Value to Push</th></tr></thead>
              <tbody>
                ${missing.map((m) => `
                  <tr>
                    <td><input type="checkbox" class="es-pick" data-key="${esc(m.key)}" checked></td>
                    <td class="mono">${esc(m.key)}</td>
                    <td><span class="chip ok">Missing</span></td>
                    <td><input class="input sm mono es-val" data-key="${esc(m.key)}" value="${esc(m.value)}"></td>
                  </tr>`).join("")}
                ${diff.map((d) => `
                  <tr>
                    <td><input type="checkbox" class="es-pick" data-key="${esc(d.key)}"></td>
                    <td class="mono">${esc(d.key)}</td>
                    <td><span class="chip warn">Different</span><div class="muted" style="font-size:11px;">VPS: ${esc(String(d.remote_value || "").slice(0, 24))}</div></td>
                    <td><input class="input sm mono es-val" data-key="${esc(d.key)}" value="${esc(d.local_value)}"></td>
                  </tr>`).join("")}
              </tbody>
            </table>`;
          pushBtn.disabled = false;
        } catch (err) {
          diffBox.innerHTML = `<div class="card error-card"><p>${esc(err.message)}</p></div>`;
          pushBtn.disabled = true;
        }
      }

      $("#es-compare-btn", root).addEventListener("click", runDiff);
      $("#es-local-site", root).addEventListener("change", () => { if ($("#es-local-site", root).value) runDiff(); });
      pushBtn.addEventListener("click", async () => {
        const updates = {};
        diffBox.querySelectorAll(".es-pick:checked").forEach((cb) => {
          const k = cb.dataset.key;
          const valInp = Array.from(diffBox.querySelectorAll(".es-val")).find((x) => x.dataset.key === k);
          if (k && valInp) updates[k] = valInp.value;
        });
        if (!Object.keys(updates).length) return toast("error", "No keys selected");
        try {
          pushBtn.disabled = true;
          const r = await LD.call("deploy_env_sync", { server: S.current, path: site.path, updates });
          toast("success", "Synced .env to server", `Updated ${r.updated_count} key(s) with backup.`);
          closeModal();
          if (S.siteTab === "env") renderSite();
        } catch (err) {
          pushBtn.disabled = false;
          toast("error", "Sync failed", err.message);
        }
      });
    });
  }

  /* ── universal deploy any app wizard modal ─────────────── */
  async function forgeSiteModal() {
    let ghRepos = [];
    let cfZones = [];
    try {
      const g = await LD.call("gh_repos", {});
      if (g && g.repos) ghRepos = g.repos;
    } catch {}
    try {
      const c = await LD.call("cf_zones", {});
      if (c && c.zones) cfZones = c.zones;
    } catch {}

    const localSites = state.sites || [];
    const localOptions = `<option value="">— ${t("srv_select_local_opt", "Pick local project")} —</option>`
      + localSites.map((s) => `<option value="${esc(s.name)}">${esc(s.name)} (${esc(s.type || "app")})</option>`).join("");
    const repoOptions = `<option value="">— Manual URL —</option>` + ghRepos.map((r) => `<option value="${esc(r.ssh_url || r.clone_url || r.html_url)}">${esc(r.full_name)}</option>`).join("");
    const zoneOptions = `<option value="">— None (Manage DNS elsewhere) —</option>` + cfZones.map((z) => `<option value="${esc(z.id)}">${esc(z.name)}</option>`).join("");

    openModal(`
      <form class="modal" id="forge-site-form" novalidate>
        <div class="modal-header">
          <h2>${icon("rocket")} ${t("srv_deploy_any_app", "Deploy Any App to VPS")}</h2>
          <p>${t("srv_universal_wizard_desc", "Deploy Laravel, Node SSR (Next/Nuxt/Nest), Static SPAs (Vite/React), Python (Django/FastAPI), or Docker apps with zero-downtime releases.")}</p>
        </div>
        <div class="modal-body">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px;padding:8px 10px;border:1px solid var(--border);border-radius:8px;">
            <span id="uds-pf-summary" class="muted" style="font-size:12px;">${t("srv_pf_hint", "Optional: run pre-flight to verify server tools, RAM & free port.")}</span>
            <button type="button" class="btn sm ghost" id="uds-pf-btn">${icon("shield")} ${t("srv_preflight_btn", "Pre-Flight Check")}</button>
          </div>

          <div class="grid-2">
            <label class="field"><span>${t("srv_stack_label", "Application Stack")}</span>
              <select name="stack" id="uds-stack" class="input sm">
                <option value="laravel" selected>Laravel / PHP</option>
                <option value="node_ssr">Node SSR (Next / Nuxt / Nest / Express)</option>
                <option value="static">Static SPA (Vite / React / Vue / HTML)</option>
                <option value="python">Python (Django / FastAPI)</option>
                <option value="docker">Docker / Docker Compose</option>
              </select>
            </label>
            <label class="field"><span>${t("srv_source_mode_label", "Deployment Source")}</span>
              <select name="source_mode" id="uds-source-mode" class="input sm">
                <option value="git" selected>${t("srv_src_git", "Git Repository (Pull on Server)")}</option>
                <option value="local_source">${t("srv_src_local_upload", "Upload Local Project (Build on VPS)")}</option>
                <option value="local_artifact">${t("srv_src_local_artifact", "Build Locally -> Upload Artifact")}</option>
              </select>
            </label>
          </div>

          <div id="uds-git-section">
            <label class="field"><span>${t("srv_repo_label", "Git Repository URL")}</span>
              <div style="display:flex;gap:8px;">
                <select id="fs-repo-picker" class="input sm" style="width:190px;">${repoOptions}</select>
                <input name="repo_url" placeholder="git@github.com:owner/repo.git" style="flex:1;" spellcheck="false">
              </div>
            </label>
            <div class="grid-2" style="align-items:center;">
              <label class="field"><span>${t("srv_branch_label", "Branch")}</span><input name="branch" value="main" spellcheck="false"></label>
              <label class="checkbox" style="margin-top:14px;"><input type="checkbox" name="setup_deploy_key" checked><span>${t("srv_setup_deploy_key", "Auto-register SSH Deploy Key on GitHub")}</span></label>
            </div>
          </div>

          <div id="uds-local-section" style="display:none;">
            <div class="grid-2">
              <label class="field"><span>${t("srv_local_site_label", "Local Workspace Site")}</span>
                <select name="local_site" id="uds-local-site" class="input sm">${localOptions}</select>
              </label>
              <label class="field"><span>${t("srv_local_path_label", "Or Custom Local Folder")}</span>
                <div style="display:flex;gap:6px;">
                  <input name="local_path" id="uds-local-path" class="input sm" placeholder="/home/user/projects/myapp" spellcheck="false">
                  <button type="button" class="btn sm" id="uds-inspect-btn">${t("srv_inspect_btn", "Inspect")}</button>
                </div>
              </label>
            </div>
            <div id="uds-local-artifact-wrap" style="display:none;">
              <label class="field"><span>${t("srv_local_build_cmd", "Local Build Command")}</span>
                <input name="local_build_cmd" id="uds-local-build" class="input sm mono" placeholder="npm run build" value="npm run build" spellcheck="false">
              </label>
            </div>
          </div>

          <div class="grid-2">
            <label class="field"><span>${t("srv_domain_label", "Domain Name")}</span><input name="domain" id="uds-domain" placeholder="app.example.com" required spellcheck="false"></label>
            <label class="field"><span>${t("srv_remote_path_label", "Server Deploy Path")}</span><input name="path" id="uds-path" placeholder="/var/www/app.example.com" spellcheck="false"></label>
          </div>

          <div class="grid-3">
            <label class="field"><span>${t("srv_layout_label", "Deploy Layout")}</span>
              <select name="deploy_layout" class="input sm">
                <option value="inplace" selected>${t("srv_layout_inplace", "Direct Folder (/var/www/project)")}</option>
                <option value="atomic">${t("srv_layout_atomic", "Atomic Releases (releases/current)")}</option>
              </select>
            </label>
            <label class="field" id="uds-php-wrap"><span>${t("srv_php_label", "PHP Version")}</span>
              <select name="php" class="input sm">
                <option value="8.3" selected>PHP 8.3</option>
                <option value="8.4">PHP 8.4</option>
                <option value="8.2">PHP 8.2</option>
              </select>
            </label>
            <label class="field" id="uds-port-wrap" style="display:none;"><span>${t("srv_port_label", "App Internal Port")}</span>
              <input name="port" id="uds-port" class="input sm mono" type="number" value="3000" min="80" max="65535">
            </label>
            <label class="field" id="uds-public-wrap" style="display:none;"><span>${t("srv_public_dir_label", "Static Output Dir")}</span>
              <input name="public_dir" id="uds-public-dir" class="input sm mono" value="dist" placeholder="dist or build">
            </label>
            <label class="field"><span>${t("srv_health_path_label", "Health Check Path")}</span>
              <input name="health_path" id="uds-health" class="input sm mono" value="/up" placeholder="/up or /">
            </label>
          </div>

          <div id="uds-db-wrap" style="border:1px solid var(--border);border-radius:8px;padding:10px 12px;margin-top:6px;">
            <div class="grid-2" style="gap:10px;">
              <label class="field" style="margin:0;"><span>${t("srv_db_engine_label", "Database Engine")}</span>
                <select name="db_engine" id="uds-db-engine" class="input sm">
                  <option value="mysql" selected>MySQL / MariaDB</option>
                  <option value="pgsql">PostgreSQL</option>
                  <option value="none">None (Skip Database)</option>
                </select>
              </label>
              <label class="field" id="uds-db-mode-wrap" style="margin:0;"><span>${t("srv_db_mode_label", "Database Setup Mode")}</span>
                <select name="db_mode" id="uds-db-mode" class="input sm">
                  <option value="create" selected>${t("srv_db_mode_create", "Create / Sync Database & User on Server")}</option>
                  <option value="existing">${t("srv_db_mode_existing", "Use Existing Credentials (.env only)")}</option>
                </select>
              </label>
            </div>
            <div id="uds-db-details" style="margin-top:10px;">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                <label class="field" style="margin:0;">
                  <span style="display:flex;justify-content:space-between;align-items:center;">
                    <span>${t("srv_db_name_label", "Database Name")}</span>
                    <select id="uds-existing-dbs" class="input sm" style="width:auto;height:22px;padding:0 6px;font-size:11px;">
                      <option value="">${t("srv_db_pick_existing", "— Pick existing on server —")}</option>
                    </select>
                  </span>
                  <input name="db_name" id="uds-db-name" class="input sm mono" placeholder="Leave blank to auto-name" spellcheck="false">
                </label>
                <label class="field" style="margin:0;"><span>${t("srv_db_user_label", "Database Username")}</span>
                  <input name="db_user" id="uds-db-user" class="input sm mono" placeholder="Leave blank to match DB name" spellcheck="false">
                </label>
              </div>
              <div style="display:grid;grid-template-columns:1.4fr 0.8fr 0.6fr;gap:10px;margin-top:8px;">
                <label class="field" style="margin:0;">
                  <span style="display:flex;justify-content:space-between;align-items:center;">
                    <span>${t("srv_db_pass_label", "Database Password")}</span>
                    <button type="button" class="btn xs" id="uds-gen-pass" style="padding:1px 6px;font-size:10px;">${icon("key")} ${t("srv_db_gen_pass", "Generate")}</button>
                  </span>
                  <input name="db_pass" id="uds-db-pass" class="input sm mono" placeholder="Auto-generate or keep existing" spellcheck="false">
                </label>
                <label class="field" style="margin:0;"><span>${t("srv_db_host_label", "DB Host")}</span>
                  <input name="db_host" id="uds-db-host" class="input sm mono" value="127.0.0.1" placeholder="127.0.0.1">
                </label>
                <label class="field" style="margin:0;"><span>${t("srv_db_port_label", "DB Port")}</span>
                  <input name="db_port" id="uds-db-port" class="input sm mono" value="3306" placeholder="3306">
                </label>
              </div>
            </div>
          </div>

          <div class="grid-2" style="align-items:center;">
            <label class="field"><span>${t("srv_cf_zone_label", "Cloudflare DNS Zone")}</span><select name="cf_zone" class="input sm">${zoneOptions}</select></label>
            <div style="display:flex;flex-direction:column;gap:4px;margin-top:10px;">
              <label class="checkbox"><input type="checkbox" name="create_site" checked><span>${t("srv_create_nginx_site", "Configure Nginx vhost & directories")}</span></label>
              <label class="checkbox"><input type="checkbox" name="auto_rollback" checked><span>${t("srv_auto_rollback_label", "Auto-rollback on failed health check")}</span></label>
              <label class="checkbox"><input type="checkbox" name="cf_proxied" checked><span>${t("srv_cf_proxied", "Cloudflare Proxy (CDN + DDoS)")}</span></label>
            </div>
          </div>

          <details style="margin-top:8px;">
            <summary class="muted" style="cursor:pointer;font-size:13px;">${t("srv_recipe_summary", "Customize Pipeline Recipe (Install / Build / Migrate / Start)")}</summary>
            <div class="grid-2" style="gap:8px;margin-top:8px;">
              <label class="field" style="margin:0;"><span>Install Command</span><input name="install_cmd" id="uds-install-cmd" class="input sm mono" placeholder="Auto"></label>
              <label class="field" style="margin:0;"><span>Build Command</span><input name="build_cmd" id="uds-build-cmd" class="input sm mono" placeholder="Auto"></label>
              <label class="field" style="margin:0;"><span>Migrate Command</span><input name="migrate_cmd" id="uds-migrate-cmd" class="input sm mono" placeholder="Optional"></label>
              <label class="field" style="margin:0;"><span>Start Command</span><input name="start_cmd" id="uds-start-cmd" class="input sm mono" placeholder="Optional"></label>
            </div>
          </details>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>${t("cancel", "Cancel")}</button>
          <button type="submit" class="btn primary">${icon("rocket")} ${t("srv_deploy_btn", "Deploy Now")}</button>
        </div>
      </form>`, (root) => {
      const form = $("#forge-site-form", root);
      const stackSel = $("#uds-stack", form);
      const srcSel = $("#uds-source-mode", form);
      const domainInp = $("#uds-domain", form);
      const pathInp = $("#uds-path", form);
      let pathEdited = false;

      const dbEngineSel = $("#uds-db-engine", form);
      const dbDetailsEl = $("#uds-db-details", form);
      const dbModeWrapEl = $("#uds-db-mode-wrap", form);
      let serverDbInfo = null;

      function syncDbVisibility() {
        const eng = dbEngineSel.value;
        const active = eng !== "none";
        dbDetailsEl.style.display = active ? "block" : "none";
        dbModeWrapEl.style.display = active ? "block" : "none";
        if (active) {
          $("#uds-db-port", form).value = eng === "pgsql" ? "5432" : "3306";
          const picker = $("#uds-existing-dbs", form);
          if (picker && serverDbInfo) {
            const list = eng === "pgsql" ? (serverDbInfo.pgsql_databases || []) : (serverDbInfo.mysql_databases || []);
            picker.innerHTML = `<option value="">${t("srv_db_pick_existing", "— Pick existing on server —")} (${list.length})</option>` +
              list.map((d) => `<option value="${esc(d)}">${esc(d)}</option>`).join("");
          }
        }
      }

      function syncVisibility() {
        const st = stackSel.value;
        const sm = srcSel.value;
        $("#uds-git-section", form).style.display = sm === "git" ? "block" : "none";
        $("#uds-local-section", form).style.display = sm === "git" ? "none" : "block";
        $("#uds-local-artifact-wrap", form).style.display = sm === "local_artifact" ? "block" : "none";
        $("#uds-php-wrap", form).style.display = st === "laravel" ? "block" : "none";
        $("#uds-port-wrap", form).style.display = (st === "node_ssr" || st === "python" || st === "docker") ? "block" : "none";
        $("#uds-public-wrap", form).style.display = st === "static" ? "block" : "none";
        if (st === "static" && !dbEngineSel.dataset.edited) {
          dbEngineSel.value = "none";
        } else if ((st === "laravel" || st === "python") && dbEngineSel.value === "none" && !dbEngineSel.dataset.edited) {
          dbEngineSel.value = "mysql";
        }
        syncDbVisibility();
        if (st === "python" && $("#uds-port", form).value === "3000") $("#uds-port", form).value = "8000";
        if (st === "node_ssr" && $("#uds-port", form).value === "8000") $("#uds-port", form).value = "3000";
        if (!$("#uds-health", form).dataset.edited) {
          $("#uds-health", form).value = st === "laravel" ? "/up" : "/";
        }
      }

      async function inspectLocalSelection() {
        const local_site = $("#uds-local-site", form).value;
        const local_path = $("#uds-local-path", form).value.trim();
        if (!local_site && !local_path) return;
        try {
          const det = await LD.call("deploy_inspect_local", { local_site, local_path });
          if (!det || !det.ok) return toast("error", "Inspection failed", det?.error || "Folder not found");
          $("#uds-local-path", form).value = det.path || local_path;
          if (det.stack) stackSel.value = det.stack;
          if (det.port) $("#uds-port", form).value = det.port;
          if (det.public_dir) $("#uds-public-dir", form).value = det.public_dir;
          if (det.health_path && !$("#uds-health", form).dataset.edited) $("#uds-health", form).value = det.health_path;
          if (det.install_cmd) $("#uds-install-cmd", form).value = det.install_cmd;
          if (det.build_cmd) $("#uds-build-cmd", form).value = det.build_cmd;
          if (det.local_build_cmd) $("#uds-local-build", form).value = det.local_build_cmd;
          if (det.start_cmd) $("#uds-start-cmd", form).value = det.start_cmd;
          if (!domainInp.value && det.name) {
            domainInp.value = `${det.name.toLowerCase().replace(/[^a-z0-9-]/g, "-")}.local`;
            if (!pathEdited) pathInp.value = `/var/www/${domainInp.value}`;
          }
          syncVisibility();
          toast("success", `Detected ${det.framework || det.stack}`, `Suggested port ${det.port}`);
        } catch (err) {
          toast("error", "Inspection failed", err.message);
        }
      }

      syncVisibility();
      (async () => {
        try {
          serverDbInfo = await LD.call("server_db_info", { server: S.current, path: "" });
          if (form.isConnected) syncDbVisibility();
        } catch {}
      })();
      $("[data-dismiss]", form).addEventListener("click", closeModal);
      stackSel.addEventListener("change", syncVisibility);
      srcSel.addEventListener("change", syncVisibility);
      dbEngineSel.addEventListener("change", () => {
        dbEngineSel.dataset.edited = "1";
        syncDbVisibility();
      });
      $("#uds-existing-dbs", form).addEventListener("change", (ev) => {
        const val = ev.target.value;
        if (val) {
          $("#uds-db-name", form).value = val;
          if (!$("#uds-db-user", form).value) $("#uds-db-user", form).value = val.slice(0, 28);
        }
      });
      $("#uds-gen-pass", form).addEventListener("click", () => {
        const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
        let out = "";
        for (let i = 0; i < 20; i++) out += chars[Math.floor(Math.random() * chars.length)];
        $("#uds-db-pass", form).value = out;
      });
      $("#uds-health", form).addEventListener("input", () => { $("#uds-health", form).dataset.edited = "1"; });
      pathInp.addEventListener("input", () => { pathEdited = true; });
      domainInp.addEventListener("input", () => {
        if (!pathEdited) pathInp.value = domainInp.value.trim() ? `/var/www/${domainInp.value.trim()}` : "";
      });
      $("#fs-repo-picker", form).addEventListener("change", (e) => {
        if (e.target.value) form.elements.repo_url.value = e.target.value;
      });
      $("#uds-local-site", form).addEventListener("change", inspectLocalSelection);
      $("#uds-inspect-btn", form).addEventListener("click", inspectLocalSelection);
      $("#uds-pf-btn", form).addEventListener("click", async () => {
        const sum = $("#uds-pf-summary", form);
        sum.textContent = "Checking VPS readiness…";
        try {
          const pf = await LD.call("remote_preflight", {
            server: S.current,
            stack: stackSel.value,
            path: pathInp.value.trim() || "/var/www",
          });
          S.preflight = pf;
          const sys = pf.sys || {};
          if (pf.suggested_port) $("#uds-port", form).value = pf.suggested_port;
          const warnCnt = (pf.checks || []).filter((c) => c.status !== "ok" && c.status !== "pass").length;
          sum.innerHTML = `RAM: <b>${esc(sys.ram_mb || "?")} MB</b> · Free port: <b class="mono">${esc(pf.suggested_port || 3000)}</b> · ${warnCnt ? `<span class="chip warn">${warnCnt} notice(s)</span>` : `<span class="chip ok">Ready</span>`}`;
        } catch (err) {
          sum.textContent = `Check failed: ${err.message}`;
        }
      });

      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const f = form.elements;
        const domain = f.domain.value.trim();
        const stack = f.stack.value;
        const source_mode = f.source_mode.value;
        const remotePath = f.path.value.trim() || (domain ? `/var/www/${domain}` : "");
        if (!domain && !remotePath) return toast("error", "Domain or Path required", "Enter a domain name or remote deployment path.");
        if (source_mode === "git" && !f.repo_url.value.trim()) return toast("error", "Repository required", "Enter a Git repository URL.");
        if (source_mode !== "git" && !f.local_site.value && !f.local_path.value.trim()) {
          return toast("error", "Local source required", "Pick a local workspace site or enter a folder path.");
        }

        const payload = {
          domain,
          path: remotePath,
          stack,
          source_mode,
          deploy_layout: f.deploy_layout.value,
          repo_url: f.repo_url.value.trim(),
          branch: f.branch.value.trim() || "main",
          local_site: f.local_site.value,
          local_path: f.local_path.value.trim(),
          local_build_cmd: f.local_build_cmd.value.trim(),
          port: +f.port.value || (stack === "python" ? 8000 : 3000),
          public_dir: f.public_dir.value.trim() || "dist",
          php: f.php.value,
          create_site: f.create_site.checked,
          db_engine: f.db_engine.value,
          db_mode: f.db_mode ? f.db_mode.value : "create",
          db_name: f.db_name.value.trim(),
          db_user: f.db_user ? f.db_user.value.trim() : "",
          db_pass: f.db_pass ? f.db_pass.value : "",
          db_host: f.db_host ? f.db_host.value.trim() || "127.0.0.1" : "127.0.0.1",
          db_port: f.db_port ? f.db_port.value.trim() : "",
          cf_zone: f.cf_zone.value,
          cf_proxied: f.cf_proxied.checked,
          setup_deploy_key: f.setup_deploy_key.checked,
          health_path: f.health_path.value.trim() || "/",
          auto_rollback: f.auto_rollback.checked,
          recipe: {
            install_cmd: f.install_cmd.value.trim(),
            build_cmd: f.build_cmd.value.trim(),
            migrate_cmd: f.migrate_cmd.value.trim(),
            start_cmd: f.start_cmd.value.trim(),
            public_dir: f.public_dir.value.trim() || (stack === "laravel" ? "public" : "dist"),
            health_path: f.health_path.value.trim() || "/",
            auto_rollback: f.auto_rollback.checked,
          },
        };
        closeModal();
        await startUniversalDeploy(payload);
        loadSites();
      });
    });
  }

  /* ── events ───────────────────────────────────────────── */
  document.addEventListener("click", async (e) => {
    const t = e.target;
    const d = (sel) => t.closest(sel);
    let el;

    if (d("[data-srv-add]")) return serverModal();
    if (d("[data-forge-provision]")) {
      if (!(await confirmModal({
        title: window.t("srv_provision_cta", "Provision this server (Forge Mode)"),
        confirm: window.t("srv_provision_btn", "Provision Server"),
        message: window.t("srv_provision_confirm", "Are you sure you want to provision this server? This will install system packages, web servers, databases, and configure UFW firewall rules.")
      }))) return;
      return runRemote("forge-provision", {});
    }
    if (d("[data-forge-new-site]")) return forgeSiteModal();
    if (d("[data-universal-preflight]")) {
      return openPreFlightModal(S.site ? mapSiteTypeToStack(S.site.type) : "", S.site ? S.site.path : "/var/www");
    }
    if (d("[data-universal-env-sync]")) {
      if (S.site) return openEnvSyncModal(S.site);
      return;
    }
    if (d("[data-universal-save-recipe]")) {
      if (!S.site) return;
      const p = collectDrawerDeployPayload();
      try {
        await LD.call("deploy_recipe_save", { server: S.current, ...p });
        toast("success", "Deploy recipe saved");
      } catch (err) {
        toast("error", "Couldn't save recipe", err.message);
      }
      return;
    }
    if (d("[data-universal-site-deploy]")) {
      if (!S.site) return;
      const p = collectDrawerDeployPayload();
      if (p.source_mode === "git" && !p.repo_url) return toast("error", "Repository required", "Enter a Git repository URL or switch to Local upload.");
      if (p.source_mode !== "git" && !p.local_site && !p.local_path) return toast("error", "Local folder required", "Select a local workspace site or enter its folder path.");
      return startUniversalDeploy({ ...p, create_site: false });
    }
    if (d("[data-forge-do-deploy]")) {
      const repo = $("#fd-repo")?.value?.trim() || "";
      const branch = $("#fd-branch")?.value?.trim() || "main";
      if (!repo) return toast("error", "Repository required", "Enter a Git repository URL to deploy.");
      return runRemote("forge-deploy", { path: S.site.path, repo_url: repo, branch, php: S.site.php || "8.3" });
    }
    if ((el = d("[data-forge-do-rollback]"))) {
      const rel = el.dataset.forgeDoRollback;
      if (!(await confirmModal({
        title: window.t("srv_rollback_title", "Rollback Release"),
        confirm: window.t("srv_rollback_btn", "Rollback"),
        message: `Rollback ${esc(S.site.name)} to release <b>${esc(rel)}</b>?`
      }))) return;
      return runRemote("forge-universal-rollback", { path: S.site.path, release: rel, php: S.site.php || "8.3" });
    }
    if (d("[data-forge-save-worker]")) {
      const queue = $("#fw-queue")?.value?.trim() || "default";
      const numprocs = +$("#fw-procs")?.value || 1;
      return runRemote("forge-worker", { path: S.site.path, queue, numprocs, php: S.site.php || "8.3" });
    }
    if ((el = d("[data-forge-cron]"))) {
      return runRemote("forge-cron", { path: S.site.path, php: S.site.php || "8.3", op: el.dataset.forgeCron });
    }
    if (d("[data-forge-issue-ssl]")) {
      const email = $("#fssl-email")?.value?.trim() || "";
      const domain = S.site.domains[0] || S.site.name;
      return runRemote("forge-ssl", { domain, email });
    }
    if (d("[data-forge-pull-db]")) {
      const localSite = $("#fdb-local-site")?.value || "";
      const exclude = $("#fdb-exclude")?.value?.trim() || "sessions,jobs,telescope_entries";
      if (!localSite) return toast("error", "Local site required", "Select a local target site to receive the database.");
      if (!(await confirmModal({
        title: window.t("srv_db_pull_title", "Pull Production Database to Local"),
        confirm: window.t("srv_db_pull_btn", "Pull Database Now"),
        danger: true,
        message: `This will dump the remote database from <b>${esc(S.site.name)}</b> and import it into your local project <b>${esc(localSite)}</b>.<br><br><b>A local backup snapshot will be created automatically before importing.</b>`
      }))) return;
      try {
        toast("success", "Pulling remote database… (creating snapshot first)");
        const res = await LD.call("forge_db_pull", { server: S.current, path: S.site.path, local_site: localSite, exclude });
        if (res.ok) {
          toast("success", "Database imported", res.message);
        } else {
          toast("error", "Database pull failed", res.error);
        }
      } catch (err) {
        toast("error", "Database pull failed", err.message);
      }
      return;
    }
    if ((el = d("[data-srv-import]"))) return serverModal({ name: el.dataset.srvImport, host: el.dataset.srvImport });
    if (d("[data-srv-reload]")) { await loadList(); return render(); }
    if ((el = d("[data-srv-terminal]"))) { e.stopPropagation(); return api("server_terminal", { id: el.dataset.srvTerminal }); }
    if ((el = d("[data-srv-files]"))) { e.stopPropagation(); return open(el.dataset.srvFiles, "files"); }
    if ((el = d("[data-srv-open]"))) return open(el.dataset.srvOpen);
    if (d("[data-srv-back]")) { S.current = null; await loadList(); return render(); }
    if (d("[data-srv-edit]")) return serverModal(server());
    if (d("[data-srv-retry]")) { S.infoError = ""; S.info = null; render(); return loadInfo(); }
    if (d("[data-srv-disconnect]")) {
      await api("server_disconnect", { id: S.current });
      toast("success", "Disconnected");
      S.current = null;
      await loadList();
      return render();
    }
    if ((el = d("[data-srv-tab]"))) {
      S.tab = el.dataset.srvTab;
      render();
      if (S.tab === "sites" && !S.sites && S.info) loadSites();
      if (S.tab === "files" && !S.files.path && S.info) loadFiles(S.info.home || "~");
      return;
    }
    if ((el = d("[data-srv-service]"))) return runRemote("remote-service", { unit: el.dataset.unit, op: el.dataset.srvService }, false);
    if ((el = d("[data-srv-url]"))) { e.stopPropagation(); return api("open", { target: "url", url: el.dataset.srvUrl }); }
    if ((el = d("[data-srv-deploy]"))) {
      e.stopPropagation();
      const idx = +el.dataset.srvDeploy;
      const site = S.sites[idx];
      try {
        const rec = await LD.call("deploy_recipe_get", { server: S.current, path: site.path, site_name: site.name });
        const entry = rec?.entry || {};
        if (entry.repo_url || entry.local_path) {
          const layoutMode = entry.deploy_layout === "atomic" ? "inplace" : (entry.deploy_layout || "inplace");
          if (!(await confirmModal({ title: `Deploy ${site.name}?`, confirm: window.t("srv_deploy_btn", "Deploy Now"), message: `Runs ${esc(entry.stack || mapSiteTypeToStack(site.type))} deployment in <b>${esc(site.path)}</b> on ${esc(server().name)}.` }))) return;
          return startUniversalDeploy({ ...entry, deploy_layout: layoutMode, server: S.current, path: site.path, domain: (site.domains && site.domains[0]) || entry.domain || site.name, site_name: site.name, create_site: false });
        }
      } catch {}
      if (site.is_atomic) {
        openSite(idx);
        S.siteTab = "deployments";
        return renderSite();
      }
      if (!(await confirmModal({ title: `Deploy ${site.name}?`, confirm: "Deploy", message: `Runs ${DEPLOY_STEPS[site.type] || DEPLOY_STEPS.node} in <b>${esc(site.path)}</b> on ${esc(server().name)}.` }))) return;
      return runRemote("remote-deploy", sitePayload(site));
    }
    if ((el = d("[data-rsite]"))) return openSite(+el.dataset.rsite);

    // files
    if ((el = d("[data-srv-cd]"))) return loadFiles(el.dataset.srvCd);
    if (d("[data-srv-hidden]")) { S.files.hidden = !S.files.hidden; return loadFiles(S.files.path); }
    if (d("[data-srv-upload]")) return api("server_upload", { id: S.current, dir: S.files.path });
    if ((el = d("[data-srv-new]"))) {
      const kind = el.dataset.srvNew;
      const name = await promptModal(kind === "folder" ? "New folder" : "New file", "Name", "");
      if (!name) return;
      await api("server_file_op", { id: S.current, op: kind === "folder" ? "mkdir" : "touch", path: joinPath(S.files.path, name) });
      return loadFiles(S.files.path);
    }
    if ((el = d("[data-rf]"))) {
      e.stopPropagation();
      const entry = S.files.entries[+el.closest("[data-rfile]").dataset.rfile];
      const path = joinPath(S.files.path, entry.name);
      const op = el.dataset.rf;
      if (op === "edit") return editFile(path);
      if (op === "download") return api("server_download", { id: S.current, path, dir: entry.dir });
      if (op === "rename") {
        const target = await promptModal("Rename or move", "New path", path);
        if (!target || target === path) return;
        await api("server_file_op", { id: S.current, op: "rename", path, target: target.startsWith("/") ? target : joinPath(S.files.path, target) });
        return loadFiles(S.files.path);
      }
      if (op === "delete") {
        if (!(await confirmModal({ title: `Delete ${entry.name}?`, danger: true, confirm: "Delete", message: `<span class="mono">${esc(path)}</span>${entry.dir ? " and everything inside it" : ""} will be permanently removed from the server.` }))) return;
        await api("server_file_op", { id: S.current, op: "delete", path });
        return loadFiles(S.files.path);
      }
    }
    if ((el = d("[data-rfile]"))) {
      const entry = S.files.entries[+el.dataset.rfile];
      const path = joinPath(S.files.path, entry.name);
      return entry.dir || entry.link ? loadFiles(path) : editFile(path);
    }

    // remote site drawer
    if ((el = d("[data-rsite-tab]"))) {
      if (S.siteTab === "env" && el.dataset.rsiteTab !== "env" && EnvEditor.dirty()
          && !(await confirmModal({ title: "Discard changes?", message: "You have unsaved environment variables.", confirm: "Discard", danger: true }))) return;
      S.siteTab = el.dataset.rsiteTab;
      return renderSite();
    }
    if ((el = d("[data-ra]"))) return runRemote("remote-artisan", { path: S.site.path, php: S.site.php, args: el.dataset.ra });
    if ((el = d("[data-rm]"))) return runRemote("remote-manage", { ...sitePayload(S.site), args: el.dataset.rm });
    if ((el = d("[data-rsa]"))) {
      const site = S.site;
      switch (el.dataset.rsa) {
        case "browser": return api("open", { target: "url", url: site.url });
        case "files": closeDrawer(); S.tab = "files"; render(); return loadFiles(site.path);
        case "terminal": return api("server_terminal", { id: S.current, path: site.path });
        case "env": return editFile(joinPath(site.path, ".env"));
        case "database":
          try {
            toast("success", "Opening the database through SSH…");
            const target = await LD.call("server_db", { id: S.current, path: site.path });
            closeDrawer();
            setView("database");
            return Database.open(target.conn, target.database);
          } catch (err) {
            return toast("error", "Couldn't open the database", err.message);
          }
        case "log": S.siteTab = "logs"; return renderSite();
        case "log-refresh": return loadLog(true);
        case "deploy":
          if (site.is_atomic) { S.siteTab = "deployments"; return renderSite(); }
          return runRemote("remote-deploy", sitePayload(site));
        case "restart": return runRemote("remote-restart", sitePayload(site));
        case "install": case "build": return runRemote("remote-app", { ...sitePayload(site), op: el.dataset.rsa });
        case "pull": return runRemote("remote-git", { path: site.path, op: "pull" });
        case "composer": return runRemote("remote-composer", { path: site.path, php: site.php });
        case "down": case "up": return runRemote("remote-maintenance", { path: site.path, php: site.php, op: el.dataset.rsa });
      }
    }
  });

  document.addEventListener("submit", (e) => {
    if (e.target.matches("[data-rmanage]")) {
      e.preventDefault();
      const margs = e.target.elements.args.value.trim().replace(/^(python3?\s+)?manage\.py\s+/, "");
      if (margs) runRemote("remote-manage", { ...sitePayload(S.site), args: margs });
      e.target.elements.args.value = "";
      return;
    }
    if (!e.target.matches("[data-rartisan]")) return;
    e.preventDefault();
    const args = e.target.elements.args.value.trim().replace(/^(php\s+)?artisan\s+/, "");
    if (!args) return;
    runRemote("remote-artisan", { path: S.site.path, php: S.site.php, args });
    e.target.elements.args.value = "";
  });

  async function editFile(path) {
    try {
      await LD.call("server_edit", { id: S.current, path });
      toast("success", `Opened ${path.split("/").pop()}`, "Saving it uploads the file back to the server.");
    } catch (err) {
      toast("error", "Couldn't open file", err.message);
    }
  }

  return {
    closeSite() {
      S.site = null;
      clearInterval(logTimer);
    },
    async show() {
      if (!S.loaded) await loadList();
      render();
    },
    onEvent(event) {
      if (event.type === "remote-file") {
        event.ok ? toast("success", `Saved to server: ${event.path.split("/").pop()}`)
                 : toast("error", `Upload failed: ${event.path.split("/").pop()}`, event.error);
      }
      if (event.type === "transfer") {
        event.ok ? toast("success", event.label) : toast("error", "Transfer failed", event.error);
        if (event.ok && S.tab === "files" && S.current) loadFiles(S.files.path);
      }
    },
    onTaskDone(task) {
      // Remote task titles end with "· <server name>"; refresh that server's view.
      if (!S.current || !server() || !S.info || !task.title.endsWith(`· ${server().name}`)) return;
      LD.call("server_info", { id: S.current }).then((info) => { S.info = info; if (S.tab === "overview") renderBody(); }).catch(() => {});
      if (S.tab === "sites") loadSites();
    },
  };
})();
window.Servers = Servers;
loadServersCount();

async function loadServersCount() {
  try {
    const data = await LD.call("servers");
    $("#nav-servers-count").textContent = data.servers.length || "";
  } catch { /* shown when the page opens */ }
}

/* ── demo data for designing in a browser ─────────────── */
{
  const base = Demo.handle;
  const demoServers = [
    { id: "prod", name: "Production", host: "203.0.113.10", user: "forge", port: "", key: "", auth_mode: "key", connected: true },
    { id: "staging", name: "Staging", host: "staging", user: "", port: "2222", key: "", auth_mode: "auto", connected: false },
  ];
  Demo.handle = function (id, method, params) {
    const ok = (data) => setTimeout(() => LD.resolve(id, { ok: true, data }), 160);
    switch (method) {
      case "servers": return ok({ servers: demoServers, ssh_hosts: ["roayat", "do-box"], mux: true });
      case "server_info": return ok({
        hostname: "prod-01", os: "Ubuntu 24.04.1 LTS", kernel: "6.8.0-45-generic", uptime: "1893210", load: "0.42 0.37 0.30",
        cpus: "4", mem_total: "8264736768", mem_used: "5123637248", disk_total: "84321009664", disk_used: "71028514816",
        user: "forge", home: "/home/forge", sudo: "password", php: "8.3.12", git: "yes", composer: "yes", sudo_cached: false,
        units: [{ unit: "nginx", status: "active" }, { unit: "mysql", status: "active" }, { unit: "redis-server", status: "active" },
          { unit: "supervisor", status: "active" }, { unit: "php8.3-fpm", status: "active" }, { unit: "php8.2-fpm", status: "inactive" }],
      });
      case "server_sites": return ok([
        { name: "shop", path: "/home/forge/shop.example.com", domains: ["shop.example.com", "www.shop.example.com"], url: "https://shop.example.com", php: "8.3", ssl: true, branch: "main", down: false },
        { name: "api", path: "/var/www/api", domains: ["api.example.com"], url: "https://api.example.com", php: "8.3", ssl: true, branch: "production", down: true },
        { name: "storefront", type: "nuxt", path: "/var/www/storefront", domains: ["example.com"], url: "https://example.com", php: "", ssl: true, branch: "main", down: false, port: "3000", pm2: { id: 0, name: "storefront", status: "online" } },
        { name: "admin", type: "django", path: "/srv/admin", domains: ["admin.example.com"], url: "https://admin.example.com", php: "", ssl: true, branch: "main", down: false, unit: "gunicorn-admin", unit_status: "active" },
      ]);
      case "server_ls": return ok({ path: params.path === "~" ? "/home/forge" : params.path, entries: [
        { name: "app", dir: true, link: false, size: 4096, mtime: 1761000000, mode: "755", owner: "forge" },
        { name: "public", dir: true, link: false, size: 4096, mtime: 1761100000, mode: "755", owner: "forge" },
        { name: "storage", dir: true, link: false, size: 4096, mtime: 1761200000, mode: "775", owner: "www-data" },
        { name: ".env", dir: false, link: false, size: 1834, mtime: 1761300000, mode: "640", owner: "forge" },
        { name: "artisan", dir: false, link: false, size: 425, mtime: 1760000000, mode: "755", owner: "forge" },
        { name: "composer.json", dir: false, link: false, size: 2412, mtime: 1760500000, mode: "644", owner: "forge" },
      ] });
      case "server_log": return ok({ exists: true, text: "[2026-10-22 09:12:01] production.INFO: Payment captured\n[2026-10-22 09:14:44] production.ERROR: SQLSTATE[HY000] Connection refused" });
      default: return base.call(this, id, method, params);
    }
  };
}
