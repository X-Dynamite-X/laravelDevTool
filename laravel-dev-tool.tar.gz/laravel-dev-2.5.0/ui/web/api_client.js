"use strict";

/* ── API Client & Documentation Studio (Postman-compatible) ───────────────────
   Full-featured Postman-like HTTP Client, Collections & Environments manager,
   Laravel Route Sync, Postman v2.1 Import/Export, Code Snippets, and
   Interactive API Documentation Generator (HTML / Markdown / OpenAPI 3.0).
───────────────────────────────────────────────────────────────────────────── */

const ApiClient = (() => {
  const tr = (key, fallback) => (window.t ? window.t(key, fallback) : (fallback !== undefined ? fallback : key));

  const METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"];
  const CODE_LANGS = [
    ["curl", "cURL"],
    ["fetch", "JS Fetch"],
    ["axios", "Axios"],
    ["laravel", "Laravel Http"],
    ["python", "Python"],
    ["dart", "Dart"],
  ];

  const S = {
    loaded: false,
    loading: false,
    mountRoot: null,       // Active DOM container (#view-api-client or site drawer pane)
    siteContext: null,     // Set when mounted inside a specific site's drawer
    mode: "builder",       // "builder" | "docs"
    sidebarTab: "collections", // "collections" | "history"
    folderLayout: (() => { try { return localStorage.getItem("ld_ac_folder_layout") || "nested"; } catch { return "nested"; } })(), // "nested" | "flat" | "original"
    sidebarSearch: "",
    expanded: new Set(),   // Expanded collection/folder IDs
    collections: [],
    environments: [],
    activeEnvId: "",
    history: [],
    tabs: [],              // Open request tabs: [{ tabId, collectionId, folderPath, request, dirty, sending, response, reqSubTab, respSubTab, bodyViewMode, respSearch, options }]
    activeTabId: "",
    docsCollectionId: "",
    docsSearch: "",
    docsSnippetLang: "curl",
    modal: null,           // Active studio modal state
  };

  let tabCounter = 1;

  // ── Helpers ────────────────────────────────────────────────────────────────

  function uid(prefix) {
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  }

  function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  function fmtBytes(n) {
    const num = Number(n || 0);
    if (!num) return "0 B";
    if (num < 1024) return `${num} B`;
    if (num < 1048576) return `${(num / 1024).toFixed(1)} KB`;
    return `${(num / 1048576).toFixed(2)} MB`;
  }

  function methodCls(m) {
    const low = String(m || "GET").toLowerCase();
    if (low === "post") return "post";
    if (low === "put" || low === "patch") return "put";
    if (low === "delete") return "delete";
    if (low === "head" || low === "options") return "other";
    return "get";
  }

  function statusCls(code) {
    const c = Number(code || 0);
    if (c >= 200 && c < 300) return "s2xx";
    if (c >= 300 && c < 400) return "s3xx";
    if (c >= 400 && c < 500) return "s4xx";
    return "s5xx";
  }

  function highlightJson(val) {
    const text = typeof val === "string" ? val : JSON.stringify(val, null, 2);
    return esc(text).replace(
      /(&quot;(?:\\.|[^\\&]|&(?!quot;))*?&quot;)(\s*:)?|\b(true|false|null)\b|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g,
      (match, str, colon, lit, num) => {
        if (str) return colon ? `<span class="ni-json-key">${str}</span>${colon}` : `<span class="ni-json-str">${str}</span>`;
        if (lit) return `<span class="ni-json-lit">${lit}</span>`;
        return `<span class="ni-json-num">${num}</span>`;
      }
    );
  }

  function downloadText(filename, content, mime = "application/json") {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function blankRequest(overrides = {}) {
    return {
      id: uid("req"),
      type: "request",
      name: overrides.name || tr("ac_new_request", "New Request"),
      description: overrides.description || "",
      method: (overrides.method || "GET").toUpperCase(),
      url: overrides.url || "",
      params: overrides.params || [],
      path_variables: overrides.path_variables || [],
      headers: overrides.headers || [
        { key: "Accept", value: "application/json", enabled: true, description: "" },
      ],
      auth: overrides.auth || { type: "inherit" },
      body: overrides.body || {
        mode: "none",
        raw: "",
        raw_type: "json",
        formdata: [],
        urlencoded: [],
        graphql: { query: "", variables: "" },
      },
      tests: overrides.tests || [],
      extractors: overrides.extractors || [],
      examples: overrides.examples || [],
    };
  }

  function activeTab() {
    return S.tabs.find((item) => item.tabId === S.activeTabId) || S.tabs[0] || null;
  }

  function activeEnv() {
    return S.environments.find((e) => e.id === S.activeEnvId) || null;
  }

  function getCollectionById(id) {
    return S.collections.find((c) => c.id === id) || null;
  }

  function getMergedVars(collectionId) {
    const map = {};
    const col = getCollectionById(collectionId);
    if (col) {
      for (const v of col.variables || []) {
        if (v.enabled !== false && v.key) map[v.key] = v.value || "";
      }
    }
    const env = activeEnv();
    if (env) {
      for (const v of env.variables || []) {
        if (v.enabled !== false && v.key) map[v.key] = v.value || "";
      }
    }
    if (S.siteContext?.url && !map.base_url) {
      map.base_url = S.siteContext.url.replace(/\/$/, "");
    }
    return map;
  }

  function resolvePreviewUrl(urlStr, collectionId) {
    if (!urlStr || !urlStr.includes("{{")) return "";
    const vars = getMergedVars(collectionId);
    return urlStr.replace(/\{\{\s*([^{}\s]+)\s*\}\}/g, (m, k) => (k in vars ? vars[k] : m));
  }

  // Locate a request or folder inside a collection tree
  function findItemInTree(items, itemId, parents = []) {
    for (let i = 0; i < (items || []).length; i++) {
      const it = items[i];
      if (it.id === itemId) {
        return { item: it, list: items, index: i, parents };
      }
      if (it.type === "folder" && Array.isArray(it.items)) {
        const hit = findItemInTree(it.items, itemId, [...parents, it]);
        if (hit) return hit;
      }
    }
    return null;
  }

  function resolveInheritedAuth(collectionId, requestId) {
    const col = getCollectionById(collectionId);
    if (!col) return { type: "none" };
    let auth = col.auth || { type: "none" };
    if (requestId) {
      const hit = findItemInTree(col.items, requestId);
      if (hit) {
        for (const folder of hit.parents) {
          if (folder.auth && folder.auth.type && folder.auth.type !== "inherit") {
            auth = folder.auth;
          }
        }
      }
    }
    return auth;
  }

  function flattenFolders(items, prefix = "") {
    const out = [];
    for (const it of items || []) {
      if (it.type === "folder") {
        const label = prefix ? `${prefix} / ${it.name}` : it.name;
        out.push({ id: it.id, label, folder: it });
        out.push(...flattenFolders(it.items || [], label));
      }
    }
    return out;
  }

  function flattenEndpoints(items, folderLabel = "General", parentAuth = { type: "none" }) {
    const out = [];
    for (const it of items || []) {
      if (it.type === "folder") {
        const effAuth = it.auth && it.auth.type && it.auth.type !== "inherit" ? it.auth : parentAuth;
        const lbl = folderLabel === "General" ? it.name : `${folderLabel} / ${it.name}`;
        out.push(...flattenEndpoints(it.items || [], lbl, effAuth));
      } else {
        const effAuth = it.auth && it.auth.type && it.auth.type !== "inherit" ? it.auth : parentAuth;
        out.push({ folder: folderLabel, request: it, effectiveAuth: effAuth });
      }
    }
    return out;
  }

  function countRequests(items) {
    let n = 0;
    for (const it of items || []) {
      if (it.type === "folder") n += countRequests(it.items || []);
      else n += 1;
    }
    return n;
  }

  // ── Folder Layout Builders (Nested Path Tree vs Flat vs Original) ──────────

  function extractStaticPathSegments(urlStr) {
    let raw = String(urlStr || "").trim().split("?", 1)[0].split("#", 1)[0];
    raw = raw.replace(/^https?:\/\/[^/]+/i, "").replace(/^\{\{[^}]+\}\}/, "").replace(/^\/+|\/+$/g, "");
    if (!raw) return [];
    let parts = raw.split("/").filter(Boolean);
    if (parts.length > 1 && parts[0].toLowerCase() === "api") parts = parts.slice(1);
    return parts.filter((seg) => !((seg.startsWith("{") && seg.endsWith("}")) || seg.startsWith(":")));
  }

  function flatFolderNameFromUrl(urlStr) {
    const segs = extractStaticPathSegments(urlStr);
    const cleaned = segs.filter((s) => !/^v\d+$/i.test(s));
    if (cleaned.length) {
      return cleaned[0].replace(/[-_]+/g, " ").replace(/\b\w/g, (ch) => ch.toUpperCase());
    }
    return segs.length ? segs[0].toUpperCase() : "";
  }

  function collectAllRequestsAndEmptyFolders(items, reqsOut = [], emptyOut = []) {
    for (const it of items || []) {
      if (it.type === "folder") {
        if (!countRequests(it.items)) emptyOut.push(it);
        else collectAllRequestsAndEmptyFolders(it.items, reqsOut, emptyOut);
      } else {
        reqsOut.push(it);
      }
    }
    return { reqs: reqsOut, emptyFolders: emptyOut };
  }

  function buildDisplayItems(col, layoutMode = S.folderLayout) {
    if (!col) return [];
    const mode = layoutMode || "nested";
    if (mode === "original") return col.items || [];

    const { reqs, emptyFolders } = collectAllRequestsAndEmptyFolders(col.items || []);
    if (!reqs.length) return col.items || [];

    if (mode === "flat") {
      const groups = new Map();
      const rootReqs = [];
      for (const req of reqs) {
        const fname = flatFolderNameFromUrl(req.url);
        if (fname) {
          if (!groups.has(fname)) groups.set(fname, []);
          groups.get(fname).push(req);
        } else {
          rootReqs.push(req);
        }
      }
      const folders = Array.from(groups.keys())
        .sort((a, b) => a.localeCompare(b))
        .map((fname) => ({
          id: `vdir:${col.id}:flat:${fname}`,
          type: "folder",
          name: fname,
          _virtual: true,
          _pathPrefix: fname.toLowerCase().replace(/\s+/g, "-"),
          items: groups.get(fname),
        }));
      return [...folders, ...rootReqs, ...emptyFolders];
    }

    // "nested" -> hierarchical path tree for ALL APIs (e.g. v1 -> admin -> products, v1 -> products -> reviews)
    const rootNode = { folders: new Map(), requests: [] };
    for (const req of reqs) {
      const segs = extractStaticPathSegments(req.url);
      let node = rootNode;
      for (const seg of segs) {
        if (!node.folders.has(seg)) {
          node.folders.set(seg, { name: seg, folders: new Map(), requests: [] });
        }
        node = node.folders.get(seg);
      }
      node.requests.push(req);
    }

    const toItems = (node, prefix = "") => {
      const out = [];
      const sortedNames = Array.from(node.folders.keys()).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
      for (const fname of sortedNames) {
        const child = node.folders.get(fname);
        const fullPath = prefix ? `${prefix}/${fname}` : fname;
        out.push({
          id: `vdir:${col.id}:nested:${fullPath}`,
          type: "folder",
          name: fname,
          _virtual: true,
          _pathPrefix: fullPath,
          items: toItems(child, fullPath),
        });
      }
      out.push(...node.requests);
      return out;
    };

    return [...toItems(rootNode), ...emptyFolders];
  }

  function setFolderLayout(mode) {
    if (!["nested", "flat", "original"].includes(mode)) return;
    S.folderLayout = mode;
    try { localStorage.setItem("ld_ac_folder_layout", mode); } catch { /* ignore */ }
    render();
  }

  // Sync URL <-> Query Params & Path Variables
  function syncParamsFromUrl(req) {
    const raw = req.url || "";
    const qIdx = raw.indexOf("?");
    if (qIdx >= 0) {
      const qs = raw.slice(qIdx + 1);
      const parsed = [];
      if (qs) {
        for (const part of qs.split("&")) {
          if (!part) continue;
          const eq = part.indexOf("=");
          const k = eq >= 0 ? decodeURIComponentSafe(part.slice(0, eq)) : decodeURIComponentSafe(part);
          const v = eq >= 0 ? decodeURIComponentSafe(part.slice(eq + 1)) : "";
          const prev = (req.params || []).find((p) => p.key === k);
          parsed.push({ key: k, value: v, enabled: true, description: prev?.description || "" });
        }
      }
      const disabled = (req.params || []).filter((p) => p.enabled === false);
      req.params = [...parsed, ...disabled];
    } else {
      // Remove enabled params if user stripped '?' from URL
      req.params = (req.params || []).filter((p) => p.enabled === false);
    }

    // Extract path variables (:id or {id} or {id?}) from path portion
    const baseOnly = qIdx >= 0 ? raw.slice(0, qIdx) : raw;
    const withoutProto = baseOnly.replace(/^https?:\/\/[^/]*/i, "").replace(/^\{\{[^}]+\}\}/, "");
    const seen = new Set();
    const nextPathVars = [];
    const re = /(?::([a-zA-Z_][a-zA-Z0-9_]*)|\{([a-zA-Z_][a-zA-Z0-9_]*)\??\})/g;
    let match;
    while ((match = re.exec(withoutProto)) !== null) {
      const key = match[1] || match[2];
      if (!seen.has(key)) {
        seen.add(key);
        const existing = (req.path_variables || []).find((p) => p.key === key);
        nextPathVars.push({
          key,
          value: existing ? existing.value : "",
          enabled: true,
          description: existing ? existing.description : "",
        });
      }
    }
    req.path_variables = nextPathVars;
  }

  function syncUrlFromParams(req) {
    const raw = req.url || "";
    const qIdx = raw.indexOf("?");
    const base = qIdx >= 0 ? raw.slice(0, qIdx) : raw;
    const enabled = (req.params || []).filter((p) => p.enabled !== false && p.key);
    if (!enabled.length) {
      req.url = base;
      return;
    }
    const qs = enabled.map((p) => `${encodeURIComponent(p.key)}=${encodeURIComponent(p.value || "")}`).join("&");
    req.url = `${base}?${qs}`;
  }

  function decodeURIComponentSafe(s) {
    try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch { return s; }
  }

  // ── Backend Sync ───────────────────────────────────────────────────────────

  async function loadState(force = false) {
    if (S.loaded && !force) return;
    S.loading = true;
    try {
      const res = await LD.call("postman_state");
      applyState(res);
      S.loaded = true;
    } catch (err) {
      toast("error", tr("ac_load_failed", "Couldn't load API Client"), err.message);
    } finally {
      S.loading = false;
    }
  }

  function applyState(res) {
    if (!res) return;
    if (Array.isArray(res.collections)) S.collections = res.collections;
    if (Array.isArray(res.environments)) S.environments = res.environments;
    if (typeof res.active_env_id === "string") S.activeEnvId = res.active_env_id;
    if (Array.isArray(res.history)) S.history = res.history;
    if (!S.docsCollectionId || !getCollectionById(S.docsCollectionId)) {
      S.docsCollectionId = S.collections[0]?.id || "";
    }
    // Auto-select matching environment when inside a site drawer
    if (S.siteContext) {
      const siteEnv = S.environments.find((e) => e.site_name === S.siteContext.name);
      if (siteEnv) S.activeEnvId = siteEnv.id;
      const siteCol = S.collections.find((c) => c.site_name === S.siteContext.name);
      if (siteCol) {
        S.expanded.add(siteCol.id);
        S.docsCollectionId = siteCol.id;
      }
    } else if (S.collections.length && !S.expanded.size) {
      S.expanded.add(S.collections[0].id);
    }
    if (!S.tabs.length) {
      openBlankTab();
    }
  }

  async function persistCollection(col) {
    const res = await LD.call("postman_save_collection", { collection: col });
    if (res?.collection) {
      const idx = S.collections.findIndex((c) => c.id === res.collection.id);
      if (idx >= 0) S.collections[idx] = res.collection;
      else S.collections.unshift(res.collection);
      return res.collection;
    }
    return col;
  }

  async function persistEnvironments() {
    const res = await LD.call("postman_save_environments", {
      environments: S.environments,
      active_env_id: S.activeEnvId,
    });
    if (res?.environments) {
      S.environments = res.environments;
      S.activeEnvId = res.active_env_id || "";
    }
  }

  // ── Tab Management ─────────────────────────────────────────────────────────

  function openBlankTab(initialReq = null, collectionId = "") {
    const tabId = `tab_${tabCounter++}`;
    const req = initialReq ? deepClone(initialReq) : blankRequest({
      url: S.siteContext?.url ? "{{base_url}}/api/" : "",
    });
    const tab = {
      tabId,
      collectionId: collectionId || "",
      request: req,
      dirty: !collectionId,
      sending: false,
      response: null,
      reqSubTab: "params",
      respSubTab: "body",
      bodyViewMode: "pretty",
      respSearch: "",
      options: { follow_redirects: true, timeout: 30 },
    };
    S.tabs.push(tab);
    S.activeTabId = tabId;
    S.mode = "builder";
    return tab;
  }

  function openRequestInTab(collectionId, reqItem) {
    const existing = S.tabs.find((tb) => tb.collectionId === collectionId && tb.request.id === reqItem.id);
    if (existing) {
      S.activeTabId = existing.tabId;
      S.mode = "builder";
      render();
      return existing;
    }
    const tab = openBlankTab(reqItem, collectionId);
    tab.dirty = false;
    render();
    return tab;
  }

  function closeTab(tabId) {
    const idx = S.tabs.findIndex((tb) => tb.tabId === tabId);
    if (idx < 0) return;
    S.tabs.splice(idx, 1);
    if (!S.tabs.length) {
      openBlankTab();
    } else if (S.activeTabId === tabId) {
      S.activeTabId = S.tabs[Math.max(0, idx - 1)].tabId;
    }
    render();
  }

  async function saveActiveTab(forcePickTarget = false) {
    const tab = activeTab();
    if (!tab) return;
    const col = getCollectionById(tab.collectionId);
    if (!col || forcePickTarget) {
      openSaveToCollectionModal(tab);
      return;
    }
    const hit = findItemInTree(col.items, tab.request.id);
    if (hit) {
      hit.list[hit.index] = deepClone(tab.request);
    } else {
      col.items.push(deepClone(tab.request));
    }
    try {
      await persistCollection(col);
      tab.dirty = false;
      toast("success", tr("ac_saved", "Request saved"), tab.request.name);
      render();
    } catch (err) {
      toast("error", tr("ac_save_failed", "Couldn't save request"), err.message);
    }
  }

  async function sendActiveRequest() {
    const tab = activeTab();
    if (!tab || tab.sending) return;
    if (!tab.request.url.trim()) {
      toast("error", tr("ac_url_required", "Enter a request URL first"));
      return;
    }
    tab.sending = true;
    render();
    const col = getCollectionById(tab.collectionId);
    const inheritedAuth = resolveInheritedAuth(tab.collectionId, tab.request.id);
    try {
      const res = await LD.call("postman_send", {
        request: tab.request,
        env_id: S.activeEnvId,
        collection_variables: col?.variables || [],
        inherited_auth: inheritedAuth,
        timeout: tab.options?.timeout || 30,
        follow_redirects: tab.options?.follow_redirects !== false,
      });
      tab.response = res;
      if (Array.isArray(res.history)) S.history = res.history;
      if (res.updated_environment) {
        const idx = S.environments.findIndex((e) => e.id === res.updated_environment.id);
        if (idx >= 0) S.environments[idx] = res.updated_environment;
        const keys = Object.keys(res.extracted_vars || {});
        if (keys.length) {
          toast("success", tr("ac_vars_extracted", "Environment variables updated"), keys.join(", "));
        }
      }
      if (!res.ok && res.error) {
        toast("error", tr("ac_request_failed", "Request failed"), res.error);
      }
    } catch (err) {
      tab.response = { ok: false, error: err.message, duration_ms: 0 };
      toast("error", tr("ac_request_failed", "Request failed"), err.message);
    } finally {
      tab.sending = false;
      render();
    }
  }

  async function saveResponseAsExample() {
    const tab = activeTab();
    if (!tab || !tab.response || !tab.response.ok) return;
    const resp = tab.response;
    const defaultName = `${resp.status} ${resp.status_text || ""}`.trim();
    const exName = prompt(tr("ac_example_name_prompt", "Example name (used in API Docs & Postman export):"), defaultName);
    if (!exName) return;
    const example = {
      id: uid("ex"),
      name: exName.trim(),
      status: resp.status || 200,
      status_text: resp.status_text || "",
      headers: Object.entries(resp.headers || {}).map(([k, v]) => ({ key: k, value: String(v) })),
      body: resp.is_json ? JSON.stringify(resp.json, null, 2) : (resp.text || ""),
      created_at: new Date().toISOString(),
    };
    tab.request.examples = tab.request.examples || [];
    tab.request.examples.push(example);
    tab.dirty = true;
    tab.respSubTab = "examples";
    if (tab.collectionId) {
      await saveActiveTab(false);
    } else {
      toast("success", tr("ac_example_added", "Saved response example"), exName);
      render();
    }
  }

  // ── Collection / Folder CRUD ───────────────────────────────────────────────

  async function createNewCollection(nameOverride = "", siteName = "") {
    const name = nameOverride || prompt(tr("ac_collection_name_prompt", "New Collection name:"), "My API Collection");
    if (!name || !name.trim()) return null;
    const site = siteName ? (state.sites || []).find((s) => s.name === siteName) : S.siteContext;
    const col = {
      id: uid("col"),
      name: name.trim(),
      description: "",
      site_name: site?.name || "",
      auth: { type: "none" },
      variables: [
        { key: "base_url", value: site?.url ? site.url.replace(/\/$/, "") : "http://localhost:8000", enabled: true, description: "Base API URL" },
      ],
      items: [],
    };
    const saved = await persistCollection(col);
    S.expanded.add(saved.id);
    if (!S.docsCollectionId) S.docsCollectionId = saved.id;
    toast("success", tr("ac_collection_created", "Collection created"), saved.name);
    render();
    return saved;
  }

  async function addFolder(collectionId, parentFolderId = null) {
    const col = getCollectionById(collectionId);
    if (!col) return;
    const name = prompt(tr("ac_folder_name_prompt", "Folder name:"), "Users");
    if (!name || !name.trim()) return;
    const folder = { id: uid("fld"), type: "folder", name: name.trim(), description: "", auth: { type: "inherit" }, items: [] };
    if (parentFolderId) {
      const hit = findItemInTree(col.items, parentFolderId);
      if (hit && hit.item.type === "folder") hit.item.items.push(folder);
    } else {
      col.items.push(folder);
    }
    S.expanded.add(collectionId);
    S.expanded.add(folder.id);
    await persistCollection(col);
    render();
  }

  async function addRequestTo(collectionId, parentFolderId = null, urlPrefix = "") {
    const col = getCollectionById(collectionId);
    if (!col) return;
    const cleanPrefix = String(urlPrefix || "").replace(/^\/+|\/+$/g, "");
    const initialUrl = cleanPrefix ? `{{base_url}}/api/${cleanPrefix}/` : "{{base_url}}/api/";
    const req = blankRequest({
      name: tr("ac_new_request", "New Request"),
      url: initialUrl,
    });
    if (parentFolderId && !String(parentFolderId).startsWith("vdir:")) {
      const hit = findItemInTree(col.items, parentFolderId);
      if (hit && hit.item.type === "folder") {
        hit.item.items.push(req);
        S.expanded.add(parentFolderId);
      } else {
        col.items.push(req);
      }
    } else {
      col.items.push(req);
      if (parentFolderId) S.expanded.add(parentFolderId);
    }
    S.expanded.add(collectionId);
    await persistCollection(col);
    openRequestInTab(collectionId, req);
  }

  async function duplicateItem(collectionId, itemId) {
    const col = getCollectionById(collectionId);
    if (!col) return;
    const hit = findItemInTree(col.items, itemId);
    if (!hit) return;
    const copy = deepClone(hit.item);
    const reId = (node) => {
      node.id = uid(node.type === "folder" ? "fld" : "req");
      if (node.type === "folder") (node.items || []).forEach(reId);
    };
    reId(copy);
    copy.name = `${copy.name} (Copy)`;
    hit.list.splice(hit.index + 1, 0, copy);
    await persistCollection(col);
    render();
  }

  async function deleteItem(collectionId, itemId) {
    const col = getCollectionById(collectionId);
    if (!col) return;
    const hit = findItemInTree(col.items, itemId);
    if (!hit) return;
    if (!confirm(`${tr("delete", "Delete")} "${hit.item.name}"?`)) return;
    hit.list.splice(hit.index, 1);
    await persistCollection(col);
    // Close open tab if it belonged to deleted request
    S.tabs = S.tabs.filter((tb) => !(tb.collectionId === collectionId && tb.request.id === itemId));
    if (!S.tabs.length) openBlankTab();
    else if (!S.tabs.some((tb) => tb.tabId === S.activeTabId)) S.activeTabId = S.tabs[0].tabId;
    render();
  }

  async function deleteCollection(collectionId) {
    const col = getCollectionById(collectionId);
    if (!col) return;
    if (!confirm(`${tr("delete", "Delete")} "${col.name}"?`)) return;
    await LD.call("postman_delete_collection", { id: collectionId });
    S.collections = S.collections.filter((c) => c.id !== collectionId);
    if (S.docsCollectionId === collectionId) S.docsCollectionId = S.collections[0]?.id || "";
    toast("success", tr("ac_collection_deleted", "Collection deleted"), col.name);
    render();
  }

  async function renameFolder(collectionId, folderId) {
    const col = getCollectionById(collectionId);
    if (!col) return;
    const hit = findItemInTree(col.items, folderId);
    if (!hit) return;
    const next = prompt(tr("ac_rename_prompt", "New name:"), hit.item.name);
    if (!next || !next.trim()) return;
    hit.item.name = next.trim();
    await persistCollection(col);
    render();
  }

  // ── Export & Import Actions ────────────────────────────────────────────────

  async function exportCollection(collectionId, format = "postman_v21") {
    try {
      const res = await LD.call("postman_export", {
        collection_id: collectionId,
        env_id: S.activeEnvId,
        format,
        folder_mode: S.folderLayout,
      });
      if (!res?.ok) throw new Error(res?.error || "Export failed");
      downloadText(res.filename, res.content, res.mime || "application/json");
      toast("success", tr("ac_exported", "Exported successfully"), res.filename);
    } catch (err) {
      toast("error", tr("ac_export_failed", "Export failed"), err.message);
    }
  }

  async function exportEnvironment(envId) {
    try {
      const res = await LD.call("postman_export", { env_id: envId, format: "postman_env" });
      if (!res?.ok) throw new Error(res?.error || "Export failed");
      downloadText(res.filename, res.content, "application/json");
      toast("success", tr("ac_exported", "Exported successfully"), res.filename);
    } catch (err) {
      toast("error", tr("ac_export_failed", "Export failed"), err.message);
    }
  }

  async function performImport(rawText) {
    if (!rawText || !rawText.trim()) {
      toast("error", tr("ac_import_empty", "Paste JSON/cURL or select a file to import"));
      return;
    }
    try {
      const res = await LD.call("postman_import", { content: rawText });
      if (!res?.ok) throw new Error(res?.error || "Import failed");
      if (res.state) applyState(res.state);
      if (res.kind === "collection" && res.collection) {
        S.expanded.add(res.collection.id);
        S.docsCollectionId = res.collection.id;
        toast("success", tr("ac_imported_collection", "Collection imported"), res.collection.name);
      } else if (res.kind === "environment" && res.environment) {
        S.activeEnvId = res.environment.id;
        toast("success", tr("ac_imported_env", "Environment imported"), res.environment.name);
      } else if (res.kind === "request" && res.request) {
        openBlankTab(res.request, "");
        toast("success", tr("ac_imported_curl", "cURL imported into new tab"), res.request.name);
      }
      S.modal = null;
      render();
    } catch (err) {
      toast("error", tr("ac_import_failed", "Import failed"), err.message);
    }
  }

  async function syncRoutesForSite(siteName, apiOnly = true, replaceExisting = true, folderMode = null) {
    if (!siteName) return;
    const targetMode = folderMode || (S.folderLayout === "flat" ? "flat" : "nested");
    toast("info", tr("ac_syncing_routes", "Scanning Laravel routes…"), siteName);
    try {
      const res = await LD.call("postman_from_routes", {
        name: siteName,
        api_only: apiOnly,
        replace_existing: replaceExisting,
        folder_mode: targetMode,
        force: true,
      });
      if (!res?.ok) throw new Error(res?.error || "Failed to generate collection");
      if (res.state) applyState(res.state);
      if (res.collection) {
        S.folderLayout = targetMode;
        try { localStorage.setItem("ld_ac_folder_layout", targetMode); } catch { /* ignore */ }
        S.expanded.add(res.collection.id);
        S.docsCollectionId = res.collection.id;
        const eps = flattenEndpoints(res.collection.items);
        if (eps.length) {
          openRequestInTab(res.collection.id, eps[0].request);
        }
        const stats = res.sync_stats || {};
        const summaryParts = [`${eps.length} endpoints`];
        if (stats.body_fields) summaryParts.push(`${stats.body_fields} fields`);
        if (stats.headers) summaryParts.push(`${stats.headers} headers`);
        toast(
          "success",
          tr("ac_routes_synced", "Collection generated from Laravel routes"),
          `${res.collection.name} (${summaryParts.join(" · ")})`
        );
      }
      S.modal = null;
      render();
    } catch (err) {
      toast("error", tr("ac_sync_failed", "Route sync failed"), err.message);
    }
  }

  // ── Modals (Import, Sync Routes, Environments, Collection Settings, Save As, Code Snippet) ──

  function openImportModal() {
    S.modal = { kind: "import", text: "" };
    render();
  }

  function openSyncRoutesModal() {
    const laravelSites = (state.sites || []).filter((s) => s.linked && s.type === "laravel");
    const defaultSite = S.siteContext?.name || laravelSites[0]?.name || "";
    const defaultLayout = S.folderLayout === "flat" ? "flat" : "nested";
    S.modal = { kind: "sync_routes", siteName: defaultSite, apiOnly: true, replaceExisting: true, folderMode: defaultLayout };
    render();
  }

  function openEnvironmentsModal() {
    if (!S.environments.length) {
      const newEnv = {
        id: uid("env"),
        name: S.siteContext ? `${S.siteContext.name} (Local)` : "Local",
        site_name: S.siteContext?.name || "",
        variables: [
          { id: uid("var"), key: "base_url", value: S.siteContext?.url?.replace(/\/$/, "") || "http://localhost:8000", enabled: true, secret: false, description: "" },
          { id: uid("var"), key: "token", value: "", enabled: true, secret: true, description: "" },
        ],
      };
      S.environments.push(newEnv);
      S.activeEnvId = newEnv.id;
    }
    S.modal = { kind: "environments", editEnvId: S.activeEnvId || S.environments[0].id };
    render();
  }

  function openCollectionSettingsModal(collectionId) {
    const col = getCollectionById(collectionId);
    if (!col) return;
    S.modal = { kind: "collection_settings", collection: deepClone(col) };
    render();
  }

  function openSaveToCollectionModal(tab) {
    const defaultColId = tab.collectionId || S.collections[0]?.id || "__new__";
    S.modal = {
      kind: "save_as",
      tabId: tab.tabId,
      name: tab.request.name || "New Request",
      collectionId: defaultColId,
      newCollectionName: S.siteContext ? `${S.siteContext.name} API` : "My API Collection",
      folderId: "",
    };
    render();
  }

  async function openCodeSnippetModal(tab, lang = "curl") {
    S.modal = { kind: "code", tabId: tab.tabId, lang, code: "Generating…", loading: true };
    render();
    try {
      const col = getCollectionById(tab.collectionId);
      const res = await LD.call("postman_snippet", {
        request: tab.request,
        lang,
        env_id: S.activeEnvId,
        collection_variables: col?.variables || [],
        inherited_auth: resolveInheritedAuth(tab.collectionId, tab.request.id),
      });
      if (S.modal?.kind === "code") {
        S.modal.code = res?.code || "";
        S.modal.loading = false;
        render();
      }
    } catch (err) {
      if (S.modal?.kind === "code") {
        S.modal.code = `// Error: ${err.message}`;
        S.modal.loading = false;
        render();
      }
    }
  }

  // ── Scroll Preservation & Renderers ────────────────────────────────────────

  const SCROLL_SELECTORS = [
    ".ac-sb-body",
    ".ac-tabs-scroll",
    ".ac-req-pane .ac-pane-body",
    ".ac-resp-pane .ac-pane-body",
    ".ac-docs-body",
    ".ac-modal-body",
  ];

  function captureScrolls(root) {
    const saved = {};
    for (const sel of SCROLL_SELECTORS) {
      const el = $(sel, root);
      if (el) saved[sel] = { top: el.scrollTop, left: el.scrollLeft };
    }
    const drawerBody = root.closest?.(".drawer-body");
    if (drawerBody) saved.__drawerBody = { top: drawerBody.scrollTop, left: drawerBody.scrollLeft };
    return saved;
  }

  function restoreScrolls(root, saved) {
    if (!saved) return;
    for (const sel of SCROLL_SELECTORS) {
      const pos = saved[sel];
      if (!pos) continue;
      const el = $(sel, root);
      if (el) {
        el.scrollTop = pos.top;
        el.scrollLeft = pos.left;
      }
    }
    if (saved.__drawerBody) {
      const drawerBody = root.closest?.(".drawer-body");
      if (drawerBody) {
        drawerBody.scrollTop = saved.__drawerBody.top;
        drawerBody.scrollLeft = saved.__drawerBody.left;
      }
    }
  }

  function render() {
    const root = S.mountRoot;
    if (!root || !root.isConnected) return;

    const savedScrolls = captureScrolls(root);
    const tab = activeTab();
    const env = activeEnv();

    root.innerHTML = `
      <div class="ac-studio ${S.siteContext ? "ac-embedded" : ""}">
        <!-- Top Toolbar -->
        <header class="ac-topbar">
          <div class="ac-topbar-left">
            ${!S.siteContext ? `
              <div class="ac-brand">
                <span class="ac-brand-icon">${icon("zap")}</span>
                <div>
                  <h1 class="ac-title">${esc(tr("api_client", "API Client"))}</h1>
                  <span class="ac-sub">${esc(tr("ac_subtitle", "Postman-compatible API tester & documentation studio"))}</span>
                </div>
              </div>
            ` : `
              <div class="ac-site-pill">
                ${icon("zap")} <b>${esc(S.siteContext.name)}</b>
                <span class="muted">· ${esc(S.siteContext.url || S.siteContext.domain || "")}</span>
              </div>
            `}
            <div class="ac-mode-switch" role="tablist">
              <button type="button" class="ac-mode-btn ${S.mode === "builder" ? "active" : ""}" data-ac-mode="builder">
                ${icon("play")}<span>${esc(tr("ac_mode_builder", "API Builder"))}</span>
              </button>
              <button type="button" class="ac-mode-btn ${S.mode === "docs" ? "active" : ""}" data-ac-mode="docs">
                ${icon("file")}<span>${esc(tr("ac_mode_docs", "API Docs"))}</span>
              </button>
            </div>
          </div>

          <div class="ac-topbar-right">
            <button type="button" class="btn sm ghost" id="ac-btn-sync-routes" title="${esc(tr("ac_sync_routes_tip", "Auto-generate a Postman collection from a Laravel project's routes"))}">
              ${icon("refresh")}<span>${esc(tr("ac_sync_routes", "Sync Laravel Routes"))}</span>
            </button>
            <button type="button" class="btn sm ghost" id="ac-btn-import" title="${esc(tr("ac_import_tip", "Import Postman Collection v2.1, Environment, OpenAPI 3.0, or cURL"))}">
              ${icon("upload")}<span>${esc(tr("ac_import", "Import"))}</span>
            </button>
            <div class="ac-env-box">
              <span class="ac-env-icon" title="${esc(tr("ac_environment", "Environment"))}">${icon("env")}</span>
              <select id="ac-env-select" class="ac-env-select" aria-label="Active Environment">
                <option value="">${esc(tr("ac_no_env", "No Environment"))}</option>
                ${S.environments.map((e) => `<option value="${esc(e.id)}" ${e.id === S.activeEnvId ? "selected" : ""}>${esc(e.name)} (${(e.variables || []).length})</option>`).join("")}
              </select>
              <button type="button" class="btn sm ghost icon-btn" id="ac-btn-manage-envs" title="${esc(tr("ac_manage_envs", "Manage Environments & Variables"))}">
                ${icon("settings")}
              </button>
            </div>
          </div>
        </header>

        <!-- Studio Body -->
        <div class="ac-workspace">
          ${renderSidebar()}
          <div class="ac-main">
            ${S.mode === "docs" ? renderDocsView() : renderBuilderView(tab, env)}
          </div>
        </div>
      </div>
      ${S.modal ? renderModal() : ""}
    `;

    wireEvents(root);
    // Force layout flush and restore exact scroll positions so expanding folders or clicking requests never jumps to top
    void root.offsetHeight;
    restoreScrolls(root, savedScrolls);
  }

  function renderSidebar() {
    const q = S.sidebarSearch.trim().toLowerCase();
    return `
      <aside class="ac-sidebar">
        <div class="ac-sb-tabs">
          <button type="button" class="ac-sb-tab ${S.sidebarTab === "collections" ? "active" : ""}" data-sb-tab="collections">
            ${icon("folder")}<span>${esc(tr("ac_collections", "Collections"))}</span>
            <span class="ac-count">${S.collections.length}</span>
          </button>
          <button type="button" class="ac-sb-tab ${S.sidebarTab === "history" ? "active" : ""}" data-sb-tab="history">
            ${icon("history")}<span>${esc(tr("ac_history", "History"))}</span>
            <span class="ac-count">${S.history.length}</span>
          </button>
        </div>

        <div class="ac-sb-actions">
          <div class="ac-sb-search">
            ${icon("search")}
            <input type="search" id="ac-sb-search" value="${esc(S.sidebarSearch)}" placeholder="${esc(tr("ac_filter_placeholder", "Filter requests…"))}" autocomplete="off">
          </div>
          ${S.sidebarTab === "collections"
            ? `<button type="button" class="btn sm primary icon-btn" id="ac-btn-new-col" title="${esc(tr("ac_new_collection", "New Collection"))}">${icon("plus")}</button>`
            : `<button type="button" class="btn sm ghost icon-btn" id="ac-btn-clear-hist" title="${esc(tr("ac_clear_history", "Clear History"))}">${icon("trash")}</button>`}
        </div>

        ${S.sidebarTab === "collections" ? `
          <div class="ac-layout-bar" role="group" aria-label="${esc(tr("ac_folder_layout", "Folder View"))}">
            <span class="ac-layout-label">${esc(tr("ac_folder_layout", "View:"))}</span>
            <div class="ac-layout-seg">
              <button type="button" class="ac-layout-btn ${S.folderLayout === "nested" ? "active" : ""}" data-folder-layout="nested" title="${esc(tr("ac_layout_nested_tip", "Nested URL path tree (v1 / admin / products)"))}">${esc(tr("ac_layout_nested", "Nested"))}</button>
              <button type="button" class="ac-layout-btn ${S.folderLayout === "flat" ? "active" : ""}" data-folder-layout="flat" title="${esc(tr("ac_layout_flat_tip", "Classic single-level flat folders"))}">${esc(tr("ac_layout_flat", "Flat"))}</button>
              <button type="button" class="ac-layout-btn ${S.folderLayout === "original" ? "active" : ""}" data-folder-layout="original" title="${esc(tr("ac_layout_original_tip", "Saved / custom collection folders"))}">${esc(tr("ac_layout_original", "Saved"))}</button>
            </div>
          </div>
        ` : ""}

        <div class="ac-sb-body">
          ${S.sidebarTab === "collections" ? renderCollectionsTree(q) : renderHistoryList(q)}
        </div>
      </aside>
    `;
  }

  function itemMatchesSearch(item, q) {
    if (!q) return true;
    if (item.type === "folder") {
      if ((item.name || "").toLowerCase().includes(q)) return true;
      return (item.items || []).some((child) => itemMatchesSearch(child, q));
    }
    return (
      (item.name || "").toLowerCase().includes(q) ||
      (item.url || "").toLowerCase().includes(q) ||
      (item.method || "").toLowerCase().includes(q)
    );
  }

  function renderTreeItems(collectionId, items, q, depth = 0) {
    const tab = activeTab();
    return (items || [])
      .filter((it) => itemMatchesSearch(it, q))
      .map((it) => {
        if (it.type === "folder") {
          const isOpen = q ? true : S.expanded.has(it.id);
          const folderCount = countRequests(it.items);
          const isVirtual = Boolean(it._virtual);
          return `
            <div class="ac-tree-folder" style="--depth:${depth}">
              <div class="ac-tree-row ac-folder-row" data-toggle-expand="${esc(it.id)}">
                <span class="ac-caret ${isOpen ? "open" : ""}">▸</span>
                <span class="ac-folder-ic">${icon("folder")}</span>
                <span class="ac-tree-name" title="${esc(it._pathPrefix ? `/${it._pathPrefix}` : it.name)}">${esc(it.name)}</span>
                ${folderCount ? `<span class="ac-folder-badge">${folderCount}</span>` : ""}
                <span class="ac-row-actions">
                  <button type="button" class="ac-mini-btn" data-add-req="${esc(collectionId)}" data-parent="${esc(it.id)}" data-url-prefix="${esc(it._pathPrefix || "")}" title="${esc(tr("ac_add_request", "Add Request"))}">${icon("plus")}</button>
                  ${!isVirtual ? `
                    <button type="button" class="ac-mini-btn" data-rename-folder="${esc(collectionId)}" data-item="${esc(it.id)}" title="${esc(tr("ac_rename", "Rename"))}">${icon("edit")}</button>
                    <button type="button" class="ac-mini-btn danger" data-del-item="${esc(collectionId)}" data-item="${esc(it.id)}" title="${esc(tr("delete", "Delete"))}">${icon("trash")}</button>
                  ` : ""}
                </span>
              </div>
              ${isOpen ? `<div class="ac-tree-children">${renderTreeItems(collectionId, it.items, q, depth + 1)}</div>` : ""}
            </div>
          `;
        }
        const isActive = tab && tab.collectionId === collectionId && tab.request.id === it.id && S.mode === "builder";
        return `
          <div class="ac-tree-row ac-req-row ${isActive ? "active" : ""}" style="--depth:${depth}" data-open-req="${esc(collectionId)}" data-req-id="${esc(it.id)}">
            <span class="ac-m-tag ${methodCls(it.method)}">${esc(it.method.slice(0, 4))}</span>
            <span class="ac-tree-name" title="${esc(it.name)} — ${esc(it.url)}">${esc(it.name)}</span>
            <span class="ac-row-actions">
              <button type="button" class="ac-mini-btn" data-dup-item="${esc(collectionId)}" data-item="${esc(it.id)}" title="${esc(tr("ac_duplicate", "Duplicate"))}">${icon("copy")}</button>
              <button type="button" class="ac-mini-btn danger" data-del-item="${esc(collectionId)}" data-item="${esc(it.id)}" title="${esc(tr("delete", "Delete"))}">${icon("trash")}</button>
            </span>
          </div>
        `;
      })
      .join("");
  }

  function renderCollectionsTree(q) {
    if (!S.collections.length) {
      return `
        <div class="ac-sb-empty">
          <div class="ac-sb-empty-ic">${icon("folder")}</div>
          <p>${esc(tr("ac_no_collections", "No collections yet"))}</p>
          <div class="ac-sb-empty-btns">
            <button type="button" class="btn sm primary" id="ac-empty-new-col">${icon("plus")}${esc(tr("ac_new_collection", "New Collection"))}</button>
            <button type="button" class="btn sm ghost" id="ac-empty-sync">${icon("refresh")}${esc(tr("ac_sync_routes", "Sync Laravel Routes"))}</button>
            <button type="button" class="btn sm ghost" id="ac-empty-import">${icon("upload")}${esc(tr("ac_import_postman", "Import Postman JSON"))}</button>
          </div>
        </div>
      `;
    }

    const filteredCols = S.collections.filter((col) => {
      if (!q) return true;
      if ((col.name || "").toLowerCase().includes(q)) return true;
      return (col.items || []).some((it) => itemMatchesSearch(it, q));
    });

    if (!filteredCols.length) {
      return `<div class="ac-sb-empty"><p>${esc(tr("no_matches", "No matches"))}</p></div>`;
    }

    return filteredCols
      .map((col) => {
        const isOpen = q ? true : S.expanded.has(col.id);
        const total = countRequests(col.items);
        return `
          <div class="ac-col-block">
            <div class="ac-tree-row ac-col-row ${S.mode === "docs" && S.docsCollectionId === col.id ? "active" : ""}" data-toggle-expand="${esc(col.id)}">
              <span class="ac-caret ${isOpen ? "open" : ""}">▸</span>
              <span class="ac-col-name" title="${esc(col.name)}">${esc(col.name)}</span>
              <span class="ac-col-badge">${total}</span>
              <span class="ac-row-actions">
                <button type="button" class="ac-mini-btn" data-add-req="${esc(col.id)}" title="${esc(tr("ac_add_request", "Add Request"))}">${icon("plus")}</button>
                <button type="button" class="ac-mini-btn" data-add-folder="${esc(col.id)}" title="${esc(tr("ac_add_folder", "Add Folder"))}">${icon("folder")}</button>
                <button type="button" class="ac-mini-btn" data-open-docs="${esc(col.id)}" title="${esc(tr("ac_view_docs", "View API Docs"))}">${icon("file")}</button>
                <button type="button" class="ac-mini-btn" data-export-col="${esc(col.id)}" title="${esc(tr("ac_export_postman", "Export Postman v2.1 JSON"))}">${icon("download")}</button>
                <button type="button" class="ac-mini-btn" data-edit-col="${esc(col.id)}" title="${esc(tr("ac_collection_settings", "Collection Settings"))}">${icon("settings")}</button>
                <button type="button" class="ac-mini-btn danger" data-del-col="${esc(col.id)}" title="${esc(tr("delete", "Delete"))}">${icon("trash")}</button>
              </span>
            </div>
            ${isOpen ? `
              <div class="ac-tree-children">
                ${renderTreeItems(col.id, buildDisplayItems(col), q, 1) || `<div class="ac-tree-empty">${esc(tr("ac_empty_col", "Empty collection — click + to add a request"))}</div>`}
              </div>
            ` : ""}
          </div>
        `;
      })
      .join("");
  }

  function renderHistoryList(q) {
    const items = S.history.filter((h) => !q || `${h.method} ${h.url} ${h.name} ${h.status}`.toLowerCase().includes(q));
    if (!items.length) {
      return `<div class="ac-sb-empty"><p>${esc(tr("ac_no_history", "No requests sent yet"))}</p></div>`;
    }
    return items
      .map((h, idx) => `
        <div class="ac-hist-row" data-open-hist="${idx}" title="${esc(h.url)}">
          <div class="ac-hist-top">
            <span class="ac-m-tag ${methodCls(h.method)}">${esc(h.method)}</span>
            <span class="ac-hist-status ${h.ok ? statusCls(h.status) : "s5xx"}">${h.ok ? esc(h.status) : "ERR"}</span>
            <span class="ac-hist-time muted">${esc(h.duration_ms || 0)}ms</span>
          </div>
          <div class="ac-hist-url">${esc(h.raw_url || h.url)}</div>
        </div>
      `)
      .join("");
  }

  // ── Mode 1: Request Builder View ───────────────────────────────────────────

  function renderBuilderView(tab) {
    if (!tab) return `<div class="empty-pane">${esc(tr("ac_no_tab", "Open or create a request"))}</div>`;
    const req = tab.request;
    const col = getCollectionById(tab.collectionId);
    const previewUrl = resolvePreviewUrl(req.url, tab.collectionId);

    const activeParamsCount = (req.params || []).filter((p) => p.enabled !== false && p.key).length + (req.path_variables || []).length;
    const activeHeadersCount = (req.headers || []).filter((h) => h.enabled !== false && h.key).length;
    const testsCount = (req.tests || []).filter((x) => x.enabled !== false).length + (req.extractors || []).filter((x) => x.enabled !== false && x.variable).length;

    return `
      <!-- Open Tabs Strip -->
      <div class="ac-tabs-strip">
        <div class="ac-tabs-scroll">
          ${S.tabs.map((tb) => `
            <div class="ac-req-tab ${tb.tabId === tab.tabId ? "active" : ""}" data-select-tab="${esc(tb.tabId)}">
              <span class="ac-m-tag ${methodCls(tb.request.method)}">${esc(tb.request.method.slice(0, 4))}</span>
              <span class="ac-req-tab-name">${esc(tb.request.name || tr("ac_untitled", "Untitled"))}</span>
              ${tb.dirty ? `<span class="ac-dirty-dot" title="${esc(tr("ac_unsaved", "Unsaved changes"))}"></span>` : ""}
              <button type="button" class="ac-tab-close" data-close-tab="${esc(tb.tabId)}" aria-label="Close tab">×</button>
            </div>
          `).join("")}
        </div>
        <button type="button" class="ac-tab-add" id="ac-btn-new-tab" title="${esc(tr("ac_new_tab", "New Request Tab"))}">${icon("plus")}</button>
      </div>

      <!-- Request Meta & Save Bar -->
      <div class="ac-req-meta">
        <div class="ac-req-meta-left">
          ${col ? `<span class="chip xs muted">${esc(col.name)}</span><span class="muted">/</span>` : `<span class="chip xs warn">${esc(tr("ac_draft", "Draft"))}</span>`}
          <input type="text" id="ac-req-name" class="ac-req-name-input" value="${esc(req.name)}" placeholder="${esc(tr("ac_req_name_placeholder", "Request name"))}">
        </div>
        <div class="ac-req-meta-right">
          <button type="button" class="btn sm ghost" id="ac-btn-code" title="${esc(tr("ac_code_snippets", "Generate Code Snippets"))}">
            ${icon("code")}<span>${esc(tr("ac_code", "Code"))}</span>
          </button>
          <button type="button" class="btn sm ghost" id="ac-btn-save-as" title="${esc(tr("ac_save_as", "Save to Collection…"))}">
            ${icon("folder")}<span>${esc(tr("ac_save_as", "Save As"))}</span>
          </button>
          <button type="button" class="btn sm ${tab.dirty ? "primary" : ""}" id="ac-btn-save" title="${esc(tr("save", "Save"))} (Ctrl+S)">
            ${icon("check")}<span>${esc(tr("save", "Save"))}</span>
          </button>
        </div>
      </div>

      <!-- Method + URL + Send Bar -->
      <div class="ac-url-bar-wrap">
        <div class="ac-url-bar">
          <select id="ac-req-method" class="ac-method-select ${methodCls(req.method)}" aria-label="HTTP Method">
            ${METHODS.map((m) => `<option value="${m}" ${m === req.method ? "selected" : ""}>${m}</option>`).join("")}
          </select>
          <input type="text" id="ac-req-url" class="ac-url-input" value="${esc(req.url)}" placeholder="{{base_url}}/api/v1/users" spellcheck="false" autocomplete="off">
          <button type="button" class="btn primary ac-send-btn" id="ac-btn-send" ${tab.sending ? "disabled" : ""} title="Ctrl+Enter">
            ${tab.sending ? `${icon("loader")}<span>${esc(tr("ac_sending", "Sending…"))}</span>` : `${icon("play")}<span>${esc(tr("ac_send", "Send"))}</span>`}
          </button>
        </div>
        ${previewUrl && previewUrl !== req.url ? `
          <div class="ac-url-preview">
            <span class="muted">${esc(tr("ac_resolved_url", "Resolved:"))}</span>
            <code>${esc(previewUrl)}</code>
          </div>
        ` : ""}
      </div>

      <!-- Split Request Editor + Response Viewer -->
      <div class="ac-split">
        <!-- Request Config Pane -->
        <section class="ac-pane ac-req-pane">
          <div class="ac-subtabs">
            ${[
              ["params", tr("ac_tab_params", "Params"), activeParamsCount],
              ["auth", tr("ac_tab_auth", "Auth"), req.auth?.type && req.auth.type !== "none" && req.auth.type !== "inherit" ? "•" : ""],
              ["headers", tr("ac_tab_headers", "Headers"), activeHeadersCount],
              ["body", tr("ac_tab_body", "Body"), req.body?.mode && req.body.mode !== "none" ? req.body.mode : ""],
              ["tests", tr("ac_tab_tests", "Tests & Vars"), testsCount],
              ["docs", tr("ac_tab_docs", "Docs"), req.description ? "•" : ""],
            ].map(([id, label, badge]) => `
              <button type="button" class="ac-subtab ${tab.reqSubTab === id ? "active" : ""}" data-req-subtab="${id}">
                <span>${esc(label)}</span>
                ${badge ? `<span class="ac-subtab-badge">${esc(badge)}</span>` : ""}
              </button>
            `).join("")}
          </div>
          <div class="ac-pane-body">
            ${renderRequestSubTab(tab)}
          </div>
        </section>

        <!-- Response Viewer Pane -->
        <section class="ac-pane ac-resp-pane">
          ${renderResponsePane(tab)}
        </section>
      </div>
    `;
  }

  function renderKvEditor(tableKind, rows, { withType = false, placeholderKey = "key", placeholderVal = "value" } = {}) {
    return `
      <div class="ac-kv-table">
        <div class="ac-kv-head ${withType ? "with-type" : ""}">
          <span></span>
          <span>${esc(tr("ac_key", "Key"))}</span>
          ${withType ? `<span>${esc(tr("ac_type", "Type"))}</span>` : ""}
          <span>${esc(tr("ac_value", "Value"))}</span>
          <span>${esc(tr("ac_description", "Description"))}</span>
          <span></span>
        </div>
        ${(rows || []).map((row, idx) => `
          <div class="ac-kv-row ${withType ? "with-type" : ""} ${row.enabled === false ? "disabled" : ""}">
            <input type="checkbox" class="ac-kv-chk" data-kv-tbl="${tableKind}" data-kv-idx="${idx}" data-kv-field="enabled" ${row.enabled !== false ? "checked" : ""}>
            <input type="text" class="ac-kv-inp mono" data-kv-tbl="${tableKind}" data-kv-idx="${idx}" data-kv-field="key" value="${esc(row.key || "")}" placeholder="${esc(placeholderKey)}" spellcheck="false">
            ${withType ? `
              <select class="ac-kv-inp" data-kv-tbl="${tableKind}" data-kv-idx="${idx}" data-kv-field="type">
                <option value="text" ${row.type !== "file" ? "selected" : ""}>Text</option>
                <option value="file" ${row.type === "file" ? "selected" : ""}>File</option>
              </select>
            ` : ""}
            ${withType && row.type === "file" ? `
              <div class="ac-file-pick-cell">
                <input type="text" class="ac-kv-inp mono" data-kv-tbl="${tableKind}" data-kv-idx="${idx}" data-kv-field="src" value="${esc(row.src || "")}" placeholder="/path/to/file.png" spellcheck="false">
                <button type="button" class="btn xs ghost" data-kv-browse="${idx}">${esc(tr("ac_browse", "Browse"))}</button>
              </div>
            ` : `
              <input type="text" class="ac-kv-inp mono" data-kv-tbl="${tableKind}" data-kv-idx="${idx}" data-kv-field="value" value="${esc(row.value || "")}" placeholder="${esc(placeholderVal)}" spellcheck="false">
            `}
            <input type="text" class="ac-kv-inp" data-kv-tbl="${tableKind}" data-kv-idx="${idx}" data-kv-field="description" value="${esc(row.description || "")}" placeholder="${esc(tr("ac_desc_opt", "Description (for docs)"))}">
            <button type="button" class="ac-mini-btn danger" data-kv-del="${tableKind}" data-kv-idx="${idx}" title="${esc(tr("delete", "Delete"))}">×</button>
          </div>
        `).join("")}
        <div class="ac-kv-foot">
          <button type="button" class="btn xs ghost" data-kv-add="${tableKind}">${icon("plus")}${esc(tr("ac_add_row", "Add Row"))}</button>
        </div>
      </div>
    `;
  }

  function renderRequestSubTab(tab) {
    const req = tab.request;
    switch (tab.reqSubTab) {
      case "params":
        return `
          <div class="ac-sec-label">${esc(tr("ac_query_params", "Query Parameters"))}</div>
          ${renderKvEditor("params", req.params, { placeholderKey: "page", placeholderVal: "1" })}
          ${(req.path_variables || []).length ? `
            <div class="ac-sec-label" style="margin-top:14px">${esc(tr("ac_path_vars", "Path Variables"))} <span class="muted">({id} / :id)</span></div>
            ${renderKvEditor("path_variables", req.path_variables, { placeholderKey: "id", placeholderVal: "1" })}
          ` : ""}
        `;

      case "auth": {
        const auth = req.auth || { type: "inherit" };
        const atype = auth.type || "inherit";
        const inherited = resolveInheritedAuth(tab.collectionId, req.id);
        return `
          <div class="ac-auth-panel">
            <div class="ac-field-row">
              <label>${esc(tr("ac_auth_type", "Authorization Type"))}</label>
              <select id="ac-auth-type" class="ac-select">
                <option value="inherit" ${atype === "inherit" ? "selected" : ""}>${esc(tr("ac_auth_inherit", "Inherit auth from parent"))} (${esc((inherited?.type || "none").toUpperCase())})</option>
                <option value="none" ${atype === "none" ? "selected" : ""}>${esc(tr("ac_auth_none", "No Auth"))}</option>
                <option value="bearer" ${atype === "bearer" ? "selected" : ""}>Bearer Token</option>
                <option value="basic" ${atype === "basic" ? "selected" : ""}>Basic Auth</option>
                <option value="apikey" ${atype === "apikey" ? "selected" : ""}>API Key</option>
                <option value="sanctum" ${atype === "sanctum" ? "selected" : ""}>Laravel Sanctum (CSRF Cookie + Bearer)</option>
              </select>
            </div>
            ${atype === "bearer" ? `
              <div class="ac-field-row">
                <label>Bearer Token</label>
                <input type="text" class="ac-input mono" data-auth-field="token" value="${esc(auth.token || "")}" placeholder="{{token}} or paste JWT/Sanctum token" spellcheck="false">
              </div>
            ` : ""}
            ${atype === "basic" ? `
              <div class="grid-2col">
                <div class="ac-field-row">
                  <label>${esc(tr("ac_username", "Username"))}</label>
                  <input type="text" class="ac-input mono" data-auth-field="username" value="${esc(auth.username || "")}" spellcheck="false">
                </div>
                <div class="ac-field-row">
                  <label>${esc(tr("ac_password", "Password"))}</label>
                  <input type="password" class="ac-input mono" data-auth-field="password" value="${esc(auth.password || "")}">
                </div>
              </div>
            ` : ""}
            ${atype === "apikey" ? `
              <div class="grid-3">
                <div class="ac-field-row">
                  <label>${esc(tr("ac_key", "Key"))}</label>
                  <input type="text" class="ac-input mono" data-auth-field="key" value="${esc(auth.key || "X-API-Key")}" spellcheck="false">
                </div>
                <div class="ac-field-row">
                  <label>${esc(tr("ac_value", "Value"))}</label>
                  <input type="text" class="ac-input mono" data-auth-field="value" value="${esc(auth.value || "")}" placeholder="{{api_key}}" spellcheck="false">
                </div>
                <div class="ac-field-row">
                  <label>${esc(tr("ac_add_to", "Add to"))}</label>
                  <select class="ac-select" data-auth-field="in">
                    <option value="header" ${auth.in !== "query" ? "selected" : ""}>Header</option>
                    <option value="query" ${auth.in === "query" ? "selected" : ""}>Query Params</option>
                  </select>
                </div>
              </div>
            ` : ""}
            ${atype === "sanctum" ? `
              <div class="ac-hint-box">
                ${icon("shield")}
                <span>${esc(tr("ac_sanctum_hint", "Automatically fetches /sanctum/csrf-cookie, extracts XSRF-TOKEN, attaches X-XSRF-TOKEN & cookies before sending this request."))}</span>
              </div>
              <div class="grid-2col" style="margin-top:10px">
                <div class="ac-field-row">
                  <label>CSRF Cookie Path</label>
                  <input type="text" class="ac-input mono" data-auth-field="csrf_url" value="${esc(auth.csrf_url || "/sanctum/csrf-cookie")}" spellcheck="false">
                </div>
                <div class="ac-field-row">
                  <label>Optional Bearer Token</label>
                  <input type="text" class="ac-input mono" data-auth-field="token" value="${esc(auth.token || "")}" placeholder="{{token}}" spellcheck="false">
                </div>
              </div>
            ` : ""}
          </div>
        `;
      }

      case "headers":
        return `
          <div class="ac-presets-bar">
            <span class="muted">${esc(tr("ac_quick_headers", "Quick add:"))}</span>
            <button type="button" class="chip xs ac-preset-hdr" data-hk="Accept" data-hv="application/json">Accept: application/json</button>
            <button type="button" class="chip xs ac-preset-hdr" data-hk="Content-Type" data-hv="application/json">Content-Type: json</button>
            <button type="button" class="chip xs ac-preset-hdr" data-hk="X-Requested-With" data-hv="XMLHttpRequest">XMLHttpRequest</button>
            <button type="button" class="chip xs ac-preset-hdr" data-hk="Accept-Language" data-hv="ar">Accept-Language: ar</button>
          </div>
          ${renderKvEditor("headers", req.headers, { placeholderKey: "X-Custom-Header", placeholderVal: "value" })}
        `;

      case "body": {
        const body = req.body || { mode: "none", raw: "", raw_type: "json", formdata: [], urlencoded: [], graphql: { query: "", variables: "" } };
        return `
          <div class="ac-body-modes">
            ${[
              ["none", "none"],
              ["raw", "raw"],
              ["formdata", "form-data"],
              ["urlencoded", "x-www-form-urlencoded"],
              ["graphql", "GraphQL"],
            ].map(([m, lbl]) => `
              <label class="ac-radio-pill ${body.mode === m ? "active" : ""}">
                <input type="radio" name="ac-body-mode" value="${m}" ${body.mode === m ? "checked" : ""}>
                <span>${esc(lbl)}</span>
              </label>
            `).join("")}

            ${body.mode === "raw" ? `
              <div class="ac-body-raw-tools">
                <select id="ac-raw-type" class="ac-select sm">
                  ${["json", "text", "xml", "html"].map((rt) => `<option value="${rt}" ${body.raw_type === rt ? "selected" : ""}>${rt.toUpperCase()}</option>`).join("")}
                </select>
                ${body.raw_type === "json" ? `<button type="button" class="btn xs ghost" id="ac-btn-prettify-body">${icon("sparkles")}${esc(tr("ac_prettify", "Beautify"))}</button>` : ""}
              </div>
            ` : ""}
          </div>

          ${body.mode === "none" ? `<div class="ac-empty-small">${esc(tr("ac_body_none", "This request does not have a body."))}</div>` : ""}
          ${body.mode === "raw" ? `<textarea id="ac-body-raw" class="ac-code-area" spellcheck="false" placeholder='{\n  "name": "Ahmed",\n  "email": "{{$randomEmail}}"\n}'>${esc(body.raw || "")}</textarea>` : ""}
          ${body.mode === "formdata" ? renderKvEditor("formdata", body.formdata, { withType: true, placeholderKey: "avatar", placeholderVal: "value" }) : ""}
          ${body.mode === "urlencoded" ? renderKvEditor("urlencoded", body.urlencoded, { placeholderKey: "email", placeholderVal: "user@example.com" }) : ""}
          ${body.mode === "graphql" ? `
            <div class="grid-2col">
              <div>
                <div class="ac-sec-label">GraphQL Query</div>
                <textarea id="ac-gql-query" class="ac-code-area" spellcheck="false" placeholder="query { users { id name } }">${esc(body.graphql?.query || "")}</textarea>
              </div>
              <div>
                <div class="ac-sec-label">Variables (JSON)</div>
                <textarea id="ac-gql-vars" class="ac-code-area" spellcheck="false" placeholder='{"limit": 10}'>${esc(body.graphql?.variables || "")}</textarea>
              </div>
            </div>
          ` : ""}
        `;
      }

      case "tests":
        return `
          <div class="ac-sec-label">${esc(tr("ac_assertions", "Response Assertions (Tests)"))}</div>
          <div class="ac-rules-list">
            ${(req.tests || []).map((rule, idx) => `
              <div class="ac-rule-row">
                <input type="checkbox" data-test-idx="${idx}" data-test-field="enabled" ${rule.enabled !== false ? "checked" : ""}>
                <select class="ac-kv-inp" data-test-idx="${idx}" data-test-field="type">
                  <option value="status_equals" ${rule.type === "status_equals" ? "selected" : ""}>Status equals</option>
                  <option value="status_2xx" ${rule.type === "status_2xx" ? "selected" : ""}>Status is 2xx</option>
                  <option value="response_time_lt" ${rule.type === "response_time_lt" ? "selected" : ""}>Response time &lt; (ms)</option>
                  <option value="json_path_exists" ${rule.type === "json_path_exists" ? "selected" : ""}>JSON path exists</option>
                  <option value="json_path_equals" ${rule.type === "json_path_equals" ? "selected" : ""}>JSON path equals</option>
                  <option value="body_contains" ${rule.type === "body_contains" ? "selected" : ""}>Body contains</option>
                  <option value="header_exists" ${rule.type === "header_exists" ? "selected" : ""}>Header exists</option>
                </select>
                <input type="text" class="ac-kv-inp mono" data-test-idx="${idx}" data-test-field="target" value="${esc(rule.target || "")}" placeholder="${rule.type.startsWith("json") ? "data.user.id" : rule.type === "header_exists" ? "Content-Type" : "(unused)"}" ${["status_equals", "status_2xx", "response_time_lt", "body_contains"].includes(rule.type) ? "disabled" : ""}>
                <input type="text" class="ac-kv-inp mono" data-test-idx="${idx}" data-test-field="value" value="${esc(rule.value || "")}" placeholder="${rule.type === "status_equals" ? "200" : rule.type === "response_time_lt" ? "500" : "expected"}" ${["status_2xx", "json_path_exists", "header_exists"].includes(rule.type) ? "disabled" : ""}>
                <button type="button" class="ac-mini-btn danger" data-del-test="${idx}">×</button>
              </div>
            `).join("")}
            <button type="button" class="btn xs ghost" id="ac-btn-add-test">${icon("plus")}${esc(tr("ac_add_assertion", "Add Assertion"))}</button>
          </div>

          <div class="ac-sec-label" style="margin-top:16px">${esc(tr("ac_extractors", "Auto-Capture Environment Variables"))} <span class="muted">(${esc(tr("ac_extractors_hint", "e.g. save login token into {{token}}"))})</span></div>
          <div class="ac-rules-list">
            ${(req.extractors || []).map((ext, idx) => `
              <div class="ac-rule-row">
                <input type="checkbox" data-ext-idx="${idx}" data-ext-field="enabled" ${ext.enabled !== false ? "checked" : ""}>
                <select class="ac-kv-inp" data-ext-idx="${idx}" data-ext-field="source">
                  <option value="json" ${ext.source === "json" ? "selected" : ""}>JSON Path</option>
                  <option value="header" ${ext.source === "header" ? "selected" : ""}>Response Header</option>
                  <option value="cookie" ${ext.source === "cookie" ? "selected" : ""}>Response Cookie</option>
                </select>
                <input type="text" class="ac-kv-inp mono" data-ext-idx="${idx}" data-ext-field="path" value="${esc(ext.path || "")}" placeholder="data.token">
                <input type="text" class="ac-kv-inp mono" data-ext-idx="${idx}" data-ext-field="variable" value="${esc(ext.variable || "")}" placeholder="token">
                <button type="button" class="ac-mini-btn danger" data-del-ext="${idx}">×</button>
              </div>
            `).join("")}
            <button type="button" class="btn xs ghost" id="ac-btn-add-ext">${icon("plus")}${esc(tr("ac_add_extractor", "Add Variable Capture"))}</button>
          </div>
        `;

      case "docs":
        return `
          <div class="ac-sec-label">${esc(tr("ac_endpoint_docs", "Endpoint Documentation (Markdown)"))}</div>
          <p class="muted sm" style="margin:0 0 8px">${esc(tr("ac_endpoint_docs_hint", "This description appears in the Live API Documentation, Postman v2.1 exports, HTML/Markdown docs, and OpenAPI 3.0 specs."))}</p>
          <textarea id="ac-req-desc" class="ac-code-area" style="min-height:140px;font-family:inherit" placeholder="Describe what this endpoint does, required permissions, and edge cases…">${esc(req.description || "")}</textarea>
        `;
    }
    return "";
  }

  function renderResponsePane(tab) {
    const resp = tab.response;
    const req = tab.request;
    const exCount = (req.examples || []).length;

    if (tab.sending) {
      return `<div class="ac-resp-empty">${icon("loader")}<span>${esc(tr("ac_sending_req", "Sending HTTP request…"))}</span></div>`;
    }

    if (!resp) {
      return `
        <div class="ac-resp-head">
          <span class="ac-resp-title">${esc(tr("ac_response", "Response"))}</span>
          <div class="ac-resp-opts">
            <label class="ac-inline-opt"><input type="checkbox" id="ac-opt-redirects" ${tab.options.follow_redirects !== false ? "checked" : ""}> ${esc(tr("ac_follow_redirects", "Follow redirects"))}</label>
            ${exCount ? `<button type="button" class="btn xs ghost" data-resp-subtab="examples">${icon("file")} ${exCount} ${esc(tr("ac_examples", "Examples"))}</button>` : ""}
          </div>
        </div>
        ${tab.respSubTab === "examples" && exCount
          ? `<div class="ac-pane-body">${renderExamplesList(tab)}</div>`
          : `<div class="ac-resp-empty">${icon("zap")}<span>${esc(tr("ac_send_prompt", "Click Send or press Ctrl+Enter to test this endpoint"))}</span></div>`}
      `;
    }

    if (!resp.ok) {
      return `
        <div class="ac-resp-head">
          <div class="ac-resp-stats">
            <span class="perf-status-badge s5xx">ERROR</span>
            <span class="chip xs mono">${esc(resp.duration_ms || 0)} ms</span>
          </div>
        </div>
        <div class="ac-pane-body">
          <div class="card error-pane">${icon("alert")} <b>${esc(tr("ac_request_failed", "Request failed"))}:</b> ${esc(resp.error || "Unknown error")}</div>
        </div>
      `;
    }

    const testResults = resp.test_results || [];
    const passedCount = testResults.filter((r) => r.passed).length;
    const hdrEntries = Object.entries(resp.headers || {});
    const cookies = resp.cookies || [];

    return `
      <div class="ac-resp-head">
        <div class="ac-resp-stats">
          <span class="perf-status-badge ${statusCls(resp.status)}">${esc(resp.status)} ${esc(resp.status_text || "")}</span>
          <span class="chip xs mono" title="Duration">${esc(resp.duration_ms)} ms</span>
          <span class="chip xs mono" title="Size">${esc(fmtBytes(resp.size_bytes))}</span>
        </div>
        <div class="ac-resp-actions">
          <button type="button" class="btn xs ghost" id="ac-btn-save-example" title="${esc(tr("ac_save_example_tip", "Save this response as a documentation example"))}">
            ${icon("sparkles")}<span>${esc(tr("ac_save_example", "Save as Example"))}</span>
          </button>
          <button type="button" class="btn xs ghost" id="ac-btn-copy-resp" title="${esc(tr("copy", "Copy"))}">
            ${icon("copy")}<span>${esc(tr("copy", "Copy"))}</span>
          </button>
        </div>
      </div>

      <div class="ac-subtabs">
        ${[
          ["body", tr("ac_tab_body", "Body"), ""],
          ["headers", tr("ac_tab_headers", "Headers"), hdrEntries.length || ""],
          ["cookies", tr("ac_cookies", "Cookies"), cookies.length || ""],
          ["tests", tr("ac_test_results", "Test Results"), testResults.length ? `${passedCount}/${testResults.length}` : ""],
          ["examples", tr("ac_examples", "Examples"), exCount || ""],
        ].map(([id, label, badge]) => `
          <button type="button" class="ac-subtab ${tab.respSubTab === id ? "active" : ""}" data-resp-subtab="${id}">
            <span>${esc(label)}</span>
            ${badge !== "" ? `<span class="ac-subtab-badge ${id === "tests" && testResults.length ? (passedCount === testResults.length ? "ok" : "bad") : ""}">${esc(badge)}</span>` : ""}
          </button>
        `).join("")}

        ${tab.respSubTab === "body" ? `
          <div class="ac-resp-body-controls">
            <div class="ac-seg">
              ${["pretty", "raw", "preview"].map((m) => `<button type="button" class="ac-seg-btn ${tab.bodyViewMode === m ? "active" : ""}" data-body-view="${m}">${esc(m)}</button>`).join("")}
            </div>
          </div>
        ` : ""}
      </div>

      <div class="ac-pane-body ac-resp-body">
        ${renderResponseSubTab(tab, resp)}
      </div>
    `;
  }

  function renderResponseSubTab(tab, resp) {
    if (tab.respSubTab === "body") {
      if (tab.bodyViewMode === "preview") {
        return `<iframe class="ac-html-preview" sandbox="" srcdoc="${esc(resp.text || "")}"></iframe>`;
      }
      if (tab.bodyViewMode === "pretty" && resp.is_json) {
        return `<pre class="ac-json-pre">${highlightJson(resp.json)}</pre>`;
      }
      return `<pre class="ac-json-pre">${esc(resp.text || "(empty response body)")}</pre>`;
    }

    if (tab.respSubTab === "headers") {
      const entries = Object.entries(resp.headers || {});
      if (!entries.length) return `<div class="ac-empty-small">No headers</div>`;
      return `
        <table class="ac-simple-table">
          <thead><tr><th>Header</th><th>Value</th></tr></thead>
          <tbody>
            ${entries.map(([k, v]) => `<tr><td class="mono"><b>${esc(k)}</b></td><td class="mono ac-break">${esc(v)}</td></tr>`).join("")}
          </tbody>
        </table>
      `;
    }

    if (tab.respSubTab === "cookies") {
      const cookies = resp.cookies || [];
      if (!cookies.length) return `<div class="ac-empty-small">${esc(tr("ac_no_cookies", "No cookies received"))}</div>`;
      return `
        <table class="ac-simple-table">
          <thead><tr><th>Name</th><th>Value</th><th>Path</th><th>HttpOnly</th><th>Secure</th><th>SameSite</th></tr></thead>
          <tbody>
            ${cookies.map((c) => `
              <tr>
                <td class="mono"><b>${esc(c.name)}</b></td>
                <td class="mono ac-break">${esc(c.value)}</td>
                <td class="mono">${esc(c.path)}</td>
                <td>${c.http_only ? "✓" : ""}</td>
                <td>${c.secure ? "✓" : ""}</td>
                <td>${esc(c.same_site || "")}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `;
    }

    if (tab.respSubTab === "tests") {
      const results = resp.test_results || [];
      const extracted = Object.entries(resp.extracted_vars || {});
      return `
        ${results.length ? `
          <div class="ac-test-results">
            ${results.map((r) => `
              <div class="ac-test-row ${r.passed ? "pass" : "fail"}">
                <span class="chip xs ${r.passed ? "ok" : "danger"}">${r.passed ? "PASS" : "FAIL"}</span>
                <b>${esc(r.name)}</b>
                <span class="muted mono sm">actual: ${esc(r.actual)}</span>
              </div>
            `).join("")}
          </div>
        ` : `<div class="ac-empty-small">${esc(tr("ac_no_tests_run", "No assertions configured for this request. Add assertions in the Tests & Vars tab."))}</div>`}
        ${extracted.length ? `
          <div class="ac-sec-label" style="margin-top:14px">${esc(tr("ac_extracted_log", "Captured Variables"))}</div>
          <table class="ac-simple-table">
            <thead><tr><th>Variable</th><th>Captured Value</th></tr></thead>
            <tbody>
              ${extracted.map(([k, v]) => `<tr><td class="mono"><code>{{${esc(k)}}}</code></td><td class="mono ac-break">${esc(v)}</td></tr>`).join("")}
            </tbody>
          </table>
        ` : ""}
      `;
    }

    if (tab.respSubTab === "examples") {
      return renderExamplesList(tab);
    }
    return "";
  }

  function renderExamplesList(tab) {
    const examples = tab.request.examples || [];
    if (!examples.length) {
      return `<div class="ac-empty-small">${esc(tr("ac_no_examples", "No saved examples yet. Send a request and click 'Save as Example' to include it in API Docs & Postman exports."))}</div>`;
    }
    return `
      <div class="ac-examples-list">
        ${examples.map((ex, idx) => `
          <div class="ac-example-card">
            <div class="ac-example-head">
              <div>
                <span class="perf-status-badge ${statusCls(ex.status)}">${esc(ex.status)} ${esc(ex.status_text || "")}</span>
                <b>${esc(ex.name)}</b>
              </div>
              <div style="display:flex;gap:4px">
                <button type="button" class="btn xs ghost" data-copy-ex="${idx}">${icon("copy")}</button>
                <button type="button" class="btn xs ghost danger" data-del-ex="${idx}">${icon("trash")}</button>
              </div>
            </div>
            <pre class="ac-json-pre sm">${ex.body && ex.body.trim().startsWith("{") ? (() => { try { return highlightJson(JSON.parse(ex.body)); } catch { return esc(ex.body); } })() : esc(ex.body || "(empty)")}</pre>
          </div>
        `).join("")}
      </div>
    `;
  }

  // ── Mode 2: Interactive API Documentation Studio ───────────────────────────

  function renderDocsView() {
    const col = getCollectionById(S.docsCollectionId) || S.collections[0] || null;
    if (!col) {
      return `
        <div class="ac-docs-empty">
          <div class="ac-sb-empty-ic">${icon("file")}</div>
          <h3>${esc(tr("ac_docs_empty_title", "No Collection to Document"))}</h3>
          <p class="muted">${esc(tr("ac_docs_empty_desc", "Create a collection, import a Postman JSON file, or sync routes from a Laravel site to generate interactive API Documentation."))}</p>
          <div style="display:flex;gap:8px;justify-content:center;margin-top:12px">
            <button type="button" class="btn primary" id="ac-docs-new-col">${icon("plus")}${esc(tr("ac_new_collection", "New Collection"))}</button>
            <button type="button" class="btn" id="ac-docs-sync">${icon("refresh")}${esc(tr("ac_sync_routes", "Sync Laravel Routes"))}</button>
          </div>
        </div>
      `;
    }

    const q = S.docsSearch.trim().toLowerCase();
    const endpoints = flattenEndpoints(buildDisplayItems(col), "General", col.auth || { type: "none" });
    const filtered = endpoints.filter((ep) => !q || `${ep.folder} ${ep.request.method} ${ep.request.name} ${ep.request.url} ${ep.request.description}`.toLowerCase().includes(q));
    const vars = getMergedVars(col.id);

    // Group filtered endpoints by folder
    const groups = new Map();
    for (const ep of filtered) {
      if (!groups.has(ep.folder)) groups.set(ep.folder, []);
      groups.get(ep.folder).push(ep);
    }

    return `
      <div class="ac-docs-studio">
        <div class="ac-docs-toolbar">
          <div class="ac-docs-toolbar-left">
            <select id="ac-docs-col-select" class="ac-select">
              ${S.collections.map((c) => `<option value="${esc(c.id)}" ${c.id === col.id ? "selected" : ""}>${esc(c.name)} (${countRequests(c.items)})</option>`).join("")}
            </select>
            <div class="ac-sb-search" style="width:220px">
              ${icon("search")}
              <input type="search" id="ac-docs-search" value="${esc(S.docsSearch)}" placeholder="${esc(tr("ac_filter_endpoints", "Filter endpoints…"))}">
            </div>
            <button type="button" class="btn sm ghost" data-edit-col="${esc(col.id)}">${icon("edit")}<span>${esc(tr("ac_edit_intro", "Edit Info"))}</span></button>
          </div>
          <div class="ac-docs-toolbar-right">
            <button type="button" class="btn sm primary" data-export-doc="${esc(col.id)}" data-doc-fmt="html">${icon("download")}<span>HTML Docs</span></button>
            <button type="button" class="btn sm" data-export-doc="${esc(col.id)}" data-doc-fmt="markdown">${icon("file")}<span>Markdown</span></button>
            <button type="button" class="btn sm" data-export-doc="${esc(col.id)}" data-doc-fmt="openapi">${icon("code")}<span>OpenAPI 3.0</span></button>
            <button type="button" class="btn sm ghost" data-export-doc="${esc(col.id)}" data-doc-fmt="postman_v21">${icon("share")}<span>Postman v2.1</span></button>
          </div>
        </div>

        <div class="ac-docs-body">
          <div class="ac-docs-hero card">
            <div class="flex-between-wrap">
              <div>
                <h2 style="margin:0 0 6px">${esc(col.name)}</h2>
                <p class="muted" style="margin:0;white-space:pre-line">${esc(col.description || tr("ac_docs_default_desc", "Add descriptions to your collection, requests, parameters, and save response examples to enrich this documentation."))}</p>
              </div>
              <div class="flex-row-sm">
                <span class="chip sm">${endpoints.length} ${esc(tr("ac_endpoints", "Endpoints"))}</span>
                ${col.auth?.type && col.auth.type !== "none" ? `<span class="chip sm accent">Auth: ${esc(col.auth.type.toUpperCase())}</span>` : ""}
              </div>
            </div>
            ${(col.variables || []).length ? `
              <div style="margin-top:12px">
                <div class="ac-sec-label">${esc(tr("ac_collection_vars", "Collection Variables"))}</div>
                <table class="ac-simple-table">
                  <thead><tr><th>Variable</th><th>Default</th><th>Description</th></tr></thead>
                  <tbody>
                    ${col.variables.filter((v) => v.key).map((v) => `
                      <tr>
                        <td class="mono"><code>{{${esc(v.key)}}}</code></td>
                        <td class="mono">${esc(v.value)}</td>
                        <td class="muted">${esc(v.description || "")}</td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              </div>
            ` : ""}
          </div>

          ${Array.from(groups.entries()).map(([folder, eps]) => `
            <div class="ac-docs-group">
              <h3 class="ac-docs-folder-h">${icon("folder")} ${esc(folder)}</h3>
              ${eps.map((ep) => renderDocEndpointCard(col.id, ep, vars)).join("")}
            </div>
          `).join("") || `<div class="card empty-pane">${esc(tr("ac_no_endpoints", "No endpoints in this collection yet."))}</div>`}
        </div>
      </div>
    `;
  }

  function buildQuickCurlPreview(req, vars, auth) {
    let url = (req.url || "").replace(/\{\{\s*([^{}\s]+)\s*\}\}/g, (m, k) => (k in vars ? vars[k] : m));
    const enabledQ = (req.params || []).filter((p) => p.enabled !== false && p.key);
    if (enabledQ.length && !url.includes("?")) {
      url += "?" + enabledQ.map((p) => `${encodeURIComponent(p.key)}=${encodeURIComponent(p.value || "")}`).join("&");
    }
    const parts = [`curl -X ${req.method} '${url}'`];
    for (const h of req.headers || []) {
      if (h.enabled !== false && h.key) parts.push(`-H '${h.key}: ${h.value || ""}'`);
    }
    if (auth?.type === "bearer") parts.push(`-H 'Authorization: Bearer ${auth.token || "<token>"}'`);
    if (auth?.type === "apikey" && auth.in !== "query") parts.push(`-H '${auth.key || "X-API-Key"}: ${auth.value || "<key>"}'`);
    if (req.body?.mode === "raw" && req.body.raw && !["GET", "HEAD"].includes(req.method)) {
      parts.push(`--data-raw '${req.body.raw.replace(/'/g, "'\\''")}'`);
    }
    return parts.join(" \\\n  ");
  }

  function renderDocEndpointCard(collectionId, ep, vars) {
    const r = ep.request;
    const activeParams = (r.params || []).filter((p) => p.enabled !== false && p.key);
    const activeHeaders = (r.headers || []).filter((h) => h.enabled !== false && h.key);
    const curlStr = buildQuickCurlPreview(r, vars, ep.effectiveAuth);

    return `
      <article class="ac-doc-card card">
        <div class="ac-doc-grid">
          <div class="ac-doc-spec">
            <div class="flex-between-wrap mb-sm">
              <div class="flex-row-sm">
                <span class="ac-m-tag lg ${methodCls(r.method)}">${esc(r.method)}</span>
                <h4 style="margin:0">${esc(r.name)}</h4>
              </div>
              <button type="button" class="btn xs ghost" data-try-doc-req="${esc(collectionId)}" data-req-id="${esc(r.id)}">
                ${icon("play")}<span>${esc(tr("ac_try_it", "Try in Builder"))}</span>
              </button>
            </div>
            <div class="ac-doc-url">
              <code>${esc(r.url)}</code>
              <button type="button" class="ac-mini-btn" data-copy-text="${esc(r.url)}" title="${esc(tr("copy", "Copy"))}">${icon("copy")}</button>
            </div>
            ${r.description ? `<p class="ac-doc-desc">${esc(r.description)}</p>` : ""}
            ${ep.effectiveAuth?.type && ep.effectiveAuth.type !== "none" ? `<div class="mb-sm"><span class="chip xs accent">Auth: ${esc(ep.effectiveAuth.type.toUpperCase())}</span></div>` : ""}

            ${(r.path_variables || []).length ? `
              <div class="ac-sec-label">${esc(tr("ac_path_vars", "Path Variables"))}</div>
              <table class="ac-simple-table">
                <thead><tr><th>Param</th><th>Example</th><th>Description</th></tr></thead>
                <tbody>${r.path_variables.map((p) => `<tr><td class="mono"><code>${esc(p.key)}</code></td><td class="mono">${esc(p.value)}</td><td class="muted">${esc(p.description || "")}</td></tr>`).join("")}</tbody>
              </table>
            ` : ""}

            ${activeParams.length ? `
              <div class="ac-sec-label">${esc(tr("ac_query_params", "Query Parameters"))}</div>
              <table class="ac-simple-table">
                <thead><tr><th>Param</th><th>Example</th><th>Description</th></tr></thead>
                <tbody>${activeParams.map((p) => `<tr><td class="mono"><code>${esc(p.key)}</code></td><td class="mono">${esc(p.value)}</td><td class="muted">${esc(p.description || "")}</td></tr>`).join("")}</tbody>
              </table>
            ` : ""}

            ${activeHeaders.length ? `
              <div class="ac-sec-label">${esc(tr("ac_tab_headers", "Headers"))}</div>
              <table class="ac-simple-table">
                <thead><tr><th>Header</th><th>Value</th><th>Description</th></tr></thead>
                <tbody>${activeHeaders.map((h) => `<tr><td class="mono"><code>${esc(h.key)}</code></td><td class="mono">${esc(h.value)}</td><td class="muted">${esc(h.description || "")}</td></tr>`).join("")}</tbody>
              </table>
            ` : ""}

            ${r.body?.mode === "raw" && r.body.raw ? `
              <div class="ac-sec-label">${esc(tr("ac_request_body", "Request Body"))} (${esc(r.body.raw_type || "json")})</div>
              <pre class="ac-json-pre sm">${r.body.raw_type === "json" ? (() => { try { return highlightJson(JSON.parse(r.body.raw)); } catch { return esc(r.body.raw); } })() : esc(r.body.raw)}</pre>
            ` : ""}
          </div>

          <div class="ac-doc-samples">
            <div class="ac-doc-codebox">
              <div class="ac-doc-codehead">
                <span>cURL Example</span>
                <button type="button" class="btn xs ghost" data-copy-text="${esc(curlStr)}">${icon("copy")} Copy</button>
              </div>
              <pre class="ac-json-pre sm">${esc(curlStr)}</pre>
            </div>

            ${(r.examples || []).length ? r.examples.map((ex) => `
              <div class="ac-doc-codebox">
                <div class="ac-doc-codehead">
                  <span><span class="perf-status-badge ${statusCls(ex.status)}">${esc(ex.status)}</span> ${esc(ex.name)}</span>
                  <button type="button" class="btn xs ghost" data-copy-text="${esc(ex.body || "")}">${icon("copy")} Copy</button>
                </div>
                <pre class="ac-json-pre sm">${ex.body && ex.body.trim().startsWith("{") ? (() => { try { return highlightJson(JSON.parse(ex.body)); } catch { return esc(ex.body); } })() : esc(ex.body || "(empty)")}</pre>
              </div>
            `).join("") : `
              <div class="ac-doc-noex muted sm">${esc(tr("ac_no_saved_examples_doc", "No saved response examples yet. Run this endpoint in API Builder and click 'Save as Example'."))}</div>
            `}
          </div>
        </div>
      </article>
    `;
  }

  // ── Modal Renderer ─────────────────────────────────────────────────────────

  function renderModal() {
    const m = S.modal;
    if (!m) return "";
    let title = "";
    let bodyHtml = "";
    let footHtml = "";
    let wide = false;

    if (m.kind === "import") {
      title = tr("ac_import_title", "Import Collection, Environment, OpenAPI or cURL");
      bodyHtml = `
        <p class="muted sm" style="margin:0 0 12px">${esc(tr("ac_import_desc", "Upload a .postman_collection.json (v2.0/v2.1), .postman_environment.json, OpenAPI 3.0 JSON file — or paste raw JSON / cURL command below."))}</p>
        <div class="ac-import-file-row">
          <input type="file" id="ac-import-file-input" accept=".json,.txt" style="display:none">
          <button type="button" class="btn sm" id="ac-btn-pick-import-file">${icon("upload")} ${esc(tr("ac_choose_file", "Choose JSON File…"))}</button>
          <span class="muted sm" id="ac-import-filename"></span>
        </div>
        <textarea id="ac-import-textarea" class="ac-code-area" style="min-height:220px;margin-top:10px" placeholder='Paste Postman Collection v2.1 JSON, OpenAPI 3.0 JSON, or:\ncurl -X POST https://api.example.com/login -H "Content-Type: application/json" -d '\''{"email":"a@b.com"}'\''' spellcheck="false">${esc(m.text || "")}</textarea>
      `;
      footHtml = `
        <button type="button" class="btn ghost" data-close-modal>${esc(tr("cancel", "Cancel"))}</button>
        <button type="button" class="btn primary" id="ac-btn-do-import">${icon("upload")} ${esc(tr("ac_import_now", "Import"))}</button>
      `;
    } else if (m.kind === "sync_routes") {
      title = tr("ac_sync_routes", "Sync Laravel Routes");
      const laravelSites = (state.sites || []).filter((s) => s.linked && s.type === "laravel");
      bodyHtml = laravelSites.length ? `
        <p class="muted sm" style="margin:0 0 12px">${esc(tr("ac_sync_routes_desc", "Automatically scan a Laravel project's routes and build a Postman collection grouped by prefix with path variables and a local environment."))}</p>
        <div class="ac-field-row">
          <label>${esc(tr("ac_select_site", "Laravel Project"))}</label>
          <select id="ac-sync-site" class="ac-select">
            ${laravelSites.map((s) => `<option value="${esc(s.name)}" ${s.name === m.siteName ? "selected" : ""}>${esc(s.name)} (${esc(s.url || s.domain)})</option>`).join("")}
          </select>
        </div>
        <div class="ac-field-row">
          <label>${esc(tr("ac_sync_folder_mode", "Folder Structure"))}</label>
          <select id="ac-sync-folder-mode" class="ac-select">
            <option value="nested" ${m.folderMode !== "flat" ? "selected" : ""}>${esc(tr("ac_sync_folder_nested", "Nested Path Tree (v1 → admin → products)"))}</option>
            <option value="flat" ${m.folderMode === "flat" ? "selected" : ""}>${esc(tr("ac_sync_folder_flat", "Flat Folders (Classic: Admin, Products…)"))}</option>
          </select>
        </div>
        <label class="ac-check-line"><input type="checkbox" id="ac-sync-api-only" ${m.apiOnly ? "checked" : ""}> <span>${esc(tr("ac_sync_api_only", "API routes only (/api/* and api middleware)"))}</span></label>
        <label class="ac-check-line"><input type="checkbox" id="ac-sync-replace" ${m.replaceExisting ? "checked" : ""}> <span>${esc(tr("ac_sync_replace", "Update existing collection for this site if present"))}</span></label>
      ` : `<div class="empty-pane">${esc(tr("ac_no_laravel_sites", "No linked Laravel sites found."))}</div>`;
      footHtml = `
        <button type="button" class="btn ghost" data-close-modal>${esc(tr("cancel", "Cancel"))}</button>
        ${laravelSites.length ? `<button type="button" class="btn primary" id="ac-btn-do-sync">${icon("refresh")} ${esc(tr("ac_generate_collection", "Generate Collection"))}</button>` : ""}
      `;
    } else if (m.kind === "environments") {
      wide = true;
      title = tr("ac_manage_envs", "Environments & Variables");
      const current = S.environments.find((e) => e.id === m.editEnvId) || S.environments[0] || null;
      bodyHtml = `
        <div class="ac-env-modal-grid">
          <div class="ac-env-modal-list">
            <button type="button" class="btn sm primary" id="ac-env-add" style="width:100%;margin-bottom:8px">${icon("plus")} ${esc(tr("ac_new_env", "New Environment"))}</button>
            ${S.environments.map((e) => `
              <div class="ac-env-list-item ${current && e.id === current.id ? "active" : ""}" data-select-edit-env="${esc(e.id)}">
                <span>${esc(e.name)}</span>
                <span class="chip xs muted">${(e.variables || []).length}</span>
              </div>
            `).join("")}
          </div>
          <div class="ac-env-modal-editor">
            ${current ? `
              <div class="flex-between-wrap mb-sm">
                <input type="text" id="ac-env-name-inp" class="ac-input" style="max-width:260px" value="${esc(current.name)}">
                <div class="flex-row-sm">
                  <button type="button" class="btn xs ghost" id="ac-env-export-btn">${icon("download")} Postman Env JSON</button>
                  <button type="button" class="btn xs ghost danger" id="ac-env-del-btn">${icon("trash")} ${esc(tr("delete", "Delete"))}</button>
                </div>
              </div>
              <div class="ac-kv-table">
                <div class="ac-kv-head with-type">
                  <span></span><span>Variable</span><span>Secret</span><span>Value</span><span>Description</span><span></span>
                </div>
                ${(current.variables || []).map((v, idx) => `
                  <div class="ac-kv-row with-type">
                    <input type="checkbox" data-ev-idx="${idx}" data-ev-field="enabled" ${v.enabled !== false ? "checked" : ""}>
                    <input type="text" class="ac-kv-inp mono" data-ev-idx="${idx}" data-ev-field="key" value="${esc(v.key || "")}" placeholder="base_url">
                    <label style="display:flex;align-items:center;justify-content:center"><input type="checkbox" data-ev-idx="${idx}" data-ev-field="secret" ${v.secret ? "checked" : ""}></label>
                    <input type="${v.secret ? "password" : "text"}" class="ac-kv-inp mono" data-ev-idx="${idx}" data-ev-field="value" value="${esc(v.value || "")}" placeholder="http://app.test">
                    <input type="text" class="ac-kv-inp" data-ev-idx="${idx}" data-ev-field="description" value="${esc(v.description || "")}">
                    <button type="button" class="ac-mini-btn danger" data-ev-del="${idx}">×</button>
                  </div>
                `).join("")}
                <div class="ac-kv-foot">
                  <button type="button" class="btn xs ghost" id="ac-env-var-add">${icon("plus")} ${esc(tr("ac_add_var", "Add Variable"))}</button>
                </div>
              </div>
            ` : `<div class="empty-pane">Create an environment to store reusable {{variables}}.</div>`}
          </div>
        </div>
      `;
      footHtml = `
        <button type="button" class="btn primary" id="ac-env-save-close">${icon("check")} ${esc(tr("save", "Save"))}</button>
      `;
    } else if (m.kind === "collection_settings") {
      wide = true;
      const col = m.collection;
      const cauth = col.auth || { type: "none" };
      title = `${tr("ac_collection_settings", "Collection Settings")} — ${col.name}`;
      bodyHtml = `
        <div class="ac-field-row">
          <label>${esc(tr("ac_col_name", "Collection Name"))}</label>
          <input type="text" id="ac-cs-name" class="ac-input" value="${esc(col.name)}">
        </div>
        <div class="ac-field-row">
          <label>${esc(tr("ac_col_desc", "Documentation Overview (Markdown)"))}</label>
          <textarea id="ac-cs-desc" class="ac-code-area" style="min-height:90px;font-family:inherit">${esc(col.description || "")}</textarea>
        </div>
        <div class="ac-field-row">
          <label>${esc(tr("ac_col_auth", "Default Collection Auth (Inherited by requests)"))}</label>
          <select id="ac-cs-auth-type" class="ac-select">
            <option value="none" ${cauth.type === "none" ? "selected" : ""}>No Auth</option>
            <option value="bearer" ${cauth.type === "bearer" ? "selected" : ""}>Bearer Token</option>
            <option value="basic" ${cauth.type === "basic" ? "selected" : ""}>Basic Auth</option>
            <option value="apikey" ${cauth.type === "apikey" ? "selected" : ""}>API Key</option>
            <option value="sanctum" ${cauth.type === "sanctum" ? "selected" : ""}>Laravel Sanctum</option>
          </select>
        </div>
        ${cauth.type === "bearer" ? `<div class="ac-field-row"><label>Token</label><input type="text" class="ac-input mono" data-cs-auth="token" value="${esc(cauth.token || "")}" placeholder="{{token}}"></div>` : ""}
        ${cauth.type === "basic" ? `<div class="grid-2col"><div class="ac-field-row"><label>Username</label><input type="text" class="ac-input mono" data-cs-auth="username" value="${esc(cauth.username || "")}"></div><div class="ac-field-row"><label>Password</label><input type="password" class="ac-input mono" data-cs-auth="password" value="${esc(cauth.password || "")}"></div></div>` : ""}
        ${cauth.type === "apikey" ? `<div class="grid-2col"><div class="ac-field-row"><label>Header Key</label><input type="text" class="ac-input mono" data-cs-auth="key" value="${esc(cauth.key || "X-API-Key")}"></div><div class="ac-field-row"><label>Value</label><input type="text" class="ac-input mono" data-cs-auth="value" value="${esc(cauth.value || "")}"></div></div>` : ""}
        <div class="ac-sec-label" style="margin-top:12px">${esc(tr("ac_collection_vars", "Collection Variables"))}</div>
        <div class="ac-kv-table">
          <div class="ac-kv-head"><span></span><span>Key</span><span>Value</span><span>Description</span><span></span></div>
          ${(col.variables || []).map((v, idx) => `
            <div class="ac-kv-row">
              <input type="checkbox" data-csv-idx="${idx}" data-csv-field="enabled" ${v.enabled !== false ? "checked" : ""}>
              <input type="text" class="ac-kv-inp mono" data-csv-idx="${idx}" data-csv-field="key" value="${esc(v.key || "")}" placeholder="base_url">
              <input type="text" class="ac-kv-inp mono" data-csv-idx="${idx}" data-csv-field="value" value="${esc(v.value || "")}">
              <input type="text" class="ac-kv-inp" data-csv-idx="${idx}" data-csv-field="description" value="${esc(v.description || "")}">
              <button type="button" class="ac-mini-btn danger" data-csv-del="${idx}">×</button>
            </div>
          `).join("")}
          <div class="ac-kv-foot"><button type="button" class="btn xs ghost" id="ac-cs-var-add">${icon("plus")} Add Variable</button></div>
        </div>
      `;
      footHtml = `
        <button type="button" class="btn ghost" data-close-modal>${esc(tr("cancel", "Cancel"))}</button>
        <button type="button" class="btn primary" id="ac-cs-save">${icon("check")} ${esc(tr("save", "Save"))}</button>
      `;
    } else if (m.kind === "save_as") {
      title = tr("ac_save_to_col", "Save Request to Collection");
      const selCol = getCollectionById(m.collectionId);
      const folders = selCol ? flattenFolders(selCol.items) : [];
      bodyHtml = `
        <div class="ac-field-row">
          <label>${esc(tr("ac_req_name", "Request Name"))}</label>
          <input type="text" id="ac-sa-name" class="ac-input" value="${esc(m.name)}">
        </div>
        <div class="ac-field-row">
          <label>${esc(tr("ac_collection", "Collection"))}</label>
          <select id="ac-sa-col" class="ac-select">
            ${S.collections.map((c) => `<option value="${esc(c.id)}" ${c.id === m.collectionId ? "selected" : ""}>${esc(c.name)}</option>`).join("")}
            <option value="__new__" ${m.collectionId === "__new__" ? "selected" : ""}>+ ${esc(tr("ac_create_new_col", "Create new collection…"))}</option>
          </select>
        </div>
        ${m.collectionId === "__new__" ? `
          <div class="ac-field-row">
            <label>${esc(tr("ac_col_name", "New Collection Name"))}</label>
            <input type="text" id="ac-sa-new-col" class="ac-input" value="${esc(m.newCollectionName)}">
          </div>
        ` : `
          <div class="ac-field-row">
            <label>${esc(tr("ac_folder_opt", "Folder (optional)"))}</label>
            <select id="ac-sa-folder" class="ac-select">
              <option value="">(Root of collection)</option>
              ${folders.map((f) => `<option value="${esc(f.id)}" ${f.id === m.folderId ? "selected" : ""}>${esc(f.label)}</option>`).join("")}
            </select>
          </div>
        `}
      `;
      footHtml = `
        <button type="button" class="btn ghost" data-close-modal>${esc(tr("cancel", "Cancel"))}</button>
        <button type="button" class="btn primary" id="ac-sa-confirm">${icon("check")} ${esc(tr("save", "Save"))}</button>
      `;
    } else if (m.kind === "code") {
      wide = true;
      title = tr("ac_code_snippets", "Code Snippets");
      bodyHtml = `
        <div class="ac-subtabs" style="margin-bottom:10px">
          ${CODE_LANGS.map(([id, lbl]) => `
            <button type="button" class="ac-subtab ${m.lang === id ? "active" : ""}" data-code-lang="${id}">${esc(lbl)}</button>
          `).join("")}
        </div>
        <pre class="ac-json-pre" style="max-height:360px">${esc(m.code || "")}</pre>
      `;
      footHtml = `
        <button type="button" class="btn ghost" data-close-modal>${esc(tr("close", "Close"))}</button>
        <button type="button" class="btn primary" id="ac-code-copy">${icon("copy")} ${esc(tr("copy", "Copy"))}</button>
      `;
    }

    return `
      <div class="ac-modal-scrim" id="ac-modal-scrim">
        <div class="ac-modal card ${wide ? "wide" : ""}">
          <div class="ac-modal-head">
            <h3>${esc(title)}</h3>
            <button type="button" class="btn ghost icon-btn sm" data-close-modal aria-label="Close">${icon("x")}</button>
          </div>
          <div class="ac-modal-body">${bodyHtml}</div>
          <div class="ac-modal-foot">${footHtml}</div>
        </div>
      </div>
    `;
  }

  // ── Event Wiring ───────────────────────────────────────────────────────────

  function wireEvents(root) {
    const tab = activeTab();

    // Topbar actions
    $$("[data-ac-mode]", root).forEach((btn) => btn.addEventListener("click", () => {
      S.mode = btn.dataset.acMode;
      render();
    }));

    $("#ac-btn-import", root)?.addEventListener("click", openImportModal);
    $("#ac-btn-sync-routes", root)?.addEventListener("click", openSyncRoutesModal);
    $("#ac-btn-manage-envs", root)?.addEventListener("click", openEnvironmentsModal);
    $("#ac-env-select", root)?.addEventListener("change", async (e) => {
      S.activeEnvId = e.target.value;
      await persistEnvironments();
      render();
    });

    // Sidebar tabs, layout switcher & search
    $$("[data-sb-tab]", root).forEach((btn) => btn.addEventListener("click", () => {
      S.sidebarTab = btn.dataset.sbTab;
      render();
    }));
    $$("[data-folder-layout]", root).forEach((btn) => btn.addEventListener("click", () => {
      setFolderLayout(btn.dataset.folderLayout);
    }));

    const sbSearch = $("#ac-sb-search", root);
    if (sbSearch) {
      sbSearch.addEventListener("input", (e) => {
        S.sidebarSearch = e.target.value;
        const pos = e.target.selectionStart;
        render();
        const nextInp = $("#ac-sb-search", root);
        if (nextInp) { nextInp.focus(); nextInp.setSelectionRange(pos, pos); }
      });
    }

    $("#ac-btn-new-col", root)?.addEventListener("click", () => createNewCollection());
    $("#ac-empty-new-col", root)?.addEventListener("click", () => createNewCollection());
    $("#ac-empty-sync", root)?.addEventListener("click", openSyncRoutesModal);
    $("#ac-empty-import", root)?.addEventListener("click", openImportModal);
    $("#ac-docs-new-col", root)?.addEventListener("click", () => createNewCollection());
    $("#ac-docs-sync", root)?.addEventListener("click", openSyncRoutesModal);

    $("#ac-btn-clear-hist", root)?.addEventListener("click", async () => {
      if (!confirm(tr("ac_clear_history_confirm", "Clear all request history?"))) return;
      await LD.call("postman_clear_history");
      S.history = [];
      render();
    });

    // Tree interactions
    $$("[data-toggle-expand]", root).forEach((row) => row.addEventListener("click", (e) => {
      if (e.target.closest("button")) return;
      const id = row.dataset.toggleExpand;
      if (S.expanded.has(id)) S.expanded.delete(id);
      else S.expanded.add(id);
      render();
    }));

    $$("[data-open-req]", root).forEach((row) => row.addEventListener("click", (e) => {
      if (e.target.closest("button")) return;
      const col = getCollectionById(row.dataset.openReq);
      if (!col) return;
      const hit = findItemInTree(col.items, row.dataset.reqId);
      if (hit) openRequestInTab(col.id, hit.item);
    }));

    $$("[data-add-req]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      addRequestTo(b.dataset.addReq, b.dataset.parent || null, b.dataset.urlPrefix || "");
    }));
    $$("[data-add-folder]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      addFolder(b.dataset.addFolder, b.dataset.parent || null);
    }));
    $$("[data-rename-folder]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      renameFolder(b.dataset.renameFolder, b.dataset.item);
    }));
    $$("[data-dup-item]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      duplicateItem(b.dataset.dupItem, b.dataset.item);
    }));
    $$("[data-del-item]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      deleteItem(b.dataset.delItem, b.dataset.item);
    }));
    $$("[data-del-col]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      deleteCollection(b.dataset.delCol);
    }));
    $$("[data-edit-col]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      openCollectionSettingsModal(b.dataset.editCol);
    }));
    $$("[data-export-col]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      exportCollection(b.dataset.exportCol, "postman_v21");
    }));
    $$("[data-open-docs]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      S.docsCollectionId = b.dataset.openDocs;
      S.mode = "docs";
      render();
    }));

    // History clicks
    $$("[data-open-hist]", root).forEach((row) => row.addEventListener("click", () => {
      const h = S.history[Number(row.dataset.openHist)];
      if (!h) return;
      const req = h.request ? deepClone(h.request) : blankRequest({ method: h.method, url: h.raw_url || h.url, name: h.name || h.url });
      req.id = uid("req");
      openBlankTab(req, "");
      render();
    }));

    // Request Tabs strip
    $$("[data-select-tab]", root).forEach((el) => el.addEventListener("click", (e) => {
      if (e.target.closest("[data-close-tab]")) return;
      S.activeTabId = el.dataset.selectTab;
      render();
    }));
    $$("[data-close-tab]", root).forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      closeTab(b.dataset.closeTab);
    }));
    $("#ac-btn-new-tab", root)?.addEventListener("click", () => {
      openBlankTab();
      render();
    });

    // Builder controls
    if (tab && S.mode === "builder") {
      const markDirty = () => { tab.dirty = true; };

      $("#ac-req-name", root)?.addEventListener("input", (e) => {
        tab.request.name = e.target.value;
        markDirty();
      });
      $("#ac-req-method", root)?.addEventListener("change", (e) => {
        tab.request.method = e.target.value;
        markDirty();
        render();
      });
      const urlInp = $("#ac-req-url", root);
      if (urlInp) {
        urlInp.addEventListener("input", (e) => {
          tab.request.url = e.target.value;
          syncParamsFromUrl(tab.request);
          markDirty();
        });
        urlInp.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            sendActiveRequest();
          }
        });
      }

      $("#ac-btn-send", root)?.addEventListener("click", sendActiveRequest);
      $("#ac-btn-save", root)?.addEventListener("click", () => saveActiveTab(false));
      $("#ac-btn-save-as", root)?.addEventListener("click", () => saveActiveTab(true));
      $("#ac-btn-code", root)?.addEventListener("click", () => openCodeSnippetModal(tab, "curl"));
      $("#ac-btn-save-example", root)?.addEventListener("click", saveResponseAsExample);
      $("#ac-btn-copy-resp", root)?.addEventListener("click", () => {
        if (!tab.response) return;
        const txt = tab.response.is_json ? JSON.stringify(tab.response.json, null, 2) : (tab.response.text || "");
        copyText(txt);
      });
      $("#ac-opt-redirects", root)?.addEventListener("change", (e) => {
        tab.options.follow_redirects = e.target.checked;
      });

      $$("[data-req-subtab]", root).forEach((b) => b.addEventListener("click", () => {
        tab.reqSubTab = b.dataset.reqSubtab;
        render();
      }));
      $$("[data-resp-subtab]", root).forEach((b) => b.addEventListener("click", () => {
        tab.respSubTab = b.dataset.respSubtab;
        render();
      }));
      $$("[data-body-view]", root).forEach((b) => b.addEventListener("click", () => {
        tab.bodyViewMode = b.dataset.bodyView;
        render();
      }));

      // KV Table edits (params, path_variables, headers, formdata, urlencoded)
      const getKvList = (tbl) => {
        if (tbl === "formdata") return tab.request.body.formdata;
        if (tbl === "urlencoded") return tab.request.body.urlencoded;
        return tab.request[tbl];
      };

      $$("[data-kv-tbl]", root).forEach((inp) => {
        const evt = inp.type === "checkbox" || inp.tagName === "SELECT" ? "change" : "input";
        inp.addEventListener(evt, () => {
          const tbl = inp.dataset.kvTbl;
          const idx = Number(inp.dataset.kvIdx);
          const field = inp.dataset.kvField;
          const list = getKvList(tbl);
          if (!list || !list[idx]) return;
          list[idx][field] = inp.type === "checkbox" ? inp.checked : inp.value;
          markDirty();
          if (tbl === "params") {
            syncUrlFromParams(tab.request);
            const urlEl = $("#ac-req-url", root);
            if (urlEl) urlEl.value = tab.request.url;
          }
          if (field === "type" || field === "enabled") render();
        });
      });

      $$("[data-kv-add]", root).forEach((b) => b.addEventListener("click", () => {
        const tbl = b.dataset.kvAdd;
        const list = getKvList(tbl);
        if (!list) return;
        if (tbl === "formdata") list.push({ key: "", value: "", type: "text", src: "", enabled: true, description: "" });
        else list.push({ key: "", value: "", enabled: true, description: "" });
        markDirty();
        render();
      }));

      $$("[data-kv-del]", root).forEach((b) => b.addEventListener("click", () => {
        const tbl = b.dataset.kvDel;
        const idx = Number(b.dataset.kvIdx);
        const list = getKvList(tbl);
        if (!list) return;
        list.splice(idx, 1);
        markDirty();
        if (tbl === "params") syncUrlFromParams(tab.request);
        render();
      }));

      $$("[data-kv-browse]", root).forEach((b) => b.addEventListener("click", async () => {
        const idx = Number(b.dataset.kvBrowse);
        try {
          const picked = await LD.call("pick_file", { title: "Select file to upload" });
          if (picked && tab.request.body.formdata[idx]) {
            tab.request.body.formdata[idx].src = picked;
            markDirty();
            render();
          }
        } catch (err) {
          toast("error", "File picker failed", err.message);
        }
      }));

      // Header presets
      $$(".ac-preset-hdr", root).forEach((b) => b.addEventListener("click", () => {
        const hk = b.dataset.hk;
        const hv = b.dataset.hv;
        const existing = tab.request.headers.find((h) => (h.key || "").toLowerCase() === hk.toLowerCase());
        if (existing) { existing.value = hv; existing.enabled = true; }
        else tab.request.headers.push({ key: hk, value: hv, enabled: true, description: "" });
        markDirty();
        render();
      }));

      // Auth controls
      $("#ac-auth-type", root)?.addEventListener("change", (e) => {
        tab.request.auth = { type: e.target.value };
        markDirty();
        render();
      });
      $$("[data-auth-field]", root).forEach((inp) => inp.addEventListener(inp.tagName === "SELECT" ? "change" : "input", () => {
        tab.request.auth = tab.request.auth || { type: "none" };
        tab.request.auth[inp.dataset.authField] = inp.value;
        markDirty();
      }));

      // Body mode & inputs
      $$('input[name="ac-body-mode"]', root).forEach((rad) => rad.addEventListener("change", () => {
        tab.request.body.mode = rad.value;
        markDirty();
        render();
      }));
      $("#ac-raw-type", root)?.addEventListener("change", (e) => {
        tab.request.body.raw_type = e.target.value;
        markDirty();
        render();
      });
      $("#ac-body-raw", root)?.addEventListener("input", (e) => {
        tab.request.body.raw = e.target.value;
        markDirty();
      });
      $("#ac-btn-prettify-body", root)?.addEventListener("click", () => {
        try {
          tab.request.body.raw = JSON.stringify(JSON.parse(tab.request.body.raw || "{}"), null, 2);
          markDirty();
          render();
        } catch (err) {
          toast("error", "Invalid JSON", err.message);
        }
      });
      $("#ac-gql-query", root)?.addEventListener("input", (e) => {
        tab.request.body.graphql = tab.request.body.graphql || { query: "", variables: "" };
        tab.request.body.graphql.query = e.target.value;
        markDirty();
      });
      $("#ac-gql-vars", root)?.addEventListener("input", (e) => {
        tab.request.body.graphql = tab.request.body.graphql || { query: "", variables: "" };
        tab.request.body.graphql.variables = e.target.value;
        markDirty();
      });

      // Tests & Extractors
      $("#ac-btn-add-test", root)?.addEventListener("click", () => {
        tab.request.tests.push({ type: "status_equals", target: "", value: "200", enabled: true });
        markDirty();
        render();
      });
      $$("[data-test-idx]", root).forEach((inp) => {
        const evt = inp.type === "checkbox" || inp.tagName === "SELECT" ? "change" : "input";
        inp.addEventListener(evt, () => {
          const r = tab.request.tests[Number(inp.dataset.testIdx)];
          if (!r) return;
          r[inp.dataset.testField] = inp.type === "checkbox" ? inp.checked : inp.value;
          markDirty();
          if (inp.dataset.testField === "type") render();
        });
      });
      $$("[data-del-test]", root).forEach((b) => b.addEventListener("click", () => {
        tab.request.tests.splice(Number(b.dataset.delTest), 1);
        markDirty();
        render();
      }));

      $("#ac-btn-add-ext", root)?.addEventListener("click", () => {
        tab.request.extractors.push({ source: "json", path: "data.token", variable: "token", enabled: true });
        markDirty();
        render();
      });
      $$("[data-ext-idx]", root).forEach((inp) => {
        const evt = inp.type === "checkbox" || inp.tagName === "SELECT" ? "change" : "input";
        inp.addEventListener(evt, () => {
          const ex = tab.request.extractors[Number(inp.dataset.extIdx)];
          if (!ex) return;
          ex[inp.dataset.extField] = inp.type === "checkbox" ? inp.checked : inp.value;
          markDirty();
        });
      });
      $$("[data-del-ext]", root).forEach((b) => b.addEventListener("click", () => {
        tab.request.extractors.splice(Number(b.dataset.delExt), 1);
        markDirty();
        render();
      }));

      // Docs description
      $("#ac-req-desc", root)?.addEventListener("input", (e) => {
        tab.request.description = e.target.value;
        markDirty();
      });

      // Saved examples actions
      $$("[data-copy-ex]", root).forEach((b) => b.addEventListener("click", () => {
        const ex = tab.request.examples[Number(b.dataset.copyEx)];
        if (ex) copyText(ex.body || "");
      }));
      $$("[data-del-ex]", root).forEach((b) => b.addEventListener("click", () => {
        tab.request.examples.splice(Number(b.dataset.delEx), 1);
        markDirty();
        render();
      }));
    }

    // Docs mode controls
    if (S.mode === "docs") {
      $("#ac-docs-col-select", root)?.addEventListener("change", (e) => {
        S.docsCollectionId = e.target.value;
        render();
      });
      const docsSearch = $("#ac-docs-search", root);
      if (docsSearch) {
        docsSearch.addEventListener("input", (e) => {
          S.docsSearch = e.target.value;
          const pos = e.target.selectionStart;
          render();
          const nextInp = $("#ac-docs-search", root);
          if (nextInp) { nextInp.focus(); nextInp.setSelectionRange(pos, pos); }
        });
      }
      $$("[data-export-doc]", root).forEach((b) => b.addEventListener("click", () => {
        exportCollection(b.dataset.exportDoc, b.dataset.docFmt);
      }));
      $$("[data-try-doc-req]", root).forEach((b) => b.addEventListener("click", () => {
        const col = getCollectionById(b.dataset.tryDocReq);
        if (!col) return;
        const hit = findItemInTree(col.items, b.dataset.reqId);
        if (hit) openRequestInTab(col.id, hit.item);
      }));
      $$("[data-copy-text]", root).forEach((b) => b.addEventListener("click", () => {
        copyText(b.dataset.copyText || "");
      }));
    }

    // Modal controls
    wireModalEvents(root);
  }

  function wireModalEvents(root) {
    const m = S.modal;
    if (!m) return;
    $$("[data-close-modal]", root).forEach((b) => b.addEventListener("click", () => {
      S.modal = null;
      render();
    }));
    $("#ac-modal-scrim", root)?.addEventListener("click", (e) => {
      if (e.target.id === "ac-modal-scrim") {
        S.modal = null;
        render();
      }
    });

    if (m.kind === "import") {
      const fileInp = $("#ac-import-file-input", root);
      const txtArea = $("#ac-import-textarea", root);
      $("#ac-btn-pick-import-file", root)?.addEventListener("click", () => fileInp?.click());
      fileInp?.addEventListener("change", async () => {
        const f = fileInp.files?.[0];
        if (!f) return;
        const text = await f.text();
        m.text = text;
        if (txtArea) txtArea.value = text;
        const fn = $("#ac-import-filename", root);
        if (fn) fn.textContent = f.name;
      });
      txtArea?.addEventListener("input", () => { m.text = txtArea.value; });
      $("#ac-btn-do-import", root)?.addEventListener("click", () => performImport(txtArea?.value || m.text));
    } else if (m.kind === "sync_routes") {
      $("#ac-sync-site", root)?.addEventListener("change", (e) => { m.siteName = e.target.value; });
      $("#ac-sync-folder-mode", root)?.addEventListener("change", (e) => { m.folderMode = e.target.value; });
      $("#ac-sync-api-only", root)?.addEventListener("change", (e) => { m.apiOnly = e.target.checked; });
      $("#ac-sync-replace", root)?.addEventListener("change", (e) => { m.replaceExisting = e.target.checked; });
      $("#ac-btn-do-sync", root)?.addEventListener("click", () => syncRoutesForSite(m.siteName, m.apiOnly, m.replaceExisting, m.folderMode));
    } else if (m.kind === "environments") {
      const current = S.environments.find((e) => e.id === m.editEnvId) || S.environments[0] || null;
      $$("[data-select-edit-env]", root).forEach((row) => row.addEventListener("click", () => {
        m.editEnvId = row.dataset.selectEditEnv;
        render();
      }));
      $("#ac-env-add", root)?.addEventListener("click", () => {
        const nextEnv = {
          id: uid("env"),
          name: `Environment ${S.environments.length + 1}`,
          site_name: "",
          variables: [{ id: uid("var"), key: "base_url", value: "http://localhost:8000", enabled: true, secret: false, description: "" }],
        };
        S.environments.push(nextEnv);
        m.editEnvId = nextEnv.id;
        render();
      });
      if (current) {
        $("#ac-env-name-inp", root)?.addEventListener("input", (e) => { current.name = e.target.value; });
        $("#ac-env-export-btn", root)?.addEventListener("click", async () => {
          await persistEnvironments();
          exportEnvironment(current.id);
        });
        $("#ac-env-del-btn", root)?.addEventListener("click", () => {
          S.environments = S.environments.filter((e) => e.id !== current.id);
          if (S.activeEnvId === current.id) S.activeEnvId = S.environments[0]?.id || "";
          m.editEnvId = S.environments[0]?.id || "";
          render();
        });
        $("#ac-env-var-add", root)?.addEventListener("click", () => {
          current.variables.push({ id: uid("var"), key: "", value: "", enabled: true, secret: false, description: "" });
          render();
        });
        $$("[data-ev-idx]", root).forEach((inp) => {
          const evt = inp.type === "checkbox" ? "change" : "input";
          inp.addEventListener(evt, () => {
            const v = current.variables[Number(inp.dataset.evIdx)];
            if (!v) return;
            v[inp.dataset.evField] = inp.type === "checkbox" ? inp.checked : inp.value;
            if (inp.dataset.evField === "secret") render();
          });
        });
        $$("[data-ev-del]", root).forEach((b) => b.addEventListener("click", () => {
          current.variables.splice(Number(b.dataset.evDel), 1);
          render();
        }));
      }
      $("#ac-env-save-close", root)?.addEventListener("click", async () => {
        await persistEnvironments();
        S.modal = null;
        toast("success", tr("ac_envs_saved", "Environments saved"));
        render();
      });
    } else if (m.kind === "collection_settings") {
      const col = m.collection;
      $("#ac-cs-name", root)?.addEventListener("input", (e) => { col.name = e.target.value; });
      $("#ac-cs-desc", root)?.addEventListener("input", (e) => { col.description = e.target.value; });
      $("#ac-cs-auth-type", root)?.addEventListener("change", (e) => {
        col.auth = { type: e.target.value };
        render();
      });
      $$("[data-cs-auth]", root).forEach((inp) => inp.addEventListener("input", () => {
        col.auth = col.auth || { type: "none" };
        col.auth[inp.dataset.csAuth] = inp.value;
      }));
      $("#ac-cs-var-add", root)?.addEventListener("click", () => {
        col.variables.push({ key: "", value: "", enabled: true, description: "" });
        render();
      });
      $$("[data-csv-idx]", root).forEach((inp) => {
        const evt = inp.type === "checkbox" ? "change" : "input";
        inp.addEventListener(evt, () => {
          const v = col.variables[Number(inp.dataset.csvIdx)];
          if (v) v[inp.dataset.csvField] = inp.type === "checkbox" ? inp.checked : inp.value;
        });
      });
      $$("[data-csv-del]", root).forEach((b) => b.addEventListener("click", () => {
        col.variables.splice(Number(b.dataset.csvDel), 1);
        render();
      }));
      $("#ac-cs-save", root)?.addEventListener("click", async () => {
        await persistCollection(col);
        S.modal = null;
        toast("success", tr("ac_col_updated", "Collection updated"), col.name);
        render();
      });
    } else if (m.kind === "save_as") {
      $("#ac-sa-name", root)?.addEventListener("input", (e) => { m.name = e.target.value; });
      $("#ac-sa-col", root)?.addEventListener("change", (e) => {
        m.collectionId = e.target.value;
        m.folderId = "";
        render();
      });
      $("#ac-sa-new-col", root)?.addEventListener("input", (e) => { m.newCollectionName = e.target.value; });
      $("#ac-sa-folder", root)?.addEventListener("change", (e) => { m.folderId = e.target.value; });
      $("#ac-sa-confirm", root)?.addEventListener("click", async () => {
        const tab = S.tabs.find((tb) => tb.tabId === m.tabId);
        if (!tab) return;
        tab.request.name = (m.name || "Request").trim();
        let targetCol = null;
        if (m.collectionId === "__new__") {
          targetCol = await createNewCollection(m.newCollectionName || "My API Collection");
          if (!targetCol) return;
        } else {
          targetCol = getCollectionById(m.collectionId);
        }
        if (!targetCol) return;
        // If saving a copy into a different collection or new location, ensure unique id
        const existsHere = findItemInTree(targetCol.items, tab.request.id);
        if (existsHere && tab.collectionId === targetCol.id) {
          existsHere.list[existsHere.index] = deepClone(tab.request);
        } else {
          tab.request.id = uid("req");
          if (m.folderId) {
            const fhit = findItemInTree(targetCol.items, m.folderId);
            if (fhit && fhit.item.type === "folder") fhit.item.items.push(deepClone(tab.request));
            else targetCol.items.push(deepClone(tab.request));
          } else {
            targetCol.items.push(deepClone(tab.request));
          }
        }
        await persistCollection(targetCol);
        tab.collectionId = targetCol.id;
        tab.dirty = false;
        S.expanded.add(targetCol.id);
        if (m.folderId) S.expanded.add(m.folderId);
        S.modal = null;
        toast("success", tr("ac_saved", "Request saved"), `${targetCol.name} / ${tab.request.name}`);
        render();
      });
    } else if (m.kind === "code") {
      $$("[data-code-lang]", root).forEach((b) => b.addEventListener("click", () => {
        const tab = S.tabs.find((tb) => tb.tabId === m.tabId);
        if (tab) openCodeSnippetModal(tab, b.dataset.codeLang);
      }));
      $("#ac-code-copy", root)?.addEventListener("click", () => copyText(m.code || ""));
    }
  }

  // Global keyboard shortcuts when API Client is visible
  document.addEventListener("keydown", (e) => {
    const root = S.mountRoot;
    if (!root || !root.isConnected || root.hidden) return;
    if (!root.closest("#view-api-client:not([hidden]), #site-drawer.open")) return;
    const ctrl = e.ctrlKey || e.metaKey;
    if (ctrl && e.key === "Enter" && S.mode === "builder" && !S.modal) {
      e.preventDefault();
      sendActiveRequest();
    } else if (ctrl && e.key.toLowerCase() === "s" && S.mode === "builder" && !S.modal) {
      e.preventDefault();
      saveActiveTab(false);
    } else if (e.key === "Escape" && S.modal) {
      e.preventDefault();
      S.modal = null;
      render();
    }
  });

  window.addEventListener("langchange", () => {
    if (S.mountRoot && S.mountRoot.isConnected && !S.mountRoot.hidden) render();
  });

  // ── Public API ─────────────────────────────────────────────────────────────

  async function show() {
    S.siteContext = null;
    S.mountRoot = $("#view-api-client");
    if (!S.mountRoot) return;
    await loadState(false);
    render();
  }

  async function mountSite(container, site) {
    S.siteContext = site;
    S.mountRoot = container;
    await loadState(false);
    // Highlight/expand collection & environment belonging to this site
    const siteEnv = S.environments.find((e) => e.site_name === site.name);
    if (siteEnv) S.activeEnvId = siteEnv.id;
    const siteCol = S.collections.find((c) => c.site_name === site.name);
    if (siteCol) {
      S.expanded.add(siteCol.id);
      S.docsCollectionId = siteCol.id;
    }
    render();
  }

  async function openRoute(site, routeObj) {
    await loadState(false);
    const method = String(routeObj.method || "GET").split("|")[0].trim().toUpperCase();
    const uri = String(routeObj.uri || "/").replace(/^\/+/, "");
    const base = (site.url || `http://${site.domain}`).replace(/\/$/, "");
    const req = blankRequest({
      name: routeObj.name || `${method} /${uri}`,
      method,
      url: `${base}/${uri}`,
      description: routeObj.action ? `**Action:** \`${routeObj.action}\`` : "",
    });
    syncParamsFromUrl(req);
    openBlankTab(req, "");
    if (typeof openDrawer === "function" && site?.name) {
      openDrawer(site.name, "api_client");
    } else if (typeof setView === "function") {
      setView("api-client");
    }
  }

  async function syncAndOpenSite(siteName) {
    await loadState(false);
    await syncRoutesForSite(siteName, true, true);
    if (typeof openDrawer === "function" && siteName) {
      openDrawer(siteName, "api_client");
    } else if (typeof setView === "function") {
      setView("api-client");
    }
  }

  return {
    show,
    mountSite,
    openRoute,
    syncAndOpenSite,
    openImportModal,
    openSyncRoutesModal,
  };
})();

window.ApiClient = ApiClient;
