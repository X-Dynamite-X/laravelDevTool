"use strict";

/* ── GitHub Explorer & Repository Workspace (ui/web/github_explorer.js) ──
   Provides the full native GitHub experience: Repo Code/Tree/Markdown/Editor,
   PR Conversation/Commits/Checks/Diffs/Reviews, Issue Threads, Actions Logs,
   Commits & Compare, Releases, Webhooks/Security/Settings, Notifications,
   Organizations, Global Search, Gists, Stars, and Profile/Activity Feed. */

const GitHubExplorer = (() => {
  const LANG_COLORS = {
    PHP: "#4F5D95", JavaScript: "#f1e05a", TypeScript: "#3178c6",
    HTML: "#e34c26", CSS: "#563d7c", Blade: "#f7523f",
    Python: "#3572A5", Shell: "#89e051", Vue: "#41b883",
    Go: "#00ADD8", Rust: "#dea584", Ruby: "#701516", SQL: "#e38c00",
  };

  const E = {
    activeRepo: "", // "owner/repo" when inside Repository Workspace
    repoSubTab: "code", // code | issues | pulls | actions | commits | releases | settings
    repoMeta: null,
    starred: false,
    branches: [],
    tags: [],
    languages: [],
    currentRef: "",
    currentPath: "",
    treeItems: [],
    treeFilter: "",
    treeHidden: false,
    dirEntries: [],
    fileData: null,
    readmeData: null,
    editingFile: false,
    newFileMode: false,

    // Detail subviews
    commits: [],
    contributors: [],
    repoLabels: [],
    selectedCommit: null,
    compareResult: null,
    compareBase: "main",
    compareHead: "",
    releases: [],
    hooks: [],
    deployKeys: [],
    collaborators: [],
    securityAlerts: [],
    securityError: "",

    // PR Detail
    activePRNumber: null,
    prSubTab: "conversation", // conversation | commits | checks | files
    prDetail: null,
    prCommits: [],
    prFiles: [],
    prReviews: [],
    prComments: [],
    prChecks: [],
    diffMode: "unified", // unified | split

    // Issue Detail
    activeIssueNumber: null,
    issueDetail: null,
    issueComments: [],

    // Actions Run Detail
    activeRunId: null,
    runJobs: [],
    runArtifacts: [],
    selectedJobId: null,
    jobLogs: "",
    jobLogsTruncated: false,

    // Global views state
    events: [],
    eventsLoadedFor: "",
    notifications: [],
    notifAll: false,
    notifParticipating: false,
    searchKind: "repositories",
    searchQuery: "",
    searchResults: null,
    gists: [],
    selectedGist: null,
    editingGist: false,
    orgs: [],
    selectedOrg: "",
    orgRepos: [],
    orgMembers: [],
    profileUser: null,
    starredRepos: [],
    sshKeys: [],

    loading: false,
    // CI/CD, Env Keys & VPS Linker
    cicdCaps: null,
    cicdInspect: null,
    cicdEnvs: [],
    cicdSelectedEnv: "",
    cicdSecrets: [],
    cicdVariables: [],
    cicdServers: [],
    cicdPreviewYaml: "",
    cicdLastResult: null,
    cicdForm: {
      repoKey: "",
      serverId: "",
      stack: "laravel",
      strategy: "ci_build_upload",
      domain: "",
      path: "",
      port: 3000,
      healthPath: "/up",
      branch: "main",
      environment: "",
      scaffold: true,
    },

    onRender: null,
  };

  function setRenderCallback(fn) {
    E.onRender = fn;
  }

  function triggerRender() {
    if (typeof E.onRender === "function") E.onRender();
  }

  function splitRepo(full) {
    if (!full || !full.includes("/")) return ["", ""];
    const idx = full.indexOf("/");
    return [full.slice(0, idx), full.slice(idx + 1)];
  }

  function sanitizeHtml(rawHtml) {
    if (!rawHtml) return "";
    const parser = new DOMParser();
    const doc = parser.parseFromString(String(rawHtml), "text/html");
    // The main window holds the backend bridge, so remote HTML must never run script.
    doc.querySelectorAll(
      "script, iframe, frame, frameset, object, embed, applet, form, input, button, textarea, select, " +
      "meta, link, style, base, noscript, template, animate, set, animatetransform, animatemotion, foreignobject"
    ).forEach((el) => el.remove());
    const urlAttrs = new Set(["href", "src", "xlink:href", "action", "formaction", "poster", "background", "srcset", "data", "cite"]);
    doc.querySelectorAll("*").forEach((el) => {
      for (const attr of [...el.attributes]) {
        const nm = attr.name.toLowerCase();
        // Browsers ignore whitespace/control chars inside the scheme ("java\tscript:").
        const val = (attr.value || "").replace(/[\u0000- \u007f-\u009f]+/g, "").toLowerCase();
        if (nm.startsWith("on") || nm === "srcdoc" || nm === "style" && /expression\(|url\(\s*['"]?\s*javascript:/i.test(attr.value)) {
          el.removeAttribute(attr.name);
        } else if (urlAttrs.has(nm)) {
          const isImgData = nm === "src" && el.tagName === "IMG" && /^data:image\/(png|gif|jpe?g|webp);/.test(val);
          if (/^(javascript|vbscript|data|file):/.test(val) && !isImgData) {
            el.setAttribute(attr.name, "#");
          }
        }
      }
      if (el.tagName === "A" && el.getAttribute("href")) {
        el.setAttribute("target", "_blank");
        el.setAttribute("rel", "noopener noreferrer");
      }
    });
    return doc.body ? doc.body.innerHTML : "";
  }

  function renderPlainMarkdownFallback(txt) {
    return `<pre class="gh-code-pre" style="white-space:pre-wrap;font-family:var(--sans,sans-serif);line-height:1.6;">${esc(txt || "")}</pre>`;
  }

  // ── Navigation Entry Points ─────────────────────────────────────────────

  async function openRepo(fullName, subTab = "code", opts = {}) {
    if (!fullName || !fullName.includes("/")) return;
    const isNewRepo = E.activeRepo !== fullName;
    E.activeRepo = fullName;
    E.repoSubTab = subTab || "code";
    E.editingFile = false;
    E.newFileMode = false;
    E.selectedCommit = null;
    if (opts.clearDetails !== false) {
      E.activePRNumber = null;
      E.activeIssueNumber = null;
      E.activeRunId = null;
    }
    if (isNewRepo) {
      E.repoMeta = null;
      E.currentPath = "";
      E.currentRef = "";
      E.fileData = null;
      E.readmeData = null;
      E.dirEntries = [];
      E.treeItems = [];
      E.commits = [];
      E.releases = [];
      E.cicdCaps = null;
      E.cicdInspect = null;
      E.cicdEnvs = [];
      E.cicdSelectedEnv = "";
      E.cicdSecrets = [];
      E.cicdVariables = [];
      E.cicdPreviewYaml = "";
      E.cicdLastResult = null;
    }
    E.loading = true;
    triggerRender();

    const [owner, repo] = splitRepo(fullName);
    try {
      const [repoRes, brRes, langRes, starRes] = await Promise.all([
        LD.call("gh_repo_detail", { owner, repo }),
        LD.call("gh_branches", { owner, repo }),
        LD.call("gh_languages", { owner, repo }),
        LD.call("gh_star_status", { owner, repo }),
      ]);
      if (repoRes?.ok && repoRes.repo) {
        E.repoMeta = repoRes.repo;
      }
      if (brRes?.ok) {
        E.branches = brRes.branches || [];
      }
      if (!E.currentRef) {
        E.currentRef = E.repoMeta?.default_branch || E.branches[0] || "main";
      }
      if (langRes?.ok) {
        E.languages = langRes.breakdown || [];
      }
      if (starRes?.ok) {
        E.starred = Boolean(starRes.starred);
      }
      await loadRepoSubTabData();
    } finally {
      E.loading = false;
      triggerRender();
    }
  }

  function closeRepo() {
    E.activeRepo = "";
    E.activePRNumber = null;
    E.activeIssueNumber = null;
    E.activeRunId = null;
    triggerRender();
  }

  async function loadRepoSubTabData() {
    if (!E.activeRepo) return;
    const [owner, repo] = splitRepo(E.activeRepo);
    if (E.repoSubTab === "code") {
      await loadContents(E.currentPath);
      LD.call("gh_tree", { owner, repo, ref: E.currentRef || "main" }).then((tr) => {
        if (tr?.ok) {
          E.treeItems = tr.tree || [];
          triggerRender();
        }
      });
    } else if (E.repoSubTab === "commits") {
      const [res, contribRes] = await Promise.all([
        LD.call("gh_commits", { owner, repo, sha: E.currentRef || "" }),
        LD.call("gh_contributors", { owner, repo }).catch(() => null),
      ]);
      if (res?.ok) E.commits = res.commits || [];
      E.contributors = contribRes?.ok ? (contribRes.contributors || []) : [];
      if (!E.compareBase) E.compareBase = E.repoMeta?.default_branch || "main";
      if (!E.compareHead) E.compareHead = E.branches.find((b) => b !== E.compareBase) || E.compareBase;
    } else if (E.repoSubTab === "releases") {
      const [relRes, tagRes] = await Promise.all([
        LD.call("gh_releases", { owner, repo }),
        LD.call("gh_tags", { owner, repo }),
      ]);
      if (relRes?.ok) E.releases = relRes.releases || [];
      if (tagRes?.ok) E.tags = tagRes.tags || [];
    } else if (E.repoSubTab === "settings") {
      const [hk, dk, col, sec] = await Promise.all([
        LD.call("gh_webhooks", { owner, repo }),
        LD.call("gh_deploy_keys", { owner, repo }),
        LD.call("gh_collaborators", { owner, repo }),
        LD.call("gh_security_alerts", { owner, repo }),
      ]);
      E.hooks = hk?.ok ? (hk.hooks || []) : [];
      E.deployKeys = dk?.ok ? (dk.keys || []) : [];
      E.collaborators = col?.ok ? (col.collaborators || []) : [];
      E.securityAlerts = sec?.ok ? (sec.alerts || []) : [];
      E.securityError = sec?.ok ? "" : (sec?.error || "Security alerts unavailable or disabled.");
    } else if (E.repoSubTab === "cicd") {
      await loadCicdTabData(owner, repo);
    }
  }

  async function loadCicdTabData(owner, repo) {
    const [capsRes, inspRes, envRes, srvRes] = await Promise.all([
      LD.call("gh_repo_capabilities", { owner, repo }).catch((e) => ({ ok: false, error: e.message })),
      LD.call("gh_cicd_inspect", { owner, repo, ref: E.currentRef || "" }).catch(() => ({ ok: false })),
      LD.call("gh_environments_list", { owner, repo }).catch(() => ({ ok: false, environments: [] })),
      LD.call("servers", {}).catch(() => ({ servers: [] })),
    ]);
    E.cicdCaps = capsRes || null;
    E.cicdInspect = inspRes || null;
    E.cicdEnvs = envRes?.ok ? (envRes.environments || []) : [];
    E.cicdServers = srvRes?.servers || [];
    if (E.cicdSelectedEnv && !E.cicdEnvs.find((x) => x.name === E.cicdSelectedEnv)) {
      E.cicdSelectedEnv = "";
    }
    if (E.cicdCaps?.can_manage_secrets || E.cicdCaps?.can_manage_variables) {
      const [secRes, varRes] = await Promise.all([
        E.cicdCaps.can_manage_secrets
          ? LD.call("gh_secrets_list", { owner, repo, env: E.cicdSelectedEnv }).catch(() => ({ ok: false, secrets: [] }))
          : Promise.resolve({ ok: false, secrets: [] }),
        E.cicdCaps.can_manage_variables
          ? LD.call("gh_variables_list", { owner, repo, env: E.cicdSelectedEnv }).catch(() => ({ ok: false, variables: [] }))
          : Promise.resolve({ ok: false, variables: [] }),
      ]);
      E.cicdSecrets = secRes?.ok ? (secRes.secrets || []) : [];
      E.cicdVariables = varRes?.ok ? (varRes.variables || []) : [];
    } else {
      E.cicdSecrets = [];
      E.cicdVariables = [];
    }
    const detStack = inspRes?.stack || "laravel";
    if (E.cicdForm.repoKey !== E.activeRepo) {
      E.cicdForm = {
        repoKey: E.activeRepo,
        serverId: (E.cicdServers[0] && E.cicdServers[0].id) || "",
        stack: detStack,
        strategy: "ci_build_upload",
        domain: `${repo.toLowerCase()}.example.com`,
        path: `/var/www/${repo.toLowerCase()}`,
        port: detStack === "python" ? 8000 : 3000,
        healthPath: detStack === "laravel" ? "/up" : "/",
        branch: E.repoMeta?.default_branch || E.currentRef || "main",
        environment: E.cicdSelectedEnv || "",
        scaffold: true,
      };
      E.cicdPreviewYaml = inspRes?.default_yaml || "";
    }
  }

  async function loadContents(path = "") {
    if (!E.activeRepo) return;
    const [owner, repo] = splitRepo(E.activeRepo);
    E.currentPath = (path || "").replace(/^\/+/, "");
    E.editingFile = false;
    E.newFileMode = false;
    const res = await LD.call("gh_contents", { owner, repo, path: E.currentPath, ref: E.currentRef });
    if (res?.ok) {
      if (res.kind === "dir") {
        E.dirEntries = res.entries || [];
        E.fileData = null;
        if (!E.currentPath) {
          const rm = await LD.call("gh_readme", { owner, repo, ref: E.currentRef, render_html: true });
          E.readmeData = rm?.ok ? rm : null;
        } else {
          const subRm = E.dirEntries.find((ent) => ent.name && ent.name.toLowerCase() === "readme.md");
          if (subRm) {
            const subFile = await LD.call("gh_contents", { owner, repo, path: subRm.path, ref: E.currentRef });
            if (subFile?.ok && subFile.content) {
              const mdRes = await LD.call("gh_markdown", { text: subFile.content, context_repo: E.activeRepo });
              E.readmeData = { name: subRm.name, content: subFile.content, html: mdRes?.ok ? mdRes.html : "" };
            } else {
              E.readmeData = null;
            }
          } else {
            E.readmeData = null;
          }
        }
      } else if (res.kind === "file") {
        E.fileData = res;
        E.readmeData = null;
        if (res.is_markdown && res.content) {
          const mdRes = await LD.call("gh_markdown", { text: res.content, context_repo: E.activeRepo });
          E.fileData.renderedHtml = mdRes?.ok ? mdRes.html : "";
        }
      }
    }
    triggerRender();
  }

  async function openPullDetail(fullName, number) {
    if (!fullName || !number) return;
    if (E.activeRepo !== fullName) {
      await openRepo(fullName, "pulls", { clearDetails: false });
    } else {
      E.repoSubTab = "pulls";
    }
    E.activePRNumber = parseInt(number, 10);
    E.activeIssueNumber = null;
    E.activeRunId = null;
    E.prSubTab = "conversation";
    E.loading = true;
    triggerRender();

    const [owner, repo] = splitRepo(fullName);
    const num = E.activePRNumber;
    const [det, cmts, fls, revs, icmts] = await Promise.all([
      LD.call("gh_pull_detail", { owner, repo, pull_number: num }),
      LD.call("gh_pull_commits", { owner, repo, pull_number: num }),
      LD.call("gh_pull_files", { owner, repo, pull_number: num }),
      LD.call("gh_pull_reviews", { owner, repo, pull_number: num }),
      LD.call("gh_issue_comments", { owner, repo, issue_number: num }),
    ]);
    E.prDetail = det?.ok ? det.pull : null;
    E.prCommits = cmts?.ok ? (cmts.commits || []) : [];
    E.prFiles = fls?.ok ? (fls.files || []) : [];
    E.prReviews = revs?.ok ? (revs.reviews || []) : [];
    E.prComments = icmts?.ok ? (icmts.comments || []) : [];
    if (E.prDetail?.head_sha) {
      const chk = await LD.call("gh_check_runs", { owner, repo, ref: E.prDetail.head_sha });
      E.prChecks = chk?.ok ? (chk.check_runs || []) : [];
    } else {
      E.prChecks = [];
    }
    E.loading = false;
    triggerRender();
  }

  async function openIssueDetail(fullName, number) {
    if (!fullName || !number) return;
    if (E.activeRepo !== fullName) {
      await openRepo(fullName, "issues", { clearDetails: false });
    } else {
      E.repoSubTab = "issues";
    }
    E.activeIssueNumber = parseInt(number, 10);
    E.activePRNumber = null;
    E.activeRunId = null;
    E.loading = true;
    triggerRender();

    const [owner, repo] = splitRepo(fullName);
    const num = E.activeIssueNumber;
    const [det, cmts, lbls] = await Promise.all([
      LD.call("gh_issue_detail", { owner, repo, issue_number: num }),
      LD.call("gh_issue_comments", { owner, repo, issue_number: num }),
      LD.call("gh_labels", { owner, repo }).catch(() => null),
    ]);
    E.issueDetail = det?.ok ? det.issue : null;
    E.issueComments = cmts?.ok ? (cmts.comments || []) : [];
    E.repoLabels = lbls?.ok ? (lbls.labels || []) : [];
    E.loading = false;
    triggerRender();
  }

  async function openRunDetail(fullName, runId) {
    if (!fullName || !runId) return;
    if (E.activeRepo !== fullName) {
      await openRepo(fullName, "actions", { clearDetails: false });
    } else {
      E.repoSubTab = "actions";
    }
    E.activeRunId = parseInt(runId, 10);
    E.selectedJobId = null;
    E.jobLogs = "";
    E.loading = true;
    triggerRender();

    const [owner, repo] = splitRepo(fullName);
    const [jobsRes, artRes] = await Promise.all([
      LD.call("gh_workflow_jobs", { owner, repo, run_id: E.activeRunId }),
      LD.call("gh_run_artifacts", { owner, repo, run_id: E.activeRunId }),
    ]);
    E.runJobs = jobsRes?.ok ? (jobsRes.jobs || []) : [];
    E.runArtifacts = artRes?.ok ? (artRes.artifacts || []) : [];
    E.loading = false;
    triggerRender();
  }

  // ── Global Data Loaders ─────────────────────────────────────────────────

  async function loadFeed(username = "") {
    if (E.eventsLoadedFor === username && E.events.length) return;
    const res = await LD.call("gh_events", { username, received: true });
    if (res?.ok) {
      E.events = res.events || [];
      E.eventsLoadedFor = username;
      triggerRender();
    }
  }

  async function loadNotifications() {
    E.loading = true;
    triggerRender();
    const res = await LD.call("gh_notifications", { all: E.notifAll, participating: E.notifParticipating });
    if (res?.ok) E.notifications = res.notifications || [];
    E.loading = false;
    triggerRender();
  }

  async function runGlobalSearch(q = E.searchQuery, kind = E.searchKind) {
    const query = (q || "").trim();
    if (!query) return;
    E.searchQuery = query;
    E.searchKind = kind || "repositories";
    E.loading = true;
    triggerRender();
    const res = await LD.call("gh_search", { kind: E.searchKind, q: query });
    E.searchResults = res;
    E.loading = false;
    triggerRender();
  }

  async function loadGists() {
    E.loading = true;
    triggerRender();
    const res = await LD.call("gh_gists", {});
    if (res?.ok) E.gists = res.gists || [];
    E.loading = false;
    triggerRender();
  }

  async function loadProfileAndOrgs() {
    E.loading = true;
    triggerRender();
    const [prof, stars, orgs, ssh] = await Promise.all([
      LD.call("gh_profile", {}),
      LD.call("gh_starred", {}),
      LD.call("gh_orgs", {}),
      LD.call("gh_ssh_keys", {}),
    ]);
    if (prof?.ok) E.profileUser = prof.user;
    if (stars?.ok) E.starredRepos = stars.repos || [];
    if (orgs?.ok) E.orgs = orgs.orgs || [];
    if (ssh?.ok) E.sshKeys = ssh.keys || [];
    E.loading = false;
    triggerRender();
  }

  async function selectOrg(orgLogin) {
    E.selectedOrg = orgLogin || "";
    if (!E.selectedOrg) {
      E.orgRepos = [];
      E.orgMembers = [];
      triggerRender();
      return;
    }
    E.loading = true;
    triggerRender();
    const [rRes, mRes] = await Promise.all([
      LD.call("gh_org_repos", { org: E.selectedOrg }),
      LD.call("gh_org_members", { org: E.selectedOrg }),
    ]);
    E.orgRepos = rRes?.ok ? (rRes.repos || []) : [];
    E.orgMembers = mRes?.ok ? (mRes.members || []) : [];
    E.loading = false;
    triggerRender();
  }

  // ── Rendering: Repository Workspace ─────────────────────────────────────

  function renderRepoWorkspace(parentState, helpers) {
    const meta = E.repoMeta || parentState.repos.find((r) => r.full_name === E.activeRepo) || {
      full_name: E.activeRepo,
      name: splitRepo(E.activeRepo)[1],
      default_branch: "main",
      html_url: `https://github.com/${E.activeRepo}`,
    };
    const [owner, repo] = splitRepo(E.activeRepo);
    const totalLangBytes = E.languages.reduce((acc, item) => acc + (item.bytes || 0), 0) || 1;

    return `
      <div class="gh-workspace" style="display:flex;flex-direction:column;gap:14px;">
        <div class="card gh-repo-header">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap;">
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
              <button type="button" class="btn sm ghost" id="ghx-back-repos">${icon("back")}<span>${esc(window.t ? window.t("gh_tab_repos", "Repositories") : "Repositories")}</span></button>
              <div style="font-size:16px;font-weight:700;">
                <span class="muted">${esc(owner)} /</span> <span>${esc(repo)}</span>
              </div>
              <span class="chip sm">${meta.private ? "Private" : "Public"}</span>
              ${meta.fork ? `<span class="chip sm muted">Fork</span>` : ""}
              ${meta.archived ? `<span class="chip sm" style="color:var(--red);">Archived</span>` : ""}
              ${meta.license ? `<span class="chip sm muted">${esc(meta.license)}</span>` : ""}
            </div>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
              <button type="button" class="btn sm ${E.starred ? "primary" : "ghost"}" id="ghx-star-btn">
                <span>${E.starred ? "★ Starred" : "☆ Star"}</span>
                <span class="chip sm">${meta.stargazers_count || 0}</span>
              </button>
              <button type="button" class="btn sm ghost" id="ghx-fork-btn">🍴 Fork (${meta.forks_count || 0})</button>
              <button type="button" class="btn sm ghost" id="ghx-clone-repo">${icon("download")}<span>Clone</span></button>
              <button type="button" class="btn sm" id="ghx-open-web">${icon("globe")}<span>Live GitHub Web</span></button>
            </div>
          </div>

          ${meta.description ? `<p class="muted sm" style="margin:10px 0 0 0;">${esc(meta.description)}</p>` : ""}
          ${E.languages.length ? `
            <div class="gh-lang-bar" title="${esc(E.languages.map((l) => `${l.name} ${l.pct}%`).join(" · "))}">
              ${E.languages.map((l) => {
                const col = LANG_COLORS[l.name] || "#8b949e";
                return `<span style="width:${Math.max(1, (l.bytes / totalLangBytes) * 100)}%;background:${col};"></span>`;
              }).join("")}
            </div>
            <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:6px;font-size:11px;" class="muted">
              ${E.languages.slice(0, 6).map((l) => `<span><b style="color:${LANG_COLORS[l.name] || "var(--accent)"};">●</b> ${esc(l.name)} ${l.pct}%</span>`).join("")}
            </div>
          ` : ""}
        </div>

        <div class="gh-repo-subtabs">
          ${[
            ["code", "folder", window.t("gh_ws_code", "Code")],
            ["issues", "alert", `${window.t("gh_tab_issues", "Issues")} (${meta.open_issues_count ?? 0})`],
            ["pulls", "branch", window.t("gh_tab_pulls", "Pull Requests")],
            ["actions", "play", window.t("gh_tab_actions", "Actions")],
            ["cicd", "rocket", window.t("gh_ws_cicd", "CI/CD & VPS")],
            ["commits", "git", window.t("gh_ws_commits", "Commits & Compare")],
            ["releases", "tag", window.t("gh_ws_releases", "Releases")],
            ["settings", "settings", window.t("gh_ws_settings", "Security & Settings")],
          ].map(([key, ic, label]) => `
            <button type="button" class="tab-btn ${E.repoSubTab === key ? "active" : ""}" data-ghxtab="${key}">
              ${icon(ic)}<span>${esc(label)}</span>
            </button>
          `).join("")}
        </div>

        ${E.loading ? `<div class="card" style="padding:28px;text-align:center;"><span class="muted">${icon("refresh", "spin")} Loading…</span></div>` : ""}

        <div class="gh-repo-stage">
          ${E.repoSubTab === "code" ? renderCodeTab() : ""}
          ${E.repoSubTab === "cicd" ? renderCicdTab() : ""}
          ${E.repoSubTab === "commits" ? renderCommitsTab() : ""}
          ${E.repoSubTab === "releases" ? renderReleasesTab() : ""}
          ${E.repoSubTab === "settings" ? renderRepoSettingsTab(meta) : ""}
          ${E.repoSubTab === "pulls" ? (E.activePRNumber ? renderPRDetail() : helpers.renderPullsTab()) : ""}
          ${E.repoSubTab === "issues" ? (E.activeIssueNumber ? renderIssueDetail() : helpers.renderIssuesTab()) : ""}
          ${E.repoSubTab === "actions" ? (E.activeRunId ? renderRunDetail() : helpers.renderActionsTab()) : ""}
        </div>
      </div>
    `;
  }

  function renderCodeTab() {
    const segs = E.currentPath ? E.currentPath.split("/") : [];
    const breadcrumbs = [
      `<button type="button" class="btn xs ghost ghx-path-crumb" data-path="">${esc(splitRepo(E.activeRepo)[1])}</button>`,
      ...segs.map((seg, i) => {
        const sub = segs.slice(0, i + 1).join("/");
        return `<span class="muted">/</span><button type="button" class="btn xs ghost ghx-path-crumb" data-path="${esc(sub)}">${esc(seg)}</button>`;
      }),
    ].join("");

    const q = (E.treeFilter || "").trim().toLowerCase();
    const visibleTree = (q
      ? E.treeItems.filter((it) => (it.path || "").toLowerCase().includes(q))
      : E.treeItems
    ).slice(0, 120);

    return `
      <div style="display:flex;flex-direction:column;gap:12px;">
        <div class="card gh-code-toolbar">
          <div class="gh-code-toolbar-left">
            <button type="button" class="btn sm ghost" id="ghx-toggle-tree" title="${esc(window.t ? window.t("gh_toggle_tree", "Toggle File Tree") : "Toggle File Tree")}">
              ${icon("folder")}<span>${esc(window.t ? window.t("gh_tree_btn", "Files") : "Files")}</span>
            </button>
            <select id="ghx-ref-select" class="input sm" style="width:170px;">
              ${E.branches.map((b) => `<option value="${esc(b)}" ${b === E.currentRef ? "selected" : ""}>🌿 ${esc(b)}</option>`).join("")}
            </select>
            <div class="gh-breadcrumbs">${breadcrumbs}</div>
          </div>
          <div style="display:flex;gap:8px;">
            <button type="button" class="btn sm primary" id="ghx-new-file-btn">${icon("plus")}<span>New File</span></button>
          </div>
        </div>

        <div class="gh-code-grid ${E.treeHidden ? "tree-collapsed" : ""}">
          ${E.treeHidden ? "" : `
            <aside class="card gh-tree-sidebar">
              <input type="text" id="ghx-tree-filter" class="input sm" placeholder="Find file in repo…" value="${esc(E.treeFilter)}" style="margin-bottom:8px;" />
              <div class="gh-tree-list">
                ${visibleTree.length ? visibleTree.map((item) => `
                  <button type="button" class="gh-tree-item ${E.currentPath === item.path ? "active" : ""}" data-tree-path="${esc(item.path)}" title="${esc(item.path)}">
                    <span>${item.type === "tree" ? "📁" : "📄"}</span>
                    <span>${esc(item.path)}</span>
                  </button>
                `).join("") : `<div class="muted sm" style="padding:8px;">Tree index empty</div>`}
              </div>
            </aside>
          `}

          <div style="display:flex;flex-direction:column;gap:14px;min-width:0;">
            ${E.newFileMode ? renderFileEditor({ path: E.currentPath ? `${E.currentPath}/new-file.txt` : "new-file.txt", content: "", sha: "", isNew: true }) :
              E.fileData ? renderFileViewer(E.fileData) : renderDirectoryTable()}

            ${!E.fileData && !E.newFileMode && E.readmeData ? `
              <div class="card" style="padding:18px;">
                <div style="font-weight:600;font-size:13px;padding-bottom:10px;margin-bottom:12px;border-bottom:1px solid var(--border);">
                  📖 ${esc(E.readmeData.name || "README.md")}
                </div>
                <div class="gh-markdown-body">
                  ${E.readmeData.html ? sanitizeHtml(E.readmeData.html) : renderPlainMarkdownFallback(E.readmeData.content)}
                </div>
              </div>
            ` : ""}
          </div>
        </div>
      </div>
    `;
  }

  function renderDirectoryTable() {
    const parentPath = E.currentPath.includes("/") ? E.currentPath.slice(0, E.currentPath.lastIndexOf("/")) : "";
    return `
      <div class="card gh-dir-card">
        <table class="gh-files-table">
          <tbody>
            ${E.currentPath ? `
              <tr class="ghx-entry-row" data-path="${esc(parentPath)}" style="cursor:pointer;">
                <td colspan="3">.. (Parent Directory)</td>
              </tr>
            ` : ""}
            ${E.dirEntries.map((ent) => `
              <tr class="ghx-entry-row" data-path="${esc(ent.path)}" style="cursor:pointer;">
                <td style="width:28px;">${ent.type === "dir" ? "📁" : "📄"}</td>
                <td style="font-weight:${ent.type === "dir" ? "600" : "400"};">${esc(ent.name)}</td>
                <td class="muted sm" style="text-align:end;">${ent.type === "file" ? `${ent.size} B` : "dir"}</td>
              </tr>
            `).join("")}
            ${!E.dirEntries.length ? `<tr><td colspan="3" class="muted sm" style="padding:18px;text-align:center;">Empty directory</td></tr>` : ""}
          </tbody>
        </table>
      </div>
    `;
  }

  function renderFileViewer(file) {
    if (E.editingFile) {
      return renderFileEditor({ path: file.path, content: file.content || "", sha: file.sha || "", isNew: false });
    }
    const lines = String(file.content || "").split("\n");
    return `
      <div class="card" style="overflow:hidden;">
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:var(--surface-2,rgba(0,0,0,0.03));border-bottom:1px solid var(--border);gap:8px;flex-wrap:wrap;">
          <div style="font-family:var(--mono);font-size:12px;">
            <b>${esc(file.name)}</b> · <span class="muted">${lines.length} lines · ${file.size} bytes</span>
          </div>
          <div style="display:flex;gap:6px;">
            ${!file.is_binary ? `<button type="button" class="btn xs primary" id="ghx-edit-file-btn">${icon("edit")}<span>Edit & Commit</span></button>` : ""}
            <button type="button" class="btn xs ghost" id="ghx-delete-file-btn" style="color:var(--red);">${icon("trash")}<span>Delete</span></button>
          </div>
        </div>
        ${file.is_binary ? `
          <div style="padding:28px;text-align:center;" class="muted">Binary file cannot be previewed (${file.size} bytes).</div>
        ` : file.is_markdown && file.renderedHtml ? `
          <div class="gh-markdown-body" style="padding:18px;">${sanitizeHtml(file.renderedHtml)}</div>
        ` : `
          <div class="gh-code-scroll">
            <table class="gh-code-table"><tbody>
              ${lines.map((ln, idx) => `<tr><td class="gh-ln">${idx + 1}</td><td class="gh-lc">${esc(ln)}</td></tr>`).join("")}
            </tbody></table>
          </div>
        `}
      </div>
    `;
  }

  function renderFileEditor(cfg) {
    return `
      <form id="ghx-file-editor-form" class="card" style="padding:16px;display:flex;flex-direction:column;gap:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <b>${cfg.isNew ? "Create New File" : `Editing ${esc(cfg.path)}`}</b>
          <button type="button" class="btn xs ghost" id="ghx-cancel-file-edit">Cancel</button>
        </div>
        <input type="text" id="ghx-file-path-input" class="input sm" value="${esc(cfg.path)}" placeholder="path/to/file.php" required style="font-family:var(--mono);" ${cfg.isNew ? "" : "readonly"} />
        <textarea id="ghx-file-content-input" class="input" rows="16" style="font-family:var(--mono);font-size:12px;line-height:1.45;">${esc(cfg.content)}</textarea>
        <input type="text" id="ghx-file-msg-input" class="input sm" value="${esc(cfg.isNew ? "Create file via Laravel Dev" : `Update ${cfg.path}`)}" placeholder="Commit message" required />
        <input type="hidden" id="ghx-file-sha-input" value="${esc(cfg.sha)}" />
        <div style="display:flex;justify-content:flex-end;gap:8px;">
          <button type="submit" class="btn sm primary">${icon("check")}<span>Commit Changes to ${esc(E.currentRef)}</span></button>
        </div>
      </form>
    `;
  }

  // ── Render: Issue Thread Detail ─────────────────────────────────────────

  function renderIssueDetail() {
    const iss = E.issueDetail;
    if (!iss) return `<div class="card" style="padding:20px;">Issue not loaded.</div>`;
    const isOpen = iss.state === "open";
    return `
      <div style="display:flex;flex-direction:column;gap:14px;">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
          <button type="button" class="btn sm ghost" id="ghx-back-issues">${icon("arrow_left")}<span>Back to Issues</span></button>
          <div style="display:flex;gap:8px;">
            <button type="button" class="btn sm ghost" id="ghx-edit-issue-btn">${icon("edit")}<span>Edit</span></button>
            <button type="button" class="btn sm ${isOpen ? "ghost" : "primary"}" id="ghx-toggle-issue-state" data-next="${isOpen ? "closed" : "open"}">
              ${isOpen ? "Close Issue" : "Reopen Issue"}
            </button>
            <a href="${esc(iss.html_url)}" target="_blank" rel="noopener noreferrer" class="btn sm ghost">${icon("browser")}<span>Open Web</span></a>
          </div>
        </div>

        <div class="card" style="padding:18px;">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px;">
            <span class="chip sm" style="color:var(--${isOpen ? "green" : "red"});">${esc(iss.state)}</span>
            <h2 style="margin:0;font-size:18px;">${esc(iss.title)} <span class="muted">#${iss.number}</span></h2>
          </div>
          <div class="muted sm" style="margin-bottom:12px;">
            Opened by <b>${esc(iss.user)}</b> on ${(iss.created_at || "").slice(0, 10)} · ${iss.comments || 0} comment(s)
            ${(iss.labels || []).map((lb) => `<span class="chip sm" style="margin-inline-start:6px;">${esc(lb.name)}</span>`).join("")}
          </div>
          <div class="gh-markdown-body" style="padding-top:12px;border-top:1px solid var(--border);">
            ${renderPlainMarkdownFallback(iss.body || "(No description provided)")}
          </div>
        </div>

        ${E.issueComments.map((c) => `
          <div class="card" style="padding:14px 16px;">
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:12px;">
              <b>${esc(c.user)}</b>
              <span class="muted">${(c.created_at || "").replace("T", " ").slice(0, 16)}</span>
            </div>
            <div class="gh-markdown-body">${renderPlainMarkdownFallback(c.body)}</div>
          </div>
        `).join("")}

        <form id="ghx-issue-comment-form" class="card" style="padding:16px;display:flex;flex-direction:column;gap:10px;">
          <textarea id="ghx-issue-comment-body" class="input" rows="4" placeholder="Write a comment (Markdown supported)…" required></textarea>
          <div style="display:flex;justify-content:flex-end;">
            <button type="submit" class="btn sm primary">${icon("check")}<span>Comment</span></button>
          </div>
        </form>
      </div>
    `;
  }

  // ── Render: Pull Request Inspector ──────────────────────────────────────

  function renderPRDetail() {
    const pr = E.prDetail;
    if (!pr) return `<div class="card" style="padding:20px;">Pull Request not loaded.</div>`;
    const isOpen = pr.state === "open";
    const statusLabel = pr.merged ? "Merged" : pr.state;
    const statusColor = pr.merged ? "#a855f7" : isOpen ? "var(--green)" : "var(--red)";

    return `
      <div style="display:flex;flex-direction:column;gap:14px;">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
          <button type="button" class="btn sm ghost" id="ghx-back-pulls">${icon("arrow_left")}<span>Back to Pull Requests</span></button>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            ${isOpen ? `
              <button type="button" class="btn sm ghost" id="ghx-pr-update-branch">↻ Update Branch</button>
              <button type="button" class="btn sm primary" id="ghx-pr-merge-btn">${icon("check")}<span>Merge PR</span></button>
              <button type="button" class="btn sm ghost" id="ghx-pr-close-btn" style="color:var(--red);">Close PR</button>
            ` : ""}
            <a href="${esc(pr.html_url)}" target="_blank" rel="noopener noreferrer" class="btn sm ghost">${icon("browser")}<span>Open Web</span></a>
          </div>
        </div>

        <div class="card" style="padding:18px;">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            <span class="chip sm" style="color:${statusColor};text-transform:capitalize;">${esc(statusLabel)}</span>
            <h2 style="margin:0;font-size:18px;">${esc(pr.title)} <span class="muted">#${pr.number}</span></h2>
          </div>
          <div class="muted sm" style="margin-top:8px;display:flex;gap:10px;flex-wrap:wrap;">
            <span><b>${esc(pr.user)}</b> wants to merge <code>${esc(pr.head)}</code> → <code>${esc(pr.base)}</code></span>
            <span style="color:var(--green);">+${pr.additions || 0}</span>
            <span style="color:var(--red);">-${pr.deletions || 0}</span>
            <span>${pr.changed_files || 0} file(s)</span>
            ${pr.mergeable_state ? `<span class="chip sm">Mergeability: ${esc(pr.mergeable_state)}</span>` : ""}
          </div>
        </div>

        <div class="gh-repo-subtabs">
          <button type="button" class="tab-btn ${E.prSubTab === "conversation" ? "active" : ""}" data-prsub="conversation">Conversation (${E.prComments.length + E.prReviews.length})</button>
          <button type="button" class="tab-btn ${E.prSubTab === "commits" ? "active" : ""}" data-prsub="commits">Commits (${E.prCommits.length})</button>
          <button type="button" class="tab-btn ${E.prSubTab === "checks" ? "active" : ""}" data-prsub="checks">Checks (${E.prChecks.length})</button>
          <button type="button" class="tab-btn ${E.prSubTab === "files" ? "active" : ""}" data-prsub="files">Files Changed (${E.prFiles.length})</button>
        </div>

        ${E.prSubTab === "conversation" ? `
          <div style="display:flex;flex-direction:column;gap:12px;">
            <div class="card" style="padding:16px;">
              <b style="font-size:12px;" class="muted">Description</b>
              <div style="margin-top:8px;">${renderPlainMarkdownFallback(pr.body || "(No description provided)")}</div>
            </div>

            ${E.prReviews.map((rv) => `
              <div class="card" style="padding:12px 16px;border-inline-start:3px solid ${rv.state === "APPROVED" ? "var(--green)" : rv.state === "CHANGES_REQUESTED" ? "var(--red)" : "var(--accent)"};">
                <div style="font-size:12px;margin-bottom:4px;"><b>${esc(rv.user)}</b> reviewed: <span class="chip sm">${esc(rv.state)}</span></div>
                ${rv.body ? `<div>${renderPlainMarkdownFallback(rv.body)}</div>` : ""}
              </div>
            `).join("")}

            ${E.prComments.map((c) => `
              <div class="card" style="padding:12px 16px;">
                <div style="font-size:12px;margin-bottom:6px;"><b>${esc(c.user)}</b> <span class="muted">${(c.created_at || "").replace("T", " ").slice(0, 16)}</span></div>
                <div>${renderPlainMarkdownFallback(c.body)}</div>
              </div>
            `).join("")}

            <form id="ghx-pr-review-form" class="card" style="padding:16px;display:flex;flex-direction:column;gap:10px;">
              <textarea id="ghx-pr-comment-body" class="input" rows="4" placeholder="Leave a PR comment or review summary…"></textarea>
              <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
                <select id="ghx-pr-review-event" class="input sm" style="width:200px;">
                  <option value="COMMENT_ONLY">Comment Only</option>
                  <option value="APPROVE">Review: Approve</option>
                  <option value="REQUEST_CHANGES">Review: Request Changes</option>
                  <option value="COMMENT">Review: General Comment</option>
                </select>
                <button type="submit" class="btn sm primary">${icon("check")}<span>Submit</span></button>
              </div>
            </form>
          </div>
        ` : ""}

        ${E.prSubTab === "commits" ? `
          <div style="display:flex;flex-direction:column;gap:8px;">
            ${E.prCommits.map((c) => `
              <div class="card" style="padding:12px 16px;display:flex;justify-content:space-between;gap:10px;">
                <div><b>${esc(c.headline)}</b><div class="muted sm">${esc(c.author_name)} · ${(c.date || "").slice(0, 10)}</div></div>
                <code class="chip sm">${esc(c.short_sha)}</code>
              </div>
            `).join("")}
          </div>
        ` : ""}

        ${E.prSubTab === "checks" ? `
          <div style="display:flex;flex-direction:column;gap:8px;">
            ${E.prChecks.length ? E.prChecks.map((ck) => `
              <div class="card" style="padding:12px 16px;display:flex;justify-content:space-between;align-items:center;">
                <div><b>${esc(ck.name)}</b> <span class="muted sm">${esc(ck.app_name)}</span></div>
                <div style="display:flex;gap:8px;align-items:center;">
                  <span class="chip sm" style="color:${ck.conclusion === "success" ? "var(--green)" : ck.conclusion === "failure" ? "var(--red)" : "var(--accent)"};">${esc(ck.conclusion || ck.status)}</span>
                  ${ck.html_url ? `<a href="${esc(ck.html_url)}" target="_blank" rel="noopener noreferrer" class="btn xs ghost">${icon("browser")}</a>` : ""}
                </div>
              </div>
            `).join("") : `<div class="card" style="padding:20px;" class="muted">No check runs reported for this commit.</div>`}
          </div>
        ` : ""}

        ${E.prSubTab === "files" ? `
          <div style="display:flex;flex-direction:column;gap:10px;">
            <div style="display:flex;justify-content:flex-end;gap:6px;">
              <button type="button" class="btn xs ${E.diffMode === "unified" ? "primary" : "ghost"}" data-diffmode="unified">Unified</button>
              <button type="button" class="btn xs ${E.diffMode === "split" ? "primary" : "ghost"}" data-diffmode="split">Split</button>
            </div>
            ${window.DiffViewer ? window.DiffViewer.renderFiles(E.prFiles, { mode: E.diffMode }) : ""}
          </div>
        ` : ""}
      </div>
    `;
  }

  // ── Render: Actions Workflow Run & Job Logs ─────────────────────────────

  function renderRunDetail() {
    return `
      <div style="display:flex;flex-direction:column;gap:14px;">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
          <button type="button" class="btn sm ghost" id="ghx-back-actions">${icon("arrow_left")}<span>Back to Workflow Runs</span></button>
          <div style="display:flex;gap:8px;">
            <button type="button" class="btn sm" id="ghx-rerun-all">↻ Re-run All Jobs</button>
            <button type="button" class="btn sm ghost" id="ghx-rerun-failed">↻ Re-run Failed</button>
            <button type="button" class="btn sm ghost" id="ghx-cancel-run" style="color:var(--red);">Cancel Run</button>
          </div>
        </div>

        <div class="gh-code-grid">
          <div style="display:flex;flex-direction:column;gap:10px;">
            ${E.runJobs.map((job) => `
              <div class="card" style="padding:14px;">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px;">
                  <b>${esc(job.name)}</b>
                  <span class="chip sm" style="color:${job.conclusion === "success" ? "var(--green)" : job.conclusion === "failure" ? "var(--red)" : "var(--accent)"};">${esc(job.conclusion || job.status)}</span>
                </div>
                <div style="display:flex;flex-direction:column;gap:4px;font-size:12px;">
                  ${(job.steps || []).map((st) => `
                    <div style="display:flex;justify-content:space-between;" class="muted">
                      <span>${st.conclusion === "success" ? "✔" : st.conclusion === "failure" ? "✖" : "•"} ${esc(st.name)}</span>
                      <span>${esc(st.conclusion || st.status || "")}</span>
                    </div>
                  `).join("")}
                </div>
                <div style="margin-top:10px;">
                  <button type="button" class="btn xs primary ghx-load-job-logs" data-job="${job.id}">📄 View Raw Log</button>
                </div>
              </div>
            `).join("")}

            ${E.runArtifacts.length ? `
              <div class="card" style="padding:14px;">
                <b style="display:block;margin-bottom:8px;">Artifacts (${E.runArtifacts.length})</b>
                ${E.runArtifacts.map((art) => `<div class="muted sm">📦 ${esc(art.name)} (${Math.round((art.size_in_bytes || 0) / 1024)} KB)</div>`).join("")}
              </div>
            ` : ""}
          </div>

          <div class="card" style="padding:14px;display:flex;flex-direction:column;">
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
              <b>Job Logs ${E.selectedJobId ? `#${E.selectedJobId}` : ""}</b>
              ${E.jobLogsTruncated ? `<span class="chip sm">Truncated at 512KB</span>` : ""}
            </div>
            <pre class="gh-log-viewer">${esc(E.jobLogs || "Select a job on the left and click 'View Raw Log' to inspect live step output.")}</pre>
          </div>
        </div>
      </div>
    `;
  }

  // ── Render: Commits & Compare ───────────────────────────────────────────

  function renderCommitsTab() {
    if (E.selectedCommit) {
      const c = E.selectedCommit;
      return `
        <div style="display:flex;flex-direction:column;gap:12px;">
          <button type="button" class="btn sm ghost" id="ghx-back-commits" style="align-self:flex-start;">${icon("arrow_left")}<span>Back to Commits</span></button>
          <div class="card" style="padding:16px;">
            <h3 style="margin:0 0 6px 0;">${esc(c.headline)}</h3>
            <div class="muted sm"><code>${esc(c.sha)}</code> by <b>${esc(c.author_name)}</b> · +${c.stats?.additions || 0} / -${c.stats?.deletions || 0}</div>
          </div>
          ${window.DiffViewer ? window.DiffViewer.renderFiles(c.files || [], { mode: E.diffMode }) : ""}
        </div>
      `;
    }

    return `
      <div style="display:flex;flex-direction:column;gap:14px;">
        <div class="card" style="padding:14px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
          <b>Compare Branches:</b>
          <select id="ghx-compare-base" class="input sm" style="width:180px;">
            ${E.branches.map((b) => `<option value="${esc(b)}" ${b === E.compareBase ? "selected" : ""}>base: ${esc(b)}</option>`).join("")}
          </select>
          <span>...</span>
          <select id="ghx-compare-head" class="input sm" style="width:180px;">
            ${E.branches.map((b) => `<option value="${esc(b)}" ${b === E.compareHead ? "selected" : ""}>head: ${esc(b)}</option>`).join("")}
          </select>
          <button type="button" class="btn sm primary" id="ghx-run-compare">Compare</button>
        </div>

        ${E.compareResult ? `
          <div class="card" style="padding:16px;display:flex;flex-direction:column;gap:12px;">
            <div><b>Comparison (${E.compareResult.status})</b> — Ahead by ${E.compareResult.ahead_by}, Behind by ${E.compareResult.behind_by} · ${E.compareResult.total_commits} commits</div>
            ${window.DiffViewer ? window.DiffViewer.renderFiles(E.compareResult.files || [], { mode: E.diffMode }) : ""}
          </div>
        ` : ""}

        <div style="display:flex;flex-direction:column;gap:8px;">
          ${E.commits.map((c) => `
            <div class="card" style="padding:12px 16px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
              <div>
                <a href="#" class="ghx-open-commit" data-sha="${esc(c.sha)}" style="font-weight:600;color:var(--text);text-decoration:none;">${esc(c.headline)}</a>
                <div class="muted sm">${esc(c.author_name)} · ${(c.date || "").replace("T", " ").slice(0, 16)}</div>
              </div>
              <button type="button" class="btn xs ghost ghx-open-commit" data-sha="${esc(c.sha)}"><code>${esc(c.short_sha)}</code></button>
            </div>
          `).join("")}
        </div>
        ${E.contributors.length ? `
          <div class="card" style="padding:14px;">
            <div class="muted sm" style="margin-bottom:8px;font-weight:600;">Top Contributors (${E.contributors.length})</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              ${E.contributors.slice(0, 12).map((ct) => `<span class="chip sm">${esc(ct.login)} (${ct.contributions || 0})</span>`).join("")}
            </div>
          </div>
        ` : ""}
      </div>
    `;
  }

  // ── Render: Releases & Tags ─────────────────────────────────────────────

  function renderReleasesTab() {
    return `
      <div style="display:flex;flex-direction:column;gap:14px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <h3 style="margin:0;">Releases (${E.releases.length}) · Tags (${E.tags.length})</h3>
          <button type="button" class="btn sm primary" id="ghx-new-release-btn">${icon("plus")}<span>Draft New Release</span></button>
        </div>

        ${E.releases.length ? E.releases.map((rel) => `
          <div class="card" style="padding:16px;">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
              <div>
                <span class="chip sm" style="font-family:var(--mono);">${esc(rel.tag_name)}</span>
                <b style="margin-inline-start:8px;">${esc(rel.name)}</b>
                ${rel.prerelease ? `<span class="chip sm" style="color:var(--accent);">Pre-release</span>` : ""}
                ${rel.draft ? `<span class="chip sm muted">Draft</span>` : ""}
              </div>
              <div style="display:flex;gap:8px;">
                <a href="${esc(rel.html_url)}" target="_blank" rel="noopener noreferrer" class="btn xs ghost">${icon("browser")}</a>
                <button type="button" class="btn xs ghost ghx-del-release" data-id="${rel.id}" style="color:var(--red);">${icon("trash")}</button>
              </div>
            </div>
            ${rel.body ? `<div style="margin-top:10px;">${renderPlainMarkdownFallback(rel.body)}</div>` : ""}
            ${rel.assets?.length ? `<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">${rel.assets.map((a) => `<a href="${esc(a.browser_download_url)}#external" class="chip sm">⬇ ${esc(a.name)}</a>`).join("")}</div>` : ""}
          </div>
        `).join("") : `<div class="card" style="padding:24px;text-align:center;" class="muted">No releases published yet.</div>`}
      </div>
    `;
  }

  // ── Render: Security, Webhooks, Deploy Keys & Repo Settings ─────────────

  function renderRepoSettingsTab(meta) {
    return `
      <div style="display:flex;flex-direction:column;gap:16px;">
        <div class="card" style="padding:18px;">
          <h3 style="margin:0 0 12px 0;">🛡 Dependabot Security Alerts (${E.securityAlerts.length})</h3>
          ${E.securityError ? `<div class="muted sm">${esc(E.securityError)}</div>` :
            E.securityAlerts.length ? E.securityAlerts.map((al) => `
              <div style="padding:10px 0;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;gap:10px;">
                <div><b>#${al.number} ${esc(al.summary || al.package_name)}</b><div class="muted sm">${esc(al.package_name)} · ${esc(al.cve_id || al.ghsa_id)}</div></div>
                <span class="chip sm" style="color:${al.severity === "critical" || al.severity === "high" ? "var(--red)" : "var(--accent)"};">${esc(al.severity)}</span>
              </div>
            `).join("") : `<div class="muted sm">✔ No open Dependabot alerts.</div>`}
        </div>

        <form id="ghx-repo-settings-form" class="card" style="padding:18px;display:flex;flex-direction:column;gap:12px;">
          <h3 style="margin:0;">⚙ Repository Settings</h3>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;">
            <div>
              <label class="muted sm">Description</label>
              <input type="text" id="ghx-set-desc" class="input sm" value="${esc(meta.description || "")}" />
            </div>
            <div>
              <label class="muted sm">Homepage URL</label>
              <input type="url" id="ghx-set-home" class="input sm" value="${esc(meta.homepage || "")}" />
            </div>
            <div>
              <label class="muted sm">Default Branch</label>
              <select id="ghx-set-branch" class="input sm">
                ${E.branches.map((b) => `<option value="${esc(b)}" ${b === meta.default_branch ? "selected" : ""}>${esc(b)}</option>`).join("")}
              </select>
            </div>
          </div>
          <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:13px;">
            <label><input type="checkbox" id="ghx-set-private" ${meta.private ? "checked" : ""} /> Private</label>
            <label><input type="checkbox" id="ghx-set-issues" ${meta.has_issues !== false ? "checked" : ""} /> Issues</label>
            <label><input type="checkbox" id="ghx-set-wiki" ${meta.has_wiki ? "checked" : ""} /> Wiki</label>
          </div>
          <div><button type="submit" class="btn sm primary">Save Repository Settings</button></div>
        </form>

        <div class="card" style="padding:18px;display:flex;flex-direction:column;gap:12px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <h3 style="margin:0;">🔗 Webhooks (${E.hooks.length})</h3>
            <button type="button" class="btn xs primary" id="ghx-add-hook-btn">${icon("plus")}<span>Add Webhook</span></button>
          </div>
          ${E.hooks.length ? E.hooks.map((h) => `
            <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--border);padding-top:8px;">
              <div><code style="font-size:12px;">${esc(h.url)}</code> <span class="muted sm">(${esc((h.events || []).join(", "))})</span></div>
              <button type="button" class="btn xs ghost ghx-del-hook" data-id="${h.id}" style="color:var(--red);">${icon("trash")}</button>
            </div>
          `).join("") : `<div class="muted sm">No webhooks configured.</div>`}
        </div>

        <div class="card" style="padding:18px;display:flex;flex-direction:column;gap:12px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <h3 style="margin:0;">🔑 Deploy Keys (${E.deployKeys.length}) & Collaborators (${E.collaborators.length})</h3>
            <button type="button" class="btn xs primary" id="ghx-add-dkey-btn">${icon("plus")}<span>Add Deploy Key</span></button>
          </div>
          ${E.deployKeys.map((dk) => `
            <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--border);padding-top:8px;">
              <div><b>${esc(dk.title)}</b> <span class="chip sm">${dk.read_only ? "Read-Only" : "Read/Write"}</span></div>
              <button type="button" class="btn xs ghost ghx-del-dkey" data-id="${dk.id}" style="color:var(--red);">${icon("trash")}</button>
            </div>
          `).join("")}
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;">
            ${E.collaborators.map((c) => `<span class="chip sm">${esc(c.login)}${c.role_name ? ` (${esc(c.role_name)})` : ""}</span>`).join("")}
          </div>
        </div>
      </div>
    `;
  }

  function renderCicdTab() {
    const caps = E.cicdCaps || {};
    const insp = E.cicdInspect || {};
    const f = E.cicdForm || {};
    const canSecrets = Boolean(caps.can_manage_secrets);
    const canVars = Boolean(caps.can_manage_variables);
    const canEnvs = Boolean(caps.can_manage_environments);
    const canWorkflows = Boolean(caps.can_edit_workflows);
    const canBind = canSecrets && canWorkflows && canVars;
    const roleLabel = caps.role || "unknown";
    const scopesText = (caps.scopes && caps.scopes.length) ? caps.scopes.join(", ") : "fine-grained / standard";
    const capPill = (ok, label) => `<span class="chip sm ${ok ? "ok" : "warn"}">${ok ? "✓" : "✕"} ${esc(label)}</span>`;

    const envTabs = [
      `<button type="button" class="btn xs ${E.cicdSelectedEnv === "" ? "primary" : "ghost"} ghx-env-pick" data-env="">${esc(window.t("gh_cicd_repo_scope", "Repository"))}</button>`,
      ...E.cicdEnvs.map((ev) => `
        <button type="button" class="btn xs ${E.cicdSelectedEnv === ev.name ? "primary" : "ghost"} ghx-env-pick" data-env="${esc(ev.name)}">
          ${esc(ev.name)}
        </button>
      `),
    ].join("");

    const serverOptions = E.cicdServers.length
      ? E.cicdServers.map((s) => `<option value="${esc(s.id)}" ${f.serverId === s.id ? "selected" : ""}>${esc(s.name)} (${esc(s.user ? `${s.user}@` : "")}${esc(s.host)})</option>`).join("")
      : `<option value="">— ${esc(window.t("gh_cicd_no_servers", "No SSH servers saved yet"))} —</option>`;

    const envSelectOpts = `<option value="">${esc(window.t("gh_cicd_no_env", "None (Repository level)"))}</option>`
      + E.cicdEnvs.map((ev) => `<option value="${esc(ev.name)}" ${f.environment === ev.name ? "selected" : ""}>${esc(ev.name)}</option>`).join("");

    return `
      <div style="display:flex;flex-direction:column;gap:16px;">
        <!-- A. Capabilities & Token Permissions Banner -->
        <div class="card gh-cap-banner ${canBind ? "ok" : "locked"}">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
              <strong>${icon("shield")} ${esc(window.t("gh_cicd_perms_title", "Repository & Token Permissions"))}</strong>
              <span class="chip sm">${esc(window.t("gh_cicd_role", "Role"))}: <b>${esc(roleLabel)}</b></span>
              <span class="muted sm">Scopes: <code class="mono">${esc(scopesText)}</code></span>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;">
              ${capPill(caps.can_push_code, "Push Code")}
              ${capPill(canWorkflows, "Workflows")}
              ${capPill(canSecrets, "Secrets")}
              ${capPill(canVars, "Variables")}
              ${capPill(canEnvs, "Environments")}
            </div>
          </div>
          ${(!canBind && caps.read_only_reason) ? `
            <div class="notice warn" style="margin-top:10px;">
              ${icon("alert")}
              <div>
                <b>${esc(window.t("gh_cicd_locked_title", "Restricted Access:"))}</b>
                ${esc(caps.read_only_reason)}
                ${(caps.missing_scopes && caps.missing_scopes.length) ? `<div class="muted sm" style="margin-top:4px;">Missing: <code>${esc(caps.missing_scopes.join(", "))}</code></div>` : ""}
              </div>
            </div>
          ` : ""}
        </div>

        <!-- B. 1-Click Connect GitHub CI/CD to Saved VPS -->
        <div class="card" style="padding:18px;">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px;">
            <div>
              <h3 style="margin:0;">${icon("rocket")} ${esc(window.t("gh_cicd_vps_title", "Connect Repo to VPS (1-Click CI/CD)"))}</h3>
              <p class="muted sm" style="margin:4px 0 0 0;">${esc(window.t("gh_cicd_vps_desc", "Generates a dedicated SSH deploy key, registers authorized_keys on your VPS, seals VPS_SSH_KEY & VPS_HOST in GitHub Secrets, saves DEPLOY_PATH/PORT Variables, and commits .github/workflows/laravel-dev-deploy.yml."))}</p>
            </div>
            ${insp.stack ? `<span class="chip ok">Detected: ${esc(insp.framework || insp.stack)}</span>` : ""}
          </div>

          <form id="ghx-vps-bind-form" style="display:flex;flex-direction:column;gap:12px;margin-top:12px;">
            <div class="grid-3">
              <label class="field" style="margin:0;"><span>${esc(window.t("gh_cicd_target_vps", "Target Saved VPS Server"))}</span>
                <select id="ghx-cicd-server" class="input sm" ${!canBind || !E.cicdServers.length ? "disabled" : ""}>${serverOptions}</select>
              </label>
              <label class="field" style="margin:0;"><span>${esc(window.t("srv_stack_label", "App Stack"))}</span>
                <select id="ghx-cicd-stack" class="input sm">
                  <option value="laravel" ${f.stack === "laravel" ? "selected" : ""}>Laravel / PHP</option>
                  <option value="node_ssr" ${f.stack === "node_ssr" ? "selected" : ""}>Node SSR (Next / Nuxt / Nest)</option>
                  <option value="static" ${f.stack === "static" ? "selected" : ""}>Static SPA (Vite / React / Vue)</option>
                  <option value="python" ${f.stack === "python" ? "selected" : ""}>Python (Django / FastAPI)</option>
                  <option value="docker" ${f.stack === "docker" ? "selected" : ""}>Docker / Compose</option>
                </select>
              </label>
              <label class="field" style="margin:0;"><span>${esc(window.t("gh_cicd_strategy", "Build & Deploy Strategy"))}</span>
                <select id="ghx-cicd-strategy" class="input sm">
                  <option value="ci_build_upload" ${f.strategy === "ci_build_upload" ? "selected" : ""}>${esc(window.t("gh_cicd_strat_upload", "Build on GitHub -> Upload Release"))}</option>
                  <option value="vps_git_pull" ${f.strategy === "vps_git_pull" ? "selected" : ""}>${esc(window.t("gh_cicd_strat_pull", "Trigger Git Pull on VPS"))}</option>
                </select>
              </label>
            </div>

            <div class="grid-3">
              <label class="field" style="margin:0;"><span>${esc(window.t("srv_domain_label", "Domain"))}</span>
                <input id="ghx-cicd-domain" class="input sm" value="${esc(f.domain || "")}" placeholder="app.example.com" spellcheck="false">
              </label>
              <label class="field" style="margin:0;"><span>${esc(window.t("gh_cicd_deploy_path", "VPS Deploy Path"))}</span>
                <input id="ghx-cicd-path" class="input sm mono" value="${esc(f.path || "")}" placeholder="/var/www/app" spellcheck="false">
              </label>
              <label class="field" style="margin:0;"><span>${esc(window.t("srv_branch_label", "Deploy Branch"))}</span>
                <select id="ghx-cicd-branch" class="input sm">
                  ${(E.branches.length ? E.branches : [f.branch || "main"]).map((b) => `<option value="${esc(b)}" ${b === f.branch ? "selected" : ""}>${esc(b)}</option>`).join("")}
                </select>
              </label>
            </div>

            <div class="grid-3">
              <label class="field" style="margin:0;"><span>${esc(window.t("srv_port_label", "Internal Port"))}</span>
                <input id="ghx-cicd-port" type="number" class="input sm mono" value="${esc(String(f.port || 3000))}">
              </label>
              <label class="field" style="margin:0;"><span>${esc(window.t("srv_health_path_label", "Health Check Path"))}</span>
                <input id="ghx-cicd-health" class="input sm mono" value="${esc(f.healthPath || "/")}" spellcheck="false">
              </label>
              <label class="field" style="margin:0;"><span>${esc(window.t("gh_cicd_target_env", "GitHub Environment (Optional)"))}</span>
                <select id="ghx-cicd-env" class="input sm">${envSelectOpts}</select>
              </label>
            </div>

            <label class="checkbox">
              <input type="checkbox" id="ghx-cicd-scaffold" ${f.scaffold !== false ? "checked" : ""}>
              <span>${esc(window.t("gh_cicd_scaffold_label", "Ensure releases/ and shared/ directories exist on the VPS"))}</span>
            </label>

            <details>
              <summary class="muted" style="cursor:pointer;font-size:13px;">${esc(window.t("gh_cicd_preview_yaml", "Preview / Edit .github/workflows/laravel-dev-deploy.yml"))}</summary>
              <div style="margin-top:8px;">
                <div style="display:flex;justify-content:flex-end;margin-bottom:6px;">
                  <button type="button" class="btn xs" id="ghx-cicd-refresh-yaml">${icon("refresh")} ${esc(window.t("gh_cicd_regenerate_yaml", "Regenerate Template"))}</button>
                </div>
                <textarea id="ghx-cicd-yaml-editor" class="input mono sm" rows="12" spellcheck="false">${esc(E.cicdPreviewYaml || "")}</textarea>
              </div>
            </details>

            <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
              <button type="submit" class="btn primary sm" id="ghx-cicd-bind-btn" ${(!canBind || !E.cicdServers.length) ? "disabled" : ""}>
                ${icon("zap")} <span>${esc(window.t("gh_cicd_bind_btn", "Bind Repo to VPS & Commit Workflow"))}</span>
              </button>
              ${!E.cicdServers.length ? `<span class="muted sm">${esc(window.t("gh_cicd_add_srv_hint", "Add an SSH server in the Servers tab first to enable 1-click binding."))}</span>` : ""}
            </div>
          </form>

          ${E.cicdLastResult ? `
            <div class="card" style="margin-top:12px;padding:12px;border-left:4px solid var(--ok);">
              <strong>${icon("check")} ${esc(window.t("gh_cicd_bind_done", "Connected to VPS!"))} (${esc(E.cicdLastResult.vps_host || "")})</strong>
              <ul style="margin:6px 0 0 18px;padding:0;font-size:12px;">
                ${(E.cicdLastResult.steps || []).map((st) => `<li>${esc(st)}</li>`).join("")}
              </ul>
              ${E.cicdLastResult.html_url ? `<a href="${esc(E.cicdLastResult.html_url)}" target="_blank" rel="noopener noreferrer" class="btn xs ghost" style="margin-top:8px;">${icon("browser")} View Workflow File</a>` : ""}
            </div>
          ` : ""}
        </div>

        <!-- C. Detected Repository Workflows -->
        ${(insp.workflows && insp.workflows.length) ? `
          <div class="card" style="padding:16px;">
            <h3 style="margin:0 0 10px 0;">${icon("play")} ${esc(window.t("gh_cicd_existing_wf", "Repository CI/CD Workflows"))}</h3>
            <div style="display:flex;flex-direction:column;gap:8px;">
              ${insp.workflows.map((wf) => `
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;border-top:1px solid var(--border);padding-top:8px;">
                  <div>
                    <strong>${esc(wf.name)}</strong>
                    <span class="mono muted sm" style="margin-inline-start:8px;">${esc(wf.path)}</span>
                  </div>
                  <div style="display:flex;gap:8px;align-items:center;">
                    <span class="chip sm ${wf.state === "active" ? "ok" : ""}">${esc(wf.state || "active")}</span>
                    <button type="button" class="btn xs primary ghx-dispatch-wf" data-wf="${esc(String(wf.id))}" ${!caps.can_push_code ? "disabled" : ""}>${icon("play")} Run</button>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>
        ` : ""}

        <!-- D. Env Keys Manager (Environments, Encrypted Secrets & Plain Variables) -->
        <div class="card" style="padding:18px;">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px;">
            <div>
              <h3 style="margin:0;">${icon("env")} ${esc(window.t("gh_cicd_envkeys_title", "CI/CD Env Keys (Secrets, Variables & Environments)"))}</h3>
              <p class="muted sm" style="margin:4px 0 0 0;">${esc(window.t("gh_cicd_envkeys_desc", "Manage sealed GitHub Actions Secrets (encrypted locally via Libsodium) and plain Variables per repository or environment."))}</p>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <button type="button" class="btn sm" id="ghx-env-create-btn" ${!canEnvs ? "disabled" : ""}>${icon("plus")} ${esc(window.t("gh_cicd_new_env", "New Environment"))}</button>
              ${E.cicdSelectedEnv ? `<button type="button" class="btn sm ghost danger" id="ghx-env-delete-btn" ${!canEnvs ? "disabled" : ""}>${icon("trash")} ${esc(window.t("delete", "Delete Env"))}</button>` : ""}
              <button type="button" class="btn sm primary" id="ghx-bulk-env-btn" ${(!canSecrets && !canVars) ? "disabled" : ""}>${icon("upload")} ${esc(window.t("gh_cicd_bulk_import", "Bulk Import .env"))}</button>
            </div>
          </div>

          <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px;">
            ${envTabs}
          </div>

          <div class="gh-envkeys-grid">
            <div class="card" style="padding:14px;">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                <h4 style="margin:0;">🔐 ${esc(window.t("gh_cicd_secrets_title", "Encrypted Secrets"))} (${E.cicdSecrets.length})</h4>
                <button type="button" class="btn xs primary" id="ghx-secret-add-btn" ${!canSecrets ? "disabled" : ""}>${icon("plus")} Add Secret</button>
              </div>
              ${!canSecrets ? `<p class="muted sm">${esc(window.t("gh_cicd_no_secret_perm", "Your role or token lacks permission to view or manage Secrets."))}</p>` :
                E.cicdSecrets.length ? E.cicdSecrets.map((s) => `
                  <div class="gh-kv-row">
                    <div>
                      <span class="mono font-semibold">${esc(s.name)}</span>
                      <div class="muted" style="font-size:11px;">•••••••• · ${esc((s.updated_at || "").slice(0, 10))}</div>
                    </div>
                    <div style="display:flex;gap:4px;">
                      <button type="button" class="btn xs ghost ghx-edit-secret" data-name="${esc(s.name)}" title="Rotate value">${icon("edit")}</button>
                      <button type="button" class="btn xs ghost danger ghx-del-secret" data-name="${esc(s.name)}" title="Delete">${icon("trash")}</button>
                    </div>
                  </div>
                `).join("") : `<p class="muted sm">No secrets defined in ${esc(E.cicdSelectedEnv || "repository")}.</p>`}
            </div>

            <div class="card" style="padding:14px;">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                <h4 style="margin:0;">📋 ${esc(window.t("gh_cicd_vars_title", "Plain Variables"))} (${E.cicdVariables.length})</h4>
                <button type="button" class="btn xs primary" id="ghx-var-add-btn" ${!canVars ? "disabled" : ""}>${icon("plus")} Add Variable</button>
              </div>
              ${!canVars ? `<p class="muted sm">${esc(window.t("gh_cicd_no_var_perm", "Your role or token lacks permission to view or manage Variables."))}</p>` :
                E.cicdVariables.length ? E.cicdVariables.map((v) => `
                  <div class="gh-kv-row">
                    <div style="min-width:0;overflow:hidden;">
                      <span class="mono font-semibold">${esc(v.name)}</span>
                      <div class="muted mono" style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${esc(v.value)}">${esc(v.value)}</div>
                    </div>
                    <div style="display:flex;gap:4px;flex-shrink:0;">
                      <button type="button" class="btn xs ghost ghx-edit-var" data-name="${esc(v.name)}" data-val="${esc(v.value)}" title="Edit">${icon("edit")}</button>
                      <button type="button" class="btn xs ghost danger ghx-del-var" data-name="${esc(v.name)}" title="Delete">${icon("trash")}</button>
                    </div>
                  </div>
                `).join("") : `<p class="muted sm">No plain variables defined in ${esc(E.cicdSelectedEnv || "repository")}.</p>`}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function openKvModal(kind, owner, repo, initName = "", initValue = "") {
    const isSecret = kind === "secret";
    openModal(`
      <form class="modal sm" id="ghx-kv-form">
        <div class="modal-header">
          <h2>${isSecret ? (initName ? "Update Secret" : "Add Encrypted Secret") : (initName ? "Update Variable" : "Add Plain Variable")}</h2>
          <p>${esc(owner)}/${esc(repo)}${E.cicdSelectedEnv ? ` · env: <b>${esc(E.cicdSelectedEnv)}</b>` : ""}</p>
        </div>
        <div class="modal-body">
          <label class="field"><span>Name (A-Z, 0-9, _)</span>
            <input name="name" class="input mono" value="${esc(initName)}" ${initName ? "readonly" : "required"} placeholder="MY_API_KEY" spellcheck="false">
          </label>
          <label class="field"><span>${isSecret ? "Secret Value (sealed locally via Libsodium)" : "Variable Value"}</span>
            <textarea name="value" class="input mono" rows="${isSecret ? 4 : 3}" required placeholder="${isSecret ? "Paste secret value…" : "Value…"}">${isSecret ? "" : esc(initValue)}</textarea>
          </label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>Cancel</button>
          <button type="submit" class="btn primary">Save</button>
        </div>
      </form>`, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      $("#ghx-kv-form", mRoot).addEventListener("submit", async (e) => {
        e.preventDefault();
        const f = e.target.elements;
        const name = f.name.value.trim().toUpperCase();
        const value = f.value.value;
        const method = isSecret ? "gh_secret_upsert" : "gh_variable_upsert";
        const res = await LD.call(method, { owner, repo, name, value, env: E.cicdSelectedEnv });
        if (res?.ok) {
          closeModal();
          toast("success", `${isSecret ? "Secret" : "Variable"} saved`, name);
          await loadCicdTabData(owner, repo);
          triggerRender();
        } else {
          toast("error", "Save failed", res?.error || "Check key name and token scopes.");
        }
      });
    });
  }

  function openBulkEnvModal(owner, repo) {
    const localSites = (window.state && window.state.sites) || [];
    const siteOpts = `<option value="">— Paste .env content below —</option>`
      + localSites.map((s) => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join("");

    openModal(`
      <div class="modal">
        <div class="modal-header">
          <h2>${icon("upload")} Bulk Import .env to GitHub Actions</h2>
          <p>${esc(owner)}/${esc(repo)}${E.cicdSelectedEnv ? ` · Target env: <b>${esc(E.cicdSelectedEnv)}</b>` : " · Target: Repository"}</p>
        </div>
        <div class="modal-body">
          <div class="grid-2" style="gap:8px;align-items:end;">
            <label class="field" style="margin:0;"><span>From Local Project</span>
              <select id="ghx-bulk-site" class="input sm">${siteOpts}</select>
            </label>
            <button type="button" class="btn sm primary" id="ghx-bulk-parse-btn">${icon("refresh")} Parse &amp; Classify</button>
          </div>
          <label class="field" style="margin-top:8px;"><span>Or Paste .env Content</span>
            <textarea id="ghx-bulk-text" class="input mono sm" rows="5" placeholder="APP_NAME=MyApp&#10;APP_KEY=base64:...&#10;DB_PASSWORD=secret"></textarea>
          </label>
          <div id="ghx-bulk-preview" style="margin-top:10px;">
            <p class="muted sm">Keys containing KEY, SECRET, PASS, TOKEN, or DATABASE_URL are automatically flagged as <b>Secret</b>.</p>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>Cancel</button>
          <button type="button" class="btn primary" id="ghx-bulk-import-btn" disabled>${icon("upload")} Import Selected to GitHub</button>
        </div>
      </div>`, (mRoot) => {
      $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
      const preview = $("#ghx-bulk-preview", mRoot);
      const importBtn = $("#ghx-bulk-import-btn", mRoot);
      let parsedItems = [];

      async function doParse() {
        const local_site = $("#ghx-bulk-site", mRoot).value;
        const env_text = $("#ghx-bulk-text", mRoot).value;
        const res = await LD.call("gh_env_bulk_parse", { local_site, env_text });
        if (!res?.ok || !res.items?.length) {
          preview.innerHTML = `<p class="muted sm">No valid .env keys found.</p>`;
          importBtn.disabled = true;
          parsedItems = [];
          return;
        }
        parsedItems = res.items;
        preview.innerHTML = `
          <table class="files" style="width:100%;">
            <thead><tr><th>Key</th><th>Value Preview</th><th>Destination</th></tr></thead>
            <tbody>
              ${parsedItems.map((it, idx) => `
                <tr>
                  <td class="mono">${esc(it.key)}</td>
                  <td class="mono muted" style="font-size:11px;">${it.kind === "secret" ? "••••••" : esc(String(it.value).slice(0, 28))}</td>
                  <td>
                    <select class="input sm ghx-bulk-kind" data-idx="${idx}">
                      <option value="secret" ${it.kind === "secret" ? "selected" : ""}>🔐 Secret</option>
                      <option value="variable" ${it.kind === "variable" ? "selected" : ""}>📋 Variable</option>
                      <option value="skip">Skip</option>
                    </select>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>`;
        importBtn.disabled = false;
      }

      $("#ghx-bulk-parse-btn", mRoot).addEventListener("click", doParse);
      $("#ghx-bulk-site", mRoot).addEventListener("change", () => { if ($("#ghx-bulk-site", mRoot).value) doParse(); });
      importBtn.addEventListener("click", async () => {
        mRoot.querySelectorAll(".ghx-bulk-kind").forEach((sel) => {
          const i = +sel.dataset.idx;
          if (parsedItems[i]) parsedItems[i].kind = sel.value;
        });
        importBtn.disabled = true;
        const res = await LD.call("gh_env_bulk_import", { owner, repo, env: E.cicdSelectedEnv, items: parsedItems });
        if (res?.ok) {
          closeModal();
          toast("success", "Bulk import complete", `${(res.secrets_saved || []).length} secrets, ${(res.variables_saved || []).length} variables saved.`);
          await loadCicdTabData(owner, repo);
          triggerRender();
        } else {
          importBtn.disabled = false;
          toast("error", "Bulk import error", (res?.errors || []).join("; ") || res?.error || "Failed");
        }
      });
    });
  }

  // ── Global Tabs Renderers ───────────────────────────────────────────────

  function renderFeedSection(username = "") {
    if (username && E.eventsLoadedFor !== username) {
      loadFeed(username);
    }
    return `
      <div class="card" style="padding:18px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
          <h3 style="margin:0;font-size:15px;">Recent GitHub Activity Feed</h3>
          <button type="button" class="btn xs ghost" id="ghx-refresh-feed">${icon("refresh")}<span>Refresh</span></button>
        </div>
        ${E.events.length ? `
          <div style="display:flex;flex-direction:column;gap:8px;">
            ${E.events.slice(0, 15).map((ev) => `
              <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);font-size:13px;">
                <div>
                  <b>${esc(ev.actor)}</b> <span class="muted">${esc(ev.summary)}</span>
                  in <a href="#" class="ghx-open-repo-link" data-repo="${esc(ev.repo_name)}" style="font-weight:600;">${esc(ev.repo_name)}</a>
                </div>
                <span class="muted sm">${(ev.created_at || "").replace("T", " ").slice(0, 16)}</span>
              </div>
            `).join("")}
          </div>
        ` : `<div class="muted sm">No recent feed events loaded yet.</div>`}
      </div>
    `;
  }

  function renderNotificationsTab() {
    return `
      <div style="display:flex;flex-direction:column;gap:14px;">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
          <div style="display:flex;gap:6px;">
            <button type="button" class="btn sm ${!E.notifAll && !E.notifParticipating ? "primary" : "ghost"}" data-notif-filter="unread">Unread</button>
            <button type="button" class="btn sm ${E.notifParticipating ? "primary" : "ghost"}" data-notif-filter="participating">Participating</button>
            <button type="button" class="btn sm ${E.notifAll ? "primary" : "ghost"}" data-notif-filter="all">All</button>
          </div>
          <div style="display:flex;gap:8px;">
            <button type="button" class="btn sm" id="ghx-notif-refresh">${icon("refresh")}<span>Refresh</span></button>
            <button type="button" class="btn sm primary" id="ghx-notif-read-all">${icon("check")}<span>Mark All Read</span></button>
          </div>
        </div>

        ${E.loading ? `<div class="card" style="padding:28px;text-align:center;" class="muted">Loading notifications…</div>` :
          E.notifications.length ? E.notifications.map((n) => `
            <div class="card" style="padding:14px 16px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;${n.unread ? "border-inline-start:3px solid var(--accent);" : ""}">
              <div>
                <div style="display:flex;gap:8px;align-items:center;">
                  <span class="chip sm">${esc(n.subject_type)}</span>
                  <a href="#" class="ghx-notif-open" data-repo="${esc(n.repo_full_name)}" data-type="${esc(n.subject_type)}" data-num="${n.subject_number || ""}" style="font-weight:600;color:var(--text);text-decoration:none;">
                    ${esc(n.subject_title)}
                  </a>
                </div>
                <div class="muted sm" style="margin-top:4px;">${esc(n.repo_full_name)} · reason: ${esc(n.reason)} · ${(n.updated_at || "").replace("T", " ").slice(0, 16)}</div>
              </div>
              <div style="display:flex;gap:6px;">
                ${n.unread ? `<button type="button" class="btn xs ghost ghx-notif-read" data-id="${esc(n.id)}">${icon("check")}<span>Mark Read</span></button>` : `<span class="chip sm muted">Read</span>`}
              </div>
            </div>
          `).join("") : `<div class="card" style="padding:28px;text-align:center;" class="muted">Inbox Zero! No notifications match this filter.</div>`}
      </div>
    `;
  }

  function renderSearchTab() {
    const res = E.searchResults;
    const items = res?.items || [];
    return `
      <div style="display:flex;flex-direction:column;gap:14px;">
        <form id="ghx-search-form" class="card" style="padding:14px;display:flex;gap:8px;flex-wrap:wrap;">
          <input type="text" id="ghx-search-input" class="input" placeholder="Search GitHub repositories, code, issues, users…" value="${esc(E.searchQuery)}" style="flex:1;min-width:220px;" />
          <select id="ghx-search-kind" class="input sm" style="width:160px;">
            <option value="repositories" ${E.searchKind === "repositories" ? "selected" : ""}>Repositories</option>
            <option value="code" ${E.searchKind === "code" ? "selected" : ""}>Code</option>
            <option value="issues" ${E.searchKind === "issues" ? "selected" : ""}>Issues &amp; PRs</option>
            <option value="users" ${E.searchKind === "users" ? "selected" : ""}>Users</option>
            <option value="commits" ${E.searchKind === "commits" ? "selected" : ""}>Commits</option>
          </select>
          <button type="submit" class="btn primary">${icon("search")}<span>Search GitHub</span></button>
        </form>

        ${E.loading ? `<div class="card" style="padding:28px;text-align:center;" class="muted">Searching GitHub…</div>` :
          res && !res.ok ? `<div class="card" style="padding:16px;color:var(--red);">${esc(res.error || "Search failed")}</div>` :
          res ? `
            <div class="muted sm">Found ${res.total_count ?? items.length} result(s)</div>
            <div style="display:flex;flex-direction:column;gap:10px;">
              ${items.map((it) => {
                if (res.kind === "repositories") {
                  return `<div class="card" style="padding:14px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
                    <div>
                      <a href="#" class="ghx-open-repo-link" data-repo="${esc(it.full_name)}" style="font-weight:700;">${esc(it.full_name)}</a>
                      <div class="muted sm">${esc(it.description || "")}</div>
                      <div class="muted sm" style="margin-top:4px;">${esc(it.language || "")} · ⭐ ${it.stargazers_count || 0} · 🍴 ${it.forks_count || 0}</div>
                    </div>
                    <button type="button" class="btn xs primary ghx-open-repo-link" data-repo="${esc(it.full_name)}">Explore</button>
                  </div>`;
                }
                if (res.kind === "code") {
                  return `<div class="card" style="padding:14px;">
                    <div><b>${esc(it.repo_full_name)}</b> / <code>${esc(it.path)}</code></div>
                    ${(it.text_matches || []).map((frag) => `<pre class="gh-code-pre" style="margin-top:6px;">${esc(frag)}</pre>`).join("")}
                  </div>`;
                }
                if (res.kind === "issues") {
                  return `<div class="card" style="padding:14px;display:flex;justify-content:space-between;align-items:center;">
                    <div>
                      <b>${esc(it.title)}</b> <span class="muted">#${it.number} in ${esc(it.repo_full_name)}</span>
                      <div class="muted sm">${esc(it.state)} · by ${esc(it.user)}</div>
                    </div>
                    <button type="button" class="btn xs ghost ghx-open-thread-btn" data-repo="${esc(it.repo_full_name)}" data-num="${it.number}" data-pr="${it.is_pull ? "1" : "0"}">Inspect</button>
                  </div>`;
                }
                if (res.kind === "users") {
                  return `<div class="card" style="padding:12px 16px;display:flex;justify-content:space-between;align-items:center;">
                    <div style="display:flex;align-items:center;gap:10px;">
                      <img src="${esc(it.avatar_url)}" style="width:28px;height:28px;border-radius:50%;" />
                      <b>${esc(it.login)}</b> <span class="chip sm">${esc(it.type)}</span>
                    </div>
                    <a href="${esc(it.html_url)}" target="_blank" rel="noopener noreferrer" class="btn xs ghost">${icon("browser")}</a>
                  </div>`;
                }
                return `<div class="card" style="padding:12px 16px;"><code>${esc(it.short_sha)}</code> <b>${esc(it.headline)}</b> <span class="muted">in ${esc(it.repo_full_name)}</span></div>`;
              }).join("")}
            </div>
          ` : `<div class="card" style="padding:28px;text-align:center;" class="muted">Enter a search query above to search all of GitHub.</div>`}
      </div>
    `;
  }

  function renderGistsTab() {
    if (E.selectedGist) {
      const g = E.selectedGist;
      const fileEntries = Object.entries(g.files || {});
      return `
        <div style="display:flex;flex-direction:column;gap:12px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <button type="button" class="btn sm ghost" id="ghx-back-gists">${icon("arrow_left")}<span>Back to Gists</span></button>
            <div style="display:flex;gap:8px;">
              <button type="button" class="btn sm ghost" id="ghx-edit-gist-btn">${icon("edit")}<span>Edit Gist</span></button>
              <a href="${esc(g.html_url)}" target="_blank" rel="noopener noreferrer" class="btn sm ghost">${icon("browser")}<span>Open Web</span></a>
            </div>
          </div>
          <div class="card" style="padding:16px;">
            <b>${esc(g.description || "Untitled Gist")}</b> <span class="chip sm">${g.public ? "Public" : "Secret"}</span>
          </div>
          ${fileEntries.map(([fname, fmeta]) => `
            <div class="card" style="padding:14px;">
              <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
                <code>${esc(fname)}</code>
                <span class="muted sm">${esc(fmeta.language || "")} · ${fmeta.size || 0} B</span>
              </div>
              <pre class="gh-code-pre">${esc(fmeta.content || "")}</pre>
            </div>
          `).join("")}
        </div>
      `;
    }

    return `
      <div style="display:flex;flex-direction:column;gap:14px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <h3 style="margin:0;">Your Gists (${E.gists.length})</h3>
          <button type="button" class="btn sm primary" id="ghx-new-gist-btn">${icon("plus")}<span>New Gist</span></button>
        </div>
        ${E.gists.length ? E.gists.map((g) => `
          <div class="card" style="padding:14px 16px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
            <div>
              <a href="#" class="ghx-open-gist" data-id="${esc(g.id)}" style="font-weight:600;color:var(--text);text-decoration:none;">
                ${esc((g.files || [])[0] || g.id)}
              </a>
              <span class="chip sm">${g.public ? "Public" : "Secret"}</span>
              <div class="muted sm">${esc(g.description || "No description")} · ${(g.files || []).length} file(s)</div>
            </div>
            <button type="button" class="btn xs ghost ghx-open-gist" data-id="${esc(g.id)}">View</button>
          </div>
        `).join("") : `<div class="card" style="padding:28px;text-align:center;" class="muted">No gists found.</div>`}
      </div>
    `;
  }

  function renderProfileTab() {
    const u = E.profileUser;
    return `
      <div style="display:flex;flex-direction:column;gap:16px;">
        ${u ? `
          <div class="card" style="padding:18px;display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap;">
            <div style="display:flex;align-items:center;gap:14px;">
              ${u.avatar_url ? `<img src="${esc(u.avatar_url)}" style="width:56px;height:56px;border-radius:50%;" />` : ""}
              <div>
                <h3 style="margin:0;">${esc(u.name || u.login)} <span class="muted">@${esc(u.login)}</span></h3>
                ${u.bio ? `<p class="muted sm" style="margin:4px 0;">${esc(u.bio)}</p>` : ""}
                <div class="muted sm">${u.followers} followers · ${u.following} following · ${u.public_repos} public repos · ${u.public_gists} gists</div>
              </div>
            </div>
            <button type="button" class="btn sm" id="ghx-profile-web">${icon("globe")}<span>View Profile in Live Web</span></button>
          </div>
        ` : ""}

        <div class="card" style="padding:16px;">
          <h3 style="margin:0 0 10px 0;">Organizations (${E.orgs.length})</h3>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;">
            ${E.orgs.length ? E.orgs.map((o) => `
              <button type="button" class="btn sm ${E.selectedOrg === o.login ? "primary" : "ghost"} ghx-select-org" data-org="${esc(o.login)}">
                ${esc(o.login)}
              </button>
            `).join("") : `<span class="muted sm">No organizations accessible with current token.</span>`}
          </div>
          ${E.selectedOrg ? `
            <div style="border-top:1px solid var(--border);padding-top:12px;">
              <b>${esc(E.selectedOrg)} Repositories (${E.orgRepos.length}) &middot; Members (${E.orgMembers.length})</b>
              <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px;margin-top:10px;">
                ${E.orgRepos.map((r) => `
                  <div class="card" style="padding:12px;">
                    <a href="#" class="ghx-open-repo-link" data-repo="${esc(r.full_name)}" style="font-weight:600;">${esc(r.name)}</a>
                    <div class="muted sm">${esc(r.description || "")}</div>
                  </div>
                `).join("")}
              </div>
            </div>
          ` : ""}
        </div>

        <div class="card" style="padding:16px;">
          <h3 style="margin:0 0 10px 0;">⭐ Starred Repositories (${E.starredRepos.length})</h3>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px;">
            ${E.starredRepos.slice(0, 24).map((r) => `
              <div class="card" style="padding:12px;">
                <a href="#" class="ghx-open-repo-link" data-repo="${esc(r.full_name)}" style="font-weight:600;">${esc(r.full_name)}</a>
                <div class="muted sm">${esc(r.language || "")} · ⭐ ${r.stargazers_count || 0}</div>
              </div>
            `).join("")}
          </div>
        </div>

        <div class="card" style="padding:16px;">
          <h3 style="margin:0 0 10px 0;">🔑 Your Account SSH Keys (${E.sshKeys.length})</h3>
          ${E.sshKeys.map((k) => `<div style="padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;"><b>${esc(k.title)}</b></div>`).join("") || `<div class="muted sm">No SSH keys found.</div>`}
        </div>
      </div>
    `;
  }

  // ── Event Binding ───────────────────────────────────────────────────────

  function bindEvents(root, parentCallbacks) {
    $("#ghx-back-repos", root)?.addEventListener("click", closeRepo);
    $("#ghx-star-btn", root)?.addEventListener("click", async () => {
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_star_toggle", { owner, repo, starred: E.starred });
      if (res?.ok) {
        E.starred = Boolean(res.starred);
        triggerRender();
      }
    });
    $("#ghx-fork-btn", root)?.addEventListener("click", async () => {
      if (!confirm(`Fork ${E.activeRepo} to your account?`)) return;
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_fork", { owner, repo });
      if (res?.ok) {
        toast("success", "Repository Forked", res.repo?.full_name || "");
      } else {
        toast("error", "Fork Failed", res?.error || "Unable to fork");
      }
    });
    $("#ghx-clone-repo", root)?.addEventListener("click", () => parentCallbacks?.openCloneModal?.(E.activeRepo));
    $("#ghx-open-web", root)?.addEventListener("click", () => {
      LD.call("gh_browser_open", { url: `https://github.com/${E.activeRepo}` });
    });

    $$("[data-ghxtab]", root).forEach((btn) => {
      btn.addEventListener("click", () => openRepo(E.activeRepo, btn.dataset.ghxtab));
    });

    // Code explorer events
    $("#ghx-toggle-tree", root)?.addEventListener("click", () => {
      E.treeHidden = !E.treeHidden;
      triggerRender();
    });
    $("#ghx-ref-select", root)?.addEventListener("change", async (e) => {
      E.currentRef = e.target.value;
      E.currentPath = "";
      E.fileData = null;
      await openRepo(E.activeRepo, "code");
    });
    $$(".ghx-path-crumb, .ghx-entry-row", root).forEach((el) => {
      el.addEventListener("click", () => loadContents(el.dataset.path || ""));
    });
    $$(".gh-tree-item", root).forEach((el) => {
      el.addEventListener("click", () => loadContents(el.dataset.treePath || ""));
    });
    $("#ghx-tree-filter", root)?.addEventListener("input", (e) => {
      E.treeFilter = e.target.value;
      triggerRender();
      $("#ghx-tree-filter", root)?.focus();
    });
    $("#ghx-new-file-btn", root)?.addEventListener("click", () => {
      E.newFileMode = true;
      E.editingFile = false;
      triggerRender();
    });
    $("#ghx-edit-file-btn", root)?.addEventListener("click", () => {
      E.editingFile = true;
      triggerRender();
    });
    $("#ghx-cancel-file-edit", root)?.addEventListener("click", () => {
      E.editingFile = false;
      E.newFileMode = false;
      triggerRender();
    });
    $("#ghx-file-editor-form", root)?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const [owner, repo] = splitRepo(E.activeRepo);
      const path = $("#ghx-file-path-input", root)?.value.trim();
      const content = $("#ghx-file-content-input", root)?.value || "";
      const message = $("#ghx-file-msg-input", root)?.value.trim();
      const sha = $("#ghx-file-sha-input", root)?.value.trim() || "";
      const res = await LD.call("gh_file_save", { owner, repo, path, content, message, branch: E.currentRef, sha });
      if (res?.ok) {
        toast("success", "Committed File", path);
        E.editingFile = false;
        E.newFileMode = false;
        await loadContents(path);
      } else {
        toast("error", "Commit Failed", res?.error || "Error saving file");
      }
    });
    $("#ghx-delete-file-btn", root)?.addEventListener("click", async () => {
      if (!E.fileData || !confirm(`Delete ${E.fileData.path} from branch ${E.currentRef}?`)) return;
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_file_delete", {
        owner, repo, path: E.fileData.path, sha: E.fileData.sha, branch: E.currentRef, message: `Delete ${E.fileData.path}`,
      });
      if (res?.ok) {
        toast("success", "File Deleted", E.fileData.path);
        const parent = E.currentPath.includes("/") ? E.currentPath.slice(0, E.currentPath.lastIndexOf("/")) : "";
        await loadContents(parent);
      } else {
        toast("error", "Delete Failed", res?.error || "Error");
      }
    });

    // Issue Detail events
    $("#ghx-back-issues", root)?.addEventListener("click", () => { E.activeIssueNumber = null; triggerRender(); });
    $("#ghx-edit-issue-btn", root)?.addEventListener("click", () => {
      const iss = E.issueDetail;
      if (!iss) return;
      const currentLbls = new Set((iss.labels || []).map((l) => l.name));
      openModal(`
        <div class="modal card" style="max-width:560px;">
          <div class="modal-header" style="display:flex;justify-content:space-between;align-items:center;">
            <h2>Edit Issue #${iss.number}</h2>
            <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
          </div>
          <form id="ghx-edit-issue-form" style="padding:16px;display:flex;flex-direction:column;gap:12px;">
            <input type="text" id="ghx-eiss-title" class="input" value="${esc(iss.title || "")}" required />
            <textarea id="ghx-eiss-body" class="input" rows="6">${esc(iss.body || "")}</textarea>
            ${E.repoLabels.length ? `
              <div>
                <div class="muted sm" style="margin-bottom:6px;">Labels:</div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                  ${E.repoLabels.map((lb) => `<label class="chip sm" style="cursor:pointer;"><input type="checkbox" class="ghx-eiss-lbl" value="${esc(lb.name)}" ${currentLbls.has(lb.name) ? "checked" : ""} /> ${esc(lb.name)}</label>`).join("")}
                </div>
              </div>
            ` : ""}
            <div style="display:flex;justify-content:flex-end;gap:8px;">
              <button type="button" class="btn" data-dismiss>Cancel</button>
              <button type="submit" class="btn primary">Save Changes</button>
            </div>
          </form>
        </div>
      `, (mRoot) => {
        $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
        $("#ghx-edit-issue-form", mRoot)?.addEventListener("submit", async (ev) => {
          ev.preventDefault();
          const [owner, repo] = splitRepo(E.activeRepo);
          const labels = $$(".ghx-eiss-lbl:checked", mRoot).map((cb) => cb.value);
          const payload = {
            owner, repo, issue_number: iss.number,
            title: $("#ghx-eiss-title", mRoot).value.trim(),
            body: $("#ghx-eiss-body", mRoot).value,
          };
          if (E.repoLabels.length) payload.labels = labels;
          const res = await LD.call("gh_issue_update", payload);
          if (res?.ok) {
            closeModal();
            toast("success", "Issue Updated");
            await openIssueDetail(E.activeRepo, iss.number);
          } else {
            alert(res?.error || "Failed to update issue");
          }
        });
      });
    });
    $("#ghx-toggle-issue-state", root)?.addEventListener("click", async (e) => {
      const [owner, repo] = splitRepo(E.activeRepo);
      const next = e.currentTarget.dataset.next;
      const res = await LD.call("gh_close_issue", { owner, repo, issue_number: E.activeIssueNumber, state: next });
      if (res?.ok) await openIssueDetail(E.activeRepo, E.activeIssueNumber);
    });
    $("#ghx-issue-comment-form", root)?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const [owner, repo] = splitRepo(E.activeRepo);
      const body = $("#ghx-issue-comment-body", root)?.value.trim();
      if (!body) return;
      const res = await LD.call("gh_issue_comment_create", { owner, repo, issue_number: E.activeIssueNumber, body });
      if (res?.ok) {
        toast("success", "Comment Posted");
        await openIssueDetail(E.activeRepo, E.activeIssueNumber);
      } else {
        toast("error", "Failed", res?.error || "Error");
      }
    });

    // PR Detail events
    $("#ghx-back-pulls", root)?.addEventListener("click", () => { E.activePRNumber = null; triggerRender(); });
    $$("[data-prsub]", root).forEach((btn) => {
      btn.addEventListener("click", () => { E.prSubTab = btn.dataset.prsub; triggerRender(); });
    });
    $$("[data-diffmode]", root).forEach((btn) => {
      btn.addEventListener("click", () => { E.diffMode = btn.dataset.diffmode; triggerRender(); });
    });
    $("#ghx-pr-update-branch", root)?.addEventListener("click", async () => {
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_pull_update_branch", { owner, repo, pull_number: E.activePRNumber });
      toast(res?.ok ? "success" : "error", res?.ok ? "Branch Updated" : "Update Failed", res?.error || "");
    });
    $("#ghx-pr-merge-btn", root)?.addEventListener("click", () => parentCallbacks?.openMergePRModal?.(E.activeRepo, E.activePRNumber));
    $("#ghx-pr-close-btn", root)?.addEventListener("click", async () => {
      if (!confirm(`Close PR #${E.activePRNumber}?`)) return;
      const [owner, repo] = splitRepo(E.activeRepo);
      await LD.call("gh_close_pull", { owner, repo, pull_number: E.activePRNumber });
      await openPullDetail(E.activeRepo, E.activePRNumber);
    });
    $("#ghx-pr-review-form", root)?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const [owner, repo] = splitRepo(E.activeRepo);
      const ev = $("#ghx-pr-review-event", root)?.value || "COMMENT_ONLY";
      const body = $("#ghx-pr-comment-body", root)?.value.trim();
      let res;
      if (ev === "COMMENT_ONLY") {
        if (!body) return;
        res = await LD.call("gh_issue_comment_create", { owner, repo, issue_number: E.activePRNumber, body });
      } else {
        res = await LD.call("gh_pull_review_create", { owner, repo, pull_number: E.activePRNumber, event: ev, body });
      }
      if (res?.ok) {
        toast("success", "Submitted");
        await openPullDetail(E.activeRepo, E.activePRNumber);
      } else {
        toast("error", "Error", res?.error || "Failed to submit");
      }
    });

    // Actions Run Detail events
    $("#ghx-back-actions", root)?.addEventListener("click", () => { E.activeRunId = null; triggerRender(); });
    $$(".ghx-load-job-logs", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        const [owner, repo] = splitRepo(E.activeRepo);
        E.selectedJobId = parseInt(btn.dataset.job, 10);
        E.jobLogs = "Loading logs…";
        triggerRender();
        const res = await LD.call("gh_job_logs", { owner, repo, job_id: E.selectedJobId });
        E.jobLogs = res?.ok ? (res.text || "(Empty log)") : (res?.error || "Failed to download logs.");
        E.jobLogsTruncated = Boolean(res?.truncated);
        triggerRender();
      });
    });
    $("#ghx-rerun-all", root)?.addEventListener("click", async () => {
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_workflow_rerun", { owner, repo, run_id: E.activeRunId, failed_only: false });
      toast(res?.ok ? "success" : "error", res?.ok ? "Workflow Re-run Triggered" : "Failed", res?.error || "");
    });
    $("#ghx-rerun-failed", root)?.addEventListener("click", async () => {
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_workflow_rerun", { owner, repo, run_id: E.activeRunId, failed_only: true });
      toast(res?.ok ? "success" : "error", res?.ok ? "Failed Jobs Re-run Triggered" : "Failed", res?.error || "");
    });
    $("#ghx-cancel-run", root)?.addEventListener("click", async () => {
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_workflow_cancel", { owner, repo, run_id: E.activeRunId });
      toast(res?.ok ? "success" : "error", res?.ok ? "Workflow Run Cancelled" : "Failed", res?.error || "");
    });

    // Commits & Compare events
    $$(".ghx-open-commit", root).forEach((el) => {
      el.addEventListener("click", async (e) => {
        e.preventDefault();
        const [owner, repo] = splitRepo(E.activeRepo);
        const res = await LD.call("gh_commit_detail", { owner, repo, sha: el.dataset.sha });
        if (res?.ok) {
          E.selectedCommit = res.commit;
          triggerRender();
        }
      });
    });
    $("#ghx-back-commits", root)?.addEventListener("click", () => { E.selectedCommit = null; triggerRender(); });
    $("#ghx-run-compare", root)?.addEventListener("click", async () => {
      const [owner, repo] = splitRepo(E.activeRepo);
      E.compareBase = $("#ghx-compare-base", root)?.value || "main";
      E.compareHead = $("#ghx-compare-head", root)?.value || "main";
      const res = await LD.call("gh_compare", { owner, repo, base: E.compareBase, head: E.compareHead });
      if (res?.ok) {
        E.compareResult = res;
        triggerRender();
      } else {
        toast("error", "Compare Failed", res?.error || "");
      }
    });

    // Releases events
    $("#ghx-new-release-btn", root)?.addEventListener("click", () => {
      openModal(`
        <div class="modal card" style="max-width:520px;">
          <div class="modal-header" style="display:flex;justify-content:space-between;align-items:center;">
            <h2>Create New Release</h2>
            <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
          </div>
          <form id="ghx-create-rel-form" style="padding:16px;display:flex;flex-direction:column;gap:12px;">
            <input type="text" id="ghx-rel-tag" class="input" placeholder="Tag (e.g. v1.2.0)" required />
            <input type="text" id="ghx-rel-name" class="input" placeholder="Release title" />
            <textarea id="ghx-rel-body" class="input" rows="5" placeholder="Release notes (optional — auto-generated if empty)"></textarea>
            <label><input type="checkbox" id="ghx-rel-pre" /> Pre-release</label>
            <div style="display:flex;justify-content:flex-end;gap:8px;">
              <button type="button" class="btn" data-dismiss>Cancel</button>
              <button type="submit" class="btn primary">Publish Release</button>
            </div>
          </form>
        </div>
      `, (mRoot) => {
        $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
        $("#ghx-create-rel-form", mRoot)?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const [owner, repo] = splitRepo(E.activeRepo);
          const res = await LD.call("gh_create_release", {
            owner, repo,
            tag_name: $("#ghx-rel-tag", mRoot).value.trim(),
            name: $("#ghx-rel-name", mRoot).value.trim(),
            body: $("#ghx-rel-body", mRoot).value,
            prerelease: $("#ghx-rel-pre", mRoot).checked,
          });
          if (res?.ok) {
            closeModal();
            toast("success", "Release Created");
            await openRepo(E.activeRepo, "releases");
          } else {
            alert(res?.error || "Failed");
          }
        });
      });
    });
    $$(".ghx-del-release", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Delete this release?")) return;
        const [owner, repo] = splitRepo(E.activeRepo);
        await LD.call("gh_delete_release", { owner, repo, release_id: parseInt(btn.dataset.id, 10) });
        await openRepo(E.activeRepo, "releases");
      });
    });

    // Repo settings & webhooks events
    $("#ghx-repo-settings-form", root)?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_repo_update", {
        owner, repo,
        updates: {
          description: $("#ghx-set-desc", root)?.value || "",
          homepage: $("#ghx-set-home", root)?.value || "",
          default_branch: $("#ghx-set-branch", root)?.value || "main",
          private: Boolean($("#ghx-set-private", root)?.checked),
          has_issues: Boolean($("#ghx-set-issues", root)?.checked),
          has_wiki: Boolean($("#ghx-set-wiki", root)?.checked),
        },
      });
      toast(res?.ok ? "success" : "error", res?.ok ? "Repository Updated" : "Update Failed", res?.error || "");
      if (res?.ok) await openRepo(E.activeRepo, "settings");
    });
    $("#ghx-add-hook-btn", root)?.addEventListener("click", () => {
      const url = prompt("Webhook Payload URL (https://...):");
      if (!url) return;
      const [owner, repo] = splitRepo(E.activeRepo);
      LD.call("gh_webhook_create", { owner, repo, url, events: ["push", "pull_request"] }).then((res) => {
        toast(res?.ok ? "success" : "error", res?.ok ? "Webhook Added" : "Error", res?.error || "");
        if (res?.ok) openRepo(E.activeRepo, "settings");
      });
    });
    $$(".ghx-del-hook", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Delete webhook?")) return;
        const [owner, repo] = splitRepo(E.activeRepo);
        await LD.call("gh_webhook_delete", { owner, repo, hook_id: parseInt(btn.dataset.id, 10) });
        await openRepo(E.activeRepo, "settings");
      });
    });
    $("#ghx-add-dkey-btn", root)?.addEventListener("click", () => {
      openModal(`
        <div class="modal card" style="max-width:520px;">
          <div class="modal-header" style="display:flex;justify-content:space-between;align-items:center;">
            <h2>Add Deploy Key</h2>
            <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
          </div>
          <form id="ghx-add-dkey-form" style="padding:16px;display:flex;flex-direction:column;gap:12px;">
            <input type="text" id="ghx-dk-title" class="input" placeholder="Key title (e.g. Deploy Server)" required />
            <textarea id="ghx-dk-key" class="input" rows="4" placeholder="ssh-ed25519 AAAA..." required style="font-family:var(--mono);font-size:12px;"></textarea>
            <label><input type="checkbox" id="ghx-dk-ro" checked /> Read-only access</label>
            <div style="display:flex;justify-content:flex-end;gap:8px;">
              <button type="button" class="btn" data-dismiss>Cancel</button>
              <button type="submit" class="btn primary">Add Key</button>
            </div>
          </form>
        </div>
      `, (mRoot) => {
        $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
        $("#ghx-add-dkey-form", mRoot)?.addEventListener("submit", async (ev) => {
          ev.preventDefault();
          const [owner, repo] = splitRepo(E.activeRepo);
          const res = await LD.call("gh_add_deploy_key", {
            owner, repo,
            title: $("#ghx-dk-title", mRoot).value.trim(),
            key: $("#ghx-dk-key", mRoot).value.trim(),
            read_only: Boolean($("#ghx-dk-ro", mRoot)?.checked),
          });
          if (res?.ok) {
            closeModal();
            toast("success", "Deploy Key Added");
            await openRepo(E.activeRepo, "settings");
          } else {
            alert(res?.error || "Failed to add deploy key");
          }
        });
      });
    });
    $$(".ghx-del-dkey", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Remove deploy key?")) return;
        const [owner, repo] = splitRepo(E.activeRepo);
        await LD.call("gh_delete_deploy_key", { owner, repo, key_id: parseInt(btn.dataset.id, 10) });
        await openRepo(E.activeRepo, "settings");
      });
    });

    // CI/CD & VPS tab events
    const saveCicdFormState = () => {
      E.cicdForm = {
        ...E.cicdForm,
        repoKey: E.activeRepo,
        serverId: $("#ghx-cicd-server", root)?.value || E.cicdForm.serverId || "",
        stack: $("#ghx-cicd-stack", root)?.value || E.cicdForm.stack || "laravel",
        strategy: $("#ghx-cicd-strategy", root)?.value || "ci_build_upload",
        domain: $("#ghx-cicd-domain", root)?.value?.trim() || "",
        path: $("#ghx-cicd-path", root)?.value?.trim() || "",
        port: +($("#ghx-cicd-port", root)?.value || 3000),
        healthPath: $("#ghx-cicd-health", root)?.value?.trim() || "/",
        branch: $("#ghx-cicd-branch", root)?.value || "main",
        environment: $("#ghx-cicd-env", root)?.value || "",
        scaffold: Boolean($("#ghx-cicd-scaffold", root)?.checked),
      };
    };
    const refreshCicdYamlPreview = async () => {
      saveCicdFormState();
      const res = await LD.call("gh_cicd_preview_yaml", {
        stack: E.cicdForm.stack,
        branch: E.cicdForm.branch,
        strategy: E.cicdForm.strategy,
        environment: E.cicdForm.environment,
        health_path: E.cicdForm.healthPath,
      });
      if (res?.ok) {
        E.cicdPreviewYaml = res.yaml || "";
        const ed = $("#ghx-cicd-yaml-editor", root);
        if (ed) ed.value = E.cicdPreviewYaml;
      }
    };
    $("#ghx-cicd-stack", root)?.addEventListener("change", () => {
      const st = $("#ghx-cicd-stack", root).value;
      const portEl = $("#ghx-cicd-port", root);
      const hpEl = $("#ghx-cicd-health", root);
      if (portEl && (portEl.value === "3000" || portEl.value === "8000")) {
        portEl.value = st === "python" ? "8000" : "3000";
      }
      if (hpEl && (hpEl.value === "/up" || hpEl.value === "/")) {
        hpEl.value = st === "laravel" ? "/up" : "/";
      }
      refreshCicdYamlPreview();
    });
    $("#ghx-cicd-strategy", root)?.addEventListener("change", refreshCicdYamlPreview);
    $("#ghx-cicd-branch", root)?.addEventListener("change", refreshCicdYamlPreview);
    $("#ghx-cicd-env", root)?.addEventListener("change", refreshCicdYamlPreview);
    $("#ghx-cicd-refresh-yaml", root)?.addEventListener("click", refreshCicdYamlPreview);
    $("#ghx-cicd-yaml-editor", root)?.addEventListener("input", (e) => {
      E.cicdPreviewYaml = e.target.value;
    });
    $("#ghx-vps-bind-form", root)?.addEventListener("submit", async (e) => {
      e.preventDefault();
      saveCicdFormState();
      if (!E.cicdForm.serverId) return toast("error", "VPS Required", "Select a saved SSH server first.");
      const [owner, repo] = splitRepo(E.activeRepo);
      const btn = $("#ghx-cicd-bind-btn", root);
      if (btn) btn.disabled = true;
      try {
        const res = await LD.call("gh_vps_bind", {
          owner, repo,
          server_id: E.cicdForm.serverId,
          domain: E.cicdForm.domain,
          deploy_path: E.cicdForm.path,
          stack: E.cicdForm.stack,
          branch: E.cicdForm.branch,
          port: E.cicdForm.port,
          health_path: E.cicdForm.healthPath,
          strategy: E.cicdForm.strategy,
          environment: E.cicdForm.environment,
          workflow_yaml: $("#ghx-cicd-yaml-editor", root)?.value || E.cicdPreviewYaml || "",
          scaffold_remote: E.cicdForm.scaffold,
        });
        if (res?.ok) {
          E.cicdLastResult = res;
          toast("success", "Repo Linked to VPS!", `Committed ${res.workflow_path}`);
          await loadCicdTabData(owner, repo);
          triggerRender();
        } else {
          toast("error", "VPS Bind Failed", res?.error || "Check permissions & server connection.");
        }
      } catch (err) {
        toast("error", "VPS Bind Failed", err.message);
      } finally {
        if (btn) btn.disabled = false;
      }
    });
    $$(".ghx-dispatch-wf", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        const [owner, repo] = splitRepo(E.activeRepo);
        const res = await LD.call("gh_trigger_workflow", { owner, repo, workflow_id: btn.dataset.wf, ref: E.currentRef || "main" });
        toast(res?.ok ? "success" : "error", res?.ok ? "Workflow Triggered" : "Dispatch Failed", res?.error || "");
      });
    });
    $$(".ghx-env-pick", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        const [owner, repo] = splitRepo(E.activeRepo);
        E.cicdSelectedEnv = btn.dataset.env || "";
        E.loading = true;
        triggerRender();
        try { await loadCicdTabData(owner, repo); } finally { E.loading = false; triggerRender(); }
      });
    });
    $("#ghx-env-create-btn", root)?.addEventListener("click", async () => {
      const envName = await promptModal("New GitHub Environment", "Name (e.g. production, staging)", "production");
      if (!envName) return;
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_environment_upsert", { owner, repo, env: envName.trim() });
      if (res?.ok) {
        E.cicdSelectedEnv = envName.trim();
        toast("success", "Environment ready", envName.trim());
        await loadCicdTabData(owner, repo);
        triggerRender();
      } else {
        toast("error", "Failed", res?.error || "Could not create environment.");
      }
    });
    $("#ghx-env-delete-btn", root)?.addEventListener("click", async () => {
      if (!E.cicdSelectedEnv) return;
      if (!confirm(`Delete GitHub Environment "${E.cicdSelectedEnv}"?`)) return;
      const [owner, repo] = splitRepo(E.activeRepo);
      const res = await LD.call("gh_environment_delete", { owner, repo, env: E.cicdSelectedEnv });
      if (res?.ok) {
        toast("success", "Environment deleted");
        E.cicdSelectedEnv = "";
        await loadCicdTabData(owner, repo);
        triggerRender();
      } else {
        toast("error", "Delete failed", res?.error || "");
      }
    });
    $("#ghx-secret-add-btn", root)?.addEventListener("click", () => {
      const [owner, repo] = splitRepo(E.activeRepo);
      openKvModal("secret", owner, repo);
    });
    $$(".ghx-edit-secret", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        const [owner, repo] = splitRepo(E.activeRepo);
        openKvModal("secret", owner, repo, btn.dataset.name);
      });
    });
    $$(".ghx-del-secret", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        const nm = btn.dataset.name;
        if (!confirm(`Delete secret "${nm}"?`)) return;
        const [owner, repo] = splitRepo(E.activeRepo);
        const res = await LD.call("gh_secret_delete", { owner, repo, name: nm, env: E.cicdSelectedEnv });
        toast(res?.ok ? "success" : "error", res?.ok ? "Secret deleted" : "Error", res?.error || "");
        await loadCicdTabData(owner, repo);
        triggerRender();
      });
    });
    $("#ghx-var-add-btn", root)?.addEventListener("click", () => {
      const [owner, repo] = splitRepo(E.activeRepo);
      openKvModal("variable", owner, repo);
    });
    $$(".ghx-edit-var", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        const [owner, repo] = splitRepo(E.activeRepo);
        openKvModal("variable", owner, repo, btn.dataset.name, btn.dataset.val || "");
      });
    });
    $$(".ghx-del-var", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        const nm = btn.dataset.name;
        if (!confirm(`Delete variable "${nm}"?`)) return;
        const [owner, repo] = splitRepo(E.activeRepo);
        const res = await LD.call("gh_variable_delete", { owner, repo, name: nm, env: E.cicdSelectedEnv });
        toast(res?.ok ? "success" : "error", res?.ok ? "Variable deleted" : "Error", res?.error || "");
        await loadCicdTabData(owner, repo);
        triggerRender();
      });
    });
    $("#ghx-bulk-env-btn", root)?.addEventListener("click", () => {
      const [owner, repo] = splitRepo(E.activeRepo);
      openBulkEnvModal(owner, repo);
    });

    // Global tab events (Feed, Notifications, Search, Gists, Profile)
    $("#ghx-refresh-feed", root)?.addEventListener("click", () => { E.eventsLoadedFor = ""; loadFeed(""); });
    $$(".ghx-open-repo-link", root).forEach((el) => {
      el.addEventListener("click", (e) => {
        e.preventDefault();
        parentCallbacks?.switchToRepoWorkspace?.(el.dataset.repo);
      });
    });

    $$("[data-notif-filter]", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        const mode = btn.dataset.notifFilter;
        E.notifAll = mode === "all";
        E.notifParticipating = mode === "participating";
        loadNotifications();
      });
    });
    $("#ghx-notif-refresh", root)?.addEventListener("click", loadNotifications);
    $("#ghx-notif-read-all", root)?.addEventListener("click", async () => {
      await LD.call("gh_notifications_read_all");
      toast("success", "All notifications marked as read");
      await loadNotifications();
    });
    $$(".ghx-notif-read", root).forEach((btn) => {
      btn.addEventListener("click", async () => {
        await LD.call("gh_notification_read", { thread_id: btn.dataset.id });
        await loadNotifications();
      });
    });
    $$(".ghx-notif-open", root).forEach((el) => {
      el.addEventListener("click", async (e) => {
        e.preventDefault();
        const repoFull = el.dataset.repo;
        const num = parseInt(el.dataset.num || "0", 10);
        const tp = el.dataset.type || "";
        parentCallbacks?.switchToRepoWorkspace?.(repoFull, () => {
          if (num && tp === "PullRequest") return openPullDetail(repoFull, num);
          if (num && tp === "Issue") return openIssueDetail(repoFull, num);
          return openRepo(repoFull, "code");
        });
      });
    });

    $("#ghx-search-form", root)?.addEventListener("submit", (e) => {
      e.preventDefault();
      runGlobalSearch($("#ghx-search-input", root)?.value, $("#ghx-search-kind", root)?.value);
    });
    $$(".ghx-open-thread-btn", root).forEach((btn) => {
      btn.addEventListener("click", () => {
        const repoFull = btn.dataset.repo;
        const num = parseInt(btn.dataset.num || "0", 10);
        const isPr = btn.dataset.pr === "1";
        parentCallbacks?.switchToRepoWorkspace?.(repoFull, () => {
          return isPr ? openPullDetail(repoFull, num) : openIssueDetail(repoFull, num);
        });
      });
    });

    $$(".ghx-open-gist", root).forEach((el) => {
      el.addEventListener("click", async (e) => {
        e.preventDefault();
        const res = await LD.call("gh_gist_detail", { gist_id: el.dataset.id });
        if (res?.ok) { E.selectedGist = res.gist; triggerRender(); }
      });
    });
    $("#ghx-back-gists", root)?.addEventListener("click", () => { E.selectedGist = null; triggerRender(); });
    $("#ghx-edit-gist-btn", root)?.addEventListener("click", () => {
      const g = E.selectedGist;
      if (!g) return;
      const firstEntry = Object.entries(g.files || {})[0] || ["snippet.txt", { content: "" }];
      const fname = firstEntry[0];
      const fcontent = firstEntry[1]?.content || "";
      openModal(`
        <div class="modal card" style="max-width:560px;">
          <div class="modal-header" style="display:flex;justify-content:space-between;align-items:center;">
            <h2>Edit Gist</h2>
            <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
          </div>
          <form id="ghx-edit-gist-form" style="padding:16px;display:flex;flex-direction:column;gap:12px;">
            <input type="text" id="ghx-eg-desc" class="input" value="${esc(g.description || "")}" placeholder="Description" />
            <input type="text" id="ghx-eg-fname" class="input" value="${esc(fname)}" required />
            <textarea id="ghx-eg-content" class="input" rows="8" required style="font-family:var(--mono);font-size:12px;">${esc(fcontent)}</textarea>
            <div style="display:flex;justify-content:flex-end;gap:8px;">
              <button type="button" class="btn" data-dismiss>Cancel</button>
              <button type="submit" class="btn primary">Save Gist</button>
            </div>
          </form>
        </div>
      `, (mRoot) => {
        $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
        $("#ghx-edit-gist-form", mRoot)?.addEventListener("submit", async (ev) => {
          ev.preventDefault();
          const newFname = $("#ghx-eg-fname", mRoot).value.trim();
          const res = await LD.call("gh_gist_update", {
            gist_id: g.id,
            description: $("#ghx-eg-desc", mRoot).value.trim(),
            files: { [newFname]: $("#ghx-eg-content", mRoot).value },
          });
          if (res?.ok) {
            closeModal();
            toast("success", "Gist Updated");
            const det = await LD.call("gh_gist_detail", { gist_id: g.id });
            if (det?.ok) E.selectedGist = det.gist;
            triggerRender();
          } else {
            alert(res?.error || "Failed to update Gist");
          }
        });
      });
    });
    $("#ghx-new-gist-btn", root)?.addEventListener("click", () => {
      openModal(`
        <div class="modal card" style="max-width:560px;">
          <div class="modal-header" style="display:flex;justify-content:space-between;align-items:center;">
            <h2>Create New Gist</h2>
            <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
          </div>
          <form id="ghx-create-gist-form" style="padding:16px;display:flex;flex-direction:column;gap:12px;">
            <input type="text" id="ghx-gist-desc" class="input" placeholder="Gist description" />
            <input type="text" id="ghx-gist-fname" class="input" placeholder="Filename (e.g. snippet.php)" required />
            <textarea id="ghx-gist-content" class="input" rows="8" placeholder="Paste code…" required style="font-family:var(--mono);font-size:12px;"></textarea>
            <label><input type="checkbox" id="ghx-gist-public" /> Public Gist</label>
            <div style="display:flex;justify-content:flex-end;gap:8px;">
              <button type="button" class="btn" data-dismiss>Cancel</button>
              <button type="submit" class="btn primary">Create Gist</button>
            </div>
          </form>
        </div>
      `, (mRoot) => {
        $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
        $("#ghx-create-gist-form", mRoot)?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fname = $("#ghx-gist-fname", mRoot).value.trim();
          const content = $("#ghx-gist-content", mRoot).value;
          const res = await LD.call("gh_gist_create", {
            description: $("#ghx-gist-desc", mRoot).value.trim(),
            public: $("#ghx-gist-public", mRoot).checked,
            files: { [fname]: content },
          });
          if (res?.ok) {
            closeModal();
            toast("success", "Gist Created");
            await loadGists();
          } else {
            alert(res?.error || "Failed to create Gist");
          }
        });
      });
    });

    $("#ghx-profile-web", root)?.addEventListener("click", () => {
      const login = E.profileUser?.login || "";
      LD.call("gh_browser_open", { url: login ? `https://github.com/${login}` : "https://github.com" });
    });
    $$(".ghx-select-org", root).forEach((btn) => {
      btn.addEventListener("click", () => selectOrg(btn.dataset.org));
    });
  }

  return {
    LANG_COLORS,
    state: E,
    setRenderCallback,
    openRepo,
    closeRepo,
    openPullDetail,
    openIssueDetail,
    openRunDetail,
    loadFeed,
    loadNotifications,
    runGlobalSearch,
    loadGists,
    loadProfileAndOrgs,
    renderRepoWorkspace,
    renderFeedSection,
    renderNotificationsTab,
    renderSearchTab,
    renderGistsTab,
    renderProfileTab,
    bindEvents,
  };
})();

window.GitHubExplorer = GitHubExplorer;
