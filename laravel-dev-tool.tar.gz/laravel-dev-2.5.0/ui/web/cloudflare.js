"use strict";

/* ── Cloudflare Platform Hub ──────────────────────────────────────────────────
   Full Cloudflare management inside Laravel Dev: Live Embedded Dashboard Web Mode
   + native API control across Zones, Analytics, DNS, SSL/TLS & Edge, Cache,
   Security/WAF/IP/Page Rules, Workers & Routes, Pages, KV, D1 SQL, R2 Storage,
   Zero Trust Tunnels + Ingress, Turnstile, and Email Routing. */

const Cloudflare = (() => {
  const S = {
    status: { configured: false, vault_locked: false, token_masked: "", account_id: "", account_name: "", accounts: [] },
    tab: "overview", // overview | dns | edge | security | compute | storage | tunnels | extras
    storageSub: "r2", // r2 | kv | d1
    zones: [],
    currentZoneId: "",
    zoneDetails: null,
    analyticsDays: 7,
    analytics: null,
    analyticsErr: null,
    dnsRecords: [],
    dnsFilterType: "ALL",
    dnsSearch: "",
    zoneSettings: {},
    universalSsl: {},
    certPacks: [],
    devMode: false,
    devModeTime: 0,
    securityLevel: "medium",
    botFightMode: false,
    ipRules: [],
    wafRules: [],
    pageRules: [],
    workers: [],
    workerSubdomain: "",
    workerRoutes: [],
    pagesProjects: [],
    pagesDeployments: [],
    activePagesProject: "",
    r2Buckets: [],
    kvNamespaces: [],
    activeKvId: "",
    kvPrefix: "",
    kvKeys: [],
    kvEditor: { key: "", value: "" },
    d1Databases: [],
    activeD1Id: "",
    d1Sql: "SELECT name, type FROM sqlite_master WHERE type='table';",
    d1Result: null,
    tunnels: [],
    turnstileWidgets: [],
    emailRouting: {},
    emailRules: [],
    tabErrors: {},
    loading: false,
    error: "",
  };

  const tr = (key, fallback) => (window.t ? window.t(key, fallback) : (fallback !== undefined ? fallback : key));
  const view = () => $("#view-cloudflare");
  const currentZone = () => S.zones.find((z) => z.id === S.currentZoneId) || S.zones[0] || null;
  const activeZoneId = () => (currentZone() ? currentZone().id : "");

  function formatBytes(bytes) {
    const num = Number(bytes || 0);
    if (!num) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    const idx = Math.min(units.length - 1, Math.floor(Math.log(num) / Math.log(1024)));
    return `${(num / Math.pow(1024, idx)).toFixed(idx === 0 ? 0 : 1)} ${units[idx]}`;
  }

  function formatCompact(n) {
    const num = Number(n || 0);
    if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(1)}M`;
    if (num >= 1_000) return `${(num / 1_000).toFixed(1)}K`;
    return String(num);
  }

  async function openCfWeb(url = "") {
    const accId = S.status.account_id && !String(S.status.account_id).startsWith("acc_") ? S.status.account_id : "";
    const target = url || (accId ? `https://dash.cloudflare.com/${accId}` : "https://dash.cloudflare.com");
    try {
      const st = await LD.call("cf_browser_status").catch(() => null);
      if (st?.active) {
        await LD.call("cf_browser_nav", { action: "load", url: target });
      } else {
        await LD.call("cf_browser_open", { url: target });
      }
    } catch {
      await LD.call("cf_browser_open", { url: target }).catch(() => {});
    }
  }

  async function init() {
    await refreshStatus();
    if (S.status.configured) {
      await loadZones();
    }
    window.addEventListener("langchange", () => {
      const root = view();
      if (root && !root.hidden) render();
    });
  }

  async function show() {
    if (!S.status.configured) {
      await refreshStatus();
    }
    if (S.status.configured && !S.zones.length) {
      await loadZones();
    }
    await loadCurrentTabData(false);
    render();
  }

  async function refreshStatus() {
    try {
      const res = await LD.call("cf_status");
      S.status = res || { configured: false };
    } catch {
      S.status = { configured: false };
    }
  }

  async function loadZones() {
    S.loading = true;
    S.tabErrors.zones = null;
    try {
      const res = await LD.call("cf_zones", { page: 1, per_page: 50 });
      if (res.ok === false) {
        S.zones = [];
        S.tabErrors.zones = res;
      } else {
        S.zones = res.zones || [];
        if (S.zones.length > 0 && !S.zones.some((z) => z.id === S.currentZoneId)) {
          S.currentZoneId = S.zones[0].id;
        }
      }
    } catch (err) {
      S.tabErrors.zones = { error: err.message };
    } finally {
      S.loading = false;
    }
  }

  async function loadOverviewData() {
    const zid = activeZoneId();
    if (!zid) return;
    S.analyticsErr = null;
    const [anRes, detRes, tunRes, r2Res] = await Promise.all([
      LD.call("cf_analytics", { zone_id: zid, days: S.analyticsDays }).catch((e) => ({ ok: false, error: e.message })),
      LD.call("cf_zone_details", { zone_id: zid }).catch(() => null),
      S.tunnels.length ? Promise.resolve(null) : LD.call("cf_tunnels").catch(() => null),
      S.r2Buckets.length ? Promise.resolve(null) : LD.call("cf_r2_buckets").catch(() => null),
    ]);
    if (anRes?.ok) {
      S.analytics = anRes;
    } else {
      S.analytics = null;
      S.analyticsErr = anRes;
    }
    if (detRes?.ok) S.zoneDetails = detRes.zone;
    if (tunRes?.ok) S.tunnels = tunRes.tunnels || [];
    if (r2Res?.ok) S.r2Buckets = r2Res.buckets || [];
  }

  async function loadDnsRecords() {
    const zid = activeZoneId();
    if (!zid) return;
    S.tabErrors.dns = null;
    try {
      const res = await LD.call("cf_dns_list", {
        zone_id: zid,
        record_type: S.dnsFilterType === "ALL" ? "" : S.dnsFilterType,
        name: S.dnsSearch || "",
      });
      if (res.ok === false) {
        S.dnsRecords = [];
        S.tabErrors.dns = res;
      } else {
        S.dnsRecords = res.records || [];
      }
    } catch (err) {
      S.tabErrors.dns = { error: err.message };
    }
  }

  async function loadEdgeSettings() {
    const zid = activeZoneId();
    if (!zid) return;
    S.tabErrors.edge = null;
    const [bundleRes, devRes, sslRes] = await Promise.all([
      LD.call("cf_zone_settings", { zone_id: zid }).catch((e) => ({ ok: false, error: e.message })),
      LD.call("cf_dev_mode_get", { zone_id: zid }).catch(() => null),
      LD.call("cf_ssl_certs", { zone_id: zid }).catch(() => null),
    ]);
    if (bundleRes?.ok) {
      S.zoneSettings = bundleRes.settings || {};
    } else {
      S.tabErrors.edge = bundleRes;
    }
    if (devRes?.ok) {
      S.devMode = Boolean(devRes.enabled ?? devRes.dev_mode);
      S.devModeTime = devRes.time_remaining || 0;
    }
    if (sslRes?.ok) {
      S.universalSsl = sslRes.universal || {};
      S.certPacks = sslRes.packs || [];
    }
  }

  async function loadSecurityData() {
    const zid = activeZoneId();
    if (!zid) return;
    S.tabErrors.security = null;
    const [secRes, botRes, ipRes, wafRes, pageRes, bundleRes] = await Promise.all([
      LD.call("cf_security_level_get", { zone_id: zid }).catch((e) => ({ ok: false, error: e.message })),
      LD.call("cf_bot_get", { zone_id: zid }).catch(() => null),
      LD.call("cf_ip_rules", { zone_id: zid }).catch(() => null),
      LD.call("cf_waf_rules", { zone_id: zid }).catch(() => null),
      LD.call("cf_page_rules", { zone_id: zid }).catch(() => null),
      Object.keys(S.zoneSettings).length ? Promise.resolve(null) : LD.call("cf_zone_settings", { zone_id: zid }).catch(() => null),
    ]);
    if (secRes?.ok === false) S.tabErrors.security = secRes;
    else if (secRes?.level) S.securityLevel = secRes.level;
    if (botRes?.ok) S.botFightMode = Boolean(botRes.fight_mode);
    if (ipRes?.ok) S.ipRules = ipRes.rules || [];
    if (wafRes?.ok) S.wafRules = wafRes.rules || [];
    if (pageRes?.ok) S.pageRules = pageRes.rules || [];
    if (bundleRes?.ok) S.zoneSettings = bundleRes.settings || {};
  }

  async function loadComputeData() {
    const zid = activeZoneId();
    S.tabErrors.compute = null;
    const [wrkRes, rtRes, pgRes] = await Promise.all([
      LD.call("cf_workers").catch((e) => ({ ok: false, error: e.message })),
      zid ? LD.call("cf_worker_routes", { zone_id: zid }).catch(() => null) : Promise.resolve(null),
      LD.call("cf_pages_projects").catch(() => null),
    ]);
    if (wrkRes?.ok) {
      S.workers = wrkRes.scripts || [];
      S.workerSubdomain = wrkRes.subdomain || "";
    } else if (wrkRes?.ok === false) {
      S.tabErrors.compute = wrkRes;
    }
    if (rtRes?.ok) S.workerRoutes = rtRes.routes || [];
    if (pgRes?.ok) {
      S.pagesProjects = pgRes.projects || [];
      if (S.pagesProjects.length && !S.activePagesProject) {
        S.activePagesProject = S.pagesProjects[0].name;
      }
      if (S.activePagesProject) {
        const depRes = await LD.call("cf_pages_deployments", { project: S.activePagesProject }).catch(() => null);
        if (depRes?.ok) S.pagesDeployments = depRes.deployments || [];
      }
    }
  }

  async function loadR2Buckets() {
    S.tabErrors.r2 = null;
    try {
      const res = await LD.call("cf_r2_buckets");
      if (res.ok === false) {
        S.r2Buckets = [];
        S.tabErrors.r2 = res;
      } else {
        S.r2Buckets = res.buckets || [];
      }
    } catch (err) {
      S.tabErrors.r2 = { error: err.message };
    }
  }

  async function loadKvData() {
    S.tabErrors.kv = null;
    const nsRes = await LD.call("cf_kv_namespaces", { page: 1 }).catch((e) => ({ ok: false, error: e.message }));
    if (nsRes?.ok === false) {
      S.kvNamespaces = [];
      S.tabErrors.kv = nsRes;
      return;
    }
    S.kvNamespaces = nsRes.namespaces || [];
    if (S.kvNamespaces.length && !S.kvNamespaces.some((ns) => ns.id === S.activeKvId)) {
      S.activeKvId = S.kvNamespaces[0].id;
    }
    if (S.activeKvId) {
      const kRes = await LD.call("cf_kv_keys", { namespace_id: S.activeKvId, prefix: S.kvPrefix || "" }).catch(() => null);
      S.kvKeys = kRes?.ok ? (kRes.keys || []) : [];
    } else {
      S.kvKeys = [];
    }
  }

  async function loadD1Data() {
    S.tabErrors.d1 = null;
    const res = await LD.call("cf_d1_list").catch((e) => ({ ok: false, error: e.message }));
    if (res?.ok === false) {
      S.d1Databases = [];
      S.tabErrors.d1 = res;
      return;
    }
    S.d1Databases = res.databases || [];
    if (S.d1Databases.length && !S.d1Databases.some((db) => db.uuid === S.activeD1Id)) {
      S.activeD1Id = S.d1Databases[0].uuid;
    }
  }

  async function loadStorageData() {
    if (S.storageSub === "r2") await loadR2Buckets();
    else if (S.storageSub === "kv") await loadKvData();
    else await loadD1Data();
  }

  async function loadTunnels() {
    S.tabErrors.tunnels = null;
    try {
      const res = await LD.call("cf_tunnels");
      if (res.ok === false) {
        S.tunnels = [];
        S.tabErrors.tunnels = res;
      } else {
        S.tunnels = res.tunnels || [];
      }
    } catch (err) {
      S.tabErrors.tunnels = { error: err.message };
    }
  }

  async function loadExtrasData() {
    S.tabErrors.extras = null;
    const zid = activeZoneId();
    const [tsRes, emRes] = await Promise.all([
      LD.call("cf_turnstile_list").catch((e) => ({ ok: false, error: e.message })),
      zid ? LD.call("cf_email_rules", { zone_id: zid }).catch(() => null) : Promise.resolve(null),
    ]);
    if (tsRes?.ok) S.turnstileWidgets = tsRes.widgets || [];
    else if (tsRes?.ok === false) S.tabErrors.extras = tsRes;
    if (emRes?.ok) {
      S.emailRouting = emRes.routing || {};
      S.emailRules = emRes.rules || [];
    }
  }

  async function loadCurrentTabData(force = true) {
    if (!S.status.configured) return;
    if (S.tab === "overview" && (force || !S.analytics)) await loadOverviewData();
    else if (S.tab === "dns" && (force || !S.dnsRecords.length)) await loadDnsRecords();
    else if (S.tab === "edge") await loadEdgeSettings();
    else if (S.tab === "security") await loadSecurityData();
    else if (S.tab === "compute") await loadComputeData();
    else if (S.tab === "storage") await loadStorageData();
    else if (S.tab === "tunnels") await loadTunnels();
    else if (S.tab === "extras") await loadExtrasData();
  }

  // ── Rendering Helpers ────────────────────────────────────────────────────

  function renderErrorBanner(err, retryBtnId = "") {
    if (!err || (!err.error && !err.cause_title)) return "";
    const isAr = (window.I18N && window.I18N.getLang && window.I18N.getLang() === "ar");
    const rawTitle = (isAr ? err.cause_title_ar : null) || err.cause_title;
    const title = rawTitle || (err.cause_key ? tr(`cf_err_${err.cause_key}_title`, err.cause_title || tr("cf_err_notice", "Cloudflare Notice")) : tr("cf_err_notice", "Cloudflare Notice"));
    const rawExplanation = (isAr ? err.cause_explanation_ar : null) || err.cause_explanation;
    const explanation = rawExplanation || err.error || tr("cf_err_default", "An error occurred while communicating with Cloudflare API.");
    const rawAction = (isAr ? err.cause_action_ar : null) || err.cause_action;
    const url = err.dashboard_url || "";
    const perm = err.required_perm || "";
    const code = err.error_code || err.status_code || "";

    return `
      <div class="card cf-error-banner">
        <div class="cf-error-head">
          <div class="cf-error-title-wrap">
            <div class="cf-error-icon">${icon("alert")}</div>
            <div>
              <b class="cf-error-title">${esc(title)}</b>
              <div class="muted sm mono">${code ? `Code: ${esc(code)} · ` : ""}${esc(err.error || title)}</div>
            </div>
          </div>
          <div class="btn-row">
            ${url ? `<button type="button" class="btn sm primary" data-cf-web="${esc(url)}">${icon("browser")}<span>${esc(tr("cf_err_fix_in_cf", "Fix in Cloudflare"))}</span></button>` : ""}
            ${retryBtnId ? `<button type="button" class="btn sm ghost" id="${esc(retryBtnId)}">${icon("refresh")}<span>${esc(tr("cf_err_retry", "Retry"))}</span></button>` : ""}
          </div>
        </div>
        <div class="cf-error-body">
          <div><b>${esc(tr("cf_err_cause", "Root Cause:"))}</b> ${esc(explanation)}</div>
          ${perm ? `<div style="color:var(--accent)"><b>${esc(tr("cf_err_required_perm", "Required API Permission:"))}</b> <code>${esc(perm)}</code></div>` : ""}
          ${rawAction ? `<div style="color:var(--green)"><b>${esc(tr("cf_err_suggested_action", "Suggested Fix:"))}</b> ${esc(rawAction)}</div>` : ""}
        </div>
      </div>
    `;
  }

  function renderZoneSelector(selectId = "cf-global-zone-select") {
    if (!S.zones.length) {
      return `
        <div class="cf-zone-bar card">
          <div class="muted sm">${esc(tr("cf_no_domains_hint", "No domains found in this account yet."))}</div>
          <button type="button" class="btn sm primary" id="btn-cf-add-zone">${icon("plus")}<span>${esc(tr("cf_add_domain", "Add Domain"))}</span></button>
        </div>
      `;
    }
    const cz = currentZone();
    return `
      <div class="cf-zone-bar card">
        <div class="cf-zone-bar-left">
          <span class="muted sm" style="font-weight:600;">${icon("globe")} ${esc(tr("cf_active_domain", "Active Domain:"))}</span>
          <select id="${esc(selectId)}" class="input sm cf-zone-select">
            ${S.zones.map((z) => `
              <option value="${esc(z.id)}" ${z.id === (cz && cz.id) ? "selected" : ""}>
                ${esc(z.name)} (${esc(z.status)})
              </option>
            `).join("")}
          </select>
          ${cz ? `
            <span class="chip sm ${cz.status === "active" ? "ok" : "warn"}">${esc(cz.status)}</span>
            <span class="chip sm muted">${esc(cz.plan || "Free")}</span>
          ` : ""}
        </div>
        <div class="cf-zone-bar-right">
          ${cz && cz.status !== "active" ? `<button type="button" class="btn sm" id="btn-cf-check-activation">${icon("refresh")}<span>${esc(tr("cf_check_ns", "Check Nameservers"))}</span></button>` : ""}
          <button type="button" class="btn sm ghost" id="btn-cf-add-zone">${icon("plus")}<span>${esc(tr("cf_add_domain", "Add Domain"))}</span></button>
        </div>
      </div>
    `;
  }

  // ── Main Render ──────────────────────────────────────────────────────────

  function render() {
    const root = view();
    if (!root) return;

    if (!S.status.configured) {
      root.innerHTML = renderOnboarding();
      attachOnboardingEvents(root);
      return;
    }

    const accounts = S.status.accounts || [];
    const navTabs = [
      ["overview", "home", tr("cf_tab_overview", "Overview & Analytics")],
      ["dns", "globe", tr("cf_tab_dns", "DNS Records")],
      ["edge", "zap", tr("cf_tab_edge", "SSL, Speed & Cache")],
      ["security", "lock", tr("cf_tab_security", "Security, WAF & Rules")],
      ["compute", "cpu", tr("cf_tab_compute", "Workers & Pages")],
      ["storage", "database", tr("cf_tab_storage", "R2, KV & D1")],
      ["tunnels", "cloud", tr("cf_tab_tunnels", "Zero Trust Tunnels")],
      ["extras", "sparkles", tr("cf_tab_extras", "Turnstile & Email")],
    ];

    root.innerHTML = `
      <header class="view-header cf-hub-header">
        <div class="cf-identity">
          <div class="cf-brand-emblem">${icon("cloud")}</div>
          <div>
            <div class="cf-identity-title-row">
              <h1>${esc(S.status.account_name || "Cloudflare Platform")}</h1>
              <span class="chip sm ok">${esc(tr("cf_connected", "Connected"))}</span>
              ${accounts.length > 1 ? `<button type="button" class="chip sm primary" id="cf-chip-acc-count" title="${esc(tr("cf_manage_accounts", "Manage Accounts"))}">${accounts.length} ${esc(tr("cf_accounts", "Accounts"))}</button>` : ""}
            </div>
            <p class="subtitle">${esc(tr("cf_hub_subtitle", "Full-stack edge control: DNS, SSL, Cache, WAF, Workers, Pages, R2, KV, D1, Tunnels, Turnstile & Email."))}</p>
          </div>
        </div>

        <div class="cf-header-controls">
          <button type="button" class="btn sm" id="btn-cf-live-web" title="${esc(tr("cf_live_web_tip", "Open full Cloudflare Dashboard inside the app"))}" data-cf-web="">
            ${icon("browser")}<span>${esc(tr("cf_live_web", "Live Cloudflare Web"))}</span>
          </button>

          <div class="cf-account-pill">
            <span class="cf-account-pill-label">${icon("cpu")}<span>${esc(tr("cf_account", "Account:"))}</span></span>
            <select id="cf-account-select">
              ${accounts.map((a) => `
                <option value="${esc(a.account_id)}" ${a.is_active ? "selected" : ""}>
                  ${esc(a.account_name || a.account_id)} ${a.is_active ? "✔" : ""}
                </option>
              `).join("")}
            </select>
          </div>

          <button type="button" class="btn sm" id="btn-cf-add-account" title="${esc(tr("cf_add_account", "Add Account"))}">
            ${icon("plus")}<span>${esc(tr("cf_add_account", "Add Account"))}</span>
          </button>
          <button type="button" class="btn sm ghost" id="btn-cf-manage-accounts" title="${esc(tr("cf_manage_accounts", "Manage Accounts"))}">${icon("settings")}</button>
          <button type="button" class="btn sm ghost" id="btn-cf-refresh" title="${esc(tr("refresh", "Refresh"))}">${icon("refresh")}</button>
          <button type="button" class="btn sm ghost danger" id="btn-cf-disconnect" title="${esc(tr("cf_disconnect", "Disconnect"))}">${icon("unlink")}</button>
        </div>
      </header>

      <div class="cf-sub-nav">
        ${navTabs.map(([id, ic, label]) => `
          <button type="button" class="tab-btn ${S.tab === id ? "active" : ""}" data-cf-tab="${id}">
            ${icon(ic)}<span>${esc(label)}</span>
          </button>
        `).join("")}
      </div>

      <div class="view-body cf-hub-body">
        ${S.error ? `<div class="notice" style="margin-bottom:16px">${icon("alert")}<span>${esc(S.error)}</span></div>` : ""}
        ${renderActiveTab()}
      </div>
    `;

    attachMainEvents(root);
  }

  function renderOnboarding() {
    const locked = Boolean(S.status.vault_locked);
    return `
      <header class="view-header">
        <div>
          <h1>${icon("cloud")} ${esc(tr("cf_hub_title", "Cloudflare Platform Hub"))}</h1>
          <p class="subtitle">${esc(tr("cf_onboarding_sub", "Connect your Cloudflare account to manage DNS, SSL, WAF, Workers, Pages, R2, D1, Tunnels, and more."))}</p>
        </div>
        <div class="header-actions">
          <button type="button" class="btn sm" id="btn-cf-live-web-onboard" data-cf-web="https://dash.cloudflare.com">
            ${icon("browser")}<span>${esc(tr("cf_live_web", "Live Cloudflare Web"))}</span>
          </button>
        </div>
      </header>
      <div class="view-body cf-onboarding-wrap">
        <div class="card cf-onboarding-card">
          ${locked ? `
            <div class="notice warn" style="margin-bottom:16px">
              ${icon("lock")}
              <div>
                <b>${esc(tr("cf_vault_locked_title", "Credential Vault is Locked"))}</b>
                <div class="sm">${esc(tr("cf_vault_locked_desc", "Your saved Cloudflare API Token is Vault-protected. Unlock the Vault in Settings -> Credential Vault to reconnect automatically."))}</div>
              </div>
            </div>
          ` : ""}
          <div style="text-align:center;margin-bottom:20px">
            <div class="cf-onboarding-hero">${icon("cloud")}</div>
            <h2 style="margin:0 0 6px">${esc(tr("cf_connect_account", "Connect Cloudflare Account"))}</h2>
            <p class="muted sm" style="margin:0">${esc(tr("cf_connect_desc", "Create an API Token in your Cloudflare dashboard or open Live Cloudflare Web directly inside the app."))}</p>
          </div>

          <form id="cf-onboarding-form" style="display:flex;flex-direction:column;gap:14px">
            <label class="field">
              <span><b>${esc(tr("cf_account_label", "Account Label (optional)"))}</b></span>
              <input type="text" id="cf-account-label-input" placeholder="e.g. Production, Personal, Client X" autocomplete="off">
            </label>

            <label class="field">
              <span><b>${esc(tr("cf_api_token", "Cloudflare API Token"))}</b> <small style="color:var(--red)">*</small></span>
              <input type="password" id="cf-token-input" placeholder="e.g. 7_Abc123XyZ..." required autocomplete="off" spellcheck="false" class="mono">
            </label>
            <small class="muted">
              <a href="https://dash.cloudflare.com/profile/api-tokens" class="link" data-cf-web="https://dash.cloudflare.com/profile/api-tokens">${esc(tr("cf_get_token_link", "Open Cloudflare API Tokens Dashboard"))}</a>
            </small>

            <div id="cf-verify-result"></div>

            <div class="btn-row" style="justify-content:flex-end">
              <button type="submit" class="btn primary" id="btn-verify-cf">${icon("check")}<span>${esc(tr("cf_verify_connect", "Verify & Connect"))}</span></button>
            </div>
          </form>

          <div class="cf-perm-checklist">
            <b class="muted sm">${esc(tr("cf_recommended_perms", "Recommended API Token Scopes for Full Control:"))}</b>
            <div class="cf-perm-grid">
              <span class="chip sm muted">Zone > Zone: Edit</span>
              <span class="chip sm muted">Zone > DNS: Edit</span>
              <span class="chip sm muted">Zone > Zone Settings &amp; SSL: Edit</span>
              <span class="chip sm muted">Zone > Firewall &amp; Page Rules: Edit</span>
              <span class="chip sm muted">Zone > Analytics: Read</span>
              <span class="chip sm muted">Zone > Email Routing Rules: Edit</span>
              <span class="chip sm muted">Account > Workers Scripts &amp; KV &amp; D1: Edit</span>
              <span class="chip sm muted">Account > R2 Storage &amp; Pages: Edit</span>
              <span class="chip sm muted">Account > Cloudflare Tunnel &amp; Turnstile: Edit</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function renderActiveTab() {
    switch (S.tab) {
      case "overview": return renderOverviewTab();
      case "dns": return renderDnsTab();
      case "edge": return renderEdgeTab();
      case "security": return renderSecurityTab();
      case "compute": return renderComputeTab();
      case "storage": return renderStorageTab();
      case "tunnels": return renderTunnelsTab();
      case "extras": return renderExtrasTab();
      default: return "";
    }
  }

  // ── Tab 1: Overview & Analytics ──────────────────────────────────────────

  function renderOverviewTab() {
    const cz = currentZone();
    const det = S.zoneDetails || cz;
    const totals = S.analytics?.totals || {};
    const series = S.analytics?.series || [];
    const maxReq = Math.max(1, ...series.map((pt) => Number(pt.requests || 0)));

    return `
      <div class="cf-stack">
        ${renderZoneSelector("cf-ov-zone-select")}
        ${S.tabErrors.zones ? renderErrorBanner(S.tabErrors.zones, "btn-retry-zones") : ""}

        <div class="cf-stats-grid">
          <div class="card cf-stat-card">
            <span class="cf-stat-label">${icon("globe")} ${esc(tr("cf_stat_zones", "Active Domains"))}</span>
            <b class="cf-stat-val">${S.zones.length}</b>
          </div>
          <div class="card cf-stat-card">
            <span class="cf-stat-label">${icon("activity")} ${esc(tr("cf_stat_requests", "Total Requests"))}</span>
            <b class="cf-stat-val" style="color:var(--accent)">${formatCompact(totals.requests || 0)}</b>
          </div>
          <div class="card cf-stat-card">
            <span class="cf-stat-label">${icon("zap")} ${esc(tr("cf_stat_cache_ratio", "Cache Hit Ratio"))}</span>
            <b class="cf-stat-val" style="color:var(--green)">${totals.cache_hit_ratio ?? 0}%</b>
          </div>
          <div class="card cf-stat-card">
            <span class="cf-stat-label">${icon("server")} ${esc(tr("cf_stat_bandwidth", "Bandwidth Served"))}</span>
            <b class="cf-stat-val">${formatBytes(totals.bytes || 0)}</b>
          </div>
          <div class="card cf-stat-card">
            <span class="cf-stat-label">${icon("lock")} ${esc(tr("cf_stat_threats", "Threats Blocked"))}</span>
            <b class="cf-stat-val" style="color:var(--red)">${formatCompact(totals.threats || 0)}</b>
          </div>
          <div class="card cf-stat-card">
            <span class="cf-stat-label">${icon("database")} R2 / Tunnels</span>
            <b class="cf-stat-val">${S.r2Buckets.length} / ${S.tunnels.length}</b>
          </div>
        </div>

        ${cz ? `
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <div>
                <h3>${icon("activity")} ${esc(tr("cf_traffic_analytics", "HTTP Traffic Analytics"))} — ${esc(cz.name)}</h3>
                <p class="muted sm">${esc(tr("cf_analytics_sub", "Requests, cached edge responses, unique visitors, and blocked threats via Cloudflare GraphQL."))}</p>
              </div>
              <div class="btn-row">
                ${[1, 7, 30].map((d) => `
                  <button type="button" class="btn xs ${S.analyticsDays === d ? "primary" : "ghost"}" data-an-days="${d}">${d === 1 ? "24h" : `${d}d`}</button>
                `).join("")}
                <button type="button" class="btn xs ghost" data-cf-web="https://dash.cloudflare.com/${esc(S.status.account_id)}/${esc(cz.name)}/analytics/traffic">${icon("browser")}<span>${esc(tr("cf_open_in_web", "Web Analytics"))}</span></button>
              </div>
            </div>
            ${S.analyticsErr ? renderErrorBanner(S.analyticsErr) : series.length ? `
              <div class="cf-analytics-chart">
                ${series.map((pt) => {
                  const pct = Math.max(6, Math.round((Number(pt.requests || 0) / maxReq) * 100));
                  const cpct = pt.requests ? Math.round((Number(pt.cached_requests || 0) / Number(pt.requests || 1)) * 100) : 0;
                  return `
                    <div class="cf-bar-col" title="${esc(pt.date)}: ${formatCompact(pt.requests)} reqs (${cpct}% cached), ${formatBytes(pt.bytes)}, ${pt.threats} threats">
                      <div class="cf-bar-track">
                        <div class="cf-bar-fill" style="height:${pct}%">
                          <div class="cf-bar-cached" style="height:${cpct}%"></div>
                        </div>
                      </div>
                      <span class="cf-bar-date">${esc((pt.date || "").slice(5))}</span>
                    </div>
                  `;
                }).join("")}
              </div>
              <div class="cf-chart-legend muted sm">
                <span><i class="cf-dot total"></i> ${esc(tr("cf_total_reqs", "Total Requests"))} (${formatCompact(totals.requests)})</span>
                <span><i class="cf-dot cached"></i> ${esc(tr("cf_cached_reqs", "Cached Edge"))} (${formatCompact(totals.cached_requests)})</span>
                <span><i class="cf-dot uniq"></i> ${esc(tr("cf_unique_visitors", "Unique Visitors:"))} ${formatCompact(totals.uniques || 0)}</span>
              </div>
            ` : `<p class="muted sm">${esc(tr("cf_no_analytics", "No traffic recorded for this period yet."))}</p>`}
          </div>
        ` : ""}

        <div class="card cf-panel">
          <div class="cf-panel-head">
            <h3>${icon("globe")} ${esc(tr("cf_domains_list", "Domains & Nameservers"))} (${S.zones.length})</h3>
            <div class="btn-row">
              <button type="button" class="btn sm primary" id="btn-cf-add-zone-2">${icon("plus")}<span>${esc(tr("cf_add_domain", "Add Domain"))}</span></button>
              <button type="button" class="btn sm ghost" id="btn-ov-refresh-zones">${icon("refresh")}</button>
            </div>
          </div>

          ${S.zones.length === 0 ? `
            <p class="muted sm">${esc(tr("cf_no_zones_msg", "No domains found. Add your domain above to connect DNS, SSL, and Cloudflare Edge."))}</p>
          ` : `
            <div class="cf-zones-grid">
              ${S.zones.map((z) => `
                <div class="cf-zone-card ${z.id === (cz && cz.id) ? "selected" : ""}">
                  <div class="cf-zone-card-head">
                    <div>
                      <b class="cf-zone-name">${esc(z.name)}</b>
                      <div class="cf-ns-list">
                        ${(z.name_servers || []).map((ns) => `<code class="cf-ns-chip" data-copy-val="${esc(ns)}" title="Copy nameserver">${esc(ns)}</code>`).join("")}
                      </div>
                    </div>
                    <div class="btn-row" style="gap:4px">
                      <span class="chip sm ${z.status === "active" ? "ok" : "warn"}">${esc(z.status)}</span>
                      <span class="chip sm muted">${esc(z.plan || "Free")}</span>
                    </div>
                  </div>
                  <div class="cf-zone-card-actions">
                    <button type="button" class="btn xs" data-open-zone-dns="${esc(z.id)}">${icon("globe")}<span>DNS</span></button>
                    <button type="button" class="btn xs ghost" data-open-zone-edge="${esc(z.id)}">${icon("zap")}<span>SSL &amp; Cache</span></button>
                    <button type="button" class="btn xs ghost" data-open-zone-sec="${esc(z.id)}">${icon("lock")}<span>Security</span></button>
                    <button type="button" class="btn xs ghost" data-cf-web="https://dash.cloudflare.com/${esc(S.status.account_id)}/${esc(z.name)}">${icon("browser")}<span>Web</span></button>
                    <button type="button" class="btn xs ghost danger" data-delete-zone="${esc(z.id)}" data-zone-name="${esc(z.name)}" title="Delete Domain">${icon("trash")}</button>
                  </div>
                </div>
              `).join("")}
            </div>
          `}
        </div>

        ${det && det.original_name_servers?.length ? `
          <div class="card cf-panel muted sm">
            <b>${esc(det.name)} Details:</b> Created ${esc((det.created_on || "").slice(0, 10))} · Type: ${esc(det.type)} · Original NS: ${esc(det.original_name_servers.join(", "))}
          </div>
        ` : ""}
      </div>
    `;
  }

  // ── Tab 2: DNS Records ───────────────────────────────────────────────────

  function renderDnsTab() {
    const cz = currentZone();
    if (!cz) return `${renderZoneSelector()}<div class="card"><p class="muted">Select or add a domain first.</p></div>`;

    const types = ["ALL", "A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV"];
    const filtered = S.dnsRecords.filter((rec) => {
      if (S.dnsFilterType !== "ALL" && rec.type !== S.dnsFilterType) return false;
      if (S.dnsSearch) {
        const q = S.dnsSearch.toLowerCase();
        return (rec.name || "").toLowerCase().includes(q) || (rec.content || "").toLowerCase().includes(q);
      }
      return true;
    });

    return `
      <div class="cf-stack">
        ${renderZoneSelector("cf-dns-zone-select")}
        ${S.tabErrors.dns ? renderErrorBanner(S.tabErrors.dns, "btn-retry-dns") : ""}

        <div class="card cf-panel">
          <div class="cf-toolbar">
            <div class="cf-filter-row">
              <input type="text" id="cf-dns-search" class="input sm" placeholder="${esc(tr("cf_search_dns", "Filter host or IP…"))}" value="${esc(S.dnsSearch)}">
              <div class="cf-type-pills">
                ${types.map((tp) => `
                  <button type="button" class="btn xs ${S.dnsFilterType === tp ? "primary" : "ghost"}" data-dns-type="${tp}">${tp}</button>
                `).join("")}
              </div>
            </div>
            <div class="btn-row">
              <button type="button" class="btn sm ghost" id="btn-cf-dns-preset" title="Add A + www CNAME preset">${icon("zap")}<span>${esc(tr("cf_dns_quick_setup", "Quick App DNS"))}</span></button>
              <button type="button" class="btn sm primary" id="btn-cf-add-dns">${icon("plus")}<span>${esc(tr("cf_add_record", "Add Record"))}</span></button>
            </div>
          </div>

          <div style="overflow-x:auto">
            <table class="table">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Name</th>
                  <th>Content</th>
                  <th>Proxy Status</th>
                  <th>TTL</th>
                  <th style="text-align:end">Actions</th>
                </tr>
              </thead>
              <tbody>
                ${filtered.length === 0 ? `
                  <tr><td colspan="6" class="muted" style="text-align:center;padding:28px">${esc(tr("cf_no_dns_records", "No DNS records match your filter."))}</td></tr>
                ` : filtered.map((rec) => `
                  <tr>
                    <td><span class="chip sm mono">${esc(rec.type)}</span></td>
                    <td class="mono sm">${esc(rec.name)}</td>
                    <td class="mono sm cf-truncate-cell" title="${esc(rec.content)}">${esc(rec.content)}</td>
                    <td>
                      ${rec.proxiable ? `
                        <button type="button" class="btn xs ${rec.proxied ? "cf-proxy-on" : "ghost"}" data-toggle-proxy="${esc(rec.id)}" data-proxied="${rec.proxied ? "1" : "0"}">
                          ${icon("cloud")}<span>${rec.proxied ? "Proxied" : "DNS Only"}</span>
                        </button>
                      ` : `<span class="muted sm">DNS Only</span>`}
                    </td>
                    <td class="muted sm">${rec.ttl === 1 ? "Auto" : `${rec.ttl}s`}</td>
                    <td style="text-align:end;white-space:nowrap">
                      <button type="button" class="btn xs ghost" data-edit-dns="${esc(rec.id)}" title="Edit">${icon("edit")}</button>
                      <button type="button" class="btn xs ghost danger" data-delete-dns="${esc(rec.id)}" title="Delete">${icon("trash")}</button>
                    </td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  // ── Tab 3: SSL/TLS, Edge Speed & Cache ───────────────────────────────────

  function renderEdgeTab() {
    const cz = currentZone();
    if (!cz) return `${renderZoneSelector()}<div class="card"><p class="muted">Select or add a domain first.</p></div>`;

    const zs = S.zoneSettings || {};
    const sslMode = zs.ssl || "full";
    const toggleRow = (id, label, desc, onVal = "on") => {
      const checked = zs[id] === onVal || zs[id] === true;
      return `
        <div class="cf-setting-row">
          <div>
            <b>${esc(label)}</b>
            <div class="muted sm">${esc(desc)}</div>
          </div>
          <input type="checkbox" class="switch" data-zone-toggle="${esc(id)}" data-on-val="${esc(onVal)}" ${checked ? "checked" : ""}>
        </div>
      `;
    };

    return `
      <div class="cf-stack">
        ${renderZoneSelector("cf-edge-zone-select")}
        ${S.tabErrors.edge ? renderErrorBanner(S.tabErrors.edge, "btn-retry-edge") : ""}

        <div class="grid-2">
          <!-- SSL/TLS Mode & Edge Certificates -->
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <h3>${icon("lock")} ${esc(tr("cf_ssl_mode", "SSL/TLS Encryption & Certificates"))}</h3>
              <button type="button" class="btn xs ghost" data-cf-web="https://dash.cloudflare.com/${esc(S.status.account_id)}/${esc(cz.name)}/ssl-tls">${icon("browser")}</button>
            </div>
            <div class="cf-ssl-modes">
              ${[
                ["off", "Off", "Unencrypted HTTP"],
                ["flexible", "Flexible", "Edge HTTPS -> HTTP origin"],
                ["full", "Full", "Self-signed or origin SSL"],
                ["strict", "Full (Strict)", "Valid CA / Cloudflare Origin Cert"],
              ].map(([val, title, sub]) => `
                <button type="button" class="cf-mode-tile ${sslMode === val ? "active" : ""}" data-ssl-mode="${val}">
                  <b>${esc(title)}</b>
                  <span class="muted sm">${esc(sub)}</span>
                </button>
              `).join("")}
            </div>

            <div class="cf-settings-list" style="margin-top:14px">
              ${toggleRow("always_use_https", "Always Use HTTPS", "Redirect all http:// requests to https:// at the edge")}
              ${toggleRow("automatic_https_rewrites", "Automatic HTTPS Rewrites", "Rewrite insecure http:// links in HTML")}
              ${toggleRow("tls_1_3", "TLS 1.3", "Latest TLS protocol for faster, stronger handshakes")}
              <div class="cf-setting-row">
                <div><b>Minimum TLS Version</b><div class="muted sm">Block legacy TLS clients below this version</div></div>
                <select id="cf-min-tls-select" class="input sm" style="width:120px">
                  ${["1.0", "1.1", "1.2", "1.3"].map((v) => `<option value="${v}" ${(zs.min_tls_version || "1.2") === v ? "selected" : ""}>TLS ${v}</option>`).join("")}
                </select>
              </div>
              <div class="cf-setting-row">
                <div>
                  <b>Universal SSL</b>
                  <div class="muted sm">Edge SSL certificates (${esc(S.universalSsl.certificate_authority || "Auto")})</div>
                </div>
                <input type="checkbox" class="switch" id="cf-universal-ssl-toggle" ${S.universalSsl.enabled !== false ? "checked" : ""}>
              </div>
            </div>

            ${S.certPacks.length ? `
              <div class="cf-subbox">
                <b class="sm">Edge Certificates (${S.certPacks.length})</b>
                <div class="cf-pack-list">
                  ${S.certPacks.slice(0, 4).map((pk) => `
                    <div class="cf-pack-row">
                      <span class="mono sm">${esc((pk.hosts || []).join(", ") || pk.type)}</span>
                      <span class="chip sm ${pk.status === "active" ? "ok" : "warn"}">${esc(pk.status)} · ${esc(pk.certificate_authority || pk.type)}</span>
                    </div>
                  `).join("")}
                </div>
              </div>
            ` : ""}
          </div>

          <!-- Cache Purge & Performance Speed -->
          <div class="card cf-panel">
            <h3>${icon("zap")} ${esc(tr("cf_cache_speed", "Cache & Edge Performance"))}</h3>
            <div class="cf-setting-row" style="margin-bottom:12px">
              <div>
                <b>${esc(tr("cf_dev_mode", "Development Mode"))}</b>
                <div class="muted sm">Bypass CDN cache for 3 hours while iterating</div>
              </div>
              <button type="button" class="btn sm ${S.devMode ? "primary" : "ghost"}" id="btn-toggle-dev-mode">
                ${S.devMode ? `Enabled (${Math.ceil((S.devModeTime || 10800) / 60)}m)` : "Turn On (3h)"}
              </button>
            </div>

            <div class="cf-subbox">
              <div class="cf-panel-head" style="margin-bottom:8px">
                <b class="sm">${esc(tr("cf_purge_cache", "Purge Edge Cache"))}</b>
                <button type="button" class="btn xs primary" id="btn-cf-purge-all">${icon("trash")}<span>${esc(tr("cf_purge_everything", "Purge Everything"))}</span></button>
              </div>
              <textarea id="cf-purge-urls-input" class="input" rows="2" placeholder="https://${esc(cz.name)}/build/assets/app.css"></textarea>
              <div style="display:flex;justify-content:flex-end;margin-top:8px">
                <button type="button" class="btn xs" id="btn-cf-purge-urls">${icon("check")}<span>${esc(tr("cf_purge_urls", "Purge Listed URLs"))}</span></button>
              </div>
            </div>

            <div class="cf-settings-list" style="margin-top:12px">
              <div class="cf-setting-row">
                <div><b>Caching Level</b><div class="muted sm">Query string cache key behavior</div></div>
                <select id="cf-cache-level-select" class="input sm" style="width:150px">
                  ${[["simplified", "Ignore Query String"], ["basic", "No Query String"], ["aggressive", "Standard"]].map(([v, l]) => `
                    <option value="${v}" ${(zs.cache_level || "aggressive") === v ? "selected" : ""}>${l}</option>
                  `).join("")}
                </select>
              </div>
              <div class="cf-setting-row">
                <div><b>Browser Cache TTL</b><div class="muted sm">Client browser cache expiration</div></div>
                <select id="cf-browser-ttl-select" class="input sm" style="width:150px">
                  ${[[0, "Respect Existing"], [1800, "30 Minutes"], [14400, "4 Hours"], [86400, "1 Day"], [2592000, "1 Month"], [31536000, "1 Year"]].map(([v, l]) => `
                    <option value="${v}" ${Number(zs.browser_cache_ttl ?? 14400) === v ? "selected" : ""}>${l}</option>
                  `).join("")}
                </select>
              </div>
              ${toggleRow("brotli", "Brotli Compression", "Serve smaller compressed assets over HTTPS")}
              ${toggleRow("http3", "HTTP/3 (with QUIC)", "Low-latency UDP transport at the Cloudflare edge")}
              ${toggleRow("early_hints", "Early Hints (103)", "Preload linked stylesheets and scripts before response finishes")}
              ${toggleRow("always_online", "Always Online", "Serve stale cached pages if your origin goes down")}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // ── Tab 4: Security, WAF, IP Access & Page Rules ─────────────────────────

  function renderSecurityTab() {
    const cz = currentZone();
    if (!cz) return `${renderZoneSelector()}<div class="card"><p class="muted">Select or add a domain first.</p></div>`;
    const zs = S.zoneSettings || {};
    const levels = [
      ["essentially_off", "Off (Trusted)", "Only severe attackers"],
      ["low", "Low", "Most threatening visitors"],
      ["medium", "Medium (Default)", "Balanced protection"],
      ["high", "High", "Strict security challenge"],
      ["under_attack", "I'm Under Attack™", "Interstitial challenge for every visitor"],
    ];

    return `
      <div class="cf-stack">
        ${renderZoneSelector("cf-security-zone-select")}
        ${S.tabErrors.security ? renderErrorBanner(S.tabErrors.security, "btn-retry-security") : ""}

        <div class="grid-2">
          <!-- DDoS Security Level + Bot Fight -->
          <div class="card cf-panel">
            <h3>${icon("lock")} ${esc(tr("cf_sec_posture", "Edge Security Posture & DDoS"))}</h3>
            <div class="cf-sec-levels">
              ${levels.map(([id, title, sub]) => `
                <button type="button" class="cf-mode-tile ${S.securityLevel === id ? "active" : ""} ${id === "under_attack" ? "danger-tile" : ""}" data-sec-level-btn="${id}">
                  <b>${esc(title)}</b>
                  <span class="muted sm">${esc(sub)}</span>
                </button>
              `).join("")}
            </div>
            <div class="cf-settings-list" style="margin-top:14px">
              <div class="cf-setting-row">
                <div><b>Bot Fight Mode</b><div class="muted sm">Detect and challenge known automated bots</div></div>
                <input type="checkbox" class="switch" id="cf-bot-fight-toggle" ${S.botFightMode ? "checked" : ""}>
              </div>
              <div class="cf-setting-row">
                <div><b>Hotlink Protection</b><div class="muted sm">Prevent external sites from embedding your images</div></div>
                <input type="checkbox" class="switch" data-zone-toggle="hotlink_protection" data-on-val="on" ${zs.hotlink_protection === "on" ? "checked" : ""}>
              </div>
              <div class="cf-setting-row">
                <div><b>Email Obfuscation</b><div class="muted sm">Hide email addresses from scraper bots</div></div>
                <input type="checkbox" class="switch" data-zone-toggle="email_obfuscation" data-on-val="on" ${zs.email_obfuscation === "on" ? "checked" : ""}>
              </div>
            </div>
          </div>

          <!-- IP / Country / ASN Access Rules -->
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <h3>${icon("filter")} ${esc(tr("cf_ip_access_rules", "IP & Country Access Rules"))} (${S.ipRules.length})</h3>
              <button type="button" class="btn xs primary" id="btn-cf-add-ip-rule">${icon("plus")}<span>Add IP Rule</span></button>
            </div>
            <div class="cf-rule-list">
              ${S.ipRules.length === 0 ? `<p class="muted sm">No custom IP, CIDR, or Country access rules configured.</p>` : S.ipRules.map((rl) => `
                <div class="cf-rule-row">
                  <div>
                    <span class="chip sm ${rl.mode === "block" ? "danger" : rl.mode === "whitelist" ? "ok" : "warn"}">${esc(rl.mode)}</span>
                    <b class="mono sm">${esc(rl.value)}</b>
                    <span class="muted sm">(${esc(rl.target)})</span>
                    ${rl.notes ? `<div class="muted sm">${esc(rl.notes)}</div>` : ""}
                  </div>
                  <button type="button" class="btn xs ghost danger" data-del-ip-rule="${esc(rl.id)}">${icon("trash")}</button>
                </div>
              `).join("")}
            </div>
          </div>
        </div>

        <div class="grid-2">
          <!-- Custom WAF Rules -->
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <h3>${icon("wrench")} ${esc(tr("cf_waf_rules", "Custom WAF Firewall Rules"))} (${S.wafRules.length})</h3>
              <button type="button" class="btn xs primary" id="btn-cf-add-waf-rule">${icon("plus")}<span>New WAF Rule</span></button>
            </div>
            <div class="cf-rule-list">
              ${S.wafRules.length === 0 ? `<p class="muted sm">No custom WAF expressions yet. Block paths like /wp-login.php, specific countries, or suspicious User-Agents.</p>` : S.wafRules.map((rl) => `
                <div class="cf-rule-row">
                  <div style="min-width:0">
                    <div>
                      <span class="chip sm ${rl.action === "block" ? "danger" : "warn"}">${esc(rl.action)}</span>
                      <b>${esc(rl.description || "WAF Rule")}</b>
                    </div>
                    <code class="cf-expr-code">${esc(rl.expression)}</code>
                  </div>
                  ${rl.id ? `<button type="button" class="btn xs ghost danger" data-del-waf-rule="${esc(rl.id)}">${icon("trash")}</button>` : ""}
                </div>
              `).join("")}
            </div>
          </div>

          <!-- Page Rules / Redirects -->
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <h3>${icon("link")} ${esc(tr("cf_page_rules", "Page Rules & Redirects"))} (${S.pageRules.length})</h3>
              <button type="button" class="btn xs primary" id="btn-cf-add-page-rule">${icon("plus")}<span>Add Page Rule</span></button>
            </div>
            <div class="cf-rule-list">
              ${S.pageRules.length === 0 ? `<p class="muted sm">No Page Rules set. Create 301/302 URL forwarding or custom Cache Everything rules.</p>` : S.pageRules.map((pr) => {
                const pat = pr.targets?.[0]?.constraint?.value || "";
                const acts = (pr.actions || []).map((a) => a.id === "forwarding_url" ? `Forward -> ${a.value?.url || ""}` : `${a.id}: ${a.value ?? "on"}`).join(", ");
                return `
                  <div class="cf-rule-row">
                    <div>
                      <span class="chip sm ${pr.status === "active" ? "ok" : "muted"}">${esc(pr.status)}</span>
                      <b class="mono sm">${esc(pat)}</b>
                      <div class="muted sm">${esc(acts)}</div>
                    </div>
                    <button type="button" class="btn xs ghost danger" data-del-page-rule="${esc(pr.id)}">${icon("trash")}</button>
                  </div>
                `;
              }).join("")}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // ── Tab 5: Workers & Pages ───────────────────────────────────────────────

  function renderComputeTab() {
    const cz = currentZone();
    return `
      <div class="cf-stack">
        ${S.tabErrors.compute ? renderErrorBanner(S.tabErrors.compute, "btn-retry-compute") : ""}

        <div class="grid-2">
          <!-- Workers Scripts -->
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <div>
                <h3>${icon("cpu")} Cloudflare Workers (${S.workers.length})</h3>
                ${S.workerSubdomain ? `<div class="muted sm mono">*.${esc(S.workerSubdomain)}.workers.dev</div>` : ""}
              </div>
              <button type="button" class="btn xs ghost" data-cf-web="https://dash.cloudflare.com/${esc(S.status.account_id)}/workers-and-pages">${icon("browser")}<span>Workers Studio</span></button>
            </div>
            <div class="cf-rule-list">
              ${S.workers.length === 0 ? `<p class="muted sm">No Workers scripts deployed on this account.</p>` : S.workers.map((w) => `
                <div class="cf-rule-row">
                  <div>
                    <b class="mono">${esc(w.id)}</b>
                    <div class="muted sm">${w.url ? `<span class="mono">${esc(w.url)}</span>` : "No workers.dev route"}</div>
                  </div>
                  <div class="btn-row" style="gap:4px">
                    ${w.url ? `<button type="button" class="btn xs ghost" data-copy-val="${esc(w.url)}" title="Copy URL">${icon("copy")}</button>` : ""}
                    <button type="button" class="btn xs ghost danger" data-del-worker="${esc(w.id)}" title="Delete Script">${icon("trash")}</button>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>

          <!-- Zone Worker Routes -->
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <h3>${icon("link")} Worker HTTP Routes ${cz ? `(${esc(cz.name)})` : ""}</h3>
              ${cz ? `<button type="button" class="btn xs primary" id="btn-cf-add-worker-route">${icon("plus")}<span>Add Route</span></button>` : ""}
            </div>
            ${!cz ? `<p class="muted sm">Select a domain in Overview to inspect zone routes.</p>` : `
              <div class="cf-rule-list">
                ${S.workerRoutes.length === 0 ? `<p class="muted sm">No Worker routes bound to ${esc(cz.name)}.</p>` : S.workerRoutes.map((rt) => `
                  <div class="cf-rule-row">
                    <div>
                      <b class="mono sm">${esc(rt.pattern)}</b>
                      <div class="muted sm">Script: <code>${esc(rt.script || "(disabled)")}</code></div>
                    </div>
                    <button type="button" class="btn xs ghost danger" data-del-worker-route="${esc(rt.id)}">${icon("trash")}</button>
                  </div>
                `).join("")}
              </div>
            `}
          </div>
        </div>

        <!-- Cloudflare Pages -->
        <div class="card cf-panel">
          <div class="cf-panel-head">
            <h3>${icon("layers")} Cloudflare Pages (${S.pagesProjects.length})</h3>
            <div class="btn-row">
              ${S.activePagesProject ? `<button type="button" class="btn sm primary" id="btn-cf-pages-deploy">${icon("rocket")}<span>Trigger Production Deploy</span></button>` : ""}
              <button type="button" class="btn sm ghost" data-cf-web="https://dash.cloudflare.com/${esc(S.status.account_id)}/workers-and-pages">${icon("browser")}<span>Open Pages</span></button>
            </div>
          </div>

          ${S.pagesProjects.length === 0 ? `<p class="muted sm">No Cloudflare Pages projects found on this account.</p>` : `
            <div class="cf-pages-layout">
              <div class="cf-rule-list">
                ${S.pagesProjects.map((pr) => `
                  <button type="button" class="cf-select-row ${pr.name === S.activePagesProject ? "active" : ""}" data-select-pages="${esc(pr.name)}">
                    <div>
                      <b>${esc(pr.name)}</b>
                      <div class="muted sm mono">${esc((pr.domains && pr.domains[0]) || `${pr.subdomain}.pages.dev`)}</div>
                    </div>
                    <span class="chip sm ${pr.latest_status === "success" ? "ok" : "muted"}">${esc(pr.latest_status || pr.production_branch)}</span>
                  </button>
                `).join("")}
              </div>
              <div class="cf-subbox">
                <b class="sm" style="display:block;margin-bottom:8px">Recent Deployments — ${esc(S.activePagesProject)}</b>
                ${S.pagesDeployments.length === 0 ? `<p class="muted sm">No deployments listed.</p>` : S.pagesDeployments.slice(0, 8).map((dep) => `
                  <div class="cf-rule-row">
                    <div style="min-width:0">
                      <div>
                        <span class="chip sm ${dep.status === "success" ? "ok" : dep.status === "failure" ? "danger" : "warn"}">${esc(dep.status || "queued")}</span>
                        <b class="mono sm">${esc(dep.short_id || (dep.id || "").slice(0, 8))}</b>
                        <span class="muted sm">${esc(dep.branch || dep.environment)}</span>
                      </div>
                      ${dep.commit_message ? `<div class="muted sm">${esc(dep.commit_message)}</div>` : ""}
                    </div>
                    <div class="btn-row" style="gap:4px">
                      ${dep.url ? `<button type="button" class="btn xs ghost" data-open-url="${esc(dep.url)}" title="Visit Preview">${icon("browser")}</button>` : ""}
                      <button type="button" class="btn xs ghost" data-retry-deploy="${esc(dep.id)}" title="Retry">${icon("refresh")}</button>
                      ${dep.status === "success" ? `<button type="button" class="btn xs ghost" data-rollback-deploy="${esc(dep.id)}" title="Rollback">${icon("rotate-ccw")}</button>` : ""}
                    </div>
                  </div>
                `).join("")}
              </div>
            </div>
          `}
        </div>
      </div>
    `;
  }

  // ── Tab 6: Storage (R2, KV, D1 SQL) ──────────────────────────────────────

  function renderStorageTab() {
    const accId = S.status.account_id || "";
    const endpointUrl = accId && !String(accId).startsWith("acc_") ? `https://${accId}.r2.cloudflarestorage.com` : "https://<account_id>.r2.cloudflarestorage.com";

    return `
      <div class="cf-stack">
        <div class="cf-sub-seg">
          <button type="button" class="btn sm ${S.storageSub === "r2" ? "primary" : "ghost"}" data-storage-sub="r2">${icon("database")}<span>R2 Object Storage</span></button>
          <button type="button" class="btn sm ${S.storageSub === "kv" ? "primary" : "ghost"}" data-storage-sub="kv">${icon("key")}<span>Workers KV</span></button>
          <button type="button" class="btn sm ${S.storageSub === "d1" ? "primary" : "ghost"}" data-storage-sub="d1">${icon("grid")}<span>D1 Serverless SQL</span></button>
        </div>

        ${S.storageSub === "r2" ? `
          ${S.tabErrors.r2 ? renderErrorBanner(S.tabErrors.r2, "btn-retry-r2") : ""}
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <div>
                <h3>${icon("database")} R2 Buckets (${S.r2Buckets.length})</h3>
                <div class="muted sm">S3 Endpoint: <code class="cf-ns-chip" data-copy-val="${esc(endpointUrl)}">${esc(endpointUrl)}</code></div>
              </div>
              <div class="btn-row">
                <button type="button" class="btn sm ghost" id="btn-refresh-r2">${icon("refresh")}</button>
                <button type="button" class="btn sm primary" id="btn-create-r2-bucket">${icon("plus")}<span>New Bucket</span></button>
              </div>
            </div>
            ${S.r2Buckets.length === 0 ? `<p class="muted sm">No R2 buckets yet. Create a bucket or connect it to a Laravel project .env in 1 click.</p>` : `
              <div class="grid-2">
                ${S.r2Buckets.map((b) => `
                  <div class="card cf-subcard">
                    <div class="cf-panel-head">
                      <div>
                        <b>${esc(b.name)}</b>
                        <div class="muted sm">Location: ${esc(b.location || "auto")}</div>
                      </div>
                      <div class="btn-row" style="gap:6px">
                        <button type="button" class="btn xs ghost" data-r2-settings="${esc(b.name)}">${icon("settings")}<span>Public &amp; CORS</span></button>
                        <button type="button" class="btn xs primary" data-r2-apply-site="${esc(b.name)}">${icon("env")}<span>Apply .env</span></button>
                        <button type="button" class="btn xs ghost danger" data-r2-delete-bucket="${esc(b.name)}">${icon("trash")}</button>
                      </div>
                    </div>
                  </div>
                `).join("")}
              </div>
            `}
          </div>
        ` : ""}

        ${S.storageSub === "kv" ? `
          ${S.tabErrors.kv ? renderErrorBanner(S.tabErrors.kv, "btn-retry-kv") : ""}
          <div class="grid-2">
            <div class="card cf-panel">
              <div class="cf-panel-head">
                <h3>${icon("key")} KV Namespaces (${S.kvNamespaces.length})</h3>
                <button type="button" class="btn xs primary" id="btn-cf-kv-create-ns">${icon("plus")}<span>New Namespace</span></button>
              </div>
              <div class="cf-rule-list">
                ${S.kvNamespaces.length === 0 ? `<p class="muted sm">No KV namespaces found.</p>` : S.kvNamespaces.map((ns) => `
                  <div class="cf-select-row ${ns.id === S.activeKvId ? "active" : ""}">
                    <button type="button" class="cf-select-row-btn" data-select-kv="${esc(ns.id)}">
                      <b>${esc(ns.title)}</b>
                      <div class="muted sm mono">${esc(ns.id)}</div>
                    </button>
                    <button type="button" class="btn xs ghost danger" data-del-kv-ns="${esc(ns.id)}">${icon("trash")}</button>
                  </div>
                `).join("")}
              </div>
            </div>

            <div class="card cf-panel">
              <div class="cf-panel-head">
                <h3>${icon("file")} Keys &amp; Values</h3>
                ${S.activeKvId ? `<button type="button" class="btn xs primary" id="btn-cf-kv-new-entry">${icon("plus")}<span>Set Key</span></button>` : ""}
              </div>
              ${!S.activeKvId ? `<p class="muted sm">Select a KV namespace first.</p>` : `
                <div style="display:flex;gap:8px;margin-bottom:10px">
                  <input type="text" id="cf-kv-prefix-input" class="input sm" placeholder="Filter prefix…" value="${esc(S.kvPrefix)}">
                  <button type="button" class="btn sm ghost" id="btn-cf-kv-search">${icon("search")}</button>
                </div>
                <div class="cf-rule-list" style="max-height:220px;overflow:auto">
                  ${S.kvKeys.length === 0 ? `<p class="muted sm">No keys found in this namespace.</p>` : S.kvKeys.map((k) => `
                    <div class="cf-rule-row">
                      <button type="button" class="btn xs ghost mono" data-read-kv="${esc(k.name)}">${esc(k.name)}</button>
                      <button type="button" class="btn xs ghost danger" data-del-kv-key="${esc(k.name)}">${icon("trash")}</button>
                    </div>
                  `).join("")}
                </div>
                ${S.kvEditor.key ? `
                  <div class="cf-subbox" style="margin-top:10px">
                    <div class="cf-panel-head"><b class="mono sm">${esc(S.kvEditor.key)}</b></div>
                    <textarea id="cf-kv-editor-val" class="input mono" rows="4">${esc(S.kvEditor.value)}</textarea>
                    <div style="display:flex;justify-content:flex-end;margin-top:6px">
                      <button type="button" class="btn xs primary" id="btn-cf-kv-save-val">${icon("check")}<span>Save Value</span></button>
                    </div>
                  </div>
                ` : ""}
              `}
            </div>
          </div>
        ` : ""}

        ${S.storageSub === "d1" ? `
          ${S.tabErrors.d1 ? renderErrorBanner(S.tabErrors.d1, "btn-retry-d1") : ""}
          <div class="grid-2">
            <div class="card cf-panel">
              <div class="cf-panel-head">
                <h3>${icon("grid")} D1 SQL Databases (${S.d1Databases.length})</h3>
                <button type="button" class="btn xs primary" id="btn-cf-d1-create">${icon("plus")}<span>New D1 Database</span></button>
              </div>
              <div class="cf-rule-list">
                ${S.d1Databases.length === 0 ? `<p class="muted sm">No D1 SQLite databases on this account.</p>` : S.d1Databases.map((db) => `
                  <div class="cf-select-row ${db.uuid === S.activeD1Id ? "active" : ""}">
                    <button type="button" class="cf-select-row-btn" data-select-d1="${esc(db.uuid)}">
                      <b>${esc(db.name)}</b>
                      <div class="muted sm mono">${esc(db.uuid)} · ${formatBytes(db.file_size || 0)}</div>
                    </button>
                    <button type="button" class="btn xs ghost danger" data-del-d1="${esc(db.uuid)}">${icon("trash")}</button>
                  </div>
                `).join("")}
              </div>
            </div>

            <div class="card cf-panel">
              <h3>${icon("terminal")} D1 SQL Query Console</h3>
              ${!S.activeD1Id ? `<p class="muted sm">Select or create a D1 database to execute SQL queries.</p>` : `
                <textarea id="cf-d1-sql-input" class="input mono" rows="4">${esc(S.d1Sql)}</textarea>
                <div style="display:flex;justify-content:flex-end;margin-top:8px">
                  <button type="button" class="btn sm primary" id="btn-cf-d1-run">${icon("play")}<span>Run SQL</span></button>
                </div>
                ${renderD1QueryResults()}
              `}
            </div>
          </div>
        ` : ""}
      </div>
    `;
  }

  function renderD1QueryResults() {
    if (!S.d1Result) return "";
    if (!S.d1Result.ok) return renderErrorBanner(S.d1Result);
    const rows = S.d1Result.results || [];
    const meta = S.d1Result.meta || {};
    if (!rows.length) {
      return `<div class="notice ok" style="margin-top:10px">${icon("check")}<span>Executed cleanly (${meta.duration ?? 0}ms, changes: ${meta.changes ?? 0})</span></div>`;
    }
    const cols = Object.keys(rows[0]);
    return `
      <div style="overflow-x:auto;margin-top:10px">
        <table class="table sm">
          <thead><tr>${cols.map((c) => `<th class="mono">${esc(c)}</th>`).join("")}</tr></thead>
          <tbody>
            ${rows.slice(0, 50).map((row) => `<tr>${cols.map((c) => `<td class="mono sm">${esc(row[c])}</td>`).join("")}</tr>`).join("")}
          </tbody>
        </table>
      </div>
    `;
  }

  // ── Tab 7: Zero Trust Tunnels & Ingress ──────────────────────────────────

  function renderTunnelsTab() {
    return `
      <div class="cf-stack">
        ${S.tabErrors.tunnels ? renderErrorBanner(S.tabErrors.tunnels, "btn-retry-tunnels") : ""}
        <div class="card cf-panel">
          <div class="cf-panel-head">
            <div>
              <h3>${icon("cloud")} Cloudflare Zero Trust Tunnels (${S.tunnels.length})</h3>
              <p class="muted sm">${esc(tr("cf_tunnels_sub", "Manage named cloudflared tunnels, edit remote Public Hostname ingress routes, and bind tokens to local projects."))}</p>
            </div>
            <div class="btn-row">
              <button type="button" class="btn sm ghost" data-cf-web="https://one.dash.cloudflare.com">${icon("browser")}<span>Zero Trust Web</span></button>
              <button type="button" class="btn sm ghost" id="btn-refresh-tunnels">${icon("refresh")}</button>
              <button type="button" class="btn sm primary" id="btn-create-named-tunnel">${icon("plus")}<span>New Tunnel</span></button>
            </div>
          </div>

          <div style="overflow-x:auto">
            <table class="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Status</th>
                  <th>Connections</th>
                  <th style="text-align:end">Actions</th>
                </tr>
              </thead>
              <tbody>
                ${S.tunnels.length === 0 ? `
                  <tr><td colspan="4" class="muted" style="text-align:center;padding:28px">No Named Tunnels configured yet.</td></tr>
                ` : S.tunnels.map((tun) => `
                  <tr>
                    <td>
                      <b>${esc(tun.name)}</b>
                      <div class="muted sm mono">${esc(tun.id)}</div>
                    </td>
                    <td><span class="chip sm ${tun.status === "healthy" ? "ok" : "muted"}">${esc(tun.status || "inactive")}</span></td>
                    <td>${tun.connections_count ?? tun.connections ?? 0} active</td>
                    <td style="text-align:end;white-space:nowrap">
                      <button type="button" class="btn xs ghost" data-tunnel-ingress="${esc(tun.id)}" data-tunnel-name="${esc(tun.name)}">${icon("globe")}<span>Public Hostnames</span></button>
                      <button type="button" class="btn xs ghost" data-copy-tunnel-token="${esc(tun.id)}">${icon("copy")}<span>Token</span></button>
                      <button type="button" class="btn xs primary" data-bind-tunnel-site="${esc(tun.id)}" data-tunnel-name="${esc(tun.name)}">${icon("link")}<span>Bind Project</span></button>
                      <button type="button" class="btn xs ghost danger" data-delete-account-tunnel="${esc(tun.id)}">${icon("trash")}</button>
                    </td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  // ── Tab 8: Turnstile & Email Routing ─────────────────────────────────────

  function renderExtrasTab() {
    const cz = currentZone();
    return `
      <div class="cf-stack">
        ${S.tabErrors.extras ? renderErrorBanner(S.tabErrors.extras, "btn-retry-extras") : ""}

        <div class="grid-2">
          <!-- Turnstile CAPTCHA Widgets -->
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <h3>${icon("sparkles")} Cloudflare Turnstile (${S.turnstileWidgets.length})</h3>
              <button type="button" class="btn xs primary" id="btn-cf-turnstile-create">${icon("plus")}<span>New Widget</span></button>
            </div>
            <div class="cf-rule-list">
              ${S.turnstileWidgets.length === 0 ? `<p class="muted sm">No Turnstile CAPTCHA-free widgets created yet.</p>` : S.turnstileWidgets.map((w) => `
                <div class="cf-rule-row">
                  <div style="min-width:0">
                    <div><b>${esc(w.name)}</b> <span class="chip sm muted">${esc(w.mode || "managed")}</span></div>
                    <div class="muted sm mono">Sitekey: ${esc(w.sitekey)}</div>
                    <div class="muted sm">${esc((w.domains || []).join(", "))}</div>
                  </div>
                  <div class="btn-row" style="gap:4px">
                    <button type="button" class="btn xs primary" data-apply-turnstile="${esc(w.sitekey)}" data-secret="${esc(w.secret || "")}">${icon("env")}<span>Apply .env</span></button>
                    <button type="button" class="btn xs ghost" data-copy-val="${esc(w.sitekey)}" title="Copy Sitekey">${icon("copy")}</button>
                    <button type="button" class="btn xs ghost danger" data-del-turnstile="${esc(w.sitekey)}">${icon("trash")}</button>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>

          <!-- Email Routing -->
          <div class="card cf-panel">
            <div class="cf-panel-head">
              <div>
                <h3>${icon("mail")} Email Routing ${cz ? `— ${esc(cz.name)}` : ""}</h3>
                <div class="muted sm">${S.emailRouting?.enabled ? "Enabled & MX configured" : "Custom domain email forwarding"}</div>
              </div>
              ${cz ? `<button type="button" class="btn xs primary" id="btn-cf-email-rule-create">${icon("plus")}<span>Add Forwarder</span></button>` : ""}
            </div>
            ${!cz ? `<p class="muted sm">Select a domain first to inspect Email Routing.</p>` : `
              <div class="cf-rule-list">
                ${S.emailRules.length === 0 ? `<p class="muted sm">No custom Email Routing rules found.</p>` : S.emailRules.map((rl) => {
                  const fromAddr = rl.matchers?.[0]?.value || rl.name || "(rule)";
                  const toAddr = rl.actions?.[0]?.value?.[0] || "";
                  return `
                    <div class="cf-rule-row">
                      <div>
                        <span class="chip sm ${rl.enabled ? "ok" : "muted"}">${rl.enabled ? "Active" : "Paused"}</span>
                        <b class="mono sm">${esc(fromAddr)}</b>
                        ${toAddr ? `<span class="muted sm"> -> ${esc(toAddr)}</span>` : ""}
                      </div>
                      <div class="btn-row" style="gap:4px">
                        ${rl.tag && toAddr ? `
                          <button type="button" class="btn xs ghost" data-toggle-email-rule="${esc(rl.tag)}" data-enabled="${rl.enabled ? "1" : "0"}" data-name="${esc(rl.name || "")}" data-from="${esc(fromAddr)}" data-to="${esc(toAddr)}">
                            ${rl.enabled ? "Pause" : "Enable"}
                          </button>
                          <button type="button" class="btn xs ghost danger" data-del-email-rule="${esc(rl.tag)}">${icon("trash")}</button>
                        ` : ""}
                      </div>
                    </div>
                  `;
                }).join("")}
              </div>
            `}
          </div>
        </div>
      </div>
    `;
  }

  // ── Event Wiring ─────────────────────────────────────────────────────────

  function attachOnboardingEvents(root) {
    root.querySelectorAll("[data-cf-web]").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.preventDefault();
        openCfWeb(el.dataset.cfWeb || "https://dash.cloudflare.com");
      });
    });

    const form = $("#cf-onboarding-form", root);
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const tok = ($("#cf-token-input", root)?.value || "").trim();
      const label = ($("#cf-account-label-input", root)?.value || "").trim();
      const box = $("#cf-verify-result", root);
      const btn = $("#btn-verify-cf", root);
      if (!tok) return;
      btn.disabled = true;
      btn.textContent = "Verifying token…";
      if (box) box.innerHTML = `<span class="spin-dot"></span> Checking permissions…`;
      try {
        const res = await LD.call("cf_verify_token", { token: tok });
        if (!res.ok || !res.valid) {
          if (box) box.innerHTML = renderErrorBanner(res);
          btn.disabled = false;
          btn.innerHTML = `${icon("check")}<span>Verify &amp; Connect</span>`;
          return;
        }
        const accounts = res.accounts || [];
        const accountId = accounts[0]?.id || "";
        const accountName = label || accounts[0]?.name || "Cloudflare Account";
        await LD.call("cf_save_credentials", { token: tok, account_id: accountId, account_name: accountName, make_active: true });
        toast("success", "Cloudflare connected", accountName || accountId);
        await refreshStatus();
        await loadZones();
        await loadCurrentTabData(true);
        render();
      } catch (err) {
        if (box) box.innerHTML = `<div class="notice danger">${icon("alert")}<span>${esc(err.message)}</span></div>`;
        btn.disabled = false;
        btn.innerHTML = `${icon("check")}<span>Verify &amp; Connect</span>`;
      }
    });
  }

  async function switchAccount(accId) {
    if (!accId || accId === S.status.account_id) return;
    try {
      const res = await LD.call("cf_switch_account", { account_id: accId });
      if (res.ok) {
        toast("success", "Account Switched", res.account_name || accId);
        await refreshStatus();
        S.zones = [];
        S.currentZoneId = "";
        S.analytics = null;
        S.workers = [];
        S.pagesProjects = [];
        S.r2Buckets = [];
        S.kvNamespaces = [];
        S.d1Databases = [];
        S.tunnels = [];
        await loadZones();
        await loadCurrentTabData(true);
        render();
      } else {
        toast("error", "Switch Failed", res.error || "Could not switch account");
      }
    } catch (err) {
      toast("error", "Error", err.message);
    }
  }

  function attachMainEvents(root) {
    // Live Cloudflare Web links
    root.querySelectorAll("[data-cf-web]").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.preventDefault();
        openCfWeb(el.dataset.cfWeb || "");
      });
    });

    root.querySelectorAll("[data-copy-val]").forEach((el) => {
      el.addEventListener("click", async () => {
        await copyText(el.dataset.copyVal || "");
        toast("info", "Copied", el.dataset.copyVal || "");
      });
    });

    root.querySelectorAll("[data-open-url]").forEach((el) => {
      el.addEventListener("click", () => LD.call("open", { target: "url", url: el.dataset.openUrl }));
    });

    $("#cf-account-select", root)?.addEventListener("change", (e) => switchAccount(e.target.value));
    $("#btn-cf-add-account", root)?.addEventListener("click", openAddAccountModal);
    $("#btn-cf-manage-accounts", root)?.addEventListener("click", openManageAccountsModal);
    $("#cf-chip-acc-count", root)?.addEventListener("click", openManageAccountsModal);

    root.querySelectorAll("[data-cf-tab]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        S.tab = btn.dataset.cfTab;
        await loadCurrentTabData(true);
        render();
      });
    });

    $("#btn-cf-refresh", root)?.addEventListener("click", async () => {
      await refreshStatus();
      await loadZones();
      await loadCurrentTabData(true);
      toast("info", "Cloudflare refreshed");
      render();
    });

    $("#btn-cf-disconnect", root)?.addEventListener("click", async () => {
      const accs = S.status.accounts || [];
      const isMulti = accs.length > 1;
      const ok = await confirmModal({
        title: isMulti ? `Remove '${S.status.account_name}'?` : "Disconnect Cloudflare?",
        message: isMulti
          ? `Remove '${S.status.account_name}' from this app? Remaining accounts stay connected.`
          : "Your Cloudflare API Token will be removed from local storage.",
        confirm: isMulti ? "Remove" : "Disconnect",
        danger: true,
      });
      if (!ok) return;
      await LD.call("cf_browser_close").catch(() => {});
      if (isMulti) await LD.call("cf_remove_account", { account_id: S.status.account_id });
      else await LD.call("cf_disconnect");
      await refreshStatus();
      S.zones = [];
      S.dnsRecords = [];
      if (S.status.configured) {
        await loadZones();
        await loadCurrentTabData(true);
      }
      render();
    });

    // Global zone switcher across tabs
    ["#cf-ov-zone-select", "#cf-dns-zone-select", "#cf-edge-zone-select", "#cf-security-zone-select", "#cf-global-zone-select"].forEach((id) => {
      $(id, root)?.addEventListener("change", async (e) => {
        S.currentZoneId = e.target.value;
        S.zoneDetails = null;
        await loadCurrentTabData(true);
        render();
      });
    });

    $("#btn-cf-add-zone", root)?.addEventListener("click", openAddZoneModal);
    $("#btn-cf-add-zone-2", root)?.addEventListener("click", openAddZoneModal);
    $("#btn-ov-refresh-zones", root)?.addEventListener("click", async () => { await loadZones(); render(); });
    $("#btn-cf-check-activation", root)?.addEventListener("click", async () => {
      const res = await LD.call("cf_zone_activation_check", { zone_id: activeZoneId() });
      if (res.ok) toast("success", "Activation check requested", "Cloudflare is re-verifying your nameservers.");
      else toast("error", "Activation check failed", res.error);
    });

    root.querySelectorAll("[data-an-days]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        S.analyticsDays = Number(btn.dataset.anDays || 7);
        await loadOverviewData();
        render();
      });
    });

    root.querySelectorAll("[data-open-zone-dns]").forEach((b) => b.addEventListener("click", async () => {
      S.currentZoneId = b.dataset.openZoneDns; S.tab = "dns"; await loadDnsRecords(); render();
    }));
    root.querySelectorAll("[data-open-zone-edge]").forEach((b) => b.addEventListener("click", async () => {
      S.currentZoneId = b.dataset.openZoneEdge; S.tab = "edge"; await loadEdgeSettings(); render();
    }));
    root.querySelectorAll("[data-open-zone-sec]").forEach((b) => b.addEventListener("click", async () => {
      S.currentZoneId = b.dataset.openZoneSec; S.tab = "security"; await loadSecurityData(); render();
    }));
    root.querySelectorAll("[data-delete-zone]").forEach((b) => {
      b.addEventListener("click", async () => {
        const zname = b.dataset.zoneName;
        const ok = await confirmModal({
          title: `Delete Domain '${zname}'?`,
          message: "All DNS records and Cloudflare settings for this zone will be permanently deleted.",
          confirm: "Delete Domain",
          danger: true,
        });
        if (!ok) return;
        const res = await LD.call("cf_zone_delete", { zone_id: b.dataset.deleteZone });
        if (res.ok) {
          toast("info", "Zone deleted", zname);
          await loadZones();
          await loadCurrentTabData(true);
          render();
        } else toast("error", "Delete failed", res.error);
      });
    });

    // DNS Events
    $("#cf-dns-search", root)?.addEventListener("input", (e) => { S.dnsSearch = e.target.value; });
    $("#cf-dns-search", root)?.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); render(); } });
    root.querySelectorAll("[data-dns-type]").forEach((b) => {
      b.addEventListener("click", () => { S.dnsFilterType = b.dataset.dnsType; render(); });
    });
    $("#btn-cf-add-dns", root)?.addEventListener("click", () => openDnsModal());
    $("#btn-cf-dns-preset", root)?.addEventListener("click", openDnsPresetModal);
    root.querySelectorAll("[data-edit-dns]").forEach((b) => {
      b.addEventListener("click", () => {
        const rec = S.dnsRecords.find((r) => r.id === b.dataset.editDns);
        if (rec) openDnsModal(rec);
      });
    });
    root.querySelectorAll("[data-toggle-proxy]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_dns_proxy", { zone_id: activeZoneId(), record_id: b.dataset.toggleProxy, proxied: b.dataset.proxied !== "1" });
        if (res.ok) { await loadDnsRecords(); render(); }
        else toast("error", "Proxy toggle failed", res.error);
      });
    });
    root.querySelectorAll("[data-delete-dns]").forEach((b) => {
      b.addEventListener("click", async () => {
        const ok = await confirmModal({ title: "Delete DNS Record?", message: "Remove this DNS record permanently?", confirm: "Delete", danger: true });
        if (!ok) return;
        const res = await LD.call("cf_dns_delete", { zone_id: activeZoneId(), record_id: b.dataset.deleteDns });
        if (res.ok) { await loadDnsRecords(); render(); }
        else toast("error", "Delete failed", res.error);
      });
    });

    // Edge / SSL / Cache Events
    root.querySelectorAll("[data-ssl-mode]").forEach((b) => {
      b.addEventListener("click", async () => {
        const val = b.dataset.sslMode;
        const res = await LD.call("cf_zone_setting_set", { zone_id: activeZoneId(), setting_id: "ssl", value: val });
        if (res.ok) { S.zoneSettings.ssl = val; toast("success", "SSL mode updated", val); render(); }
        else toast("error", "Update failed", res.error);
      });
    });
    root.querySelectorAll("[data-zone-toggle]").forEach((chk) => {
      chk.addEventListener("change", async () => {
        const sid = chk.dataset.zoneToggle;
        const val = chk.checked ? (chk.dataset.onVal || "on") : "off";
        const res = await LD.call("cf_zone_setting_set", { zone_id: activeZoneId(), setting_id: sid, value: val });
        if (res.ok) { S.zoneSettings[sid] = val; toast("success", `${sid} updated`, val); }
        else { chk.checked = !chk.checked; toast("error", "Update failed", res.error); }
      });
    });
    $("#cf-min-tls-select", root)?.addEventListener("change", async (e) => {
      const res = await LD.call("cf_zone_setting_set", { zone_id: activeZoneId(), setting_id: "min_tls_version", value: e.target.value });
      if (res.ok) { S.zoneSettings.min_tls_version = e.target.value; toast("success", "Min TLS updated", e.target.value); }
      else toast("error", "Failed", res.error);
    });
    $("#cf-universal-ssl-toggle", root)?.addEventListener("change", async (e) => {
      const res = await LD.call("cf_ssl_universal_set", { zone_id: activeZoneId(), enabled: e.target.checked });
      if (res.ok) { S.universalSsl.enabled = e.target.checked; toast("success", "Universal SSL updated"); }
      else { e.target.checked = !e.target.checked; toast("error", "Failed", res.error); }
    });
    $("#btn-toggle-dev-mode", root)?.addEventListener("click", async () => {
      const res = await LD.call("cf_dev_mode_set", { zone_id: activeZoneId(), value: !S.devMode });
      if (res.ok) { S.devMode = !S.devMode; toast("success", S.devMode ? "Dev Mode Enabled" : "Dev Mode Disabled"); render(); }
      else toast("error", "Failed", res.error);
    });
    $("#btn-cf-purge-all", root)?.addEventListener("click", async () => {
      const ok = await confirmModal({ title: "Purge Entire Edge Cache?", message: "Purge all cached files for this domain.", confirm: "Purge All", danger: true });
      if (!ok) return;
      const res = await LD.call("cf_purge_cache", { zone_id: activeZoneId(), purge_everything: true });
      if (res.ok) toast("success", "Cache Purged");
      else toast("error", "Purge failed", res.error);
    });
    $("#btn-cf-purge-urls", root)?.addEventListener("click", async () => {
      const urls = ($("#cf-purge-urls-input", root)?.value || "").split("\n").map((u) => u.trim()).filter(Boolean);
      if (!urls.length) return toast("warn", "Enter at least one URL");
      const res = await LD.call("cf_purge_cache", { zone_id: activeZoneId(), purge_everything: false, files: urls });
      if (res.ok) { toast("success", `Purged ${urls.length} URL(s)`); $("#cf-purge-urls-input", root).value = ""; }
      else toast("error", "Purge failed", res.error);
    });
    $("#cf-cache-level-select", root)?.addEventListener("change", async (e) => {
      const res = await LD.call("cf_zone_setting_set", { zone_id: activeZoneId(), setting_id: "cache_level", value: e.target.value });
      if (res.ok) toast("success", "Cache level updated");
      else toast("error", "Failed", res.error);
    });
    $("#cf-browser-ttl-select", root)?.addEventListener("change", async (e) => {
      const res = await LD.call("cf_zone_setting_set", { zone_id: activeZoneId(), setting_id: "browser_cache_ttl", value: Number(e.target.value) });
      if (res.ok) toast("success", "Browser TTL updated");
      else toast("error", "Failed", res.error);
    });

    // Security / WAF / IP / Page Rules
    root.querySelectorAll("[data-sec-level-btn]").forEach((b) => {
      b.addEventListener("click", async () => {
        const lvl = b.dataset.secLevelBtn;
        const res = await LD.call("cf_security_level_set", { zone_id: activeZoneId(), level: lvl });
        if (res.ok) { S.securityLevel = lvl; toast("success", "Security Level Updated", lvl); render(); }
        else toast("error", "Update failed", res.error);
      });
    });
    $("#cf-bot-fight-toggle", root)?.addEventListener("change", async (e) => {
      const res = await LD.call("cf_bot_set", { zone_id: activeZoneId(), fight_mode: e.target.checked });
      if (res.ok) { S.botFightMode = e.target.checked; toast("success", "Bot Fight Mode updated"); }
      else { e.target.checked = !e.target.checked; toast("error", "Failed", res.error); }
    });
    $("#btn-cf-add-ip-rule", root)?.addEventListener("click", openAddIpRuleModal);
    root.querySelectorAll("[data-del-ip-rule]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_ip_rule_delete", { zone_id: activeZoneId(), rule_id: b.dataset.delIpRule });
        if (res.ok) { await loadSecurityData(); render(); } else toast("error", "Delete failed", res.error);
      });
    });
    $("#btn-cf-add-waf-rule", root)?.addEventListener("click", openAddWafRuleModal);
    root.querySelectorAll("[data-del-waf-rule]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_waf_rule_delete", { zone_id: activeZoneId(), rule_id: b.dataset.delWafRule });
        if (res.ok) { await loadSecurityData(); render(); } else toast("error", "Delete failed", res.error);
      });
    });
    $("#btn-cf-add-page-rule", root)?.addEventListener("click", openAddPageRuleModal);
    root.querySelectorAll("[data-del-page-rule]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_page_rule_delete", { zone_id: activeZoneId(), rule_id: b.dataset.delPageRule });
        if (res.ok) { await loadSecurityData(); render(); } else toast("error", "Delete failed", res.error);
      });
    });

    // Workers & Pages
    root.querySelectorAll("[data-del-worker]").forEach((b) => {
      b.addEventListener("click", async () => {
        const ok = await confirmModal({ title: `Delete Worker '${b.dataset.delWorker}'?`, message: "Remove this Worker script?", confirm: "Delete", danger: true });
        if (!ok) return;
        const res = await LD.call("cf_worker_delete", { name: b.dataset.delWorker });
        if (res.ok) { await loadComputeData(); render(); } else toast("error", "Delete failed", res.error);
      });
    });
    $("#btn-cf-add-worker-route", root)?.addEventListener("click", openAddWorkerRouteModal);
    root.querySelectorAll("[data-del-worker-route]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_worker_route_delete", { zone_id: activeZoneId(), route_id: b.dataset.delWorkerRoute });
        if (res.ok) { await loadComputeData(); render(); } else toast("error", "Failed", res.error);
      });
    });
    root.querySelectorAll("[data-select-pages]").forEach((b) => {
      b.addEventListener("click", async () => {
        S.activePagesProject = b.dataset.selectPages;
        const depRes = await LD.call("cf_pages_deployments", { project: S.activePagesProject }).catch(() => null);
        S.pagesDeployments = depRes?.ok ? (depRes.deployments || []) : [];
        render();
      });
    });
    $("#btn-cf-pages-deploy", root)?.addEventListener("click", async () => {
      const res = await LD.call("cf_pages_deploy", { project: S.activePagesProject });
      if (res.ok) { toast("success", "Pages deployment triggered"); await loadComputeData(); render(); }
      else toast("error", "Deploy failed", res.error);
    });
    root.querySelectorAll("[data-retry-deploy]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_pages_retry", { project: S.activePagesProject, deployment_id: b.dataset.retryDeploy });
        if (res.ok) { toast("success", "Deployment retried"); await loadComputeData(); render(); }
        else toast("error", "Retry failed", res.error);
      });
    });
    root.querySelectorAll("[data-rollback-deploy]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_pages_rollback", { project: S.activePagesProject, deployment_id: b.dataset.rollbackDeploy });
        if (res.ok) { toast("success", "Rolled back deployment"); await loadComputeData(); render(); }
        else toast("error", "Rollback failed", res.error);
      });
    });

    // Storage sub-tabs (R2, KV, D1)
    root.querySelectorAll("[data-storage-sub]").forEach((b) => {
      b.addEventListener("click", async () => {
        S.storageSub = b.dataset.storageSub;
        await loadStorageData();
        render();
      });
    });
    $("#btn-refresh-r2", root)?.addEventListener("click", async () => { await loadR2Buckets(); render(); });
    $("#btn-create-r2-bucket", root)?.addEventListener("click", openCreateR2Modal);
    root.querySelectorAll("[data-r2-settings]").forEach((b) => {
      b.addEventListener("click", () => openR2SettingsModal(b.dataset.r2Settings));
    });
    root.querySelectorAll("[data-r2-apply-site]").forEach((b) => {
      b.addEventListener("click", () => openApplyR2Modal(b.dataset.r2ApplySite));
    });
    root.querySelectorAll("[data-r2-delete-bucket]").forEach((b) => {
      b.addEventListener("click", async () => {
        const ok = await confirmModal({ title: `Delete R2 Bucket '${b.dataset.r2DeleteBucket}'?`, message: "Bucket must be empty.", confirm: "Delete", danger: true });
        if (!ok) return;
        const res = await LD.call("cf_r2_delete_bucket", { name: b.dataset.r2DeleteBucket });
        if (res.ok) { await loadR2Buckets(); render(); } else toast("error", "Delete failed", res.error);
      });
    });

    // KV Events
    $("#btn-cf-kv-create-ns", root)?.addEventListener("click", openCreateKvNsModal);
    root.querySelectorAll("[data-select-kv]").forEach((b) => {
      b.addEventListener("click", async () => { S.activeKvId = b.dataset.selectKv; S.kvEditor = { key: "", value: "" }; await loadKvData(); render(); });
    });
    root.querySelectorAll("[data-del-kv-ns]").forEach((b) => {
      b.addEventListener("click", async () => {
        const ok = await confirmModal({ title: "Delete KV Namespace?", message: "Delete namespace and all entries?", confirm: "Delete", danger: true });
        if (!ok) return;
        const res = await LD.call("cf_kv_namespace_delete", { namespace_id: b.dataset.delKvNs });
        if (res.ok) { S.activeKvId = ""; await loadKvData(); render(); } else toast("error", "Failed", res.error);
      });
    });
    $("#btn-cf-kv-search", root)?.addEventListener("click", async () => {
      S.kvPrefix = $("#cf-kv-prefix-input", root)?.value || "";
      await loadKvData();
      render();
    });
    root.querySelectorAll("[data-read-kv]").forEach((b) => {
      b.addEventListener("click", async () => {
        const kname = b.dataset.readKv;
        const res = await LD.call("cf_kv_get", { namespace_id: S.activeKvId, key: kname });
        if (res.ok) { S.kvEditor = { key: kname, value: res.value || "" }; render(); }
        else toast("error", "Read failed", res.error);
      });
    });
    $("#btn-cf-kv-new-entry", root)?.addEventListener("click", openKvEntryModal);
    $("#btn-cf-kv-save-val", root)?.addEventListener("click", async () => {
      const val = $("#cf-kv-editor-val", root)?.value ?? "";
      const res = await LD.call("cf_kv_put", { namespace_id: S.activeKvId, key: S.kvEditor.key, value: val });
      if (res.ok) { toast("success", "KV Entry Saved", S.kvEditor.key); await loadKvData(); render(); }
      else toast("error", "Save failed", res.error);
    });
    root.querySelectorAll("[data-del-kv-key]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_kv_delete", { namespace_id: S.activeKvId, key: b.dataset.delKvKey });
        if (res.ok) { if (S.kvEditor.key === b.dataset.delKvKey) S.kvEditor = { key: "", value: "" }; await loadKvData(); render(); }
        else toast("error", "Delete failed", res.error);
      });
    });

    // D1 SQL Events
    $("#btn-cf-d1-create", root)?.addEventListener("click", openCreateD1Modal);
    root.querySelectorAll("[data-select-d1]").forEach((b) => {
      b.addEventListener("click", () => { S.activeD1Id = b.dataset.selectD1; S.d1Result = null; render(); });
    });
    root.querySelectorAll("[data-del-d1]").forEach((b) => {
      b.addEventListener("click", async () => {
        const ok = await confirmModal({ title: "Delete D1 Database?", message: "Delete database permanently?", confirm: "Delete", danger: true });
        if (!ok) return;
        const res = await LD.call("cf_d1_delete", { database_id: b.dataset.delD1 });
        if (res.ok) { S.activeD1Id = ""; S.d1Result = null; await loadD1Data(); render(); } else toast("error", "Failed", res.error);
      });
    });
    $("#btn-cf-d1-run", root)?.addEventListener("click", async () => {
      S.d1Sql = $("#cf-d1-sql-input", root)?.value || "";
      if (!S.d1Sql.trim()) return;
      S.d1Result = await LD.call("cf_d1_query", { database_id: S.activeD1Id, sql: S.d1Sql }).catch((e) => ({ ok: false, error: e.message }));
      render();
    });

    // Tunnels Events
    $("#btn-refresh-tunnels", root)?.addEventListener("click", async () => { await loadTunnels(); render(); });
    $("#btn-create-named-tunnel", root)?.addEventListener("click", openCreateTunnelModal);
    root.querySelectorAll("[data-tunnel-ingress]").forEach((b) => {
      b.addEventListener("click", () => openTunnelIngressModal(b.dataset.tunnelIngress, b.dataset.tunnelName));
    });
    root.querySelectorAll("[data-copy-tunnel-token]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_tunnel_token", { tunnel_id: b.dataset.copyTunnelToken });
        if (res.ok && res.token) { await copyText(res.token); toast("success", "Tunnel Token Copied"); }
        else toast("error", "Failed", res.error);
      });
    });
    root.querySelectorAll("[data-bind-tunnel-site]").forEach((b) => {
      b.addEventListener("click", () => openBindTunnelModal(b.dataset.bindTunnelSite, b.dataset.tunnelName));
    });
    root.querySelectorAll("[data-delete-account-tunnel]").forEach((b) => {
      b.addEventListener("click", async () => {
        const ok = await confirmModal({ title: "Delete Named Tunnel?", message: "Remove tunnel from Cloudflare?", confirm: "Delete", danger: true });
        if (!ok) return;
        const res = await LD.call("cf_tunnel_delete", { tunnel_id: b.dataset.deleteAccountTunnel });
        if (res.ok) { await loadTunnels(); render(); } else toast("error", "Failed", res.error);
      });
    });

    // Turnstile & Email Routing Events
    $("#btn-cf-turnstile-create", root)?.addEventListener("click", openCreateTurnstileModal);
    root.querySelectorAll("[data-apply-turnstile]").forEach((b) => {
      b.addEventListener("click", () => openApplyTurnstileModal(b.dataset.applyTurnstile, b.dataset.secret || ""));
    });
    root.querySelectorAll("[data-del-turnstile]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_turnstile_delete", { sitekey: b.dataset.delTurnstile });
        if (res.ok) { await loadExtrasData(); render(); } else toast("error", "Delete failed", res.error);
      });
    });
    $("#btn-cf-email-rule-create", root)?.addEventListener("click", openCreateEmailRuleModal);
    root.querySelectorAll("[data-toggle-email-rule]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_email_rule_toggle", {
          zone_id: activeZoneId(),
          rule_id: b.dataset.toggleEmailRule,
          enabled: b.dataset.enabled !== "1",
          name: b.dataset.name,
          custom_address: b.dataset.from,
          forward_to: b.dataset.to,
        });
        if (res.ok) { await loadExtrasData(); render(); } else toast("error", "Update failed", res.error);
      });
    });
    root.querySelectorAll("[data-del-email-rule]").forEach((b) => {
      b.addEventListener("click", async () => {
        const res = await LD.call("cf_email_rule_delete", { zone_id: activeZoneId(), rule_id: b.dataset.delEmailRule });
        if (res.ok) { await loadExtrasData(); render(); } else toast("error", "Delete failed", res.error);
      });
    });

    // Retry buttons
    ["zones", "dns", "edge", "security", "compute", "r2", "kv", "d1", "tunnels", "extras"].forEach((k) => {
      $(`#btn-retry-${k}`, root)?.addEventListener("click", async () => {
        if (k === "zones") await loadZones();
        else if (k === "r2") await loadR2Buckets();
        else if (k === "kv") await loadKvData();
        else if (k === "d1") await loadD1Data();
        else await loadCurrentTabData(true);
        render();
      });
    });
  }

  // ── Modals ───────────────────────────────────────────────────────────────

  function openAddZoneModal() {
    openModal(`
      <div class="modal" style="max-width:460px">
        <div class="modal-header">
          <h2>${icon("globe")}Add Domain to Cloudflare</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
        </div>
        <form id="cf-add-zone-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Domain Name</span><input type="text" name="name" placeholder="example.com" required></label>
          <label class="field"><span>Setup Type</span>
            <select name="zone_type"><option value="full">Full (Cloudflare Nameservers)</option><option value="partial">Partial (CNAME Setup)</option></select>
          </label>
          <label class="field" style="flex-direction:row;align-items:center;gap:8px">
            <input type="checkbox" name="jump_start" checked><span>Auto-scan existing DNS records</span>
          </label>
          <div id="cf-add-zone-err"></div>
          <div class="modal-footer">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary">${icon("check")}<span>Add Domain</span></button>
          </div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#cf-add-zone-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_zone_create", {
          name: fd.get("name"),
          zone_type: fd.get("zone_type"),
          jump_start: Boolean(fd.get("jump_start")),
        });
        if (res.ok) {
          closeModal();
          toast("success", "Domain Added", (res.zone?.name_servers || []).join(", "));
          await loadZones();
          if (res.zone?.id) S.currentZoneId = res.zone.id;
          render();
        } else {
          $("#cf-add-zone-err", root).innerHTML = renderErrorBanner(res);
        }
      });
    });
  }

  function openDnsModal(existing = null) {
    const cz = currentZone();
    if (!cz) return;
    const isEdit = Boolean(existing);
    openModal(`
      <div class="modal" style="max-width:480px">
        <div class="modal-header">
          <h2>${icon("globe")}${isEdit ? "Edit DNS Record" : "Add DNS Record"} — ${esc(cz.name)}</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
        </div>
        <form id="dns-modal-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <div class="grid-2">
            <label class="field"><span>Type</span>
              <select name="type">${["A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV"].map((tp) => `<option value="${tp}" ${existing?.type === tp ? "selected" : ""}>${tp}</option>`).join("")}</select>
            </label>
            <label class="field"><span>TTL (s)</span><input type="number" name="ttl" value="${existing?.ttl ?? 1}" min="1"></label>
          </div>
          <label class="field"><span>Name (e.g. @ or api)</span><input type="text" name="name" value="${esc(existing?.name || "@")}" required></label>
          <label class="field"><span>Content (IPv4, Hostname, TXT…)</span><input type="text" name="content" value="${esc(existing?.content || "")}" required></label>
          <div class="grid-2">
            <label class="field"><span>MX Priority</span><input type="number" name="priority" value="${existing?.priority ?? 10}"></label>
            <label class="field" style="flex-direction:row;align-items:center;gap:8px;padding-top:20px">
              <input type="checkbox" name="proxied" ${existing ? (existing.proxied ? "checked" : "") : "checked"}>
              <span>Cloudflare Proxy (Orange Cloud)</span>
            </label>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary">${icon("check")}<span>Save Record</span></button>
          </div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#dns-modal-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const tp = fd.get("type");
        const res = await LD.call("cf_dns_save", {
          zone_id: cz.id,
          record_id: existing?.id || "",
          type: tp,
          name: fd.get("name"),
          content: fd.get("content"),
          ttl: Number(fd.get("ttl") || 1),
          proxied: ["A", "AAAA", "CNAME"].includes(tp) ? Boolean(fd.get("proxied")) : false,
          priority: ["MX", "SRV"].includes(tp) ? Number(fd.get("priority") || 10) : null,
        });
        if (res.ok) { closeModal(); toast("success", "DNS Record Saved"); await loadDnsRecords(); render(); }
        else toast("error", "DNS Save Failed", res.error);
      });
    });
  }

  function openDnsPresetModal() {
    const cz = currentZone();
    if (!cz) return;
    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header">
          <h2>${icon("zap")}Quick Server DNS Setup</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
        </div>
        <form id="dns-preset-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <p class="muted sm" style="margin:0">Automatically create root <code>A @ -&gt; IP</code> and <code>CNAME www -&gt; ${esc(cz.name)}</code> proxied records.</p>
          <label class="field"><span>Server IPv4 Address</span><input type="text" name="ip" placeholder="203.0.113.10" required class="mono"></label>
          <label class="field" style="flex-direction:row;align-items:center;gap:8px"><input type="checkbox" name="proxied" checked><span>Enable Cloudflare Proxy</span></label>
          <div class="modal-footer">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary">${icon("check")}<span>Create Records</span></button>
          </div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#dns-preset-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const ip = fd.get("ip").trim();
        const px = Boolean(fd.get("proxied"));
        await LD.call("cf_dns_save", { zone_id: cz.id, type: "A", name: "@", content: ip, proxied: px, ttl: 1 });
        await LD.call("cf_dns_save", { zone_id: cz.id, type: "CNAME", name: "www", content: cz.name, proxied: px, ttl: 1 });
        closeModal();
        toast("success", "App DNS Preset Applied");
        await loadDnsRecords();
        render();
      });
    });
  }

  function openAddIpRuleModal() {
    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header"><h2>${icon("filter")}Add IP Access Rule</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="ip-rule-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <div class="grid-2">
            <label class="field"><span>Action Mode</span>
              <select name="mode"><option value="block">Block</option><option value="managed_challenge">Managed Challenge</option><option value="js_challenge">JS Challenge</option><option value="whitelist">Allow (Whitelist)</option></select>
            </label>
            <label class="field"><span>Target</span>
              <select name="target"><option value="ip">IP Address</option><option value="ip_range">CIDR Range</option><option value="country">Country Code (US/SA…)</option><option value="asn">ASN (AS13335)</option></select>
            </label>
          </div>
          <label class="field"><span>Value</span><input type="text" name="value" placeholder="192.0.2.10 or US" required class="mono"></label>
          <label class="field"><span>Note (optional)</span><input type="text" name="notes" placeholder="Office IP or attacker block"></label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create Rule</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#ip-rule-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_ip_rule_create", {
          zone_id: activeZoneId(), mode: fd.get("mode"), target: fd.get("target"), value: fd.get("value"), notes: fd.get("notes"),
        });
        if (res.ok) { closeModal(); toast("success", "IP Access Rule Created"); await loadSecurityData(); render(); }
        else toast("error", "Failed", res.error);
      });
    });
  }

  function openAddWafRuleModal() {
    openModal(`
      <div class="modal" style="max-width:520px">
        <div class="modal-header"><h2>${icon("wrench")}New Custom WAF Rule</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="waf-rule-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button type="button" class="btn xs ghost" data-waf-tpl='(http.request.uri.path contains "/wp-login.php")'>Block WP-Login</button>
            <button type="button" class="btn xs ghost" data-waf-tpl='(ip.geoip.country eq "XX")'>Block Country</button>
            <button type="button" class="btn xs ghost" data-waf-tpl='(http.request.uri.path starts_with "/admin")'>Protect /admin</button>
          </div>
          <label class="field"><span>Description</span><input type="text" name="description" placeholder="Block Admin Brute Force" required></label>
          <label class="field"><span>Action</span>
            <select name="action"><option value="block">Block</option><option value="managed_challenge">Managed Challenge</option><option value="js_challenge">JS Challenge</option><option value="skip">Skip (Allow)</option><option value="log">Log</option></select>
          </label>
          <label class="field"><span>Filter Expression (Wirefilter syntax)</span>
            <textarea name="expression" id="waf-expr-input" rows="3" class="mono" placeholder='(http.request.uri.path contains "/xmlrpc.php")' required></textarea>
          </label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Save WAF Rule</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      root.querySelectorAll("[data-waf-tpl]").forEach((b) => {
        b.addEventListener("click", () => { $("#waf-expr-input", root).value = b.dataset.wafTpl; });
      });
      $("#waf-rule-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_waf_rule_add", {
          zone_id: activeZoneId(), description: fd.get("description"), expression: fd.get("expression"), action: fd.get("action"),
        });
        if (res.ok) { closeModal(); toast("success", "WAF Rule Added"); await loadSecurityData(); render(); }
        else toast("error", "WAF Error", res.error);
      });
    });
  }

  function openAddPageRuleModal() {
    const cz = currentZone();
    if (!cz) return;
    openModal(`
      <div class="modal" style="max-width:480px">
        <div class="modal-header"><h2>${icon("link")}New Page Rule / Redirect</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="page-rule-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>URL Match Pattern</span><input type="text" name="url_pattern" value="https://www.${esc(cz.name)}/*" required class="mono"></label>
          <label class="field"><span>Action Preset</span>
            <select name="preset" id="pr-preset-sel">
              <option value="forward_301">Forwarding URL (301 Permanent Redirect)</option>
              <option value="forward_302">Forwarding URL (302 Temporary Redirect)</option>
              <option value="cache_everything">Cache Everything (Edge CDN)</option>
              <option value="bypass_cache">Bypass Cache</option>
            </select>
          </label>
          <label class="field" id="pr-dest-wrap"><span>Destination URL</span><input type="text" name="dest_url" value="https://${esc(cz.name)}/$1" class="mono"></label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create Page Rule</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      const sel = $("#pr-preset-sel", root);
      const destWrap = $("#pr-dest-wrap", root);
      sel?.addEventListener("change", () => { if (destWrap) destWrap.hidden = !sel.value.startsWith("forward_"); });
      $("#page-rule-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const pr = fd.get("preset");
        let actions = [];
        if (pr === "forward_301" || pr === "forward_302") {
          actions = [{ id: "forwarding_url", value: { url: fd.get("dest_url"), status_code: pr === "forward_301" ? 301 : 302 } }];
        } else if (pr === "cache_everything") {
          actions = [{ id: "cache_level", value: "cache_everything" }];
        } else {
          actions = [{ id: "cache_level", value: "bypass" }];
        }
        const res = await LD.call("cf_page_rule_create", { zone_id: activeZoneId(), url_pattern: fd.get("url_pattern"), actions });
        if (res.ok) { closeModal(); toast("success", "Page Rule Created"); await loadSecurityData(); render(); }
        else toast("error", "Page Rule Failed", res.error);
      });
    });
  }

  function openAddWorkerRouteModal() {
    const cz = currentZone();
    if (!cz) return;
    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header"><h2>${icon("link")}Add Worker Route</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="worker-route-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Route Pattern</span><input type="text" name="pattern" value="api.${esc(cz.name)}/*" required class="mono"></label>
          <label class="field"><span>Worker Script Name</span>
            <select name="script">
              ${S.workers.map((w) => `<option value="${esc(w.id)}">${esc(w.id)}</option>`).join("")}
            </select>
          </label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Bind Route</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#worker-route-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_worker_route_create", { zone_id: activeZoneId(), pattern: fd.get("pattern"), script: fd.get("script") });
        if (res.ok) { closeModal(); toast("success", "Worker Route Created"); await loadComputeData(); render(); }
        else toast("error", "Failed", res.error);
      });
    });
  }

  function openCreateR2Modal() {
    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header"><h2>${icon("database")}Create R2 Bucket</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="r2-create-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Bucket Name</span><input type="text" name="name" placeholder="laravel-media-prod" required pattern="[a-z0-9-]+"></label>
          <label class="field"><span>Location Hint</span>
            <select name="location_hint"><option value="">Automatic</option><option value="weur">Western Europe (WEUR)</option><option value="eeur">Eastern Europe (EEUR)</option><option value="enam">Eastern North America (ENAM)</option><option value="apac">Asia-Pacific (APAC)</option></select>
          </label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create Bucket</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#r2-create-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_r2_create_bucket", { name: fd.get("name"), location_hint: fd.get("location_hint") });
        if (res.ok) { closeModal(); toast("success", "R2 Bucket Created"); await loadR2Buckets(); render(); }
        else toast("error", "Create Failed", res.error);
      });
    });
  }

  async function openR2SettingsModal(bucketName) {
    const [domRes, corsRes] = await Promise.all([
      LD.call("cf_r2_domain_get", { name: bucketName }).catch(() => ({ enabled: false, domain: "" })),
      LD.call("cf_r2_cors_get", { name: bucketName }).catch(() => ({ rules: [] })),
    ]);
    openModal(`
      <div class="modal" style="max-width:520px">
        <div class="modal-header"><h2>${icon("settings")}R2 Settings — ${esc(bucketName)}</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <div class="cf-setting-row">
            <div>
              <b>Public r2.dev Subdomain</b>
              <div class="muted sm mono">${esc(domRes.domain || "Disabled")}</div>
            </div>
            <input type="checkbox" class="switch" id="r2-public-toggle" ${domRes.enabled ? "checked" : ""}>
          </div>
          <label class="field">
            <span>CORS Rules JSON Policy</span>
            <textarea id="r2-cors-json" class="input mono" rows="6">${esc(JSON.stringify(corsRes.rules || [{ AllowedOrigins: ["*"], AllowedMethods: ["GET", "PUT", "POST", "HEAD"], AllowedHeaders: ["*"] }], null, 2))}</textarea>
          </label>
          <div class="modal-footer">
            <button type="button" class="btn" data-dismiss>Close</button>
            <button type="button" class="btn primary" id="btn-save-r2-cors">${icon("check")}<span>Save CORS</span></button>
          </div>
        </div>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#r2-public-toggle", root)?.addEventListener("change", async (e) => {
        const res = await LD.call("cf_r2_domain_set", { name: bucketName, enabled: e.target.checked });
        if (res.ok) toast("success", "r2.dev Access Updated", res.domain || "");
        else { e.target.checked = !e.target.checked; toast("error", "Failed", res.error); }
      });
      $("#btn-save-r2-cors", root)?.addEventListener("click", async () => {
        try {
          const rules = JSON.parse($("#r2-cors-json", root).value);
          const res = await LD.call("cf_r2_cors_set", { name: bucketName, rules });
          if (res.ok) { closeModal(); toast("success", "R2 CORS Updated"); }
          else toast("error", "Failed", res.error);
        } catch (err) {
          toast("error", "Invalid JSON", err.message);
        }
      });
    });
  }

  function openApplyR2Modal(bucketName) {
    const siteOptions = (state.sites || []).map((s) => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join("");
    openModal(`
      <div class="modal" style="max-width:460px">
        <div class="modal-header"><h2>${icon("env")}Apply R2 to Laravel .env</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="r2-apply-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <p class="muted sm" style="margin:0">Configure <b>${esc(bucketName)}</b> (<code>FILESYSTEM_DISK=r2</code>, <code>R2_ENDPOINT</code>, keys) directly into <code>.env</code>.</p>
          <label class="field"><span>Select Site</span><select name="site">${siteOptions}</select></label>
          <label class="field"><span>R2 Access Key ID</span><input type="text" name="access_key" class="mono"></label>
          <label class="field"><span>R2 Secret Access Key</span><input type="password" name="secret_key" class="mono"></label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Write .env</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#r2-apply-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_r2_apply_site", {
          site: fd.get("site"), bucket: bucketName, access_key: fd.get("access_key"), secret_key: fd.get("secret_key"),
        });
        if (res.ok) { closeModal(); toast("success", "R2 Configured in .env", fd.get("site")); }
        else toast("error", "Failed", res.error);
      });
    });
  }

  function openCreateKvNsModal() {
    openModal(`
      <div class="modal" style="max-width:400px">
        <div class="modal-header"><h2>${icon("key")}Create KV Namespace</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="kv-ns-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Namespace Title</span><input type="text" name="title" placeholder="LARAVEL_CACHE" required></label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#kv-ns-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const res = await LD.call("cf_kv_namespace_create", { title: new FormData(e.target).get("title") });
        if (res.ok) { closeModal(); toast("success", "KV Namespace Created"); await loadKvData(); render(); }
        else toast("error", "Failed", res.error);
      });
    });
  }

  function openKvEntryModal() {
    openModal(`
      <div class="modal" style="max-width:460px">
        <div class="modal-header"><h2>${icon("key")}Set KV Key / Value</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="kv-entry-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Key Name</span><input type="text" name="key" placeholder="feature_flag:dark_mode" required class="mono"></label>
          <label class="field"><span>Value</span><textarea name="value" rows="4" class="mono" placeholder='{"enabled": true}'></textarea></label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Save</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#kv-entry-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_kv_put", { namespace_id: S.activeKvId, key: fd.get("key"), value: fd.get("value") });
        if (res.ok) { closeModal(); toast("success", "KV Key Stored"); await loadKvData(); render(); }
        else toast("error", "Failed", res.error);
      });
    });
  }

  function openCreateD1Modal() {
    openModal(`
      <div class="modal" style="max-width:420px">
        <div class="modal-header"><h2>${icon("grid")}Create D1 Database</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="d1-create-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Database Name</span><input type="text" name="name" placeholder="laravel-edge-db" required></label>
          <label class="field"><span>Location Hint</span>
            <select name="location"><option value="">Automatic</option><option value="weur">Western Europe</option><option value="eeur">Eastern Europe</option><option value="enam">Eastern North America</option><option value="apac">Asia-Pacific</option></select>
          </label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#d1-create-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_d1_create", { name: fd.get("name"), location: fd.get("location") });
        if (res.ok) { closeModal(); toast("success", "D1 Database Created"); await loadD1Data(); render(); }
        else toast("error", "Failed", res.error);
      });
    });
  }

  function openCreateTunnelModal() {
    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header"><h2>${icon("cloud")}Create Named Tunnel</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="tunnel-create-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Tunnel Name</span><input type="text" name="name" placeholder="laravel-office-dev" required></label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create Tunnel</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#tunnel-create-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const res = await LD.call("cf_tunnel_create", { name: new FormData(e.target).get("name") });
        if (res.ok) { closeModal(); toast("success", "Tunnel Created"); await loadTunnels(); render(); }
        else toast("error", "Create Failed", res.error);
      });
    });
  }

  async function openTunnelIngressModal(tunnelId, tunnelName) {
    const res = await LD.call("cf_tunnel_config_get", { tunnel_id: tunnelId }).catch(() => ({ ingress: [] }));
    const routes = (res.ingress || []).filter((r) => r.hostname);
    openModal(`
      <div class="modal" style="max-width:560px">
        <div class="modal-header"><h2>${icon("globe")}Public Hostnames — ${esc(tunnelName)}</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <p class="muted sm" style="margin:0">Route public subdomains straight to your local services (a <code>http_status:404</code> catch-all is appended automatically).</p>
          <div id="ingress-rows" style="display:flex;flex-direction:column;gap:8px">
            ${(routes.length ? routes : [{ hostname: "", service: "http://127.0.0.1:8000" }]).map((rt) => `
              <div class="cf-ingress-row">
                <input type="text" class="input sm ing-host mono" placeholder="app.example.com" value="${esc(rt.hostname || "")}">
                <input type="text" class="input sm ing-svc mono" placeholder="http://127.0.0.1:8000" value="${esc(rt.service || "")}">
                <button type="button" class="btn xs ghost danger ing-del">${icon("x")}</button>
              </div>
            `).join("")}
          </div>
          <div><button type="button" class="btn xs ghost" id="btn-ing-add-row">${icon("plus")}<span>Add Hostname Rule</span></button></div>
          <div class="modal-footer">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="button" class="btn primary" id="btn-ing-save">${icon("check")}<span>Save Ingress Routes</span></button>
          </div>
        </div>
      </div>
    `, (root) => {
      const attachRowDel = (row) => row.querySelector(".ing-del")?.addEventListener("click", () => row.remove());
      root.querySelectorAll(".cf-ingress-row").forEach(attachRowDel);
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#btn-ing-add-row", root)?.addEventListener("click", () => {
        const div = document.createElement("div");
        div.className = "cf-ingress-row";
        div.innerHTML = `<input type="text" class="input sm ing-host mono" placeholder="api.example.com"><input type="text" class="input sm ing-svc mono" placeholder="http://127.0.0.1:8000"><button type="button" class="btn xs ghost danger ing-del">${icon("x")}</button>`;
        attachRowDel(div);
        $("#ingress-rows", root).appendChild(div);
      });
      $("#btn-ing-save", root)?.addEventListener("click", async () => {
        const ingress = Array.from(root.querySelectorAll(".cf-ingress-row")).map((row) => ({
          hostname: row.querySelector(".ing-host")?.value.trim() || "",
          service: row.querySelector(".ing-svc")?.value.trim() || "",
        })).filter((r) => r.hostname && r.service);
        const saveRes = await LD.call("cf_tunnel_config_set", { tunnel_id: tunnelId, ingress });
        if (saveRes.ok) { closeModal(); toast("success", "Tunnel Ingress Saved"); }
        else toast("error", "Save failed", saveRes.error);
      });
    });
  }

  function openBindTunnelModal(tunnelId, tunnelName) {
    const siteOptions = (state.sites || []).map((s) => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join("");
    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header"><h2>${icon("link")}Bind Tunnel to Site</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="bind-tunnel-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <p class="muted sm" style="margin:0">Fetch token for <b>${esc(tunnelName)}</b> and save to local project config.</p>
          <label class="field"><span>Select Project</span><select name="site">${siteOptions}</select></label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Bind Token</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#bind-tunnel-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const site = e.target.elements.site.value;
        const tokRes = await LD.call("cf_tunnel_token", { tunnel_id: tunnelId });
        if (!tokRes.ok || !tokRes.token) return toast("error", "Could not fetch token", tokRes.error);
        await LD.call("tunnel_token", { name: site, token: tokRes.token });
        closeModal();
        toast("success", "Tunnel Bound", site);
      });
    });
  }

  function openCreateTurnstileModal() {
    const cz = currentZone();
    openModal(`
      <div class="modal" style="max-width:460px">
        <div class="modal-header"><h2>${icon("sparkles")}Create Turnstile Widget</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="turnstile-create-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Widget Name</span><input type="text" name="name" placeholder="Laravel Login Form" required></label>
          <label class="field"><span>Allowed Domains (comma-separated)</span><input type="text" name="domains" value="${esc(cz?.name || "localhost")}" required class="mono"></label>
          <label class="field"><span>Widget Mode</span>
            <select name="mode"><option value="managed">Managed (Recommended)</option><option value="non-interactive">Non-Interactive</option><option value="invisible">Invisible</option></select>
          </label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create Widget</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#turnstile-create-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_turnstile_create", { name: fd.get("name"), domains: fd.get("domains"), mode: fd.get("mode") });
        if (res.ok) { closeModal(); toast("success", "Turnstile Widget Created"); await loadExtrasData(); render(); }
        else toast("error", "Create Failed", res.error);
      });
    });
  }

  function openApplyTurnstileModal(sitekey, secret) {
    const siteOptions = (state.sites || []).map((s) => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join("");
    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header"><h2>${icon("env")}Apply Turnstile Keys to .env</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="ts-apply-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Target Site</span><select name="site">${siteOptions}</select></label>
          <label class="field"><span>Secret Key</span><input type="password" name="secret" value="${esc(secret)}" placeholder="0x..." class="mono"></label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Write TURNSTILE Keys</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#ts-apply-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_turnstile_apply_site", { site: fd.get("site"), sitekey, secret: fd.get("secret") });
        if (res.ok) { closeModal(); toast("success", "Turnstile keys written to .env"); }
        else toast("error", "Failed", res.error);
      });
    });
  }

  function openCreateEmailRuleModal() {
    const cz = currentZone();
    if (!cz) return;
    openModal(`
      <div class="modal" style="max-width:460px">
        <div class="modal-header"><h2>${icon("mail")}Add Email Routing Forwarder</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="email-rule-form" class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <label class="field"><span>Custom Address</span><input type="email" name="custom_address" placeholder="support@${esc(cz.name)}" required class="mono"></label>
          <label class="field"><span>Forward To (Destination Email)</span><input type="email" name="forward_to" placeholder="you@gmail.com" required class="mono"></label>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create Forwarder</button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#email-rule-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await LD.call("cf_email_rule_create", {
          zone_id: cz.id, custom_address: fd.get("custom_address"), forward_to: fd.get("forward_to"),
        });
        if (res.ok) { closeModal(); toast("success", "Email Rule Created"); await loadExtrasData(); render(); }
        else toast("error", "Failed", res.error);
      });
    });
  }

  function openAddAccountModal() {
    openModal(`
      <div class="modal" style="max-width:500px">
        <div class="modal-header"><h2>${icon("plus")}Add Cloudflare Account</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <form id="cf-add-account-form" class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <label class="field"><span>Account Label</span><input type="text" name="label" placeholder="e.g. Client Prod"></label>
          <label class="field"><span>Cloudflare API Token</span><input type="password" name="token" placeholder="Paste API token…" required class="mono"></label>
          <div id="cf-add-acc-verify-box"></div>
          <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary" id="btn-submit-add-acc">${icon("check")}<span>Verify &amp; Save</span></button></div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#cf-add-account-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const tok = fd.get("token").trim();
        const label = fd.get("label").trim();
        const res = await LD.call("cf_verify_token", { token: tok });
        if (!res.ok || !res.valid) { $("#cf-add-acc-verify-box", root).innerHTML = renderErrorBanner(res); return; }
        const acc = (res.accounts || [])[0] || {};
        await LD.call("cf_save_credentials", { token: tok, account_id: acc.id || "", account_name: label || acc.name || "Cloudflare", make_active: true });
        closeModal();
        await refreshStatus();
        await loadZones();
        await loadCurrentTabData(true);
        render();
      });
    });
  }

  async function openManageAccountsModal() {
    const accRes = await LD.call("cf_accounts").catch(() => null);
    const accs = accRes?.accounts || S.status.accounts || [];
    openModal(`
      <div class="modal" style="max-width:520px">
        <div class="modal-header"><h2>${icon("settings")}Manage Cloudflare Accounts</h2><button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button></div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:10px">
          ${accs.map((a) => `
            <div class="cf-rule-row">
              <div>
                <b>${esc(a.account_name || a.account_id)}</b> ${a.is_active ? `<span class="chip sm ok">Active</span>` : ""}
                <div class="muted sm mono">${esc(a.account_id)} · ${esc(a.token_preview)}</div>
              </div>
              <div class="btn-row" style="gap:6px">
                ${!a.is_active ? `<button type="button" class="btn xs primary" data-switch-acc="${esc(a.account_id)}">Switch</button>` : ""}
                <button type="button" class="btn xs ghost danger" data-remove-acc="${esc(a.account_id)}" data-acc-name="${esc(a.account_name || a.account_id)}">${icon("trash")}</button>
              </div>
            </div>
          `).join("")}
          <div class="modal-footer">
            <button type="button" class="btn primary" id="btn-open-add-from-manage">${icon("plus")}<span>Add Account</span></button>
            <button type="button" class="btn" data-dismiss>Close</button>
          </div>
        </div>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#btn-open-add-from-manage", root)?.addEventListener("click", () => { closeModal(); openAddAccountModal(); });
      root.querySelectorAll("[data-switch-acc]").forEach((b) => b.addEventListener("click", async () => { closeModal(); await switchAccount(b.dataset.switchAcc); }));
      root.querySelectorAll("[data-remove-acc]").forEach((b) => {
        b.addEventListener("click", async () => {
          const ok = await confirmModal({ title: `Remove '${b.dataset.accName}'?`, message: "Remove credentials locally?", confirm: "Remove", danger: true });
          if (!ok) return;
          const res = await LD.call("cf_remove_account", { account_id: b.dataset.removeAcc });
          if (res.ok) { closeModal(); await refreshStatus(); S.zones = []; if (S.status.configured) await loadZones(); render(); }
          else toast("error", "Remove failed", res.error);
        });
      });
    });
  }

  return { init, show };
})();

window.Cloudflare = Cloudflare;
