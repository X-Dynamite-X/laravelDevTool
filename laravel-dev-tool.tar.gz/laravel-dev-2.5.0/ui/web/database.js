"use strict";

/* Database manager (Navicat-style): a connection tree on the left, tabs for
   databases, tables and SQL editors on the right, all in one window.
   Grid edits are staged and saved in one transaction.
   Uses the helpers defined in app.js (icon, esc, LD, toast, modals). */

const Database = (() => {
  const DRIVERS = { mysql: "MySQL", mariadb: "MariaDB", pgsql: "PostgreSQL", sqlite: "SQLite" };
  const DRIVER_COLORS = { mysql: "#00758f", mariadb: "#c0765a", pgsql: "#336791", sqlite: "#0f80cc" };
  const PAGE_SIZES = [50, 100, 250, 500];
  const KEEP_DATA_TABS = 4; // inactive tabs beyond this drop their rows to save memory

  const S = {
    loaded: false,
    conns: [],
    tree: {},          // conn id -> {open, loading, error, version, databases, dbs: {name: {open, loading, tables, error}}}
    filter: "",
    showSystem: false,
    sideCollapsed: false,
    tabs: [],
    active: null,
    recent: [],        // tab ids, most recent first
    servers: [],
    sshEnv: null,
  };
  let seq = 0;
  let menuEl = null;

  const view = () => $("#view-database");
  const conn = (id) => S.conns.find((c) => c.id === id);
  const tab = () => S.tabs.find((x) => x.id === S.active);
  const inDb = (el) => el.closest("#view-database");
  const q = (driver, name) => driver === "mysql" || driver === "mariadb" ? "`" + name.replace(/`/g, "``") + "`" : `"${name.replace(/"/g, '""')}"`;

  function tunnelBadge(c) {
    if (!c || c.driver === "sqlite" || !(c.use_ssh || c.ssh_host || c.server)) {
      return `<span class="dbm-tunnel-badge">${esc(t("db_local_conn"))}</span>`;
    }
    if (c.ssh_mode === "server" || (c.server && !c.ssh_host)) {
      return `<span class="dbm-tunnel-badge auto">${icon("cloud")} ${esc(t("db_tunnel_server"))}</span>`;
    }
    const mode = (c.ssh_auth || "auto").toLowerCase();
    if (mode === "key") return `<span class="dbm-tunnel-badge key">${icon("key")} ${esc(t("db_tunnel_key"))}</span>`;
    if (mode === "auto") return `<span class="dbm-tunnel-badge auto">${icon("key")} ${esc(t("db_tunnel_auto"))}</span>`;
    return `<span class="dbm-tunnel-badge">${icon("lock")} ${esc(t("db_tunnel_pass"))}</span>`;
  }

  function fmtNum(n) {
    if (n === null || n === undefined) return "";
    return n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1e4 ? `${Math.round(n / 1e3)}k` : String(n);
  }
  function fmtBytes(n) {
    if (!n) return "—";
    const u = ["B", "KB", "MB", "GB"];
    const i = Math.min(Math.floor(Math.log(n) / Math.log(1024)), u.length - 1);
    return `${(n / 1024 ** i).toFixed(i ? 1 : 0)} ${u[i]}`;
  }
  function display(value) {
    if (value === null || value === undefined) return `<span class="null">NULL</span>`;
    const text = String(value);
    return esc(text.length > 300 ? text.slice(0, 300) + "…" : text).replace(/\n/g, "↵");
  }

  /* ── data loading ───────────────────────────────────────── */
  async function loadConns(refresh = false) {
    try {
      S.conns = await LD.call("db_connections", { refresh });
    } catch (err) {
      toast("error", "Couldn't load connections", err.message);
    }
    S.loaded = true;
  }

  async function openConn(id, { quiet = false } = {}) {
    const node = S.tree[id] || (S.tree[id] = { open: false, dbs: {} });
    node.open = true;
    node.loading = true;
    node.error = "";
    renderTree();
    try {
      const data = await LD.call("db_databases", { conn: id });
      Object.assign(node, { databases: data.databases, version: data.version, default: data.default, loading: false });
      const c = conn(id);
      if (c) c.open = true;
      if (data.default && data.databases.some((d) => d.name === data.default)) await openDb(id, data.default);
    } catch (err) {
      Object.assign(node, { loading: false, error: err.message });
      if (!quiet) toast("error", `Couldn't connect to ${conn(id)?.name || "database"}`, err.message);
    }
    renderTree();
  }

  async function openDb(id, db, force = false) {
    const node = S.tree[id];
    const dbn = node.dbs[db] || (node.dbs[db] = {});
    dbn.open = true;
    if (dbn.tables && !force) return renderTree();
    dbn.loading = true;
    renderTree();
    try {
      dbn.tables = await LD.call("db_tables", { conn: id, database: db });
      dbn.error = "";
    } catch (err) {
      dbn.error = err.message;
    }
    dbn.loading = false;
    renderTree();
    S.tabs.filter((t) => t.kind === "db" && t.conn === id && t.db === db).forEach(() => renderMain());
  }

  /* ── layout ─────────────────────────────────────────────── */
  function render() {
    const root = view();
    if (!root) return;
    if (!$(".dbm", root)) {
      root.innerHTML = `
        <div class="dbm ${S.sideCollapsed ? "side-collapsed" : ""}">
          <aside class="dbm-side">
            <div class="dbm-side-head">
              <b>${esc(t("db_connections"))}</b>
              <span class="spacer"></span>
              <button class="btn ghost icon-btn sm" data-db="open-diff" title="Schema Diff">${icon("layers")}</button>
              <button class="btn ghost icon-btn sm" data-db="refresh-conns" title="${esc(t("db_refresh"))}">${icon("refresh")}</button>
              <button class="btn ghost icon-btn sm" data-db="new-conn" title="${esc(t("db_add_conn"))}">${icon("plus")}</button>
              <button class="btn ghost icon-btn sm" data-db="toggle-side" title="${esc(t("db_sidebar_toggle"))}">${icon("sidebar")}</button>
            </div>
            <div class="search sm dbm-filter">${icon("search")}<input data-db-filter placeholder="${esc(t("db_search_tree"))}" value="${esc(S.filter)}" autocomplete="off" spellcheck="false"></div>
            <div class="dbm-tree" id="dbm-tree"></div>
          </aside>
          <section class="dbm-main">
            <div class="dbm-tabs" id="dbm-tabs"></div>
            <div class="dbm-content" id="dbm-content"></div>
          </section>
        </div>`;
    } else {
      $(".dbm", root).classList.toggle("side-collapsed", Boolean(S.sideCollapsed));
    }
    renderTree();
    renderTabs();
    renderMain();
  }

  function renderTree() {
    const el = $("#dbm-tree");
    if (!el) return;
    if (!S.loaded) {
      el.innerHTML = `<div class="skeleton" style="height:28px;margin:8px"></div>`.repeat(4);
      return;
    }
    const filter = S.filter.trim().toLowerCase();
    const groups = [
      ["Projects", S.conns.filter((c) => c.source === "site")],
      [t("db_connections"), S.conns.filter((c) => c.source === "local" || c.source === "saved")],
      [t("servers"), S.conns.filter((c) => c.source === "server")],
    ].filter(([, list]) => list.length);
    if (!groups.length) {
      el.innerHTML = `<div class="dbm-hint">${esc(t("db_no_match"))}<br><button class="btn sm primary" data-db="new-conn">${icon("plus")}${esc(t("db_add_conn"))}</button></div>`;
      return;
    }
    el.innerHTML = groups.map(([label, list]) => `
      <div class="dbm-group">${esc(label)}</div>
      ${list.map((c) => connNode(c, filter)).join("")}`).join("");
  }

  function connNode(c, filter) {
    const node = S.tree[c.id] || {};
    const open = node.open;
    const isSsh = Boolean(c.use_ssh || c.ssh_host || c.server);
    const sshTag = isSsh ? (c.ssh_mode === "server" ? "SSH Server" : (c.ssh_auth === "key" ? "SSH Key" : "SSH")) : "";
    const sub = c.driver === "sqlite"
      ? (c.file || "").split(/[\\/]/).pop()
      : `${sshTag ? `${sshTag} · ` : ""}${c.server_name ? `${c.server_name} · ` : ""}${c.database || c.host || ""}`;
    let children = "";
    if (open) {
      if (node.loading) children = `<div class="dbm-node dim" style="--depth:1"><span class="spin-dot"></span>${esc(t("db_loading"))}</div>`;
      else if (node.error) children = `<div class="dbm-node error" style="--depth:1" title="${esc(node.error)}">${icon("alert")}<span class="label">${esc(node.error)}</span></div>`;
      else {
        const focused = c.source !== "saved" && c.source !== "local" && node.default && !node.showAll;
        const dbs = (node.databases || []).filter((d) => focused ? d.name === node.default : S.showSystem || !d.system || d.name === node.default);
        children = dbs.map((d) => dbNode(c, d, filter)).join("") || `<div class="dbm-node dim" style="--depth:1">${esc(t("db_no_match"))}</div>`;
        const hidden = (node.databases || []).length - dbs.length;
        if (hidden > 0) children += focused
          ? `<div class="dbm-node dim link" style="--depth:1" data-db="show-all" data-conn="${esc(c.id)}">Show ${hidden} other database${hidden > 1 ? "s" : ""} on this server</div>`
          : `<div class="dbm-node dim link" style="--depth:1" data-db="show-system">Show ${hidden} system database${hidden > 1 ? "s" : ""}</div>`;
      }
    }
    const colorStyle = c.color ? `border-left: 3px solid ${c.color}; padding-left: 5px;` : "";
    return `
      <div class="dbm-node conn ${open ? "open" : ""}" style="--depth:0; ${colorStyle}" data-node="conn" data-conn="${esc(c.id)}">
        <span class="chev">${icon("back", "flip-down")}</span>
        <span class="drv" style="--c:${c.color || DRIVER_COLORS[c.driver] || "#888"}" title="${esc(DRIVERS[c.driver] || c.driver)}">${esc((DRIVERS[c.driver] || "?").slice(0, 2))}</span>
        <span class="label"><b>${esc(c.name)}</b><small>${esc(sub)}</small></span>
        ${isSsh ? `<span title="SSH Tunneled Connection" style="color:var(--muted);display:grid;place-items:center;">${icon("cloud")}</span>` : ""}
        <span class="dot ${c.open ? "on" : "off"}" title="${esc(c.open ? t("db_connected") : "")}"></span>
        <button class="btn ghost icon-btn xs node-more" data-menu="conn" title="More">⋯</button>
      </div>${children}`;
  }

  function dbNode(c, d, filter) {
    const dbn = S.tree[c.id].dbs[d.name] || {};
    let children = "";
    if (dbn.open) {
      if (dbn.loading) children = `<div class="dbm-node dim" style="--depth:2"><span class="spin-dot"></span>${esc(t("db_loading"))}</div>`;
      else if (dbn.error) children = `<div class="dbm-node error" style="--depth:2" title="${esc(dbn.error)}">${icon("alert")}<span class="label">${esc(dbn.error)}</span></div>`;
      else {
        const tables = (dbn.tables || []).filter((tb) => !filter || tb.name.toLowerCase().includes(filter));
        children = tables.map((tb) => `
          <div class="dbm-node table ${isActiveTable(c.id, d.name, tb.name) ? "active" : ""}" style="--depth:2" data-node="table" data-conn="${esc(c.id)}" data-dbname="${esc(d.name)}" data-table="${esc(tb.name)}" title="${esc(tb.name)}${tb.comment ? ` — ${esc(tb.comment)}` : ""}">
            ${icon(tb.view ? "eye" : "grid")}<span class="label">${esc(tb.name)}</span>
            <span class="count">${fmtNum(tb.rows)}</span>
          </div>`).join("") || `<div class="dbm-node dim" style="--depth:2">${esc(t("db_no_match"))}</div>`;
      }
    }
    return `
      <div class="dbm-node db ${dbn.open ? "open" : ""} ${d.system ? "system" : ""}" style="--depth:1" data-node="db" data-conn="${esc(c.id)}" data-dbname="${esc(d.name)}">
        <span class="chev">${icon("back", "flip-down")}</span>${icon("database")}
        <span class="label">${esc(d.name)}</span>
        <button class="btn ghost icon-btn xs node-more" data-db="open-hologram" data-conn="${esc(c.id)}" data-dbname="${esc(d.name)}" title="${esc(t("holo_title"))}">${icon("layers")}</button>
        <button class="btn ghost icon-btn xs node-more" data-db="query-here" title="${esc(t("db_new_query"))}">${icon("terminal")}</button>
        <button class="btn ghost icon-btn xs node-more" data-menu="db" title="More">⋯</button>
      </div>${children}`;
  }

  const isActiveTable = (c, d, tbl) => { const a = tab(); return a && a.kind === "table" && a.conn === c && a.db === d && a.table === tbl; };

  function renderTabs() {
    const el = $("#dbm-tabs");
    if (!el) return;
    const reopenBtn = S.sideCollapsed
      ? `<button class="dbm-side-reopen" data-db="toggle-side" title="${esc(t("db_sidebar_show"))}">${icon("sidebar")}</button>`
      : "";
    el.innerHTML = reopenBtn + S.tabs.map((item) => {
      const dirty = item.kind === "table" && pendingCount(item);
      const label = item.kind === "query" ? item.title : item.kind === "hologram" ? `ERD · ${item.db}` : item.kind === "diff" ? `Diff · ${item.srcDb || "Source"} ➔ ${item.tgtDb || "Target"}` : item.kind === "db" ? item.db : item.table;
      const ico = item.kind === "query" ? "terminal" : item.kind === "hologram" ? "layers" : item.kind === "diff" ? "layers" : item.kind === "db" ? "database" : "grid";
      return `<button class="dbm-tab ${item.id === S.active ? "active" : ""}" data-tab-id="${item.id}" title="${esc(conn(item.conn)?.name || "")} · ${esc(item.db)}${item.table ? ` · ${esc(item.table)}` : ""}">
        ${icon(ico)}<span>${esc(label)}</span>${dirty ? `<span class="dirty-dot"></span>` : ""}
        <span class="x" data-close-tab="${item.id}">${icon("x")}</span></button>`;
    }).join("") + (S.tabs.length ? `<button class="dbm-tab add" data-db="new-query" title="${esc(t("db_new_query"))} (Ctrl+T)">${icon("plus")}</button>` : "");
  }

  function renderMain() {
    const el = $("#dbm-content");
    if (!el) return;
    const curTab = tab();
    if (!curTab) return (el.innerHTML = welcome());
    const grid = $(".dbm-grid-wrap", el);
    const key = curTab.id + (curTab.sub || "");
    const scroll = grid && el.dataset.tab === key ? [grid.scrollTop, grid.scrollLeft] : null;
    el.dataset.tab = key;
    if (curTab.kind === "db") el.innerHTML = dbTab(curTab);
    if (curTab.kind === "table") el.innerHTML = tableTab(curTab);
    if (curTab.kind === "hologram") {
      el.innerHTML = hologramTab(curTab);
      bindHologramEvents(curTab, el);
    }
    if (curTab.kind === "diff") {
      el.innerHTML = diffTab(curTab);
      bindDiffEvents(curTab, el);
    }
    if (scroll && curTab.kind !== "query" && curTab.kind !== "hologram" && curTab.kind !== "diff") {
      const next = $(".dbm-grid-wrap", el);
      if (next) [next.scrollTop, next.scrollLeft] = scroll;
    }
    if (curTab.kind === "query") {
      const editor = $(".sql-editor", el);
      if (editor && editor.dataset.tab === curTab.id) {
        $("#dbm-query-results").innerHTML = queryResults(curTab);
        $("#dbm-query-bar").innerHTML = queryBar(curTab);
        return;
      }
      el.innerHTML = queryTab(curTab);
      const area = $(".sql-editor", el);
      area.value = curTab.sql;
      area.focus();
    }
  }

  function welcome() {
    const cards = S.conns.slice(0, 8);
    return `
      <div class="dbm-welcome">
        <div class="empty-icon">${icon("database")}</div>
        <h2>${esc(t("db_welcome_title"))}</h2>
        <p class="muted">${esc(t("db_welcome_sub"))}</p>
        <div class="btn-row" style="justify-content:center">
          <button class="btn primary" data-db="new-conn">${icon("plus")}${esc(t("db_add_conn"))}</button>
          ${S.conns.length ? `<button class="btn" data-db="new-query">${icon("terminal")}${esc(t("db_new_query"))}</button>` : ""}
          ${S.conns.length ? `<button class="btn" data-db="open-diff">${icon("layers")}Schema Diff</button>` : ""}
        </div>
        ${cards.length ? `<div class="dbm-welcome-cards-grid">${cards.map((c) => {
          const dbName = c.database || (c.file || "").split(/[\\/]/).pop() || (c.driver === "sqlite" ? "main" : "");
          return `
            <div class="dbm-card-rich" data-open-conn="${esc(c.id)}" style="cursor:pointer;">
              <div class="dbm-card-top">
                <span class="drv" style="--c:${c.color || DRIVER_COLORS[c.driver] || "#888"}">${esc((DRIVERS[c.driver] || "?").slice(0, 2))}</span>
                <span class="dbm-card-meta"><b>${esc(c.name)}</b><small>${esc(dbName || c.host || "")}</small></span>
                ${tunnelBadge(c)}
              </div>
              <div class="dbm-card-foot">
                <span class="muted" style="font-size:11px;">${esc(DRIVERS[c.driver] || c.driver)}</span>
                <span class="btn-row" style="gap:4px;">
                  ${dbName ? `<button type="button" class="btn ghost xs" data-db="open-hologram" data-conn="${esc(c.id)}" data-dbname="${esc(dbName)}" title="${esc(t("holo_title"))}">${icon("layers")} ERD</button>` : ""}
                  <button type="button" class="btn ghost xs" data-db="query-here" data-conn="${esc(c.id)}" data-dbname="${esc(dbName)}" title="${esc(t("db_new_query"))}">${icon("terminal")} SQL</button>
                </span>
              </div>
            </div>`;
        }).join("")}</div>` : ""}
      </div>`;
  }

  /* ── tabs ───────────────────────────────────────────────── */
  function activate(id) {
    S.active = id;
    S.recent = [id, ...S.recent.filter((r) => r !== id)];
    // Memory: tabs that haven't been looked at for a while forget their rows.
    S.recent.slice(KEEP_DATA_TABS).forEach((rid) => {
      const old = S.tabs.find((t) => t.id === rid);
      if (old && old.kind === "table" && !pendingCount(old)) old.data = null;
      if (old && old.kind === "query") old.results = old.results?.map((r) => (r.rows ? { ...r, rows: [], dropped: true } : r)) || null;
    });
    const t = tab();
    renderTabs();
    renderMain();
    renderTree();
    if (t && t.kind === "table" && !t.data && !t.loading) loadRows(t);
    if (t && t.kind === "db" && !S.tree[t.conn]?.dbs[t.db]?.tables) openDb(t.conn, t.db);
    if (t && t.kind === "hologram" && !t.data && !t.loading) loadHologram(t);
  }

  function openTab(spec) {
    const existing = S.tabs.find((item) => item.kind === spec.kind && item.conn === spec.conn && item.db === spec.db && (spec.kind !== "table" || item.table === spec.table) && spec.kind !== "query");
    if (existing) {
      let needsReload = false;
      if (spec.showFilters !== undefined) existing.showFilters = spec.showFilters;
      if (spec.filters) {
        existing.filters = [...spec.filters];
        existing.page = 1;
        existing.showFilters = true;
        needsReload = true;
      }
      if (spec.where !== undefined && spec.where !== existing.where) {
        existing.where = spec.where;
        existing.page = 1;
        needsReload = true;
      }
      if (spec.sub) existing.sub = spec.sub;
      activate(existing.id);
      if (needsReload && existing.kind === "table") loadRows(existing, { keepPage: false });
      return;
    }
    const newTab = { id: `t${++seq}`, ...spec };
    if (newTab.kind === "table") Object.assign(newTab, {
      sub: spec.sub || "data",
      page: 1,
      limit: 100,
      sort: "",
      dir: "ASC",
      where: spec.where || "",
      search: spec.search || "",
      filters: spec.filters ? [...spec.filters] : [],
      showFilters: Boolean(spec.showFilters || (spec.filters && spec.filters.length)),
      showRawWhere: false,
      data: null,
      edits: new Map(),
      inserts: [],
      deletes: new Set(),
      selected: new Set(),
      structure: null
    });
    if (newTab.kind === "db") Object.assign(newTab, { tableSearch: "", tableSort: "name", tableDir: "ASC" });
    if (newTab.kind === "query") Object.assign(newTab, { title: `Query ${seq}`, sql: spec.sql || "", results: null, running: false, resultIndex: 0 });
    if (newTab.kind === "hologram") Object.assign(newTab, {
      title: `Hologram · ${spec.db}`,
      zoom: 1,
      panX: 60,
      panY: 60,
      data: null,
      loading: false,
      compact: false,
      filter: "",
      layoutMode: "hierarchical",
      edgeFilter: "all",
      hideIsolated: false,
      selectedTable: null,
      selectedRel: null,
      showInspector: true,
      showMinimap: true,
      showLegend: false,
      positions: {}
    });
    S.tabs.push(newTab);
    activate(newTab.id);
  }

  async function closeTab(id) {
    const t = S.tabs.find((x) => x.id === id);
    if (!t) return;
    if (t.kind === "table" && pendingCount(t) && !(await confirmModal({ title: `Discard changes to ${t.table}?`, message: "You have edits that were not saved.", confirm: "Discard", danger: true }))) return;
    const index = S.tabs.indexOf(t);
    S.tabs.splice(index, 1);
    S.recent = S.recent.filter((r) => r !== id);
    if (S.active === id) S.active = S.recent[0] || S.tabs[Math.max(0, index - 1)]?.id || null;
    if (S.active) activate(S.active);
    else { renderTabs(); renderMain(); renderTree(); }
  }

  /* ── database (objects) tab ─────────────────────────────── */
  function dbTab(tabObj) {
    const c = conn(tabObj.conn);
    const dbn = S.tree[tabObj.conn]?.dbs[tabObj.db] || {};
    const tables = dbn.tables || [];
    const totalRows = tables.reduce((acc, tb) => acc + (Number(tb.rows) || 0), 0);
    const totalSize = tables.reduce((acc, tb) => acc + (Number(tb.size) || 0), 0);
    const search = (tabObj.tableSearch || "").trim().toLowerCase();
    const sortBy = tabObj.tableSort || "name";
    const sortDir = tabObj.tableDir === "DESC" ? -1 : 1;
    const filtered = (search
      ? tables.filter((tb) => tb.name.toLowerCase().includes(search) || (tb.comment && tb.comment.toLowerCase().includes(search)) || (tb.engine && tb.engine.toLowerCase().includes(search)))
      : [...tables]
    ).sort((a, b) => {
      if (sortBy === "rows") return ((Number(a.rows) || 0) - (Number(b.rows) || 0)) * sortDir;
      if (sortBy === "size") return ((Number(a.size) || 0) - (Number(b.size) || 0)) * sortDir;
      if (sortBy === "engine") return String(a.engine || "").localeCompare(String(b.engine || "")) * sortDir;
      return String(a.name || "").localeCompare(String(b.name || "")) * sortDir;
    });
    const sortMark = (col) => tabObj.tableSort === col ? ` ${tabObj.tableDir === "DESC" ? "▼" : "▲"}` : "";
    return `
      <div class="dbm-pane">
        <div class="dbm-bar">
          <div class="crumbs-db">${esc(c?.name || "")}<span class="sep">›</span><b>${esc(tabObj.db)}</b>
            ${S.tree[tabObj.conn]?.version ? `<span class="chip">${esc(S.tree[tabObj.conn].version)}</span>` : ""}
            ${tunnelBadge(c)}</div>
          <span class="spacer"></span>
          <button class="btn sm" data-db="open-hologram" data-conn="${esc(tabObj.conn)}" data-dbname="${esc(tabObj.db)}" title="${esc(t("holo_title"))}">${icon("layers")}${esc(t("holo_title"))}</button>
          <button class="btn sm" data-db="query-db">${icon("terminal")}${esc(t("db_new_query"))}</button>
          <button class="btn sm" data-db="import">${icon("upload")}${esc(t("db_import"))}</button>
          <button class="btn sm" data-db="export-db">${icon("download")}${esc(t("db_export"))}</button>
          <button class="btn sm" data-db="snapshots-db" data-conn="${esc(tabObj.conn)}" data-dbname="${esc(tabObj.db)}" title="${esc(t("db_snapshots"))}">${icon("history")}${esc(t("db_snapshots"))}</button>
          <button class="btn icon-btn sm" data-db="refresh-db" title="${esc(t("db_refresh"))}">${icon("refresh")}</button>
        </div>
        <div class="dbm-kpi-strip">
          <div class="dbm-kpi-card"><span class="dbm-kpi-ico">${icon("grid")}</span><span class="dbm-kpi-meta"><small>${esc(t("db_tables"))}</small><b>${tables.length.toLocaleString()}</b></span></div>
          <div class="dbm-kpi-card"><span class="dbm-kpi-ico">${icon("layers")}</span><span class="dbm-kpi-meta"><small>${esc(t("db_total_rows"))}</small><b>${totalRows ? totalRows.toLocaleString() : "—"}</b></span></div>
          <div class="dbm-kpi-card"><span class="dbm-kpi-ico">${icon("database")}</span><span class="dbm-kpi-meta"><small>${esc(t("db_total_size"))}</small><b>${fmtBytes(totalSize)}</b></span></div>
          <div class="dbm-kpi-card"><span class="dbm-kpi-ico">${icon("cloud")}</span><span class="dbm-kpi-meta"><small>${esc(t("db_engine"))}</small><b>${esc(DRIVERS[c?.driver] || c?.driver || "DB")}</b></span></div>
        </div>
        <div class="dbm-toolbar" style="background:var(--surface-2);">
          <div class="search sm dbm-table-search" style="width:240px;">
            ${icon("search")}
            <input data-db-table-search placeholder="${esc(t("db_filter_tables"))}" value="${esc(tabObj.tableSearch || "")}" autocomplete="off" spellcheck="false">
            ${tabObj.tableSearch ? `<button type="button" class="btn ghost icon-btn xs" data-db-clear-table-search title="Clear">✕</button>` : ""}
          </div>
          <span class="muted" style="font-size:12px;">${filtered.length} / ${tables.length} ${esc(t("db_tables"))}</span>
          <span class="spacer"></span>
          <button class="btn sm" data-db="query-db" title="${esc(t("db_new_query"))}">${icon("terminal")} SQL Editor</button>
        </div>
        <div class="dbm-grid-wrap">
          ${dbn.loading && !tables.length ? `<div class="skeleton" style="height:120px;margin:16px"></div>` : `
          <table class="dbg objects">
            <thead><tr>
              <th class="obj-sort-btn" data-db-sort="name">${esc(t("db_sort_name"))}${sortMark("name")}</th>
              <th class="num obj-sort-btn" data-db-sort="rows">${esc(t("db_sort_rows"))}${sortMark("rows")}</th>
              <th class="num obj-sort-btn" data-db-sort="size">${esc(t("db_sort_size"))}${sortMark("size")}</th>
              ${c?.driver === "sqlite" ? "" : `<th class="obj-sort-btn" data-db-sort="engine">${esc(t("db_sort_engine"))}${sortMark("engine")}</th>`}
              <th>Comment</th>
              <th style="text-align:end;">Actions</th>
            </tr></thead>
            <tbody>${filtered.map((tb) => `
              <tr data-node="table" data-conn="${esc(tabObj.conn)}" data-dbname="${esc(tabObj.db)}" data-table="${esc(tb.name)}">
                <td>${icon(tb.view ? "eye" : "grid")} <b>${esc(tb.name)}</b>${tb.view ? ` <span class="chip">view</span>` : ""}</td>
                <td class="num">${tb.rows === null ? "—" : `${tb.rows > 0 && c?.driver !== "sqlite" ? "~" : ""}${Number(tb.rows).toLocaleString()}`}</td>
                <td class="num">${fmtBytes(tb.size)}</td>${c?.driver === "sqlite" ? "" : `<td>${esc(tb.engine)}</td>`}
                <td class="muted">${esc(tb.comment)}</td>
                <td class="row-actions" style="white-space:nowrap;">
                  <button class="btn ghost icon-btn xs" data-db-quick-query="${esc(tb.name)}" title="SELECT * FROM ${esc(tb.name)}">${icon("terminal")}</button>
                  <button class="btn ghost icon-btn xs" data-db-open-filtered="${esc(tb.name)}" title="Filter">${icon("filter")}</button>
                  <button class="btn ghost icon-btn xs" data-node="table" data-conn="${esc(tabObj.conn)}" data-dbname="${esc(tabObj.db)}" data-table="${esc(tb.name)}" title="${esc(t("db_open_table"))}">${icon("grid")}</button>
                  <button class="btn ghost icon-btn xs" data-menu="table" title="More">⋯</button>
                </td>
              </tr>`).join("") || `<tr><td colspan="6" class="dbm-hint">${esc(t("db_no_match"))}</td></tr>`}</tbody>
          </table>`}
        </div>
      </div>`;
  }

  /* ── table tab ──────────────────────────────────────────── */
  const pendingCount = (tabObj) => tabObj.kind === "table" ? tabObj.edits.size + tabObj.inserts.length + tabObj.deletes.size : 0;

  async function loadRows(tabObj, { keepPage = true } = {}) {
    tabObj.loading = true;
    if (!keepPage) tabObj.page = 1;
    if (S.active === tabObj.id) renderMain();
    const started = performance.now();
    if (!tabObj.structure && !tabObj._loadingStruct) {
      tabObj._loadingStruct = true;
      LD.call("db_structure", { conn: tabObj.conn, database: tabObj.db, table: tabObj.table })
        .then((res) => {
          tabObj.structure = res;
          tabObj._loadingStruct = false;
          if (S.active === tabObj.id && !tabObj.loading && tabObj.sub === "data") renderMain();
        })
        .catch(() => { tabObj._loadingStruct = false; });
    }
    try {
      tabObj.data = await LD.call("db_rows", {
        conn: tabObj.conn,
        database: tabObj.db,
        table: tabObj.table,
        page: tabObj.page,
        limit: tabObj.limit,
        sort: tabObj.sort,
        dir: tabObj.dir,
        where: tabObj.where,
        search: tabObj.search,
        filters: tabObj.filters || []
      });
      tabObj.error = "";
      tabObj.ms = Math.round(performance.now() - started);
      tabObj.selected = new Set();
    } catch (err) {
      tabObj.error = err.message;
    }
    tabObj.loading = false;
    if (S.active === tabObj.id) renderMain();
  }

  async function loadStructure(tabObj) {
    try {
      tabObj.structure = await LD.call("db_structure", { conn: tabObj.conn, database: tabObj.db, table: tabObj.table });
    } catch (err) {
      tabObj.structure = { error: err.message };
    }
    if (S.active === tabObj.id) renderMain();
  }

  async function inspectCellModal(tabObj, ri, colIndex) {
    if (!tabObj?.data) return;
    const col = tabObj.data.columns[colIndex];
    const row = tabObj.data.rows[ri];
    if (!col || !row) return;
    const edits = tabObj.edits.get(ri) || {};
    const hasEdit = Object.prototype.hasOwnProperty.call(edits, col.name);
    let raw = hasEdit ? edits[col.name] : row[colIndex];
    const isCut = !hasEdit && tabObj.data.truncated?.some(([r, ci]) => r === ri && ci === colIndex);

    openModal(`
      <div class="modal" style="max-width:640px;">
        <div class="modal-header">
          <h2>${esc(t("db_cell_inspector"))}: <code>${esc(col.name)}</code></h2>
          <p>${esc(tabObj.table)} · ${esc(col.type || "")}</p>
        </div>
        <div class="modal-body">
          <pre class="mono" data-cell-full style="max-height:52vh;overflow:auto;padding:12px;border-radius:8px;border:1px solid var(--border);background:var(--surface-2);white-space:pre-wrap;word-break:break-word;font-size:12px;">${isCut ? esc(t("db_loading")) : ""}</pre>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-cell-copy>${icon("copy")} ${esc(t("db_copy_value"))}</button>
          <button type="button" class="btn primary" data-dismiss>${esc(t("close") || "Close")}</button>
        </div>
      </div>`, async (mRoot) => {
      const pre = $("[data-cell-full]", mRoot);
      const formatVal = (v) => {
        if (v === null || v === undefined) return "NULL";
        const s = String(v);
        const tr = s.trim();
        if ((tr.startsWith("{") && tr.endsWith("}")) || (tr.startsWith("[") && tr.endsWith("]"))) {
          try { return JSON.stringify(JSON.parse(tr), null, 2); } catch {}
        }
        return s;
      };
      let currentText = formatVal(raw);
      pre.textContent = currentText;
      if (isCut) {
        try {
          const full = await LD.call("db_cell", {
            conn: tabObj.conn, database: tabObj.db, table: tabObj.table,
            key: rowKey(tabObj, ri), column: col.name,
          });
          currentText = formatVal(full.value);
          pre.textContent = currentText;
        } catch (err) {
          pre.textContent = `${currentText}\n\n[Failed to load full value: ${err.message}]`;
        }
      }
      $("[data-cell-copy]", mRoot).addEventListener("click", () => {
        copyText(currentText);
        toast("success", t("db_copied"));
      });
      $("[data-dismiss]", mRoot).addEventListener("click", closeModal);
    });
  }

  function tableTab(tabObj) {
    const c = conn(tabObj.conn);
    const subLabels = { data: t("db_data"), structure: t("db_structure"), ddl: "DDL" };
    const sub = `
      <div class="seg sm">
        ${["data", "structure", "ddl"].map((s) => `<button class="${tabObj.sub === s ? "active" : ""}" data-sub="${s}">${esc(subLabels[s])}</button>`).join("")}
      </div>`;
    const tools = `
      <div class="dbm-quick-tools">
        <button class="dbm-quick-btn" data-db="gen-model" title="Generate Eloquent Model">${icon("code")} Model</button>
        <button class="dbm-quick-btn" data-db="gen-migration" title="Generate Laravel Migration">${icon("file")} Migration</button>
        <button class="dbm-quick-btn" data-db="seed-table" title="Seed Realistic Dummy Data">${icon("zap")} Seed Data</button>
      </div>`;
    const head = `
      <div class="dbm-bar">
        <div class="crumbs-db">${esc(c?.name || "")}<span class="sep">›</span>${esc(tabObj.db)}<span class="sep">›</span><b>${esc(tabObj.table)}</b></div>
        <span class="spacer"></span>
        ${tools}
        ${sub}
      </div>`;
    if (tabObj.sub !== "data") {
      if (!tabObj.structure) { loadStructure(tabObj); return head + `<div class="skeleton" style="height:160px;margin:16px"></div>`; }
      if (tabObj.structure.error) return head + `<div class="card error-card" style="margin:16px">${esc(tabObj.structure.error)}</div>`;
      return head + (tabObj.sub === "structure" ? structureView(tabObj.structure) : `
        <div class="dbm-pane-scroll"><div class="ddl-box"><button class="btn sm" data-db="copy-ddl">${icon("copy")}${esc(t("copy") || "Copy")}</button><pre class="mono">${esc(tabObj.structure.ddl || "-- not available")}</pre></div></div>`);
    }
    return head + dataView(tabObj);
  }

  function dataView(tabObj) {
    const d = tabObj.data;
    const pending = pendingCount(tabObj);
    const readOnly = d?.view;
    const cols = d?.columns || [];
    const filterCount = (tabObj.filters || []).length;
    const hasSearch = Boolean((tabObj.search || "").trim());

    const fkMap = new Map();
    (tabObj.structure?.foreign_keys || []).forEach((fk) => {
      (fk.columns || []).forEach((colName, idx) => {
        fkMap.set(colName, {
          ref_table: fk.ref_table,
          ref_col: fk.ref_columns?.[idx] || fk.ref_columns?.[0] || "id",
        });
      });
    });

    const toolbar = `
      <div class="dbm-toolbar">
        <button class="btn icon-btn sm" data-db="reload" title="${esc(t("db_refresh"))} (F5)">${icon("refresh")}</button>
        ${readOnly ? `<span class="chip">Read-only view</span>` : `
        <button class="btn sm" data-db="add-row">${icon("plus")}Row</button>
        <button class="btn sm" data-db="delete-rows" ${tabObj.selected.size ? "" : "disabled"}>${icon("trash")}Delete${tabObj.selected.size ? ` (${tabObj.selected.size})` : ""}</button>`}
        
        <button class="btn sm ${tabObj.showFilters || filterCount ? "active" : ""}" data-db="toggle-filters" title="Filter table rows">
          ${icon("filter")} Filter ${filterCount ? `<span class="badge" style="margin-inline-start:4px;">${filterCount}</span>` : ""}
        </button>

        <div class="search sm">
          ${icon("search")}
          <input data-row-search placeholder="Search all columns…" value="${esc(tabObj.search)}" autocomplete="off" spellcheck="false">
          ${hasSearch ? `<button type="button" class="btn ghost icon-btn xs" data-db-clear-row-search title="Clear search">✕</button>` : ""}
        </div>

        <button class="btn sm" data-db="open-as-query" title="Open in SQL Editor">${icon("terminal")} SQL Editor</button>
        <button class="btn icon-btn sm" data-db="export-table" title="${esc(t("db_export"))}">${icon("download")}</button>
      </div>

      ${tabObj.showFilters || filterCount || tabObj.showRawWhere ? `
      <div class="dbm-filter-panel">
        <div class="dbm-filter-row">
          <span class="filter-lbl">${icon("filter")} Filter:</span>
          <select class="sm" data-flt-column>
            ${cols.filter((c) => !c.hidden).map((c) => `<option value="${esc(c.name)}">${esc(c.name)}${c.type ? ` (${esc(c.type.replace(/\(.*\)/, ""))})` : ""}</option>`).join("")}
          </select>
          <select class="sm" data-flt-op>
            <option value="=">= (equals)</option>
            <option value="!=">!= (not equals)</option>
            <option value="CONTAINS">contains</option>
            <option value="STARTS_WITH">starts with</option>
            <option value="ENDS_WITH">ends with</option>
            <option value=">">&gt; (greater than)</option>
            <option value="<">&lt; (less than)</option>
            <option value=">=">&gt;= (greater or equal)</option>
            <option value="<=">&lt;= (less or equal)</option>
            <option value="IS NULL">is NULL</option>
            <option value="IS NOT NULL">is NOT NULL</option>
            <option value="IN">in (comma-separated)</option>
          </select>
          <input class="sm mono" data-flt-value placeholder="Value…" spellcheck="false" autocomplete="off">
          <button class="btn sm primary" data-db="add-filter">${icon("plus")} Add Filter</button>
          <button class="btn ghost sm" data-db="toggle-raw-where" title="Switch to custom SQL WHERE clause">${tabObj.showRawWhere ? "Hide Raw SQL" : "Custom SQL WHERE"}</button>
        </div>

        ${tabObj.showRawWhere ? `
        <form class="dbm-raw-where-form" data-where-form>
          <span class="mono" style="font-size:11px; font-weight:700; color:var(--accent);">WHERE</span>
          <input name="where" class="mono" value="${esc(tabObj.where)}" placeholder="e.g. id > 100 AND status = 'active'" spellcheck="false" autocomplete="off">
          <button class="btn sm" type="submit">Apply SQL</button>
        </form>` : ""}

        ${filterCount ? `
        <div class="dbm-filter-chips">
          <span class="filter-chips-title">Active Filters:</span>
          ${tabObj.filters.map((f, fi) => `
            <span class="filter-chip">
              <b>${esc(f.column)}</b> <i>${esc(f.op)}</i> ${f.op.includes("NULL") ? "" : `<code>${esc(String(f.value ?? ""))}</code>`}
              <button type="button" class="filter-chip-remove" data-remove-filter="${fi}" title="Remove this filter">✕</button>
            </span>
          `).join("")}
          <button class="btn ghost xs" data-db="clear-all-filters" style="color:var(--red);">Clear all</button>
        </div>` : ""}
      </div>` : ""}

      ${pending ? `<div class="dbm-pending"><span><b>${pending}</b> unsaved change${pending > 1 ? "s" : ""}</span><span class="spacer"></span>
        <button class="btn sm" data-db="discard">Discard</button><button class="btn sm primary" data-db="save">${icon("check")}Save (Ctrl+S)</button></div>` : ""}`;
    if (tabObj.error && !d) return toolbar + `<div class="card error-card" style="margin:16px"><h3>${icon("alert")}Couldn't load rows</h3><p class="muted">${esc(tabObj.error)}</p></div>`;
    if (!d) return toolbar + `<div class="skeleton" style="height:220px;margin:16px"></div>`;

    const visible = cols.map((col, i) => ({ ...col, i })).filter((col) => !col.hidden);
    const truncated = new Set(d.truncated.map(([r, ci]) => `${r}:${ci}`));
    const headCells = visible.map((col) => {
      const fk = fkMap.get(col.name);
      return `
      <th data-sort="${esc(col.name)}" class="${tabObj.sort === col.name ? "sorted" : ""}" title="${esc(col.type || "")}${col.nullable ? "" : " · NOT NULL"}${fk ? ` · FK → ${fk.ref_table}.${fk.ref_col}` : ""}${col.comment ? ` — ${col.comment}` : ""}">
        <span>${col.pk ? `<span class="pk">PK</span>` : ""}${fk ? `<span class="fk-tag">FK</span>` : ""}${esc(col.name)}</span><small>${esc((col.type || "").replace(/\(.*\)/, ""))}</small>
        ${tabObj.sort === col.name ? `<i>${tabObj.dir === "ASC" ? "▲" : "▼"}</i>` : ""}
      </th>`;
    }).join("");

    const insertRows = tabObj.inserts.map((row, ni) => `
      <tr class="new" data-new="${ni}">
        <td class="rn"><button class="btn ghost icon-btn xs" data-db="drop-new" title="Remove">${icon("x")}</button></td>
        ${visible.map((col) => `<td data-new-cell="${esc(col.name)}" class="${row[col.name] !== undefined ? "dirty" : ""}">${row[col.name] !== undefined ? display(row[col.name]) : `<span class="null">${col.auto ? "auto" : col.default !== null && col.default !== undefined ? "default" : "NULL"}</span>`}</td>`).join("")}
      </tr>`).join("");

    const bodyRows = d.rows.map((row, ri) => {
      const edits = tabObj.edits.get(ri) || {};
      const deleted = tabObj.deletes.has(ri);
      return `
        <tr class="${deleted ? "deleted" : ""} ${tabObj.selected.has(ri) ? "selected" : ""}" data-row="${ri}">
          <td class="rn" data-select-row>${(d.page - 1) * d.limit + ri + 1}</td>
          ${visible.map((col) => {
            const has = Object.prototype.hasOwnProperty.call(edits, col.name);
            const value = has ? edits[col.name] : row[col.i];
            const cut = !has && truncated.has(`${ri}:${col.i}`);
            const fk = fkMap.get(col.name);
            const rawStr = value === null || value === undefined ? "" : String(value);
            const isLongOrJson = cut || (!col.binary && (rawStr.length > 72 || (rawStr.trim().startsWith("{") && rawStr.trim().endsWith("}"))));
            return `<td data-cell="${col.i}" class="${has ? "dirty" : ""} ${col.binary ? "bin" : ""} ${typeof value === "number" ? "num" : ""}">${display(value)}${cut ? `<span class="cut">…</span>` : ""}${fk && value !== null && value !== undefined ? `<button type="button" class="fk-jump-btn" data-fk-table="${esc(fk.ref_table)}" data-fk-col="${esc(fk.ref_col)}" data-fk-val="${esc(rawStr)}" title="${esc(t("db_jump_fk"))} → ${esc(fk.ref_table)}.${esc(fk.ref_col)}">${icon("external")}</button>` : ""}${isLongOrJson ? `<button type="button" class="cell-inspect-btn" data-inspect-row="${ri}" data-inspect-col="${col.i}" title="${esc(t("db_cell_inspector"))}">${icon("eye")}</button>` : ""}</td>`;
          }).join("")}
        </tr>`;
    }).join("");

    const from = d.total ? (d.page - 1) * d.limit + 1 : 0;
    return toolbar + `
      <div class="dbm-grid-wrap ${tabObj.loading ? "loading" : ""}" tabindex="0" data-grid>
        <table class="dbg">
          <thead><tr><th class="rn" data-select-all title="Select all">#</th>${headCells}</tr></thead>
          <tbody>${insertRows}${bodyRows || (insertRows ? "" : `<tr><td colspan="${visible.length + 1}" class="dbm-hint">${tabObj.where || tabObj.search ? esc(t("db_no_match")) : esc(t("db_empty_table"))}</td></tr>`)}</tbody>
        </table>
      </div>
      <div class="dbm-foot">
        <span class="muted">${from}–${Math.min(d.page * d.limit, d.total)} of ${d.estimated ? "~" : ""}${Number(d.total).toLocaleString()} ${esc(t("db_rows"))}${tabObj.ms ? ` · ${tabObj.ms} ms` : ""}</span>
        ${!d.identity.length && !d.view ? `<span class="chip warn" title="Edits match the whole row and change one row at a time">No primary key</span>` : ""}
        <span class="spacer"></span>
        <button class="btn icon-btn sm" data-page="first" ${d.page <= 1 ? "disabled" : ""} title="First page">«</button>
        <button class="btn icon-btn sm" data-page="prev" ${d.page <= 1 ? "disabled" : ""}>${icon("back")}</button>
        <span class="page-input">Page <input type="number" min="1" max="${d.pages}" value="${d.page}" data-page-input> of ${d.pages}</span>
        <button class="btn icon-btn sm" data-page="next" ${d.page >= d.pages ? "disabled" : ""}>${icon("back", "flip")}</button>
        <button class="btn icon-btn sm" data-page="last" ${d.page >= d.pages ? "disabled" : ""} title="Last page">»</button>
        <select data-page-size class="sm">${PAGE_SIZES.map((n) => `<option value="${n}" ${n === d.limit ? "selected" : ""}>${n} / page</option>`).join("")}</select>
      </div>`;
  }

  function structureView(s) {
    return `
      <div class="dbm-pane-scroll">
        <h4 class="dbm-h">${esc(t("db_columns"))} <span class="muted">${s.columns.length}</span></h4>
        <table class="dbg plain">
          <thead><tr><th>#</th><th>Name</th><th>Type</th><th>Null</th><th>Default</th><th>Key</th><th>Extra</th><th>Comment</th></tr></thead>
          <tbody>${s.columns.map((c, i) => `<tr>
            <td class="muted">${i + 1}</td><td><b>${esc(c.name)}</b></td><td class="mono">${esc(c.type)}</td>
            <td>${c.nullable ? "YES" : `<span class="chip">NOT NULL</span>`}</td>
            <td class="mono">${c.default === null || c.default === undefined ? `<span class="null">NULL</span>` : esc(c.default)}</td>
            <td>${c.pk ? `<span class="pk">PK</span>` : ""}</td><td class="mono muted">${esc(c.extra || (c.auto ? "auto increment" : ""))}</td><td class="muted">${esc(c.comment)}</td>
          </tr>`).join("")}</tbody>
        </table>
        <h4 class="dbm-h">${esc(t("db_indexes"))} <span class="muted">${s.indexes.length}</span></h4>
        <table class="dbg plain">
          <thead><tr><th>Name</th><th>Columns</th><th>Kind</th><th>Method</th></tr></thead>
          <tbody>${s.indexes.map((x) => `<tr><td><b>${esc(x.name)}</b></td><td class="mono">${esc(x.columns.join(", "))}</td>
            <td>${x.primary ? `<span class="pk">PRIMARY</span>` : x.unique ? `<span class="chip">UNIQUE</span>` : "INDEX"}</td><td class="muted">${esc(x.type || "")}</td></tr>`).join("") || `<tr><td colspan="4" class="dbm-hint">No indexes</td></tr>`}</tbody>
        </table>
        <h4 class="dbm-h">${esc(t("db_foreign_keys"))} <span class="muted">${s.foreign_keys.length}</span></h4>
        <table class="dbg plain">
          <thead><tr><th>Name</th><th>Columns</th><th>References</th><th>On update</th><th>On delete</th></tr></thead>
          <tbody>${s.foreign_keys.map((f) => `<tr><td><b>${esc(f.name)}</b></td><td class="mono">${esc(f.columns.join(", "))}</td>
            <td class="mono"><button type="button" class="btn ghost xs mono" data-struct-jump-table="${esc(f.ref_table)}" title="${esc(t("db_open_table"))}">${esc(f.ref_table)}(${esc(f.ref_columns.join(", "))}) ${icon("external")}</button></td><td>${esc(f.on_update || "")}</td><td>${esc(f.on_delete || "")}</td></tr>`).join("") || `<tr><td colspan="5" class="dbm-hint">No foreign keys</td></tr>`}</tbody>
        </table>
      </div>`;
  }

  /* cell editing */
  function startEdit(td) {
    const t = tab();
    if (!t?.data || t.data.view) return;
    const tr = td.closest("tr");
    const isNew = tr.dataset.new !== undefined;
    const colName = isNew ? td.dataset.newCell : t.data.columns[+td.dataset.cell].name;
    const col = t.data.columns.find((c) => c.name === colName);
    if (col.binary) return toast("error", "Binary values can't be edited here", "Use the SQL editor.");
    const ri = isNew ? +tr.dataset.new : +tr.dataset.row;
    if (!isNew && t.deletes.has(ri)) return;
    let value;
    if (isNew) value = t.inserts[ri][colName];
    else {
      const edits = t.edits.get(ri) || {};
      value = Object.prototype.hasOwnProperty.call(edits, colName) ? edits[colName] : t.data.rows[ri][+td.dataset.cell];
    }
    const truncated = !isNew && t.data.truncated.some(([r, c]) => r === ri && c === +td.dataset.cell) && !(t.edits.get(ri) || {})[colName];
    const long = typeof value === "string" && (value.length > 80 || value.includes("\n"));
    td.classList.add("editing");
    td.innerHTML = long || truncated
      ? `<textarea class="cell-input mono" rows="4" spellcheck="false"></textarea>`
      : `<input class="cell-input mono" spellcheck="false" autocomplete="off">`;
    const input = $(".cell-input", td);
    input.value = value === null || value === undefined ? "" : String(value);
    input.placeholder = value === null ? "NULL" : "";
    input.dataset.wasNull = value === null || value === undefined ? "1" : "";
    input.focus();
    input.select();
    if (truncated) {
      input.disabled = true;
      LD.call("db_cell", { conn: t.conn, database: t.db, table: t.table, key: rowKey(t, ri), column: colName })
        .then((res) => { input.value = res.value ?? ""; input.disabled = false; input.focus(); })
        .catch((err) => { toast("error", "Couldn't load the full value", err.message); renderMain(); });
    }
    const finish = (commit, move = 0) => {
      if (!td.classList.contains("editing")) return;
      td.classList.remove("editing");
      if (commit) {
        const raw = input.value;
        const newValue = raw === "" && input.dataset.wasNull ? null : raw;
        setCell(t, isNew, ri, colName, newValue, td);
      }
      renderMain();
      if (move) {
        const cells = $$(`#dbm-content tr[data-${isNew ? "new" : "row"}="${ri}"] td[data-${isNew ? "new-cell" : "cell"}]`);
        const index = cells.findIndex((c) => (isNew ? c.dataset.newCell === colName : t.data.columns[+c.dataset.cell].name === colName));
        const next = cells[index + move];
        if (next) startEdit(next);
      }
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); finish(false); }
      else if (e.key === "Enter" && (input.tagName === "INPUT" || e.ctrlKey)) { e.preventDefault(); finish(true); }
      else if (e.key === "Tab") { e.preventDefault(); finish(true, e.shiftKey ? -1 : 1); }
    });
    input.addEventListener("blur", () => setTimeout(() => finish(true), 0));
  }

  function setCell(t, isNew, ri, colName, value) {
    if (isNew) {
      t.inserts[ri][colName] = value;
      return renderTabs();
    }
    const colIndex = t.data.columns.findIndex((c) => c.name === colName);
    const original = t.data.rows[ri][colIndex];
    const edits = t.edits.get(ri) || {};
    if (value === original || (original !== null && value !== null && String(original) === value)) delete edits[colName];
    else edits[colName] = value;
    Object.keys(edits).length ? t.edits.set(ri, edits) : t.edits.delete(ri);
    renderTabs();
  }

  function rowKey(t, ri) {
    const d = t.data;
    const row = d.rows[ri];
    const key = {};
    if (d.identity.length) {
      for (const name of d.identity) key[name] = row[d.columns.findIndex((c) => c.name === name)];
    } else {
      const cut = new Set(d.truncated.filter(([r]) => r === ri).map(([, c]) => c));
      d.columns.forEach((c, i) => { if (!c.binary && !cut.has(i)) key[c.name] = row[i]; });
    }
    return key;
  }

  async function saveChanges(t) {
    if (!pendingCount(t)) return;
    const matchAll = !t.data.identity.length;
    const changes = {
      deletes: [...t.deletes].map((ri) => ({ key: rowKey(t, ri), match_all: matchAll })),
      updates: [...t.edits].filter(([ri]) => !t.deletes.has(ri)).map(([ri, values]) => ({ key: rowKey(t, ri), values, match_all: matchAll })),
      inserts: t.inserts,
    };
    try {
      const res = await LD.call("db_apply", { conn: t.conn, database: t.db, table: t.table, changes });
      t.edits = new Map(); t.inserts = []; t.deletes = new Set();
      const parts = [res.inserted && `${res.inserted} added`, res.updated && `${res.updated} updated`, res.deleted && `${res.deleted} deleted`].filter(Boolean);
      toast("success", `Saved ${t.table}`, parts.join(", "));
      renderTabs();
      await loadRows(t);
    } catch (err) {
      toast("error", "Nothing was saved", err.message);
    }
  }

  /* ── SQL & query helpers ────────────────────────────────── */
  function buildTableSelectSql(driver, table, filters = [], rawWhere = "", sort = "", dir = "ASC", limit = 100) {
    const tableRef = q(driver, table);
    let sql = `SELECT * FROM ${tableRef}`;
    const clauses = [];
    (filters || []).forEach((f) => {
      const colQ = q(driver, f.column);
      const op = (f.op || "=").toUpperCase().trim();
      const val = f.value;
      if (op === "IS NULL" || op === "IS NOT NULL") {
        clauses.push(`${colQ} ${op}`);
      } else if (op === "CONTAINS") {
        clauses.push(`${colQ} LIKE '%${String(val).replace(/'/g, "''")}%'`);
      } else if (op === "STARTS_WITH") {
        clauses.push(`${colQ} LIKE '${String(val).replace(/'/g, "''")}%'`);
      } else if (op === "ENDS_WITH") {
        clauses.push(`${colQ} LIKE '%${String(val).replace(/'/g, "''")}'`);
      } else if (op === "IN" || op === "NOT IN") {
        const parts = String(val).split(",").map((v) => `'${v.trim().replace(/'/g, "''")}'`);
        clauses.push(`${colQ} ${op} (${parts.join(", ")})`);
      } else {
        const isNum = !isNaN(val) && val !== "" && val !== null;
        clauses.push(`${colQ} ${op} ${isNum ? val : `'${String(val).replace(/'/g, "''")}'`}`);
      }
    });
    if (rawWhere && rawWhere.trim()) clauses.push(`(${rawWhere.trim()})`);
    if (clauses.length) sql += `\nWHERE ${clauses.join(" AND ")}`;
    if (sort) sql += `\nORDER BY ${q(driver, sort)} ${dir === "DESC" ? "DESC" : "ASC"}`;
    sql += `\nLIMIT ${limit || 100};`;
    return sql;
  }

  function formatSql(sql) {
    if (!sql || !sql.trim()) return sql;
    const keywords = [
      "SELECT", "FROM", "WHERE", "AND", "OR", "GROUP BY", "ORDER BY", "HAVING",
      "LIMIT", "OFFSET", "JOIN", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "FULL JOIN",
      "CROSS JOIN", "ON", "INSERT INTO", "VALUES", "UPDATE", "SET", "DELETE FROM",
      "AS", "DESC", "ASC", "IN", "NOT IN", "IS NULL", "IS NOT NULL", "LIKE", "NOT LIKE",
      "DISTINCT", "UNION", "UNION ALL", "CASE", "WHEN", "THEN", "ELSE", "END",
      "EXISTS", "NOT EXISTS", "BETWEEN", "CREATE TABLE", "ALTER TABLE", "DROP TABLE",
      "TRUNCATE TABLE", "PRIMARY KEY", "FOREIGN KEY", "DEFAULT"
    ];
    keywords.sort((a, b) => b.length - a.length);

    let res = sql;
    keywords.forEach((kw) => {
      const rx = new RegExp(`\\b${kw.replace(/ /g, "\\s+")}\\b`, "gi");
      res = res.replace(rx, kw);
    });

    const breakClauses = ["FROM", "WHERE", "GROUP BY", "ORDER BY", "HAVING", "LIMIT", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "JOIN", "SET", "VALUES"];
    breakClauses.forEach((kw) => {
      const rx = new RegExp(`([^\\n;])\\s+(${kw}\\b)`, "g");
      res = res.replace(rx, "$1\n$2");
    });
    return res;
  }

  function saveQueryHistory(sql) {
    if (!sql || !sql.trim()) return;
    try {
      const raw = localStorage.getItem("ld_sql_history");
      let history = raw ? JSON.parse(raw) : [];
      history = [sql.trim(), ...history.filter((s) => s.trim() !== sql.trim())].slice(0, 30);
      localStorage.setItem("ld_sql_history", JSON.stringify(history));
    } catch {}
  }

  function showQueryHistoryMenu(x, y) {
    try {
      const raw = localStorage.getItem("ld_sql_history");
      const history = raw ? JSON.parse(raw) : [];
      if (!history.length) {
        return toast("info", "No query history yet", "Queries you execute will be saved here automatically.");
      }
      const items = history.map((sql) => {
        const singleLine = sql.replace(/\s+/g, " ").trim();
        const label = singleLine.length > 55 ? singleLine.slice(0, 55) + "…" : singleLine;
        return {
          label,
          icon: "terminal",
          run: () => {
            const area = $(".sql-editor");
            if (area) {
              area.value = sql;
              area.focus();
              const current = tab();
              if (current?.kind === "query") current.sql = sql;
            }
          }
        };
      });
      items.push("-");
      items.push({
        label: "Clear History",
        icon: "trash",
        danger: true,
        run: () => {
          localStorage.removeItem("ld_sql_history");
          toast("success", "Query history cleared");
        }
      });
      showMenu(x, y, items);
    } catch (e) {
      toast("error", "Couldn't read history", e.message);
    }
  }

  function insertSqlSnippet(text, replaceAll = false) {
    const area = $(".sql-editor");
    if (!area) return;
    area.focus();
    if (replaceAll || !area.value.trim()) {
      area.value = text;
      area.setSelectionRange(text.length, text.length);
    } else {
      const start = area.selectionStart;
      const end = area.selectionEnd;
      const before = area.value.substring(0, start);
      const after = area.value.substring(end);
      const needSpaceBefore = before.length && !/\s$/.test(before) && !/^\s/.test(text);
      const insert = (needSpaceBefore ? " " : "") + text;
      area.value = before + insert + after;
      const newPos = start + insert.length;
      area.setSelectionRange(newPos, newPos);
    }
    const current = tab();
    if (current?.kind === "query") current.sql = area.value;
  }

  function applyQueryTemplate(templateName) {
    const current = tab();
    const c = conn(current?.conn);
    const dbn = S.tree[current?.conn]?.dbs[current?.db] || {};
    const tables = dbn.tables || [];
    const tblSelect = $("[data-query-table]");
    const selectedTable = tblSelect?.value || (tables[0] ? tables[0].name : "table_name");
    const tRef = q(c?.driver, selectedTable);

    let sql = "";
    switch (templateName) {
      case "select_all":
        sql = `SELECT * FROM ${tRef} LIMIT 100;`;
        break;
      case "select_where":
        sql = `SELECT * FROM ${tRef}\nWHERE status = 'active'\nORDER BY id DESC\nLIMIT 50;`;
        break;
      case "count_group":
        sql = `SELECT status, COUNT(*) AS count\nFROM ${tRef}\nGROUP BY status\nORDER BY count DESC;`;
        break;
      case "join":
        sql = `SELECT t1.*, t2.*\nFROM ${tRef} t1\nINNER JOIN other_table t2 ON t1.id = t2.${selectedTable}_id\nLIMIT 100;`;
        break;
      case "insert":
        sql = `INSERT INTO ${tRef} (column1, column2)\nVALUES ('value1', 'value2');`;
        break;
      case "update":
        sql = `UPDATE ${tRef}\nSET column1 = 'value1'\nWHERE id = 1;`;
        break;
      case "delete":
        sql = `DELETE FROM ${tRef}\nWHERE id = 1;`;
        break;
      default:
        return;
    }
    insertSqlSnippet(sql, true);
  }

  function exportQueryResult(result, format) {
    if (!result?.columns || !result?.rows) return;
    let content = "";
    let mime = "text/plain;charset=utf-8";
    const ext = format === "json" ? "json" : "csv";
    if (format === "json") {
      const objs = result.rows.map((row) => Object.fromEntries(result.columns.map((c, idx) => [c, row[idx]])));
      content = JSON.stringify(objs, null, 2);
      mime = "application/json;charset=utf-8";
    } else {
      const csvCell = (val) => {
        if (val === null || val === undefined) return "";
        const s = String(val);
        return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
      };
      content = [result.columns.map(csvCell).join(","), ...result.rows.map((row) => row.map(csvCell).join(","))].join("\n");
      mime = "text/csv;charset=utf-8";
    }
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `query_result_${Date.now()}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  }

  /* ── query tab ──────────────────────────────────────────── */
  function queryTab(tabObj) {
    const c = conn(tabObj.conn);
    const dbs = (S.tree[tabObj.conn]?.databases || []).filter((d) => S.showSystem || !d.system || d.name === tabObj.db);
    const dbn = S.tree[tabObj.conn]?.dbs[tabObj.db] || {};
    const tables = dbn.tables || [];

    return `
      <div class="dbm-query">
        <div class="dbm-bar">
          <select data-query-conn class="sm">${S.conns.map((x) => `<option value="${esc(x.id)}" ${x.id === tabObj.conn ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>
          ${c?.driver === "sqlite" ? "" : `<select data-query-db class="sm"><option value="">(no database)</option>${dbs.map((d) => `<option ${d.name === tabObj.db ? "selected" : ""}>${esc(d.name)}</option>`).join("")}</select>`}
          <span class="spacer"></span>
          <div id="dbm-query-bar">${queryBar(tabObj)}</div>
        </div>

        <div class="dbm-query-tools">
          <div class="dbm-query-tool-group">
            <span class="tool-label">Table:</span>
            <select class="sm" data-query-table title="Select a table">
              <option value="">(choose table)</option>
              ${tables.map((tb) => `<option value="${esc(tb.name)}">${esc(tb.name)}</option>`).join("")}
            </select>
            <button class="btn xs ghost" data-query-action="select-table" title="Generate SELECT * FROM table LIMIT 100">SELECT *</button>
            <button class="btn xs ghost" data-query-action="count-table" title="Generate COUNT(*) FROM table">COUNT(*)</button>
          </div>

          <div class="dbm-query-tool-sep"></div>

          <div class="dbm-query-tool-group">
            <span class="tool-label">Snippets:</span>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="WHERE " title="Add WHERE">WHERE</button>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="ORDER BY id DESC " title="Add ORDER BY">ORDER BY</button>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="GROUP BY " title="Add GROUP BY">GROUP BY</button>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="INNER JOIN  ON " title="Add INNER JOIN">JOIN</button>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="LIMIT 50 " title="Add LIMIT">LIMIT</button>
          </div>

          <div class="dbm-query-tool-sep"></div>

          <div class="dbm-query-tool-group">
            <select class="sm" data-query-template title="Load SQL Template">
              <option value="">SQL Templates…</option>
              <option value="select_all">SELECT * FROM ... LIMIT 100</option>
              <option value="select_where">SELECT ... WHERE ...</option>
              <option value="count_group">SELECT col, COUNT(*) GROUP BY col</option>
              <option value="join">SELECT * FROM t1 JOIN t2 ON ...</option>
              <option value="insert">INSERT INTO table (col1, col2) VALUES (...)</option>
              <option value="update">UPDATE table SET col = val WHERE ...</option>
              <option value="delete">DELETE FROM table WHERE ...</option>
            </select>
            <button class="btn xs ghost" data-query-action="format" title="Format SQL keywords and indentation">${icon("code")} Format</button>
            <button class="btn xs ghost" data-query-action="history" title="Recent queries history">${icon("clock")} History</button>
            <button class="btn xs ghost" data-query-action="clear" title="Clear editor">${icon("trash")} Clear</button>
          </div>
        </div>

        <textarea class="sql-editor mono" data-tab="${tabObj.id}" spellcheck="false" placeholder="SELECT * FROM users LIMIT 100;&#10;&#10;Ctrl+Enter runs the selection, or everything."></textarea>
        <div class="dbm-results" id="dbm-query-results">${queryResults(tabObj)}</div>
      </div>`;
  }

  function queryBar(tabObj) {
    return `
      <button class="btn sm" data-db="explain-query" ${tabObj.running ? "disabled" : ""} title="Analyze query execution plan (EXPLAIN)">${icon("pulse")} EXPLAIN</button>
      <button class="btn sm primary" data-db="run-query" ${tabObj.running ? "disabled" : ""}>${icon("play")}${tabObj.running ? "Running…" : esc(t("db_run_query"))} <kbd>Ctrl ↵</kbd></button>
    `;
  }

  function queryResults(tabObj) {
    if (tabObj.running) return `<div class="dbm-hint"><span class="spin-dot"></span>Running…</div>`;
    if (tabObj.showExplain && tabObj.explain) return renderExplainView(tabObj);
    if (!tabObj.results) return `<div class="dbm-hint">Results show up here.</div>`;
    const results = tabObj.results;
    const index = Math.min(tabObj.resultIndex, results.length - 1);
    const r = results[index];
    const tabs = results.length > 1 ? `<div class="seg sm result-tabs">${results.map((x, i) => `<button class="${i === index ? "active" : ""}" data-result="${i}">${x.error ? "⚠ Error" : x.columns ? `Result ${i + 1}` : `Query ${i + 1}`}</button>`).join("")}</div>` : "";
    let body;
    if (r.error) body = `<div class="query-msg error">${icon("alert")}<div><b>${esc(r.error)}</b><small class="mono">${esc(r.sql)}</small></div></div>`;
    else if (!r.columns) body = `<div class="query-msg ok">${icon("check")}<div><b>${r.affected >= 0 ? `${r.affected} row${r.affected === 1 ? "" : "s"} affected` : "Done"}</b><small class="mono">${esc(r.sql)} · ${r.ms} ms</small></div></div>`;
    else if (r.dropped) body = `<div class="dbm-hint">Rows released to save memory — run the query again.</div>`;
    else body = `
      <div class="dbm-grid-wrap"><table class="dbg">
        <thead><tr><th class="rn">#</th>${r.columns.map((c) => `<th><span>${esc(c)}</span></th>`).join("")}</tr></thead>
        <tbody>${r.rows.map((row, i) => `<tr><td class="rn">${i + 1}</td>${row.map((v) => `<td class="${typeof v === "number" ? "num" : ""}">${display(v)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${r.columns.length + 1}" class="dbm-hint">${esc(t("db_empty_table"))}</td></tr>`}</tbody>
      </table></div>
      <div class="dbm-foot">
        <span class="muted">${r.rows.length}${r.more ? "+" : ""} ${esc(t("db_rows"))} · ${r.ms} ms${r.more ? " · showing the first 1000" : ""}</span>
        <span class="spacer"></span>
        ${r.rows.length ? `
          <button type="button" class="btn xs ghost" data-db="export-query-csv">${icon("download")} ${esc(t("db_export_csv"))}</button>
          <button type="button" class="btn xs ghost" data-db="export-query-json">${icon("code")} ${esc(t("db_export_json"))}</button>
        ` : ""}
      </div>`;
    return tabs + body;
  }

  async function runQuery(tabObj) {
    const area = $(".sql-editor");
    if (area) tabObj.sql = area.value;
    const selected = area && area.selectionEnd > area.selectionStart ? area.value.slice(area.selectionStart, area.selectionEnd) : tabObj.sql;
    if (!selected.trim()) return toast("error", "Write a query first");
    saveQueryHistory(selected);
    tabObj.running = true;
    tabObj.showExplain = false;
    renderMain();
    try {
      const res = await LD.call("db_query", { conn: tabObj.conn, database: tabObj.db, sql: selected });
      tabObj.results = res.results;
      const firstError = res.results.findIndex((r) => r.error);
      const lastGrid = res.results.map((r, i) => (r.columns ? i : -1)).filter((i) => i >= 0).pop();
      tabObj.resultIndex = firstError >= 0 ? firstError : lastGrid ?? res.results.length - 1;
      if (/\b(create|drop|alter|rename)\b/i.test(selected) && S.tree[tabObj.conn]?.dbs[tabObj.db]) openDb(tabObj.conn, tabObj.db, true);
    } catch (err) {
      tabObj.results = [{ error: err.message, sql: selected.slice(0, 120) }];
      tabObj.resultIndex = 0;
    }
    tabObj.running = false;
    renderMain();
  }

  /* ── connections (Navicat-style with SSH) ──────────────── */
  async function connModal(existing = {}) {
    if (!S.servers.length) {
      try { S.servers = (await LD.call("servers")).servers || []; } catch { S.servers = []; }
    }
    const sshEnv = await LD.call("ssh_environment").catch(() => ({
      local_user: "", keys: [], config_hosts: [], agent_active: false, agent_keys: [],
    }));
    S.sshEnv = sshEnv;
    const configHosts = sshEnv.config_hosts || [];
    const discKeys = sshEnv.keys || [];
    const localUser = sshEnv.local_user || "";
    const driver = existing.driver || "mysql";
    const useSsh = Boolean(existing.use_ssh || existing.ssh_host || existing.server);
    const sshMode = existing.ssh_mode || (existing.server && !existing.ssh_host ? "server" : "custom");
    const sshAuth = existing.ssh_auth || (existing.has_ssh_password ? "password" : existing.ssh_key ? "key" : "auto");
    const curSshKey = existing.ssh_key || "";
    const sshKeyMatched = discKeys.some((k) => k.path === curSshKey);
    const sshKeySelectVal = !curSshKey ? "" : (sshKeyMatched ? curSshKey : "__custom__");
    const userChips = Array.from(new Set([localUser, "root", "ubuntu", "forge", "deploy"].filter(Boolean)));
    const agentBadge = sshEnv.agent_active
      ? (sshEnv.agent_keys?.length
        ? `<span class="ssh-agent-pill ok">${icon("key")} ${esc(t("ssh_agent_running"))} (${sshEnv.agent_keys.length})</span>`
        : `<span class="ssh-agent-pill">${icon("key")} ${esc(t("ssh_agent_empty"))}</span>`)
      : `<span class="ssh-agent-pill">${icon("info")} ${esc(t("ssh_agent_inactive"))}</span>`;
    const colors = ["", "#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"];

    openModal(`
      <form class="modal" id="conn-form" novalidate style="max-width:560px;">
        <div class="modal-header">
          <h2>${existing.id ? "Edit connection" : esc(t("db_add_conn"))}</h2>
          <p>${esc(t("db_ssh_tab_title"))}</p>
        </div>

        <div class="modal-body" style="padding-bottom: 8px;">
          <!-- Top Nav Tabs -->
          <div class="conn-nav-tabs">
            <button type="button" class="conn-nav-btn active" data-nav-panel="general">
              ${icon("database")} ${esc(t("db_general_tab"))}
            </button>
            <button type="button" class="conn-nav-btn" data-nav-panel="ssh">
              ${icon("cloud")} ${esc(t("db_ssh_tunnel_tab"))} <span class="badge" data-ssh-badge ${useSsh ? "" : "hidden"}>${esc(sshAuth.toUpperCase())}</span>
            </button>
          </div>

          <!-- General Tab Panel -->
          <div class="conn-panel" id="conn-panel-general">
            <div class="segmented" style="margin-bottom: 12px;">
              ${Object.entries(DRIVERS).map(([k, v]) => `
                <button type="button" class="segment ${k === driver ? "active" : ""}" data-driver="${k}">
                  ${v}
                </button>
              `).join("")}
            </div>
            <input type="hidden" name="driver" value="${esc(driver)}">

            <div style="display:flex; gap:10px; align-items:flex-end;">
              <label class="field" style="flex:1;">
                <span>Connection Name</span>
                <input name="name" value="${esc(existing.name || "")}" placeholder="e.g. Production Database">
              </label>
              <div class="field" style="flex:none; padding-bottom: 2px;">
                <span>Color Tag</span>
                <div class="conn-colors">
                  ${colors.map((c) => `
                    <button type="button" class="conn-color-dot ${c === (existing.color || "") ? "active" : ""}"
                      data-color="${c}" style="background:${c || "var(--border-strong)"};"
                      title="${c ? "Tag color" : "Default"}"></button>
                  `).join("")}
                </div>
                <input type="hidden" name="color" value="${esc(existing.color || "")}">
              </div>
            </div>

            <!-- Network DB options -->
            <div data-net ${driver === "sqlite" ? "hidden" : ""}>
              <div class="grid-2">
                <label class="field">
                  <span>Host</span>
                  <input name="host" value="${esc(existing.host || "127.0.0.1")}" spellcheck="false" placeholder="127.0.0.1 or localhost">
                </label>
                <label class="field">
                  <span>Port</span>
                  <input name="port" value="${esc(existing.port || "")}" placeholder="${driver === "pgsql" ? 5432 : 3306}" inputmode="numeric">
                </label>
                <label class="field">
                  <span>Username</span>
                  <input name="user" value="${esc(existing.user || "")}" spellcheck="false" autocomplete="off" placeholder="root">
                </label>
                <label class="field">
                  <span>Password</span>
                  <div class="input-with-eye">
                    <input name="password" type="password" placeholder="${existing.has_password ? "(unchanged)" : "Enter password"}" autocomplete="new-password">
                    <button type="button" class="input-eye-btn" data-toggle-pass title="Show/Hide Password">${icon("eye")}</button>
                  </div>
                </label>
              </div>
              <label class="field">
                <span>Default Database <small>(optional)</small></span>
                <input name="database" value="${esc(existing.database || "")}" spellcheck="false" placeholder="e.g. shopjo_db">
              </label>
            </div>

            <!-- SQLite options -->
            <div data-file ${driver !== "sqlite" ? "hidden" : ""}>
              <label class="field">
                <span>Database File</span>
                <span class="input-group" style="width:100%">
                  <input name="file" value="${esc(existing.file || "")}" spellcheck="false" placeholder="/path/to/database.sqlite">
                  <button type="button" class="btn" data-pick-sqlite>${esc(t("ssh_browse"))}</button>
                </span>
              </label>
            </div>
          </div>

          <!-- SSH Tunnel Tab Panel -->
          <div class="conn-panel" id="conn-panel-ssh" hidden>
            <label class="place-opt" style="margin-bottom: 12px; cursor: pointer;">
              <input type="checkbox" name="use_ssh" ${useSsh ? "checked" : ""} class="switch">
              <span>
                <b>${esc(t("db_use_ssh"))}</b>
                <small>${esc(t("srv_modal_sub"))}</small>
              </span>
            </label>

            <div id="ssh-details" ${useSsh ? "" : "hidden"}>
              <div class="segmented" style="grid-template-columns: 1fr 1fr; margin-bottom: 12px;">
                <button type="button" class="segment ${sshMode === "custom" ? "active" : ""}" data-ssh-mode="custom">
                  ${icon("wrench")} ${esc(t("db_ssh_source_custom"))}
                </button>
                <button type="button" class="segment ${sshMode === "server" ? "active" : ""}" data-ssh-mode="server">
                  ${icon("cloud")} ${esc(t("db_ssh_source_server"))}
                </button>
              </div>
              <input type="hidden" name="ssh_mode" value="${esc(sshMode)}">

              <!-- Custom SSH settings -->
              <div id="ssh-custom-box" ${sshMode === "custom" ? "" : "hidden"}>
                ${configHosts.length ? `
                <label class="field" style="margin-bottom:8px;">
                  <span>${esc(t("ssh_config_import"))}</span>
                  <select class="input" data-db-ssh-config-pick>
                    <option value="">${esc(t("ssh_config_select"))}</option>
                    ${configHosts.map((h) => `<option value="${esc(h.alias)}">${esc(h.alias)}${h.hostname ? ` → ${esc(h.hostname)}` : ""}${h.user ? ` (${esc(h.user)})` : ""}</option>`).join("")}
                  </select>
                </label>` : ""}
                <div class="grid-2">
                  <label class="field">
                    <span>${esc(t("srv_host_label"))}</span>
                    <input name="ssh_host" value="${esc(existing.ssh_host || "")}" placeholder="e.g. 165.245.242.88 or config-alias" spellcheck="false">
                  </label>
                  <label class="field">
                    <span>${esc(t("srv_port_label"))}</span>
                    <input name="ssh_port" value="${esc(existing.ssh_port || "")}" placeholder="22 / ~/.ssh/config" inputmode="numeric">
                  </label>
                </div>

                <div class="field" style="margin-top: 6px;">
                  <span>${esc(t("ssh_auth_mode"))}</span>
                  <div class="segmented" style="grid-template-columns: 1fr 1fr 1fr; margin-top: 4px;">
                    <button type="button" class="segment ${sshAuth === "auto" ? "active" : ""}" data-ssh-auth="auto">
                      ${icon("sparkles")} ${esc(t("ssh_auth_auto"))}
                    </button>
                    <button type="button" class="segment ${sshAuth === "key" ? "active" : ""}" data-ssh-auth="key">
                      ${icon("key")} ${esc(t("ssh_auth_key"))}
                    </button>
                    <button type="button" class="segment ${sshAuth === "password" ? "active" : ""}" data-ssh-auth="password">
                      ${icon("lock")} ${esc(t("ssh_auth_password"))}
                    </button>
                  </div>
                  <input type="hidden" name="ssh_auth" value="${esc(sshAuth)}">
                  <small class="ssh-auth-hint" data-db-ssh-hint></small>
                </div>

                <label class="field" style="margin-top:6px;">
                  <span>${esc(t("ssh_user_label"))} <small data-db-ssh-user-opt>(${esc(t("ssh_user_optional"))})</small></span>
                  <input name="ssh_user" value="${esc(existing.ssh_user || "")}" placeholder="${esc(localUser || "ubuntu / root")}" spellcheck="false" autocomplete="off">
                  ${userChips.length ? `<div class="ssh-quick-chips">${userChips.map((u) => `<button type="button" class="ssh-chip-btn" data-db-user-chip="${esc(u)}">${esc(u)}</button>`).join("")}</div>` : ""}
                </label>

                <!-- Key Auth (Auto + Key modes) -->
                <div id="ssh-auth-key" ${sshAuth === "password" ? "hidden" : ""}>
                  <label class="field">
                    <span>${esc(t("ssh_key_label"))}</span>
                    <select class="input" data-db-key-select style="margin-bottom:6px;">
                      <option value="" ${sshKeySelectVal === "" ? "selected" : ""}>${esc(t("ssh_key_auto_opt"))}</option>
                      ${discKeys.map((k) => `<option value="${esc(k.path)}" ${sshKeySelectVal === k.path ? "selected" : ""}>${esc(k.name)} (${esc(k.type)}${k.has_pub ? "" : ", no .pub"})</option>`).join("")}
                      <option value="__custom__" ${sshKeySelectVal === "__custom__" ? "selected" : ""}>${esc(t("ssh_key_custom_opt"))}</option>
                    </select>
                    <span class="input-group" style="width:100%;display:${sshKeySelectVal === "__custom__" ? "flex" : "none"}" data-db-key-custom>
                      <input name="ssh_key" value="${esc(curSshKey)}" placeholder="~/.ssh/id_ed25519" spellcheck="false">
                      <button type="button" class="btn" data-pick-ssh-key>${esc(t("ssh_browse"))}</button>
                    </span>
                    <div>${agentBadge}</div>
                  </label>
                  <label class="field">
                    <span>${esc(t("ssh_passphrase_label"))}</span>
                    <div class="input-with-eye">
                      <input name="ssh_passphrase" type="password" placeholder="${existing.has_ssh_passphrase ? "(unchanged)" : "Optional key passphrase"}" autocomplete="new-password">
                      <button type="button" class="input-eye-btn" data-toggle-pass title="Show/Hide Passphrase">${icon("eye")}</button>
                    </div>
                  </label>
                </div>

                <!-- Password Auth (Auto + Password modes) -->
                <div id="ssh-auth-password" ${sshAuth === "key" ? "hidden" : ""}>
                  <label class="field">
                    <span>SSH Password ${sshAuth === "auto" ? "<small>(optional)</small>" : ""}</span>
                    <div class="input-with-eye">
                      <input name="ssh_password" type="password" placeholder="${existing.has_ssh_password ? "(unchanged)" : (sshAuth === "auto" ? "Leave blank to use SSH key / agent" : "Enter SSH password")}" autocomplete="new-password">
                      <button type="button" class="input-eye-btn" data-toggle-pass title="Show/Hide Password">${icon("eye")}</button>
                    </div>
                  </label>
                </div>
              </div>

              <!-- Saved Server option -->
              <div id="ssh-server-box" ${sshMode === "server" ? "" : "hidden"}>
                <label class="field">
                  <span>${esc(t("db_ssh_select_server"))}</span>
                  <select name="server">
                    <option value="">Choose a server...</option>
                    ${S.servers.map((s) => `
                      <option value="${esc(s.id)}" ${s.id === existing.server ? "selected" : ""}>
                        ${esc(s.name)} (${esc(s.host)})
                      </option>
                    `).join("")}
                  </select>
                </label>
              </div>

              <!-- SSH Test button -->
              <div class="ssh-inline-test">
                <button type="button" class="btn sm" data-test-ssh>${icon("pulse")} ${esc(t("db_test_ssh_btn"))}</button>
                <div id="ssh-test-inline" class="ssh-inline-result muted"></div>
              </div>
            </div>
          </div>

          <div class="test-result-box" id="conn-test" hidden></div>
        </div>

        <div class="modal-footer">
          ${existing.id ? `<button type="button" class="btn danger" data-remove style="margin-right:auto">${icon("trash")}Remove</button>` : ""}
          <button type="button" class="btn" data-test>${icon("pulse")}${esc(t("db_test_db_btn"))}</button>
          <button type="button" class="btn" data-dismiss>${esc(t("cancel"))}</button>
          <button type="submit" class="btn primary">${existing.id ? esc(t("save")) : `${icon("plus")}Add`}</button>
        </div>
      </form>`, (root) => {
      const form = $("#conn-form", root);
      const f = form.elements;
      const hintEl = $("[data-db-ssh-hint]", form);
      const userOptEl = $("[data-db-ssh-user-opt]", form);
      const keySelect = $("[data-db-key-select]", form);
      const keyCustomRow = $("[data-db-key-custom]", form);

      const sync = () => {
        const sqlite = f.driver.value === "sqlite";
        $("[data-net]", form).hidden = sqlite;
        $("[data-file]", form).hidden = !sqlite;
        f.port.placeholder = f.driver.value === "pgsql" ? "5432" : "3306";
      };

      const syncSshAuth = (mode) => {
        f.ssh_auth.value = mode;
        $$("[data-ssh-auth]", form).forEach((x) => x.classList.toggle("active", x.dataset.sshAuth === mode));
        const hints = { auto: t("ssh_auth_auto_hint"), key: t("ssh_auth_key_hint"), password: t("ssh_auth_password_hint") };
        if (hintEl) hintEl.textContent = hints[mode] || "";
        if (userOptEl) userOptEl.hidden = mode === "password";
        $("#ssh-auth-password", form).hidden = mode === "key";
        $("#ssh-auth-key", form).hidden = mode === "password";
        const badge = $("[data-ssh-badge]", form);
        if (badge) badge.textContent = mode.toUpperCase();
      };

      syncSshAuth(sshAuth);

      // Top Tab Navigation
      $$("[data-nav-panel]", form).forEach((btn) => {
        btn.addEventListener("click", () => {
          $$("[data-nav-panel]", form).forEach((b) => b.classList.toggle("active", b === btn));
          const panelName = btn.dataset.navPanel;
          $("#conn-panel-general", form).hidden = panelName !== "general";
          $("#conn-panel-ssh", form).hidden = panelName !== "ssh";
        });
      });

      // Driver selector
      $$("[data-driver]", form).forEach((b) => b.addEventListener("click", () => {
        $$("[data-driver]", form).forEach((x) => x.classList.toggle("active", x === b));
        f.driver.value = b.dataset.driver;
        sync();
      }));

      // Color picker
      $$("[data-color]", form).forEach((b) => b.addEventListener("click", () => {
        $$("[data-color]", form).forEach((x) => x.classList.toggle("active", x === b));
        f.color.value = b.dataset.color;
      }));

      // Password eye toggling
      $$("[data-toggle-pass]", form).forEach((btn) => {
        btn.addEventListener("click", () => {
          const input = btn.previousElementSibling;
          if (input) {
            input.type = input.type === "password" ? "text" : "password";
            btn.classList.toggle("active", input.type === "text");
          }
        });
      });

      // SSH toggle
      f.use_ssh.addEventListener("change", () => {
        const checked = f.use_ssh.checked;
        $("#ssh-details", form).hidden = !checked;
        $("[data-ssh-badge]", form).hidden = !checked;
      });

      // SSH mode (custom vs server)
      $$("[data-ssh-mode]", form).forEach((b) => b.addEventListener("click", () => {
        $$("[data-ssh-mode]", form).forEach((x) => x.classList.toggle("active", x === b));
        f.ssh_mode.value = b.dataset.sshMode;
        $("#ssh-custom-box", form).hidden = f.ssh_mode.value !== "custom";
        $("#ssh-server-box", form).hidden = f.ssh_mode.value !== "server";
      }));

      // SSH auth (auto / key / password)
      $$("[data-ssh-auth]", form).forEach((b) => b.addEventListener("click", () => {
        syncSshAuth(b.dataset.sshAuth);
      }));

      $("[data-db-ssh-config-pick]", form)?.addEventListener("change", (e) => {
        const picked = configHosts.find((h) => h.alias === e.target.value);
        if (!picked) return;
        f.ssh_host.value = picked.alias;
        f.ssh_port.value = picked.port || "";
        f.ssh_user.value = picked.user || "";
        if (picked.identityfile) {
          const matched = discKeys.some((k) => k.path === picked.identityfile);
          if (keySelect) keySelect.value = matched ? picked.identityfile : "__custom__";
          if (keyCustomRow) keyCustomRow.style.display = matched ? "none" : "flex";
          f.ssh_key.value = picked.identityfile;
          syncSshAuth("key");
        } else {
          if (keySelect) keySelect.value = "";
          if (keyCustomRow) keyCustomRow.style.display = "none";
          f.ssh_key.value = "";
          syncSshAuth("auto");
        }
      });

      $$("[data-db-user-chip]", form).forEach((chip) => {
        chip.addEventListener("click", () => { f.ssh_user.value = chip.dataset.dbUserChip; });
      });

      keySelect?.addEventListener("change", () => {
        const val = keySelect.value;
        if (val === "__custom__") {
          keyCustomRow.style.display = "flex";
          f.ssh_key.focus();
        } else {
          keyCustomRow.style.display = "none";
          f.ssh_key.value = val;
        }
      });

      const payload = () => ({
        id: existing.id,
        name: f.name.value,
        driver: f.driver.value,
        color: f.color.value,
        host: f.host.value,
        port: f.port.value,
        user: f.user.value,
        password: f.password.value === "" && existing.has_password ? null : f.password.value,
        database: f.database.value,
        file: f.file.value,
        use_ssh: f.use_ssh.checked,
        ssh_mode: f.ssh_mode.value,
        server: f.server ? f.server.value : "",
        ssh_host: f.ssh_host ? f.ssh_host.value : "",
        ssh_port: f.ssh_port ? f.ssh_port.value : "",
        ssh_user: f.ssh_user ? f.ssh_user.value : "",
        ssh_auth: f.ssh_auth ? f.ssh_auth.value : "auto",
        ssh_password: f.ssh_password && f.ssh_password.value === "" && existing.has_ssh_password ? null : (f.ssh_password ? f.ssh_password.value : ""),
        ssh_key: f.ssh_key ? f.ssh_key.value : "",
        ssh_passphrase: f.ssh_passphrase && f.ssh_passphrase.value === "" && existing.has_ssh_passphrase ? null : (f.ssh_passphrase ? f.ssh_passphrase.value : ""),
      });

      $("[data-dismiss]", form).addEventListener("click", closeModal);

      $("[data-pick-sqlite]", form).addEventListener("click", async () => {
        const path = await LD.call("db_pick_sqlite", { current: f.file.value }).catch(() => "");
        if (path) {
          f.file.value = path;
          if (!f.name.value) f.name.value = path.split(/[\\/]/).pop();
        }
      });

      $("[data-pick-ssh-key]", form)?.addEventListener("click", async () => {
        const path = await LD.call("pick_file", { title: t("ssh_key_label"), current: f.ssh_key?.value || "~/.ssh" }).catch(() => "");
        if (path && f.ssh_key) {
          f.ssh_key.value = path;
          if (keySelect) keySelect.value = "__custom__";
          if (keyCustomRow) keyCustomRow.style.display = "flex";
        }
      });

      // Inline SSH Test
      $("[data-test-ssh]", form)?.addEventListener("click", async () => {
        const out = $("#ssh-test-inline", form);
        out.className = "ssh-inline-result muted";
        out.innerHTML = `<span class="spin-dot"></span> ${esc(t("ssh_testing"))}`;
        const p = payload();
        try {
          const res = await LD.call("db_test_ssh", {
            id: existing.id,
            ssh_mode: p.ssh_mode,
            server: p.server,
            ssh_host: p.ssh_host,
            ssh_port: p.ssh_port,
            ssh_user: p.ssh_user,
            ssh_auth: p.ssh_auth,
            ssh_key: p.ssh_key,
            ssh_password: p.ssh_password,
            ssh_passphrase: p.ssh_passphrase,
          });
          out.className = "ssh-inline-result ok";
          out.innerHTML = `${icon("check")} SSH connected · ${res.ms} ms${res.auth_mode ? ` (${esc(res.auth_mode)})` : ""}`;
        } catch (err) {
          out.className = "ssh-inline-result err";
          out.innerHTML = `${icon("alert")} ${esc(err.message)}`;
        }
      });

      // Full Connection Test
      $("[data-test]", form).addEventListener("click", async () => {
        const out = $("#conn-test", form);
        out.hidden = false;
        out.className = "test-result-box";
        out.innerHTML = `<div class="test-result-step"><span class="spin-dot"></span> Testing connection…</div>`;
        const p = payload();
        try {
          const res = await LD.call("db_test", { ...p, name: p.name || "test" });
          out.className = "test-result-box ok";
          let html = "";
          if (res.ssh) {
            html += `<div class="test-result-step">${icon("check")} SSH Tunnel connected · ${esc(res.ssh.host)} (${res.ssh.ms} ms)</div>`;
          }
          html += `<div class="test-result-step">${icon("check")} Database connected · ${esc(res.version)} (${res.ms} ms total)</div>`;
          out.innerHTML = html;
        } catch (err) {
          out.className = "test-result-box error";
          out.innerHTML = `<div class="test-result-step">${icon("alert")} ${esc(err.message)}</div>`;
        }
      });

      $("[data-remove]", form)?.addEventListener("click", async () => {
        closeModal();
        if (!(await confirmModal({ title: `Remove ${existing.name}?`, message: "Only the saved connection is removed; the database is not touched.", confirm: "Remove", danger: true }))) return;
        await LD.call("db_remove", { id: existing.id });
        S.tabs.filter((x) => x.conn === existing.id).forEach((x) => closeTab(x.id));
        delete S.tree[existing.id];
        await loadConns();
        render();
      });

      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const saved = await LD.call("db_save", payload());
          closeModal();
          delete S.tree[saved.id];
          await loadConns();
          render();
          openConn(saved.id);
        } catch (err) {
          toast("error", err.message);
        }
      });

      sync();
    });
  }

  /* ── hologram (schema ERD visualizer) ────────────────────── */
  function openHologram(connId, dbName) {
    const existing = S.tabs.find((x) => x.kind === "hologram" && x.conn === connId && x.db === dbName);
    if (existing) return activate(existing.id);
    openTab({ kind: "hologram", conn: connId, db: dbName });
  }

  async function loadHologram(tabObj, force = false) {
    if (tabObj.loading) return;
    tabObj.loading = true;
    tabObj.error = "";
    if (force) tabObj.data = null;
    renderMain();
    try {
      tabObj.data = await LD.call("db_hologram", { conn: tabObj.conn, database: tabObj.db });
      const savedKey = `ld_holo_${tabObj.conn}_${tabObj.db}`;
      const savedPos = localStorage.getItem(savedKey);
      if (savedPos && !force) {
        try { tabObj.positions = JSON.parse(savedPos); } catch { tabObj.positions = {}; }
      } else {
        tabObj.positions = {};
      }
      autoLayout(tabObj, false);
    } catch (err) {
      tabObj.error = err.message;
    }
    tabObj.loading = false;
    renderMain();
  }

  function buildHoloGraph(tabObj) {
    const tables = tabObj.data?.tables || [];
    const allRels = tabObj.data?.relations || [];
    const edgeFilter = tabObj.edgeFilter || "all";
    const visibleRelations = edgeFilter === "explicit" ? allRels.filter((r) => !r.inferred) : allRels;
    const adj = {};
    tables.forEach((tb) => { adj[tb.name] = { out: [], in: [], neighbors: new Set() }; });
    visibleRelations.forEach((rel) => {
      if (!adj[rel.source_table] || !adj[rel.target_table]) return;
      adj[rel.source_table].out.push(rel);
      adj[rel.target_table].in.push(rel);
      if (rel.source_table !== rel.target_table) {
        adj[rel.source_table].neighbors.add(rel.target_table);
        adj[rel.target_table].neighbors.add(rel.source_table);
      }
    });
    const isolatedSet = new Set(
      tables.filter((tb) => !adj[tb.name].out.length && !adj[tb.name].in.length).map((tb) => tb.name)
    );
    return { tables, allRels, visibleRelations, adj, isolatedSet };
  }

  function holoVisibleCols(tabObj, tb, relations) {
    if (!tabObj.compact) return tb.columns || [];
    return (tb.columns || []).filter((col) =>
      col.pk || col.unique || relations.some((r) =>
        (r.source_table === tb.name && r.source_col === col.name) ||
        (r.target_table === tb.name && r.target_col === col.name)
      )
    );
  }

  function holoCardEstHeight(tabObj, tb, relations) {
    const count = Math.max(1, holoVisibleCols(tabObj, tb, relations).length);
    return Math.min(272, 42 + count * 23);
  }

  function autoLayout(tabObj, overwrite = true) {
    if (!tabObj.data || !tabObj.data.tables) return;
    const { tables, visibleRelations, adj, isolatedSet } = buildHoloGraph(tabObj);
    tabObj.positions = tabObj.positions || {};
    const cardW = 256;

    if (tabObj.layoutMode === "grid") {
      const sorted = [...tables].sort((a, b) => {
        const degA = adj[a.name].in.length * 2 + adj[a.name].out.length;
        const degB = adj[b.name].in.length * 2 + adj[b.name].out.length;
        return degB - degA || a.name.localeCompare(b.name);
      });
      const colsCount = Math.max(2, Math.min(5, Math.ceil(Math.sqrt(sorted.length))));
      const colHeights = new Array(colsCount).fill(60);
      sorted.forEach((tb) => {
        if (!overwrite && tabObj.positions[tb.name]) return;
        let minCol = 0;
        for (let c = 1; c < colsCount; c++) {
          if (colHeights[c] < colHeights[minCol]) minCol = c;
        }
        tabObj.positions[tb.name] = { x: 60 + minCol * (cardW + 84), y: colHeights[minCol] };
        colHeights[minCol] += holoCardEstHeight(tabObj, tb, visibleRelations) + 32;
      });
    } else {
      const tableMap = Object.fromEntries(tables.map((tb) => [tb.name, tb]));
      const connectedNames = tables.map((tb) => tb.name).filter((n) => !isolatedSet.has(n));
      const seen = new Set();
      const components = [];
      connectedNames.forEach((start) => {
        if (seen.has(start)) return;
        const comp = [];
        const queue = [start];
        seen.add(start);
        while (queue.length) {
          const cur = queue.shift();
          comp.push(cur);
          adj[cur].neighbors.forEach((nb) => {
            if (!seen.has(nb) && !isolatedSet.has(nb)) { seen.add(nb); queue.push(nb); }
          });
        }
        components.push(comp);
      });
      components.sort((a, b) => b.length - a.length);

      let cursorY = 60;
      let maxUsedX = 60;
      const colGap = 116;
      const rowGap = 32;

      components.forEach((comp) => {
        const compSet = new Set(comp);
        const depth = {};
        comp.forEach((n) => { depth[n] = 0; });
        const maxDepth = Math.max(1, comp.length - 1);
        for (let iter = 0; iter < comp.length; iter++) {
          let changed = false;
          visibleRelations.forEach((rel) => {
            if (!compSet.has(rel.source_table) || !compSet.has(rel.target_table)) return;
            if (rel.source_table === rel.target_table) return;
            const nextDepth = Math.min(maxDepth, depth[rel.target_table] + 1);
            if (nextDepth > depth[rel.source_table]) {
              depth[rel.source_table] = nextDepth;
              changed = true;
            }
          });
          if (!changed) break;
        }

        const layers = new Map();
        comp.forEach((n) => {
          const d = depth[n];
          if (!layers.has(d)) layers.set(d, []);
          layers.get(d).push(n);
        });
        const layerKeys = [...layers.keys()].sort((a, b) => a - b);
        const layerYOrder = {};
        let compBottom = cursorY;

        layerKeys.forEach((lk, li) => {
          const nodes = layers.get(lk);
          nodes.sort((a, b) => {
            const avgA = adj[a].out.length
              ? adj[a].out.reduce((sum, r) => sum + (layerYOrder[r.target_table] ?? 0), 0) / adj[a].out.length
              : 0;
            const avgB = adj[b].out.length
              ? adj[b].out.reduce((sum, r) => sum + (layerYOrder[r.target_table] ?? 0), 0) / adj[b].out.length
              : 0;
            return (li > 0 ? avgA - avgB : 0) || (adj[b].in.length - adj[a].in.length) || a.localeCompare(b);
          });
          let y = cursorY;
          const x = 60 + li * (cardW + colGap);
          nodes.forEach((n, idx) => {
            layerYOrder[n] = idx;
            if (overwrite || !tabObj.positions[n]) {
              tabObj.positions[n] = { x, y };
            }
            const h = holoCardEstHeight(tabObj, tableMap[n], visibleRelations);
            y += h + rowGap;
          });
          compBottom = Math.max(compBottom, y);
          maxUsedX = Math.max(maxUsedX, x + cardW);
        });
        cursorY = compBottom + 44;
      });

      const isolatedList = [...isolatedSet].sort((a, b) => a.localeCompare(b));
      if (isolatedList.length) {
        const isoStartX = connectedNames.length ? maxUsedX + 120 : 60;
        const isoCols = Math.max(1, Math.min(3, Math.ceil(Math.sqrt(isolatedList.length))));
        const isoHeights = new Array(isoCols).fill(60);
        isolatedList.forEach((n) => {
          if (!overwrite && tabObj.positions[n]) return;
          let minCol = 0;
          for (let c = 1; c < isoCols; c++) {
            if (isoHeights[c] < isoHeights[minCol]) minCol = c;
          }
          tabObj.positions[n] = { x: isoStartX + minCol * (cardW + 64), y: isoHeights[minCol] };
          isoHeights[minCol] += holoCardEstHeight(tabObj, tableMap[n], visibleRelations) + rowGap;
        });
      }
    }

    try {
      localStorage.setItem(`ld_holo_${tabObj.conn}_${tabObj.db}`, JSON.stringify(tabObj.positions));
    } catch {}
  }

  function buildJoinSql(driver, tableName, rels) {
    const tblRef = q(driver, tableName);
    if (!rels || !rels.length) return `SELECT * FROM ${tblRef} LIMIT 100;`;
    const seen = new Set([tableName]);
    const joins = [];
    rels.forEach((rel) => {
      if (rel.source_table === tableName && !seen.has(rel.target_table)) {
        seen.add(rel.target_table);
        joins.push(`LEFT JOIN ${q(driver, rel.target_table)} ON ${tblRef}.${q(driver, rel.source_col)} = ${q(driver, rel.target_table)}.${q(driver, rel.target_col)}`);
      } else if (rel.target_table === tableName && !seen.has(rel.source_table)) {
        seen.add(rel.source_table);
        joins.push(`LEFT JOIN ${q(driver, rel.source_table)} ON ${q(driver, rel.source_table)}.${q(driver, rel.source_col)} = ${tblRef}.${q(driver, rel.target_col)}`);
      }
    });
    return `SELECT ${tblRef}.*\nFROM ${tblRef}${joins.length ? `\n${joins.join("\n")}` : ""}\nLIMIT 100;`;
  }

  function hologramInspectorHtml(tabObj, graph) {
    if (tabObj.showInspector === false) return "";
    const c = conn(tabObj.conn);
    if (tabObj.selectedRel) {
      const rel = graph.visibleRelations.find((r) => r.id === tabObj.selectedRel) || graph.allRels.find((r) => r.id === tabObj.selectedRel);
      if (!rel) return "";
      const sql = `SELECT s.*, tgt.*\nFROM ${q(c?.driver, rel.source_table)} s\nINNER JOIN ${q(c?.driver, rel.target_table)} tgt ON s.${q(c?.driver, rel.source_col)} = tgt.${q(c?.driver, rel.target_col)}\nLIMIT 100;`;
      return `
        <aside class="hologram-inspector" data-holo-inspector>
          <div class="hologram-inspector-head">
            ${icon("git")}
            <b>${esc(t("holo_inspector_edge"))}</b>
            <button type="button" class="btn ghost icon-btn xs" data-holo="clear-focus" title="${esc(t("holo_clear_focus"))}">${icon("x")}</button>
          </div>
          <div class="hologram-inspector-body">
            <div class="hologram-inspector-section">
              <span class="chip ${rel.inferred ? "" : "ok"}">${esc(rel.inferred ? t("holo_inferred_fk") : t("holo_explicit_fk"))}</span>
              <div style="margin-top:8px;display:flex;flex-direction:column;gap:4px;">
                <button type="button" class="hologram-fk-pill" data-holo-jump-table="${esc(rel.source_table)}">
                  <span class="mono"><b>${esc(rel.source_table)}</b>.${esc(rel.source_col)}</span>
                  <span>→</span>
                </button>
                <button type="button" class="hologram-fk-pill" data-holo-jump-table="${esc(rel.target_table)}">
                  <span class="mono"><b>${esc(rel.target_table)}</b>.${esc(rel.target_col)}</span>
                  <span>${icon("external")}</span>
                </button>
              </div>
            </div>
            ${rel.constraint ? `<div class="hologram-inspector-section"><h5>${esc(t("holo_constraint"))}</h5><code class="mono">${esc(rel.constraint)}</code></div>` : ""}
            ${(rel.on_update || rel.on_delete) ? `
            <div class="hologram-inspector-section">
              <div class="grid-2">
                <div><h5>${esc(t("holo_on_update"))}</h5><span class="chip">${esc(rel.on_update || "—")}</span></div>
                <div><h5>${esc(t("holo_on_delete"))}</h5><span class="chip">${esc(rel.on_delete || "—")}</span></div>
              </div>
            </div>` : ""}
            <div class="hologram-inspector-section">
              <button type="button" class="btn sm primary" style="width:100%;" data-holo-run-join="${esc(sql)}">${icon("terminal")} ${esc(t("holo_run_join"))}</button>
            </div>
          </div>
        </aside>`;
    }
    if (tabObj.selectedTable) {
      const tb = graph.tables.find((x) => x.name === tabObj.selectedTable);
      if (!tb) return "";
      const nodeAdj = graph.adj[tb.name] || { out: [], in: [] };
      const joinSql = buildJoinSql(c?.driver, tb.name, [...nodeAdj.out, ...nodeAdj.in]);
      return `
        <aside class="hologram-inspector" data-holo-inspector>
          <div class="hologram-inspector-head">
            ${icon("grid")}
            <b title="${esc(tb.name)}">${esc(tb.name)}</b>
            <button type="button" class="btn ghost icon-btn xs" data-holo="clear-focus" title="${esc(t("holo_clear_focus"))}">${icon("x")}</button>
          </div>
          <div class="hologram-inspector-body">
            <div class="hologram-inspector-section">
              <div style="display:flex;gap:6px;flex-wrap:wrap;">
                <span class="chip">${(tb.columns || []).length} ${esc(t("db_columns"))}</span>
                ${tb.rows !== null && tb.rows !== undefined ? `<span class="chip">${fmtNum(tb.rows)} ${esc(t("db_rows"))}</span>` : ""}
                ${tb.size ? `<span class="chip">${fmtBytes(tb.size)}</span>` : ""}
              </div>
              ${tb.comment ? `<p class="muted" style="margin:6px 0 0;">${esc(tb.comment)}</p>` : ""}
            </div>
            <div class="hologram-inspector-section" style="display:flex;gap:6px;flex-wrap:wrap;">
              <button type="button" class="btn sm primary" data-holo-action="data" data-table="${esc(tb.name)}">${icon("eye")} ${esc(t("holo_open_table"))}</button>
              <button type="button" class="btn sm" data-holo-sql-table="${esc(tb.name)}">${icon("terminal")} ${esc(t("holo_open_sql"))}</button>
              <button type="button" class="btn sm" data-holo-copy-join="${esc(joinSql)}">${icon("copy")} ${esc(t("holo_copy_join"))}</button>
            </div>
            ${nodeAdj.out.length ? `
            <div class="hologram-inspector-section">
              <h5>${esc(t("holo_outgoing_fk"))} (${nodeAdj.out.length})</h5>
              ${nodeAdj.out.map((r) => `
                <button type="button" class="hologram-fk-pill" data-holo-jump-table="${esc(r.target_table)}" title="${esc(r.source_col)} → ${esc(r.target_table)}.${esc(r.target_col)}">
                  <span class="mono">${esc(r.source_col)} → <b>${esc(r.target_table)}</b></span>
                  ${r.inferred ? `<span class="chip">auto</span>` : ""}
                </button>`).join("")}
            </div>` : ""}
            ${nodeAdj.in.length ? `
            <div class="hologram-inspector-section">
              <h5>${esc(t("holo_incoming_fk"))} (${nodeAdj.in.length})</h5>
              ${nodeAdj.in.map((r) => `
                <button type="button" class="hologram-fk-pill" data-holo-jump-table="${esc(r.source_table)}" title="${esc(r.source_table)}.${esc(r.source_col)} → ${esc(r.target_col)}">
                  <span class="mono"><b>${esc(r.source_table)}</b>.${esc(r.source_col)}</span>
                  ${r.inferred ? `<span class="chip">auto</span>` : ""}
                </button>`).join("")}
            </div>` : ""}
            ${(!nodeAdj.out.length && !nodeAdj.in.length) ? `<p class="muted" style="margin:0;">${esc(t("holo_no_relations"))}</p>` : ""}
          </div>
        </aside>`;
    }
    return "";
  }

  function hologramTab(tabObj) {
    const c = conn(tabObj.conn);
    if (tabObj.loading && !tabObj.data) {
      return `
        <div class="hologram-wrap">
          <div class="hologram-bar">
            <div class="hologram-title">${esc(c?.name || "")}<span class="sep">›</span><b>${esc(tabObj.db)}</b><span class="sep">›</span><span>${esc(t("holo_title"))}</span></div>
          </div>
          <div class="hologram-empty">
            <span class="spin-dot" style="width:32px;height:32px;"></span>
            <h3>${esc(t("db_loading"))}</h3>
            <p>${esc(t("holo_title"))}</p>
          </div>
        </div>`;
    }

    if (tabObj.error && !tabObj.data) {
      return `
        <div class="hologram-wrap">
          <div class="hologram-bar">
            <div class="hologram-title">${esc(c?.name || "")}<span class="sep">›</span><b>${esc(tabObj.db)}</b><span class="sep">›</span><span>${esc(t("holo_title"))}</span></div>
          </div>
          <div class="hologram-empty">
            ${icon("alert")}
            <h3>${esc(tabObj.error)}</h3>
            <button class="btn primary sm" data-holo="retry">${icon("refresh")} ${esc(t("db_refresh"))}</button>
          </div>
        </div>`;
    }

    const graph = buildHoloGraph(tabObj);
    const { tables, visibleRelations, adj, isolatedSet } = graph;
    const displayTables = tabObj.hideIsolated ? tables.filter((tb) => !isolatedSet.has(tb.name)) : tables;
    if (!tables.length) {
      return `
        <div class="hologram-wrap">
          <div class="hologram-bar">
            <div class="hologram-title">${esc(c?.name || "")}<span class="sep">›</span><b>${esc(tabObj.db)}</b><span class="sep">›</span><span>${esc(t("holo_title"))}</span></div>
          </div>
          <div class="hologram-empty">
            ${icon("database")}
            <h3>${esc(t("holo_empty_title"))}</h3>
            <p>${esc(t("holo_empty_desc"))}</p>
          </div>
        </div>`;
    }

    const filter = (tabObj.filter || "").toLowerCase().trim();
    const selRelObj = tabObj.selectedRel ? graph.allRels.find((r) => r.id === tabObj.selectedRel) : null;
    const focusSet = tabObj.selectedTable
      ? new Set([tabObj.selectedTable, ...(adj[tabObj.selectedTable]?.neighbors || [])])
      : selRelObj
        ? new Set([selRelObj.source_table, selRelObj.target_table])
        : null;
    const matchCount = filter
      ? displayTables.filter((tb) =>
          tb.name.toLowerCase().includes(filter) ||
          (tb.columns || []).some((col) => col.name.toLowerCase().includes(filter))
        ).length
      : displayTables.length;

    return `
      <div class="hologram-wrap" id="hologram-wrap-${tabObj.id}">
        <div class="hologram-bar">
          <div class="hologram-title">
            ${esc(c?.name || "")}<span class="sep">›</span><b>${esc(tabObj.db)}</b><span class="sep">›</span>
            <span>${icon("layers")} ${esc(t("holo_title"))}</span>
          </div>

          <div class="search sm" style="width:205px;">
            ${icon("search")}
            <input type="search" placeholder="${esc(t("holo_search_placeholder"))}" value="${esc(tabObj.filter || "")}" data-holo-search autocomplete="off">
          </div>
          ${filter ? `<span class="chip" data-holo-match-count>${matchCount} ${esc(t("holo_matches"))}</span>` : ""}

          <select class="sm" data-holo-layout title="${esc(t("holo_re_layout"))}">
            <option value="hierarchical" ${(tabObj.layoutMode || "hierarchical") === "hierarchical" ? "selected" : ""}>${esc(t("holo_layout_hierarchical"))}</option>
            <option value="grid" ${tabObj.layoutMode === "grid" ? "selected" : ""}>${esc(t("holo_layout_grid"))}</option>
          </select>

          <select class="sm" data-holo-edge-filter>
            <option value="all" ${(tabObj.edgeFilter || "all") === "all" ? "selected" : ""}>${esc(t("holo_filter_all"))}</option>
            <option value="explicit" ${tabObj.edgeFilter === "explicit" ? "selected" : ""}>${esc(t("holo_filter_explicit"))}</option>
          </select>

          <button type="button" class="btn sm ${tabObj.hideIsolated ? "active" : ""}" data-holo="toggle-isolated">
            ${esc(t("holo_filter_hide_isolated"))}
          </button>

          <button type="button" class="btn sm ${tabObj.compact ? "active" : ""}" data-holo="toggle-compact">
            ${icon("grid")} ${esc(tabObj.compact ? t("holo_cols_all") : t("holo_cols_keys"))}
          </button>

          <button type="button" class="btn sm" data-holo="autolayout" title="${esc(t("holo_re_layout"))}">
            ${icon("sparkles")} ${esc(t("holo_re_layout"))}
          </button>
          <button type="button" class="btn icon-btn sm" data-holo="reload" title="${esc(t("db_refresh"))}">
            ${icon("refresh")}
          </button>

          <span class="spacer"></span>

          <div class="btn-group">
            <button type="button" class="btn sm" data-holo="export-svg" title="${esc(t("holo_export_svg"))}">${icon("download")} ${esc(t("holo_export_svg"))}</button>
            <button type="button" class="btn sm" data-holo="export-png" title="${esc(t("holo_export_png"))}">${esc(t("holo_export_png"))}</button>
          </div>
        </div>

        <div class="hologram-viewport" id="holo-vp-${tabObj.id}">
          <div class="hologram-canvas" id="holo-canvas-${tabObj.id}" style="transform: translate(${tabObj.panX ?? 60}px, ${tabObj.panY ?? 60}px) scale(${tabObj.zoom || 1});">
            <svg class="hologram-svg-layer" id="holo-svg-${tabObj.id}">
              <defs>
                <marker id="holo-arrow" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="var(--accent)" />
                </marker>
                <marker id="holo-arrow-inferred" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#0ea5e9" />
                </marker>
              </defs>
              <g class="hologram-edges-group" id="holo-edges-${tabObj.id}"></g>
            </svg>

            <div class="hologram-nodes-layer" id="holo-nodes-${tabObj.id}">
              ${displayTables.map((tb) => {
                const pos = (tabObj.positions && tabObj.positions[tb.name]) || { x: 0, y: 0 };
                const cols = holoVisibleCols(tabObj, tb, visibleRelations);
                const tableTextMatch = !filter || tb.name.toLowerCase().includes(filter) || (tb.columns || []).some((col) => col.name.toLowerCase().includes(filter));
                const isSelected = tabObj.selectedTable === tb.name;
                const isNeighbor = !isSelected && focusSet && focusSet.has(tb.name);
                const isDimmed = !tableTextMatch || (focusSet && !focusSet.has(tb.name));
                return `
                  <div class="hologram-card ${isSelected ? "selected" : ""} ${isNeighbor ? "neighbor" : ""} ${isDimmed ? "dimmed" : ""}" id="holo-card-${tabObj.id}-${esc(tb.name)}"
                    data-table="${esc(tb.name)}"
                    style="transform: translate3d(${pos.x}px, ${pos.y}px, 0);">
                    <div class="hologram-card-head" data-card-drag="${esc(tb.name)}">
                      ${icon("grid")}
                      <span class="hologram-card-name" title="${esc(tb.name)}">${esc(tb.name)}</span>
                      ${tb.rows !== null && tb.rows !== undefined ? `<span class="hologram-card-badge">${fmtNum(tb.rows)}</span>` : ""}
                      <div class="hologram-card-actions">
                        <button type="button" class="btn ghost icon-btn xs" data-holo-action="model" data-table="${esc(tb.name)}" title="Model">${icon("code")}</button>
                        <button type="button" class="btn ghost icon-btn xs" data-holo-action="migration" data-table="${esc(tb.name)}" title="Migration">${icon("file")}</button>
                        <button type="button" class="btn ghost icon-btn xs" data-holo-action="seed" data-table="${esc(tb.name)}" title="Seed">${icon("zap")}</button>
                        <button type="button" class="btn ghost icon-btn xs" data-holo-action="data" data-table="${esc(tb.name)}" title="${esc(t("holo_open_table"))}">${icon("eye")}</button>
                      </div>
                    </div>
                    <div class="hologram-card-body">
                      ${cols.map((col) => {
                        const isFk = visibleRelations.some((r) => r.source_table === tb.name && r.source_col === col.name);
                        const isColMatch = Boolean(filter && col.name.toLowerCase().includes(filter));
                        const isRelHighlight = (selRelObj && ((selRelObj.source_table === tb.name && selRelObj.source_col === col.name) || (selRelObj.target_table === tb.name && selRelObj.target_col === col.name)));
                        return `
                          <div class="hologram-col-row ${col.pk ? "pk" : ""} ${isColMatch ? "col-match" : ""} ${isRelHighlight ? "highlighted" : ""}" data-col="${esc(col.name)}" data-table="${esc(tb.name)}">
                            <span class="hologram-port left" data-port="left" data-table="${esc(tb.name)}" data-col="${esc(col.name)}"></span>
                            ${col.pk ? `<span class="hologram-tag pk">PK</span>` : ""}
                            ${isFk ? `<span class="hologram-tag fk">FK</span>` : ""}
                            ${!col.pk && col.unique ? `<span class="hologram-tag uq">UQ</span>` : ""}
                            <span class="hologram-col-name" title="${esc(col.name)}">${esc(col.name)}</span>
                            <span class="hologram-col-type" title="${esc(col.type)}">${esc((col.type || "").split("(")[0])}</span>
                            <span class="hologram-port right" data-port="right" data-table="${esc(tb.name)}" data-col="${esc(col.name)}"></span>
                          </div>`;
                      }).join("")}
                    </div>
                  </div>`;
              }).join("")}
            </div>
          </div>

          ${hologramInspectorHtml(tabObj, graph)}

          ${tabObj.showLegend ? `
          <div class="hologram-legend-popover">
            <div class="hologram-legend-row"><span class="hologram-legend-line"></span><span>${esc(t("holo_explicit_fk"))}</span></div>
            <div class="hologram-legend-row"><span class="hologram-legend-line inferred"></span><span>${esc(t("holo_inferred_fk"))}</span></div>
            <div class="hologram-legend-row"><span class="hologram-tag pk">PK</span><span>Primary Key</span></div>
            <div class="hologram-legend-row"><span class="hologram-tag fk">FK</span><span>Foreign Key</span></div>
            <div class="hologram-legend-row"><span class="hologram-tag uq">UQ</span><span>Unique Index</span></div>
          </div>` : ""}

          ${tabObj.showMinimap !== false ? `<div class="hologram-minimap" id="holo-minimap-${tabObj.id}"></div>` : ""}

          <div class="hologram-stats-floating">
            <span><b>${displayTables.length}</b> ${esc(t("db_tables"))}</span>
            <span>·</span>
            <span><b>${visibleRelations.length}</b> links</span>
            ${isolatedSet.size ? `<span>· <b>${isolatedSet.size}</b> ${esc(t("holo_isolated_tables"))}</span>` : ""}
            ${(tabObj.selectedTable || tabObj.selectedRel) ? `<button type="button" class="btn ghost xs" data-holo="clear-focus">${icon("x")} ${esc(t("holo_clear_focus"))}</button>` : ""}
          </div>

          <div class="hologram-controls-floating">
            <button type="button" class="btn ghost icon-btn sm" data-holo="zoom-out" title="${esc(t("holo_zoom_out"))}">${icon("minus")}</button>
            <button type="button" class="btn ghost sm" data-holo="zoom-reset" data-holo-zoom-pct title="100%">${Math.round((tabObj.zoom || 1) * 100)}%</button>
            <button type="button" class="btn ghost icon-btn sm" data-holo="zoom-in" title="${esc(t("holo_zoom_in"))}">${icon("plus")}</button>
            <button type="button" class="btn ghost icon-btn sm" data-holo="fit" title="${esc(t("holo_fit"))}">${icon("maximize")}</button>
            <button type="button" class="btn ghost icon-btn sm ${tabObj.showMinimap !== false ? "active" : ""}" data-holo="toggle-minimap" title="${esc(t("holo_minimap"))}">${icon("map")}</button>
            <button type="button" class="btn ghost icon-btn sm ${tabObj.showLegend ? "active" : ""}" data-holo="toggle-legend" title="${esc(t("holo_legend"))}">${icon("info")}</button>
          </div>
        </div>
      </div>`;
  }

  function updateHoloMinimap(tabObj, root = document) {
    const mm = $(`#holo-minimap-${tabObj.id}`, root);
    const vp = $(`#holo-vp-${tabObj.id}`, root);
    if (!mm || !vp || !tabObj.data?.tables?.length) return;
    const { tables, isolatedSet } = buildHoloGraph(tabObj);
    const shown = tabObj.hideIsolated ? tables.filter((tb) => !isolatedSet.has(tb.name)) : tables;
    if (!shown.length) return;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    shown.forEach((tb) => {
      const p = tabObj.positions[tb.name] || { x: 0, y: 0 };
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x + 256);
      maxY = Math.max(maxY, p.y + 240);
    });
    const pad = 40;
    const vx = minX - pad;
    const vy = minY - pad;
    const vw = Math.max(400, maxX - minX + pad * 2);
    const vh = Math.max(300, maxY - minY + pad * 2);
    const rect = vp.getBoundingClientRect();
    const zoom = tabObj.zoom || 1;
    const panX = tabObj.panX ?? 60;
    const panY = tabObj.panY ?? 60;
    const camX = -panX / zoom;
    const camY = -panY / zoom;
    const camW = rect.width / zoom;
    const camH = rect.height / zoom;
    mm.dataset.vx = vx;
    mm.dataset.vy = vy;
    mm.dataset.vw = vw;
    mm.dataset.vh = vh;
    mm.innerHTML = `<svg viewBox="${vx} ${vy} ${vw} ${vh}" width="100%" height="100%" preserveAspectRatio="xMidYMid meet">
      ${shown.map((tb) => {
        const p = tabObj.positions[tb.name] || { x: 0, y: 0 };
        const active = tabObj.selectedTable === tb.name;
        return `<rect x="${p.x}" y="${p.y}" width="256" height="140" rx="14" fill="${active ? "var(--accent)" : "var(--border-strong)"}" opacity="${active ? "0.9" : "0.5"}"/>`;
      }).join("")}
      <rect x="${camX}" y="${camY}" width="${camW}" height="${camH}" fill="var(--accent)" fill-opacity="0.1" stroke="var(--accent)" stroke-width="${Math.max(8, vw * 0.008)}"/>
    </svg>`;
  }

  function holoAnchorY(tabObj, tableName, colName, cardEl) {
    const pos = tabObj.positions[tableName] || { x: 0, y: 0 };
    if (!cardEl) return pos.y + 38;
    const head = $(".hologram-card-head", cardEl);
    const body = $(".hologram-card-body", cardEl);
    const row = $(`[data-col="${CSS.escape(colName)}"]`, cardEl);
    if (!row || !body) return pos.y + (head ? head.offsetHeight / 2 : 20);
    const headH = head ? head.offsetHeight : 34;
    const rawRelY = row.offsetTop - body.scrollTop + (row.offsetHeight / 2 || 11);
    const clampedRelY = Math.max(headH + 4, Math.min(headH + body.clientHeight - 4, rawRelY));
    return pos.y + clampedRelY;
  }

  function drawHologramEdges(tabObj, root) {
    const svgGroup = $("#holo-edges-" + tabObj.id, root);
    if (!svgGroup || !tabObj.data || !tabObj.data.relations) return;
    const { visibleRelations, isolatedSet } = buildHoloGraph(tabObj);
    const filter = (tabObj.filter || "").toLowerCase().trim();
    const cardWidth = 256;

    let pathsHtml = "";
    visibleRelations.forEach((rel) => {
      if (tabObj.hideIsolated && (isolatedSet.has(rel.source_table) || isolatedSet.has(rel.target_table))) return;
      const sp = tabObj.positions[rel.source_table];
      const tp = tabObj.positions[rel.target_table];
      if (!sp || !tp) return;

      const sourceCard = $(`#holo-card-${tabObj.id}-${CSS.escape(rel.source_table)}`, root);
      const targetCard = $(`#holo-card-${tabObj.id}-${CSS.escape(rel.target_table)}`, root);

      const sy = holoAnchorY(tabObj, rel.source_table, rel.source_col, sourceCard);
      const ty = holoAnchorY(tabObj, rel.target_table, rel.target_col, targetCard);

      let sx, tx, c1x, c1y, c2x, c2y;
      if (rel.source_table === rel.target_table) {
        sx = sp.x + cardWidth;
        tx = tp.x + cardWidth;
        c1x = sx + 64;
        c1y = sy - 24;
        c2x = tx + 64;
        c2y = ty + 24;
      } else {
        const isRight = tp.x >= sp.x;
        sx = isRight ? sp.x + cardWidth : sp.x;
        tx = isRight ? tp.x : tp.x + cardWidth;
        const dx = Math.max(52, Math.abs(tx - sx) * 0.45);
        c1x = sx + (isRight ? dx : -dx);
        c1y = sy;
        c2x = tx + (isRight ? -dx : dx);
        c2y = ty;
      }
      const d = `M ${sx} ${sy} C ${c1x} ${c1y}, ${c2x} ${c2y}, ${tx} ${ty}`;

      const matchFilter = !filter
        || rel.source_table.toLowerCase().includes(filter)
        || rel.target_table.toLowerCase().includes(filter)
        || rel.source_col.toLowerCase().includes(filter)
        || rel.target_col.toLowerCase().includes(filter);
      const isSelectedEdge = tabObj.selectedRel === rel.id;
      const isFocusedByTable = tabObj.selectedTable && (rel.source_table === tabObj.selectedTable || rel.target_table === tabObj.selectedTable);
      const hasFocus = Boolean(tabObj.selectedTable || tabObj.selectedRel);
      const isHover = tabObj.hoverRel === rel.id || (tabObj.hoverTable && (rel.source_table === tabObj.hoverTable || rel.target_table === tabObj.hoverTable));

      const isDimmed = !matchFilter || (hasFocus && !isSelectedEdge && !isFocusedByTable && !isHover);
      const cls = ["hologram-edge"];
      if (rel.inferred) cls.push("inferred");
      if (isDimmed) cls.push("dimmed");
      if (isSelectedEdge) cls.push("selected");
      else if (isFocusedByTable || isHover) cls.push("highlighted");

      const marker = rel.inferred ? "url(#holo-arrow-inferred)" : "url(#holo-arrow)";
      const title = `${esc(rel.source_table)}.${esc(rel.source_col)} → ${esc(rel.target_table)}.${esc(rel.target_col)}${rel.on_delete ? ` (ON DELETE ${esc(rel.on_delete)})` : ""}${rel.inferred ? " [Auto]" : ""}`;

      pathsHtml += `<path d="${d}" class="hologram-edge-hit" data-rel-hit="${esc(rel.id)}"><title>${title}</title></path>`;
      pathsHtml += `<path d="${d}" class="${cls.join(" ")}" data-rel="${esc(rel.id)}" marker-end="${marker}"><title>${title}</title></path>`;

      if (isSelectedEdge || isFocusedByTable || isHover) {
        const mx = 0.125 * sx + 0.375 * c1x + 0.375 * c2x + 0.125 * tx;
        const my = 0.125 * sy + 0.375 * c1y + 0.375 * c2y + 0.125 * ty;
        const lbl = `${rel.source_col} → ${rel.target_col}`;
        const bw = Math.min(200, Math.max(66, lbl.length * 6.4 + 14));
        pathsHtml += `<g style="pointer-events:none;">
          <rect x="${mx - bw / 2}" y="${my - 10}" width="${bw}" height="18" class="hologram-edge-label-bg"/>
          <text x="${mx}" y="${my + 3}" text-anchor="middle" class="hologram-edge-label-text">${esc(lbl)}</text>
        </g>`;
      }
    });

    svgGroup.innerHTML = pathsHtml;
    updateHoloMinimap(tabObj, root);
  }

  function updateHologramTransform(tabObj) {
    const canvas = $(`#holo-canvas-${tabObj.id}`);
    if (canvas) {
      canvas.style.transform = `translate(${tabObj.panX ?? 60}px, ${tabObj.panY ?? 60}px) scale(${tabObj.zoom || 1})`;
    }
    const zoomBtn = $(`[data-holo-zoom-pct]`);
    if (zoomBtn) zoomBtn.textContent = `${Math.round((tabObj.zoom || 1) * 100)}%`;
    updateHoloMinimap(tabObj);
  }

  function fitHologram(tabObj) {
    if (!tabObj.data || !tabObj.data.tables || !tabObj.data.tables.length) return;
    const vp = $(`#holo-vp-${tabObj.id}`);
    if (!vp) return;
    const { tables, isolatedSet } = buildHoloGraph(tabObj);
    const shown = tabObj.hideIsolated ? tables.filter((tb) => !isolatedSet.has(tb.name)) : tables;
    if (!shown.length) return;
    const rect = vp.getBoundingClientRect();
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    shown.forEach((tb) => {
      const p = tabObj.positions[tb.name] || { x: 0, y: 0 };
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x + 256);
      maxY = Math.max(maxY, p.y + 240);
    });
    const padding = 60;
    const w = (maxX - minX) + padding * 2;
    const h = (maxY - minY) + padding * 2;
    const scaleX = rect.width / w;
    const scaleY = rect.height / h;
    tabObj.zoom = Math.min(1.2, Math.max(0.25, Math.min(scaleX, scaleY)));
    tabObj.panX = (rect.width - (maxX - minX) * tabObj.zoom) / 2 - minX * tabObj.zoom;
    tabObj.panY = (rect.height - (maxY - minY) * tabObj.zoom) / 2 - minY * tabObj.zoom;
    updateHologramTransform(tabObj);
  }

  function bindHologramEvents(tabObj, root) {
    const vp = $(`#holo-vp-${tabObj.id}`, root);
    const canvas = $(`#holo-canvas-${tabObj.id}`, root);
    if (!vp || !canvas) return;

    drawHologramEdges(tabObj, root);

    // Card Dragging + click-to-focus selection (only if not dragged > 4px)
    $$("[data-card-drag]", root).forEach((head) => {
      head.addEventListener("mousedown", (e) => {
        if (e.target.closest("button")) return;
        e.stopPropagation();
        const tableName = head.dataset.cardDrag;
        const card = $(`#holo-card-${tabObj.id}-${CSS.escape(tableName)}`, root);
        if (!card) return;
        const startX = e.clientX, startY = e.clientY;
        const orig = { ...(tabObj.positions[tableName] || { x: 0, y: 0 }) };
        let moved = 0;

        function onMove(ev) {
          moved = Math.max(moved, Math.abs(ev.clientX - startX), Math.abs(ev.clientY - startY));
          const dx = (ev.clientX - startX) / (tabObj.zoom || 1);
          const dy = (ev.clientY - startY) / (tabObj.zoom || 1);
          tabObj.positions[tableName] = { x: Math.round(orig.x + dx), y: Math.round(orig.y + dy) };
          card.style.transform = `translate3d(${tabObj.positions[tableName].x}px, ${tabObj.positions[tableName].y}px, 0)`;
          drawHologramEdges(tabObj, root);
        }

        function onUp() {
          window.removeEventListener("mousemove", onMove);
          window.removeEventListener("mouseup", onUp);
          if (moved <= 4) {
            tabObj.selectedTable = tabObj.selectedTable === tableName ? null : tableName;
            tabObj.selectedRel = null;
            renderMain();
          } else {
            try { localStorage.setItem(`ld_holo_${tabObj.conn}_${tabObj.db}`, JSON.stringify(tabObj.positions)); } catch {}
          }
        }

        window.addEventListener("mousemove", onMove);
        window.addEventListener("mouseup", onUp);
      });
    });

    // Clicking inside card body selects card too (without interfering with scrolling or buttons)
    $$(".hologram-card-body", root).forEach((body) => {
      let rafId = null;
      body.addEventListener("scroll", () => {
        if (rafId) return;
        rafId = requestAnimationFrame(() => {
          rafId = null;
          drawHologramEdges(tabObj, root);
        });
      });
      body.addEventListener("click", (e) => {
        if (e.target.closest("button")) return;
        const card = body.closest(".hologram-card");
        if (!card) return;
        tabObj.selectedTable = card.dataset.table;
        tabObj.selectedRel = null;
        renderMain();
      });
    });

    // Edge click & hover delegation inside SVG layer
    const svgLayer = $(`#holo-svg-${tabObj.id}`, root);
    if (svgLayer) {
      svgLayer.addEventListener("click", (e) => {
        const hit = e.target.closest("[data-rel-hit], [data-rel]");
        if (!hit) return;
        e.stopPropagation();
        const relId = hit.dataset.relHit || hit.dataset.rel;
        tabObj.selectedRel = tabObj.selectedRel === relId ? null : relId;
        tabObj.selectedTable = null;
        renderMain();
      });
      svgLayer.addEventListener("mouseover", (e) => {
        const hit = e.target.closest("[data-rel-hit], [data-rel]");
        const nextHover = hit ? (hit.dataset.relHit || hit.dataset.rel) : null;
        if (nextHover !== tabObj.hoverRel) {
          tabObj.hoverRel = nextHover;
          drawHologramEdges(tabObj, root);
        }
      });
      svgLayer.addEventListener("mouseout", (e) => {
        if (!e.relatedTarget || !svgLayer.contains(e.relatedTarget)) {
          if (tabObj.hoverRel) {
            tabObj.hoverRel = null;
            drawHologramEdges(tabObj, root);
          }
        }
      });
    }

    // Canvas Panning + click-empty to clear selection
    vp.addEventListener("mousedown", (e) => {
      if (e.target.closest(".hologram-card, .hologram-inspector, .hologram-minimap, .hologram-controls-floating, .hologram-stats-floating, .hologram-legend-popover, button, input, select, [data-rel-hit], [data-rel]")) return;
      vp.classList.add("panning");
      const startX = e.clientX, startY = e.clientY;
      const startPanX = tabObj.panX ?? 60, startPanY = tabObj.panY ?? 60;
      let moved = 0;

      function onMove(ev) {
        moved = Math.max(moved, Math.abs(ev.clientX - startX), Math.abs(ev.clientY - startY));
        tabObj.panX = startPanX + (ev.clientX - startX);
        tabObj.panY = startPanY + (ev.clientY - startY);
        updateHologramTransform(tabObj);
      }

      function onUp() {
        vp.classList.remove("panning");
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
        if (moved <= 3 && (tabObj.selectedTable || tabObj.selectedRel)) {
          tabObj.selectedTable = null;
          tabObj.selectedRel = null;
          renderMain();
        }
      }

      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    });

    // Canvas Zooming with mouse wheel
    vp.addEventListener("wheel", (e) => {
      e.preventDefault();
      const factor = e.deltaY < 0 ? 1.08 : 0.92;
      const newZoom = Math.min(Math.max((tabObj.zoom || 1) * factor, 0.25), 2.5);
      const rect = vp.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;
      tabObj.panX = mouseX - (mouseX - (tabObj.panX ?? 60)) * (newZoom / (tabObj.zoom || 1));
      tabObj.panY = mouseY - (mouseY - (tabObj.panY ?? 60)) * (newZoom / (tabObj.zoom || 1));
      tabObj.zoom = newZoom;
      updateHologramTransform(tabObj);
    }, { passive: false });

    // Minimap click-to-pan
    const mm = $(`#holo-minimap-${tabObj.id}`, root);
    if (mm) {
      const panToMinimapEvent = (ev) => {
        const box = mm.getBoundingClientRect();
        const vx = Number(mm.dataset.vx || 0);
        const vy = Number(mm.dataset.vy || 0);
        const vw = Number(mm.dataset.vw || 1000);
        const vh = Number(mm.dataset.vh || 600);
        const rx = Math.max(0, Math.min(1, (ev.clientX - box.left) / box.width));
        const ry = Math.max(0, Math.min(1, (ev.clientY - box.top) / box.height));
        const worldX = vx + rx * vw;
        const worldY = vy + ry * vh;
        const vpRect = vp.getBoundingClientRect();
        const z = tabObj.zoom || 1;
        tabObj.panX = vpRect.width / 2 - worldX * z;
        tabObj.panY = vpRect.height / 2 - worldY * z;
        updateHologramTransform(tabObj);
      };
      mm.addEventListener("mousedown", (e) => {
        e.stopPropagation();
        panToMinimapEvent(e);
        const onMmMove = (ev) => panToMinimapEvent(ev);
        const onMmUp = () => {
          window.removeEventListener("mousemove", onMmMove);
          window.removeEventListener("mouseup", onMmUp);
        };
        window.addEventListener("mousemove", onMmMove);
        window.addEventListener("mouseup", onMmUp);
      });
    }

    // Table Hover Highlighting
    $$(".hologram-card", root).forEach((card) => {
      card.addEventListener("mouseenter", () => {
        tabObj.hoverTable = card.dataset.table;
        card.classList.add("highlighted");
        drawHologramEdges(tabObj, root);
      });
      card.addEventListener("mouseleave", () => {
        tabObj.hoverTable = null;
        card.classList.remove("highlighted");
        drawHologramEdges(tabObj, root);
      });
    });

    // Live Search across table names & column names
    const searchInput = $("[data-holo-search]", root);
    if (searchInput) {
      searchInput.addEventListener("input", (e) => {
        tabObj.filter = e.target.value;
        const val = tabObj.filter.toLowerCase().trim();
        let matched = 0;
        $$(".hologram-card", root).forEach((card) => {
          const tableMatch = card.dataset.table.toLowerCase().includes(val);
          let anyColMatch = false;
          $$(".hologram-col-row", card).forEach((row) => {
            const colMatch = Boolean(val && row.dataset.col.toLowerCase().includes(val));
            row.classList.toggle("col-match", colMatch);
            if (colMatch) anyColMatch = true;
          });
          const hit = !val || tableMatch || anyColMatch;
          if (hit) matched++;
          card.classList.toggle("dimmed", !hit);
        });
        const badge = $("[data-holo-match-count]", root);
        if (badge) badge.textContent = `${matched} ${t("holo_matches")}`;
        drawHologramEdges(tabObj, root);
      });
    }

    // Toolbar dropdowns (layout & edge filter)
    $("[data-holo-layout]", root)?.addEventListener("change", (e) => {
      tabObj.layoutMode = e.target.value;
      autoLayout(tabObj, true);
      renderMain();
    });
    $("[data-holo-edge-filter]", root)?.addEventListener("change", (e) => {
      tabObj.edgeFilter = e.target.value;
      renderMain();
    });
  }

  function exportHologramSvg(tabObj, { asPng = false } = {}) {
    if (!tabObj.data || !tabObj.data.tables) return;
    const { tables, visibleRelations, isolatedSet } = buildHoloGraph(tabObj);
    const exportTables = tabObj.hideIsolated ? tables.filter((tb) => !isolatedSet.has(tb.name)) : tables;
    if (!exportTables.length) return;
    const cardW = 256;
    const headerH = 34;
    const rowH = 22;

    const cardMetrics = {};
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    exportTables.forEach((tb) => {
      const p = tabObj.positions[tb.name] || { x: 0, y: 0 };
      const cols = holoVisibleCols(tabObj, tb, visibleRelations);
      const h = headerH + Math.max(1, cols.length) * rowH + 10;
      const colY = {};
      cols.forEach((col, i) => { colY[col.name] = p.y + headerH + 6 + i * rowH + rowH / 2; });
      cardMetrics[tb.name] = { x: p.x, y: p.y, h, cols, colY };
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x + cardW);
      maxY = Math.max(maxY, p.y + h);
    });
    const padding = 50;
    const width = Math.max(600, (maxX - minX) + padding * 2);
    const height = Math.max(400, (maxY - minY) + padding * 2);
    const offsetX = padding - minX;
    const offsetY = padding - minY;

    let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">\n`;
    svg += `<style>
      .bg { fill: #18181b; }
      .card { fill: #27272a; stroke: #3f3f46; stroke-width: 1; rx: 8; }
      .card-hd { fill: #202024; }
      .head { font-family: sans-serif; font-weight: bold; font-size: 13px; fill: #f4f4f5; }
      .col { font-family: monospace; font-size: 11px; fill: #d4d4d8; }
      .col-pk { font-weight: bold; fill: #fbbf24; }
      .col-fk { fill: #60a5fa; }
      .edge { fill: none; stroke: #3b82f6; stroke-width: 2; opacity: 0.85; }
      .edge-inf { fill: none; stroke: #0ea5e9; stroke-width: 2; stroke-dasharray: 5 4; opacity: 0.85; }
    </style>\n`;
    svg += `<rect width="100%" height="100%" class="bg"/>\n`;

    visibleRelations.forEach((r) => {
      const sm = cardMetrics[r.source_table];
      const tm = cardMetrics[r.target_table];
      if (!sm || !tm) return;
      const sy = (sm.colY[r.source_col] ?? (sm.y + headerH / 2)) + offsetY;
      const ty = (tm.colY[r.target_col] ?? (tm.y + headerH / 2)) + offsetY;
      const isRight = tm.x >= sm.x;
      const x1 = sm.x + offsetX + (isRight ? cardW : 0);
      const x2 = tm.x + offsetX + (isRight ? 0 : cardW);
      const dx = Math.max(48, Math.abs(x2 - x1) * 0.45);
      const cls = r.inferred ? "edge-inf" : "edge";
      svg += `<path d="M ${x1} ${sy} C ${x1 + (isRight ? dx : -dx)} ${sy}, ${x2 + (isRight ? -dx : dx)} ${ty}, ${x2} ${ty}" class="${cls}"/>\n`;
    });

    exportTables.forEach((tb) => {
      const m = cardMetrics[tb.name];
      const x = m.x + offsetX;
      const y = m.y + offsetY;
      svg += `<rect x="${x}" y="${y}" width="${cardW}" height="${m.h}" class="card"/>\n`;
      svg += `<text x="${x + 12}" y="${y + 22}" class="head">${esc(tb.name)}</text>\n`;
      m.cols.forEach((col, i) => {
        const cy = y + headerH + 6 + i * rowH + 14;
        const isFk = visibleRelations.some((r) => r.source_table === tb.name && r.source_col === col.name);
        const cls = col.pk ? "col col-pk" : isFk ? "col col-fk" : "col";
        const prefix = col.pk ? "[PK] " : isFk ? "[FK] " : col.unique ? "[UQ] " : "     ";
        svg += `<text x="${x + 10}" y="${cy}" class="${cls}">${prefix}${esc(col.name)} (${esc((col.type || "").split("(")[0])})</text>\n`;
      });
    });

    svg += `</svg>`;
    if (!asPng) {
      const blob = new Blob([svg], { type: "image/svg+xml" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `hologram_${tabObj.db}_schema.svg`;
      a.click();
      URL.revokeObjectURL(url);
      toast("success", "Schema Exported", `Saved hologram_${tabObj.db}_schema.svg`);
      return;
    }

    const svgBlob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(2, 4096 / Math.max(width, height));
      const c = document.createElement("canvas");
      c.width = Math.round(width * scale);
      c.height = Math.round(height * scale);
      const ctx = c.getContext("2d");
      ctx.scale(scale, scale);
      ctx.drawImage(img, 0, 0);
      URL.revokeObjectURL(url);
      c.toBlob((pngBlob) => {
        if (!pngBlob) return toast("error", "PNG export failed");
        const pngUrl = URL.createObjectURL(pngBlob);
        const a = document.createElement("a");
        a.href = pngUrl;
        a.download = `hologram_${tabObj.db}_schema.png`;
        a.click();
        URL.revokeObjectURL(pngUrl);
        toast("success", "Schema Exported", `Saved hologram_${tabObj.db}_schema.png`);
      }, "image/png");
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      toast("error", "PNG export failed");
    };
    img.src = url;
  }

  function exportHologramPng(tabObj) {
    exportHologramSvg(tabObj, { asPng: true });
  }

  async function testConnAction(c) {
    toast("info", `Testing ${c.name}…`);
    try {
      const res = await LD.call("db_test", { id: c.id, existing: true });
      let details = `${res.version} · ${res.ms} ms`;
      if (res.ssh) details = `SSH (${res.ssh.ms}ms) + DB (${res.ms}ms)`;
      toast("success", `Connected to ${c.name}`, details);
    } catch (err) {
      toast("error", `Connection to ${c.name} failed`, err.message);
    }
  }

  /* ── context menu ───────────────────────────────────────── */
  function showMenu(x, y, items) {
    hideMenu();
    menuEl = document.createElement("div");
    menuEl.className = "ctx-menu";
    menuEl.innerHTML = items.map((it, i) => it === "-" ? `<hr>` : `<button data-mi="${i}" class="${it.danger ? "danger" : ""}" ${it.disabled ? "disabled" : ""}>${it.icon ? icon(it.icon) : ""}${esc(it.label)}</button>`).join("");
    document.body.append(menuEl);
    const rect = menuEl.getBoundingClientRect();
    menuEl.style.left = `${Math.min(x, innerWidth - rect.width - 8)}px`;
    menuEl.style.top = `${Math.min(y, innerHeight - rect.height - 8)}px`;
    menuEl.addEventListener("click", (e) => {
      const b = e.target.closest("[data-mi]");
      if (!b) return;
      const item = items[+b.dataset.mi];
      hideMenu();
      item.run();
    });
  }
  function hideMenu() { menuEl?.remove(); menuEl = null; }

  function connMenu(c) {
    const node = S.tree[c.id];
    return [
      { label: node?.open ? "Refresh" : "Connect", icon: "refresh", run: () => openConn(c.id) },
      { label: "Test connection…", icon: "pulse", run: () => testConnAction(c) },
      { label: "New query", icon: "terminal", run: () => openTab({ kind: "query", conn: c.id, db: c.database || node?.default || (c.driver === "sqlite" ? "main" : "") }) },
      ...(c.driver !== "sqlite" ? [{ label: "New database…", icon: "plus", run: () => createDbModal(c) }] : []),
      "-",
      ...(c.source === "saved" ? [{ label: "Edit connection…", icon: "edit", run: () => connModal(c) }] : []),
      ...(c.source === "site" ? [{ label: "Edit project .env", icon: "file", run: () => { setView("sites"); openDrawer(c.site, "env"); } }] : []),
      ...(c.source !== "saved" ? [{ label: "Save as connection…", icon: "plus", run: () => connModal({ ...c, id: undefined, name: `${c.name} copy`, source: "saved" }) }] : []),
      { label: "Disconnect", icon: "power", disabled: !c.open, run: async () => {
        await LD.call("db_close", { id: c.id });
        c.open = false;
        if (S.tree[c.id]) S.tree[c.id].open = false;
        renderTree();
      } },
    ];
  }

  function dbMenu(c, db) {
    return [
      { label: "Open", icon: "database", run: () => openTab({ kind: "db", conn: c.id, db }) },
      { label: "Hologram (ERD)…", icon: "layers", run: () => openHologram(c.id, db) },
      { label: "Compare with… (Schema Diff)", icon: "layers", run: () => openDiffTab({ srcConn: c.id, srcDb: db }) },
      { label: "New query", icon: "terminal", run: () => openTab({ kind: "query", conn: c.id, db }) },
      { label: "Refresh", icon: "refresh", run: () => openDb(c.id, db, true) },
      "-",
      { label: "Export as SQL…", icon: "download", run: () => exportData(c.id, db, [], "sql") },
      { label: "Import .sql file…", icon: "upload", run: () => importSql(c.id, db) },
      ...(c.driver !== "sqlite" ? ["-", { label: "Drop database…", icon: "trash", danger: true, run: () => dropDb(c, db) }] : []),
    ];
  }

  function tableMenu(c, db, table) {
    const meta = S.tree[c.id]?.dbs[db]?.tables?.find((t) => t.name === table) || {};
    return [
      { label: "Open", icon: "grid", run: () => openTab({ kind: "table", conn: c.id, db, table }) },
      { label: "Filter Table…", icon: "filter", run: () => openTab({ kind: "table", conn: c.id, db, table, showFilters: true }) },
      { label: "Structure", icon: "layers", run: () => { openTab({ kind: "table", conn: c.id, db, table }); tab().sub = "structure"; renderMain(); } },
      { label: "Query this table", icon: "terminal", run: () => openTab({ kind: "query", conn: c.id, db, sql: `SELECT * FROM ${q(c.driver, table)} LIMIT 100;` }) },
      "-",
      { label: "Generate Eloquent Model…", icon: "code", run: () => openModelModal(c.id, db, table) },
      { label: "Generate Migration…", icon: "file", run: () => openMigrationModal(c.id, db, table) },
      { label: "Seed Dummy Data…", icon: "zap", run: () => openSeedModal(c.id, db, table) },
      "-",
      { label: "Export as SQL…", icon: "download", run: () => exportData(c.id, db, [table], "sql") },
      { label: "Export as CSV…", icon: "download", run: () => exportData(c.id, db, [table], "csv") },
      { label: "Export as JSON…", icon: "download", run: () => exportData(c.id, db, [table], "json") },
      "-",
      { label: "Rename…", icon: "rename", run: () => renameTable(c, db, table) },
      ...(meta.view ? [] : [{ label: "Empty table…", icon: "x", danger: true, run: () => tableOp(c, db, table, "truncate") }]),
      { label: `Drop ${meta.view ? "view" : "table"}…`, icon: "trash", danger: true, run: () => tableOp(c, db, table, "drop") },
    ];
  }

  function cellMenu(t, ri, colIndex) {
    const d = t.data;
    const col = d.columns[colIndex];
    const row = d.rows[ri];
    const value = (t.edits.get(ri) || {})[col.name] ?? row[colIndex];
    const asObject = Object.fromEntries(d.columns.filter((c) => !c.hidden).map((c) => [c.name, row[d.columns.indexOf(c)]]));
    return [
      { label: "Copy value", icon: "copy", run: () => copyText(value === null ? "NULL" : String(value)) },
      { label: "Copy row as JSON", icon: "copy", run: () => copyText(JSON.stringify(asObject, null, 2)) },
      { label: "Copy row as INSERT", icon: "copy", run: () => {
        const cols = Object.keys(asObject);
        const vals = Object.values(asObject).map((v) => v === null ? "NULL" : typeof v === "number" ? v : `'${String(v).replace(/'/g, "''")}'`);
        copyText(`INSERT INTO ${q(conn(t.conn).driver, t.table)} (${cols.map((c) => q(conn(t.conn).driver, c)).join(", ")}) VALUES (${vals.join(", ")});`);
      } },
      "-",
      { label: `Filter: ${col.name} = this`, icon: "filter", run: () => {
        t.filters = t.filters || [];
        t.filters.push({ column: col.name, op: value === null ? "IS NULL" : "=", value: value === null ? "" : value });
        t.showFilters = true;
        loadRows(t, { keepPage: false });
      } },
      { label: `Filter: ${col.name} != this`, icon: "filter", run: () => {
        t.filters = t.filters || [];
        t.filters.push({ column: col.name, op: value === null ? "IS NOT NULL" : "!=", value: value === null ? "" : value });
        t.showFilters = true;
        loadRows(t, { keepPage: false });
      } },
      ...(d.view ? [] : [
        { label: "Set NULL", icon: "x", disabled: !col.nullable || col.binary, run: () => { setCell(t, false, ri, col.name, null); renderMain(); } },
        { label: t.deletes.has(ri) ? "Restore row" : "Delete row", icon: "trash", danger: !t.deletes.has(ri), run: () => {
          t.deletes.has(ri) ? t.deletes.delete(ri) : t.deletes.add(ri);
          renderTabs(); renderMain();
        } },
      ]),
    ];
  }

  /* ── operations ─────────────────────────────────────────── */
  function exportData(connId, db, tables, format) {
    LD.call("db_export", { conn: connId, database: db, tables, format }).then((started) => {
      if (started) toast("success", "Export started", "You'll get a message when it's done.");
    }).catch((err) => toast("error", "Export failed", err.message));
  }

  async function importSql(connId, db) {
    if (!(await confirmModal({ title: `Import into ${db}?`, message: `Statements in the file run against <b>${esc(db)}</b> on ${esc(conn(connId)?.name)}. Dumps usually drop and recreate their tables.`, confirm: "Choose file…" }))) return;
    LD.call("db_import", { conn: connId, database: db }).then((started) => {
      if (started) toast("success", "Import started");
    }).catch((err) => toast("error", "Import failed", err.message));
  }

  async function openSnapshotsModal(connId, dbName) {
    const c = conn(connId);
    const siteName = c?.site_name || c?.name || dbName;

    openModal(`
      <div class="modal" style="max-width:720px">
        <div class="modal-header">
          <h2>${icon("camera")} Database Snapshots · ${esc(dbName)}</h2>
          <p>Instant database snapshots for rapid testing, migration rollbacks, and schema experimentation.</p>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <div style="display:flex;gap:8px;align-items:center;background:var(--surface-2);padding:10px;border-radius:6px">
            <input type="text" id="snap-new-name" placeholder="Snapshot name (e.g. before-migrate)" class="input sm" style="flex:1">
            <input type="text" id="snap-new-desc" placeholder="Optional description" class="input sm" style="flex:1">
            <button class="btn sm primary" id="btn-create-snap">${icon("camera")} Take Snapshot</button>
          </div>
          <div id="snapshots-list-pane" style="max-height:50vh;overflow-y:auto">
            <div class="loading-pane sm">${icon("pulse")} Loading snapshots…</div>
          </div>
        </div>
        <div class="modal-footer"><button type="button" class="btn" data-dismiss>Close</button></div>
      </div>`, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      async function refreshSnaps() {
        const pane = $("#snapshots-list-pane", root);
        if (!pane) return;
        pane.innerHTML = `<div class="loading-pane sm">${icon("pulse")} Loading snapshots…</div>`;
        try {
          const res = await LD.call("db_snapshots_list", { name: siteName });
          const snaps = res.snapshots || [];
          if (!snaps.length) {
            pane.innerHTML = `<div class="muted sm" style="padding:24px;text-align:center">No snapshots saved for this project yet. Take one above!</div>`;
            return;
          }
          pane.innerHTML = `
            <div class="routes-table-wrap">
              <table class="routes-table" style="font-size:12px">
                <thead><tr><th>Name</th><th>Created</th><th>Tables</th><th>Size</th><th>Actions</th></tr></thead>
                <tbody>
                  ${snaps.map((s) => `
                    <tr>
                      <td>
                        <b style="font-size:12.5px">${esc(s.name)}</b>
                        ${s.description ? `<div class="muted xs">${esc(s.description)}</div>` : ""}
                        ${s.git_commit ? `<span class="chip xs" style="font-family:var(--mono)">git: ${esc(s.git_commit)}</span>` : ""}
                      </td>
                      <td><span class="muted" style="font-size:11px">${new Date(s.created_at).toLocaleString()}</span></td>
                      <td><span class="chip sm">${s.tables_count || "—"}</span></td>
                      <td><span class="mono" style="font-size:11.5px">${fmtBytes(s.size_bytes || 0)}</span></td>
                      <td style="white-space:nowrap">
                        <button class="btn xs primary" data-restore-snap="${esc(s.id)}">${icon("refresh")} Restore</button>
                        <button class="btn xs ghost danger" data-del-snap="${esc(s.id)}">${icon("trash")}</button>
                      </td>
                    </tr>
                  `).join("")}
                </tbody>
              </table>
            </div>
          `;

          $$("[data-restore-snap]", pane).forEach((btn) => {
            btn.addEventListener("click", async () => {
              const sid = btn.dataset.restoreSnap;
              if (!(await confirmModal({ title: "Restore database snapshot?", message: "This will overwrite current database state with this snapshot.", confirm: "Restore", danger: true }))) return;
              btn.disabled = true;
              btn.innerHTML = `${icon("pulse")} Restoring…`;
              try {
                const r = await LD.call("db_snapshot_restore", { name: siteName, snapshot_id: sid });
                if (r.ok) {
                  toast("success", "Database restored from snapshot");
                  closeModal();
                  openDb(connId, dbName, true);
                } else {
                  toast("error", "Restore failed", r.error);
                }
              } catch (err) {
                toast("error", "Restore failed", err.message);
              }
            });
          });

          $$("[data-del-snap]", pane).forEach((btn) => {
            btn.addEventListener("click", async () => {
              const sid = btn.dataset.delSnap;
              await LD.call("db_snapshot_delete", { name: siteName, snapshot_id: sid });
              toast("success", "Snapshot deleted");
              refreshSnaps();
            });
          });
        } catch (err) {
          pane.innerHTML = `<div style="padding:16px;color:var(--red)">Failed to load snapshots: ${esc(err.message)}</div>`;
        }
      }

      $("#btn-create-snap", root)?.addEventListener("click", async () => {
        const nameInput = $("#snap-new-name", root);
        const descInput = $("#snap-new-desc", root);
        const sName = nameInput.value.trim() || "snapshot";
        const btn = $("#btn-create-snap", root);
        btn.disabled = true;
        btn.innerHTML = `${icon("pulse")} Saving…`;
        try {
          const res = await LD.call("db_snapshot_create", { name: siteName, snapshot_name: sName, description: descInput.value.trim() });
          if (res.ok) {
            toast("success", "Snapshot created successfully");
            nameInput.value = "";
            descInput.value = "";
            refreshSnaps();
          } else {
            toast("error", "Failed to create snapshot", res.error);
          }
        } catch (err) {
          toast("error", "Failed to create snapshot", err.message);
        } finally {
          btn.disabled = false;
          btn.innerHTML = `${icon("camera")} Take Snapshot`;
        }
      });

      refreshSnaps();
    });
  }

  function createDbModal(c) {
    openModal(`
      <form class="modal sm" id="newdb-form">
        <div class="modal-header"><h2>New database</h2><p>On ${esc(c.name)}</p></div>
        <div class="modal-body">
          <label class="field"><span>Name</span><input name="name" placeholder="shop" spellcheck="false" autocomplete="off"></label>
          ${c.driver !== "pgsql" ? `<div class="grid-2">
            <label class="field"><span>Charset</span><input name="charset" value="utf8mb4"></label>
            <label class="field"><span>Collation</span><input name="collation" value="utf8mb4_unicode_ci"></label></div>` : ""}
        </div>
        <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create</button></div>
      </form>`, (root) => {
      const form = $("#newdb-form", root);
      $("[data-dismiss]", form).addEventListener("click", closeModal);
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const name = form.elements.name.value.trim();
        try {
          await LD.call("db_create_database", { conn: c.id, name, charset: form.elements.charset?.value, collation: form.elements.collation?.value });
          closeModal();
          toast("success", `Database ${name} created`);
          await openConn(c.id);
          openDb(c.id, name);
        } catch (err) {
          toast("error", "Couldn't create the database", err.message);
        }
      });
    });
  }

  async function dropDb(c, db) {
    if (!(await confirmModal({ title: `Drop ${db}?`, danger: true, confirm: "Drop database", requireText: db,
      message: `Permanently deletes <b>${esc(db)}</b> and every table in it on ${esc(c.name)}.` }))) return;
    try {
      await LD.call("db_drop_database", { conn: c.id, name: db });
      S.tabs.filter((t) => t.conn === c.id && t.db === db).forEach((t) => { t.edits = new Map(); t.inserts = []; t.deletes = new Set(); closeTab(t.id); });
      toast("success", `Dropped ${db}`);
      openConn(c.id);
    } catch (err) {
      toast("error", "Couldn't drop it", err.message);
    }
  }

  async function tableOp(c, db, table, op) {
    const verb = op === "drop" ? "Drop" : "Empty";
    if (!(await confirmModal({ title: `${verb} ${table}?`, danger: true, confirm: verb, requireText: op === "drop" ? table : "",
      message: op === "drop" ? `Permanently deletes <b>${esc(table)}</b> and its data.` : `Deletes every row in <b>${esc(table)}</b>. The table stays.` }))) return;
    try {
      await LD.call("db_table_op", { conn: c.id, database: db, table, op });
      toast("success", `${verb === "Drop" ? "Dropped" : "Emptied"} ${table}`);
      if (op === "drop") S.tabs.filter((t) => t.kind === "table" && t.conn === c.id && t.db === db && t.table === table).forEach((t) => { t.edits = new Map(); t.inserts = []; t.deletes = new Set(); closeTab(t.id); });
      else S.tabs.filter((t) => t.kind === "table" && t.table === table && t.conn === c.id).forEach((t) => loadRows(t));
      openDb(c.id, db, true);
    } catch (err) {
      toast("error", `Couldn't ${verb.toLowerCase()} ${table}`, err.message);
    }
  }

  async function renameTable(c, db, table) {
    const target = await promptModal(`Rename ${table}`, "New name", table);
    if (!target || target === table) return;
    try {
      await LD.call("db_table_op", { conn: c.id, database: db, table, op: "rename", target });
      S.tabs.filter((t) => t.kind === "table" && t.conn === c.id && t.db === db && t.table === table).forEach((t) => { t.table = target; t.data = null; });
      openDb(c.id, db, true);
      renderTabs();
      renderMain();
    } catch (err) {
      toast("error", "Couldn't rename", err.message);
    }
  }

  /* ── code generation & seeder modals (Phase 1) ────────── */

  function highlightPhp(code) {
    const re = /(\/\*[\s\S]*?\*\/|\/\/[^\n]*)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|(\$[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)|(\b(?:class|new|extends|implements|public|protected|private|function|return|use|namespace|void|bool|int|string|float|array|true|false|null|if|else|foreach)\b)|(\b[A-Z][a-zA-Z0-9_]*\b)/g;

    let lastIndex = 0;
    let html = "";
    let m;
    while ((m = re.exec(code)) !== null) {
      if (m.index > lastIndex) {
        html += esc(code.slice(lastIndex, m.index));
      }
      const [match, comment, str, variable, keyword, typeName] = m;
      if (comment) html += `<span class="tok-comment">${esc(match)}</span>`;
      else if (str) html += `<span class="tok-str">${esc(match)}</span>`;
      else if (variable) html += `<span class="tok-var">${esc(match)}</span>`;
      else if (keyword) html += `<span class="tok-kw">${esc(match)}</span>`;
      else if (typeName) html += `<span class="tok-type">${esc(match)}</span>`;
      lastIndex = re.lastIndex;
    }
    if (lastIndex < code.length) html += esc(code.slice(lastIndex));
    return html;
  }

  function openCodeModal({ title, type, fileName, code, connId, database, table }) {
    const c = conn(connId);
    const sitesList = (window.state?.sites || []).map((s) => s.name);
    const defaultSite = c?.site || sitesList[0] || "";

    const folderMap = {
      model: "app/Models/",
      migration: "database/migrations/",
      seeder: "database/seeders/"
    };
    const targetFolder = folderMap[type] || "";

    openModal(`
      <div class="modal code-preview-modal" id="code-modal">
        <div class="modal-header" style="padding-bottom: 12px;">
          <h2>${esc(title)}</h2>
          <p>Generated Laravel code for table <b>${esc(table)}</b>.</p>
        </div>

        <div class="modal-body" style="padding-top: 0;">
          <div class="code-preview-bar">
            <div class="code-preview-meta">
              <span class="code-badge">${esc(targetFolder)}</span>
              <input id="code-modal-filename" value="${esc(fileName)}" spellcheck="false" style="font-family:var(--font-mono, monospace); font-size:12px; width:260px; padding:4px 8px; border:1px solid var(--border); border-radius:6px; background:var(--surface); color:var(--text);">
            </div>
            <div class="code-preview-tools">
              ${sitesList.length ? `
                <select id="code-modal-site" style="font-size:12px; padding:4px 8px; border:1px solid var(--border); border-radius:6px; background:var(--surface); color:var(--text);">
                  ${sitesList.map((s) => `<option value="${esc(s)}" ${s === defaultSite ? "selected" : ""}>Project: ${esc(s)}</option>`).join("")}
                </select>
              ` : ""}
              <button type="button" class="btn sm" id="code-modal-copy">${icon("copy")} Copy</button>
              <button type="button" class="btn sm primary" id="code-modal-save">${icon("check")} Save to Project</button>
            </div>
          </div>

          <pre class="code-preview-pre"><code>${highlightPhp(code)}</code></pre>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>Close</button>
        </div>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      $("#code-modal-copy", root)?.addEventListener("click", async function () {
        try {
          await navigator.clipboard.writeText(code);
          const orig = this.innerHTML;
          this.innerHTML = `${icon("check")} Copied!`;
          setTimeout(() => { this.innerHTML = orig; }, 1800);
          toast("success", "Code copied to clipboard");
        } catch {
          copyText(code);
        }
      });

      $("#code-modal-save", root)?.addEventListener("click", async function () {
        const site = $("#code-modal-site", root)?.value || defaultSite;
        if (!site) {
          toast("error", "Choose a project first");
          return;
        }
        const fn = $("#code-modal-filename", root)?.value.trim() || fileName;
        this.disabled = true;
        this.innerHTML = `${icon("refresh")} Saving…`;
        try {
          let res = await LD.call("db_save_code", { site, type, file_name: fn, code, overwrite: false });
          if (res.exists) {
            this.disabled = false;
            this.innerHTML = `${icon("check")} Save to Project`;
            const confirmed = await confirmModal({
              title: `${res.file_name || fn} already exists`,
              message: `${esc(res.message || "A file with this name already exists.")}<br><br>Do you want to overwrite it?`,
              confirm: "Overwrite",
              danger: true,
            });
            if (!confirmed) return;

            this.disabled = true;
            this.innerHTML = `${icon("refresh")} Overwriting…`;
            res = await LD.call("db_save_code", { site, type, file_name: fn, code, overwrite: true });
          }
          if (res.ok) {
            toast("success", `Saved to ${res.path}`);
            closeModal();
          } else {
            throw new Error(res.error || "Failed to save file");
          }
        } catch (err) {
          this.disabled = false;
          this.innerHTML = `${icon("check")} Save to Project`;
          toast("error", "Couldn't save file", err.message);
        }
      });
    });
  }

  async function openModelModal(connId, database, table) {
    try {
      const res = await LD.call("db_generate_model", { conn: connId, database, table });
      openCodeModal({
        title: `Eloquent Model: ${res.model}`,
        type: "model",
        fileName: res.file_name,
        code: res.code,
        connId,
        database,
        table
      });
    } catch (err) {
      toast("error", "Failed to generate model", err.message);
    }
  }

  async function openMigrationModal(connId, database, table) {
    try {
      const res = await LD.call("db_generate_migration", { conn: connId, database, table });
      openCodeModal({
        title: `Laravel Migration: ${table}`,
        type: "migration",
        fileName: res.file_name,
        code: res.code,
        connId,
        database,
        table
      });
    } catch (err) {
      toast("error", "Failed to generate migration", err.message);
    }
  }

  function openSeedModal(connId, database, table) {
    let selectedCount = 25;
    let selectedMode = "insert";

    openModal(`
      <div class="modal seeder-modal" id="seed-modal">
        <div class="modal-header">
          <h2>Seed Dummy Data</h2>
          <p>Generate realistic mock records for <b>${esc(table)}</b>.</p>
        </div>

        <div class="modal-body">
          <label class="field">
            <span>Number of Records</span>
            <div class="seed-count-pills">
              ${[10, 25, 50, 100, 500].map((num) => `
                <button type="button" class="seed-count-pill ${num === selectedCount ? "active" : ""}" data-count="${num}">
                  ${num}
                </button>
              `).join("")}
            </div>
          </label>

          <label class="field" style="margin-top: 8px;">
            <span>Seeding Mode</span>
            <div class="seed-mode-group">
              <label class="seed-mode-card ${selectedMode === "insert" ? "active" : ""}">
                <input type="radio" name="seed-mode" value="insert" ${selectedMode === "insert" ? "checked" : ""}>
                <div>
                  <div class="seed-mode-title">⚡ Direct Insert to Database</div>
                  <div class="seed-mode-desc">Immediately stream realistic records into the live database table with real foreign keys.</div>
                </div>
              </label>

              <label class="seed-mode-card ${selectedMode === "code" ? "active" : ""}">
                <input type="radio" name="seed-mode" value="code" ${selectedMode === "code" ? "checked" : ""}>
                <div>
                  <div class="seed-mode-title">📄 Generate Laravel Seeder File</div>
                  <div class="seed-mode-desc">Create a Database\\Seeders PHP class file that you can save or run via artisan db:seed.</div>
                </div>
              </label>
            </div>
          </label>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>Cancel</button>
          <button type="button" class="btn primary" id="seed-modal-submit">${icon("zap")} Start Seeding</button>
        </div>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      $$(".seed-count-pill", root).forEach((btn) => {
        btn.addEventListener("click", () => {
          $$(".seed-count-pill", root).forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          selectedCount = Number(btn.dataset.count);
        });
      });

      $$(".seed-mode-card", root).forEach((card) => {
        card.addEventListener("click", () => {
          $$(".seed-mode-card", root).forEach((c) => c.classList.remove("active"));
          card.classList.add("active");
          selectedMode = card.querySelector("input").value;
          const submitBtn = $("#seed-modal-submit", root);
          if (submitBtn) {
            submitBtn.innerHTML = selectedMode === "insert" ? `${icon("zap")} Start Seeding` : `${icon("code")} Generate Seeder`;
          }
        });
      });

      $("#seed-modal-submit", root)?.addEventListener("click", async function () {
        if (selectedMode === "insert") {
          const connObj = S.connections?.find((c) => c.id === connId);
          const isRemote = Boolean(connObj?.use_ssh || connObj?.server || connObj?.source === "server");
          const isProd = /prod/i.test(database) || /prod/i.test(connObj?.name || "");

          if (isRemote || isProd) {
            const confirmed = await confirmModal({
              title: "⚠️ Remote / Production Database Guard",
              message: `You are about to insert ${selectedCount} mock records directly into table "${table}" on ${isProd ? "production " : ""}database "${database}" (${connObj?.name || connId}). Type "${database}" to confirm:`,
              confirm: "Confirm & Insert",
              danger: true,
              requireText: database,
            });
            if (!confirmed) return;
          } else {
            const confirmed = await confirmModal({
              title: "Insert mock records?",
              message: `Insert ${selectedCount} realistic mock records into table "${table}" on database "${database}" (${connObj?.name || connId})?`,
              confirm: "Insert Data",
              danger: false,
            });
            if (!confirmed) return;
          }
        }

        this.disabled = true;
        this.innerHTML = `${icon("refresh", "spin")} Processing…`;
        try {
          if (selectedMode === "insert") {
            const res = await LD.call("db_seed_data", { conn: connId, database, table, count: selectedCount, mode: "insert" });
            toast("success", `Inserted ${res.inserted} mock rows into ${res.table} (${res.ms}ms)`);
            closeModal();
            const current = tab();
            if (current?.kind === "table" && current.table === table && current.conn === connId) {
              loadRows(current, { keepPage: true });
            }
          } else {
            const res = await LD.call("db_seed_data", { conn: connId, database, table, count: selectedCount, mode: "code" });
            closeModal();
            openCodeModal({
              title: `Laravel Seeder: ${res.model}Seeder`,
              type: "seeder",
              fileName: res.file_name,
              code: res.code,
              connId,
              database,
              table
            });
          }
        } catch (err) {
          this.disabled = false;
          this.innerHTML = selectedMode === "insert" ? `${icon("zap")} Start Seeding` : `${icon("code")} Generate Seeder`;
          toast("error", "Seeding failed", err.message);
        }
      });
    });
  }

  /* ── Phase 2: Schema Diff & Visual EXPLAIN ─────────────── */

  async function runExplain(t) {
    const area = $(".sql-editor");
    if (area) t.sql = area.value;
    const selected = area && area.selectionEnd > area.selectionStart ? area.value.slice(area.selectionStart, area.selectionEnd) : t.sql;
    if (!selected.trim()) return toast("error", "Write a query first to explain");
    t.running = true;
    t.showExplain = true;
    renderMain();
    try {
      const res = await LD.call("db_explain", { conn: t.conn, database: t.db, sql: selected });
      t.explain = res;
    } catch (err) {
      t.explain = { error: err.message };
    }
    t.running = false;
    renderMain();
  }

  function renderExplainView(t) {
    const exp = t.explain;
    if (exp?.error) {
      return `
        <div style="padding:16px;">
          <div style="margin-bottom:12px;">
            <button class="btn sm" data-db="close-explain">${icon("back")} Back to Results</button>
          </div>
          <div class="query-msg error">${icon("alert")}<div><b>EXPLAIN Error</b><small class="mono">${esc(exp.error)}</small></div></div>
        </div>`;
    }

    const summary = exp.summary || {};
    const status = summary.status || "optimal";
    const statusTitles = {
      optimal: "Optimal Execution Plan",
      warning: "Optimization Opportunity Detected",
      critical: "Performance Warning: Full Table Scan"
    };
    const statusSubs = {
      optimal: "The database uses indexes efficiently for this query.",
      warning: "Some operations (sorting or temporary tables) may slow down large datasets.",
      critical: `${summary.full_table_scans || 1} table(s) are scanned row-by-row without using an index.`
    };

    return `
      <div class="dbm-explain-wrap">
        <div style="display:flex; align-items:center; justify-content:space-between;">
          <button class="btn sm" data-db="close-explain">${icon("back")} Back to Results</button>
          <span class="muted" style="font-size:12px;">Driver: <b>${esc(exp.driver?.toUpperCase() || "")}</b></span>
        </div>

        <div class="explain-banner ${esc(status)}">
          ${icon(status === "optimal" ? "check" : "alert", "explain-banner-icon")}
          <div>
            <div class="explain-banner-title">${esc(statusTitles[status] || "Analysis Complete")}</div>
            <div class="explain-banner-sub">${esc(statusSubs[status] || "")}</div>
          </div>
        </div>

        ${(summary.recommendations || []).length ? `
          <div style="display:flex; flex-direction:column; gap:8px;">
            <div style="font-size:12px; font-weight:600; color:var(--text); text-transform:uppercase; letter-spacing:0.5px;">Recommended Index Optimizations:</div>
            ${summary.recommendations.map((rec) => `
              <div class="explain-rec-card">
                <div>
                  <div class="explain-rec-text">${esc(rec.message)}</div>
                  ${rec.suggested_sql ? `<code class="explain-rec-sql">${esc(rec.suggested_sql)}</code>` : ""}
                </div>
                ${rec.suggested_sql ? `
                  <button class="btn sm" data-copy-sql="${esc(rec.suggested_sql)}">${icon("copy")} Copy SQL</button>
                ` : ""}
              </div>
            `).join("")}
          </div>
        ` : ""}

        <div style="font-size:12px; font-weight:600; color:var(--text); text-transform:uppercase; letter-spacing:0.5px;">Execution Steps Breakdown:</div>
        <div class="explain-steps-flow">
          ${(exp.steps || []).map((step, idx) => `
            <div class="explain-step-card ${esc(step.severity || "good")}">
              <span class="chip" style="font-family:var(--font-mono, monospace); font-weight:bold;">#${idx + 1}</span>
              <div>
                <div class="explain-step-op">${esc(step.operation || step.type)}</div>
                ${step.warning ? `<div class="explain-step-detail" style="color:var(--red); font-weight:550; margin-top:2px;">⚠ ${esc(step.warning)}</div>` : ""}
                ${step.key ? `<div class="explain-step-detail">Index used: <code class="mono">${esc(step.key)}</code></div>` : ""}
              </div>
              <div class="explain-step-badges">
                ${step.table ? `<span class="explain-pill">${icon("grid")} ${esc(step.table)}</span>` : ""}
                ${step.rows !== undefined && step.rows !== null ? `<span class="explain-pill ${step.severity === "critical" ? "red" : ""}">${Number(step.rows).toLocaleString()} rows est.</span>` : ""}
                ${step.type === "scan" ? `<span class="explain-pill red">Full Scan</span>` : step.type === "index_lookup" ? `<span class="explain-pill green">Indexed</span>` : ""}
              </div>
            </div>
          `).join("")}
        </div>
      </div>`;
  }

  function openDiffTab({ srcConn, srcDb, tgtConn, tgtDb } = {}) {
    const sConn = srcConn || S.conns[0]?.id;
    const sDb = srcDb || conn(sConn)?.database || (conn(sConn)?.driver === "sqlite" ? "main" : "");
    const tConn = tgtConn || (S.conns.length > 1 ? S.conns[1]?.id : sConn);
    const tDb = tgtDb || conn(tConn)?.database || (conn(tConn)?.driver === "sqlite" ? "main" : "");

    const t = {
      id: fId(),
      kind: "diff",
      srcConn: sConn,
      srcDb: sDb,
      tgtConn: tConn,
      tgtDb: tDb,
      data: null,
      loading: false,
      selectedTable: null,
      checkedStatements: new Set(),
      tableFilter: ""
    };
    S.tabs.push(t);
    activate(t.id);
    loadDiff(t);
  }

  async function loadDiff(t) {
    if (!t.srcConn || !t.tgtConn) return;
    t.loading = true;
    renderMain();
    try {
      const res = await LD.call("db_diff", {
        src_conn: t.srcConn,
        src_db: t.srcDb,
        tgt_conn: t.tgtConn,
        tgt_db: t.tgtDb
      });
      t.data = res;
      t.checkedStatements = new Set((res.statements || []).map((s) => s.id));
      t.selectedTable = res.tables?.[0]?.name || null;
    } catch (err) {
      toast("error", "Comparison failed", err.message);
    }
    t.loading = false;
    renderMain();
  }

  function diffTab(t) {
    const sConn = conn(t.srcConn);
    const tConn = conn(t.tgtConn);
    const sDbs = (S.tree[t.srcConn]?.databases || []).filter((d) => S.showSystem || !d.system || d.name === t.srcDb);
    const tDbs = (S.tree[t.tgtConn]?.databases || []).filter((d) => S.showSystem || !d.system || d.name === t.tgtDb);

    const diff = t.data;
    const stats = diff?.stats || {
      missing_tables: 0, extra_tables: 0, altered_tables: 0, identical_tables: 0,
      missing_columns: 0, modified_columns: 0, missing_indexes: 0, total_statements: 0
    };

    const tables = diff?.tables || [];
    const filter = (t.tableFilter || "").toLowerCase().trim();
    const visibleTables = tables.filter((tb) => !filter || tb.name.toLowerCase().includes(filter));
    const selected = t.selectedTable || (visibleTables[0]?.name || null);
    const currentTableData = tables.find((tb) => tb.name === selected);

    const statements = diff?.statements || [];
    const checkedCount = t.checkedStatements ? t.checkedStatements.size : 0;

    return `
      <div class="dbm-diff-container">
        <div class="diff-toolbar">
          <div class="diff-target-group">
            <span class="muted" style="font-size:12px; font-weight:600;">Source:</span>
            <select data-diff-src-conn class="sm">
              ${S.conns.map((c) => `<option value="${esc(c.id)}" ${c.id === t.srcConn ? "selected" : ""}>${esc(c.name)}</option>`).join("")}
            </select>
            ${sConn?.driver === "sqlite" ? "" : `
              <select data-diff-src-db class="sm">
                ${sDbs.map((d) => `<option value="${esc(d.name)}" ${d.name === t.srcDb ? "selected" : ""}>${esc(d.name)}</option>`).join("")}
              </select>
            `}
          </div>

          <span class="diff-arrow">➔</span>

          <div class="diff-target-group">
            <span class="muted" style="font-size:12px; font-weight:600;">Target:</span>
            <select data-diff-tgt-conn class="sm">
              ${S.conns.map((c) => `<option value="${esc(c.id)}" ${c.id === t.tgtConn ? "selected" : ""}>${esc(c.name)}</option>`).join("")}
            </select>
            ${tConn?.driver === "sqlite" ? "" : `
              <select data-diff-tgt-db class="sm">
                ${tDbs.map((d) => `<option value="${esc(d.name)}" ${d.name === t.tgtDb ? "selected" : ""}>${esc(d.name)}</option>`).join("")}
              </select>
            `}
          </div>

          <button class="btn sm primary" data-diff="run-compare" ${t.loading ? "disabled" : ""}>
            ${icon("refresh")}${t.loading ? "Comparing…" : "Compare Schemas"}
          </button>

          <span class="spacer"></span>

          <button class="btn sm" data-diff="copy-all-sql" ${statements.length ? "" : "disabled"} title="Copy generated sync script">
            ${icon("copy")} Copy Sync SQL
          </button>
          <button class="btn sm primary" data-diff="sync-selected" ${checkedCount ? "" : "disabled"} title="Apply selected migration statements to target">
            ${icon("zap")} Sync to Target (${checkedCount})
          </button>
        </div>

        ${diff ? `
          <div class="diff-stats-bar">
            <span class="diff-chip ${stats.missing_tables ? "missing" : "identical"}">
              ${stats.missing_tables} Missing Tables
            </span>
            <span class="diff-chip ${stats.altered_tables ? "altered" : "identical"}">
              ${stats.altered_tables} Altered Tables
            </span>
            <span class="diff-chip ${stats.missing_columns ? "altered" : "identical"}">
              ${stats.missing_columns} Missing Columns
            </span>
            <span class="diff-chip ${stats.missing_indexes ? "altered" : "identical"}">
              ${stats.missing_indexes} Missing Indexes
            </span>
            <span class="diff-chip identical">
              ${stats.identical_tables} Identical Tables
            </span>
          </div>

          <div class="diff-content-grid">
            <div class="diff-table-list">
              <div style="padding: 8px 10px; border-bottom: 1px solid var(--border);">
                <div class="search sm" style="width:100%;">
                  ${icon("search")}
                  <input data-diff-filter placeholder="Filter tables…" value="${esc(t.tableFilter || "")}">
                </div>
              </div>
              <div style="overflow-y:auto; flex:1;">
                ${visibleTables.map((tb) => {
                  const statusColors = {
                    missing_in_target: "background:var(--red-soft); color:var(--red);",
                    altered: "background:var(--amber-soft); color:var(--amber);",
                    extra_in_target: "background:rgba(14,165,233,0.15); color:#0ea5e9;",
                    identical: "background:var(--green-soft); color:var(--green);"
                  };
                  const statusLabels = {
                    missing_in_target: "Missing",
                    altered: "Altered",
                    extra_in_target: "Extra",
                    identical: "Identical"
                  };
                  return `
                    <div class="diff-table-row ${tb.name === selected ? "active" : ""}" data-diff-table="${esc(tb.name)}">
                      <div class="diff-table-name">
                        ${icon("grid")} <span>${esc(tb.name)}</span>
                      </div>
                      <span class="chip" style="${statusColors[tb.status] || ""}">
                        ${statusLabels[tb.status] || tb.status}
                      </span>
                    </div>`;
                }).join("")}
              </div>
            </div>

            <div class="diff-details-panel">
              ${currentTableData ? `
                <div style="background:var(--surface); border:1px solid var(--border); border-radius:8px; padding:12px 16px;">
                  <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:8px;">
                    <h3 style="margin:0; font-size:15px; display:flex; align-items:center; gap:6px;">
                      ${icon("grid")} Table: <b>${esc(currentTableData.name)}</b>
                    </h3>
                  </div>

                  ${currentTableData.missing_columns?.length ? `
                    <div style="margin-top:8px;">
                      <span class="muted" style="font-size:12px; font-weight:600;">Missing Columns in Target:</span>
                      <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:4px;">
                        ${currentTableData.missing_columns.map((c) => `<span class="chip" style="color:var(--red); background:var(--red-soft); font-family:var(--font-mono, monospace);">+ ${esc(c)}</span>`).join("")}
                      </div>
                    </div>
                  ` : ""}

                  ${currentTableData.modified_columns?.length ? `
                    <div style="margin-top:8px;">
                      <span class="muted" style="font-size:12px; font-weight:600;">Modified Columns:</span>
                      <div style="display:flex; flex-direction:column; gap:4px; margin-top:4px;">
                        ${currentTableData.modified_columns.map((m) => `
                          <div style="font-size:12px; font-family:var(--font-mono, monospace); color:var(--text);">
                            ~ <b>${esc(m.column)}</b>: ${esc(m.target_type)} ➔ <span style="color:var(--accent);">${esc(m.source_type)}</span>
                          </div>`).join("")}
                      </div>
                    </div>
                  ` : ""}

                  ${currentTableData.missing_indexes?.length ? `
                    <div style="margin-top:8px;">
                      <span class="muted" style="font-size:12px; font-weight:600;">Missing Indexes:</span>
                      <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:4px;">
                        ${currentTableData.missing_indexes.map((idx) => `<span class="chip" style="color:var(--amber); background:var(--amber-soft); font-family:var(--font-mono, monospace);">+ ${esc(idx)}</span>`).join("")}
                      </div>
                    </div>
                  ` : ""}
                </div>
              ` : ""}

              <div style="display:flex; align-items:center; justify-content:space-between;">
                <span style="font-size:13px; font-weight:600; color:var(--text);">Executable Sync Statements (${statements.length}):</span>
                <button class="btn ghost xs" data-diff="toggle-all-stmts">
                  ${t.checkedStatements.size === statements.length ? "Deselect All" : "Select All"}
                </button>
              </div>

              ${statements.length ? `
                <div style="display:flex; flex-direction:column; gap:8px;">
                  ${statements.map((stmt) => `
                    <div class="diff-stmt-card">
                      <input type="checkbox" data-stmt-id="${stmt.id}" ${t.checkedStatements.has(stmt.id) ? "checked" : ""}>
                      <div class="diff-stmt-content">
                        <div class="diff-stmt-desc">${esc(stmt.description || stmt.type)}</div>
                        <pre class="diff-stmt-sql"><code>${esc(stmt.sql)}</code></pre>
                      </div>
                    </div>
                  `).join("")}
                </div>
              ` : `
                <div class="card" style="padding:24px; text-align:center; color:var(--muted);">
                  ${icon("check")} Target schema is completely in sync with source! No statements required.
                </div>
              `}
            </div>
          </div>
        ` : `
          <div class="dbm-welcome" style="padding:40px 20px;">
            <div class="empty-icon">${icon("layers")}</div>
            <h2>Schema Diff & Safe Sync</h2>
            <p class="muted">Compare two database structures (e.g. Local vs Staging or Production via SSH) to find missing tables, extra columns, modified types, and missing indexes.</p>
            <button class="btn primary" data-diff="run-compare" style="margin-top:12px;">
              ${icon("refresh")} Start Schema Comparison
            </button>
          </div>
        `}
      </div>`;
  }

  function bindDiffEvents(t, root) {
    const srcConnSel = $("[data-diff-src-conn]", root);
    const srcDbSel = $("[data-diff-src-db]", root);
    const tgtConnSel = $("[data-diff-tgt-conn]", root);
    const tgtDbSel = $("[data-diff-tgt-db]", root);

    srcConnSel?.addEventListener("change", async (e) => {
      t.srcConn = e.target.value;
      const c = conn(t.srcConn);
      t.srcDb = c?.database || (c?.driver === "sqlite" ? "main" : "");
      if (!S.tree[t.srcConn]?.databases) await openConn(t.srcConn, { quiet: true });
      renderMain();
    });

    srcDbSel?.addEventListener("change", (e) => {
      t.srcDb = e.target.value;
      renderMain();
    });

    tgtConnSel?.addEventListener("change", async (e) => {
      t.tgtConn = e.target.value;
      const c = conn(t.tgtConn);
      t.tgtDb = c?.database || (c?.driver === "sqlite" ? "main" : "");
      if (!S.tree[t.tgtConn]?.databases) await openConn(t.tgtConn, { quiet: true });
      renderMain();
    });

    tgtDbSel?.addEventListener("change", (e) => {
      t.tgtDb = e.target.value;
      renderMain();
    });

    const searchInput = $("[data-diff-filter]", root);
    searchInput?.addEventListener("input", (e) => {
      t.tableFilter = e.target.value;
      renderMain();
    });

    $$("[data-diff-table]", root).forEach((el) => {
      el.addEventListener("click", () => {
        t.selectedTable = el.dataset.diffTable;
        renderMain();
      });
    });

    $$("[data-stmt-id]", root).forEach((cb) => {
      cb.addEventListener("change", (e) => {
        const id = Number(e.target.dataset.stmtId);
        if (e.target.checked) t.checkedStatements.add(id);
        else t.checkedStatements.delete(id);
        renderMain();
      });
    });
  }

  /* ── events ─────────────────────────────────────────────── */

  document.addEventListener("click", async (e) => {
    if (menuEl && !menuEl.contains(e.target)) hideMenu();
    const target = e.target;
    if (!inDb(target)) return;
    let el;

    if ((el = target.closest("[data-close-tab]"))) { e.stopPropagation(); return closeTab(el.dataset.closeTab); }
    if ((el = target.closest("[data-tab-id]"))) return activate(el.dataset.tabId);
    if ((el = target.closest("[data-open-conn]")) && !target.closest("[data-db]")) return openConn(el.dataset.openConn);
    if ((el = target.closest("[data-menu]"))) {
      e.stopPropagation();
      const node = el.closest("[data-conn]");
      const c = conn(node.dataset.conn);
      const r = el.getBoundingClientRect();
      const items = el.dataset.menu === "conn" ? connMenu(c) : el.dataset.menu === "db" ? dbMenu(c, node.dataset.dbname) : tableMenu(c, node.dataset.dbname, node.dataset.table);
      return showMenu(r.left, r.bottom + 4, items);
    }

    const action = target.closest("[data-db]")?.dataset.db;
    const current = tab();
    switch (action) {
      case "toggle-side": S.sideCollapsed = !S.sideCollapsed; return render();
      case "new-conn": return connModal();
      case "refresh-conns": await loadConns(true); for (const id of Object.keys(S.tree)) if (S.tree[id].open && conn(id)) openConn(id, { quiet: true }); return render();
      case "show-system": S.showSystem = true; return renderTree();
      case "show-all": S.tree[target.closest("[data-conn]").dataset.conn].showAll = true; return renderTree();
      case "query-here": {
        e.stopPropagation();
        const node = target.closest("[data-conn]");
        return openTab({ kind: "query", conn: node.dataset.conn, db: node.dataset.dbname || "" });
      }
      case "new-query": {
        const base = current || { conn: S.conns[0]?.id, db: S.conns[0]?.database || "" };
        if (!base.conn) return toast("error", "Add a connection first");
        return openTab({ kind: "query", conn: base.conn, db: base.db || "" });
      }
      case "query-db": return openTab({ kind: "query", conn: current.conn, db: current.db });
      case "refresh-db": return openDb(current.conn, current.db, true);
      case "export-db": return exportData(current.conn, current.db, [], "sql");
      case "snapshots-db": return openSnapshotsModal(current.conn, current.db);
      case "import": return importSql(current.conn, current.db);
      case "copy-ddl": return copyText(current.structure?.ddl || "");
      case "gen-model": return openModelModal(current.conn, current.db, current.table);
      case "gen-migration": return openMigrationModal(current.conn, current.db, current.table);
      case "seed-table": return openSeedModal(current.conn, current.db, current.table);
      case "reload":
        if (pendingCount(current) && !(await confirmModal({ title: "Discard changes?", message: "Refreshing drops your unsaved edits.", confirm: "Discard", danger: true }))) return;
        current.edits = new Map(); current.inserts = []; current.deletes = new Set();
        renderTabs();
        return loadRows(current);
      case "add-row": current.inserts.unshift({}); renderTabs(); renderMain(); {
        const first = $("#dbm-content tr.new td[data-new-cell]");
        const visible = current.data.columns.filter((c) => !c.hidden);
        const firstCol = visible.find((c) => !c.auto);
        const cell = firstCol ? $(`#dbm-content tr[data-new="0"] td[data-new-cell="${CSS.escape(firstCol.name)}"]`) : first;
        if (cell) startEdit(cell);
      }
        return;
      case "drop-new": current.inserts.splice(+target.closest("[data-new]").dataset.new, 1); renderTabs(); return renderMain();
      case "delete-rows": current.selected.forEach((ri) => current.deletes.add(ri)); current.selected = new Set(); renderTabs(); return renderMain();
      case "discard": current.edits = new Map(); current.inserts = []; current.deletes = new Set(); renderTabs(); return renderMain();
      case "save": return saveChanges(current);
      case "export-table": return showMenu(e.clientX, e.clientY, ["sql", "csv", "json"].map((f) => ({ label: `Export as ${f.toUpperCase()}…`, icon: "download", run: () => exportData(current.conn, current.db, [current.table], f) })));
      case "export-query-csv": return exportQueryResult(current?.results?.[current.resultIndex], "csv");
      case "export-query-json": return exportQueryResult(current?.results?.[current.resultIndex], "json");
      case "run-query": return runQuery(current);
      case "toggle-filters": {
        current.showFilters = !current.showFilters;
        return renderMain();
      }
      case "toggle-raw-where": {
        current.showRawWhere = !current.showRawWhere;
        return renderMain();
      }
      case "add-filter": {
        const colSel = $("[data-flt-column]");
        const opSel = $("[data-flt-op]");
        const valInp = $("[data-flt-value]");
        if (!colSel || !opSel) return;
        const column = colSel.value;
        const op = opSel.value;
        const value = valInp ? valInp.value.trim() : "";
        if (!op.includes("NULL") && !value) {
          return toast("error", "Filter value required", "Please enter a value for the filter condition.");
        }
        current.filters = current.filters || [];
        current.filters.push({ column, op, value });
        current.showFilters = true;
        return loadRows(current, { keepPage: false });
      }
      case "clear-all-filters": {
        current.filters = [];
        current.where = "";
        current.showRawWhere = false;
        return loadRows(current, { keepPage: false });
      }
      case "open-as-query": {
        const c = conn(current.conn);
        const sql = buildTableSelectSql(c?.driver, current.table, current.filters, current.where, current.sort, current.dir, current.limit);
        return openTab({ kind: "query", conn: current.conn, db: current.db, sql });
      }
      case "open-hologram": {
        e.stopPropagation();
        const node = target.closest("[data-conn]") || target.closest("[data-dbname]");
        const cId = node?.dataset.conn || current?.conn;
        const dbName = node?.dataset.dbname || current?.db;
        if (cId && dbName) return openHologram(cId, dbName);
        break;
      }
      case "open-diff": return openDiffTab();
      case "explain-query": return runExplain(current);
      case "close-explain": current.showExplain = false; return renderMain();
    }

    const dbSortCol = target.closest("[data-db-sort]")?.dataset.dbSort;
    if (dbSortCol && current?.kind === "db") {
      current.tableDir = current.tableSort === dbSortCol && current.tableDir === "ASC" ? "DESC" : "ASC";
      current.tableSort = dbSortCol;
      return renderMain();
    }

    const fkJump = target.closest("[data-fk-table]");
    if (fkJump && current?.kind === "table") {
      e.stopPropagation();
      return openTab({
        kind: "table",
        conn: current.conn,
        db: current.db,
        table: fkJump.dataset.fkTable,
        filters: [{ column: fkJump.dataset.fkCol, op: "=", value: fkJump.dataset.fkVal }],
        showFilters: true,
      });
    }

    const inspectCellBtn = target.closest("[data-inspect-row]");
    if (inspectCellBtn && current?.kind === "table") {
      e.stopPropagation();
      return inspectCellModal(current, +inspectCellBtn.dataset.inspectRow, +inspectCellBtn.dataset.inspectCol);
    }

    const structJump = target.closest("[data-struct-jump-table]");
    if (structJump && current?.kind === "table") {
      return openTab({ kind: "table", conn: current.conn, db: current.db, table: structJump.dataset.structJumpTable, sub: "data" });
    }

    const holoJump = target.closest("[data-holo-jump-table]");
    if (holoJump && current?.kind === "hologram") {
      current.selectedTable = holoJump.dataset.holoJumpTable;
      current.selectedRel = null;
      return renderMain();
    }

    const holoSql = target.closest("[data-holo-sql-table]");
    if (holoSql && current?.kind === "hologram") {
      const c = conn(current.conn);
      return openTab({
        kind: "query",
        conn: current.conn,
        db: current.db,
        sql: `SELECT * FROM ${q(c?.driver, holoSql.dataset.holoSqlTable)} LIMIT 100;`,
      });
    }

    const holoCopyJoin = target.closest("[data-holo-copy-join]");
    if (holoCopyJoin && current?.kind === "hologram") {
      copyText(holoCopyJoin.dataset.holoCopyJoin);
      toast("success", t("db_copied"));
      return;
    }

    const holoRunJoin = target.closest("[data-holo-run-join]");
    if (holoRunJoin && current?.kind === "hologram") {
      return openTab({ kind: "query", conn: current.conn, db: current.db, sql: holoRunJoin.dataset.holoRunJoin });
    }

    const quickTable = target.closest("[data-db-quick-query]")?.dataset.dbQuickQuery;
    if (quickTable) {
      e.stopPropagation();
      const c = conn(current?.conn);
      return openTab({
        kind: "query",
        conn: current.conn,
        db: current.db,
        sql: `SELECT * FROM ${q(c?.driver, quickTable)} LIMIT 100;`
      });
    }

    const filterTable = target.closest("[data-db-open-filtered]")?.dataset.dbOpenFiltered;
    if (filterTable) {
      e.stopPropagation();
      return openTab({
        kind: "table",
        conn: current.conn,
        db: current.db,
        table: filterTable,
        showFilters: true
      });
    }

    const rmFilter = target.closest("[data-remove-filter]");
    if (rmFilter && current?.kind === "table") {
      const idx = +rmFilter.dataset.removeFilter;
      if (current.filters && current.filters[idx] !== undefined) {
        current.filters.splice(idx, 1);
        return loadRows(current, { keepPage: false });
      }
    }

    if (target.closest("[data-db-clear-row-search]") && current?.kind === "table") {
      current.search = "";
      return loadRows(current, { keepPage: false });
    }

    if (target.closest("[data-db-clear-table-search]") && current?.kind === "db") {
      current.tableSearch = "";
      return renderMain();
    }

    const qAction = target.closest("[data-query-action]")?.dataset.queryAction;
    if (qAction && current?.kind === "query") {
      switch (qAction) {
        case "select-table": {
          const tbl = $("[data-query-table]")?.value;
          if (!tbl) return toast("info", "Select a table first");
          const tRef = q(conn(current.conn)?.driver, tbl);
          return insertSqlSnippet(`SELECT * FROM ${tRef} LIMIT 100;`, true);
        }
        case "count-table": {
          const tbl = $("[data-query-table]")?.value;
          if (!tbl) return toast("info", "Select a table first");
          const tRef = q(conn(current.conn)?.driver, tbl);
          return insertSqlSnippet(`SELECT COUNT(*) AS total_rows FROM ${tRef};`, true);
        }
        case "format": {
          const area = $(".sql-editor");
          if (!area || !area.value.trim()) return toast("info", "No SQL to format");
          const formatted = formatSql(area.value);
          area.value = formatted;
          current.sql = formatted;
          return toast("success", "SQL formatted");
        }
        case "history": {
          const r = target.getBoundingClientRect();
          return showQueryHistoryMenu(r.left, r.bottom + 4);
        }
        case "clear": {
          const area = $(".sql-editor");
          if (area) {
            area.value = "";
            current.sql = "";
            area.focus();
          }
          return;
        }
      }
    }

    const snippetBtn = target.closest("[data-sql-snippet]");
    if (snippetBtn && current?.kind === "query") {
      const snippet = snippetBtn.dataset.sqlSnippet;
      if (snippet) insertSqlSnippet(snippet);
      return;
    }

    const diffAction = target.closest("[data-diff]")?.dataset.diff;
    if (diffAction && current?.kind === "diff") {
      switch (diffAction) {
        case "run-compare": return loadDiff(current);
        case "copy-all-sql": {
          if (!current.data?.sync_sql) return;
          try {
            await navigator.clipboard.writeText(current.data.sync_sql);
            toast("success", "Sync SQL copied to clipboard");
          } catch {
            copyText(current.data.sync_sql);
          }
          return;
        }
        case "toggle-all-stmts": {
          const all = (current.data?.statements || []).map((s) => s.id);
          if (current.checkedStatements.size === all.length) current.checkedStatements.clear();
          else current.checkedStatements = new Set(all);
          return renderMain();
        }
        case "sync-selected": {
          const selected = (current.data?.statements || []).filter((s) => current.checkedStatements.has(s.id));
          if (!selected.length) return toast("error", "Select at least one statement to apply");

          const tgtConnObj = S.connections?.find((c) => c.id === current.tgtConn);
          const isMysql = tgtConnObj?.driver === "mysql" || tgtConnObj?.driver === "mariadb";

          const msgHtml = `
            Apply <b>${selected.length}</b> migration statement(s) to <b>${esc(current.tgtDb)}</b>?
            ${isMysql
              ? `<div class="notice danger sm" style="margin-top:10px">⚠️ MySQL/MariaDB performs implicit commits on DDL statements. Changes cannot be rolled back if an error occurs.</div>`
              : `<div class="notice info sm" style="margin-top:10px">ℹ️ Atomic: In PostgreSQL/SQLite, statements run in a transaction and roll back automatically on error.</div>`
            }
          `;

          const ok = await confirmModal({
            title: "Sync to Target Database?",
            message: msgHtml,
            confirm: "Execute Sync",
            danger: isMysql,
          });
          if (!ok) return;

          try {
            const res = await LD.call("db_sync", {
              tgt_conn: current.tgtConn,
              tgt_db: current.tgtDb,
              statements: selected,
              stop_on_error: true,
            });

            if (res.failed > 0) {
              toast("error", `Sync finished with ${res.failed} error(s)`, `${res.executed} succeeded, ${res.failed} failed`);
              const failedItems = (res.results || []).filter((r) => !r.ok);
              openModal(`
                <div class="modal" style="max-width:640px">
                  <div class="modal-header">
                    <h2 style="color:var(--danger)">${icon("alert")} Schema Sync Failed</h2>
                    <p><b>${res.failed}</b> statement(s) failed during execution.</p>
                  </div>
                  <div class="modal-body">
                    ${failedItems.map((f) => `
                      <div style="margin-bottom:12px;background:var(--surface-2);padding:10px;border-radius:6px;border:1px solid var(--border)">
                        <div style="color:var(--danger);font-weight:600;font-size:12.5px;margin-bottom:6px">${esc(f.error)}</div>
                        <pre style="margin:0;font-family:var(--mono);font-size:11.5px;white-space:pre-wrap;color:var(--muted)">${esc(f.sql)}</pre>
                      </div>
                    `).join("")}
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn primary" data-dismiss>Dismiss</button>
                  </div>
                </div>
              `, (mRoot) => {
                $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
              });
            } else {
              toast("success", `Executed all ${res.executed} statement(s) successfully!`);
            }

            await loadDiff(current);
          } catch (err) {
            toast("error", "Sync execution failed", err.message);
          }
          return;
        }
      }
    }

    if (target.closest("[data-copy-sql]")) {
      const sql = target.closest("[data-copy-sql]").dataset.copySql;
      try {
        await navigator.clipboard.writeText(sql);
        toast("success", "Index SQL copied to clipboard");
      } catch {
        copyText(sql);
      }
      return;
    }

    const holo = target.closest("[data-holo]")?.dataset.holo;
    if (holo && current?.kind === "hologram") {
      switch (holo) {
        case "retry":
        case "reload": return loadHologram(current, true);
        case "autolayout": autoLayout(current, true); return renderMain();
        case "toggle-compact": current.compact = !current.compact; return renderMain();
        case "toggle-isolated": current.hideIsolated = !current.hideIsolated; return renderMain();
        case "toggle-minimap": current.showMinimap = current.showMinimap === false; return renderMain();
        case "toggle-legend": current.showLegend = !current.showLegend; return renderMain();
        case "clear-focus": current.selectedTable = null; current.selectedRel = null; return renderMain();
        case "zoom-in": current.zoom = Math.min(2.5, (current.zoom || 1) * 1.2); return updateHologramTransform(current);
        case "zoom-out": current.zoom = Math.max(0.25, (current.zoom || 1) / 1.2); return updateHologramTransform(current);
        case "zoom-reset": current.zoom = 1; current.panX = 60; current.panY = 60; return updateHologramTransform(current);
        case "fit": return fitHologram(current);
        case "export-svg": return exportHologramSvg(current);
        case "export-png": return exportHologramPng(current);
      }
    }

    const holoAction = target.closest("[data-holo-action]")?.dataset.holoAction;
    if (holoAction && current?.kind === "hologram") {
      e.stopPropagation();
      const tb = target.closest("[data-holo-action]").dataset.table;
      if (holoAction === "model") return openModelModal(current.conn, current.db, tb);
      if (holoAction === "migration") return openMigrationModal(current.conn, current.db, tb);
      if (holoAction === "seed") return openSeedModal(current.conn, current.db, tb);
      return openTab({ kind: "table", conn: current.conn, db: current.db, table: tb, sub: holoAction });
    }

    if ((el = target.closest("[data-node]")) && !target.closest("button")) {
      const kind = el.dataset.node;
      const id = el.dataset.conn;
      if (kind === "conn") {
        const node = S.tree[id];
        if (node?.open && !node.error) { node.open = false; return renderTree(); }
        return openConn(id);
      }
      if (kind === "db") {
        const dbn = S.tree[id].dbs[el.dataset.dbname];
        if (dbn?.open) { dbn.open = false; return renderTree(); }
        return openDb(id, el.dataset.dbname);
      }
      if (kind === "table") return openTab({ kind: "table", conn: id, db: el.dataset.dbname, table: el.dataset.table });
    }

    if ((el = target.closest("[data-sub]"))) { current.sub = el.dataset.sub; return renderMain(); }
    if ((el = target.closest("[data-result]"))) { current.resultIndex = +el.dataset.result; return renderMain(); }
    if ((el = target.closest("[data-sort]"))) {
      const col = el.dataset.sort;
      current.dir = current.sort === col && current.dir === "ASC" ? "DESC" : "ASC";
      current.sort = col;
      return loadRows(current);
    }
    if ((el = target.closest("[data-page]"))) {
      const d = current.data;
      current.page = { first: 1, prev: d.page - 1, next: d.page + 1, last: d.pages }[el.dataset.page];
      return loadRows(current);
    }
    if (target.closest("[data-select-all]")) {
      const all = current.data.rows.map((_, i) => i);
      current.selected = current.selected.size === all.length ? new Set() : new Set(all);
      return renderMain();
    }
    if ((el = target.closest("[data-select-row]"))) {
      const ri = +el.closest("tr").dataset.row;
      if (e.shiftKey && current.lastSelected !== undefined) {
        const [a, b] = [current.lastSelected, ri].sort((x, y) => x - y);
        for (let i = a; i <= b; i++) current.selected.add(i);
      } else if (e.ctrlKey || e.metaKey) {
        current.selected.has(ri) ? current.selected.delete(ri) : current.selected.add(ri);
      } else {
        current.selected = current.selected.has(ri) && current.selected.size === 1 ? new Set() : new Set([ri]);
      }
      current.lastSelected = ri;
      return renderMain();
    }
  });

  document.addEventListener("dblclick", (e) => {
    const td = e.target.closest("#view-database td[data-cell], #view-database td[data-new-cell]");
    if (td && !td.classList.contains("editing")) startEdit(td);
    const card = e.target.closest("#view-database .hologram-card");
    const current = tab();
    if (card && current?.kind === "hologram") {
      const tb = card.dataset.table;
      if (tb) openTab({ kind: "table", conn: current.conn, db: current.db, table: tb, sub: "data" });
    }
  });

  document.addEventListener("contextmenu", (e) => {
    const target = e.target;
    if (!inDb(target)) return;
    const current = tab();
    const td = target.closest("td[data-cell]");
    if (td && current?.kind === "table") {
      e.preventDefault();
      return showMenu(e.clientX, e.clientY, cellMenu(current, +td.closest("tr").dataset.row, +td.dataset.cell));
    }
    const holoCard = target.closest("#view-database .hologram-card");
    if (holoCard && current?.kind === "hologram") {
      e.preventDefault();
      const tb = holoCard.dataset.table;
      return showMenu(e.clientX, e.clientY, [
        { label: `Table: ${tb}`, icon: "grid", run: () => openTab({ kind: "table", conn: current.conn, db: current.db, table: tb, sub: "data" }) },
        { label: "View Structure", icon: "wrench", run: () => openTab({ kind: "table", conn: current.conn, db: current.db, table: tb, sub: "structure" }) },
        "-",
        { label: "Generate Eloquent Model…", icon: "code", run: () => openModelModal(current.conn, current.db, tb) },
        { label: "Generate Migration…", icon: "file", run: () => openMigrationModal(current.conn, current.db, tb) },
        { label: "Seed Dummy Data…", icon: "zap", run: () => openSeedModal(current.conn, current.db, tb) },
      ]);
    }
    const node = target.closest("[data-node]");
    if (node) {
      e.preventDefault();
      const c = conn(node.dataset.conn);
      const items = node.dataset.node === "conn" ? connMenu(c) : node.dataset.node === "db" ? dbMenu(c, node.dataset.dbname) : tableMenu(c, node.dataset.dbname, node.dataset.table);
      showMenu(e.clientX, e.clientY, items);
    }
  });

  document.addEventListener("submit", (e) => {
    if (!e.target.matches("#view-database [data-where-form]")) return;
    e.preventDefault();
    const curTab = tab();
    curTab.where = e.target.elements.where.value.trim();
    loadRows(curTab, { keepPage: false });
  });

  let searchTimer = null;
  document.addEventListener("input", (e) => {
    const target = e.target;
    if (target.matches("#view-database [data-db-filter]")) {
      S.filter = target.value;
      return renderTree();
    }
    if (target.matches("#view-database [data-db-table-search]")) {
      const current = tab();
      if (current?.kind === "db") {
        current.tableSearch = target.value;
        renderMain();
        const box = $("#view-database [data-db-table-search]");
        if (box) { box.focus(); box.setSelectionRange(box.value.length, box.value.length); }
      }
      return;
    }
    if (target.matches("#view-database [data-row-search]")) {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        const current = tab();
        current.search = target.value;
        loadRows(current, { keepPage: false }).then(() => {
          const box = $("#view-database [data-row-search]");
          if (box) { box.focus(); box.setSelectionRange(box.value.length, box.value.length); }
        });
      }, 350);
    }
    if (target.matches("#view-database .sql-editor")) {
      const current = tab();
      if (current?.kind === "query") current.sql = target.value;
    }
  });

  document.addEventListener("change", async (e) => {
    const target = e.target;
    if (!inDb(target)) return;
    const current = tab();
    if (target.matches("[data-page-size]")) { current.limit = +target.value; return loadRows(current, { keepPage: false }); }
    if (target.matches("[data-page-input]")) {
      current.page = Math.min(Math.max(1, +target.value || 1), current.data.pages);
      return loadRows(current);
    }
    if (target.matches("[data-query-conn]")) {
      current.conn = target.value;
      current.db = conn(target.value)?.database || (conn(target.value)?.driver === "sqlite" ? "main" : "");
      if (!S.tree[target.value]?.databases) await openConn(target.value, { quiet: true });
      $("#dbm-content").innerHTML = queryTab(current);
      $(".sql-editor").value = current.sql;
      return;
    }
    if (target.matches("[data-query-db]")) current.db = target.value;
    if (target.matches("[data-query-template]") && current?.kind === "query") {
      if (target.value) {
        applyQueryTemplate(target.value);
        target.value = "";
      }
      return;
    }
    if (target.matches("[data-flt-op]")) {
      const valInp = $("[data-flt-value]");
      if (valInp) {
        valInp.disabled = target.value.includes("NULL");
        if (target.value.includes("NULL")) valInp.value = "";
      }
      return;
    }
  });

  document.addEventListener("keydown", (e) => {
    if (state.view !== "database" || !$("#modal-root").hidden) return;
    const current = tab();
    const ctrl = e.ctrlKey || e.metaKey;
    if (e.key === "Enter" && e.target.matches("[data-flt-value]")) {
      e.preventDefault();
      $("[data-db='add-filter']")?.click();
      return;
    }
    if (e.target.matches(".sql-editor")) {
      if (ctrl && e.key === "Enter") { e.preventDefault(); return runQuery(current); }
      if (e.key === "Tab") {
        e.preventDefault();
        const a = e.target;
        const s = a.selectionStart;
        a.setRangeText("  ", s, a.selectionEnd, "end");
        current.sql = a.value;
      }
      return;
    }
    if (ctrl && e.key.toLowerCase() === "s" && current?.kind === "table") { e.preventDefault(); return saveChanges(current); }
    if (ctrl && e.key.toLowerCase() === "t") { e.preventDefault(); $("[data-db='new-query']")?.click(); return; }
    if (ctrl && e.key.toLowerCase() === "w" && current) { e.preventDefault(); return closeTab(current.id); }
    if (e.key === "F5" && current?.kind === "table") { e.preventDefault(); return loadRows(current); }
    if (e.key === "Delete" && current?.kind === "table" && current.selected.size && !e.target.matches("input, textarea")) {
      e.preventDefault();
      current.selected.forEach((ri) => current.deletes.add(ri));
      current.selected = new Set();
      renderTabs();
      return renderMain();
    }
    if (e.key === "Escape") {
      hideMenu();
      if (current?.kind === "hologram" && (current.selectedTable || current.selectedRel)) {
        current.selectedTable = null;
        current.selectedRel = null;
        renderMain();
      }
    }
  });

  window.addEventListener("blur", hideMenu);

  /* ── public ─────────────────────────────────────────────── */
  async function ensureLoaded() {
    if (!S.loaded) await loadConns();
  }

  return {
    async show() {
      render();
      await ensureLoaded();
      render();
    },
    dirty: () => S.tabs.some((t) => pendingCount(t)),
    async open(connId, db) {
      await loadConns(true);
      render();
      if (!conn(connId)) return toast("error", "Connection not found");
      await openConn(connId, { quiet: false });
      if (db) {
        await openDb(connId, db);
        openTab({ kind: "db", conn: connId, db });
      }
    },
    async openSite(name) {
      try {
        const target = await LD.call("db_for_site", { name });
        await this.open(target.conn, target.database);
      } catch (err) {
        toast("error", "No database for this project", err.message);
      }
    },
    onEvent(event) {
      if (event.type === "db-progress") {
        const el = $("#db-job");
        const text = `${event.kind === "export" ? "Exporting" : "Importing"}… ${event.count.toLocaleString()} ${event.kind === "export" ? "rows" : "statements"}`;
        if (el) el.textContent = text;
        else { const n = document.createElement("div"); n.id = "db-job"; n.className = "db-job"; n.textContent = text; document.body.append(n); }
      }
      if (event.type === "db-job") {
        $("#db-job")?.remove();
        event.ok ? toast("success", event.label, `${event.count.toLocaleString()} ${event.kind === "export" ? "rows" : "statements"}`)
                 : toast("error", event.kind === "export" ? "Export failed" : "Import failed", event.error);
        if (event.ok && event.kind === "import") {
          for (const [id, node] of Object.entries(S.tree)) for (const [db, dbn] of Object.entries(node.dbs || {})) if (dbn.open) openDb(id, db, true);
        }
      }
    },
  };
})();
window.Database = Database;
