#!/usr/bin/env bash

set -euo pipefail

sudo rm -rf /opt/laravel-dev
sudo rm -f /usr/local/bin/laravel-dev /usr/bin/laravel-dev
sudo rm -f /usr/share/applications/laravel-dev.desktop
rm -f "${XDG_DATA_HOME:-$HOME/.local/share}/applications/laravel-dev.desktop"
rm -f "${XDG_CONFIG_HOME:-$HOME/.config}/autostart/laravel-dev.desktop"
if command -v update-desktop-database >/dev/null 2>&1; then
  sudo update-desktop-database /usr/share/applications >/dev/null 2>&1 || true
fi

# Scheduler entries (core/CronManager.sh) and queue workers (core/SupervisorManager.sh)
if command -v crontab >/dev/null 2>&1 && crontab -l 2>/dev/null | grep -q '# laravel-dev:'; then
  remaining="$(crontab -l 2>/dev/null | grep -v '# laravel-dev:[A-Za-z0-9._-]*\(:backup\)\?$' || true)"
  if [[ -n "$remaining" ]]; then printf '%s\n' "$remaining" | crontab -; else crontab -r || true; fi
fi
if compgen -G "/etc/supervisor/conf.d/laravel-dev-*.conf" >/dev/null; then
  sudo rm -f /etc/supervisor/conf.d/laravel-dev-*.conf
  sudo supervisorctl reread >/dev/null 2>&1 || true
  sudo supervisorctl update >/dev/null 2>&1 || true
fi

echo "Laravel Dev removed"
