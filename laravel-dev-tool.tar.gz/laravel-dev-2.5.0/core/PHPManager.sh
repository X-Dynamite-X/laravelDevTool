#!/usr/bin/env bash

set -euo pipefail

normalize_php_version() {
  local version="$1"
  if [[ "$version" =~ ^[0-9]+\.[0-9]+$ ]]; then
    echo "$version"
    return 0
  fi
  if [[ "$version" =~ ^php([0-9]+\.[0-9]+)$ ]]; then
    echo "${BASH_REMATCH[1]}"
    return 0
  fi
  echo ""
}

list_available_php_versions() {
  local versions=()
  local cmd=""
  local version=""
  local sock=""

  if command -v php >/dev/null 2>&1; then
    version="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  fi

  while IFS= read -r cmd; do
    version="$(normalize_php_version "${cmd##*/}")"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  done < <(compgen -c | grep -E '^php[0-9]+\.[0-9]+$' | sort -u || true)

  for remi_bin in /opt/remi/php*/root/usr/bin/php; do
    if [[ -x "$remi_bin" ]]; then
      version="$("$remi_bin" -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
      if [[ -n "$version" ]]; then
        versions+=("$version")
      fi
    fi
  done

  while IFS= read -r sock; do
    version="$(printf '%s\n' "$sock" | sed -nE 's#.*php([0-9]+\.[0-9]+)-fpm\.sock#\1#p')"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  done < <(find /run/php /run/php-fpm -maxdepth 1 -type s -name 'php*-fpm.sock' 2>/dev/null || true)

  if [[ ${#versions[@]} -eq 0 ]]; then
    echo "8.4"
    return 0
  fi

  printf '%s\n' "${versions[@]}" | awk 'NF' | sort -Vu | uniq
}

list_php_fpm_services() {
  local units=()

  if command -v systemctl >/dev/null 2>&1; then
    while IFS= read -r unit; do
      unit="${unit%.service}"
      [[ -n "$unit" ]] && units+=("$unit")
    done < <(systemctl list-unit-files --type=service --no-legend 2>/dev/null | awk '{print $1}' | grep -E '^php.*fpm\.service$' | sort -u || true)
  fi

  if [[ ${#units[@]} -eq 0 ]]; then
    units+=(php-fpm)
  fi

  printf '%s\n' "${units[@]}" | awk 'NF' | sort -u
}

default_php_version() {
  local v
  local best=""
  # Prefer the newest PHP version that has mbstring extension installed and working
  while IFS= read -r v; do
    [[ -n "$v" ]] || continue
    if command -v "php${v}" >/dev/null 2>&1; then
      if "php${v}" -m 2>/dev/null | grep -qi 'mbstring'; then
        best="$v"
      fi
    fi
  done < <(list_available_php_versions)

  if [[ -n "$best" ]]; then
    echo "$best"
    return 0
  fi

  list_available_php_versions | tail -n1
}

get_php_socket() {
  local version="${1:-$(default_php_version)}"
  local nodot="${version//./}"
  local candidates=(
    "/run/php/php${version}-fpm.sock"
    "/run/php-fpm/php${version}-fpm.sock"
    "/var/opt/remi/php${nodot}/run/php-fpm/www.sock"
    "/run/php-fpm/www.sock"
    "/run/php-fpm/php-fpm.sock"
  )
  local sock=""

  for sock in "${candidates[@]}"; do
    if [[ -S "$sock" ]]; then
      echo "$sock"
      return 0
    fi
  done

  if [[ ! -d /run/php && -d /run/php-fpm ]]; then
    echo "/run/php-fpm/php${version}-fpm.sock"
  else
    echo "/run/php/php${version}-fpm.sock"
  fi
}

php_fpm_pool_dir() {
  local version="$1"
  local nodot="${version//./}"
  local candidates=(
    "/etc/php/${version}/fpm/pool.d"
    "/etc/php-fpm.d"
    "/etc/php/php-fpm.d"
    "/var/opt/remi/php${nodot}/etc/php-fpm.d"
  )
  local c
  for c in "${candidates[@]}"; do
    if [[ -d "$c" ]]; then
      echo "$c"
      return 0
    fi
  done
  return 1
}

# ---------------------------------------------------------------------------
# On-demand Xdebug.
#
# A PHP-FPM pool always shares the php.ini of its master process, and Xdebug is a
# zend_extension: it can't be loaded for one pool only. So the debug pool is a
# second, independent PHP-FPM master (its own systemd unit) that loads the normal
# php.ini + conf.d *plus* an extra scan dir holding Xdebug. nginx sends a request
# there only when it carries an Xdebug trigger (XDEBUG_SESSION cookie from the
# browser extension, ?XDEBUG_SESSION_START, XDEBUG_TRIGGER...). Every other
# request goes to the regular FPM, which runs without Xdebug at full speed.
# ---------------------------------------------------------------------------

php_debug_dir() { echo "/etc/laravel-dev/php/$1"; }
php_debug_unit() { echo "laravel-dev-php$1-fpm-debug"; }
php_debug_runtime_dir() { echo "/run/laravel-dev-php$1-debug"; }

get_php_debug_socket() {
  local version="${1:-$(default_php_version)}"
  echo "$(php_debug_runtime_dir "$version")/fpm.sock"
}

php_fpm_debug_pool_enabled() {
  [[ -f "$(php_debug_dir "$1")/php-fpm-debug.conf" ]]
}

# The php-fpm binary of a given version (Debian/Ubuntu, Remi, Fedora/Arch single version).
php_fpm_binary() {
  local version="$1"
  local nodot="${version//./}"
  local c
  for c in "php-fpm${version}" "/usr/sbin/php-fpm${version}" "/opt/remi/php${nodot}/root/usr/sbin/php-fpm"; do
    if command -v "$c" >/dev/null 2>&1; then
      command -v "$c"
      return 0
    fi
  done
  for c in php-fpm /usr/sbin/php-fpm /usr/bin/php-fpm; do
    if command -v "$c" >/dev/null 2>&1 \
      && env -u PHP_INI_SCAN_DIR "$c" -v 2>/dev/null | head -1 | grep -q "^PHP ${version//./\\.}\."; then
      command -v "$c"
      return 0
    fi
  done
  return 1
}

# Does the regular PHP-FPM (not the debug one) load Xdebug?
php_fpm_main_has_xdebug() {
  local bin
  bin="$(php_fpm_binary "$1")" || return 1
  env -u PHP_INI_SCAN_DIR "$bin" -m 2>/dev/null | grep -qx "Xdebug"
}

php_xdebug_so_exists() {
  local bin ext_dir
  bin="$(php_fpm_binary "$1")" || return 1
  ext_dir="$(env -u PHP_INI_SCAN_DIR "$bin" -i 2>/dev/null | sed -nE 's/^extension_dir => ([^ ]+).*/\1/p' | head -1)"
  [[ -n "$ext_dir" && -f "$ext_dir/xdebug.so" ]]
}

php_debug_service_running() {
  local version="$1"
  if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
    systemctl is-active --quiet "$(php_debug_unit "$version")"
  else
    [[ -S "$(get_php_debug_socket "$version")" ]]
  fi
}

# Older releases put the debug pool inside the regular FPM master (which loaded
# Xdebug for every pool). Remove those files; returns 0 when something was removed.
_php_debug_remove_legacy_pools() {
  local version="$1" pool_dir removed=1
  pool_dir="$(php_fpm_pool_dir "$version" 2>/dev/null || true)"
  [[ -n "$pool_dir" ]] || return 1
  if [[ -f "${pool_dir}/laravel-dev-debug-${version}.conf" ]]; then
    sudo_cmd rm -f "${pool_dir}/laravel-dev-debug-${version}.conf"
    removed=0
  fi
  if [[ -f "${pool_dir}/laravel-dev-debug.conf" ]] && grep -qs "\[laravel-dev-debug-${version}\]" "${pool_dir}/laravel-dev-debug.conf"; then
    sudo_cmd rm -f "${pool_dir}/laravel-dev-debug.conf"
    removed=0
  fi
  return "$removed"
}

php_fpm_unit() {
  local version="$1"
  if command -v systemctl >/dev/null 2>&1; then
    if systemctl list-unit-files --type=service 2>/dev/null | grep -q "php${version}-fpm\.service"; then
      echo "php${version}-fpm"
      return 0
    elif systemctl list-unit-files --type=service 2>/dev/null | grep -q "php-fpm\.service"; then
      echo "php-fpm"
      return 0
    fi
  fi
  echo "php${version}-fpm"
}

restart_php_fpm() {
  local version="$1"
  local unit
  unit="$(php_fpm_unit "$version")"
  if command -v systemctl >/dev/null 2>&1; then
    sudo_cmd systemctl restart "$unit" >/dev/null 2>&1 || sudo_cmd service "$unit" restart >/dev/null 2>&1 || true
  fi
}

php_xdebug_status() {
  local version="$1"
  local bin="php${version}"
  command -v "$bin" >/dev/null 2>&1 || bin="php"
  if "$bin" -m 2>/dev/null | grep -qi "xdebug"; then
    echo "on"
  else
    echo "off"
  fi
}

php_xdebug_toggle() {
  local version="$1"
  local state="$2" # on | off
  require_system_access

  if command -v phpenmod >/dev/null 2>&1 && command -v phpdismod >/dev/null 2>&1; then
    if [[ "$state" == "on" ]]; then
      sudo_cmd phpenmod -v "$version" xdebug || true
    else
      sudo_cmd phpdismod -v "$version" xdebug || true
    fi
  else
    local inis=(
      "/etc/php/${version}/mods-available/xdebug.ini"
      "/etc/php/${version}/conf.d/xdebug.ini"
    )
    local extra
    for extra in /etc/php.d/*xdebug.ini /etc/php/conf.d/*xdebug.ini; do  # Fedora / Arch
      inis+=("$extra")
    done
    for f in "${inis[@]}"; do
      if [[ -f "$f" ]]; then
        if [[ "$state" == "on" ]]; then
          sudo_cmd sed -i 's/^;zend_extension/zend_extension/' "$f"
        else
          sudo_cmd sed -i 's/^zend_extension/;zend_extension/' "$f"
        fi
      fi
    done
  fi
  restart_php_fpm "$version"
  echo "Xdebug is now $state for PHP $version"
}

php_xdebug_configure_jit() {
  local version="$1"
  require_system_access

  # First make sure xdebug is enabled
  php_xdebug_toggle "$version" "on" >/dev/null 2>&1 || true

  local candidates=(
    "/etc/php/${version}/mods-available/xdebug.ini"
    "/etc/php/${version}/conf.d/xdebug.ini"
    "/etc/php/${version}/fpm/conf.d/20-xdebug.ini"
    "/etc/php/${version}/cli/conf.d/20-xdebug.ini"
  )
  local extra
  for extra in /etc/php.d/*xdebug.ini /etc/php/conf.d/*xdebug.ini; do
    candidates+=("$extra")
  done

  # Resolve symlinks and de-duplicate: on Debian/Ubuntu conf.d/20-xdebug.ini is a symlink to
  # mods-available/xdebug.ini, and `sed -i` on the link would replace it with a plain copy,
  # after which phpdismod can no longer turn Xdebug off.
  local -A seen=()
  local inis=() f real
  for f in "${candidates[@]}"; do
    [[ -e "$f" ]] || continue
    real="$(readlink -f "$f")"
    [[ -f "$real" && -z "${seen[$real]:-}" ]] || continue
    seen[$real]=1
    inis+=("$real")
  done

  if [[ ${#inis[@]} -eq 0 ]]; then
    echo "Error: no xdebug.ini found for PHP $version. Install it first: laravel-dev php-ext $version install xdebug"
    return 1
  fi

  local settings=(
    "xdebug.mode=develop,debug"
    "xdebug.start_with_request=trigger"
    "xdebug.trigger_value=LARAVEL_DEV"
    "xdebug.client_host=127.0.0.1"
    "xdebug.client_port=9003"
  )
  local kv key val
  for f in "${inis[@]}"; do
    for kv in "${settings[@]}"; do
      key="${kv%%=*}"
      val="${kv#*=}"
      if grep -qE "^[;[:space:]]*${key//./\\.}[[:space:]]*=" "$f"; then
        sudo_cmd sed -i -E "s|^[;[:space:]]*${key//./\\.}[[:space:]]*=.*|${key} = ${val}|" "$f"
      else
        echo "${key} = ${val}" | sudo_cmd tee -a "$f" >/dev/null
      fi
    done
  done

  restart_php_fpm "$version"
  echo "Xdebug configured in JIT (Just-In-Time trigger) mode for PHP $version."
  echo "Debug a web request: add ?XDEBUG_TRIGGER=LARAVEL_DEV or set the XDEBUG_TRIGGER=LARAVEL_DEV cookie."
  echo "Debug artisan:       laravel-dev debug <project> artisan <command>"
}

# $1 = "migrate": also switch existing site vhosts to the routable FPM variable.
_php_debug_sync_nginx() {
  local migrate="${1:-}"
  if ! declare -F ensure_nginx_perf_logging >/dev/null 2>&1 && [[ -f "${BASE_DIR:-}/core/NginxManager.sh" ]]; then
    # shellcheck disable=SC1091
    source "${BASE_DIR}/core/NginxManager.sh"
  fi
  declare -F ensure_nginx_perf_logging >/dev/null 2>&1 || return 0

  local backup="" migrated=0 name conf
  if [[ "$migrate" == "migrate" ]] && declare -F nginx_route_sites_through_fpm_maps >/dev/null 2>&1 \
    && declare -F list_registered_project_names >/dev/null 2>&1; then
    backup="$(mktemp -d)"
    while IFS= read -r name; do
      conf="$(get_nginx_config_path "$name")"
      [[ -n "$name" && -f "$conf" ]] && sudo_cmd cat "$conf" > "$backup/$name" 2>/dev/null || true
    done < <(list_registered_project_names 2>/dev/null)
    migrated="$(nginx_route_sites_through_fpm_maps)"
  fi

  ensure_nginx_perf_logging || true
  if command -v nginx >/dev/null 2>&1; then
    if sudo_cmd nginx -t >/dev/null 2>&1; then
      sudo_cmd systemctl reload nginx >/dev/null 2>&1 || sudo_cmd nginx -s reload >/dev/null 2>&1 || true
      [[ "$migrated" -gt 0 ]] && echo "Updated $migrated site config(s) so their PHP requests can be routed to the debug FPM."
    else
      if [[ -n "$backup" && "$migrated" -gt 0 ]]; then
        for conf in "$backup"/*; do
          [[ -f "$conf" ]] || continue
          sudo_cmd tee "$(get_nginx_config_path "$(basename "$conf")")" < "$conf" >/dev/null
        done
        echo "Warning: nginx -t failed after updating site configs; they were restored." >&2
      else
        echo "Warning: nginx -t failed; nginx was not reloaded." >&2
      fi
    fi
  fi
  [[ -n "$backup" ]] && rm -rf -- "$backup"
  return 0
}

_php_debug_status() {
  local version="$1" sock
  sock="$(get_php_debug_socket "$version")"
  if ! php_fpm_debug_pool_enabled "$version"; then
    echo "Xdebug on demand for PHP $version: disabled"
    return 1
  fi
  if php_debug_service_running "$version"; then
    echo "Xdebug on demand for PHP $version: enabled, running ($sock)"
  else
    echo "Xdebug on demand for PHP $version: enabled, NOT running (start it: laravel-dev php-debug-pool $version enable)"
  fi
  if php_fpm_main_has_xdebug "$version"; then
    echo "Note: the regular PHP $version FPM still loads Xdebug, so normal requests are slower than they need to be."
  else
    echo "Regular PHP $version FPM runs without Xdebug."
  fi
  return 0
}

_php_debug_disable() {
  local version="$1" dir unit
  dir="$(php_debug_dir "$version")"
  unit="$(php_debug_unit "$version")"
  require_system_access

  if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
    sudo_cmd systemctl disable --now "$unit" >/dev/null 2>&1 || true
  elif [[ -f "$(php_debug_runtime_dir "$version")/fpm.pid" ]]; then
    sudo_cmd kill "$(cat "$(php_debug_runtime_dir "$version")/fpm.pid")" 2>/dev/null || true
  fi
  if [[ -f "/etc/systemd/system/${unit}.service" ]]; then
    sudo_cmd rm -f "/etc/systemd/system/${unit}.service"
    sudo_cmd systemctl daemon-reload >/dev/null 2>&1 || true
  fi

  # Give the regular FPM its Xdebug back if we were the ones who took it away.
  local restart_main=0
  if [[ -f "$dir/restore-fpm-xdebug" ]] && command -v phpenmod >/dev/null 2>&1; then
    sudo_cmd phpenmod -v "$version" -s fpm xdebug || true
    restart_main=1
  fi
  _php_debug_remove_legacy_pools "$version" && restart_main=1
  sudo_cmd rm -rf "$dir"
  [[ "$restart_main" == "1" ]] && restart_php_fpm "$version"

  _php_debug_sync_nginx
  echo "Xdebug on demand for PHP $version disabled."
}

_php_debug_enable() {
  local version="$1"
  local dir unit sock run_dir fpm_bin
  dir="$(php_debug_dir "$version")"
  unit="$(php_debug_unit "$version")"
  sock="$(get_php_debug_socket "$version")"
  run_dir="$(php_debug_runtime_dir "$version")"

  if ! fpm_bin="$(php_fpm_binary "$version")"; then
    echo "Error: php-fpm for PHP $version not found. Install php${version}-fpm first." >&2
    return 1
  fi
  if ! php_xdebug_so_exists "$version"; then
    echo "Error: Xdebug is not installed for PHP $version. Install it first: laravel-dev php-ext $version install xdebug" >&2
    return 1
  fi
  require_system_access

  local user="www-data" group="www-data"
  id -u www-data >/dev/null 2>&1 || { user="nginx"; group="nginx"; }
  id -u "$user" >/dev/null 2>&1 || { user="http"; group="http"; }   # Arch

  sudo_cmd mkdir -p "$dir/conf.d"
  # Loaded after the normal conf.d, so these values win over a global xdebug.ini
  # (for example the trigger_value written by `php-jit`). Loading Xdebug twice only
  # logs a harmless "already loaded" notice.
  sudo_cmd tee "$dir/conf.d/99-laravel-dev-xdebug.ini" >/dev/null <<EOF
; Managed by Laravel Dev: Xdebug for the on-demand debug PHP-FPM only.
zend_extension = xdebug
xdebug.mode = debug,develop
xdebug.start_with_request = trigger
xdebug.trigger_value = ""
xdebug.client_host = 127.0.0.1
xdebug.client_port = 9003
EOF

  sudo_cmd tee "$dir/php-fpm-debug.conf" >/dev/null <<EOF
; Managed by Laravel Dev: independent PHP-FPM master with Xdebug for PHP $version.
[global]
pid = $run_dir/fpm.pid
error_log = /var/log/laravel-dev-php${version}-fpm-debug.log
daemonize = no

[laravel-dev-debug]
user = $user
group = $group
listen = $sock
listen.owner = $user
listen.group = $group
listen.mode = 0660
pm = ondemand
pm.max_children = 5
pm.process_idle_timeout = 60s
; A paused breakpoint must not be killed by a timeout.
request_terminate_timeout = 0
php_admin_value[max_execution_time] = 0
EOF

  if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
    sudo_cmd tee "/etc/systemd/system/${unit}.service" >/dev/null <<EOF
[Unit]
Description=Laravel Dev PHP $version FPM with Xdebug (on demand)
After=network.target

[Service]
Type=simple
RuntimeDirectory=laravel-dev-php${version}-debug
RuntimeDirectoryMode=0755
Environment=PHP_INI_SCAN_DIR=:$dir/conf.d
ExecStart=$fpm_bin --nodaemonize --fpm-config $dir/php-fpm-debug.conf
ExecReload=/bin/kill -USR2 \$MAINPID
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    sudo_cmd systemctl daemon-reload
    sudo_cmd systemctl enable "$unit" >/dev/null 2>&1 || true
    sudo_cmd systemctl restart "$unit" || true
  else
    # No systemd: start it by hand (it won't come back after a reboot).
    sudo_cmd mkdir -p "$run_dir"
    [[ -f "$run_dir/fpm.pid" ]] && sudo_cmd kill "$(cat "$run_dir/fpm.pid")" 2>/dev/null || true
    sudo_cmd env PHP_INI_SCAN_DIR=":$dir/conf.d" "$fpm_bin" --daemonize --fpm-config "$dir/php-fpm-debug.conf" || true
  fi

  local i
  for i in 1 2 3 4 5 6 7 8 9 10; do
    [[ -S "$sock" ]] && break
    sleep 0.3
  done
  if [[ ! -S "$sock" ]]; then
    echo "Error: the debug PHP-FPM did not start. See: journalctl -u $unit, /var/log/laravel-dev-php${version}-fpm-debug.log" >&2
    return 1
  fi

  # The point of all this: the regular FPM should not pay for Xdebug.
  local restart_main=0
  _php_debug_remove_legacy_pools "$version" && restart_main=1
  if php_fpm_main_has_xdebug "$version"; then
    if command -v phpdismod >/dev/null 2>&1; then
      sudo_cmd phpdismod -v "$version" -s fpm xdebug || true
      sudo_cmd touch "$dir/restore-fpm-xdebug"
      restart_main=1
      echo "Xdebug unloaded from the regular PHP $version FPM (CLI keeps it; disabling the debug pool restores it)."
    else
      echo "Note: the regular PHP $version FPM also loads Xdebug (its xdebug.ini is shared by every SAPI)."
      echo "      Comment out zend_extension in it to make normal requests faster; the debug pool still works."
    fi
  fi
  [[ "$restart_main" == "1" ]] && restart_php_fpm "$version"

  _php_debug_sync_nginx migrate
  echo "Xdebug on demand enabled for PHP $version ($sock)."
  echo "Requests with an Xdebug trigger go to the debug FPM: the XDEBUG_SESSION cookie (Xdebug Helper"
  echo "browser extension), ?XDEBUG_SESSION_START=1 or XDEBUG_TRIGGER. All other requests skip Xdebug."
  echo "Your IDE must listen on port 9003."
}

php_fpm_manage_debug_pool() {
  local version="$1"
  local action="${2:-enable}" # enable | disable | status
  if [[ ! "$version" =~ ^[0-9]+\.[0-9]+$ ]]; then
    echo "Error: invalid PHP version '$version' (expected e.g. 8.4)." >&2
    return 1
  fi
  case "$action" in
    status) _php_debug_status "$version" ;;
    disable) _php_debug_disable "$version" ;;
    enable) _php_debug_enable "$version" ;;
    *)
      echo "Usage: laravel-dev php-debug-pool <version> [enable|disable|status]" >&2
      return 1
      ;;
  esac
}

php_coverage_command() {
  local project="$1"
  shift || true

  local project_path
  project_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$project_path" || ! -d "$project_path" ]]; then
    project_path="${SITES_DIR:-$HOME/Sites}/$project"
  fi
  if [[ ! -d "$project_path" ]]; then
    echo "Error: Project directory '$project_path' not found." >&2
    return 1
  fi

  local version
  version="$(get_project_php_version "$project" 2>/dev/null || echo "8.3")"
  local bin="php${version}"
  command -v "$bin" >/dev/null 2>&1 || bin="php"

  local cmd=()
  if [[ $# -eq 0 ]]; then
    if [[ -f "$project_path/artisan" ]]; then
      cmd=("$bin" "artisan" "test" "--coverage")
    elif [[ -x "$project_path/vendor/bin/pest" ]]; then
      cmd=("$bin" "$project_path/vendor/bin/pest" "--coverage")
    elif [[ -x "$project_path/vendor/bin/phpunit" ]]; then
      cmd=("$bin" "$project_path/vendor/bin/phpunit" "--coverage")
    else
      cmd=("$bin" "artisan" "test" "--coverage")
    fi
  else
    if [[ "$1" == "artisan" ]]; then
      shift
      cmd=("$bin" "artisan" "$@")
    elif [[ "$1" == "pest" ]]; then
      shift
      cmd=("$bin" "$project_path/vendor/bin/pest" "$@")
    elif [[ "$1" == "phpunit" ]]; then
      shift
      cmd=("$bin" "$project_path/vendor/bin/phpunit" "$@")
    else
      cmd=("$@")
    fi
  fi

  echo "Running test coverage with Xdebug for '$project' (PHP $version)..."
  (
    cd "$project_path"
    export XDEBUG_MODE=coverage
    exec "${cmd[@]}"
  )
}

php_debug_artisan() {
  local project="$1"
  shift

  local project_path
  project_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$project_path" || ! -d "$project_path" ]]; then
    project_path="$SITES_DIR/$project"
  fi

  if [[ ! -d "$project_path" ]]; then
    echo "Error: Project directory '$project_path' not found."
    return 1
  fi

  local php_version
  php_version="$(get_project_php_version "$project" 2>/dev/null || echo "")"
  local php_bin="php"
  if [[ -n "$php_version" ]] && command -v "php$php_version" >/dev/null 2>&1; then
    php_bin="php$php_version"
  fi

  echo "Starting artisan command with Xdebug trigger enabled..."
  (cd "$project_path" && XDEBUG_TRIGGER="LARAVEL_DEV" XDEBUG_SESSION="LARAVEL_DEV" "$php_bin" artisan "$@")
}

php_ini_get() {
  local version="$1"
  local key="$2"
  local bin="php${version}"
  command -v "$bin" >/dev/null 2>&1 || bin="php"
  "$bin" -r "echo ini_get('$key');" 2>/dev/null || true
}

php_ini_set() {
  local version="$1"
  local key="$2"
  local value="$3"
  require_system_access

  local targets=(
    "/etc/php/${version}/fpm/conf.d/99-laravel-dev.ini"
    "/etc/php/${version}/cli/conf.d/99-laravel-dev.ini"
  )
  for t in "${targets[@]}"; do
    local dir="${t%/*}"
    if [[ -d "$dir" ]]; then
      sudo_cmd mkdir -p "$dir"
      if sudo_cmd grep -qE "^${key}\s*=" "$t" 2>/dev/null; then
        sudo_cmd sed -i "s|^${key}\s*=.*|${key} = ${value}|" "$t"
      else
        echo "${key} = ${value}" | sudo_cmd tee -a "$t" >/dev/null
      fi
    fi
  done
  restart_php_fpm "$version"
  echo "Updated $key = $value for PHP $version"
}

php_ext_install() {
  local version="$1"
  local ext="$2"
  require_system_access

  if command -v apt-get >/dev/null 2>&1; then
    sudo_cmd apt-get update -qq
    sudo_cmd apt-get install -y "php${version}-${ext}" || sudo_cmd apt-get install -y "php-${ext}"
  elif command -v dnf >/dev/null 2>&1; then
    sudo_cmd dnf install -y "php-${ext}" || sudo_cmd dnf install -y "php${version}-${ext}"
  elif command -v pacman >/dev/null 2>&1; then
    sudo_cmd pacman -S --noconfirm "php-${ext}"
  fi
  restart_php_fpm "$version"
  echo "Installed extension $ext for PHP $version"
}

ensure_php_apt_repo() {
  local os_id=""
  if [[ -f /etc/os-release ]]; then
    # shellcheck source=/dev/null
    os_id="$(grep -E '^ID=' /etc/os-release | cut -d= -f2 | tr -d '"')"
  fi

  if [[ "$os_id" == "ubuntu" || "$os_id" == "linuxmint" || "$os_id" == "pop" ]]; then
    if ! grep -rq "ondrej/php" /etc/apt/sources.list /etc/apt/sources.list.d/ 2>/dev/null; then
      echo "Adding Ondřej Surý PHP PPA for Ubuntu..."
      sudo_cmd apt-get update -qq
      sudo_cmd apt-get install -y software-properties-common ca-certificates lsb-release apt-transport-https
      sudo_cmd add-apt-repository -y ppa:ondrej/php
      sudo_cmd apt-get update -qq
    fi
  elif [[ "$os_id" == "debian" || "$os_id" == "kali" || "$os_id" == "raspbian" ]]; then
    if [[ ! -f /etc/apt/sources.list.d/sury-php.list ]]; then
      echo "Configuring Sury PHP repository for Debian..."
      sudo_cmd apt-get update -qq
      sudo_cmd apt-get install -y ca-certificates apt-transport-https lsb-release curl gnupg
      sudo_cmd mkdir -p /usr/share/keyrings
      curl -sSLo /tmp/sury-php.gpg https://packages.sury.org/php/apt.gpg
      sudo_cmd gpg --dearmor -o /usr/share/keyrings/deb.sury.org-php.gpg < /tmp/sury-php.gpg 2>/dev/null || sudo_cmd cp /tmp/sury-php.gpg /usr/share/keyrings/deb.sury.org-php.gpg
      rm -f /tmp/sury-php.gpg
      local dist
      dist="$(lsb_release -sc 2>/dev/null || echo "bookworm")"
      echo "deb [signed-by=/usr/share/keyrings/deb.sury.org-php.gpg] https://packages.sury.org/php/ $dist main" | sudo_cmd tee /etc/apt/sources.list.d/sury-php.list >/dev/null
      sudo_cmd apt-get update -qq
    fi
  fi
}

php_install_version() {
  local version="$1"
  require_system_access

  local pkg_manager
  pkg_manager="$(detect_package_manager)"

  echo "Installing PHP $version via $pkg_manager..."

  case "$pkg_manager" in
    apt)
      ensure_php_apt_repo
      sudo_cmd apt-get install -y \
        "php${version}-cli" \
        "php${version}-fpm" \
        "php${version}-common" \
        "php${version}-mbstring" \
        "php${version}-xml" \
        "php${version}-curl" \
        "php${version}-zip" \
        "php${version}-bcmath" \
        "php${version}-intl" \
        "php${version}-gd" \
        "php${version}-mysql" \
        "php${version}-pgsql" \
        "php${version}-sqlite3" \
        "php${version}-redis" || {
          echo "Error: Failed to install PHP $version packages via apt"
          return 1
        }
      local unit
      unit="$(php_fpm_unit "$version")"
      sudo_cmd systemctl enable --now "$unit" >/dev/null 2>&1 || true
      ;;
    dnf|yum)
      echo "Enabling Remi repository on Fedora/RHEL..."
      local fedora_ver
      fedora_ver="$(rpm -E %fedora 2>/dev/null || true)"
      if [[ -n "$fedora_ver" && "$fedora_ver" != "%fedora" ]]; then
        sudo_cmd dnf install -y "https://rpms.remirepo.net/fedora/remi-release-${fedora_ver}.rpm" || true
      fi
      local nodot="${version//./}"
      sudo_cmd dnf install -y \
        "php${nodot}-php-cli" \
        "php${nodot}-php-fpm" \
        "php${nodot}-php-mbstring" \
        "php${nodot}-php-xml" \
        "php${nodot}-php-curl" \
        "php${nodot}-php-zip" \
        "php${nodot}-php-bcmath" \
        "php${nodot}-php-intl" \
        "php${nodot}-php-gd" \
        "php${nodot}-php-mysqlnd" \
        "php${nodot}-php-pgsql" \
        "php${nodot}-php-pdo" \
        "php${nodot}-php-pecl-redis5" || sudo_cmd dnf install -y "php${version}" "php${version}-fpm"
      sudo_cmd systemctl enable --now "php${nodot}-php-fpm" 2>/dev/null || true
      ;;
    pacman)
      echo "Arch Linux uses rolling release. Attempting to install PHP via pacman..."
      sudo_cmd pacman -S --noconfirm "php" "php-fpm" 2>/dev/null || {
        echo "Tip: On Arch Linux, specific historical PHP versions can be installed from AUR: yay -S php${version//./} php${version//./}-fpm"
        return 1
      }
      sudo_cmd systemctl enable --now php-fpm >/dev/null 2>&1 || true
      ;;
    *)
      echo "Error: unsupported package manager for automatic PHP installation"
      return 1
      ;;
  esac

  echo "PHP $version installed successfully!"
}

php_update_version() {
  local version="$1"
  require_system_access

  local pkg_manager
  pkg_manager="$(detect_package_manager)"

  echo "Checking updates for PHP $version..."
  case "$pkg_manager" in
    apt)
      sudo_cmd apt-get update -qq
      sudo_cmd apt-get install --only-upgrade -y "php${version}*" 2>/dev/null || sudo_cmd apt-get install --only-upgrade -y "php${version}"
      ;;
    dnf)
      sudo_cmd dnf upgrade -y "php${version}*"
      ;;
    pacman)
      sudo_cmd pacman -Sy --noconfirm "php${version}" 2>/dev/null || sudo_cmd pacman -Sy --noconfirm php
      ;;
    apk)
      sudo_cmd apk upgrade "php${version}*" 2>/dev/null || sudo_cmd apk upgrade "php${version/./}"
      ;;
    *)
      echo "Error: unsupported package manager"
      return 1
      ;;
  esac

  # Restart FPM service to pick up new patch release
  php_fpm_service_action "restart" "$version" 2>/dev/null || true
  echo "PHP $version updated to latest available release."
}

php_installable_versions() {
  local installed_list
  installed_list="$(list_available_php_versions)"
  local all_versions=("7.4" "8.0" "8.1" "8.2" "8.3" "8.4" "8.5")
  for v in "${all_versions[@]}"; do
    if echo "$installed_list" | grep -qx "$v"; then
      echo "$v:installed"
    else
      echo "$v:available"
    fi
  done
}

