<?php

namespace LaravelDev\Profiler;

class Collector
{
    protected static float $startTime = 0.0;
    protected static float $appStartTime = 0.0;
    protected static array $queries = [];
    protected static array $httpCalls = [];
    protected static array $views = [];
    protected static int $eventsCount = 0;
    protected static array $cache = ['hits' => 0, 'misses' => 0, 'writes' => 0];
    protected static array $jobs = [];
    protected static ?array $response = null;
    protected static bool $initialized = false;

    // Bodies above this are cut; the inspector shows the first part like a
    // browser preview. UDP limits mean it is the first thing dropped.
    protected const BODY_PREVIEW_BYTES = 24000;

    public static function init(): void
    {
        if (isset($_SERVER['HTTP_USER_AGENT']) && str_contains($_SERVER['HTTP_USER_AGENT'], 'LaravelDev-Uptime')) {
            return;
        }
        if (self::$initialized) {
            return;
        }
        self::$initialized = true;
        self::$appStartTime = microtime(true);
        self::$startTime = defined('LARAVEL_START') ? (float) LARAVEL_START : self::$appStartTime;
    }

    public static function addQuery(object $query): void
    {
        if (count(self::$queries) >= 300) {
            return;
        }

        $callerFile = '';
        $callerLine = 0;
        $base = function_exists('base_path') ? base_path() : '';

        // Find first frame inside app/
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 25);
        foreach ($trace as $frame) {
            if (isset($frame['file']) && str_contains($frame['file'], DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR)) {
                $callerFile = $base ? str_replace($base . DIRECTORY_SEPARATOR, '', $frame['file']) : $frame['file'];
                $callerLine = $frame['line'] ?? 0;
                break;
            }
        }

        $bindings = [];
        if (!empty($query->bindings) && is_array($query->bindings)) {
            foreach (array_slice($query->bindings, 0, 25) as $val) {
                if ($val instanceof \DateTimeInterface) {
                    $bindings[] = $val->format('Y-m-d H:i:s');
                } elseif (is_scalar($val) || is_null($val)) {
                    $bindings[] = $val;
                } else {
                    $bindings[] = (string) $val;
                }
            }
        }

        $timeMs = round((float) ($query->time ?? 0), 2);
        self::$queries[] = [
            'sql' => (string) $query->sql,
            'bindings' => $bindings,
            'time_ms' => $timeMs,
            // QueryExecuted fires when the query ends; its start is that minus its time.
            'start_ms' => round(max(0.0, (microtime(true) - self::$startTime) * 1000 - $timeMs), 2),
            'connection' => (string) ($query->connectionName ?? 'default'),
            'file' => $callerFile,
            'line' => $callerLine,
        ];
    }

    public static function addHttpCall(string $url, int $status, float $durationMs, string $method = '', string $mockRule = ''): void
    {
        if (count(self::$httpCalls) >= 50) {
            return;
        }
        self::$httpCalls[] = [
            'method' => $method,
            'url' => $url,
            'status' => $status,
            'duration_ms' => round($durationMs, 2),
            'mocked' => $mockRule !== '',
            'rule_id' => $mockRule,
        ];
    }

    /** Called from the RequestHandled event, the one place the response object is reachable. */
    public static function setResponse(object $response): void
    {
        $headers = [];
        $cookies = [];
        if (isset($response->headers)) {
            foreach ($response->headers->all() as $name => $values) {
                if (strtolower($name) === 'set-cookie') {
                    continue;
                }
                $headers[$name] = implode(', ', (array) $values);
            }
            if (method_exists($response->headers, 'getCookies')) {
                foreach ($response->headers->getCookies() as $cookie) {
                    // Names and flags only: values are session secrets.
                    $cookies[] = [
                        'name' => $cookie->getName(),
                        'expires' => $cookie->getExpiresTime() ? gmdate('Y-m-d H:i:s', $cookie->getExpiresTime()) : 'Session',
                        'http_only' => $cookie->isHttpOnly(),
                        'secure' => $cookie->isSecure(),
                        'same_site' => (string) $cookie->getSameSite(),
                    ];
                }
            }
        }

        $type = $headers['content-type'] ?? '';
        $body = null;
        $size = null;
        $streamed = $response instanceof \Symfony\Component\HttpFoundation\StreamedResponse
            || $response instanceof \Symfony\Component\HttpFoundation\BinaryFileResponse;
        if (!$streamed && method_exists($response, 'getContent')) {
            $content = (string) $response->getContent();
            $size = strlen($content);
            if (preg_match('~json|text/|xml|javascript~i', $type) || ($type === '' && $size < 2048)) {
                $body = substr($content, 0, self::BODY_PREVIEW_BYTES);
            }
        }

        self::$response = [
            'status' => method_exists($response, 'getStatusCode') ? $response->getStatusCode() : null,
            'headers' => $headers,
            'cookies' => $cookies,
            'content_type' => $type,
            'size' => $size,
            'body' => $body,
            'body_truncated' => $size !== null && $body !== null && $size > strlen($body),
            'streamed' => $streamed,
        ];
    }

    public static function addView(string $viewName): void
    {
        if (!in_array($viewName, self::$views, true) && count(self::$views) < 50) {
            self::$views[] = $viewName;
        }
    }

    public static function recordEvent(): void
    {
        self::$eventsCount++;
    }

    public static function recordCacheHit(): void
    {
        self::$cache['hits']++;
    }

    public static function recordCacheMiss(): void
    {
        self::$cache['misses']++;
    }

    public static function recordCacheWrite(): void
    {
        self::$cache['writes']++;
    }

    public static function addJob(string $name, float $durationMs, string $queue, int $attempts, bool $failed = false): void
    {
        if (count(self::$jobs) >= 50) {
            return;
        }
        self::$jobs[] = [
            'name' => $name,
            'duration_ms' => round($durationMs, 2),
            'queue' => $queue,
            'attempts' => $attempts,
            'status' => $failed ? 'failed' : 'processed',
        ];
    }

    public static function flush(): void
    {
        if (!self::$initialized) {
            return;
        }

        if (isset($_SERVER['HTTP_USER_AGENT']) && str_contains($_SERVER['HTTP_USER_AGENT'], 'LaravelDev-Uptime')) {
            return;
        }

        $now = microtime(true);
        $durationMs = round(($now - self::$startTime) * 1000, 2);
        $bootMs = round((self::$appStartTime - self::$startTime) * 1000, 2);
        $peakMemMb = round(memory_get_peak_usage(true) / 1024 / 1024, 2);

        $method = 'CLI';
        $uri = '';
        $routeName = '';
        $action = '';
        $middleware = [];
        $headers = [];
        $queryParams = $_GET ?? [];
        $requestPayload = null;
        $requestInfo = [];
        $user = null;
        $status = 200;

        if (function_exists('getallheaders')) {
            foreach (getallheaders() as $k => $v) {
                // Session cookies and CSRF tokens are credentials too; never ship them.
                if (preg_match('/^(cookie|x-(xsrf|csrf)-token)$/i', $k)) {
                    $headers[$k] = '[hidden]';
                } elseif (stripos($k, 'authorization') !== false || stripos($k, 'password') !== false) {
                    $headers[$k] = substr($v, 0, 10) . '... [hidden]';
                } else {
                    $headers[$k] = $v;
                }
            }
        }

        if (function_exists('request') && function_exists('app') && app()->bound('request')) {
            $req = request();
            $method = $req->method();
            $uri = '/' . ltrim($req->path(), '/');
            if ($req->route()) {
                $routeName = (string) ($req->route()->getName() ?? '');
                $action = (string) ($req->route()->getActionName() ?? '');
                if (method_exists($req->route(), 'gatherMiddleware')) {
                    $middleware = (array) ($req->route()->gatherMiddleware() ?? []);
                }
            }
            if ($req->user()) {
                $user = [
                    'id' => $req->user()->getKey(),
                    'name' => $req->user()->name ?? $req->user()->email ?? '',
                    'email' => $req->user()->email ?? '',
                ];
            }
            // Full payload, like the browser's Network panel. This is a local dev
            // tool and the packet only goes to 127.0.0.1. Files are listed below.
            if (!$req->isMethod('GET') && !$req->isMethod('HEAD')) {
                $rawBody = $req->input();
                $requestPayload = array_slice($rawBody, 0, 50);
            }
            $files = [];
            foreach ($req->allFiles() as $field => $file) {
                foreach (is_array($file) ? $file : [$file] as $f) {
                    if ($f instanceof \Illuminate\Http\UploadedFile) {
                        $files[] = ['field' => $field, 'name' => $f->getClientOriginalName(), 'size' => $f->getSize(), 'mime' => $f->getClientMimeType()];
                    }
                }
            }
            $requestInfo = [
                'url' => $req->fullUrl(),
                'scheme' => $req->getScheme(),
                'ip' => $req->ip(),
                'content_type' => (string) $req->header('Content-Type', ''),
                'content_length' => (int) $req->header('Content-Length', 0),
                'is_json' => $req->isJson(),
                'is_ajax' => $req->ajax(),
                'cookies' => array_keys($req->cookies->all()),
                'files' => $files,
            ];
        }
        if (self::$response && self::$response['status']) {
            $status = self::$response['status'];
        } elseif (http_response_code()) {
            $status = http_response_code();
        }

        $basePath = function_exists('base_path') ? base_path() : getcwd();
        $folderName = basename($basePath);
        $hostName = isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']) : '';
        $envSite = function_exists('env') ? env('LARAVEL_DEV_SITE') : null;
        $siteName = $envSite ?: ($_SERVER['LARAVEL_DEV_SITE'] ?? ($hostName ?: $folderName));

        $payload = [
            'site' => $siteName,
            'folder' => $folderName,
            'path' => $basePath,
            'host' => $hostName,
            'id' => 'req-' . uniqid('', true),
            'time' => round(self::$startTime, 3),
            'method' => $method,
            'uri' => $uri,
            'route' => $routeName,
            'action' => $action,
            'middleware' => array_values($middleware),
            'headers' => $headers,
            'query_params' => $queryParams,
            'payload' => $requestPayload,
            'request' => $requestInfo,
            'response' => self::$response,
            'user' => $user,
            'status' => $status,
            'duration_ms' => $durationMs,
            'boot_ms' => $bootMs,
            'memory_peak_mb' => $peakMemMb,
            'queries' => self::$queries,
            'http_calls' => self::$httpCalls,
            'cache' => self::$cache,
            'views' => self::$views,
            'events_count' => self::$eventsCount,
            'jobs' => self::$jobs,
        ];

        $json = self::encode($payload);

        // A UDP datagram tops out near 64KB and an oversized one is dropped
        // silently, yet heavy requests are exactly the ones worth seeing. Shed
        // detail step by step until it fits, and flag what was cut.
        $shrinks = [
            function (&$p) { if ($p['response']) { $p['response']['body'] = null; $p['response']['body_dropped'] = true; } },
            function (&$p) { $p['payload'] = null; $p['headers'] = []; },
            function (&$p) { foreach ($p['queries'] as &$q) { $q['bindings'] = []; } },
            function (&$p) { $p['queries'] = array_slice($p['queries'], 0, 50); },
            function (&$p) {
                foreach ($p['queries'] as &$q) { $q['sql'] = substr($q['sql'], 0, 500); }
                $p['queries'] = array_slice($p['queries'], 0, 20);
                $p['http_calls'] = array_slice($p['http_calls'], 0, 10);
            },
            function (&$p) { $p['queries'] = []; $p['http_calls'] = []; $p['views'] = []; $p['jobs'] = []; },
        ];
        foreach ($shrinks as $shrink) {
            if ($json !== false && strlen($json) <= 60000) {
                break;
            }
            $shrink($payload);
            $payload['truncated'] = true;
            $json = self::encode($payload);
        }

        if ($json === false || strlen($json) > 60000) {
            return;
        }

        static::sendUdp($json);
    }

    protected static function encode(array $payload): string|false
    {
        // Binary bindings or a non-UTF-8 header must not cost the whole request.
        return json_encode(
            $payload,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR
        );
    }

    protected static function sendUdp(string $data): void
    {
        // 1. Try pure PHP stream socket (built into core PHP, no ext-sockets needed)
        $fp = @stream_socket_client('udp://127.0.0.1:9913', $errno, $errstr, 0.2);
        if ($fp) {
            @fwrite($fp, $data);
            @fclose($fp);
            return;
        }

        // 2. Fallback to ext-sockets if available
        if (function_exists('socket_create')) {
            $sock = @socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
            if ($sock) {
                @socket_set_nonblock($sock);
                @socket_sendto($sock, $data, strlen($data), 0, '127.0.0.1', 9913);
                @socket_close($sock);
            }
        }
    }
}

