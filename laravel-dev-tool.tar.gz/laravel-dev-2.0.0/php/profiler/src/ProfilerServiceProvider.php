<?php

namespace LaravelDev\Profiler;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Event;

class ProfilerServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Zero footprint when profiler is disabled
        if (!$this->isEnabled()) {
            return;
        }

        Collector::init();
    }

    public function boot(): void
    {
        // Mocks also apply to queue workers and artisan, so they come before the
        // HTTP-only profiler check.
        $this->registerHttpMocks();

        if (!$this->isEnabled()) {
            return;
        }

        // 1. Capture Database queries
        try {
            DB::listen(function ($query) {
                Collector::addQuery($query);
            });
        } catch (\Throwable $e) {}

        // 2. HTTP Client external requests (Laravel 8+)
        try {
            Event::listen('Illuminate\Http\Client\Events\ResponseReceived', function ($event) {
                $duration = 0.0;
                $stats = $event->response->handlerStats();
                if (isset($stats['total_time'])) {
                    $duration = (float) $stats['total_time'] * 1000;
                }
                Collector::addHttpCall(
                    (string) $event->request->url(),
                    $event->response->status(),
                    $duration,
                    $event->request->method(),
                    (string) $event->response->header('X-Laravel-Dev-Mock')
                );
            });
        } catch (\Throwable $e) {}

        // 3. Cache events
        try {
            Event::listen('Illuminate\Cache\Events\CacheHit', function () {
                Collector::recordCacheHit();
            });
            Event::listen('Illuminate\Cache\Events\CacheMissed', function () {
                Collector::recordCacheMiss();
            });
            Event::listen('Illuminate\Cache\Events\KeyWritten', function () {
                Collector::recordCacheWrite();
            });
        } catch (\Throwable $e) {}

        // 4. View events
        try {
            Event::listen('composing:*', function ($eventName, $data = []) {
                $viewName = str_replace('composing: ', '', $eventName);
                if ($viewName) {
                    Collector::addView($viewName);
                }
            });
        } catch (\Throwable $e) {}

        // 5. General events counter
        try {
            Event::listen('*', function ($eventName) {
                if (!str_starts_with($eventName, 'illuminate.') && !str_starts_with($eventName, 'composing:')) {
                    Collector::recordEvent();
                }
            });
        } catch (\Throwable $e) {}

        // 6. Queue Job events
        try {
            Event::listen('Illuminate\Queue\Events\JobProcessed', function ($event) {
                $jobName = $event->job->resolveName();
                Collector::addJob($jobName, 0.0, $event->job->getQueue(), $event->job->attempts(), false);
            });
            Event::listen('Illuminate\Queue\Events\JobFailed', function ($event) {
                $jobName = $event->job->resolveName();
                Collector::addJob($jobName, 0.0, $event->job->getQueue(), $event->job->attempts(), true);
            });
        } catch (\Throwable $e) {}

        // 6b. Capture dump() output for the Studio Bar, still printing it as usual
        if (StudioBar::enabled() && class_exists(\Symfony\Component\VarDumper\VarDumper::class)) {
            try {
                $previous = null;
                $previous = \Symfony\Component\VarDumper\VarDumper::setHandler(function ($var, ?string $label = null) use (&$previous) {
                    Collector::addDump($var, $label);
                    if ($previous) {
                        $previous($var, $label);
                        return;
                    }
                    $cloner = new \Symfony\Component\VarDumper\Cloner\VarCloner();
                    $dumper = \in_array(\PHP_SAPI, ['cli', 'phpdbg'], true)
                        ? new \Symfony\Component\VarDumper\Dumper\CliDumper()
                        : new \Symfony\Component\VarDumper\Dumper\HtmlDumper();
                    $dumper->dump($cloner->cloneVar($var));
                });
            } catch (\Throwable $e) {}
        }

        // 7. Response (status, headers, body preview) for the inspector
        try {
            Event::listen('Illuminate\Foundation\Http\Events\RequestHandled', function ($event) {
                Collector::setResponse($event->response);
                if (isset($event->request)) {
                    Collector::captureWebhook($event->request, $event->response);
                }
                if (StudioBar::enabled()) {
                    StudioBar::inject($event->response);
                }
            });
        } catch (\Throwable $e) {}

        // 8. Flush at terminating
        try {
            $this->app->terminating(function () {
                Collector::flush();
            });
        } catch (\Throwable $e) {}
    }

    /**
     * Apply the rules Laravel Dev mirrors into storage/framework/cache/. A
     * request no rule matches returns null, which lets it go out for real.
     */
    protected function registerHttpMocks(): void
    {
        if (!$this->app->isLocal() || !class_exists(\Illuminate\Support\Facades\Http::class)) {
            return;
        }
        $file = $this->app->storagePath('framework/cache/laravel-dev-http-mocks.json');
        if (!is_file($file)) {
            return;
        }
        $rules = json_decode((string) @file_get_contents($file), true);
        if (!is_array($rules) || !$rules) {
            return;
        }

        \Illuminate\Support\Facades\Http::fake(function ($request) use ($rules) {
            $url = $request->url();
            foreach ($rules as $rule) {
                $method = strtoupper((string) ($rule['method'] ?? '*'));
                if ($method !== '*' && $method !== strtoupper($request->method())) {
                    continue;
                }
                $pattern = (string) ($rule['url_pattern'] ?? '*');
                if (!\Illuminate\Support\Str::is($pattern, $url) && !\Illuminate\Support\Str::is('*' . $pattern . '*', $url)) {
                    continue;
                }
                $headers = (array) ($rule['headers'] ?? []);
                $headers['X-Laravel-Dev-Mock'] = (string) ($rule['id'] ?? 'mock');
                return \Illuminate\Support\Facades\Http::response($rule['response'] ?? '', (int) ($rule['status'] ?? 200), $headers);
            }
            return null;
        });
    }

    protected function isEnabled(): bool
    {
        if (!$this->app->isLocal()) {
            return false;
        }

        // Artisan commands (the scheduler, queue:work, Laravel Dev's own calls) are not
        // HTTP requests; profiling them records a fake "GET /" for every run.
        if ($this->app->runningInConsole()) {
            return false;
        }

        // Opt-in: only `laravel-dev profiler enable` turns it on for a site.
        $envVal = env('LARAVEL_DEV_PROFILER');
        return $envVal === true || $envVal === 'true' || $envVal === '1' || $envVal === 1;
    }
}

