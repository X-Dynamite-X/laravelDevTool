<?php

namespace LaravelDev\Profiler;

/**
 * In-browser Studio Bar: a small floating toolbar injected into HTML responses of local
 * Laravel apps (only when the profiler is enabled and LARAVEL_DEV_STUDIO=true).
 *
 * Shows timing, memory, SQL count / slowest query / N+1 groups, recent log errors,
 * captured dump() output and the current route, with "open in editor" links.
 * The UI itself lives in ../assets/studio-bar.{js,css}; this class only gathers data.
 */
class StudioBar
{
    protected const MAX_LOG_ENTRIES = 10;
    protected const LOG_TAIL_BYTES = 131072;
    protected const N_PLUS_ONE_THRESHOLD = 3;

    public static function enabled(): bool
    {
        $val = env('LARAVEL_DEV_STUDIO');
        return $val === true || $val === 'true' || $val === '1' || $val === 1;
    }

    public static function inject($response): void
    {
        try {
            self::doInject($response);
        } catch (\Throwable $e) {
            // The bar must never break the host page.
        }
    }

    protected static function doInject($response): void
    {
        if (!is_object($response) || !method_exists($response, 'getContent') || !method_exists($response, 'setContent')) {
            return;
        }
        // Streamed / binary responses have no inline body to modify.
        if ($response instanceof \Symfony\Component\HttpFoundation\StreamedResponse
            || $response instanceof \Symfony\Component\HttpFoundation\BinaryFileResponse) {
            return;
        }

        $contentType = isset($response->headers) ? (string) $response->headers->get('Content-Type', '') : '';
        if ($contentType !== '' && !str_contains($contentType, 'text/html')) {
            return;
        }
        // Skip redirects, Livewire/Inertia XHR updates and prefetches.
        if (method_exists($response, 'isRedirection') && $response->isRedirection()) {
            return;
        }
        $request = function_exists('request') ? request() : null;
        if ($request && ($request->ajax() || $request->headers->has('X-Livewire') || $request->headers->has('X-Inertia')
            || $request->headers->get('Purpose') === 'prefetch')) {
            return;
        }

        $content = $response->getContent();
        if (!is_string($content) || str_contains($content, 'id="ld-studio-bar"')) {
            return;
        }
        $pos = strripos($content, '</body>');
        if ($pos === false) {
            return;
        }

        $html = self::render(self::collect());
        $response->setContent(substr($content, 0, $pos) . $html . substr($content, $pos));
    }

    /** Gathers everything the bar shows. */
    public static function collect(): array
    {
        $duration = defined('LARAVEL_START') ? round((microtime(true) - LARAVEL_START) * 1000, 1) : 0.0;
        $basePath = function_exists('base_path') ? base_path() : (string) getcwd();
        $summary = Collector::getSummary();
        $queries = $summary['queries'] ?? [];

        $slowest = null;
        foreach ($queries as $q) {
            if ($slowest === null || ($q['time_ms'] ?? 0) > ($slowest['time_ms'] ?? 0)) {
                $slowest = $q;
            }
        }

        return [
            'php' => PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION,
            'laravel' => function_exists('app') ? app()->version() : '',
            'duration_ms' => $duration,
            'memory_mb' => round(memory_get_peak_usage(true) / (1024 * 1024), 1),
            'base_path' => $basePath,
            'queries' => array_map(fn ($q) => [
                'sql' => (string) ($q['sql'] ?? ''),
                'time_ms' => (float) ($q['time_ms'] ?? 0),
                'file' => (string) ($q['file'] ?? ''),
                'line' => (int) ($q['line'] ?? 0),
            ], array_slice($queries, 0, 100)),
            'query_count' => count($queries),
            'query_time_ms' => round(array_sum(array_map(fn ($q) => (float) ($q['time_ms'] ?? 0), $queries)), 2),
            'slowest' => $slowest ? ['sql' => (string) $slowest['sql'], 'time_ms' => (float) $slowest['time_ms']] : null,
            'n_plus_one' => self::detectNPlusOne($queries),
            'logs' => self::recentLogErrors($basePath),
            'dumps' => Collector::getDumps(),
            'route' => self::routeInfo($basePath),
        ];
    }

    /** Groups identical SELECTs (bindings are already "?") fired from the same place. */
    public static function detectNPlusOne(array $queries): array
    {
        $groups = [];
        foreach ($queries as $q) {
            $sql = (string) ($q['sql'] ?? '');
            if (stripos(ltrim($sql), 'select') !== 0) {
                continue;
            }
            $normalized = preg_replace('/\s+/', ' ', preg_replace('/\b\d+\b/', '?', $sql));
            $key = $normalized . '|' . ($q['file'] ?? '') . ':' . ($q['line'] ?? 0);
            $groups[$key] ??= ['sql' => $normalized, 'file' => (string) ($q['file'] ?? ''), 'line' => (int) ($q['line'] ?? 0), 'count' => 0, 'time_ms' => 0.0];
            $groups[$key]['count']++;
            $groups[$key]['time_ms'] += (float) ($q['time_ms'] ?? 0);
        }
        $hits = array_values(array_filter($groups, fn ($g) => $g['count'] >= self::N_PLUS_ONE_THRESHOLD));
        usort($hits, fn ($a, $b) => $b['count'] <=> $a['count']);
        return array_slice($hits, 0, 10);
    }

    /** Last error-level entries of laravel.log (or today's daily log). */
    public static function recentLogErrors(string $basePath): array
    {
        $dir = function_exists('storage_path') ? storage_path('logs') : $basePath . '/storage/logs';
        $candidates = [$dir . '/laravel.log', $dir . '/laravel-' . date('Y-m-d') . '.log'];
        $file = null;
        $mtime = 0;
        foreach ($candidates as $c) {
            if (is_file($c) && filemtime($c) > $mtime) {
                $file = $c;
                $mtime = filemtime($c);
            }
        }
        if (!$file) {
            return [];
        }

        $size = filesize($file);
        $fh = @fopen($file, 'rb');
        if (!$fh) {
            return [];
        }
        fseek($fh, max(0, $size - self::LOG_TAIL_BYTES));
        $tail = (string) stream_get_contents($fh);
        fclose($fh);

        preg_match_all(
            '/^\[(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2})[^\]]*\]\s+[\w-]+\.(ERROR|CRITICAL|ALERT|EMERGENCY):\s*(.+)$/m',
            $tail,
            $m,
            PREG_SET_ORDER
        );
        $entries = [];
        foreach (array_slice($m, -self::MAX_LOG_ENTRIES) as $row) {
            $msg = $row[3];
            $at = '';
            if (preg_match('/ at (\/\S+?\.php):(\d+)\)?/', $msg, $loc)) {
                $at = $loc[1] . ':' . $loc[2];
            }
            $time = strtotime($row[1]) ?: 0;
            $entries[] = [
                'time' => $row[1],
                'level' => strtolower($row[2]),
                'message' => mb_substr(preg_replace('/\s*\{"exception".*$/s', '', $msg), 0, 400),
                'at' => $at,
                'recent' => $time && (time() - $time) < 3600,
            ];
        }
        return array_reverse($entries);
    }

    public static function routeInfo(string $basePath): array
    {
        $info = ['name' => '', 'uri' => '', 'methods' => '', 'action' => 'Closure', 'middleware' => [], 'file' => '', 'line' => 0];
        if (!class_exists(\Illuminate\Support\Facades\Route::class)) {
            return $info;
        }
        $route = \Illuminate\Support\Facades\Route::current();
        if (!$route) {
            return $info;
        }
        $info['name'] = (string) ($route->getName() ?? '');
        $info['uri'] = '/' . ltrim((string) $route->uri(), '/');
        $info['methods'] = implode('|', array_diff($route->methods(), ['HEAD']));
        $info['action'] = (string) $route->getActionName();
        $info['middleware'] = array_values(array_map('strval', $route->gatherMiddleware()));

        try {
            $action = $info['action'];
            if (str_contains($action, '@')) {
                [$cls, $method] = explode('@', $action, 2);
                $ref = new \ReflectionMethod($cls, $method);
            } elseif (class_exists($action) && method_exists($action, '__invoke')) {
                $ref = new \ReflectionMethod($action, '__invoke');
            } else {
                $closure = $route->getAction('uses');
                $ref = $closure instanceof \Closure ? new \ReflectionFunction($closure) : null;
            }
            if ($ref && $ref->getFileName()) {
                $info['file'] = $ref->getFileName();
                $info['line'] = (int) $ref->getStartLine();
            }
        } catch (\Throwable $e) {
        }
        return $info;
    }

    protected static function asset(string $name): string
    {
        $path = dirname(__DIR__) . '/assets/' . $name;
        return is_file($path) ? (string) file_get_contents($path) : '';
    }

    public static function render(array $data): string
    {
        $json = json_encode(
            $data,
            JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR
        );

        // Respect a CSP nonce when the app uses Vite's nonce support.
        $nonce = '';
        try {
            if (class_exists(\Illuminate\Support\Facades\Vite::class)) {
                $n = \Illuminate\Support\Facades\Vite::cspNonce();
                if ($n) {
                    $nonce = ' nonce="' . htmlspecialchars($n, ENT_QUOTES, 'UTF-8') . '"';
                }
            }
        } catch (\Throwable $e) {
        }

        $css = self::asset('studio-bar.css');
        $js = self::asset('studio-bar.js');

        return "\n<!-- Laravel Dev Studio Bar -->\n"
            . "<div id=\"ld-studio-bar\"></div>\n"
            . "<script type=\"application/json\" id=\"ld-studio-data\">{$json}</script>\n"
            . "<style{$nonce}>{$css}</style>\n"
            . "<script{$nonce}>{$js}</script>\n";
    }
}
