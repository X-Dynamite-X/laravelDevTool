<?php

/**
 * Universal Profiler Prepend File for Laravel Dev Tool.
 * Automatically profiles any PHP or Laravel application without composer modifications.
 */

if (php_sapi_name() === 'cli' && !defined('LARAVEL_DEV_CLI_PROFILE')) {
    return;
}

// Ignore internal uptime checks
if (isset($_SERVER['HTTP_USER_AGENT']) && str_contains($_SERVER['HTTP_USER_AGENT'], 'LaravelDev-Uptime')) {
    return;
}

require_once __DIR__ . '/src/Collector.php';

\LaravelDev\Profiler\Collector::init();

// Always register shutdown flush
register_shutdown_function(function () {
    \LaravelDev\Profiler\Collector::flush();
});

// Hook into Laravel package discovery & event listeners
if (file_exists(__DIR__ . '/src/ProfilerServiceProvider.php')) {
    require_once __DIR__ . '/src/ProfilerServiceProvider.php';
}

