(function () {
  "use strict";
  var root = document.getElementById("ld-studio-bar");
  var dataEl = document.getElementById("ld-studio-data");
  if (!root || !dataEl || root.dataset.ready) return;
  root.dataset.ready = "1";

  var d;
  try { d = JSON.parse(dataEl.textContent || "{}"); } catch (e) { return; }

  var STORE = "ld-studio-state";
  var state = { open: false, tab: "queries" };
  try { Object.assign(state, JSON.parse(sessionStorage.getItem(STORE) || "{}")); } catch (e) {}
  function persist() { try { sessionStorage.setItem(STORE, JSON.stringify(state)); } catch (e) {} }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function abs(file) {
    if (!file) return "";
    return file.charAt(0) === "/" ? file : (d.base_path || "") + "/" + file;
  }
  function rel(file) {
    var base = (d.base_path || "") + "/";
    return file && file.indexOf(base) === 0 ? file.slice(base.length) : file;
  }
  function loc(file, line) {
    if (!file) return "";
    var f = abs(file);
    var label = rel(f) + (line ? ":" + line : "");
    return '<a class="ld-link" data-file="' + esc(f) + '" data-line="' + esc(line || 1) + '">' + esc(label) + "</a>";
  }
  function editorUrl(kind, file, line) {
    if (kind === "phpstorm") return "phpstorm://open?file=" + encodeURIComponent(file) + "&line=" + (line || 1);
    return "vscode://file/" + encodeURI(file) + ":" + (line || 1);
  }

  var errors = (d.logs || []).filter(function (l) { return l.recent; }).length;
  var nplus = (d.n_plus_one || []).length;
  var alert = errors > 0 || nplus > 0;
  var durCls = d.duration_ms > 1000 ? "ld-bad" : d.duration_ms > 500 ? "ld-warn" : "ld-ok";
  var sqlCls = nplus ? "ld-bad" : d.query_count > 30 ? "ld-warn" : "ld-ok";

  var tabs = [
    { id: "queries", label: "Queries", count: d.query_count, red: nplus > 0 },
    { id: "logs", label: "Logs", count: (d.logs || []).length, red: errors > 0 },
    { id: "dumps", label: "Dumps", count: (d.dumps || []).length },
    { id: "route", label: "Route" }
  ];

  function panel(id) {
    if (id === "queries") {
      var out = "";
      if (d.slowest) {
        out += '<div class="ld-row"><span class="ld-muted">Slowest:</span> <span class="ld-warn">' + esc(d.slowest.time_ms) + "ms</span><pre>" + esc(d.slowest.sql) + "</pre></div>";
      }
      (d.n_plus_one || []).forEach(function (g) {
        out += '<div class="ld-row"><span class="ld-bad">N+1 × ' + esc(g.count) + "</span> " + loc(g.file, g.line) +
          ' <span class="ld-muted">(' + esc(Math.round(g.time_ms * 100) / 100) + "ms total)</span><pre>" + esc(g.sql) + "</pre></div>";
      });
      (d.queries || []).forEach(function (q) {
        out += '<div class="ld-row"><span class="' + (q.time_ms > 100 ? "ld-warn" : "ld-ok") + '">' + esc(q.time_ms) + "ms</span> " +
          loc(q.file, q.line) + "<pre>" + esc(q.sql) + "</pre></div>";
      });
      if (d.query_count > (d.queries || []).length) {
        out += '<div class="ld-empty">… ' + (d.query_count - d.queries.length) + " more</div>";
      }
      return out || '<div class="ld-empty">No SQL queries executed on this request.</div>';
    }
    if (id === "logs") {
      if (!(d.logs || []).length) return '<div class="ld-empty">No errors in the application log.</div>';
      return d.logs.map(function (l) {
        var at = l.at ? l.at.split(":") : null;
        return '<div class="ld-row"><span class="' + (l.recent ? "ld-bad" : "ld-muted") + '">' + esc(l.level.toUpperCase()) + "</span> " +
          '<span class="ld-muted">' + esc(l.time) + "</span>" + (at ? " · " + loc(at[0], at[1]) : "") + "<pre>" + esc(l.message) + "</pre></div>";
      }).join("");
    }
    if (id === "dumps") {
      if (!(d.dumps || []).length) return '<div class="ld-empty">No dump() calls on this request.</div>';
      return d.dumps.map(function (x) {
        return '<div class="ld-row">' + (x.label ? "<b>" + esc(x.label) + "</b> " : "") + loc(x.file, x.line) + "<pre>" + esc(x.output) + "</pre></div>";
      }).join("");
    }
    var r = d.route || {};
    return "<dl>" +
      "<dt>URI</dt><dd><code>" + esc((r.methods ? r.methods + " " : "") + (r.uri || location.pathname)) + "</code></dd>" +
      "<dt>Name</dt><dd>" + esc(r.name || "—") + "</dd>" +
      "<dt>Action</dt><dd><code>" + esc(r.action || "Closure") + "</code></dd>" +
      "<dt>Source</dt><dd>" + (r.file ? loc(r.file, r.line) : "—") + "</dd>" +
      "<dt>Middleware</dt><dd>" + esc((r.middleware || []).join(", ") || "—") + "</dd>" +
      "<dt>Runtime</dt><dd>PHP " + esc(d.php) + (d.laravel ? " · Laravel " + esc(d.laravel) : "") + "</dd>" +
      "<dt>SQL time</dt><dd>" + esc(d.query_time_ms) + " ms</dd>" +
      "</dl>";
  }

  function armed() { return document.cookie.indexOf("XDEBUG_TRIGGER=LARAVEL_DEV") !== -1; }

  function render() {
    var r = d.route || {};
    var srcFile = r.file || (d.base_path || "");
    root.innerHTML =
      '<div class="ld-drawer" ' + (state.open ? "" : "hidden") + ">" +
        '<div class="ld-tabs" role="tablist">' + tabs.map(function (t) {
          return '<button type="button" class="ld-tab" role="tab" data-tab="' + t.id + '" aria-selected="' + (state.tab === t.id) + '">' + t.label +
            (t.count != null ? '<span class="ld-count' + (t.red ? " ld-red" : "") + '">' + esc(t.count) + "</span>" : "") + "</button>";
        }).join("") + "</div>" +
        '<div class="ld-panel" role="tabpanel">' + panel(state.tab) + "</div>" +
        '<div class="ld-actions">' +
          '<a class="ld-btn ld-primary" href="' + esc(editorUrl("vscode", srcFile, r.line)) + '">Open in VS Code</a>' +
          '<a class="ld-btn" href="' + esc(editorUrl("phpstorm", srcFile, r.line)) + '">Open in PhpStorm</a>' +
          '<button type="button" class="ld-btn' + (armed() ? " ld-armed" : "") + '" data-xdebug>' + (armed() ? "Xdebug armed (10m)" : "Debug next request") + "</button>" +
        "</div>" +
      "</div>" +
      '<div class="ld-pill" data-toggle title="Laravel Dev Studio">' +
        (alert ? '<span class="ld-alert" title="' + esc((errors ? errors + " recent log error(s) " : "") + (nplus ? nplus + " N+1 group(s)" : "")) + '"></span>' : "") +
        '<span class="ld-brand">⚡ Studio</span>' +
        '<span class="ld-tag">PHP ' + esc(d.php) + "</span>" +
        '<span class="' + durCls + '">' + esc(d.duration_ms) + "ms</span>" +
        '<span class="' + sqlCls + '">' + esc(d.query_count) + " SQL" + (nplus ? " · N+1" : "") + "</span>" +
        '<span class="ld-muted">' + esc(d.memory_mb) + "MB</span>" +
      "</div>";
  }

  root.addEventListener("click", function (e) {
    var t = e.target.closest ? e.target : e.target.parentElement;
    var tog = t.closest("[data-toggle]");
    if (tog) { state.open = !state.open; persist(); return render(); }
    var tab = t.closest("[data-tab]");
    if (tab) { state.tab = tab.dataset.tab; persist(); return render(); }
    var file = t.closest("[data-file]");
    if (file) { window.location.href = editorUrl("vscode", file.dataset.file, file.dataset.line); return; }
    if (t.closest("[data-xdebug]")) {
      document.cookie = armed() ? "XDEBUG_TRIGGER=;path=/;max-age=0" : "XDEBUG_TRIGGER=LARAVEL_DEV;path=/;max-age=600";
      render();
    }
  });

  render();
})();
