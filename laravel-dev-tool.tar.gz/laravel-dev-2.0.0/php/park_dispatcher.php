<?php
// php/park_dispatcher.php - Serves <folder>.test for every parked directory (Valet-style).
//
// nginx sends every request of the park vhost here. The parked directories come from the
// LARAVEL_DEV_PARKED_DIRS fastcgi_param (":"-separated, written by `laravel-dev park`), so
// PHP-FPM never needs to read the user's home directory.
//
// Rules: PHP files are executed, never sent as source; dot-files and files outside the
// site's public directory are never served; everything else goes to the front controller.

$host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
$host = (string) preg_replace('/:\d+$/', '', $host);
$site = (string) preg_replace('/\.test$/', '', $host);
if ($site === '' || !preg_match('/^[a-z0-9-]+$/', $site)) {
    http_response_code(400);
    exit('Bad host');
}

$parked_dirs = array_values(array_filter(explode(':', (string) ($_SERVER['LARAVEL_DEV_PARKED_DIRS'] ?? getenv('LARAVEL_DEV_PARKED_DIRS') ?: ''))));

function ld_not_found(string $site, array $dirs): void
{
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    echo "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Site Not Found - Laravel Dev</title>";
    echo "<style>body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;padding:40px;background:#0f172a;color:#f1f5f9;display:flex;justify-content:center}main{max-width:600px;width:100%;background:#1e293b;padding:30px;border-radius:12px;border:1px solid #334155}h1{color:#f43f5e;margin-top:0}ul{background:#0f172a;padding:15px 30px;border-radius:8px;border:1px solid #334155}code{color:#38bdf8;font-family:monospace}</style></head>";
    echo "<body><main><h1>Site Not Found (404)</h1><p>Could not find <code>" . htmlspecialchars($site) . "</code> in any parked directory:</p><ul>";
    foreach ($dirs as $d) {
        echo "<li><code>" . htmlspecialchars($d) . "</code></li>";
    }
    echo "</ul><p>Use <code>laravel-dev park add &lt;directory&gt;</code> to park the folder holding this project.</p></main></body></html>";
    exit;
}

$site_dir = null;
foreach ($parked_dirs as $dir) {
    $target = rtrim($dir, '/') . '/' . $site;
    if (is_dir($target)) {
        $site_dir = $target;
        break;
    }
}
if ($site_dir === null) {
    ld_not_found($site, $parked_dirs);
}

$public = $site_dir;
foreach (['public', 'web', 'pub', 'webroot'] as $candidate) {
    if (is_dir($site_dir . '/' . $candidate)) {
        $public = $site_dir . '/' . $candidate;
        break;
    }
}
$public_real = realpath($public);

$uri = rawurldecode((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH));
if (str_contains($uri, "\0")) {
    http_response_code(400);
    exit('Bad request');
}

// Resolve the requested path and make sure it stays inside the public directory.
$requested = $uri !== '/' ? realpath($public_real . $uri) : false;
$inside = $requested !== false && ($requested === $public_real || str_starts_with($requested, $public_real . '/'));
$hidden = (bool) preg_match('#/\.(?!well-known/)#', $uri);
if ($hidden) {
    http_response_code(403);
    exit('Forbidden');
}

function ld_run_php(string $script, string $public_real, string $site_dir, string $script_name): void
{
    $_SERVER['SCRIPT_FILENAME'] = $script;
    $_SERVER['SCRIPT_NAME'] = $script_name;
    $_SERVER['PHP_SELF'] = $script_name;
    $_SERVER['DOCUMENT_ROOT'] = $public_real;
    chdir(dirname($script));
    require $script;
    exit;
}

if ($inside) {
    // A directory: serve its index (WordPress /wp-admin/, static sub-sites).
    if (is_dir($requested)) {
        foreach (['index.php', 'index.html'] as $index) {
            if (is_file($requested . '/' . $index)) {
                $requested = $requested . '/' . $index;
                break;
            }
        }
    }
    if (is_file($requested)) {
        $relative = substr($requested, strlen($public_real));
        if (strtolower(pathinfo($requested, PATHINFO_EXTENSION)) === 'php') {
            ld_run_php($requested, $public_real, $site_dir, $relative);
        }
        $mimes = [
            'css' => 'text/css', 'js' => 'application/javascript', 'mjs' => 'application/javascript',
            'json' => 'application/json', 'map' => 'application/json', 'html' => 'text/html; charset=utf-8',
            'htm' => 'text/html; charset=utf-8', 'txt' => 'text/plain; charset=utf-8', 'xml' => 'application/xml',
            'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif',
            'svg' => 'image/svg+xml', 'ico' => 'image/x-icon', 'webp' => 'image/webp', 'avif' => 'image/avif',
            'woff' => 'font/woff', 'woff2' => 'font/woff2', 'ttf' => 'font/ttf', 'otf' => 'font/otf',
            'mp4' => 'video/mp4', 'webm' => 'video/webm', 'mp3' => 'audio/mpeg', 'pdf' => 'application/pdf',
        ];
        $ext = strtolower(pathinfo($requested, PATHINFO_EXTENSION));
        header('Content-Type: ' . ($mimes[$ext] ?? (mime_content_type($requested) ?: 'application/octet-stream')));
        header('Content-Length: ' . filesize($requested));
        readfile($requested);
        exit;
    }
}

// Everything else: the front controller.
if (is_file($public_real . '/index.php')) {
    ld_run_php($public_real . '/index.php', $public_real, $site_dir, '/index.php');
}
if (is_file($public_real . '/index.html')) {
    header('Content-Type: text/html; charset=utf-8');
    readfile($public_real . '/index.html');
    exit;
}
http_response_code(404);
echo 'Index file not found in ' . htmlspecialchars($public);
