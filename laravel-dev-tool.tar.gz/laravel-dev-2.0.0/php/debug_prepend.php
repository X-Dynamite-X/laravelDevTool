<?php
/**
 * Laravel Dev — Debug Session hook (auto_prepend_file, set by the site's nginx vhost).
 *
 * While a site's debug session is armed, every PHP request to it starts an Xdebug
 * step-debugging session: page loads, API calls made by a separate frontend (any origin,
 * no cookie or query string needed), Postman/curl calls, webhooks and queued callbacks
 * over HTTP. When nothing is armed it costs one is_file() call.
 *
 * Armed state: /var/lib/laravel-dev/debug/<site-domain>.json  {"expires_at": <unix time>}
 * written by `laravel-dev debug-session on <project>`. Subdomains (branch workspaces,
 * tenant subdomains) match their parent site's file.
 */

(static function (): void {
    if (\PHP_SAPI === 'cli') {
        return;
    }

    // OAuth / webhook callback helper page: served for every site, Xdebug or not.
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    if (\str_starts_with($uri, '/_laravel_dev/oauth')) {
        $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $base = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
        \header('Content-Type: text/html; charset=utf-8');
        echo "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Laravel Dev · OAuth Callback Helper</title>";
        echo "<style>body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#0f172a;color:#f8fafc;padding:40px;display:flex;justify-content:center}main{max-width:700px;width:100%;background:#1e293b;padding:32px;border-radius:12px;border:1px solid #334155;box-shadow:0 10px 30px rgba(0,0,0,0.5)}h1{font-size:22px;color:#38bdf8;margin-top:0}p{color:#94a3b8;font-size:14px}.box{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:16px;margin-bottom:16px}.row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #1e293b}.row:last-child{border-bottom:none}.label{font-weight:600;font-size:13px;color:#e2e8f0;width:140px}.url{font-family:monospace;font-size:13px;color:#38bdf8;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}button{background:#0284c7;color:#fff;border:none;padding:5px 12px;border-radius:6px;cursor:pointer;font-size:12px;margin-left:12px}button:hover{background:#0369a1}</style></head>";
        echo "<body><main><h1>OAuth & Webhook Callback Helper</h1><p>Use these URLs in your OAuth Application settings (GitHub, Google, etc.) or webhook consumers while testing:</p>";
        echo "<div class=\"box\">";
        $endpoints = [
            'Default Socialite' => $base . '/auth/callback',
            'GitHub Callback'   => $base . '/auth/github/callback',
            'Google Callback'   => $base . '/auth/google/callback',
            'Stripe Webhook'    => $base . '/stripe/webhook',
            'General Webhook'   => $base . '/webhook',
        ];
        foreach ($endpoints as $lbl => $u) {
            echo "<div class=\"row\"><span class=\"label\">" . htmlspecialchars($lbl) . "</span><span class=\"url\" id=\"u_" . md5($lbl) . "\">" . htmlspecialchars($u) . "</span><button onclick=\"navigator.clipboard.writeText(document.getElementById('u_" . md5($lbl) . "').innerText);this.innerText='Copied!';setTimeout(()=>this.innerText='Copy',1500)\">Copy</button></div>";
        }
        echo "</div><p style=\"font-size:12px;color:#64748b\">Powered by Laravel Dev Suite</p></main></body></html>";
        exit;
    }

    if (!\function_exists('xdebug_connect_to_client')) {
        return;
    }
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if ($ua !== '' && \str_contains($ua, 'LaravelDev-Uptime')) {
        return;
    }

    $host = \strtolower((string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? ''));
    $host = (string) \preg_replace('/:\d+$/', '', $host);
    if ($host === '' || !\preg_match('/^[a-z0-9.-]+$/', $host)) {
        return;
    }


    // PHP-FPM clears the environment by default, so this override only matters for tests.
    $dir = \getenv('LARAVEL_DEV_DEBUG_DIR') ?: '/var/lib/laravel-dev/debug';
    $labels = \explode('.', $host);
    while (\count($labels) >= 2) {
        $file = $dir . '/' . \implode('.', $labels) . '.json';
        if (\is_file($file)) {
            $data = \json_decode((string) @\file_get_contents($file), true);
            if (!\is_array($data) || (int) ($data['expires_at'] ?? 0) <= \time()) {
                return;
            }
            if (!\headers_sent()) {
                \header('X-Laravel-Dev-Debug: session');
            }
            if (\function_exists('xdebug_is_debugger_active') && \xdebug_is_debugger_active()) {
                return; // already started by a trigger
            }
            @\xdebug_connect_to_client();
            return;
        }
        \array_shift($labels);
    }
})();
