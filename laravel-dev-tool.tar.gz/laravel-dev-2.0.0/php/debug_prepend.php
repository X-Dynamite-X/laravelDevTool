<?php
/**
 * Laravel Dev — Debug Session hook (auto_prepend_file, set by the site's nginx vhost).
 *
 * While a site's debug session is armed, every PHP request to it starts an Xdebug
 * step-debugging session: page loads, API calls made by a separate frontend (any origin,
 * no cookie or query string needed), Postman/curl calls, webhooks and queued callbacks
 * over HTTP. When nothing is armed it costs one is_file() call.
 *
 * Armed state: /var/lib/laravel-dev/debug/<site-domain>.json  {"expires_at": <unix time>}
 * written by `laravel-dev debug-session on <project>`. Subdomains (branch workspaces,
 * tenant subdomains) match their parent site's file.
 */

(static function (): void {
    if (\PHP_SAPI === 'cli' || !\function_exists('xdebug_connect_to_client')) {
        return;
    }
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if ($ua !== '' && \str_contains($ua, 'LaravelDev-Uptime')) {
        return;
    }

    $host = \strtolower((string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? ''));
    $host = (string) \preg_replace('/:\d+$/', '', $host);
    if ($host === '' || !\preg_match('/^[a-z0-9.-]+$/', $host)) {
        return;
    }

    // PHP-FPM clears the environment by default, so this override only matters for tests.
    $dir = \getenv('LARAVEL_DEV_DEBUG_DIR') ?: '/var/lib/laravel-dev/debug';
    $labels = \explode('.', $host);
    while (\count($labels) >= 2) {
        $file = $dir . '/' . \implode('.', $labels) . '.json';
        if (\is_file($file)) {
            $data = \json_decode((string) @\file_get_contents($file), true);
            if (!\is_array($data) || (int) ($data['expires_at'] ?? 0) <= \time()) {
                return;
            }
            if (!\headers_sent()) {
                \header('X-Laravel-Dev-Debug: session');
            }
            if (\function_exists('xdebug_is_debugger_active') && \xdebug_is_debugger_active()) {
                return; // already started by a trigger
            }
            @\xdebug_connect_to_client();
            return;
        }
        \array_shift($labels);
    }
})();
