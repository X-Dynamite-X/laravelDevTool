#!/usr/bin/env bash

set -euo pipefail

INSTALL_DIR=/opt/laravel-dev
DESKTOP_FILE=/usr/share/applications/laravel-dev.desktop

detect_package_manager() {
  if command -v apt-get >/dev/null 2>&1; then
    echo "apt"
    return
  fi
  if command -v pacman >/dev/null 2>&1; then
    echo "pacman"
    return
  fi
  if command -v dnf >/dev/null 2>&1; then
    echo "dnf"
    return
  fi
  if command -v yum >/dev/null 2>&1; then
    echo "yum"
    return
  fi
  if command -v zypper >/dev/null 2>&1; then
    echo "zypper"
    return
  fi
  echo ""
}

install_dependencies() {
  local pm
  pm="$(detect_package_manager)"

  if [[ -z "$pm" ]]; then
    echo "Warning: unsupported package manager. Please install dependencies manually."
    return 0
  fi

  echo "Installing system dependencies using: $pm"

  case "$pm" in
    apt)
      sudo apt-get update
      local apt_pkgs=(
        bash sudo curl ca-certificates git unzip acl openssh-client
        nginx mariadb-server
        php php-cli php-fpm php-mysql php-xml php-mbstring php-curl php-zip
        composer
        python3 python3-gi gir1.2-gtk-3.0 python3-pymysql python3-cryptography
        ssh-askpass
        zenity
      )
      sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "${apt_pkgs[@]}"
      sudo DEBIAN_FRONTEND=noninteractive apt-get install -y phpmyadmin >/dev/null 2>&1 || echo "Warning: phpMyAdmin package is unavailable on this apt repository."
      sudo DEBIAN_FRONTEND=noninteractive apt-get install -y cloudflared >/dev/null 2>&1 || echo "Warning: cloudflared package is unavailable on this apt repository."
      # Local HTTPS (trusted *.test certificates).
      sudo DEBIAN_FRONTEND=noninteractive apt-get install -y mkcert libnss3-tools openssl >/dev/null 2>&1 \
        || echo "Warning: mkcert/libnss3-tools unavailable; HTTPS will use self-signed certificates."
      if apt-cache show gir1.2-webkit2-4.1 >/dev/null 2>&1; then
        sudo DEBIAN_FRONTEND=noninteractive apt-get install -y gir1.2-webkit2-4.1
      elif apt-cache show gir1.2-webkit2-4.0 >/dev/null 2>&1; then
        sudo DEBIAN_FRONTEND=noninteractive apt-get install -y gir1.2-webkit2-4.0
      else
        echo "Warning: WebKit GTK package not found via apt; desktop UI may not open."
      fi
      # Next.js / Nuxt / Django support. Skip node when the user manages it (nvm, volta…).
      command -v node >/dev/null 2>&1 || sudo DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs npm >/dev/null 2>&1 \
        || echo "Warning: nodejs/npm unavailable; install Node.js to run Next.js/Nuxt apps."
      sudo DEBIAN_FRONTEND=noninteractive apt-get install -y python3-venv >/dev/null 2>&1 \
        || echo "Warning: python3-venv unavailable; needed to create Django projects."
      # PostgreSQL in the Database view (MySQL/MariaDB and SQLite need nothing more).
      sudo DEBIAN_FRONTEND=noninteractive apt-get install -y python3-psycopg2 >/dev/null 2>&1 \
        || echo "Warning: python3-psycopg2 unavailable; PostgreSQL connections won't open."
      sudo DEBIAN_FRONTEND=noninteractive apt-get install -y gir1.2-ayatanaappindicator3-0.1 >/dev/null 2>&1 \
        || echo "Warning: tray icon support (gir1.2-ayatanaappindicator3-0.1) is unavailable."
      ;;
    pacman)
      local pacman_pkgs=(
        bash sudo curl ca-certificates git unzip acl
        nginx mariadb
        php php-fpm composer
        python python-gobject gtk3 webkit2gtk-4.1 libayatana-appindicator python-pymysql python-psycopg2 python-cryptography
        x11-ssh-askpass
        zenity
      )
      sudo pacman -S --noconfirm --needed "${pacman_pkgs[@]}"
      sudo pacman -S --noconfirm --needed phpmyadmin >/dev/null 2>&1 || echo "Warning: phpMyAdmin package is unavailable on this pacman repository."
      sudo pacman -S --noconfirm --needed cloudflared >/dev/null 2>&1 || echo "Warning: cloudflared package is unavailable on this pacman repository."
      sudo pacman -S --noconfirm --needed mkcert nss openssl >/dev/null 2>&1 \
        || echo "Warning: mkcert unavailable; HTTPS will use self-signed certificates."
      if ! command -v python3 >/dev/null 2>&1 && command -v python >/dev/null 2>&1; then
        sudo ln -sf "$(command -v python)" /usr/local/bin/python3
      fi
      ;;
    dnf)
      local dnf_pkgs=(
        bash sudo curl ca-certificates git unzip acl
        nginx mariadb-server
        php php-cli php-fpm php-mysqlnd php-xml php-mbstring php-json php-curl php-zip composer
        python3 python3-gobject gtk3 webkit2gtk3 python3-PyMySQL python3-cryptography python3-psycopg2 python3-cryptography
        openssh-askpass
        zenity
      )
      sudo dnf install -y "${dnf_pkgs[@]}" || sudo dnf install -y bash sudo nginx mariadb-server php php-cli php-fpm composer python3
      sudo dnf install -y phpMyAdmin >/dev/null 2>&1 || echo "Warning: phpMyAdmin package is unavailable on this dnf repository."
      sudo dnf install -y cloudflared >/dev/null 2>&1 || echo "Warning: cloudflared package is unavailable on this dnf repository."
      sudo dnf install -y mkcert nss-tools openssl >/dev/null 2>&1 \
        || echo "Warning: mkcert unavailable; HTTPS will use self-signed certificates."
      ;;
    yum)
      local yum_pkgs=(
        bash sudo curl ca-certificates git unzip acl
        nginx mariadb-server
        php php-cli php-fpm php-mysqlnd php-xml php-mbstring php-json php-curl php-zip composer
        python3 python3-gobject gtk3 webkit2gtk3
        openssh-askpass
        zenity
      )
      sudo yum install -y "${yum_pkgs[@]}" || sudo yum install -y bash sudo nginx mariadb-server php php-cli php-fpm composer python3
      sudo yum install -y phpMyAdmin >/dev/null 2>&1 || echo "Warning: phpMyAdmin package is unavailable on this yum repository."
      sudo yum install -y cloudflared >/dev/null 2>&1 || echo "Warning: cloudflared package is unavailable on this yum repository."
      sudo yum install -y mkcert nss-tools openssl >/dev/null 2>&1 \
        || echo "Warning: mkcert unavailable; HTTPS will use self-signed certificates."
      ;;
    zypper)
      local zypper_pkgs=(
        bash sudo curl ca-certificates git unzip acl
        nginx mariadb
        php8 php8-cli php8-fpm php8-mysql php8-xml php8-mbstring php8-curl php8-zip
        python3 python3-gobject gtk3 webkit2gtk3 python3-PyMySQL python3-cryptography
        openssh-askpass
        zenity
      )
      sudo zypper --non-interactive refresh
      sudo zypper --non-interactive install --no-recommends "${zypper_pkgs[@]}" || sudo zypper --non-interactive install nginx mariadb php8 php8-fpm composer python3
      sudo zypper --non-interactive install phpMyAdmin >/dev/null 2>&1 || echo "Warning: phpMyAdmin package is unavailable on this zypper repository."
      sudo zypper --non-interactive install cloudflared >/dev/null 2>&1 || echo "Warning: cloudflared package is unavailable on this zypper repository."
      sudo zypper --non-interactive install mkcert mozilla-nss-tools openssl >/dev/null 2>&1 \
        || echo "Warning: mkcert unavailable; HTTPS will use self-signed certificates."
      ;;
  esac
}

phpmyadmin_source_dir() {
  local candidates=(
    /usr/share/phpmyadmin
    /usr/share/phpMyAdmin
    /usr/share/webapps/phpmyadmin
    /usr/share/webapps/phpMyAdmin
  )
  local candidate=""

  for candidate in "${candidates[@]}"; do
    if [[ -d "$candidate" ]]; then
      echo "$candidate"
      return 0
    fi
  done

  echo ""
}

configure_phpmyadmin_nginx() {
  local source_dir="" config_path="/etc/nginx/conf.d/laravel-dev-phpmyadmin.conf" php_socket=""
  source_dir="$(phpmyadmin_source_dir)"

  if [[ -z "$source_dir" ]]; then
    echo "phpMyAdmin package not detected locally; skipping Nginx alias setup."
    return 0
  fi

  php_socket="$(
    ls -1 /run/php/php*-fpm.sock /run/php-fpm/php*-fpm.sock /run/php-fpm/www.sock /run/php-fpm/php-fpm.sock 2>/dev/null \
    | head -n1 || true
  )"
  if [[ -z "$php_socket" ]]; then
    echo "phpMyAdmin package found, but no PHP-FPM socket was detected yet; skipping alias setup."
    return 0
  fi

  sudo mkdir -p /etc/nginx/conf.d
  sudo tee "$config_path" >/dev/null <<EOF
location /phpmyadmin {
    alias ${source_dir}/;
    index index.php;
}

location ~ ^/phpmyadmin/(.+\.php)$ {
    alias ${source_dir}/\$1;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME ${source_dir}/\$1;
    fastcgi_pass unix:${php_socket};
}
EOF

  sudo nginx -t >/dev/null 2>&1 || {
    echo "Warning: phpMyAdmin Nginx alias could not be validated. Leaving existing Nginx config unchanged."
    sudo rm -f "$config_path"
    return 0
  }

  sudo systemctl reload nginx >/dev/null 2>&1 || sudo service nginx reload >/dev/null 2>&1 || true
}

verify_dependencies() {
  local missing=()
  local required_cmds=(bash sudo nginx php composer mysql python3)
  local c=""

  for c in "${required_cmds[@]}"; do
    if ! command -v "$c" >/dev/null 2>&1; then
      missing+=("$c")
    fi
  done

  if [[ ${#missing[@]} -gt 0 ]]; then
    echo "Warning: some required tools are still missing: ${missing[*]}"
    echo "Install them manually, then run installer again."
  fi
}

service_exists() {
  local service_name="$1"
  systemctl list-unit-files --type=service --no-legend 2>/dev/null | awk '{print $1}' | grep -qx "${service_name}.service"
}

enable_start_service() {
  local service_name="$1"
  if command -v systemctl >/dev/null 2>&1; then
    sudo systemctl enable --now "$service_name" >/dev/null 2>&1 || sudo systemctl start "$service_name" >/dev/null 2>&1 || true
  elif command -v service >/dev/null 2>&1; then
    sudo service "$service_name" start >/dev/null 2>&1 || true
  fi
}

detect_db_service() {
  local candidates=(mariadb mysql mysqld)
  local c=""

  for c in "${candidates[@]}"; do
    if command -v systemctl >/dev/null 2>&1; then
      if service_exists "$c"; then
        echo "$c"
        return 0
      fi
    elif [[ -x "/etc/init.d/$c" ]]; then
      echo "$c"
      return 0
    fi
  done

  echo "mariadb"
}

detect_php_fpm_service() {
  local candidates=(
    php-fpm
    php8.5-fpm
    php8.4-fpm
    php8.3-fpm
    php8.2-fpm
    php-fpm8
  )
  local c=""
  local discovered=""

  for c in "${candidates[@]}"; do
    if command -v systemctl >/dev/null 2>&1; then
      if service_exists "$c"; then
        echo "$c"
        return 0
      fi
    elif [[ -x "/etc/init.d/$c" ]]; then
      echo "$c"
      return 0
    fi
  done

  if command -v systemctl >/dev/null 2>&1; then
    discovered="$(systemctl list-unit-files --type=service --no-legend 2>/dev/null | awk '{print $1}' | grep -E '^php.*fpm\.service$' | head -n1 | sed 's/\.service$//')"
    if [[ -n "$discovered" ]]; then
      echo "$discovered"
      return 0
    fi
  fi

  echo "php-fpm"
}

initialize_mariadb_if_needed() {
  if command -v mariadb-install-db >/dev/null 2>&1; then
    if [[ ! -d /var/lib/mysql/mysql ]]; then
      sudo mariadb-install-db --user=mysql --basedir=/usr --datadir=/var/lib/mysql >/dev/null 2>&1 || true
    fi
  elif command -v mysql_install_db >/dev/null 2>&1; then
    if [[ ! -d /var/lib/mysql/mysql ]]; then
      sudo mysql_install_db --user=mysql --basedir=/usr --datadir=/var/lib/mysql >/dev/null 2>&1 || true
    fi
  fi
}

setup_mysql_root_access() {
  # Ensure root@localhost can connect without a password from the laravel-dev user.
  # This is a local dev tool — passwordless root on loopback is acceptable.
  local db_service
  db_service="$(detect_db_service)"

  echo "Configuring MySQL/MariaDB root access for local development..."

  # Wait up to 10 seconds for the DB socket/port to be ready
  local waited=0
  while ! mysqladmin ping -h 127.0.0.1 --silent 2>/dev/null; do
    if [[ $waited -ge 10 ]]; then
      echo "Warning: MySQL/MariaDB did not become ready in time. Skipping root setup."
      return 0
    fi
    sleep 1
    (( waited++ )) || true
  done

  # Try to connect as root without password first — already set up
  if mysql -h 127.0.0.1 -u root -e "SELECT 1;" >/dev/null 2>&1; then
    echo "MySQL root access (no password) is already working."
    return 0
  fi

  # Try sudo mysql to configure root
  if sudo mysql -e "SELECT 1;" >/dev/null 2>&1; then
    echo "Granting root@127.0.0.1 full privileges with no password..."
    sudo mysql <<'SQL'
ALTER USER 'root'@'localhost' IDENTIFIED VIA mysql_native_password USING PASSWORD('') OR unix_socket;
GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;
-- Also allow root@127.0.0.1 for TCP connections
CREATE USER IF NOT EXISTS 'root'@'127.0.0.1' IDENTIFIED BY '';
GRANT ALL PRIVILEGES ON *.* TO 'root'@'127.0.0.1' WITH GRANT OPTION;
FLUSH PRIVILEGES;
SQL
    echo "MySQL root access configured."
    return 0
  fi

  echo "Warning: Could not configure MySQL root access automatically."
  echo "You can set DB credentials manually in Settings after launching the app."
}

setup_mailpit() {
  if ! command -v mailpit >/dev/null 2>&1; then
    echo "Installing Mailpit (local email testing)..."
    bash < <(curl -sL https://raw.githubusercontent.com/axllent/mailpit/develop/install.sh) >/dev/null 2>&1 || true
  fi

  if command -v mailpit >/dev/null 2>&1 && [[ ! -f /etc/systemd/system/mailpit.service ]]; then
    sudo tee /etc/systemd/system/mailpit.service >/dev/null <<'EOF'
[Unit]
Description=Mailpit - local mail catcher
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/mailpit
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    sudo systemctl daemon-reload >/dev/null 2>&1 || true
  fi
}

enable_runtime_services() {
  local db_service=""
  local php_fpm_service=""

  db_service="$(detect_db_service)"
  php_fpm_service="$(detect_php_fpm_service)"

  initialize_mariadb_if_needed

  echo "Enabling and starting services: nginx, $db_service, $php_fpm_service"
  enable_start_service nginx
  enable_start_service "$db_service"
  enable_start_service "$php_fpm_service"
  setup_mailpit
  enable_start_service mailpit

  # Give the DB a moment to finish starting before configuring access
  sleep 2
  setup_mysql_root_access
}

echo "Installing Laravel Dev"
install_dependencies
verify_dependencies
enable_runtime_services
configure_phpmyadmin_nginx

sudo mkdir -p "$INSTALL_DIR"
# Replace the app files wholesale so files removed upstream (e.g. the old PHP
# dashboard in public/) don't linger from a previous install.
sudo rm -rf "$INSTALL_DIR/public" "$INSTALL_DIR/ui"
sudo cp -r bin config core ui assets VERSION "$INSTALL_DIR/"
if [[ -d php ]]; then
  sudo cp -r php "$INSTALL_DIR/"
fi

if [[ -f uninstall.sh ]]; then
  sudo cp uninstall.sh "$INSTALL_DIR/uninstall.sh"
fi

if [[ -f assets/laravel-dev.desktop ]]; then
  sudo cp assets/laravel-dev.desktop "$DESKTOP_FILE"
fi

if [[ -f assets/laravel-dev.svg ]]; then
  sudo mkdir -p /usr/share/icons/hicolor/scalable/apps
  sudo cp assets/laravel-dev.svg /usr/share/icons/hicolor/scalable/apps/laravel-dev.svg
fi

# Install app icon into hicolor icon theme (all common sizes)
if [[ -f assets/laravel-dev.png ]]; then
  for size in 512x512 256x256 128x128 64x64 48x48 32x32; do
    sudo mkdir -p "/usr/share/icons/hicolor/${size}/apps"
    sudo cp assets/laravel-dev.png "/usr/share/icons/hicolor/${size}/apps/laravel-dev.png"
  done
  # Update icon cache if gtk-update-icon-cache is available
  if command -v gtk-update-icon-cache >/dev/null 2>&1; then
    sudo gtk-update-icon-cache -f -t /usr/share/icons/hicolor >/dev/null 2>&1 || true
  fi
fi

sudo ln -sf "$INSTALL_DIR/bin/laravel-dev" /usr/local/bin/laravel-dev
sudo chmod +x /usr/local/bin/laravel-dev
sudo chmod +x "$INSTALL_DIR/bin/laravel-dev"
sudo chmod +x "$INSTALL_DIR/ui/app.py"
if [[ -f "$INSTALL_DIR/ui/sudo-askpass.sh" ]]; then
  sudo chmod +x "$INSTALL_DIR/ui/sudo-askpass.sh"
fi
if [[ -f "$INSTALL_DIR/ui/ssh-askpass.sh" ]]; then
  sudo chmod +x "$INSTALL_DIR/ui/ssh-askpass.sh"
fi
if [[ -f "$INSTALL_DIR/ui/git-askpass.sh" ]]; then
  sudo chmod +x "$INSTALL_DIR/ui/git-askpass.sh"
fi

echo "Installation complete"
echo "Use command: laravel-dev app"
echo "Or launch 'Laravel Dev' from app menu"
