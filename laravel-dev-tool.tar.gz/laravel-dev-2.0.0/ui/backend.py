"""Everything the interface can ask for. The window (GTK on Linux, the system
web view on macOS/Windows) only carries messages: see shell_gtk.py and
shell_webview.py. Every api_* method here is callable from app.js.
"""

import datetime
import json
import os
import re
import subprocess
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import apps
import envfile
import laravel_dev
import osutil
import perf
import sites
import webhooks
import team_config
import ai_assistant
from database import DatabaseManager, DBError, friendly_error, spec_from_env
from remote import Remote, RemoteError
from sites import BASE_DIR, CONFIG_DIR, NAME_RE, PROCESSES, UI_DIR, require
from tasks import TaskRunner
from vault import VaultManager, VaultError


XDEBUG_LAUNCH_CONFIG = {
    "name": "Listen for Xdebug (Laravel Dev)",
    "type": "php",
    "request": "launch",
    "port": 9003,
}


def _strip_jsonc(text: str) -> str:
    """Removes // and /* */ comments and trailing commas (VS Code's JSON-with-comments),
    leaving string contents untouched."""
    out, i, n, in_str = [], 0, len(text), False
    while i < n:
        c = text[i]
        if in_str:
            out.append(c)
            if c == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 2
                continue
            if c == '"':
                in_str = False
        elif c == '"':
            in_str = True
            out.append(c)
        elif text.startswith("//", i):
            while i < n and text[i] != "\n":
                i += 1
            continue
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            i = n if end == -1 else end + 2
            continue
        else:
            out.append(c)
        i += 1
    import re as _re
    return _re.sub(r",(\s*[}\]])", r"\1", "".join(out))


def write_xdebug_launch_json(project_path: str) -> dict:
    """Adds the 'Listen for Xdebug' config to <project>/.vscode/launch.json (creating it if
    needed). VS Code only reads launch.json from the folder that is open, so it must live in
    the project being debugged."""
    path = Path(project_path) / ".vscode" / "launch.json"
    if path.is_file():
        raw = path.read_text(encoding="utf-8")
        try:
            data = json.loads(_strip_jsonc(raw))
        except ValueError as exc:
            return {"ok": False, "path": str(path), "error": f"Could not parse existing launch.json ({exc}). Add the config manually."}
        configs = data.setdefault("configurations", [])
        if any(c.get("type") == "php" and c.get("request") == "launch" and int(c.get("port") or 0) == 9003
               and not c.get("program") and not c.get("runtimeArgs") for c in configs if isinstance(c, dict)):
            return {"ok": True, "path": str(path), "created": False, "message": "launch.json already has an Xdebug listener on port 9003."}
        configs.insert(0, dict(XDEBUG_LAUNCH_CONFIG))
        backup = path.with_suffix(".json.bak")
        backup.write_text(raw, encoding="utf-8")
        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        return {"ok": True, "path": str(path), "created": False, "backup": str(backup),
                "message": "Added the Xdebug listener to the existing launch.json (comments were not kept; original saved as launch.json.bak)."}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"version": "0.2.0", "configurations": [XDEBUG_LAUNCH_CONFIG]}, indent=2) + "\n", encoding="utf-8")
    return {"ok": True, "path": str(path), "created": True, "message": "Created .vscode/launch.json."}
from cloudflare import CloudflareClient
from github import GitHubClient

NON_EMPTY_RE = re.compile(r"^.+$")
DUMPS_FORMAT = "tcp://127.0.0.1:9912"  # dumps.DUMPS_PORT

# Called on the UI thread: they start tasks or touch UI state.
MAIN_THREAD = ("run", "cancel", "save")
# Answer later, after a native file dialog: api_x(params, done).
DIALOGS = ("pick_folder", "pick_file", "server_download", "server_upload", "db_export", "db_import", "db_pick_sqlite")


class Backend:
    def __init__(self, shell):
        """shell provides: post(fn, *args), eval_js(script), choose(kind, title, done, ...),
        refresh_tray(), notify(title, body, task_id), is_active(), has_tray."""
        self.shell = shell
        self.prefs = sites.load_prefs()
        self.runner = TaskRunner(self.emit, shell.post, {"LARAVEL_DEV_BASE_DIR": str(BASE_DIR), "LARAVEL_DEV_GUI": "1"})
        self.remote = Remote(CONFIG_DIR, UI_DIR, lambda event: shell.post(self.emit, event))
        self.vault = VaultManager(CONFIG_DIR)
        self.ai_settings = ai_assistant.AISettings(CONFIG_DIR, self.vault)
        self.cf = CloudflareClient(CONFIG_DIR)
        self.gh = GitHubClient(CONFIG_DIR)
        self.db = DatabaseManager(CONFIG_DIR, self.remote, self.db_auto_connections, vault=self.vault)
        self.workers = ThreadPoolExecutor(max_workers=6, thread_name_prefix="ld-api")
        self._auto_cache = (0.0, [])
        self._watcher_stop = threading.Event()
        self._last_log_errors = {}
        self._last_failed_jobs = {}
        self._last_mail_count = None
        self._notified_perf_ids = set()
        self._watcher_thread = threading.Thread(target=self._notification_watcher, daemon=True, name="ld-notify-watcher")
        self._watcher_thread.start()
        import dumps
        self.dumps_server = dumps.get_dumps_server(lambda event: shell.post(self.emit, event))
        try:
            if any(DUMPS_FORMAT in (Path(s.get("path", "")) / ".env").read_text(errors="replace")
                   for s in sites.list_sites() if (Path(s.get("path", "")) / ".env").is_file()):
                self.dumps_server.start()
        except Exception:
            pass
        try:
            perf.ensure_udp_server(emit_fn=lambda event: shell.post(self.emit, event))
        except Exception:
            pass
        try:
            sites.start_uptime_monitor()
        except Exception:
            pass

    # ── bridge ──────────────────────────────────────────────
    def emit(self, event):
        self.shell.eval_js(f"window.LD && window.LD.onEvent({json.dumps(event, default=str)})")
        if event.get("done"):
            self.on_task_done(event["task"])
        return False

    def on_task_done(self, task):
        if task.get("site") or task["title"].endswith("services"):
            self.shell.refresh_tray()
        if not self.shell.is_active():
            if not self.prefs.get("notify_task_fail", True) and task.get("status") in ("error", "success"):
                return
            body = {"success": "Finished successfully.", "cancelled": "Cancelled."}.get(task["status"], "Failed — open Laravel Dev for details.")
            self.shell.notify(task["title"], body, task["id"])

    def _notification_watcher(self):
        """Background thread monitoring logs, queue failed jobs, and mail for desktop notifications."""
        tick = 0
        while not self._watcher_stop.wait(30):
            tick += 1
            if self._watcher_stop.is_set():
                break
            try:
                # 1. Check today's log errors for linked Laravel sites every 30s
                if self.prefs.get("notify_log_errors", True):
                    for site in sites.list_sites():
                        if site.get("type") == "laravel" and site.get("linked") and site.get("exists"):
                            name = site["name"]
                            errs = site.get("log_errors_today", 0)
                            if name in self._last_log_errors:
                                prev = self._last_log_errors[name]
                                if errs > prev:
                                    diff = errs - prev
                                    self.shell.post(self.shell.notify,  # GTK calls belong on the main thread
                                        f"Laravel Error · {name}",
                                        f"{diff} new error(s) logged in laravel.log",
                                        f"log-err-{name}"
                                    )
                            self._last_log_errors[name] = errs

                # 2. Check Mailpit messages every 30s
                if self.prefs.get("notify_mail", True):
                    try:
                        import urllib.request
                        req = urllib.request.Request("http://127.0.0.1:8025/api/v1/messages?limit=1", headers={"Accept": "application/json"})
                        with urllib.request.urlopen(req, timeout=2.0) as resp:
                            if resp.status == 200:
                                data = json.loads(resp.read().decode("utf-8"))
                                total = data.get("total", 0)
                                if self._last_mail_count is not None and total > self._last_mail_count:
                                    diff = total - self._last_mail_count
                                    self.shell.post(self.shell.notify,
                                        "Mailpit · New Email",
                                        f"{diff} new message(s) captured in Mailpit",
                                        "mailpit-new"
                                    )
                                self._last_mail_count = total
                    except Exception:
                        pass

                # 3. Check queue failed jobs every 2 minutes (every 4 ticks)
                if tick % 4 == 0 and self.prefs.get("notify_failed_jobs", True):
                    for site in sites.list_sites():
                        if site.get("type") == "laravel" and site.get("linked") and site.get("exists") and (site.get("worker") or site.get("worker_configured")):
                            name = site["name"]
                            try:
                                q = laravel_dev.get_queue_status(site["path"], php_bin=sites.php_binary(site.get("php")))
                                fcount = q.get("failed_count", 0)
                                if name in self._last_failed_jobs:
                                    prev_f = self._last_failed_jobs[name]
                                    if fcount > prev_f:
                                        diff = fcount - prev_f
                                        self.shell.post(self.shell.notify,
                                            f"Queue Job Failed · {name}",
                                            f"{diff} queue job(s) failed execution",
                                            f"queue-fail-{name}"
                                        )
                                self._last_failed_jobs[name] = fcount
                            except Exception:
                                pass

                # 4. Check for new N+1 alerts or 5xx server errors every 30s
                if self.prefs.get("notify_perf_issues", True):
                    for site in sites.list_sites():
                        if not site.get("linked"):
                            continue
                        name = site["name"]
                        with perf._PERF_LOCK:
                            recent_reqs = list(perf._SITE_REQUESTS.get(name, []))[:5]
                        for r in recent_reqs:
                            req_id = r.get("id")
                            if req_id and req_id not in self._notified_perf_ids:
                                self._notified_perf_ids.add(req_id)
                                n1_alerts = r.get("insights", {}).get("n_plus_one", [])
                                if n1_alerts:
                                    self.shell.post(self.shell.notify,
                                        f"N+1 Query Alert · {name}",
                                        f"{len(n1_alerts)} potential N+1 bottleneck(s) in {r.get('uri', '/')}",
                                        f"perf-n1-{name}"
                                    )
                                elif r.get("status", 200) >= 500:
                                    self.shell.post(self.shell.notify,
                                        f"5xx Server Error · {name}",
                                        f"HTTP {r.get('status')} on {r.get('uri', '/')}",
                                        f"perf-5xx-{name}"
                                    )
            except Exception:
                pass

    def handle(self, raw):
        """Entry point for a message from app.js: {"id", "method", "params"}."""
        try:
            message = json.loads(raw)
            call_id, method, params = message["id"], message["method"], message.get("params") or {}
        except (ValueError, KeyError, TypeError):
            return

        def reply(payload):
            self.shell.eval_js(f"window.LD && window.LD.resolve({json.dumps(call_id)}, {json.dumps(payload, default=str)})")
            return False

        def fail(exc):
            if isinstance(exc, (ValueError, DBError, RemoteError, OSError)):
                return {"ok": False, "error": str(exc) or exc.__class__.__name__}
            return {"ok": False, "error": friendly_error(exc)}

        handler = getattr(self, f"api_{method}", None)
        if handler is None:
            reply({"ok": False, "error": f"Unknown method {method}"})
            return

        if method in DIALOGS:
            try:
                handler(params, lambda data: self.shell.post(reply, {"ok": True, "data": data}))
            except Exception as exc:  # noqa: BLE001 — surfaced to the UI
                reply(fail(exc))
            return

        if method in MAIN_THREAD:
            try:
                reply({"ok": True, "data": handler(params)})
            except Exception as exc:  # noqa: BLE001
                reply(fail(exc))
            return

        def work():
            try:
                payload = {"ok": True, "data": handler(params)}
            except Exception as exc:  # noqa: BLE001
                payload = fail(exc)
            self.shell.post(reply, payload)

        self.workers.submit(work)

    def start_action(self, action, params):
        if action.startswith("remote-") or action.startswith("forge-"):
            title, argv, env, data = self.remote.build_task(action, params)
            site_name = params.get("site_name") or params.get("name") or params.get("domain")
            task = self.runner.start(title, argv, site=site_name, env_extra=env, stdin_data=data)
            if action in ("remote-deploy", "remote-rollback", "forge-deploy", "forge-rollback") and site_name:
                def on_task_finish(t):
                    try:
                        laravel_dev.record_deploy_history(
                            CONFIG_DIR,
                            site_name,
                            action="rollback" if "rollback" in action else "deploy",
                            server_id=params.get("server", ""),
                            status=t.status,
                            message=f"Exit code: {t.code}" if t.code != 0 else "Completed successfully",
                        )
                    except Exception:
                        pass
                task.on_done = on_task_finish
            return task.summary()
        spec = sites.build_action(action, params)
        return self.runner.start_steps(spec["title"], spec["steps"], spec["site"]).summary()

    def shutdown(self):
        self._watcher_stop.set()
        if hasattr(self, "dumps_server"):
            self.dumps_server.stop()
        laravel_dev.stop_all_tinker()
        laravel_dev.stop_all_tunnels()
        for task in self.runner.running():
            self.runner.cancel(task.id)
        for site in sites.list_sites():  # dev servers belong to the app's session
            if site.get("running"):
                PROCESSES.stop(site["name"], site["path"])
        self.db.close_all()
        if not self.remote.mux:
            self.remote.disconnect_all()
        self.workers.shutdown(wait=False, cancel_futures=True)

    # ── app ─────────────────────────────────────────────────
    def api_init(self, _p):
        return {
            "version": (BASE_DIR / "VERSION").read_text().strip() if (BASE_DIR / "VERSION").is_file() else "",
            "home": str(osutil.HOME),
            "platform": osutil.PLATFORM,
            "mode": sites.MODE,
            "sep": os.sep,
            "settings": sites.load_settings(),
            "config_dir": str(CONFIG_DIR).replace(str(osutil.HOME), "~", 1),
            "prefs": self.prefs,
            "php_versions": sites.php_versions(),
            "editors": osutil.detect_editors(),
            "tray": self.shell.has_tray,
            "sites": sites.list_sites(),
            "services": sites.list_services(),
            "tasks": [t.summary() for t in self.runner.tasks.values()],
            "vault": self.vault.status(),
        }

    def api_version_check(self, p):
        force = bool(p.get("force"))
        curr = (BASE_DIR / "VERSION").read_text().strip() if (BASE_DIR / "VERSION").is_file() else "2.0.0"
        return sites.check_for_updates(CONFIG_DIR, curr, force=force)

    def api_sites(self, _p):
        return sites.list_sites()

    def api_site(self, p):
        return sites.site_details(require(NAME_RE, p.get("name"), "site name"))

    def api_site_services_get(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        site = sites.find_site(site_name)
        import site_services
        return {"ok": True, "services": site_services.get_site_services(site["path"])}

    def api_site_services_set(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        site = sites.find_site(site_name)
        category = str(p.get("category") or "").strip()
        option = str(p.get("option") or "").strip()
        db_name = p.get("database_name")
        import site_services
        return site_services.set_site_service(site["path"], category, option, database_name=db_name)

    def api_services(self, _p):
        return sites.list_services()

    def api_tools(self, _p):
        return sites.list_tools()

    def api_php_info(self, p):
        version = p.get("version") or (sites.php_versions()[0] if sites.php_versions() else "8.4")
        return sites.php_config_info(version)

    def api_php_installable(self, _p):
        return {"versions": sites.php_installable_list()}

    def api_node_versions(self, _p):
        code, out = sites.run_quiet([sites.CLI, "node-versions"])
        versions = [v.strip() for v in out.splitlines() if v.strip()] if code == 0 else []
        return {"versions": versions}

    def api_shim_status(self, _p):
        code, out = sites.run_quiet([sites.CLI, "shim", "status"])
        return {"status": out.strip() if code == 0 else "disabled"}

    def api_dns_status(self, _p):
        return sites.dns_status_info()

    def api_park_status(self, _p):
        return sites.park_status_info()

    def api_octane_status(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        return sites.octane_status_info(site_name)

    def api_octane_logs(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        return {"log": sites.octane_logs(site_name, int(p.get("lines") or 80))}

    def api_debug_write_launch_json(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return write_xdebug_launch_json(site["path"])

    def api_debug_session_status(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        return sites.debug_session_info(site_name)

    def api_team_config_status(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        site = sites.find_site(site_name)
        details = sites.site_details(site_name)
        srv_map = {}
        for s in sites.list_services():
            active = s.get("status") == "active"
            unit = s.get("unit", "").lower()
            label = s.get("label", "").lower()
            if "mysql" in unit or "mariadb" in unit or "database" in label:
                srv_map["mysql"] = active
                srv_map["mariadb"] = active
            elif "postgres" in unit:
                srv_map["postgresql"] = active
                srv_map["pgsql"] = active
            elif "redis" in unit:
                srv_map["redis"] = active
            elif "mailpit" in unit:
                srv_map["mail"] = active
                srv_map["mailpit"] = active
            elif "meilisearch" in unit:
                srv_map["meilisearch"] = active
            elif "minio" in unit:
                srv_map["minio"] = active
        curr_env = {
            "php": details.get("php") or site.get("php", ""),
            "node": details.get("node_version") or details.get("node", ""),
            "services": srv_map,
        }
        return team_config.inspect_team_config(site["path"], curr_env)

    def api_workspaces_list(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        code, out = sites.run_quiet([sites.CLI, "workspace", "list", site_name])
        if code == 0 and out.strip():
            try:
                return {"workspaces": json.loads(out)}
            except Exception:
                pass
        return {"workspaces": []}

    def api_instances_list(self, _p):
        code, out = sites.run_quiet([sites.CLI, "instance", "list"])
        if code == 0 and out.strip():
            try:
                return {"instances": json.loads(out)}
            except Exception:
                pass
        return {"instances": []}

    def api_mcp_status(self, _p):
        import mcp_server
        resp = mcp_server.process_message({"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}})
        tools = resp.get("result", {}).get("tools", []) if isinstance(resp, dict) else []
        return {
            "ok": True,
            "cli": str(sites.CLI),
            "command": f"{sites.CLI} mcp",
            "tools": [{"name": t["name"], "description": t["description"]} for t in tools],
            "clients": mcp_server.client_configs(),
        }

    def api_agent_docs_write(self, p):
        import agent_cli
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return agent_cli.write_agent_instructions(site)

    def api_mcp_test(self, _p):
        import mcp_server
        return mcp_server.self_test(str(sites.CLI))

    def api_ai_settings(self, _p):
        return self.ai_settings.public()

    def api_ai_settings_save(self, p):
        """Saves what the page sends; a missing field keeps its stored value."""
        def opt(name):
            return str(p[name]) if p.get(name) is not None else None
        api_key = "" if p.get("clear_key") else (opt("api_key") or None)  # empty = keep the stored key
        try:
            return self.ai_settings.save(provider=opt("provider"), model=opt("model"), ollama_url=opt("ollama_url"),
                                         api_key=api_key, custom_url=opt("custom_url"))
        except VaultError as exc:
            raise ValueError(str(exc)) from exc

    def api_ai_models(self, p):
        """Models of a provider for the model picker (loaded with that provider's saved key)."""
        provider = str(p.get("provider") or "") or None
        try:
            cfg = self.ai_settings.call_config(provider)
        except ValueError as exc:  # vault locked
            return {"models": [], "error": str(exc), "live": False}
        return ai_assistant.list_models(cfg, refresh=bool(p.get("refresh")))

    def api_ai_test(self, p):
        try:
            cfg = self.ai_settings.call_config(str(p.get("provider") or "") or None)
        except ValueError as exc:
            return {"ok": False, "provider": str(p.get("provider") or ""), "error": str(exc)}
        label = ai_assistant.provider_label(cfg["provider"])
        started = time.monotonic()
        reply, err = ai_assistant.ask_llm("Reply with the single word: pong", cfg)
        if err:
            return {"ok": False, "provider": label, "error": err}
        return {"ok": True, "provider": label, "model": cfg.get("model") or ai_assistant.DEFAULT_MODELS.get(cfg["provider"], ""),
                "reply": (reply or "").strip()[:200], "ms": int((time.monotonic() - started) * 1000)}

    def api_ai_propose_fix(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        ai_cfg = self.ai_settings.call_config()
        return ai_assistant.propose_fix(
            project_path=site["path"],
            error_message=str(p.get("message") or ""),
            file_path=str(p.get("file") or ""),
            line=int(p.get("line") or 1),
            trace=str(p.get("trace") or ""),
            custom_prompt=str(p.get("prompt") or ""),
            ai_config=ai_cfg,
        )

    def api_ai_generate_diff(self, p):
        original = p.get("original") or ""
        new_text = p.get("new_text") or ""
        filename = p.get("filename") or "file"
        diff = ai_assistant.generate_diff(original, new_text, filename)
        return {"diff": diff}

    def _ai_file_root(self, p):
        """Project root a file edit/revert is confined to: the named site, or the registered
        project that contains the file. Raises when the file is outside every project."""
        site_name = p.get("name")
        if site_name:
            return sites.find_site(require(NAME_RE, site_name, "site name"))["path"]
        resolved = Path(str(p.get("file_path") or "").strip()).resolve()
        matched_root = next(
            (s["path"] for s in sites.list_sites() if s.get("path") and resolved.is_relative_to(Path(s["path"]).resolve())),
            None,
        )
        if not matched_root:
            raise ValueError("Target file must belong to a registered project.")
        return matched_root

    def api_ai_apply_changes(self, p):
        try:
            allowed_root = self._ai_file_root(p)
        except ValueError as exc:
            return {"success": False, "error": str(exc)}
        file_path = str(p.get("file_path") or "").strip()
        new_content = p.get("new_content") or ""
        return ai_assistant.apply_file_changes(file_path, new_content, allowed_root=allowed_root)

    def api_ai_revert_changes(self, p):
        try:
            allowed_root = self._ai_file_root(p)
        except ValueError as exc:
            return {"success": False, "error": str(exc)}
        file_path = str(p.get("file_path") or "").strip()
        return ai_assistant.revert_file_changes(file_path, allowed_root=allowed_root)

    def api_webhooks_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        limit = int(p.get("limit") or 100)
        return {"webhooks": webhooks.list_webhooks(site["path"], limit=limit)}

    def api_webhooks_get(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        wh_id = str(p.get("id") or "").strip()
        data = webhooks.get_webhook(site["path"], wh_id)
        if not data:
            raise ValueError("Webhook not found")
        return {"webhook": data}

    def api_webhooks_clear(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        ok = webhooks.clear_webhooks(site["path"])
        return {"ok": ok}

    def api_webhooks_replay(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        wh_id = str(p.get("id") or "").strip()
        wh_data = webhooks.get_webhook(site["path"], wh_id) if wh_id else p.get("webhook")
        if not wh_data:
            raise ValueError("Webhook data required for replay")
        custom_body = p.get("custom_body")
        site_url = site.get("url") or f"http://{site['domain']}"
        res = webhooks.replay_webhook(site_url, wh_data, custom_body=custom_body)
        return res

    def api_webhooks_curl(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        wh_id = str(p.get("id") or "").strip()
        wh_data = webhooks.get_webhook(site["path"], wh_id) if wh_id else p.get("webhook")
        if not wh_data:
            raise ValueError("Webhook data required for cURL export")
        site_url = site.get("url") or f"http://{site['domain']}"
        cmd = webhooks.export_curl(wh_data, site_url=site_url)
        return {"curl": cmd}

    def api_webhooks_patterns(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return {"patterns": webhooks.get_patterns(site["path"])}

    def api_webhooks_save_patterns(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        patterns = p.get("patterns") or []
        ok = webhooks.save_patterns(site["path"], patterns)
        return {"ok": ok}

    def api_log(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        file_name = p.get("file") or "laravel.log"
        offset = int(p.get("offset", 0))
        inode = int(p.get("inode", 0))
        mode = p.get("mode") or "structured"
        return laravel_dev.parse_laravel_logs(
            site["path"],
            file_name=file_name,
            offset=offset,
            inode=inode,
            mode=mode,
        )

    def api_tinker(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        code = p.get("code") or ""
        return laravel_dev.run_tinker(site["path"], php_bin=php_bin, code=code, site_name=site["name"])

    def api_tinker_stop(self, p):
        name = require(NAME_RE, p.get("name"), "site name")
        site = sites.find_site(name)
        killed = laravel_dev.stop_tinker(name) or laravel_dev.stop_tinker(site["path"])
        return {"ok": True, "stopped": killed}

    def api_mail(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.fetch_captured_mail(site["path"], site_name=site["name"])

    def api_mail_message(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        msg_id = p.get("id") or ""
        source = p.get("source") or "mailpit"
        return laravel_dev.fetch_mail_message(site["path"], msg_id, source=source)

    def api_mail_clear(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        ids = p.get("ids")
        return laravel_dev.clear_captured_mail(site["path"], site_name=site["name"], ids=ids)

    def api_queue_status(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        res = laravel_dev.get_queue_status(site["path"], php_bin=php_bin)
        res["worker_running"] = bool(site.get("worker"))
        details = sites.site_details(site["name"])
        dev_tools = details.get("dev_tools", {})
        res["dev_tools"] = dev_tools
        if dev_tools.get("horizon"):
            res["horizon_status"] = laravel_dev.check_horizon_status(site["path"], php_bin=php_bin)
        return res

    def api_queue_retry(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.retry_failed_job(site["path"], php_bin=php_bin, job_id=p.get("id", "all"))

    def api_queue_forget(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.forget_failed_job(site["path"], php_bin=php_bin, job_id=p.get("id", "all"))

    def api_queue_delete_pending(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.clear_pending_jobs(site["path"], php_bin=php_bin, job_id=p.get("id", "all"))

    def api_worker_log(self, p):
        return sites.worker_log(require(NAME_RE, p.get("name"), "site name"))

    def api_supervisor_programs(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return sites.list_supervisor_programs(site["name"])

    def api_supervisor_program_log(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        program = require(re.compile(r"^[a-zA-Z0-9_-]+$"), p.get("program"), "program name")
        log_name = f"laravel-dev-{site['name']}.log" if program == "worker" else f"laravel-dev-{site['name']}-{program}.log"
        log_file = Path.home() / ".local" / "log" / "laravel-dev" / log_name
        if not log_file.is_file():
            return {"exists": False, "text": ""}
        text = osutil.tail_file(log_file, lines=100)
        return {"exists": True, "text": text}

    def api_scheduler_log(self, p):
        return sites.scheduler_log(require(NAME_RE, p.get("name"), "site name"))

    def api_schedule_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.get_schedule_list(site["path"], php_bin=php_bin)

    def api_schedule_run(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.run_scheduled_task(
            site["path"],
            php_bin=php_bin,
            command=p.get("command", ""),
            task_index=p.get("index"),
        )

    def api_backup_create(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.create_backup(site["path"], backup_type=p.get("type", "full"), custom_name=p.get("custom_name"))

    def api_backup_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.list_backups(site["path"])

    def api_backup_estimate(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.estimate_backup(site["path"])

    def api_backup_delete(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.delete_backup(site["path"], filename=p.get("filename", ""))

    def api_backup_restore(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.restore_backup(site["path"], filename=p.get("filename", ""))

    def api_backup_schedule_get(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.get_backup_schedule(site["name"])

    def api_backup_schedule_set(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        freq = str(p.get("frequency") or "off").strip()
        retention = int(p.get("retention") or 5)
        btype = str(p.get("type") or "full").strip()
        remote_id = str(p.get("remote") or "").strip()
        if freq not in ("off", "daily", "weekly") or btype not in ("full", "db", "storage") \
                or not re.fullmatch(r"[A-Za-z0-9._-]*", remote_id) or not 1 <= retention <= 999:
            raise ValueError("Invalid backup schedule")
        return laravel_dev.set_backup_schedule(site["name"], site["path"], frequency=freq, retention=retention, backup_type=btype, remote_id=remote_id)

    def api_backup_prune(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        keep = int(p.get("keep") or 5)
        return laravel_dev.prune_backups(site["path"], keep=keep)

    def api_site_routes(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        force = bool(p.get("force"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.get_routes(site["path"], php_bin=php_bin, force=force)

    def api_open_file(self, p):
        path = p.get("path")
        line = p.get("line")
        # The profiler reports callers relative to the project (app/Models/User.php).
        if path and not os.path.isabs(path) and p.get("name"):
            root = os.path.realpath(sites.find_site(require(NAME_RE, p.get("name"), "site name"))["path"])
            path = os.path.realpath(os.path.join(root, path))
            if not path.startswith(root + os.sep):
                raise ValueError("That file is outside the project")
        if not path or not os.path.exists(path):
            raise ValueError(f"File not found: {path}")
        return osutil.open_in_editor(path, self.prefs.get("editor", ""), line=line)

    def api_artisan_commands(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.get_artisan_commands(site["path"], php_bin=php_bin)

    def api_site_doctor(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.check_site_health(site["path"], php_bin=php_bin)

    def api_site_doctor_heal(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.heal_site(site["path"], php_bin=php_bin)

    def api_tests_discover(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        import test_runner
        return test_runner.discover_tests(site["path"])

    def api_tests_run(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        filter_q = str(p.get("filter") or "").strip()
        cov = bool(p.get("coverage", False))
        stop_on_fail = bool(p.get("stop_on_failure", False))
        import test_runner
        return test_runner.run_tests_enhanced(site["path"], php_bin=php_bin, filter_query=filter_q, coverage=cov, stop_on_failure=stop_on_fail)

    def api_package_audit(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        force = bool(p.get("force"))
        return laravel_dev.audit_packages(site["path"], php_bin=php_bin, force=force)

    def api_git_info(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return sites.git_extended_info(site["name"])

    def api_git_diff(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return sites.git_file_diff(site["name"], file_path=str(p.get("file") or "").strip())

    def api_dumps_list(self, p):
        return self.dumps_server.list_dumps(site_name=p.get("name", ""))

    def api_dumps_clear(self, _p):
        self.dumps_server.clear()
        return {"ok": True}

    def api_dumps_status(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        env_file = Path(site["path"]) / ".env"
        active = False
        if env_file.is_file():
            try:
                import envfile
                ed = envfile.to_dict(env_file.read_text(encoding="utf-8", errors="replace"))
                active = ed.get("VAR_DUMPER_FORMAT") == DUMPS_FORMAT
            except Exception:
                pass
        import dumps
        config_cached = (Path(site["path"]) / "bootstrap" / "cache" / "config.php").is_file()
        return {
            "server_running": self.dumps_server.running,
            "port": dumps.DUMPS_PORT,
            "site_active": active,
            "config_cached": config_cached,
            "count": len(self.dumps_server.list_dumps(site["name"])),
        }

    def api_dumps_toggle(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        enable = bool(p.get("enable"))
        env_file = Path(site["path"]) / ".env"
        if not env_file.is_file():
            return {"ok": False, "error": ".env file not found"}
        import dumps
        if enable and not self.dumps_server.running:
            started = self.dumps_server.start()
            if not started:
                return {
                    "ok": False,
                    "error": f"Could not bind to port {dumps.DUMPS_PORT}. Another process (such as php artisan dump-server) may be using it."
                }
        elif not enable:
            try:
                other_active = False
                for s in sites.list_sites():
                    if s["name"] != site["name"]:
                        ef = Path(s.get("path", "")) / ".env"
                        if ef.is_file() and DUMPS_FORMAT in ef.read_text(errors="replace"):
                            other_active = True
                            break
                if not other_active and self.dumps_server.running:
                    self.dumps_server.stop()
            except Exception:
                pass

        import envfile
        text = env_file.read_text(encoding="utf-8", errors="replace")
        changes = {"VAR_DUMPER_FORMAT": DUMPS_FORMAT if enable else None}
        if "VAR_DUMPER_SERVER" in envfile.to_dict(text):
            changes["VAR_DUMPER_SERVER"] = None
        env_file.write_text(envfile.apply(text, changes), encoding="utf-8")
        cached = (Path(site["path"]) / "bootstrap" / "cache" / "config.php").is_file()
        return {"ok": True, "server_running": self.dumps_server.running, "site_active": enable, "config_cached": cached}

    # ── Performance Monitor & Profiler (Phase 6) ─────────────────────────────

    def api_perf_status(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        profiler = perf.check_profiler_status(site["path"])
        log_file = Path(f"/var/log/nginx/laravel-dev/{site['name']}.json")
        fallback_log = CONFIG_DIR / "logs" / f"{site['name']}.json"
        return {
            "nginx_available": log_file.is_file() or fallback_log.is_file(),
            "profiler_installed": profiler["installed"],
            "profiler_active": profiler["active"],
            # Request traffic is universal; the SQL collector is currently a
            # Laravel adapter and needs the managed installer to add Composer
            # metadata safely.
            "profiler_supported": sites.MANAGED and site.get("type") == "laravel",
            "profiler_adapter": "laravel" if site.get("type") == "laravel" else "",
        }

    def api_perf_nginx(self, p):
        name = require(NAME_RE, p.get("name"), "site name")
        limit = max(1, min(int(p.get("limit") or 100), 500))
        filter_assets = bool(p.get("filter_assets", True))
        status = str(p.get("status") or "").strip()
        min_dur = float(p.get("min_duration_ms") or 0.0)
        search = str(p.get("search") or "").strip()
        return perf.get_nginx_requests(
            name, limit=limit, filter_assets=filter_assets,
            status_filter=status, min_duration_ms=min_dur, search=search
        )

    def api_perf_requests(self, p):
        name = require(NAME_RE, p.get("name"), "site name")
        limit = max(1, min(int(p.get("limit") or 50), 200))
        n_plus_one_only = bool(p.get("n_plus_one_only", False))
        route = str(p.get("route") or "").strip()
        return perf.get_profiled_requests(
            name, limit=limit, n_plus_one_only=n_plus_one_only, route=route
        )

    def api_perf_telescope(self, p):
        name = require(NAME_RE, p.get("name"), "site name")
        limit = max(1, min(int(p.get("limit") or 100), 500))
        category = str(p.get("category") or "requests").strip()
        search = str(p.get("search") or "").strip()
        status = str(p.get("status") or "").strip()
        min_dur = float(p.get("min_duration_ms") or 0.0)
        filter_assets = bool(p.get("filter_assets", True))
        return perf.get_telescope_feed(
            name, limit=limit, category=category, search=search,
            status_filter=status, min_duration_ms=min_dur, filter_assets=filter_assets
        )

    def api_perf_detail(self, p):
        name = require(NAME_RE, p.get("name"), "site name")
        req_id = str(p.get("id") or "").strip()
        return perf.get_request_detail(name, req_id)

    def api_perf_clear(self, p):
        name = require(NAME_RE, p.get("name"), "site name")
        return perf.clear_perf_data(name)

    def api_perf_profiler_toggle(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        enable = bool(p.get("enable", True))
        if site.get("type") != "laravel":
            raise ValueError("Detailed SQL profiling needs a framework adapter. This site still has universal request monitoring through Nginx.")
        if not sites.MANAGED:
            raise ValueError("Install the Laravel profiler from managed Linux mode. This site still has universal request monitoring when access logging is configured.")

        bin_path = sites.BASE_DIR / "bin" / "laravel-dev"
        cmd = [str(bin_path), "profiler", "enable" if enable else "disable", site["name"]]
        # composer needs far longer than run_quiet's 10s, and its errors go to stderr.
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        except subprocess.TimeoutExpired:
            return {"ok": False, "message": "composer took longer than 10 minutes", "enabled": not enable}
        out = (proc.stdout + "\n" + proc.stderr).strip()
        return {"ok": proc.returncode == 0, "message": out[-2000:], "enabled": enable}

    def api_share_info(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.get_share_info(site["name"], domain=site.get("domain", ""), port=str(site.get("port") or ""))

    def api_tunnel_info(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.get_tunnel_status(site["name"])

    def api_tunnel_start(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        mode = p.get("mode", "quick")
        token = p.get("token", "")
        return laravel_dev.start_tunnel(site["name"], domain=site.get("domain", ""), port=str(site.get("port") or ""),
                                        mode=mode, token=token)

    def api_tunnel_stop(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return {"ok": laravel_dev.stop_tunnel(site["name"])}

    def api_tunnel_restart(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        mode = p.get("mode", "quick")
        token = p.get("token", "")
        return laravel_dev.restart_tunnel(site["name"], domain=site.get("domain", ""), port=str(site.get("port") or ""),
                                          mode=mode, token=token)

    def api_tunnel_logs(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        lines = int(p.get("lines", 100))
        return {"logs": laravel_dev.get_tunnel_logs(site["name"], lines=lines)}

    def api_tunnel_token(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        if "token" in p:
            token = p.get("token", "")
            return {"ok": laravel_dev.set_tunnel_token(site["name"], token), "token": token}
        return {"token": laravel_dev.get_tunnel_token(site["name"])}

    def api_tunnel_list(self, _p):
        return {"tunnels": laravel_dev.list_all_tunnels()}

    def api_deploy_target_get(self, p):
        return laravel_dev.get_deploy_target(CONFIG_DIR, require(NAME_RE, p.get("name"), "site name"))

    def api_deploy_target_save(self, p):
        return laravel_dev.save_deploy_target(CONFIG_DIR, require(NAME_RE, p.get("name"), "site name"),
                                              p.get("server", ""), p.get("path", ""), p.get("branch", "main"),
                                              server_php=p.get("server_php", ""))

    def api_vault_status(self, _p):
        return self.vault.status()

    def api_vault_set_key(self, p):
        return self.vault.set_master_key(
            p.get("password", ""),
            old_password=p.get("old_password"),
            migrator=self._rekey_all_secrets,
        )

    def api_vault_unlock(self, p):
        return self.vault.unlock(p.get("password", ""))

    def api_vault_lock(self, _p):
        return self.vault.lock()

    def api_vault_disable(self, p):
        return self.vault.disable_vault(
            p.get("password", ""),
            migrator=self._rekey_all_secrets,
        )

    def _rekey_all_secrets(self, old_key, new_key):
        self.db.rekey_secrets(old_key, new_key)
        self.ai_settings.rekey(old_key, new_key)

    def api_clear_log(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        log = Path(site["path"], "storage", "logs", "laravel.log")
        if log.is_file():
            log.write_text("")
        return True

    def api_open(self, p):
        target = p.get("target")
        if target == "url":
            url = p.get("url", "")
            if not re.match(r"^https?://", url):
                raise ValueError("Only http(s) links can be opened")
            return osutil.open_path(url)
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        path = site["path"]
        if target == "browser":
            if not site.get("url"):
                raise ValueError("Start the site first — it gets its address when it runs.")
            return osutil.open_path(site["url"])
        if target == "folder":
            return osutil.open_path(path)
        if target in ("editor", "env"):
            return osutil.open_in_editor(os.path.join(path, ".env") if target == "env" else path, self.prefs.get("editor", ""))
        if target == "terminal":
            return osutil.open_terminal(cwd=path)
        raise ValueError(f"Unknown target: {target}")

    def api_run(self, p):
        return self.start_action(p.get("action"), p.get("params") or {})

    def api_cancel(self, p):
        self.runner.cancel(p.get("id"))
        return True

    def api_pick_folder(self, p, done):
        start = os.path.expanduser(p.get("current") or "")
        while start and not os.path.isdir(start):
            parent = os.path.dirname(start)
            start = "" if parent == start else parent
        self.shell.choose("folder", p.get("title") or "Choose a folder", lambda paths: done(paths[0] if paths else ""),
                          start=start or str(osutil.HOME))

    def api_pick_file(self, p, done):
        self.shell.choose("open", p.get("title") or "Choose a file", lambda paths: done(paths[0] if paths else ""),
                          start=os.path.expanduser(p.get("current") or str(osutil.HOME)))

    def api_detect(self, p):
        path = os.path.realpath(os.path.expanduser(p.get("path") or ""))
        return apps.detect_type(path) if os.path.isdir(path) else ""

    def api_save(self, p):
        settings = p.get("settings") or {}
        updates = {}
        if "LARAVEL_SITES_DIR" in settings:
            folder = os.path.expanduser(settings["LARAVEL_SITES_DIR"].strip())
            if not osutil.is_abs(folder):
                raise ValueError("The www folder must be an absolute path")
            updates["LARAVEL_SITES_DIR"] = updates["SITES_DIR"] = folder
        if settings.get("DB_TYPE", "mysql") not in ("mysql", "mariadb", "pgsql", "sqlite"):
            raise ValueError("Unsupported database type")
        if settings.get("DB_PORT") and not str(settings["DB_PORT"]).isdigit():
            raise ValueError("Database port must be a number")
        for key in ("DB_TYPE", "DB_HOST", "DB_PORT", "DB_USER", "DB_PASSWORD"):
            if key in settings:
                updates[key] = str(settings[key]).strip() if key != "DB_PASSWORD" else str(settings[key])
        if updates:
            sites.save_settings(updates)
            self._auto_cache = (0.0, [])
            self.db.close_connection("local")

        prefs = p.get("prefs")
        if prefs is not None:
            self.prefs.update({k: prefs[k] for k in (*sites.DEFAULT_PREFS, "autostart") if k in prefs})
            sites.save_prefs(self.prefs)
            self.prefs = sites.load_prefs()
        return {"settings": sites.load_settings(), "prefs": self.prefs}

    # ── apps (own server process) ───────────────────────────
    def _app_site(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        if not site.get("process") or not site["linked"]:
            raise ValueError("Only linked sites that run their own server can be started here")
        if not site.get("port"):
            raise ValueError("No port recorded for this app — unlink it and link it again")
        return site

    def _start(self, site):
        PROCESSES.start(site["name"], site["path"], site["command"], site["port"], site["type"], sites.php_binary(site.get("php")))

    def api_app_start(self, p):
        self._start(self._app_site(p))
        self.shell.refresh_tray()
        return True

    def api_app_stop(self, p):
        site = self._app_site(p)
        PROCESSES.stop(site["name"], site["path"])
        self.shell.refresh_tray()
        return True

    def api_app_restart(self, p):
        site = self._app_site(p)
        PROCESSES.stop(site["name"], site["path"])
        self._start(site)
        return True

    def api_app_log(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        text = PROCESSES.log(site["name"])
        return {"text": text or "", "exists": text is not None}

    def api_app_config(self, p):
        site = self._app_site(p)
        mode = p.get("mode") if p.get("mode") in ("dev", "prod") else site["mode"]
        command = (p.get("command") or "").strip()
        if "\n" in command or len(command) > 500:
            raise ValueError("Invalid command")
        default = apps.default_command(site["type"], mode, site["path"])
        sites.update_record(site["name"], {"RUN_MODE": mode, "RUN_COMMAND": "" if command in ("", default) else command})
        return True

    # ── environment variables ───────────────────────────────
    def api_env_read(self, p):
        if p.get("server"):
            return self._server_env(p)
        return sites.read_local_env(p.get("name"), p.get("file") or "")

    def api_env_save(self, p):
        if p.get("server"):
            return self._server_env(p, save=True)
        return sites.write_local_env(p.get("name"), p.get("file"), p.get("changes") or {}, p.get("hash") or "")

    def api_env_type(self, p):
        key = (p.get("key") or "").strip()
        if not envfile.KEY_RE.fullmatch(key) or not p.get("scope"):
            raise ValueError("Invalid variable")
        sites.set_env_type(str(p["scope"])[:500], key, bool(p.get("secret")))
        return True

    def api_env_parse(self, p):
        text = str(p.get("text") or "")
        if len(text) > 1_000_000:
            raise ValueError("That is too much text to import")
        return [{"key": i["key"], "value": i["value"]} for i in envfile.parse(text)]

    def _server_env(self, p, save=False):
        server_id, project = p.get("server", ""), (p.get("path") or "").rstrip("/")
        if not project.startswith("/"):
            raise ValueError("Invalid project path")
        name = sites.env_file_name(p.get("file") or ".env")
        files, text, example = self.remote.read_env(server_id, project, name)
        if save:
            if p.get("hash") and envfile.digest(text or "") != p["hash"]:
                raise ValueError("The file changed on the server since you opened it. Reload to see the latest values.")
            new_text = envfile.apply(text or "", envfile.validate_changes(p.get("changes") or {}))
            self.remote.write_env(server_id, f"{project}/{name}", new_text)
            files, text, example = self.remote.read_env(server_id, project, name)
        payload = sites.env_payload(text or "", text is not None, files or [".env"], name, f"server:{server_id}:{project}", example)
        payload["remote"] = True
        return payload

    # ── remote servers ──────────────────────────────────────
    def api_servers(self, _p):
        return {"servers": self.remote.list(), "ssh_hosts": self.remote.ssh_config_hosts(), "mux": self.remote.mux}

    def api_server_save(self, p):
        return self.remote.upsert(p)

    def api_server_remove(self, p):
        return self.remote.remove(p.get("id", ""))

    def api_server_info(self, p):
        return self.remote.info(p.get("id", ""))

    def api_server_disconnect(self, p):
        for spec in list(self.db.ephemeral.values()):
            if spec.get("server") == p.get("id"):
                self.db.close_connection(spec["id"])
        return self.remote.disconnect(p.get("id", ""))

    def api_server_sites(self, p):
        return self.remote.sites(p.get("id", ""))

    def api_server_ls(self, p):
        return self.remote.list_dir(p.get("id", ""), p.get("path") or "~", bool(p.get("hidden")))

    def api_server_log(self, p):
        return self.remote.tail_log(p.get("id", ""), p.get("path", ""), p.get("type") or "laravel",
                                    p.get("pm2") if p.get("pm2") is not None else "", p.get("unit") or "")

    def api_server_file_op(self, p):
        return self.remote.file_op(p.get("id", ""), p.get("op"), p.get("path", ""), p.get("target", ""))

    def api_server_edit(self, p):
        local = self.remote.fetch_for_edit(p.get("id", ""), p.get("path", ""))
        return osutil.open_in_editor(local, self.prefs.get("editor", ""))

    def api_server_sudo(self, p):
        return self.remote.verify_sudo(p.get("id", ""), p.get("password") or "")

    def api_server_terminal(self, p):
        return osutil.open_terminal(command=self.remote.terminal_argv(p.get("id", ""), p.get("path", "")))

    def api_forge_provision_status(self, p):
        import forge
        return {"ok": True, "status": forge.get_provision_status(self.remote, p.get("server", ""))}

    def api_forge_list_releases(self, p):
        import forge
        return {"ok": True, **forge.list_releases(self.remote, p.get("server", ""), p.get("path", ""))}

    def api_forge_deploy_key(self, p):
        server_id = p.get("server", "")
        domain = p.get("domain", "")
        github_repo = p.get("github_repo", "")
        server = self.remote.get(server_id)
        key_name = f"ld_{domain.replace('.', '_')}"
        script = f"""
mkdir -p ~/.ssh && chmod 700 ~/.ssh
KEY_FILE="$HOME/.ssh/{key_name}"
if [ ! -f "$KEY_FILE" ]; then
  ssh-keygen -t ed25519 -N "" -f "$KEY_FILE" -C "laravel-dev-{domain}" >/dev/null
fi
cat "$KEY_FILE.pub"
"""
        code, pubkey, err = self.remote.run(server, script)
        if code != 0 or not pubkey.strip():
            return {"ok": False, "error": f"Failed to generate deploy key: {err}"}
        pubkey = pubkey.strip()
        gh_res = None
        if github_repo and "/" in github_repo:
            owner, repo = github_repo.split("/", 1)
            gh_res = self.gh.add_deploy_key(owner, repo, f"Laravel Dev Tool ({server['name']})", pubkey, read_only=True)
        return {"ok": True, "public_key": pubkey, "github_result": gh_res}

    def api_forge_dns_setup(self, p):
        zone_id = p.get("zone_id", "")
        domain = p.get("domain", "")
        server_ip = p.get("server_ip", "")
        proxied = bool(p.get("proxied", True))
        if not zone_id or not domain or not server_ip:
            return {"ok": False, "error": "zone_id, domain, and server_ip are required"}
        return self.cf.create_dns_record(zone_id, "A", domain, server_ip, proxied=proxied)

    def api_forge_db_pull(self, p):
        import forge
        import gzip
        import shutil
        server_id = p.get("server", "")
        app_dir = p.get("path", "")
        local_site_name = p.get("local_site", "")
        exclude = p.get("exclude", "sessions,jobs,telescope_entries")

        all_sites = sites.list_sites()
        local_site = next((s for s in all_sites if s["name"] == local_site_name), None)
        if not local_site:
            return {"ok": False, "error": f"Local site '{local_site_name}' not found."}

        # 1. Snapshot local database first
        snap_res = laravel_dev.create_db_snapshot(local_site["path"], local_site["name"], "pre_forge_pull", "Pre-pull backup before remote DB sync")

        # 2. Dump from remote
        server = self.remote.get(server_id)
        script_path = forge.FORGE_SCRIPTS_DIR / "db_dump.sh"
        script_content = script_path.read_text(encoding="utf-8")
        code, raw_dump, err = self.remote.run(server, script_content, app_dir, exclude, binary=True, timeout=600)
        if code != 0 or not raw_dump:
            return {"ok": False, "error": f"Remote database dump failed: {err.strip() or 'No data returned'}"}

        # 3. Import locally
        try:
            sql_bytes = gzip.decompress(raw_dump)
        except Exception:
            sql_bytes = raw_dump

        spec = laravel_dev.get_site_db_spec(Path(local_site["path"]))
        if not spec:
            return {"ok": False, "error": "No database connection configured in local site .env"}

        driver = spec.get("driver")
        if driver in ("mysql", "mariadb"):
            tool = shutil.which("mysql")
            if not tool:
                return {"ok": False, "error": "Local mysql client not found"}
            sql_bytes = re.sub(rb"/\*M!999999\\?-? enable the sandbox mode \*/\s*", b"", sql_bytes)
            env = os.environ.copy()
            env["MYSQL_PWD"] = spec.get("password") or ""
            argv = [tool, "-h", spec.get("host") or "127.0.0.1", "-P", str(spec.get("port") or "3306"),
                    "-u", spec.get("user") or "root", spec["database"]]
            proc = subprocess.Popen(argv, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            _, stderr = proc.communicate(input=sql_bytes)
            if proc.returncode != 0:
                return {"ok": False, "error": f"MySQL local import failed: {stderr.decode('utf-8', errors='replace').strip()}"}
        elif driver in ("pgsql", "postgres", "postgresql"):
            tool = shutil.which("psql")
            if not tool:
                return {"ok": False, "error": "Local psql client not found"}
            env = os.environ.copy()
            env["PGPASSWORD"] = spec.get("password") or ""
            argv = [tool, "-h", spec.get("host") or "127.0.0.1", "-p", str(spec.get("port") or "5432"),
                    "-U", spec.get("user") or "postgres", "-d", spec["database"]]
            proc = subprocess.Popen(argv, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            _, stderr = proc.communicate(input=sql_bytes)
            if proc.returncode != 0:
                return {"ok": False, "error": f"PostgreSQL local import failed: {stderr.decode('utf-8', errors='replace').strip()}"}
        else:
            return {"ok": False, "error": f"Unsupported database driver: {driver}"}

        return {"ok": True, "message": f"Successfully pulled remote DB to local '{local_site_name}'!", "snapshot": snap_res.get("snapshot")}

    def _transfer(self, label, work):
        def run():
            try:
                work()
                self.shell.post(self.emit, {"type": "transfer", "ok": True, "label": label})
            except (RemoteError, OSError) as exc:
                self.shell.post(self.emit, {"type": "transfer", "ok": False, "label": label, "error": str(exc)})
        threading.Thread(target=run, daemon=True).start()

    def api_server_download(self, p, done):
        server_id, remote_path, is_dir = p.get("id", ""), p.get("path", ""), bool(p.get("dir"))
        name = os.path.basename(remote_path.rstrip("/")) + (".tar.gz" if is_dir else "")

        def chosen(paths):
            if paths:
                self._transfer(f"Downloaded {name}", lambda: self.remote.download(server_id, remote_path, is_dir, paths[0]))
            done(bool(paths))

        self.shell.choose("save", "Save download", chosen, start=osutil.downloads_dir(), name=name, accept="Save")

    def api_server_upload(self, p, done):
        server_id, remote_dir = p.get("id", ""), p.get("dir", "").rstrip("/")

        def chosen(files):
            if files:
                def work():
                    for local in files:
                        remote_path = f"{remote_dir}/{os.path.basename(local)}"
                        self.remote.upload_bytes(server_id, remote_path, Path(local).read_bytes(), overwrite=False)
                self._transfer(f"Uploaded {len(files)} file{'s' if len(files) > 1 else ''}", work)
            done(len(files))

        self.shell.choose("open", "Upload files", chosen, start=str(osutil.HOME), multiple=True, accept="Upload")

    # ── databases ───────────────────────────────────────────
    def db_auto_connections(self):
        """Connections that need no setup: the local server from Settings and each site's .env."""
        stamp, cached = self._auto_cache
        if time.time() - stamp < 15:
            return cached
        specs = []
        settings = sites.load_settings()
        if settings.get("DB_TYPE") in ("mysql", "mariadb", "pgsql"):
            specs.append({"id": "local", "name": "Local server", "driver": settings["DB_TYPE"],
                          "host": settings.get("DB_HOST") or "127.0.0.1", "port": settings.get("DB_PORT") or "",
                          "user": settings.get("DB_USER") or "", "password": settings.get("DB_PASSWORD") or "", "source": "local"})
        for site in sites.list_sites():
            if not site["linked"] or not site["exists"]:
                continue
            env = sites.parse_env_file(Path(site["path"]) / ".env")
            spec = spec_from_env(env, site["path"])
            if spec is None and site["type"] == "django" and (Path(site["path"]) / "db.sqlite3").is_file():
                spec = {"driver": "sqlite", "file": str(Path(site["path"]) / "db.sqlite3")}
            if spec is None:
                continue
            spec.update({"id": f"site:{site['name']}", "name": site["name"], "source": "site", "site": site["name"], "type": site["type"]})
            specs.append(spec)
        self._auto_cache = (time.time(), specs)
        return specs

    def api_db_connections(self, p):
        if p.get("refresh"):
            self._auto_cache = (0.0, [])
        return self.db.list()

    def api_db_save(self, p):
        return self.db.save(p)

    def api_db_remove(self, p):
        return self.db.remove(p.get("id", ""))

    def api_db_test(self, p):
        return self.db.test(p)

    def api_db_test_ssh(self, p):
        return self.db.test_ssh(p)

    def api_db_close(self, p):
        return self.db.close_connection(p.get("id", ""))

    def api_db_databases(self, p):
        return self.db.databases(p.get("conn", ""))

    def api_db_tables(self, p):
        return self.db.tables(p.get("conn", ""), p.get("database") or "")

    def api_db_structure(self, p):
        return self.db.structure(p.get("conn", ""), p.get("database") or "", p.get("table") or "")

    def api_db_hologram(self, p):
        return self.db.hologram(p.get("conn", ""), p.get("database") or "")

    def api_db_generate_migration(self, p):
        return self.db.generate_migration(p.get("conn", ""), p.get("database") or "", p.get("table") or "")

    def api_db_generate_model(self, p):
        return self.db.generate_model(p.get("conn", ""), p.get("database") or "", p.get("table") or "")

    def api_db_seed_data(self, p):
        return self.db.seed_data(p.get("conn", ""), p.get("database") or "", p.get("table") or "",
                                 count=int(p.get("count", 25)), mode=p.get("mode", "code"))

    def api_db_save_code(self, p):
        return self.db.save_code_to_project(
            p.get("site") or "",
            p.get("type") or "model",
            p.get("file_name") or "",
            p.get("code") or "",
            overwrite=bool(p.get("overwrite", False)),
        )

    def api_db_explain(self, p):
        return self.db.explain_query(p.get("conn", ""), p.get("database") or "", p.get("sql") or "")

    def api_db_diff(self, p):
        return self.db.schema_diff(p.get("src_conn", ""), p.get("src_db") or "",
                                  p.get("tgt_conn", ""), p.get("tgt_db") or "")

    def api_db_sync(self, p):
        stop_on_error = p.get("stop_on_error", True)
        return self.db.execute_sync(p.get("tgt_conn", ""), p.get("tgt_db") or "", p.get("statements") or [], stop_on_error=stop_on_error)

    def api_db_rows(self, p):
        return self.db.rows(p.get("conn", ""), p.get("database") or "", p.get("table") or "", page=p.get("page", 1),
                            limit=p.get("limit", 100), sort=p.get("sort") or "", direction=p.get("dir") or "ASC",
                            filters=p.get("filters") or [], search=p.get("search") or "", where=p.get("where") or "")

    def api_db_cell(self, p):
        return self.db.cell_value(p.get("conn", ""), p.get("database") or "", p.get("table") or "", p.get("key") or {}, p.get("column") or "")

    def api_db_apply(self, p):
        return self.db.apply(p.get("conn", ""), p.get("database") or "", p.get("table") or "", p.get("changes") or {})

    def api_db_query(self, p):
        return self.db.query(p.get("conn", ""), p.get("database") or "", p.get("sql") or "")

    def api_db_create_database(self, p):
        return self.db.create_database(p.get("conn", ""), (p.get("name") or "").strip(),
                                       p.get("charset") or "utf8mb4", p.get("collation") or "utf8mb4_unicode_ci")

    def api_db_drop_database(self, p):
        return self.db.drop_database(p.get("conn", ""), p.get("name") or "")

    def api_db_table_op(self, p):
        return self.db.table_op(p.get("conn", ""), p.get("database") or "", p.get("table") or "", p.get("op"), p.get("target") or "")

    def api_db_for_site(self, p):
        name = require(NAME_RE, p.get("name"), "site name")
        self._auto_cache = (0.0, [])
        for spec in self.db_auto_connections():
            if spec.get("site") == name:
                return {"conn": spec["id"], "database": spec.get("database") or ("main" if spec["driver"] == "sqlite" else "")}
        raise ValueError("No database settings found in this project's .env (DB_CONNECTION / DB_DATABASE or DATABASE_URL).")

    def api_server_db(self, p):
        """Open the database a server site uses, through an SSH tunnel."""
        server_id, project = p.get("id", ""), (p.get("path") or "").rstrip("/")
        if not project.startswith("/"):
            raise ValueError("Invalid project path")
        server = self.remote.get(server_id)
        _, text, _ = self.remote.read_env(server_id, project, ".env")
        spec = spec_from_env(envfile.to_dict(text or ""), project)
        if spec is None:
            raise ValueError("No database settings found in the server's .env (DB_CONNECTION / DATABASE_URL).")
        if spec["driver"] == "sqlite":
            raise ValueError("This site uses SQLite on the server — download the database file to open it.")
        conn_id = f"r{abs(hash((server_id, project))) % 10**10}"
        spec.update({"id": conn_id, "name": f"{os.path.basename(project)} · {server['name']}", "server": server_id,
                     "source": "server", "server_name": server["name"]})
        self.db.close_connection(conn_id)
        self.db.add_ephemeral(spec)
        return {"conn": conn_id, "database": spec.get("database") or ""}

    def _db_job(self, kind, label, work):
        def run():
            last = [0.0]

            def progress(count):
                if time.time() - last[0] > 0.5:
                    last[0] = time.time()
                    self.shell.post(self.emit, {"type": "db-progress", "kind": kind, "label": label, "count": count})
            try:
                count = work(progress)
                self.shell.post(self.emit, {"type": "db-job", "kind": kind, "ok": True, "label": label, "count": count})
            except Exception as exc:  # noqa: BLE001
                self.shell.post(self.emit, {"type": "db-job", "kind": kind, "ok": False, "label": label,
                                            "error": str(exc) if isinstance(exc, (DBError, OSError)) else friendly_error(exc)})
        threading.Thread(target=run, daemon=True).start()

    def api_db_export(self, p, done):
        conn, database, tables = p.get("conn", ""), p.get("database") or "", p.get("tables") or []
        fmt = p.get("format") if p.get("format") in ("sql", "csv", "json") else "sql"
        base = tables[0] if len(tables) == 1 else (database or "database")
        name = f"{re.sub(r'[^A-Za-z0-9_.-]+', '_', base)}-{time.strftime('%Y%m%d-%H%M')}.{fmt}"

        def chosen(paths):
            if paths:
                self._db_job("export", f"Exported {base}", lambda progress: self.db.export(conn, database, tables, fmt, paths[0], progress))
            done(bool(paths))

        self.shell.choose("save", "Export", chosen, start=osutil.downloads_dir(), name=name, accept="Export")

    def api_db_import(self, p, done):
        conn, database = p.get("conn", ""), p.get("database") or ""

        def chosen(paths):
            if paths:
                label = f"Imported {os.path.basename(paths[0])} into {database or 'database'}"
                self._db_job("import", label, lambda progress: self.db.import_sql(conn, database, paths[0], progress))
            done(bool(paths))

        self.shell.choose("open", "Import an .sql file", chosen, start=osutil.downloads_dir(), accept="Import")

    def api_db_pick_sqlite(self, p, done):
        self.shell.choose("open", "Choose a SQLite database", lambda paths: done(paths[0] if paths else ""),
                          start=os.path.expanduser(p.get("current") or str(osutil.HOME)))

    # ── Phase 7: Productivity & Developer Tools ──────────────────────────────

    def api_models_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return {"ok": True, "models": laravel_dev.list_models(site["path"])}

    def api_model_show(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        model_name = str(p.get("model") or "").strip()
        if not model_name:
            return {"ok": False, "error": "Model name required"}
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.show_model(site["path"], model_name, php_bin=php_bin)

    def api_log_errors_aggregated(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        file_name = p.get("file") or "laravel.log"
        return laravel_dev.get_aggregated_errors(site["path"], file_name=file_name)

    def api_log_error_resolve(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        sig = str(p.get("signature") or "")
        resolved = bool(p.get("resolved", True))
        return laravel_dev.mark_error_resolved(site["path"], sig, resolved=resolved)

    def api_route_test(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        method = str(p.get("method") or "GET").upper()
        uri = str(p.get("uri") or "/")
        if not uri.startswith("/"):
            uri = "/" + uri
        base = site.get("url") or f"http://{site['domain']}"
        url = f"{base.rstrip('/')}{uri}"
        headers = p.get("headers") or {}
        body = p.get("body") or ""
        return laravel_dev.test_route_request(url, method=method, headers=headers, body=body)

    def api_about_info(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.get_about_info(site["path"], php_bin=php_bin)

    def api_events_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.get_events_list(site["path"], php_bin=php_bin)

    def api_config_show(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        cfg_name = str(p.get("config") or "app").strip()
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.get_config_show(site["path"], config_name=cfg_name, php_bin=php_bin)

    def api_mailables_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return {"ok": True, "mailables": laravel_dev.list_mailables(site["path"])}

    def api_mailable_render(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        mailable = str(p.get("mailable") or "").strip()
        if not mailable:
            return {"ok": False, "error": "Mailable name required"}
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.render_mailable(site["path"], mailable, php_bin=php_bin)

    def api_translations_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return laravel_dev.get_translations(site["path"], php_bin=sites.php_binary(site.get("php")))

    def api_translation_save(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        loc = str(p.get("locale") or "en").strip()
        key = str(p.get("key") or "").strip()
        val = str(p.get("value") or "")
        return laravel_dev.save_translation(site["path"], loc, key, val)

    def api_db_snapshots_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        return {"ok": True, "snapshots": laravel_dev.list_db_snapshots(site["name"])}

    def api_db_snapshot_create(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        name = str(p.get("snapshot_name") or "snapshot").strip()
        desc = str(p.get("description") or "").strip()
        return laravel_dev.create_db_snapshot(site["path"], site["name"], name=name, description=desc)

    def api_db_snapshot_restore(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        snap_id = str(p.get("snapshot_id") or "").strip()
        return laravel_dev.restore_db_snapshot(site["path"], site["name"], snap_id)

    def api_db_snapshot_delete(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        snap_id = str(p.get("snapshot_id") or "").strip()
        return laravel_dev.delete_db_snapshot(site["name"], snap_id)

    # ── Project Time Machine / Checkpoints ─────────────────────────────────
    def api_checkpoint_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        import checkpoints
        return {"ok": True, "checkpoints": checkpoints.list_checkpoints(site["name"])}

    def api_checkpoint_create(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        import checkpoints
        note = str(p.get("note") or "").strip()
        include_storage = bool(p.get("include_storage", True))
        return checkpoints.create_checkpoint(site["name"], site["path"], note=note, include_storage=include_storage)

    def api_checkpoint_restore(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        cp_id = require(NAME_RE, p.get("id"), "checkpoint id")
        import checkpoints
        return checkpoints.restore_checkpoint(site["name"], site["path"], cp_id)

    def api_checkpoint_delete(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        cp_id = require(NAME_RE, p.get("id"), "checkpoint id")
        import checkpoints
        return checkpoints.delete_checkpoint(site["name"], cp_id)

    # ── Live Cache & Redis Explorer (Feature 5) ────────────────────────────
    def api_cache_list(self, p):
        site_path = str(p.get("site_path") or "").strip()
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
        import cache_explorer
        q = str(p.get("query") or "").strip()
        limit = max(1, min(int(p.get("limit") or 100), 500))
        return cache_explorer.list_cache_keys(site_path, query=q, limit=limit)

    def api_cache_get(self, p):
        site_path = str(p.get("site_path") or "").strip()
        php_bin = "php"
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
            php_bin = sites.php_binary(site.get("php"))
        key = require(NON_EMPTY_RE, p.get("key"), "cache key")
        import cache_explorer
        return cache_explorer.get_cache_value(site_path, key, php_bin=php_bin)

    def api_cache_delete(self, p):
        site_path = str(p.get("site_path") or "").strip()
        php_bin = "php"
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
            php_bin = sites.php_binary(site.get("php"))
        key = require(NON_EMPTY_RE, p.get("key"), "cache key")
        import cache_explorer
        return cache_explorer.delete_cache_key(site_path, key, php_bin=php_bin)

    def api_cache_flush(self, p):
        site_path = str(p.get("site_path") or "").strip()
        php_bin = "php"
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
            php_bin = sites.php_binary(site.get("php"))
        import cache_explorer
        return cache_explorer.flush_all_cache(site_path, php_bin=php_bin)

    # ── Multi-Domain & Wildcard Subdomains (Feature 6) ─────────────────────
    def api_domains_get(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        return sites.get_site_domains(site_name)

    def api_domains_update(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        aliases = p.get("aliases")
        if isinstance(aliases, str):
            aliases = [a.strip() for a in aliases.replace(",", " ").split() if a.strip()]
        wildcard = bool(p.get("wildcard", True))
        return sites.update_site_domains(site_name, aliases=aliases, wildcard=wildcard)

    # ── Per-Site Resource Monitor (Feature 7) ──────────────────────────────
    def api_site_resources(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        import resources
        return resources.get_site_metrics(site["name"], site["path"])

    def api_site_kill_process(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        pid = int(p.get("pid") or 0)
        import resources
        return resources.kill_site_process(site["name"], site["path"], pid)

    # ── Universal Command Palette (Feature 8) ──────────────────────────────
    def api_palette_search(self, p):
        query = str(p.get("query") or "").strip()
        site_name = str(p.get("site_name") or "").strip()
        import palette
        items = palette.search_palette(query, current_site_name=site_name)
        return {"ok": True, "query": query, "items": items, "count": len(items)}

    # ── Vite & Asset Watcher Supervisor (Feature 9) ────────────────────────
    def api_vite_status(self, p):
        site_path = str(p.get("site_path") or "").strip()
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
        import vite_watcher
        return vite_watcher.get_vite_status(site_path)

    def api_vite_start(self, p):
        site_path = str(p.get("site_path") or "").strip()
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
        import vite_watcher
        return vite_watcher.start_vite(site_path)

    def api_vite_stop(self, p):
        site_path = str(p.get("site_path") or "").strip()
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
        import vite_watcher
        return vite_watcher.stop_vite(site_path)

    def api_vite_ensure(self, p):
        site_path = str(p.get("site_path") or "").strip()
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
        wait = bool(p.get("wait", True))
        timeout = float(p.get("timeout", 10.0))
        import vite_watcher
        return vite_watcher.ensure_vite_running(site_path, wait=wait, timeout=timeout)

    def api_vite_touch(self, p):
        site_path = str(p.get("site_path") or "").strip()
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
        import vite_watcher
        vite_watcher.touch_vite_activity(site_path)
        return {"ok": True}

    # ── Laravel Cloud CLI Integration (Stage 12) ───────────────────────────
    def api_cloud_status(self, p):
        import laravel_cloud
        cli_st = laravel_cloud.get_cloud_cli_status()
        site_st = None
        site_name = str(p.get("name") or "").strip()
        site_path = str(p.get("site_path") or "").strip()
        if not site_path and site_name:
            try:
                site = sites.find_site(site_name)
                if site:
                    site_path = site["path"]
            except Exception:
                pass
        if site_path:
            site_st = laravel_cloud.get_project_cloud_status(site_path)
        return {"ok": True, "cli": cli_st, "project": site_st}

    def api_cloud_link(self, p):
        import laravel_cloud
        site_name = require(NAME_RE, p.get("name"), "site name")
        site = sites.find_site(site_name)
        app_name = str(p.get("app_name") or site["name"]).strip()
        env = str(p.get("environment") or "production").strip()
        return laravel_cloud.link_project_cloud(site["path"], app_name, environment=env)

    def api_cloud_deploy(self, p):
        import laravel_cloud
        site_name = require(NAME_RE, p.get("name"), "site name")
        site = sites.find_site(site_name)
        env = str(p.get("environment") or "production").strip()
        branch = str(p.get("branch") or "").strip() or None
        return laravel_cloud.deploy_project_cloud(site["path"], environment=env, branch=branch)

    # ── In-Browser Studio & Studio Agent (Stage 13) ────────────────────────
    def api_studio_agents_list(self, _p):
        import studio_agent
        agents = studio_agent.detect_installed_agents(self.ai_settings)
        return {"ok": True, "agents": agents, "count": len(agents)}

    def api_studio_agent_run(self, p):
        """One turn of a saved Studio conversation (creates the conversation when none is given)."""
        import studio_agent
        import studio_history
        site_name = require(NAME_RE, p.get("name"), "site name")
        site = sites.find_site(site_name)
        prompt = str(p.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("Prompt cannot be empty.")
        agent_id = str(p.get("agent_id") or "auto").strip()
        conv_id = str(p.get("conversation_id") or "").strip()
        conv = studio_history.get(site_name, conv_id) if conv_id else studio_history.create(site_name, agent_id)
        res = studio_agent.run_studio_agent_task(
            site["path"], prompt, agent_id=agent_id, conversation=conv, ai_settings=self.ai_settings,
            allow_edits=bool(p.get("allow_edits")), mcp_cli=str(sites.CLI) if sites.MANAGED else "",
            model=str(p.get("model") or ""), effort=str(p.get("effort") or ""),
        )
        if "agent" not in res:  # the project directory is missing: nothing ran
            raise ValueError(res.get("error") or "Agent could not run.")
        conv = studio_history.append(site_name, conv["id"], [
            {"role": "user", "text": prompt},
            {"role": "agent", "text": res.get("reply") or "", "agent": res.get("agent"), "source": res.get("source"),
             "model": res.get("model") or "", "effort": res.get("effort") or "", "files_changed": res.get("files_changed") or [],
             "error": res.get("error") or "",
             "activity": res.get("activity") or [], "duration": res.get("duration") or 0},
        ], agent_id=res.get("agent_id"), agent=res.get("agent"), session_id=res.get("session_id") or "",
                        model=res.get("model") or "")
        res["conversation_id"] = conv["id"]
        res["conversation_title"] = conv["title"]
        return res

    def api_studio_agent_models(self, p):
        import studio_agent
        agent_id = require(re.compile(r"^[a-z_]{1,32}$"), p.get("agent_id") or "", "agent id")
        return studio_agent.list_agent_models(agent_id, self.ai_settings, refresh=bool(p.get("refresh")))

    def api_studio_agent_start(self, p):
        """Starts a Studio turn in the background and streams it to the page:
        {"type": "studio", "run_id", "events": [{"delta": text} | {"activity": {...}}, …]} while the agent
        works (the answer text and what it does on the way: thinking, tool calls — see
        studio_agent._ActivityStream), then {"type": "studio", "run_id", "finished": true, "result": {...}}
        (the same result as studio_agent_run). Stop it with studio_agent_cancel."""
        import studio_agent
        import studio_history
        site_name = require(NAME_RE, p.get("name"), "site name")
        site = sites.find_site(site_name)
        prompt = str(p.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("Prompt cannot be empty.")
        agent_id = str(p.get("agent_id") or "auto").strip()
        conv_id = str(p.get("conversation_id") or "").strip()
        conv = studio_history.get(site_name, conv_id) if conv_id else studio_history.create(site_name, agent_id)
        run_id = uuid.uuid4().hex[:12]
        cancel = threading.Event()
        runs = self.__dict__.setdefault("_studio_runs", {})
        runs[run_id] = cancel
        post = lambda event: self.shell.post(self.emit, event)  # noqa: E731 — eval_js belongs on the main thread
        queue, lock, last = [], threading.Lock(), [0.0]

        def flush(force=False):
            with lock:
                if not queue or (not force and time.monotonic() - last[0] < 0.08):
                    return
                events = list(queue)
                queue.clear()
                last[0] = time.monotonic()
            post({"type": "studio", "run_id": run_id, "events": events})

        def push(item):
            with lock:
                prev = queue[-1] if queue else None
                # Merge consecutive text pieces and thinking pieces: one event per ~80 ms, not per token.
                if prev and "delta" in item and "delta" in prev:
                    prev["delta"] += item["delta"]
                elif (prev and item.get("activity", {}).get("kind") == "thinking"
                      and prev.get("activity", {}).get("kind") == "thinking"):
                    prev["activity"] = {**prev["activity"], "text": prev["activity"]["text"] + item["activity"]["text"]}
                else:
                    queue.append(item)
            flush()

        def on_delta(text):
            push({"delta": text})

        def on_activity(event):
            push({"activity": dict(event)})

        perms = self.__dict__.setdefault("_studio_perms", {})

        def ask_permission(request):
            """Shows the request in Studio and waits for studio_permission_reply (or Stop)."""
            import studio_permissions
            waiter = {"run_id": run_id, "event": threading.Event(), "answer": None}
            perms[request["id"]] = waiter
            push({"permission": request})
            flush(force=True)
            studio_agent.notify_agent_completion(site_name, f"{request['agent']} needs your approval: {request['title']}",
                                                 "Studio: approval needed")
            deadline = time.monotonic() + studio_permissions.ANSWER_TIMEOUT
            try:
                while not waiter["event"].wait(0.25):
                    if cancel.is_set() or time.monotonic() > deadline:
                        break
            finally:
                perms.pop(request["id"], None)
            return waiter["answer"] or {"decision": "deny"}

        # "Allow for this conversation" answers, kept while the app runs.
        always = self.__dict__.setdefault("_studio_always", {}).setdefault(conv["id"], set())

        def work():
            try:
                res = studio_agent.run_studio_agent_task(
                    site["path"], prompt, agent_id=agent_id, conversation=conv, ai_settings=self.ai_settings,
                    allow_edits=bool(p.get("allow_edits")), mcp_cli=str(sites.CLI) if sites.MANAGED else "",
                    on_delta=on_delta, cancel=cancel, model=str(p.get("model") or ""),
                    on_activity=on_activity, think=bool(p.get("think")), effort=str(p.get("effort") or ""),
                    ask_permission=ask_permission, always_allowed=always)
                flush(force=True)
                if "agent" in res:
                    saved = studio_history.append(site_name, conv["id"], [
                        {"role": "user", "text": prompt},
                        {"role": "agent", "text": res.get("reply") or "", "agent": res.get("agent"),
                         "source": res.get("source"), "model": res.get("model") or "", "effort": res.get("effort") or "", "files_changed": res.get("files_changed") or [],
                         "error": "" if res.get("cancelled") else (res.get("error") or ""),
                         "activity": res.get("activity") or [], "duration": res.get("duration") or 0},
                    ], agent_id=res.get("agent_id"), agent=res.get("agent"), session_id=res.get("session_id") or "",
                        model=res.get("model") or "")
                    res["conversation_title"] = saved["title"]
                res["conversation_id"] = conv["id"]
            except Exception as exc:  # noqa: BLE001 — shown in the chat
                res = {"ok": False, "error": str(exc), "reply": str(exc), "conversation_id": conv["id"]}
            finally:
                runs.pop(run_id, None)
            post({"type": "studio", "run_id": run_id, "finished": True, "result": res})

        threading.Thread(target=work, daemon=True, name=f"studio-{run_id}").start()
        return {"run_id": run_id, "conversation_id": conv["id"]}

    def api_studio_permission_reply(self, p):
        """The user's answer to a permission request of a running Studio agent:
        {run_id, request_id, decision: allow | always | deny, input?: the edited command}."""
        import studio_permissions
        waiter = self.__dict__.get("_studio_perms", {}).get(str(p.get("request_id") or ""))
        if waiter is None or waiter["run_id"] != str(p.get("run_id") or ""):
            return {"ok": False, "error": "This request is no longer waiting for an answer."}
        decision = str(p.get("decision") or "")
        if decision not in studio_permissions.DECISIONS:
            raise ValueError(f"Unknown decision: {decision}")
        edited = p.get("input")
        waiter["answer"] = {"decision": decision,
                            "input": str(edited)[:20000] if isinstance(edited, str) and edited.strip() else None}
        waiter["event"].set()
        return {"ok": True}

    def api_studio_agent_cancel(self, p):
        cancel = self.__dict__.get("_studio_runs", {}).get(str(p.get("run_id") or ""))
        if cancel is None:
            return {"ok": False, "running": False}
        cancel.set()
        return {"ok": True}

    def api_studio_conversations_list(self, p):
        import studio_history
        return {"conversations": studio_history.list_conversations(require(NAME_RE, p.get("name"), "site name"))}

    def api_studio_conversation_get(self, p):
        import studio_history
        return studio_history.get(require(NAME_RE, p.get("name"), "site name"), str(p.get("id") or ""))

    def api_studio_conversation_rename(self, p):
        import studio_history
        return studio_history.rename(require(NAME_RE, p.get("name"), "site name"), str(p.get("id") or ""), str(p.get("title") or ""))

    def api_studio_conversation_delete(self, p):
        import studio_history
        return {"ok": studio_history.delete(require(NAME_RE, p.get("name"), "site name"), str(p.get("id") or ""))}

    def api_studio_revert(self, p):
        import studio_agent
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        status = p.get("file_status") or {}
        if not isinstance(status, dict):
            raise ValueError("file_status must be an object")
        return studio_agent.revert_agent_changes(site["path"], {str(k): str(v) for k, v in status.items()})

    def api_studio_voice_transcribe(self, p):
        import studio_agent
        audio_path = str(p.get("audio_path") or "").strip()
        return studio_agent.transcribe_audio_whisper(audio_path)

    def api_tinkerwell_open(self, p):
        import urllib.parse
        site_name = require(NAME_RE, p.get("name"), "site name")
        site = sites.find_site(site_name)
        url = f"tinkerwell://?project={urllib.parse.quote(site['path'])}"
        import subprocess, shutil
        if shutil.which("xdg-open"):
            try:
                subprocess.Popen(["xdg-open", url])
            except Exception:
                pass
        return {"ok": True, "url": url}

    # ── Notification & Email Studio (Feature 10) ───────────────────────────
    def api_notifications_list(self, p):
        site_path = str(p.get("site_path") or "").strip()
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
        import notification_studio
        notifs = notification_studio.list_notifications(site_path)
        return {"ok": True, "notifications": notifs, "count": len(notifs)}

    def api_notification_preview(self, p):
        site_path = str(p.get("site_path") or "").strip()
        if not site_path:
            site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
            site_path = site["path"]
        name = require(NON_EMPTY_RE, p.get("class_name") or p.get("name"), "notification class name")
        channel = str(p.get("channel") or "mail").strip().lower()
        import notification_studio
        return notification_studio.get_notification_preview(site_path, name, channel=channel)

    # ── Outgoing HTTP Mock & Interceptor (Feature 11) ──────────────────────
    def api_http_mocks_list(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        import http_interceptor
        rules = http_interceptor.list_mock_rules(site_name)
        status = http_interceptor.mocks_status(sites.find_site(site_name)["path"])
        return {"ok": True, "rules": rules, "count": len(rules), **status}

    def api_http_mocks_save(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        rules = p.get("rules") or []
        import http_interceptor
        return http_interceptor.save_mock_rules(site["name"], rules, site_path=site["path"])

    def api_http_mock_test(self, p):
        site_name = require(NAME_RE, p.get("name"), "site name")
        url = require(NON_EMPTY_RE, p.get("url"), "url")
        method = str(p.get("method") or "GET").upper()
        import http_interceptor
        match = http_interceptor.match_mock_rule(site_name, url, method=method)
        return {"ok": True, "url": url, "method": method, "matched": match is not None, "result": match}

    def api_http_outgoing_logs(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        import http_interceptor
        calls = http_interceptor.get_outgoing_http_logs(site["name"], site["path"])
        return {"ok": True, "calls": calls, "count": len(calls)}

    # ── Local Media & Storage Gallery (Feature 12) ─────────────────────────
    # The site's path always comes from the registry, never from the page.
    def api_media_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        folder = str(p.get("folder") or "").strip()
        query = str(p.get("query") or "").strip()
        file_type = str(p.get("type") or "all").strip()
        offset = max(0, int(p.get("offset") or 0))
        limit = max(1, min(int(p.get("limit") or 120), 500))
        import media_gallery
        return media_gallery.list_media_files(site["path"], folder=folder, query=query, file_type=file_type,
                                              offset=offset, limit=limit)

    def api_media_delete(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        rel_path = require(NON_EMPTY_RE, p.get("file_path") or p.get("path"), "media file path")
        import media_gallery
        res = media_gallery.delete_media_file(site["path"], rel_path)
        if not res.get("ok"):
            raise ValueError(res.get("error") or "Could not delete the file")
        return res

    def api_media_fix_symlink(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        import media_gallery
        res = media_gallery.fix_storage_symlink(site["path"], php_bin=php_bin)
        if not res.get("ok"):
            raise ValueError(res.get("error") or "Could not repair the link")
        return res

    # ── Environment Vault & Diff Inspector (Feature 13) ───────────────────
    def api_env_compare_files(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        file_a = str(p.get("file_a") or ".env").strip()
        file_b = str(p.get("file_b") or ".env.example").strip()
        import env_vault
        return env_vault.compare_env_files(site["path"], file_a_name=file_a, file_b_name=file_b)

    def api_env_encrypt(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        cipher = str(p.get("cipher") or "AES-256-CBC").strip()
        php_bin = sites.php_binary(site.get("php"))
        import env_vault
        return env_vault.encrypt_env(site["path"], cipher=cipher, php_bin=php_bin)

    def api_env_decrypt(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        key = require(NON_EMPTY_RE, p.get("key"), "encryption key")
        php_bin = sites.php_binary(site.get("php"))
        import env_vault
        return env_vault.decrypt_env(site["path"], key=key, php_bin=php_bin)

    def api_env_diff_server(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        server_id = str(p.get("server_id") or "").strip()
        remote_path = str(p.get("remote_path") or "").rstrip("/")
        if not remote_path:
            target = laravel_dev.get_deploy_target(Path(self.ui_dir).parent / "config", site["name"])
            remote_path = target.get("remote_path", "")
        if not server_id or not remote_path:
            return {"ok": False, "error": "Server ID and remote project path are required."}
        try:
            _, remote_text, _ = self.remote.read_env(server_id, remote_path, ".env")
        except Exception as exc:
            return {"ok": False, "error": f"Failed to read remote .env: {exc}"}
        return laravel_dev.compare_env_with_server(site["path"], remote_text)

    def api_artisan_make(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        make_type = str(p.get("type") or "model").strip()
        name = str(p.get("make_name") or "").strip()
        flags = p.get("flags") or []
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.artisan_make(site["path"], make_type, name, flags=flags, php_bin=php_bin)

    def api_upgrade_check(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        target_major = int(p.get("target_major")) if p.get("target_major") else None
        php_bin = sites.php_binary(site.get("php"))
        return laravel_dev.check_laravel_upgrade(site["path"], target_major=target_major, php_bin=php_bin)

    def api_settings_export(self, p):
        all_sites = sites.list_sites()
        servers_list = []
        for s in self.remote.servers():
            sc = dict(s)
            sc.pop("password", None)
            sc.pop("private_key", None)
            servers_list.append(sc)
        prefs = sites.load_prefs()  # stored in app.json
        prefs.pop("autostart", None)  # a property of this machine, not a setting to carry over
        return {
            "version": "1.0",
            "exported_at": datetime.datetime.now().isoformat(),
            "sites": [
                {"name": s.get("name"), "domain": s.get("domain"), "path": s.get("path"), "php": s.get("php"), "type": s.get("type")}
                for s in all_sites
            ],
            "servers": servers_list,
            "preferences": prefs,
        }

    def api_settings_import(self, p):
        data = p.get("data") or {}
        if not isinstance(data, dict):
            return {"ok": False, "error": "Invalid settings JSON format"}
        prefs = data.get("preferences")
        if isinstance(prefs, dict):
            merged = {**self.prefs, **{k: v for k, v in prefs.items() if k != "autostart"}}
            sites.save_prefs(merged)  # keeps only known keys
            self.prefs = sites.load_prefs()
        for s in data.get("servers", []):
            if isinstance(s, dict) and s.get("id") and s.get("host"):
                self.remote.upsert(s)
        return {"ok": True, "imported_servers": len(data.get("servers", []))}

    def api_sites_uptime(self, p):
        return {"ok": True, "uptime": sites.get_sites_uptime()}

    # ── Visual Package Hub (Feature 14) ───────────────────────────
    def api_packages_list(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        import package_hub
        return package_hub.list_packages(site["path"], php_bin=php_bin)

    def api_packages_outdated(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        force = bool(p.get("force"))
        import package_hub
        return package_hub.check_outdated(site["path"], php_bin=php_bin, force=force)

    def api_packages_audit(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = sites.php_binary(site.get("php"))
        force = bool(p.get("force"))
        import package_hub
        return package_hub.audit_packages(site["path"], php_bin=php_bin, force=force)

    def api_packages_manage(self, p):
        site = sites.find_site(require(NAME_RE, p.get("name"), "site name"))
        action = require(NAME_RE, p.get("action"), "action")
        manager = require(NAME_RE, p.get("manager"), "package manager")
        package_name = str(p.get("package") or "").strip()
        dev = bool(p.get("dev"))
        php_bin = sites.php_binary(site.get("php"))
        import package_hub
        return package_hub.manage_package(site["path"], action=action, manager=manager, package_name=package_name, dev=dev, php_bin=php_bin)

    # ── Cloudflare Hub (Feature 15) ──────────────────────────────
    def api_cf_status(self, _p):
        return self.cf.get_status()

    def api_cf_accounts(self, _p):
        return {
            "ok": True,
            "accounts": self.cf.list_stored_accounts(),
            "active_id": self.cf.get_active_account_id(),
        }

    def api_cf_switch_account(self, p):
        account_id = str(p.get("account_id") or "").strip()
        if not account_id:
            return {"ok": False, "error": "Account ID is required"}
        res = self.cf.switch_account(account_id)
        if res.get("ok"):
            res["status"] = self.cf.get_status()
        return res

    def api_cf_remove_account(self, p):
        account_id = str(p.get("account_id") or "").strip()
        if not account_id:
            return {"ok": False, "error": "Account ID is required"}
        res = self.cf.remove_account(account_id)
        if res.get("ok"):
            res["status"] = self.cf.get_status()
        return res

    def api_cf_verify_token(self, p):
        token = str(p.get("token") or "").strip()
        if not token:
            return {"ok": False, "error": "Token is required"}
        return self.cf.verify_token(token)

    def api_cf_save_credentials(self, p):
        token = str(p.get("token") or "").strip()
        account_id = str(p.get("account_id") or "").strip()
        account_name = str(p.get("account_name") or "").strip()
        email = str(p.get("email") or "").strip()
        if not token:
            return {"ok": False, "error": "Token is required"}
        ok = self.cf.save_credentials(token, account_id=account_id, account_name=account_name, email=email)
        return {"ok": ok, "status": self.cf.get_status()}

    def api_cf_disconnect(self, _p):
        return {"ok": self.cf.clear_credentials()}

    def api_cf_zones(self, p):
        page = int(p.get("page", 1))
        per_page = int(p.get("per_page", 50))
        return self.cf.list_zones(page=page, per_page=per_page)

    def api_cf_dns_list(self, p):
        zone_id = str(p.get("zone_id") or "").strip()
        if not zone_id:
            return {"ok": False, "error": "zone_id is required"}
        record_type = str(p.get("type") or "").strip()
        name = str(p.get("name") or "").strip()
        page = int(p.get("page", 1))
        return self.cf.list_dns_records(zone_id, record_type=record_type, name=name, page=page)

    def api_cf_dns_save(self, p):
        zone_id = str(p.get("zone_id") or "").strip()
        record_id = str(p.get("record_id") or "").strip()
        record_type = str(p.get("type") or "A").strip()
        name = str(p.get("name") or "").strip()
        content = str(p.get("content") or "").strip()
        proxied = bool(p.get("proxied"))
        ttl = int(p.get("ttl", 1))
        priority = int(p["priority"]) if p.get("priority") is not None and str(p.get("priority")).isdigit() else None
        comment = str(p.get("comment") or "").strip()

        if not zone_id or not name or not content:
            return {"ok": False, "error": "zone_id, name, and content are required"}

        if record_id:
            return self.cf.update_dns_record(
                zone_id, record_id, record_type, name, content,
                proxied=proxied, ttl=ttl, priority=priority, comment=comment
            )
        else:
            return self.cf.create_dns_record(
                zone_id, record_type, name, content,
                proxied=proxied, ttl=ttl, priority=priority, comment=comment
            )

    def api_cf_dns_proxy(self, p):
        zone_id = str(p.get("zone_id") or "").strip()
        record_id = str(p.get("record_id") or "").strip()
        proxied = bool(p.get("proxied"))
        if not zone_id or not record_id:
            return {"ok": False, "error": "zone_id and record_id are required"}
        return self.cf.toggle_dns_proxy(zone_id, record_id, proxied)

    def api_cf_dns_delete(self, p):
        zone_id = str(p.get("zone_id") or "").strip()
        record_id = str(p.get("record_id") or "").strip()
        if not zone_id or not record_id:
            return {"ok": False, "error": "zone_id and record_id are required"}
        return self.cf.delete_dns_record(zone_id, record_id)

    def api_cf_purge_cache(self, p):
        zone_id = str(p.get("zone_id") or "").strip()
        purge_everything = bool(p.get("purge_everything", True))
        files = p.get("files")
        if not zone_id:
            return {"ok": False, "error": "zone_id is required"}
        return self.cf.purge_cache(zone_id, purge_everything=purge_everything, files=files)

    def api_cf_dev_mode_get(self, p):
        zone_id = str(p.get("zone_id") or "").strip()
        if not zone_id:
            return {"ok": False, "error": "zone_id is required"}
        return self.cf.get_dev_mode(zone_id)

    def api_cf_dev_mode_set(self, p):
        zone_id = str(p.get("zone_id") or "").strip()
        enable = bool(p.get("enable"))
        if not zone_id:
            return {"ok": False, "error": "zone_id is required"}
        return self.cf.set_dev_mode(zone_id, enable)

    def api_cf_security_level_get(self, p):
        zone_id = str(p.get("zone_id") or "").strip()
        if not zone_id:
            return {"ok": False, "error": "zone_id is required"}
        return self.cf.get_security_level(zone_id)

    def api_cf_security_level_set(self, p):
        zone_id = str(p.get("zone_id") or "").strip()
        level = str(p.get("level") or "").strip()
        if not zone_id or not level:
            return {"ok": False, "error": "zone_id and level are required"}
        return self.cf.set_security_level(zone_id, level)

    def api_cf_r2_buckets(self, _p):
        return self.cf.list_r2_buckets()

    def api_cf_r2_create_bucket(self, p):
        name = str(p.get("name") or "").strip()
        if not name:
            return {"ok": False, "error": "Bucket name is required"}
        location_hint = str(p.get("location_hint") or "").strip()
        return self.cf.create_r2_bucket(name, location_hint=location_hint)

    def api_cf_r2_delete_bucket(self, p):
        name = str(p.get("name") or "").strip()
        if not name:
            return {"ok": False, "error": "Bucket name is required"}
        return self.cf.delete_r2_bucket(name)

    def api_cf_r2_apply_site(self, p):
        site_name = str(p.get("site") or "").strip()
        bucket = str(p.get("bucket") or "").strip()
        access_key = str(p.get("access_key") or "").strip()
        secret_key = str(p.get("secret_key") or "").strip()
        if not site_name or not bucket:
            return {"ok": False, "error": "Site and bucket name are required"}

        site = sites.find_site(require(NAME_RE, site_name, "site name"))
        env_path = Path(site["path"]) / ".env"
        if not env_path.is_file():
            return {"ok": False, "error": f".env file not found at {env_path}"}

        acc_id = self.cf.load_credentials().get("account_id", "")
        endpoint = f"https://{acc_id}.r2.cloudflaredstorage.com" if acc_id else ""

        updates = {
            "FILESYSTEM_DISK": "r2",
            "R2_BUCKET": bucket,
        }
        if endpoint:
            updates["R2_ENDPOINT"] = endpoint
        if access_key:
            updates["R2_ACCESS_KEY_ID"] = access_key
        if secret_key:
            updates["R2_SECRET_ACCESS_KEY"] = secret_key

        try:
            lines = env_path.read_text(encoding="utf-8").splitlines()
            existing_keys = set()
            new_lines = []
            for line in lines:
                m = re.match(r"^([A-Za-z0-9_]+)=", line)
                if m and m.group(1) in updates:
                    k = m.group(1)
                    existing_keys.add(k)
                    new_lines.append(f"{k}={updates[k]}")
                else:
                    new_lines.append(line)

            for k, v in updates.items():
                if k not in existing_keys:
                    new_lines.append(f"{k}={v}")

            env_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
            return {"ok": True, "applied": list(updates.keys())}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def api_cf_tunnels(self, _p):
        return self.cf.list_account_tunnels()

    def api_cf_tunnel_create(self, p):
        name = str(p.get("name") or "").strip()
        if not name:
            return {"ok": False, "error": "Tunnel name is required"}
        return self.cf.create_account_tunnel(name)

    def api_cf_tunnel_token(self, p):
        tunnel_id = str(p.get("tunnel_id") or "").strip()
        if not tunnel_id:
            return {"ok": False, "error": "Tunnel ID is required"}
        return self.cf.get_tunnel_token(tunnel_id)

    def api_cf_tunnel_delete(self, p):
        tunnel_id = str(p.get("tunnel_id") or "").strip()
        if not tunnel_id:
            return {"ok": False, "error": "Tunnel ID is required"}
        return self.cf.delete_account_tunnel(tunnel_id)

    # ── GitHub Hub (Feature 16) ──────────────────────────────────
    def api_gh_status(self, _p):
        return self.gh.get_status()

    def api_gh_accounts(self, _p):
        return {
            "ok": True,
            "accounts": self.gh.list_stored_accounts(),
            "active_id": self.gh.get_active_account_id(),
        }

    def api_gh_switch_account(self, p):
        account_id = str(p.get("account_id") or "").strip()
        if not account_id:
            return {"ok": False, "error": "Account ID is required"}
        res = self.gh.switch_account(account_id)
        if res.get("ok"):
            res["status"] = self.gh.get_status()
        return res

    def api_gh_remove_account(self, p):
        account_id = str(p.get("account_id") or "").strip()
        if not account_id:
            return {"ok": False, "error": "Account ID is required"}
        res = self.gh.remove_account(account_id)
        if res.get("ok"):
            res["status"] = self.gh.get_status()
        return res

    def api_gh_verify_token(self, p):
        token = str(p.get("token") or "").strip()
        if not token:
            return {"ok": False, "error": "Token is required"}
        return self.gh.verify_token(token)

    def api_gh_save_credentials(self, p):
        token = str(p.get("token") or "").strip()
        username = str(p.get("username") or "").strip()
        account_name = str(p.get("account_name") or "").strip()
        avatar_url = str(p.get("avatar_url") or "").strip()
        email = str(p.get("email") or "").strip()
        scopes = p.get("scopes") or []
        if not token:
            return {"ok": False, "error": "Token is required"}
        ok = self.gh.save_credentials(
            token=token,
            username=username,
            account_name=account_name,
            avatar_url=avatar_url,
            email=email,
            scopes=scopes,
            make_active=True,
        )
        return {"ok": ok, "status": self.gh.get_status()}

    def api_gh_disconnect(self, _p):
        return {"ok": self.gh.clear_credentials()}

    def api_gh_repos(self, p):
        visibility = str(p.get("visibility") or "all").strip()
        affiliation = str(p.get("affiliation") or "owner,collaborator,organization_member").strip()
        sort = str(p.get("sort") or "updated").strip()
        direction = str(p.get("direction") or "desc").strip()
        page = int(p.get("page", 1))
        per_page = int(p.get("per_page", 30))
        return self.gh.list_repos(
            visibility=visibility,
            affiliation=affiliation,
            sort=sort,
            direction=direction,
            page=page,
            per_page=per_page,
        )

    def api_gh_create_repo(self, p):
        name = str(p.get("name") or "").strip()
        description = str(p.get("description") or "").strip()
        private = bool(p.get("private", True))
        auto_init = bool(p.get("auto_init", False))
        gitignore_template = str(p.get("gitignore_template") or "").strip()
        license_template = str(p.get("license_template") or "").strip()
        if not name:
            return {"ok": False, "error": "Repository name is required"}
        return self.gh.create_repo(
            name=name,
            description=description,
            private=private,
            auto_init=auto_init,
            gitignore_template=gitignore_template,
            license_template=license_template,
        )

    def api_gh_delete_repo(self, p):
        full_name = str(p.get("full_name") or "").strip()
        if not full_name:
            return {"ok": False, "error": "Repository full name is required"}
        return self.gh.delete_repo(full_name)

    def api_gh_clone_repo(self, p):
        repo_full_name = str(p.get("repo_full_name") or "").strip()
        target_dir = str(p.get("target_dir") or "").strip()
        if not repo_full_name:
            return {"ok": False, "error": "Repository full name is required"}
        return self.gh.clone_repo(repo_full_name, target_dir)

    def api_gh_branches(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        if not owner or not repo:
            return {"ok": False, "error": "Owner and repository are required"}
        return self.gh.list_branches(owner, repo)

    def api_gh_pulls(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        state = str(p.get("state") or "open").strip()
        page = int(p.get("page", 1))
        per_page = int(p.get("per_page", 30))
        if not owner or not repo:
            return {"ok": False, "error": "Owner and repository are required"}
        return self.gh.list_pulls(owner, repo, state=state, page=page, per_page=per_page)

    def api_gh_create_pull(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        title = str(p.get("title") or "").strip()
        head = str(p.get("head") or "").strip()
        base = str(p.get("base") or "main").strip()
        body = str(p.get("body") or "").strip()
        if not owner or not repo or not title or not head:
            return {"ok": False, "error": "Owner, repo, title, and head branch are required"}
        return self.gh.create_pull(owner, repo, title, head, base=base, body=body)

    def api_gh_merge_pull(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        pull_number = int(p.get("pull_number", 0))
        commit_title = str(p.get("commit_title") or "").strip()
        commit_message = str(p.get("commit_message") or "").strip()
        merge_method = str(p.get("merge_method") or "merge").strip()
        if not owner or not repo or not pull_number:
            return {"ok": False, "error": "Owner, repo, and pull_number are required"}
        return self.gh.merge_pull(
            owner, repo, pull_number,
            commit_title=commit_title,
            commit_message=commit_message,
            merge_method=merge_method,
        )

    def api_gh_close_pull(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        pull_number = int(p.get("pull_number", 0))
        if not owner or not repo or not pull_number:
            return {"ok": False, "error": "Owner, repo, and pull_number are required"}
        return self.gh.close_pull(owner, repo, pull_number)

    def api_gh_issues(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        state = str(p.get("state") or "open").strip()
        page = int(p.get("page", 1))
        per_page = int(p.get("per_page", 30))
        if not owner or not repo:
            return {"ok": False, "error": "Owner and repository are required"}
        return self.gh.list_issues(owner, repo, state=state, page=page, per_page=per_page)

    def api_gh_create_issue(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        title = str(p.get("title") or "").strip()
        body = str(p.get("body") or "").strip()
        labels = p.get("labels")
        assignees = p.get("assignees")
        if not owner or not repo or not title:
            return {"ok": False, "error": "Owner, repo, and issue title are required"}
        return self.gh.create_issue(owner, repo, title, body=body, labels=labels, assignees=assignees)

    def api_gh_close_issue(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        issue_number = int(p.get("issue_number", 0))
        state = str(p.get("state") or "closed").strip()
        state_reason = str(p.get("state_reason") or "completed").strip()
        if not owner or not repo or not issue_number:
            return {"ok": False, "error": "Owner, repo, and issue_number are required"}
        return self.gh.close_issue(owner, repo, issue_number, state=state, state_reason=state_reason)

    def api_gh_actions(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        branch = str(p.get("branch") or "").strip()
        event = str(p.get("event") or "").strip()
        status = str(p.get("status") or "").strip()
        page = int(p.get("page", 1))
        per_page = int(p.get("per_page", 30))
        if not owner or not repo:
            return {"ok": False, "error": "Owner and repository are required"}
        return self.gh.list_workflow_runs(
            owner, repo,
            branch=branch,
            event=event,
            status=status,
            page=page,
            per_page=per_page,
        )

    def api_gh_trigger_workflow(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        workflow_id = str(p.get("workflow_id") or "").strip()
        ref = str(p.get("ref") or "main").strip()
        inputs = p.get("inputs")
        if not owner or not repo or not workflow_id:
            return {"ok": False, "error": "Owner, repo, and workflow_id are required"}
        return self.gh.trigger_workflow(owner, repo, workflow_id, ref=ref, inputs=inputs)

    def api_gh_site_git_status(self, p):
        site = str(p.get("site") or "").strip()
        if not site:
            return {"ok": False, "error": "Site name or path is required"}
        return self.gh.get_site_git_status(site)

    def api_gh_publish_site(self, p):
        site = str(p.get("site") or "").strip()
        repo_name = str(p.get("repo_name") or "").strip()
        private = bool(p.get("private", True))
        description = str(p.get("description") or "").strip()
        if not site:
            return {"ok": False, "error": "Site name or path is required"}
        return self.gh.publish_site(site, repo_name=repo_name, private=private, description=description)

    def api_gh_link_site(self, p):
        site = str(p.get("site") or "").strip()
        repo_full_name = str(p.get("repo_full_name") or "").strip()
        if not site or not repo_full_name:
            return {"ok": False, "error": "Site name and repo_full_name are required"}
        return self.gh.link_site(site, repo_full_name)

    def api_gh_ssh_keys(self, _p):
        return self.gh.list_ssh_keys()

    def api_gh_add_deploy_key(self, p):
        owner = str(p.get("owner") or "").strip()
        repo = str(p.get("repo") or "").strip()
        title = str(p.get("title") or "").strip()
        key = str(p.get("key") or "").strip()
        read_only = bool(p.get("read_only", True))
        if not owner or not repo or not title or not key:
            return {"ok": False, "error": "Owner, repo, title, and SSH key are required"}
        return self.gh.add_deploy_key(owner, repo, title, key, read_only=read_only)

