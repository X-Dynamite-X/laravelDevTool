#!/usr/bin/env python3
"""ui/agent_cli.py - Non-interactive commands for coding agents and scripts.

Called by `laravel-dev <command>` for: status, site:info, site:env, db:*, mail:*, insights:*.
Every command detects the site from the current directory (or --site=NAME) and supports --json.
Exit codes: 0 success, 1 failure / timeout / not found, 2 usage error.
"""
from __future__ import annotations

import html
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

UI_DIR = os.path.dirname(os.path.abspath(__file__))
if UI_DIR not in sys.path:
    sys.path.insert(0, UI_DIR)

import envfile  # noqa: E402

MAILPIT_API = os.environ.get("LARAVEL_DEV_MAILPIT_URL", "http://127.0.0.1:8025").rstrip("/")
MAILPIT_SMTP_PORT = int(os.environ.get("LARAVEL_DEV_MAILPIT_SMTP_PORT", "1025"))
PERF_DIR = Path.home() / ".config" / "laravel-dev" / "perf"
KEY_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
DB_NAME_RE = re.compile(r"[A-Za-z0-9_-]{1,64}")
SLOW_QUERY_MS = 100.0
SLOW_REQUEST_MS = 1000.0


class CliError(Exception):
    def __init__(self, message: str, code: int = 1):
        super().__init__(message)
        self.code = code


class UsageError(CliError):
    def __init__(self, message: str):
        super().__init__(message, 2)


# ── argument parsing ──────────────────────────────────────────────────────────

def parse_args(argv: list[str]) -> tuple[list[str], dict[str, str | bool]]:
    """`a b --key=value --flag` -> (["a", "b"], {"key": "value", "flag": True}).
    `--key value` is not supported on purpose: values never get mistaken for positionals."""
    positional: list[str] = []
    options: dict[str, str | bool] = {}
    rest_positional = False
    for arg in argv:
        if rest_positional:
            positional.append(arg)
        elif arg == "--":
            rest_positional = True
        elif arg.startswith("--"):
            key, sep, value = arg[2:].partition("=")
            if not key:
                raise UsageError(f"Invalid option: {arg}")
            options[key.replace("-", "_")] = value if sep else True
        else:
            positional.append(arg)
    return positional, options


def opt_str(options: dict, key: str, default: str = "") -> str:
    value = options.get(key, default)
    if value is True:
        raise UsageError(f"--{key.replace('_', '-')} needs a value (--{key.replace('_', '-')}=...)")
    return str(value)


def opt_int(options: dict, key: str, default: int) -> int:
    raw = opt_str(options, key, str(default))
    try:
        return int(raw)
    except ValueError as exc:
        raise UsageError(f"--{key} must be a number") from exc


# ── output ────────────────────────────────────────────────────────────────────

def emit(data, as_json: bool, render=None):
    if as_json or render is None:
        print(json.dumps(data, indent=2, ensure_ascii=False, default=str))
    else:
        render(data)


def table(rows: list[dict], columns: list[tuple[str, str]]):
    if not rows:
        print("(none)")
        return
    widths = [max(len(title), *(len(str(r.get(key, "") if r.get(key) is not None else "")) for r in rows)) for key, title in columns]
    widths = [min(w, 70) for w in widths]

    def fmt(values):
        return "  ".join(str(v)[:w].ljust(w) for v, w in zip(values, widths)).rstrip()

    print(fmt([title for _, title in columns]))
    print(fmt(["-" * w for w in widths]))
    for r in rows:
        print(fmt(["" if r.get(key) is None else r.get(key, "") for key, _ in columns]))


def kv(data: dict, indent: int = 0):
    pad = " " * indent
    for key, value in data.items():
        if isinstance(value, dict):
            print(f"{pad}{key}:")
            kv(value, indent + 2)
        elif isinstance(value, list):
            print(f"{pad}{key}: {', '.join(str(v) for v in value) if value else '-'}")
        else:
            print(f"{pad}{key}: {'-' if value in (None, '') else value}")


# ── site detection ────────────────────────────────────────────────────────────

def _sites():
    import sites
    return sites.list_sites()


def resolve_site(options: dict, cwd: str | None = None, site_list: list[dict] | None = None) -> dict:
    """--site=NAME (name or domain), else the site whose path contains the current directory."""
    site_list = _sites() if site_list is None else site_list
    wanted = opt_str(options, "site") if "site" in options else ""
    if wanted:
        for s in site_list:
            if wanted in (s.get("name"), s.get("domain")) or wanted + ".test" == s.get("domain"):
                return s
        raise CliError(f"Unknown site: {wanted}. Run `laravel-dev list` to see all sites.")
    here = os.path.realpath(cwd or os.getcwd())
    best, best_len = None, -1
    for s in site_list:
        path = s.get("path") or ""
        if not path:
            continue
        real = os.path.realpath(path)
        if (here == real or here.startswith(real + os.sep)) and len(real) > best_len:
            best, best_len = s, len(real)
    if best is None:
        raise CliError("No site found for the current directory. Run the command inside a project or pass --site=NAME.")
    return best


def read_env(site: dict) -> tuple[Path, str]:
    path = Path(site["path"]) / ".env"
    if not path.is_file():
        raise CliError(f"{path} does not exist.")
    return path, path.read_text(encoding="utf-8", errors="replace")


def write_env(path: Path, changes: dict):
    text = path.read_text(encoding="utf-8", errors="replace")
    path.write_text(envfile.apply(text, envfile.validate_changes(changes)), encoding="utf-8")


# ── status ────────────────────────────────────────────────────────────────────

STATUS_UNITS = ("nginx", "dnsmasq", "supervisor", "mysql", "mariadb", "postgresql", "redis-server", "redis",
                "mailpit", "meilisearch", "minio")


def _unit_state(unit: str) -> str:
    try:
        res = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True, timeout=5)
        return res.stdout.strip() or "unknown"
    except (OSError, subprocess.TimeoutExpired):
        return "unknown"


def _unit_exists(unit: str) -> bool:
    try:
        res = subprocess.run(["systemctl", "list-unit-files", f"{unit}.service", "--no-legend", "--plain"],
                             capture_output=True, text=True, timeout=5)
        return bool(res.stdout.strip())
    except (OSError, subprocess.TimeoutExpired):
        return False


def _unit_id(unit: str) -> str:
    try:
        res = subprocess.run(["systemctl", "show", "-p", "Id", "--value", unit], capture_output=True, text=True, timeout=5)
        return res.stdout.strip() or unit
    except (OSError, subprocess.TimeoutExpired):
        return unit


def _port_open(port: int, host: str = "127.0.0.1") -> bool:
    import socket
    try:
        with socket.create_connection((host, port), timeout=0.4):
            return True
    except OSError:
        return False


def status_data() -> dict:
    import sites
    base = Path(os.environ.get("LARAVEL_DEV_BASE_DIR") or Path(UI_DIR).parent)
    version = (base / "VERSION").read_text().strip() if (base / "VERSION").is_file() else ""
    services, seen_ids = [], set()
    for unit in list(STATUS_UNITS) + [f"php{v}-fpm" for v in sites.php_versions()]:
        if not _unit_exists(unit):
            continue
        unit_id = _unit_id(unit)  # redis.service is an alias of redis-server.service on Debian
        if unit_id in seen_ids:
            continue
        seen_ids.add(unit_id)
        services.append({"name": unit, "state": _unit_state(unit)})
    node = ""
    try:
        node = subprocess.run(["node", "--version"], capture_output=True, text=True, timeout=5).stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    php_default = ""
    try:
        php_default = subprocess.run(["php", "-r", "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;"],
                                     capture_output=True, text=True, timeout=5).stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    data = {
        "version": version,
        "php_default": php_default,
        "php_installed": sites.php_versions(),
        "node": node,
        "dns": sites.dns_status_info(),
        "mail": {"api": MAILPIT_API, "smtp_port": MAILPIT_SMTP_PORT, "running": _mailpit_up()},
        "services": services,
    }
    data["healthy"] = all(s["state"] == "active" for s in services if s["name"] in ("nginx",) or s["name"].endswith("-fpm"))
    return data


def cmd_status(args, options):
    data = status_data()

    def render(d):
        print(f"laravel-dev {d['version']}  ·  PHP {d['php_default'] or '?'} (installed: {', '.join(d['php_installed']) or '-'})  ·  Node {d['node'] or '-'}")
        print(f"DNS (*.test): {'on' if d['dns'].get('resolves') else 'off'}  ·  Mailpit: {'running' if d['mail']['running'] else 'not running'}")
        print()
        table(d["services"], [("name", "Service"), ("state", "State")])
        print()
        print("Healthy" if d["healthy"] else "Problems found: a web service is not active.")
    emit(data, options.get("json") is True, render)
    return 0 if data["healthy"] else 1


# ── site:info / site:env ──────────────────────────────────────────────────────

def env_services(env: dict) -> dict:
    """Which service each Laravel subsystem points at, from .env values."""
    db = (env.get("DB_CONNECTION") or "").lower()
    database = {"driver": db or "", "host": env.get("DB_HOST", ""), "port": env.get("DB_PORT", ""),
                "database": env.get("DB_DATABASE", "")}
    mail = (env.get("MAIL_MAILER") or "").lower()
    mail_target = "mailpit" if mail == "smtp" and env.get("MAIL_PORT") == str(MAILPIT_SMTP_PORT) else mail
    return {
        "database": database,
        "queue": env.get("QUEUE_CONNECTION", ""),
        "cache": env.get("CACHE_STORE") or env.get("CACHE_DRIVER", ""),
        "session": env.get("SESSION_DRIVER", ""),
        "broadcasting": env.get("BROADCAST_CONNECTION") or env.get("BROADCAST_DRIVER", ""),
        "mail": mail_target,
        "filesystem": env.get("FILESYSTEM_DISK", ""),
        "search": env.get("SCOUT_DRIVER", ""),
    }


def site_capabilities(path: Path) -> dict:
    composer = {}
    try:
        composer = json.loads((path / "composer.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    req = {**(composer.get("require") or {}), **(composer.get("require-dev") or {})}
    scripts = composer.get("scripts") or {}
    pkg = {}
    try:
        pkg = json.loads((path / "package.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    return {
        "composer_dev": "dev" in scripts,
        "vite": any((path / f"vite.config.{ext}").is_file() for ext in ("js", "ts", "mjs", "mts")),
        "npm_dev": "dev" in (pkg.get("scripts") or {}),
        "pail": "laravel/pail" in req,
        "horizon": "laravel/horizon" in req,
        "reverb": "laravel/reverb" in req,
        "octane": "laravel/octane" in req,
        "telescope": "laravel/telescope" in req,
        "boost": "laravel/boost" in req,
    }


def _workspaces(site_name: str) -> list:
    import sites
    if not sites.MANAGED:
        return []
    try:
        res = subprocess.run([sites.CLI, "workspace", "list", site_name], capture_output=True, text=True, timeout=15)
        out = res.stdout.strip()
        return json.loads(out) if out.startswith("[") else []
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return []


def site_info(site: dict) -> dict:
    import sites
    path = Path(site["path"])
    env = sites.parse_env_file(path / ".env") if (path / ".env").is_file() else {}
    laravel = ""
    try:
        lock = json.loads((path / "composer.lock").read_text(encoding="utf-8"))
        for p in lock.get("packages", []):
            if p.get("name") == "laravel/framework":
                laravel = p.get("version", "").lstrip("v")
    except (OSError, ValueError):
        pass
    record = sites.parse_env_file(sites.REGISTRY_DIR / f"{site['name']}.env") if hasattr(sites, "REGISTRY_DIR") else {}
    nvmrc = (path / ".nvmrc").read_text().strip() if (path / ".nvmrc").is_file() else ""
    return {
        "name": site["name"],
        "url": site.get("url", ""),
        "domain": site.get("domain", ""),
        "path": str(path),
        "type": site.get("type", ""),
        "laravel": laravel,
        "php": site.get("php", ""),
        "node": record.get("NODE_VERSION") or nvmrc,
        "secure": bool(site.get("ssl")),
        "runtime": record.get("RUNTIME") or "php-fpm",
        "branch": site.get("branch", ""),
        "has_env": (path / ".env").is_file(),
        "app_env": env.get("APP_ENV", ""),
        "app_url": env.get("APP_URL", ""),
        "services": env_services(env),
        "capabilities": site_capabilities(path),
        "worker": bool(site.get("worker")),
        "scheduler": bool(site.get("cron")),
        "workspaces": _workspaces(site["name"]),
    }


def cmd_site_info(args, options):
    data = site_info(resolve_site(options))

    def render(d):
        kv({k: v for k, v in d.items() if k not in ("workspaces",)})
        print(f"workspaces: {', '.join(w.get('branch') or w.get('name', '') for w in d['workspaces']) or '-'}")
    emit(data, options.get("json") is True, render)
    return 0


def cmd_which(args, options):
    import drivers
    site = resolve_site(options)
    drv = drivers.detect_driver(Path(site["path"]))
    data = {
        "site": site["name"],
        "driver": drv["driver"],
        "driver_label": drv["driver_label"],
        "root": drv["root"],
        "public_dir": drv["public_dir"],
        "public_path": drv["public_path"],
        "front_controller": drv["front_controller"],
        "php": site.get("php", ""),
        "custom": drv.get("custom", False),
    }

    def render(d):
        print(f"Site:             {d['site']}")
        print(f"Driver:           {d['driver_label']} ({d['driver']})")
        print(f"Root:             {d['root']}")
        print(f"Public Path:      {d['public_path']}")
        print(f"Front Controller: {d['front_controller'] or '-'}")
        print(f"PHP:              {d['php'] or '-'}")

    emit(data, options.get("json") is True, render)
    return 0


def cmd_site_env(args, options):
    as_json = options.get("json") is True
    op = args[0] if args else "list"
    site = resolve_site(options)
    path, text = read_env(site)
    values = envfile.to_dict(text)
    if op == "list":
        emit(values, as_json, lambda d: [print(f"{k}={v}") for k, v in d.items()])
        return 0
    if op == "get":
        if len(args) < 2:
            raise UsageError("Usage: laravel-dev site:env get KEY")
        key = args[1]
        if key not in values:
            if as_json:
                emit({"key": key, "value": None, "exists": False}, True)
            else:
                print(f"{key} is not set in {path}", file=sys.stderr)
            return 1
        emit({"key": key, "value": values[key], "exists": True}, as_json, lambda d: print(d["value"]))
        return 0
    if op == "set":
        if len(args) < 3:
            raise UsageError('Usage: laravel-dev site:env set KEY "VALUE"')
        key, value = args[1], " ".join(args[2:])
        if not KEY_RE.fullmatch(key):
            raise UsageError(f"Invalid variable name: {key}")
        write_env(path, {key: value})
        emit({"ok": True, "key": key, "value": value, "file": str(path)}, as_json, lambda d: print(f"Set {key} in {path}"))
        return 0
    if op == "unset":
        if len(args) < 2:
            raise UsageError("Usage: laravel-dev site:env unset KEY")
        key = args[1]
        existed = key in values
        if existed:
            write_env(path, {key: None})
        emit({"ok": True, "key": key, "removed": existed}, as_json,
             lambda d: print(f"Removed {key}" if existed else f"{key} was not set"))
        return 0
    raise UsageError("Usage: laravel-dev site:env <list|get|set|unset>")


def cmd_site_services(args: list[str], options: dict) -> int:
    import site_services

    site = resolve_site(options)
    project_path = site["path"]

    if not args:
        data = site_services.get_site_services(project_path)
        emit(
            {"site": site["name"], "services": data},
            options.get("json") is True,
            lambda d: table(
                [
                    {
                        "category": cat,
                        "current": info["current"],
                        "managed": "yes" if info["is_managed"] else "no",
                    }
                    for cat, info in d["services"].items()
                ],
                [("category", "Category"), ("current", "Active Option"), ("managed", "Managed")],
            ),
        )
        return 0

    category = args[0].lower().strip()
    if category not in site_services.CATEGORIES:
        raise UsageError(f"Unknown category '{category}'. Valid: {', '.join(site_services.CATEGORIES)}")

    if len(args) < 2:
        raise UsageError(f"Usage: laravel-dev site:services {category} <option> [--database-name=NAME]")

    option = args[1].lower().strip()
    db_name = options.get("database_name") or options.get("db")

    try:
        res = site_services.set_site_service(
            project_path,
            category=category,
            option=option,
            database_name=db_name,
        )
    except ValueError as exc:
        raise CliError(str(exc)) from exc

    emit(
        res,
        options.get("json") is True,
        lambda d: print(f"Set {category} to {option} on {site['name']}."),
    )
    return 0


# ── databases ─────────────────────────────────────────────────────────────────

def site_db_spec(site: dict) -> dict:
    import database
    import sites
    env = sites.parse_env_file(Path(site["path"]) / ".env")
    spec = database.spec_from_env(env, site["path"])
    if spec is None:
        raise CliError("No database settings found in this project's .env (DB_CONNECTION / DB_DATABASE or DATABASE_URL).")
    spec.update({"id": f"site:{site['name']}", "name": site["name"], "source": "site", "site": site["name"]})
    return spec


def db_manager(spec: dict):
    import database
    import tempfile
    # A throwaway config dir: the CLI must not read or rewrite the app's saved connections.
    return database.DatabaseManager(tempfile.mkdtemp(prefix="ld-agent-"), None, lambda: [spec])


def connection_url(spec: dict) -> str:
    if spec["driver"] == "sqlite":
        return f"sqlite://{spec.get('file', '')}"
    scheme = {"pgsql": "postgresql"}.get(spec["driver"], spec["driver"])
    user = urllib.parse.quote(spec.get("user") or "", safe="")
    pw = urllib.parse.quote(spec.get("password") or "", safe="")
    auth = f"{user}:{pw}@" if pw else (f"{user}@" if user else "")
    return f"{scheme}://{auth}{spec.get('host', '127.0.0.1')}:{spec.get('port', '')}/{spec.get('database', '')}"


def tableplus_url(spec: dict) -> str:
    if spec["driver"] == "sqlite":
        return f"tableplus://?env=local&driver=sqlite&path={urllib.parse.quote(spec.get('file', ''))}"
    driver = "mysql" if "mysql" in spec["driver"] or "mariadb" in spec["driver"] else "postgres"
    host = spec.get("host", "127.0.0.1")
    port = spec.get("port", "3306")
    user = spec.get("user", "root")
    pw = spec.get("password", "")
    db = spec.get("database", "")
    return f"tableplus://?driver={driver}&host={host}&port={port}&user={urllib.parse.quote(user)}&password={urllib.parse.quote(pw)}&database={urllib.parse.quote(db)}"


def cmd_db_connection(args, options):
    site = resolve_site(options)
    spec = site_db_spec(site)
    data = {"site": site["name"], "driver": spec["driver"]}
    if spec["driver"] == "sqlite":
        data.update({"file": spec.get("file", ""), "exists": Path(spec.get("file", "")).is_file()})
    else:
        data.update({k: spec.get(k, "") for k in ("host", "port", "database", "user")})
        data["password_set"] = bool(spec.get("password"))
    data["url"] = connection_url(spec)
    data["tableplus_url"] = tableplus_url(spec)
    emit(data, options.get("json") is True, kv)
    return 0


def tableplus_installed() -> bool:
    """TablePlus opens tableplus:// links only when it registered that URL scheme."""
    if shutil.which("tableplus"):
        return True
    try:
        res = subprocess.run(["xdg-mime", "query", "default", "x-scheme-handler/tableplus"],
                             capture_output=True, text=True, timeout=5)
        return bool(res.stdout.strip())
    except (OSError, subprocess.TimeoutExpired):
        return False


def dbeaver_connection(spec: dict) -> str:
    """DBeaver's -con argument: key=value pairs separated by |."""
    if spec["driver"] == "sqlite":
        return f"driver=sqlite|database={spec.get('file', '')}|name=laravel-dev|openConsole=false"
    driver = "mysql" if spec["driver"] in ("mysql", "mariadb") else "postgresql"
    parts = {"driver": driver, "host": spec.get("host", "127.0.0.1"), "port": spec.get("port", ""),
             "database": spec.get("database", ""), "user": spec.get("user", ""), "password": spec.get("password", ""),
             "name": f"laravel-dev {spec.get('database', '')}".strip()}
    return "|".join(f"{k}={v}" for k, v in parts.items() if v != "")


def cmd_db_open(args, options):
    site = resolve_site(options)
    spec = site_db_spec(site)
    client = (args[0] if args else "tableplus").lower()
    if client not in ("tableplus", "dbeaver"):
        raise UsageError("Usage: laravel-dev db:open [tableplus|dbeaver]")
    tp_url = tableplus_url(spec)
    conn_url = connection_url(spec)

    launched, error = False, ""
    if options.get("print"):
        pass  # only print the links
    elif client == "tableplus":
        if not tableplus_installed():
            error = "TablePlus is not installed (no handler for tableplus:// links). Use the connection URL instead."
        else:
            res = subprocess.run(["xdg-open", tp_url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            launched = res.returncode == 0
            error = "" if launched else "xdg-open could not open the TablePlus link."
    else:
        dbeaver = shutil.which("dbeaver") or shutil.which("dbeaver-ce")
        if not dbeaver:
            error = "DBeaver is not installed."
        else:
            subprocess.Popen([dbeaver, "-con", dbeaver_connection(spec)], stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
            launched = True

    data = {"ok": not error, "client": client, "launched": launched, "error": error,
            "tableplus_url": tp_url, "connection_url": conn_url}

    def render(d):
        if d["error"]:
            print(f"Error: {d['error']}", file=sys.stderr)
        print(f"Connection URL: {d['connection_url']}\nTablePlus URL: {d['tableplus_url']}")
    emit(data, options.get("json") is True, render)
    return 0 if not error else 1


def cmd_db_list(args, options):
    site = resolve_site(options)
    spec = site_db_spec(site)
    if spec["driver"] == "sqlite":
        data = {"driver": "sqlite", "databases": [{"name": spec.get("file", ""), "current": True}]}
    else:
        res = db_manager(spec).databases(spec["id"])
        current = spec.get("database", "")
        data = {"driver": spec["driver"], "version": res.get("version", ""),
                "databases": [{"name": d["name"], "current": d["name"] == current, "system": d.get("system", False)}
                              for d in res.get("databases", [])]}
    emit(data, options.get("json") is True,
         lambda d: [print(("* " if x.get("current") else "  ") + x["name"]) for x in d["databases"] if not x.get("system")])
    return 0


def _create_database(spec: dict, name: str) -> bool:
    """Returns False when it already exists."""
    if spec["driver"] == "sqlite":
        file = Path(name if os.path.isabs(name) else Path(spec.get("_base", "")) / name)
        if file.exists():
            return False
        file.parent.mkdir(parents=True, exist_ok=True)
        sqlite3.connect(str(file)).close()
        return True
    mgr = db_manager(spec)
    existing = {d["name"] for d in mgr.databases(spec["id"]).get("databases", [])}
    if name in existing:
        return False
    mgr.create_database(spec["id"], name)
    return True


def cmd_db_create(args, options):
    site = resolve_site(options)
    spec = site_db_spec(site)
    spec["_base"] = site["path"]
    if spec["driver"] == "sqlite":
        name = args[0] if args else spec.get("file", "")
    else:
        name = args[0] if args else spec.get("database", "")
        if not DB_NAME_RE.fullmatch(name or ""):
            raise UsageError("Usage: laravel-dev db:create [NAME]  (letters, numbers, - and _)")
    created = _create_database(spec, name)
    emit({"ok": True, "database": name, "created": created}, options.get("json") is True,
         lambda d: print(f"Created {name}" if created else f"{name} already exists"))
    return 0


def cmd_db_use(args, options):
    if not args:
        raise UsageError("Usage: laravel-dev db:use NAME [--create]")
    name = args[0]
    site = resolve_site(options)
    spec = site_db_spec(site)
    spec["_base"] = site["path"]
    env_path, _ = read_env(site)
    created = False
    if spec["driver"] == "sqlite":
        target = Path(name if os.path.isabs(name) else Path(site["path"]) / name)
        if not target.exists():
            if not options.get("create"):
                raise CliError(f"{target} does not exist. Pass --create to create it.")
            created = _create_database(spec, str(target))
    else:
        if not DB_NAME_RE.fullmatch(name):
            raise UsageError("Database names may use letters, numbers, - and _")
        existing = {d["name"] for d in db_manager(spec).databases(spec["id"]).get("databases", [])}
        if name not in existing:
            if not options.get("create"):
                raise CliError(f"Database {name} does not exist on {spec.get('host')}:{spec.get('port')}. Pass --create to create it.")
            created = _create_database(spec, name)
    write_env(env_path, {"DB_DATABASE": name})
    emit({"ok": True, "database": name, "created": created}, options.get("json") is True,
         lambda d: print(f"{site['name']} now uses {name}" + (" (created)" if created else "")))
    return 0


def cmd_db_drop(args, options):
    if not args:
        raise UsageError("Usage: laravel-dev db:drop NAME [--force]")
    name = args[0]
    site = resolve_site(options)
    spec = site_db_spec(site)
    if spec["driver"] == "sqlite":
        raise CliError("SQLite databases are files: delete the file instead.")
    if name == spec.get("database") and not options.get("force"):
        raise CliError(f"{name} is the database in this site's DB_DATABASE. Pass --force to drop it anyway.")
    db_manager(spec).drop_database(spec["id"], name)
    emit({"ok": True, "dropped": name}, options.get("json") is True, lambda d: print(f"Dropped {name}"))
    return 0


# ── mail (Mailpit) ────────────────────────────────────────────────────────────

def _mailpit(path: str, method: str = "GET", body: dict | None = None, raw: bool = False, timeout: float = 3.0):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(MAILPIT_API + path, data=data, method=method,
                                 headers={"Accept": "application/json", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = resp.read()
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise CliError("Mail not found.") from exc
        raise CliError(f"Mailpit returned HTTP {exc.code}") from exc
    except (urllib.error.URLError, OSError) as exc:
        raise CliError(f"Mailpit is not reachable at {MAILPIT_API}. Install/start it: laravel-dev service-install mailpit") from exc
    if raw:
        return payload
    text = payload.decode("utf-8", "replace")
    try:
        return json.loads(text or "null")
    except ValueError:
        return text  # DELETE/PUT answer with a plain "ok"


def _mailpit_up() -> bool:
    try:
        _mailpit("/api/v1/info", timeout=0.6)
        return True
    except CliError:
        return False


def _addr(value) -> str:
    if isinstance(value, dict):
        name, addr = value.get("Name", ""), value.get("Address", "")
        return f"{name} <{addr}>" if name else addr
    return str(value or "")


def _summary(m: dict) -> dict:
    return {
        "id": m.get("ID", ""),
        "date": m.get("Created", ""),
        "from": _addr(m.get("From")),
        "to": ", ".join(_addr(t) for t in m.get("To") or []),
        "subject": m.get("Subject", ""),
        "mailbox": m.get("Username") or "",
        "attachments": m.get("Attachments", 0),
        "read": m.get("Read", False),
        "size": m.get("Size", 0),
        "tags": m.get("Tags") or [],
    }


def _parse_since(value: str) -> float:
    """'5 minutes ago', '2h', '30s', an ISO date or a unix timestamp -> epoch seconds."""
    value = value.strip().lower()
    m = re.fullmatch(r"(\d+)\s*(s|sec|secs|second|seconds|m|min|mins|minute|minutes|h|hour|hours|d|day|days)(\s+ago)?", value)
    if m:
        unit = m.group(2)[0]
        return time.time() - int(m.group(1)) * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
    if re.fullmatch(r"\d{9,}", value):
        return float(value)
    from datetime import datetime
    try:
        dt = datetime.fromisoformat(value.replace("z", "+00:00"))
        return dt.timestamp()
    except ValueError as exc:
        raise UsageError(f"--since: could not understand '{value}' (try \"5 minutes ago\" or 2026-01-31T10:00)") from exc


def _iso_ts(value: str) -> float:
    from datetime import datetime
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except (ValueError, AttributeError):
        return 0.0


def mail_matches(m: dict, options: dict) -> bool:
    for key in ("to", "from", "subject"):
        wanted = opt_str(options, key).lower() if key in options else ""
        if wanted and wanted not in str(m.get(key, "")).lower():
            return False
    mailbox = opt_str(options, "mailbox").lower() if "mailbox" in options else ""
    if mailbox and mailbox != str(m.get("mailbox", "")).lower() and mailbox not in [t.lower() for t in m.get("tags", [])]:
        return False
    if "since" in options and _iso_ts(m.get("date", "")) < _parse_since(opt_str(options, "since")):
        return False
    return True


def fetch_mails(options: dict, scan: int = 200) -> list[dict]:
    data = _mailpit(f"/api/v1/messages?limit={scan}") or {}
    out = []
    for raw in data.get("messages") or []:
        m = _summary(raw)
        if mail_matches(m, options):
            out.append(m)
    return out


MAIL_COLUMNS = [("id", "ID"), ("date", "Date"), ("from", "From"), ("to", "To"), ("subject", "Subject")]


def cmd_mail_list(args, options):
    limit = opt_int(options, "limit", 50)
    mails = fetch_mails(options)[:limit]
    emit(mails, options.get("json") is True, lambda d: table(d, MAIL_COLUMNS))
    return 0


def mail_detail(msg_id: str) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", msg_id or ""):
        raise UsageError("Invalid mail ID")
    d = _mailpit(f"/api/v1/message/{msg_id}")
    return {
        "id": d.get("ID", msg_id),
        "date": d.get("Date", ""),
        "from": _addr(d.get("From")),
        "to": [_addr(t) for t in d.get("To") or []],
        "cc": [_addr(t) for t in d.get("Cc") or []],
        "subject": d.get("Subject", ""),
        "text": d.get("Text", ""),
        "html": d.get("HTML", ""),
        "attachments": [{"part": a.get("PartID"), "name": a.get("FileName"), "type": a.get("ContentType"),
                         "size": a.get("Size")} for a in d.get("Attachments") or []],
        "links": extract_links(d.get("HTML", ""), d.get("Text", "")),
    }


def _print_mail(d: dict, fmt: str, headers: bool):
    if fmt == "html":
        print(d["html"])
        return
    if fmt == "raw":
        sys.stdout.write(_mailpit(f"/api/v1/message/{d['id']}/raw", raw=True).decode("utf-8", "replace"))
        return
    print(f"ID:      {d['id']}\nDate:    {d['date']}\nFrom:    {d['from']}\nTo:      {', '.join(d['to'])}\nSubject: {d['subject']}")
    if d["attachments"]:
        print("Attachments: " + ", ".join(a["name"] or "" for a in d["attachments"]))
    if headers:
        hdrs = _mailpit(f"/api/v1/message/{d['id']}/headers") or {}
        for k, values in hdrs.items():
            for v in values:
                print(f"{k}: {v}")
    print()
    print(d["text"] or html_to_text(d["html"]))


def html_to_text(markup: str) -> str:
    markup = re.sub(r"(?is)<(script|style)\b.*?</\1>", "", markup or "")
    markup = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>|</h\d>", "\n", markup)
    text = html.unescape(re.sub(r"<[^>]+>", "", markup))
    return re.sub(r"\n{3,}", "\n\n", "\n".join(line.strip() for line in text.splitlines())).strip()


def extract_links(markup: str, text: str = "") -> list[str]:
    links = [html.unescape(h) for h in re.findall(r"""(?i)href\s*=\s*["']([^"']+)["']""", markup or "")]
    links += re.findall(r"https?://[^\s<>\"')\]]+", text or "")
    seen, out = set(), []
    for link in links:
        link = link.strip()
        if link and not link.lower().startswith(("mailto:", "tel:", "#", "cid:")) and link not in seen:
            seen.add(link)
            out.append(link)
    return out


def cmd_mail_show(args, options):
    if not args:
        raise UsageError("Usage: laravel-dev mail:show ID [--format=text|html|raw|json] [--headers]")
    fmt = opt_str(options, "format", "text")
    if fmt not in ("text", "html", "raw", "json"):
        raise UsageError("--format must be text, html, raw or json")
    d = mail_detail(args[0])
    if fmt == "json" or options.get("json") is True:
        emit(d, True)
    else:
        _print_mail(d, fmt, options.get("headers") is True)
    return 0


def cmd_mail_latest(args, options):
    mails = fetch_mails(options)
    if not mails:
        print("No matching mail.", file=sys.stderr)
        return 1
    d = mail_detail(mails[0]["id"])
    if options.get("json") is True:
        emit(d, True)
    else:
        _print_mail(d, opt_str(options, "format", "text"), options.get("headers") is True)
    return 0


def wait_for_mail(options: dict, timeout: int, sleep=time.sleep, clock=time.monotonic) -> dict | None:
    """First matching mail that arrives after the call started (older mails never count)."""
    seen = {m["id"] for m in fetch_mails({})}
    deadline = clock() + timeout
    while clock() < deadline:
        sleep(1.0)
        for m in fetch_mails(options):
            if m["id"] not in seen:
                return mail_detail(m["id"])
    return None


def cmd_mail_wait(args, options, sleep=time.sleep, clock=time.monotonic):
    timeout = opt_int(options, "timeout", 30)
    d = wait_for_mail(options, timeout, sleep, clock)
    if d is None:
        print(f"No matching mail arrived within {timeout} seconds.", file=sys.stderr)
        return 1
    if options.get("json") is True:
        emit(d, True)
    else:
        _print_mail(d, opt_str(options, "format", "text"), False)
    return 0


def cmd_mail_links(args, options):
    if not args:
        raise UsageError("Usage: laravel-dev mail:links ID")
    links = mail_detail(args[0])["links"]
    emit(links, options.get("json") is True, lambda d: [print(x) for x in d])
    return 0 if links else 1


def cmd_mail_attachments(args, options):
    if not args:
        raise UsageError("Usage: laravel-dev mail:attachments ID")
    atts = mail_detail(args[0])["attachments"]
    emit(atts, options.get("json") is True, lambda d: table(d, [("part", "Part"), ("name", "Name"), ("type", "Type"), ("size", "Size")]))
    return 0


def cmd_mail_attachment(args, options):
    if len(args) < 2:
        raise UsageError("Usage: laravel-dev mail:attachment ID FILENAME [--out=DIR]")
    d = mail_detail(args[0])
    att = next((a for a in d["attachments"] if a["name"] == args[1] or a["part"] == args[1]), None)
    if att is None:
        raise CliError(f"Attachment {args[1]} not found. Run `laravel-dev mail:attachments {args[0]}`.")
    out_dir = Path(opt_str(options, "out", os.getcwd())).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / Path(att["name"] or f"part-{att['part']}").name  # never write outside out_dir
    target.write_bytes(_mailpit(f"/api/v1/message/{d['id']}/part/{att['part']}", raw=True))
    emit({"ok": True, "path": str(target)}, options.get("json") is True, lambda x: print(x["path"]))
    return 0


def cmd_mail_mailboxes(args, options):
    boxes: dict[str, int] = {}
    for m in fetch_mails({}, scan=500):
        for tag in m.get("tags") or [m.get("mailbox") or "(default)"]:
            boxes[tag] = boxes.get(tag, 0) + 1
    rows = [{"mailbox": k, "count": v} for k, v in sorted(boxes.items())]
    emit(rows, options.get("json") is True, lambda d: table(d, [("mailbox", "Mailbox"), ("count", "Mails")]))
    return 0


def cmd_mail_delete(args, options):
    if not args:
        raise UsageError("Usage: laravel-dev mail:delete ID [ID...]")
    for msg_id in args:
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", msg_id):
            raise UsageError(f"Invalid mail ID: {msg_id}")
    _mailpit("/api/v1/messages", method="DELETE", body={"IDs": args})
    emit({"ok": True, "deleted": args}, options.get("json") is True, lambda d: print(f"Deleted {len(args)} mail(s)"))
    return 0


def cmd_mail_clear(args, options):
    if args:  # a mailbox: delete only its mails
        ids = [m["id"] for m in fetch_mails({"mailbox": args[0]}, scan=1000)]
        if ids:
            _mailpit("/api/v1/messages", method="DELETE", body={"IDs": ids})
        count = len(ids)
    else:
        count = len(fetch_mails({}, scan=1000))
        _mailpit("/api/v1/messages", method="DELETE", body={"IDs": []})
    emit({"ok": True, "deleted": count}, options.get("json") is True, lambda d: print(f"Deleted {count} mail(s)"))
    return 0


def cmd_mail_config(args, options):
    data = {
        "running": _mailpit_up(),
        "smtp_host": "127.0.0.1",
        "smtp_port": MAILPIT_SMTP_PORT,
        "web_ui": MAILPIT_API,
        "env": {"MAIL_MAILER": "smtp", "MAIL_HOST": "127.0.0.1", "MAIL_PORT": str(MAILPIT_SMTP_PORT),
                "MAIL_USERNAME": "null", "MAIL_PASSWORD": "null", "MAIL_ENCRYPTION": "null"},
    }

    def render(d):
        print(f"Mailpit: {'running' if d['running'] else 'not running'}  ·  SMTP 127.0.0.1:{d['smtp_port']}  ·  UI {d['web_ui']}")
        print("\nAdd to .env:")
        for k, v in d["env"].items():
            print(f"{k}={v}")
    emit(data, options.get("json") is True, render)
    return 0


# ── insights (profiler data) ──────────────────────────────────────────────────

def _perf_rows(site: dict, after: float = 0.0, limit: int = 50) -> list[dict]:
    """Profiled requests from the per-site SQLite store the desktop app writes (newest first)."""
    names = {site["name"], site.get("domain", ""), site["name"].replace("-", "_"), site["name"].replace("_", "-")}
    rows: dict[str, dict] = {}
    for name in filter(None, names):
        db = PERF_DIR / f"{name}.sqlite"
        if not db.is_file():
            continue
        try:
            conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            for r in conn.execute("SELECT id, created_at, data FROM requests WHERE created_at > ? AND uri != '/up' "
                                  "ORDER BY created_at DESC LIMIT ?", (after, limit)):
                try:
                    data = json.loads(r["data"])
                except ValueError:
                    continue
                if "LaravelDev-Uptime" in str(data.get("user_agent", "")):
                    continue
                data["_created_at"] = r["created_at"]
                rows[r["id"]] = data
            conn.close()
        except sqlite3.Error:
            continue
    return sorted(rows.values(), key=lambda d: d["_created_at"], reverse=True)[:limit]


def _request_summary(r: dict) -> dict:
    return {
        "id": r.get("id", ""),
        "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(r.get("_created_at", 0))),
        "method": r.get("method", ""),
        "uri": r.get("uri", ""),
        "route": r.get("route", ""),
        "status": r.get("status", ""),
        "duration_ms": round(float(r.get("duration_ms") or 0), 1),
        "queries": r.get("query_count", len(r.get("queries") or [])),
        "query_ms": round(float(r.get("query_time_ms") or 0), 1),
        "memory_mb": r.get("memory_peak_mb") or r.get("memory_mb"),
    }


def cmd_insights_list(args, options):
    site = resolve_site(options)
    kind = opt_str(options, "type", "request")
    if kind not in ("request", "query"):
        raise UsageError("--type must be request or query")
    reqs = _perf_rows(site, limit=opt_int(options, "limit", 20))
    if kind == "query":
        out = []
        for r in reqs:
            for q in r.get("queries") or []:
                out.append({"request": r.get("id"), "uri": r.get("uri"), "time_ms": q.get("time_ms"),
                            "sql": q.get("sql"), "bindings": q.get("bindings", []),
                            "file": q.get("file", ""), "line": q.get("line", 0)})
        emit(out, options.get("json") is True,
             lambda d: table(d, [("time_ms", "ms"), ("uri", "Request"), ("sql", "SQL"), ("file", "File"), ("line", "Line")]))
        return 0
    out = [_request_summary(r) for r in reqs]
    emit(out, options.get("json") is True, lambda d: table(d, [
        ("time", "Time"), ("method", "Method"), ("uri", "URI"), ("status", "Status"),
        ("duration_ms", "ms"), ("queries", "Queries")]))
    if not out and options.get("json") is not True:
        print("\nNo captured requests. Enable the profiler for this site in the app (Performance tab), then load a page.")
    return 0


def analyze_requests(reqs: list[dict], slow_query_ms: float = SLOW_QUERY_MS, slow_request_ms: float = SLOW_REQUEST_MS) -> list[dict]:
    import perf
    issues = []
    for r in reqs:
        where = {"request": r.get("id"), "method": r.get("method"), "uri": r.get("uri"), "route": r.get("route")}
        queries = r.get("queries") or []
        for a in perf.detect_n_plus_one(queries):
            issues.append({"type": "n_plus_one", **where, "count": a["count"], "sql": a["pattern"],
                           "file": a["file"], "line": a["line"], "hint": a["suggestion"]})
        for a in perf.detect_duplicate_queries(queries):
            issues.append({"type": "duplicate_query", **where, "count": a["count"], "sql": a["sql"],
                           "file": a["file"], "line": a["line"], "hint": a["suggestion"]})
        for a in perf.detect_slow_queries(queries, slow_query_ms):
            issues.append({"type": "slow_query", **where, "time_ms": a["time_ms"], "sql": a["sql"],
                           "file": a["file"], "line": a["line"], "hint": "Add an index or reduce the rows this query reads."})
        status = int(r.get("status") or 0)
        if status >= 500:
            exc = r.get("exception") or {}
            issues.append({"type": "error", **where, "status": status,
                           "message": exc.get("message", "") if isinstance(exc, dict) else str(exc),
                           "file": exc.get("file", "") if isinstance(exc, dict) else "",
                           "line": exc.get("line", 0) if isinstance(exc, dict) else 0,
                           "hint": "Run `laravel-dev` logs / check storage/logs/laravel.log for the stack trace."})
        if float(r.get("duration_ms") or 0) >= slow_request_ms:
            issues.append({"type": "slow_request", **where, "time_ms": round(float(r.get("duration_ms") or 0), 1),
                           "hint": "Open the request in the app's Performance tab to see the timeline."})
    return issues


def cmd_insights_analyze(args, options):
    site = resolve_site(options)
    after = float(opt_str(options, "after", "0") or 0)
    reqs = _perf_rows(site, after=after, limit=opt_int(options, "limit", 50))
    issues = analyze_requests(reqs, float(opt_str(options, "slow_query_ms", str(SLOW_QUERY_MS))),
                              float(opt_str(options, "slow_request_ms", str(SLOW_REQUEST_MS))))
    cursor = max((r["_created_at"] for r in reqs), default=after) or time.time()
    data = {"site": site["name"], "requests_analyzed": len(reqs), "issues": issues, "cursor": f"{cursor:.6f}"}

    def render(d):
        if not d["requests_analyzed"]:
            print("No captured requests to analyze. Enable the profiler for this site, then load a page.")
        elif not d["issues"]:
            print(f"No problems found in {d['requests_analyzed']} request(s).")
        for i in d["issues"]:
            loc = f"{i.get('file')}:{i.get('line')}" if i.get("file") else ""
            extra = f"x{i['count']}" if "count" in i else (f"{i['time_ms']} ms" if "time_ms" in i else f"HTTP {i.get('status')}")
            print(f"[{i['type']}] {i.get('method') or ''} {i.get('uri') or ''}  {extra}  {loc}")
            if i.get("sql"):
                print(f"    {i['sql'][:200]}")
            if i.get("message"):
                print(f"    {i['message'][:200]}")
            print(f"    hint: {i['hint']}")
        print(f"\nTo verify a fix, reload the page and run: laravel-dev insights:analyze --after={d['cursor']}")
    emit(data, options.get("json") is True, render)
    return 0


def cmd_insights_clear(args, options):
    site = resolve_site(options)
    removed = 0
    for name in {site["name"], site.get("domain", "")}:
        db = PERF_DIR / f"{name}.sqlite"
        if name and db.is_file():
            conn = sqlite3.connect(str(db))
            removed += conn.execute("DELETE FROM requests").rowcount
            conn.commit()
            conn.close()
    emit({"ok": True, "removed": removed}, options.get("json") is True, lambda d: print(f"Removed {removed} captured request(s)"))
    return 0


# ── instructions for coding agents ─────────────────────────────────────────

AGENT_BLOCK_START = "<!-- laravel-dev:start -->"
AGENT_BLOCK_END = "<!-- laravel-dev:end -->"


def agent_instructions(site: dict) -> str:
    return f"""{AGENT_BLOCK_START}
## Local development with Laravel Dev

This project runs locally on Laravel Dev at {site.get('url') or 'its .test domain'}.
Run `laravel-dev site:info` for the URL, PHP version and the services `.env` points at.
All commands below detect the site from the current directory and accept `--json`.

- Run PHP and Composer with this site's PHP version: `php{site.get('php') or ''} artisan ...`
  (or `laravel-dev site:info --json` → `php`).
- Read or change `.env`: `laravel-dev site:env get APP_URL`, `laravel-dev site:env set KEY "value"`.
- Database: `laravel-dev db:connection`, `laravel-dev db:list`, `laravel-dev db:use NAME --create` for a fresh test database.
- Mail is caught by Mailpit. After an action that sends a mail run
  `laravel-dev mail:wait --to=user@example.com` (start it before the action) or `laravel-dev mail:latest`,
  then `laravel-dev mail:links ID` for verification / reset URLs.
- Profiler data of recent requests: `laravel-dev insights:list` (`--type=query` for SQL) and
  `laravel-dev insights:analyze` for N+1, duplicate and slow queries, errors and slow requests with file and line.
  After a fix, reload the page and run `laravel-dev insights:analyze --after=CURSOR`.
- If something does not respond: `laravel-dev status`.
- `laravel-dev agent-help` lists every command. The same tools are available through the `laravel-dev mcp` MCP server.
{AGENT_BLOCK_END}
"""


def write_agent_instructions(site: dict) -> dict:
    """Adds/refreshes the Laravel Dev section in AGENTS.md (read by Codex, Cursor, Gemini, ...) and makes
    CLAUDE.md import it (Claude Code reads CLAUDE.md, which supports `@file` imports)."""
    root = Path(site["path"])
    block = agent_instructions(site)
    agents = root / "AGENTS.md"
    text = agents.read_text(encoding="utf-8") if agents.is_file() else ""
    pattern = re.compile(re.escape(AGENT_BLOCK_START) + r".*?" + re.escape(AGENT_BLOCK_END) + r"\n?", re.S)
    if pattern.search(text):
        new = pattern.sub(lambda _m: block, text, count=1)
        action = "updated"
    else:
        new = (text.rstrip("\n") + "\n\n" if text.strip() else "") + block
        action = "added" if text else "created"
    if new != text:
        agents.write_text(new, encoding="utf-8")
    else:
        action = "unchanged"
    files = [{"file": str(agents), "action": action}]

    claude = root / "CLAUDE.md"
    ctext = claude.read_text(encoding="utf-8") if claude.is_file() else ""
    if "@AGENTS.md" in ctext or AGENT_BLOCK_START in ctext:
        if AGENT_BLOCK_START in ctext:  # an older copy of the block: refresh it in place
            refreshed = pattern.sub(lambda _m: block, ctext, count=1)
            if refreshed != ctext:
                claude.write_text(refreshed, encoding="utf-8")
                files.append({"file": str(claude), "action": "updated"})
    else:
        claude.write_text((ctext.rstrip("\n") + "\n\n" if ctext.strip() else "") + "@AGENTS.md\n", encoding="utf-8")
        files.append({"file": str(claude), "action": "added import" if ctext else "created"})
    return {"ok": True, "files": files}


def cmd_site_agents(args, options):
    site = resolve_site(options)
    if options.get("print"):
        print(agent_instructions(site))
        return 0
    res = write_agent_instructions(site)
    emit(res, options.get("json") is True, lambda d: [print(f"{f['action']}: {f['file']}") for f in d["files"]])
    return 0


def cmd_init(args, options):
    site = resolve_site(options)
    project_path = Path(site["path"])
    fresh = bool(options.get("fresh") or "fresh" in args)
    import team_config
    yml_file = team_config.generate_laravel_dev_yml(project_path, fresh=fresh)
    data = {
        "ok": True,
        "site": site["name"],
        "file": str(yml_file),
        "fresh": fresh,
    }
    def render(d):
        print(f"Initialized project configuration: {d['file']}")
        print(f"Site: {d['site']}")
    emit(data, options.get("json") is True, render)
    return 0


def cmd_cloud(args: list[str], options: dict) -> int:
    import laravel_cloud
    sub = args[0] if args else "status"
    if sub in ("deploy", "push"):
        site = resolve_site(options)
        env = str(options.get("env") or options.get("environment") or "production")
        res = laravel_cloud.deploy_project_cloud(site["path"], environment=env)

        def render(d):
            print(f"Deploying {site['name']} to Laravel Cloud ({d.get('environment')})...")
            for stage in d.get("stages", []):
                st = "✔" if stage.get("status") == "completed" else "✖"
                print(f"  {st} [{stage['name'].upper()}] {stage.get('status')} ({stage.get('duration_ms', 0)}ms)")
            if d.get("url"):
                print(f"\nLive URL: {d['url']}")
        emit(res, options.get("json") is True, render)
        return 0 if res.get("ok") else 1
    elif sub == "link":
        site = resolve_site(options)
        app_name = args[1] if len(args) > 1 else site["name"]
        env = str(options.get("env") or "production")
        res = laravel_cloud.link_project_cloud(site["path"], app_name, environment=env)
        emit(res, options.get("json") is True, lambda d: print(f"Linked {site['name']} to Laravel Cloud app '{d['app_name']}' ({d['url']})"))
        return 0
    else:  # status / whoami
        cli_st = laravel_cloud.get_cloud_cli_status()
        site_info = None
        try:
            site = resolve_site(options)
            site_info = laravel_cloud.get_project_cloud_status(site["path"])
        except Exception:
            pass
        combined = {
            "cli": cli_st,
            "project": site_info,
        }

        def render(d):
            cli = d["cli"]
            print(f"Laravel Cloud CLI: {'Installed (' + str(cli['version']) + ')' if cli['installed'] else 'Not installed'}")
            if cli.get("cli_path"):
                print(f"CLI Path:          {cli['cli_path']}")
            print(f"Authenticated:     {'Yes (' + str(cli.get('user') or 'user') + ')' if cli['authenticated'] else 'No'}")
            if d.get("project"):
                p = d["project"]
                print(f"\nProject Linked:    {'Yes' if p['linked'] else 'No'}")
                if p.get("app_name"):
                    print(f"Application:       {p['app_name']}")
                if p.get("url"):
                    print(f"Public URL:        {p['url']}")
        emit(combined, options.get("json") is True, render)
        return 0


# ── dispatch ──────────────────────────────────────────────────────────────────

COMMANDS = {
    "init": (cmd_init, "[--fresh]  Initialize or update laravel-dev.yml based on .env"),
    "status": (cmd_status, "Health check of the local environment"),
    "which": (cmd_which, "Determine the framework driver and public root serving this site"),
    "cloud": (cmd_cloud, "[status|deploy|link|login] Laravel Cloud CLI integration"),
    "cloud:status": (cmd_cloud, "Inspect Laravel Cloud CLI and account authentication status"),
    "cloud:deploy": (cmd_cloud, "[--env=production] Deploy current site to Laravel Cloud"),
    "site:info": (cmd_site_info, "URL, PHP/Node versions, services and capabilities of a site"),
    "site:env": (cmd_site_env, "list | get KEY | set KEY VALUE | unset KEY  (keeps comments and order)"),
    "site:services": (cmd_site_services, "[category] [option]  View or switch per-site services (database/queue/cache/broadcasting/mail)"),
    "site:agents": (cmd_site_agents, "Add/refresh the Laravel Dev section in AGENTS.md (+ CLAUDE.md import) [--print]"),
    "db:connection": (cmd_db_connection, "Database connection of the site and a connection URL"),
    "db:open": (cmd_db_open, "[tableplus|dbeaver]  Open database in GUI client or print deep-link URLs"),
    "db:list": (cmd_db_list, "Databases on the server the site uses"),
    "db:create": (cmd_db_create, "[NAME]  Create a database (default: DB_DATABASE)"),
    "db:use": (cmd_db_use, "NAME [--create]  Point DB_DATABASE at another database"),
    "db:drop": (cmd_db_drop, "NAME [--force]  Drop a database"),
    "mail:list": (cmd_mail_list, "Captured mails  [--to= --from= --subject= --mailbox= --since= --limit=]"),
    "mail:latest": (cmd_mail_latest, "Newest matching mail"),
    "mail:show": (cmd_mail_show, "ID [--format=text|html|raw|json] [--headers]"),
    "mail:wait": (cmd_mail_wait, "Wait for a new matching mail [--timeout=30]"),
    "mail:links": (cmd_mail_links, "ID  Print every link of a mail"),
    "mail:attachments": (cmd_mail_attachments, "ID  List attachments"),
    "mail:attachment": (cmd_mail_attachment, "ID FILE [--out=DIR]  Save an attachment"),
    "mail:mailboxes": (cmd_mail_mailboxes, "Mailboxes (tags) and their mail count"),
    "mail:delete": (cmd_mail_delete, "ID [ID...]  Delete mails"),
    "mail:clear": (cmd_mail_clear, "[MAILBOX]  Delete all mails (or one mailbox)"),
    "mail:config": (cmd_mail_config, "Mail server host/port and the .env values"),
    "insights:list": (cmd_insights_list, "Profiled requests [--type=request|query] [--limit=20]"),
    "insights:analyze": (cmd_insights_analyze, "N+1, duplicate and slow queries, errors, slow requests [--after=CURSOR]"),
    "insights:clear": (cmd_insights_clear, "Discard the captured requests of the site"),
}


def usage() -> str:
    lines = ["Agent commands (all accept --json and --site=NAME):"]
    for name, (_, desc) in COMMANDS.items():
        lines.append(f"  {name:<18} {desc}")
    return "\n".join(lines)


def main(argv: list[str]) -> int:
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(usage())
        return 0
    name = argv[0]
    entry = COMMANDS.get(name)
    if entry is None:
        print(f"Unknown command: {name}\n\n{usage()}", file=sys.stderr)
        return 2
    try:
        args, options = parse_args(argv[1:])
        if options.get("help"):
            print(f"laravel-dev {name}  {entry[1]}")
            return 0
        return entry[0](args, options)
    except CliError as exc:
        if "--json" in argv:
            print(json.dumps({"ok": False, "error": str(exc)}))
        else:
            print(f"Error: {exc}", file=sys.stderr)
        return exc.code
    except Exception as exc:  # database / network errors from shared modules
        if "--json" in argv:
            print(json.dumps({"ok": False, "error": str(exc)}))
        else:
            print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
