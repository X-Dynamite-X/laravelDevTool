"""ui/workspaces.py - Full Git Workspaces management:
- Database modes: shared, clone, empty (with SQLite, MySQL/MariaDB, PostgreSQL)
- .env configuration: APP_URL, SESSION_DOMAIN, SANCTUM_STATEFUL_DOMAINS, DB_DATABASE
- Copying files and smart vendor/node_modules caching
- Config loading from laravel-dev.yml / laravel-dev.local.yml
- Lifecycle hooks (after_create, before_delete)
- Workspace merge and cleanup
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import envfile

# Safe branch sanitization matching core/WorkspaceManager.sh
def sanitize_branch_name(branch: str) -> str:
    cleaned = re.sub(r"[/_.]+", "-", branch)
    cleaned = re.sub(r"[^A-Za-z0-9\-]+", "", cleaned).lower()
    return cleaned.strip("-")


def parse_yaml_fallback(text: str) -> Dict[str, Any]:
    """Lightweight fallback YAML parser for workspaces: config block."""
    result: Dict[str, Any] = {}
    current_key: Optional[str] = None
    sub_key: Optional[str] = None
    in_workspaces = False

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue

        indent = len(raw_line) - len(raw_line.lstrip(" "))
        if indent == 0:
            if line.startswith("workspaces:"):
                in_workspaces = True
                result["workspaces"] = {}
                current_key = "workspaces"
                sub_key = None
            else:
                in_workspaces = False
                current_key = None
            continue

        if in_workspaces and current_key == "workspaces":
            ws = result["workspaces"]
            if indent >= 4 and sub_key in ("hooks", "env") and isinstance(ws.get(sub_key), dict):
                inner = ws[sub_key]
                if line.startswith("- ") and inner:
                    last = list(inner)[-1]
                    if not isinstance(inner[last], list):
                        inner[last] = [inner[last]] if inner[last] else []
                    inner[last].append(line[2:].strip().strip("'\""))
                elif ":" in line:
                    hk, hv = line.split(":", 1)
                    inner[hk.strip()] = hv.strip().strip("'\"")
                continue
            if indent == 2:
                if ":" in line:
                    k, v = line.split(":", 1)
                    k, v = k.strip(), v.strip()
                    sub_key = k
                    if not v:
                        ws[k] = {} if k in ("env", "hooks") else []
                    else:
                        ws[k] = v.strip("'\"")
                elif line.startswith("- "):
                    pass
            elif indent >= 4 and sub_key:
                if isinstance(ws.get(sub_key), dict) and ":" in line:
                    hk, hv = line.split(":", 1)
                    ws[sub_key][hk.strip()] = hv.strip().strip("'\"")
                elif isinstance(ws.get(sub_key), list) and line.startswith("- "):
                    ws[sub_key].append(line[2:].strip().strip("'\""))

    return result


def load_workspace_config(project_path: Path) -> Dict[str, Any]:
    """Reads workspaces configuration from laravel-dev.yml and overlays laravel-dev.local.yml."""
    config: Dict[str, Any] = {
        "database": "shared",
        "migrate": True,
        "copy": [],
        "env": {},
        "hooks": {},
        "app_dir": "",
    }

    candidates = [
        project_path / "laravel-dev.yml",
        project_path / "herd.yml",
        project_path / "laravel-dev.local.yml",
    ]

    for c in candidates:
        if c.is_file():
            try:
                try:
                    import yaml  # type: ignore
                    data = yaml.safe_load(c.read_text(encoding="utf-8")) or {}
                except ImportError:
                    data = parse_yaml_fallback(c.read_text(encoding="utf-8"))

                ws_data = data.get("workspaces")
                if isinstance(ws_data, dict):
                    if "database" in ws_data:
                        config["database"] = str(ws_data["database"]).lower().strip()
                    if "migrate" in ws_data:
                        config["migrate"] = bool(ws_data["migrate"])
                    if "copy" in ws_data and isinstance(ws_data["copy"], list):
                        config["copy"].extend(ws_data["copy"])
                    if "env" in ws_data and isinstance(ws_data["env"], dict):
                        config["env"].update(ws_data["env"])
                    if "hooks" in ws_data and isinstance(ws_data["hooks"], dict):
                        config["hooks"].update(ws_data["hooks"])
                    if "app_dir" in ws_data:
                        config["app_dir"] = str(ws_data["app_dir"]).strip()
            except Exception:
                pass

    return config


def render_template(template: str, vars_map: Dict[str, str]) -> str:
    """Substitutes {{variable}} placeholders with values from vars_map."""
    res = template
    for k, v in vars_map.items():
        res = res.replace(f"{{{{{k}}}}}", str(v))
    return res


def prepare_workspace_env(
    parent_path: Path,
    wt_path: Path,
    branch: str,
    project_domain: str,
    scheme: str = "http",
    db_mode: str = "shared",
    custom_db_name: Optional[str] = None,
    custom_env: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    """Creates the workspace .env by adjusting URL, domains, database, and custom vars."""
    parent_env_file = parent_path / ".env"
    parent_text = parent_env_file.read_text(encoding="utf-8", errors="replace") if parent_env_file.is_file() else ""
    parent_dict = envfile.to_dict(parent_text)

    sanitized = sanitize_branch_name(branch)
    workspace_domain = f"{sanitized}.{project_domain}"

    vars_map = {
        "branch": branch,
        "sanitized_branch": sanitized,
        "sanitized": sanitized,
        "project": parent_path.name,
        "domain": workspace_domain,
        "project_domain": project_domain,
    }

    changes: Dict[str, Any] = {"APP_URL": f"{scheme}://{workspace_domain}"}
    # Only values that point at the parent domain change; ".shop.test" already covers the workspace.
    if (parent_dict.get("SESSION_DOMAIN") or "").strip() == project_domain:
        changes["SESSION_DOMAIN"] = workspace_domain
    stateful = parent_dict.get("SANCTUM_STATEFUL_DOMAINS")
    if stateful:
        parts = [d.strip() for d in stateful.split(",")]
        changes["SANCTUM_STATEFUL_DOMAINS"] = ",".join(workspace_domain if d == project_domain else d for d in parts)

    if db_mode in ("clone", "empty"):
        parent_db = parent_dict.get("DB_DATABASE") or parent_path.name
        # Sanitize database name for SQL
        sanitized_db = re.sub(r"[^A-Za-z0-9_]+", "_", f"{parent_db}_{sanitized}").strip("_")
        changes["DB_DATABASE"] = custom_db_name or sanitized_db

    if custom_env:
        for k, v in custom_env.items():
            changes[k] = render_template(str(v), vars_map)

    new_text = envfile.apply(parent_text, changes)
    wt_env_file = wt_path / ".env"
    wt_env_file.write_text(new_text, encoding="utf-8")

    return envfile.to_dict(new_text)


def setup_workspace_database(
    parent_dict: Dict[str, str],
    wt_dict: Dict[str, str],
    db_mode: str,
    parent_path: Path,
    wt_path: Path,
) -> Tuple[bool, str]:
    """Sets up database for clone or empty mode. Falls back cleanly to shared on failure."""
    if db_mode == "shared":
        return True, "Using shared parent database."

    driver = (wt_dict.get("DB_CONNECTION") or wt_dict.get("DB_DRIVER") or "sqlite").lower()
    parent_db = parent_dict.get("DB_DATABASE") or ""
    new_db = wt_dict.get("DB_DATABASE") or ""

    if not new_db:
        return False, "Target DB_DATABASE is empty."

    # SQLite
    if "sqlite" in driver:
        # Resolve path
        def resolve_sqlite(raw_path: str, base: Path) -> Path:
            p = Path(raw_path)
            return p if p.is_absolute() else (base / p)

        parent_sqlite = resolve_sqlite(parent_db or "database/database.sqlite", parent_path)
        wt_sqlite = resolve_sqlite(new_db or "database/database.sqlite", wt_path)
        wt_sqlite.parent.mkdir(parents=True, exist_ok=True)

        if db_mode == "clone":
            if parent_sqlite.is_file():
                shutil.copy2(parent_sqlite, wt_sqlite)
                return True, f"Cloned SQLite database to {wt_sqlite.name}."
            else:
                wt_sqlite.touch()
                return True, f"Created SQLite database at {wt_sqlite.name} (parent was empty)."
        elif db_mode == "empty":
            wt_sqlite.touch()
            return True, f"Created empty SQLite database at {wt_sqlite.name}."

    # MySQL / MariaDB
    if "mysql" in driver or "mariadb" in driver:
        host = wt_dict.get("DB_HOST") or "127.0.0.1"
        port = wt_dict.get("DB_PORT") or "3306"
        user = wt_dict.get("DB_USERNAME") or "root"
        pw = wt_dict.get("DB_PASSWORD") or ""

        mysql_base = ["mysql", f"-h{host}", f"-P{port}", f"-u{user}"]
        dump_base = ["mysqldump", f"-h{host}", f"-P{port}", f"-u{user}"]
        my_env = os.environ.copy()
        if pw:
            my_env["MYSQL_PWD"] = pw  # not on the command line, where `ps` shows it

        try:
            # 1. Create database
            create_sql = f"CREATE DATABASE IF NOT EXISTS `{new_db}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
            subprocess.run(mysql_base + ["-e", create_sql], check=True, capture_output=True, text=True, env=my_env)

            if db_mode == "clone" and parent_db:
                # 2. Dump and import
                dump_cmd = dump_base + ["--routines", "--triggers", "--events", parent_db]
                dump_proc = subprocess.Popen(dump_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=my_env)
                import_proc = subprocess.Popen(mysql_base + [new_db], stdin=dump_proc.stdout, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=my_env)
                if dump_proc.stdout:
                    dump_proc.stdout.close()
                _, import_err = import_proc.communicate()
                dump_err = dump_proc.stderr.read() if dump_proc.stderr else b""
                dump_proc.wait()

                # A failed mysqldump still lets the import "succeed" on empty input.
                if dump_proc.returncode != 0:
                    return False, f"mysqldump failed: {dump_err.decode(errors='replace').strip()}"
                if import_proc.returncode != 0:
                    return False, f"MySQL import failed: {import_err.decode(errors='replace').strip()}"
                return True, f"Cloned MySQL database '{parent_db}' into '{new_db}'."

            return True, f"Created empty MySQL database '{new_db}'."
        except Exception as e:
            return False, f"MySQL database setup failed: {str(e)}"

    # PostgreSQL
    if "pgsql" in driver or "postgres" in driver:
        host = wt_dict.get("DB_HOST") or "127.0.0.1"
        port = wt_dict.get("DB_PORT") or "5432"
        user = wt_dict.get("DB_USERNAME") or "postgres"
        pw = wt_dict.get("DB_PASSWORD") or ""

        env_pg = os.environ.copy()
        if pw:
            env_pg["PGPASSWORD"] = pw

        psql_cmd = ["psql", "-h", host, "-p", port, "-U", user, "-d", "postgres"]

        try:
            if db_mode == "clone" and parent_db:
                sql = f'CREATE DATABASE "{new_db}" TEMPLATE "{parent_db}";'
            else:
                sql = f'CREATE DATABASE "{new_db}";'

            proc = subprocess.run(psql_cmd + ["-c", sql], env=env_pg, capture_output=True, text=True)
            if proc.returncode == 0:
                return True, f"PostgreSQL database '{new_db}' created (mode: {db_mode})."
            else:
                return False, f"PostgreSQL error: {proc.stderr}"
        except Exception as e:
            return False, f"PostgreSQL execution failed: {str(e)}"

    return True, f"Database configured ({driver})."


def drop_workspace_database(parent_dict: Dict[str, str], wt_dict: Dict[str, str], wt_path: Path) -> Tuple[bool, str]:
    """Drops the workspace database if it is isolated and different from parent."""
    parent_db = parent_dict.get("DB_DATABASE") or ""
    wt_db = wt_dict.get("DB_DATABASE") or ""

    if not wt_db or wt_db == parent_db:
        return True, "Database was shared; skipping drop."

    driver = (wt_dict.get("DB_CONNECTION") or wt_dict.get("DB_DRIVER") or "sqlite").lower()

    if "sqlite" in driver:
        p = Path(wt_db)
        sqlite_file = p if p.is_absolute() else (wt_path / p)
        if sqlite_file.is_file():
            sqlite_file.unlink()
            return True, f"Removed workspace SQLite file {sqlite_file.name}."
        return True, "No SQLite file found to remove."

    if "mysql" in driver or "mariadb" in driver:
        host = wt_dict.get("DB_HOST") or "127.0.0.1"
        port = wt_dict.get("DB_PORT") or "3306"
        user = wt_dict.get("DB_USERNAME") or "root"
        pw = wt_dict.get("DB_PASSWORD") or ""

        cmd = ["mysql", f"-h{host}", f"-P{port}", f"-u{user}"]
        my_env = os.environ.copy()
        if pw:
            my_env["MYSQL_PWD"] = pw
        try:
            subprocess.run(cmd + ["-e", f"DROP DATABASE IF EXISTS `{wt_db}`;"], check=True, capture_output=True, env=my_env)
            return True, f"Dropped MySQL database `{wt_db}`."
        except Exception as e:
            return False, f"Failed to drop MySQL database `{wt_db}`: {str(e)}"

    if "pgsql" in driver or "postgres" in driver:
        host = wt_dict.get("DB_HOST") or "127.0.0.1"
        port = wt_dict.get("DB_PORT") or "5432"
        user = wt_dict.get("DB_USERNAME") or "postgres"
        pw = wt_dict.get("DB_PASSWORD") or ""
        env_pg = os.environ.copy()
        if pw:
            env_pg["PGPASSWORD"] = pw

        try:
            cmd = ["psql", "-h", host, "-p", port, "-U", user, "-d", "postgres", "-c", f'DROP DATABASE IF EXISTS "{wt_db}";']
            subprocess.run(cmd, env=env_pg, check=True, capture_output=True)
            return True, f"Dropped PostgreSQL database `{wt_db}`."
        except Exception as e:
            return False, f"Failed to drop PostgreSQL database `{wt_db}`: {str(e)}"

    return True, "Database dropped."


def copy_configured_files(parent_path: Path, wt_path: Path, copy_list: List[str]) -> List[str]:
    """Copies extra configured files (e.g. auth.json, .env.testing) from parent to workspace."""
    copied = []
    for rel in copy_list:
        src = parent_path / rel
        dest = wt_path / rel
        if src.is_file():
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
            copied.append(rel)
        elif src.is_dir():
            dest.parent.mkdir(parents=True, exist_ok=True)
            if not dest.exists():
                shutil.copytree(src, dest)
                copied.append(f"{rel}/")
    return copied


def run_workspace_hook(hook_cmd, wt_path: Path) -> Tuple[int, str]:
    """Runs a hook: one command or a list of commands (stops at the first failure, like Herd)."""
    if isinstance(hook_cmd, (list, tuple)):
        output = []
        for cmd in hook_cmd:
            code, out = run_workspace_hook(str(cmd), wt_path)
            output.append(out)
            if code != 0:
                return code, "\n".join(output)
        return 0, "\n".join(output)
    if not hook_cmd or not str(hook_cmd).strip():
        return 0, ""
    try:
        proc = subprocess.run(
            hook_cmd,
            shell=True,
            cwd=str(wt_path),
            capture_output=True,
            text=True,
            timeout=120,
        )
        return proc.returncode, proc.stdout + proc.stderr
    except Exception as e:
        return 1, str(e)


def workspace_merge(
    project_path: Path,
    branch: str,
    target_branch: Optional[str] = None,
    push: bool = False,
) -> Dict[str, Any]:
    """Merges workspace branch into target branch."""
    # Ensure working tree clean
    status = subprocess.check_output(["git", "-C", str(project_path), "status", "--porcelain"], text=True)
    if status.strip():
        raise ValueError("Cannot merge: Primary repository working tree has uncommitted changes.")

    target = target_branch
    if not target:
        # Detect default branch
        try:
            sym = subprocess.check_output(["git", "-C", str(project_path), "symbolic-ref", "refs/remotes/origin/HEAD"], text=True).strip()
            target = sym.split("/")[-1]
        except Exception:
            target = "main"

    subprocess.run(["git", "-C", str(project_path), "checkout", target], check=True, capture_output=True)
    merge_proc = subprocess.run(["git", "-C", str(project_path), "merge", branch], capture_output=True, text=True)
    if merge_proc.returncode != 0:
        raise ValueError(f"Merge conflict or failure: {merge_proc.stderr}")

    pushed = False
    if push:
        push_proc = subprocess.run(["git", "-C", str(project_path), "push", "origin", target], capture_output=True, text=True)
        if push_proc.returncode != 0:
            raise ValueError(f"Push to remote failed: {push_proc.stderr}")
        pushed = True

    return {
        "ok": True,
        "branch": branch,
        "merged_into": target,
        "pushed": pushed,
    }


def main() -> int:
    import sys

    if len(sys.argv) < 2:
        print("Usage: python3 -m ui.workspaces <post-create|pre-delete|merge> ...")
        return 2

    action = sys.argv[1]

    if action == "post-create":
        # python3 -m ui.workspaces post-create <parent_path> <wt_path> <branch> <domain> <scheme> [options]
        if len(sys.argv) < 7:
            print("Usage: python3 -m ui.workspaces post-create <parent_path> <wt_path> <branch> <domain> <scheme> [options]")
            return 2
        parent_path = Path(sys.argv[2])
        wt_path = Path(sys.argv[3])
        branch = sys.argv[4]
        domain = sys.argv[5]
        scheme = sys.argv[6]

        db_mode = None
        no_migrate = False
        for arg in sys.argv[7:]:
            if arg.startswith("--database="):
                db_mode = arg.split("=", 1)[1]
            elif arg == "--no-migrate":
                no_migrate = True

        cfg = load_workspace_config(parent_path)
        effective_db_mode = db_mode or cfg.get("database") or "shared"
        # Only a new empty database is migrated: in shared mode the parent's database must not
        # get this branch's migrations, and a clone already has the parent's schema.
        should_migrate = effective_db_mode == "empty" and cfg.get("migrate", True) and not no_migrate

        # 1. Prepare env
        parent_env_file = parent_path / ".env"
        parent_dict = envfile.to_dict(parent_env_file.read_text(encoding="utf-8", errors="replace")) if parent_env_file.is_file() else {}
        wt_env_dict = prepare_workspace_env(
            parent_path,
            wt_path,
            branch,
            domain,
            scheme=scheme,
            db_mode=effective_db_mode,
            custom_env=cfg.get("env"),
        )

        # 2. Database setup
        ok, msg = setup_workspace_database(parent_dict, wt_env_dict, effective_db_mode, parent_path, wt_path)
        print(f"[{'OK' if ok else 'WARN'}] {msg}")
        if not ok and effective_db_mode != "shared":
            # Fall back to the shared database instead of leaving the workspace pointing at nothing.
            wt_env_file = wt_path / ".env"
            restore = {"DB_DATABASE": parent_dict.get("DB_DATABASE")}
            wt_env_file.write_text(envfile.apply(wt_env_file.read_text(encoding="utf-8"), restore), encoding="utf-8")
            print("[WARN] Using the shared parent database instead.")
            effective_db_mode = "shared"
            should_migrate = False

        # 3. Copy files
        copied = copy_configured_files(parent_path, wt_path, cfg.get("copy", []))
        if copied:
            print(f"[OK] Copied {len(copied)} files/folders to workspace.")

        # 4. Run after_create hook
        after_hook = cfg.get("hooks", {}).get("after_create", "")
        if after_hook:
            print(f"Running after_create hook: {after_hook}")
            code, out = run_workspace_hook(after_hook, wt_path)
            if code != 0:
                print(f"[WARN] after_create hook returned non-zero code {code}: {out.strip()}")
            else:
                print(f"[OK] after_create hook succeeded.")

        # 5. Migrations
        artisan = wt_path / "artisan"
        if should_migrate and artisan.is_file():
            print("Running migrations in workspace...")
            mig_proc = subprocess.run(["php", "artisan", "migrate", "--force"], cwd=str(wt_path), capture_output=True, text=True)
            if mig_proc.returncode == 0:
                print("[OK] Database migrations completed.")
            else:
                print(f"[WARN] Migrations failed or incomplete: {mig_proc.stderr.strip() or mig_proc.stdout.strip()}")

        return 0

    elif action == "pre-delete":
        # python3 -m ui.workspaces pre-delete <parent_path> <wt_path> [--keep-database]
        if len(sys.argv) < 4:
            print("Usage: python3 -m ui.workspaces pre-delete <parent_path> <wt_path> [options]")
            return 2
        parent_path = Path(sys.argv[2])
        wt_path = Path(sys.argv[3])
        keep_db = "--keep-database" in sys.argv[4:]

        cfg = load_workspace_config(parent_path)

        # 1. Run before_delete hook
        before_hook = cfg.get("hooks", {}).get("before_delete", "")
        if before_hook:
            print(f"Running before_delete hook: {before_hook}")
            run_workspace_hook(before_hook, wt_path)

        # 2. Drop database if not keep_db
        if not keep_db and wt_path.is_dir():
            parent_env_file = parent_path / ".env"
            parent_dict = envfile.to_dict(parent_env_file.read_text(encoding="utf-8", errors="replace")) if parent_env_file.is_file() else {}
            wt_env_file = wt_path / ".env"
            wt_dict = envfile.to_dict(wt_env_file.read_text(encoding="utf-8", errors="replace")) if wt_env_file.is_file() else {}
            ok, msg = drop_workspace_database(parent_dict, wt_dict, wt_path)
            print(f"[{'OK' if ok else 'WARN'}] {msg}")

        return 0

    elif action == "merge":
        # python3 -m ui.workspaces merge <project_path> <branch> [--target=...] [--push]
        if len(sys.argv) < 4:
            print("Usage: python3 -m ui.workspaces merge <project_path> <branch> [options]")
            return 2
        project_path = Path(sys.argv[2])
        branch = sys.argv[3]
        target = None
        push = False
        for arg in sys.argv[4:]:
            if arg.startswith("--target="):
                target = arg.split("=", 1)[1]
            elif arg == "--push":
                push = True

        try:
            res = workspace_merge(project_path, branch, target_branch=target, push=push)
            print(f"[OK] Merged branch '{branch}' into '{res['merged_into']}'. (Pushed: {res['pushed']})")
            return 0
        except Exception as e:
            print(f"Error: {str(e)}", file=sys.stderr)
            return 1

    else:
        print(f"Unknown action: {action}")
        return 2


if __name__ == "__main__":
    import sys
    sys.exit(main())

