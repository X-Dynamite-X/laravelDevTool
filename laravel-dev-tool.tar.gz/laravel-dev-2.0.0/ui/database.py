"""Database browser (Navicat-style) for MySQL / MariaDB, PostgreSQL and SQLite.

Connections come from three places: the global settings, each site's .env
(DB_* or DATABASE_URL) and connections the user saved. Remote databases are
reached through an SSH tunnel over the server's existing connection, so no
port has to be opened on the server.

Memory: drivers are imported only when first used, live connections are
pooled per (connection, database) and closed after two idle minutes, result
pages are capped and long values are truncated before they reach the UI.
Exports and imports stream row by row / statement by statement.
"""

import base64
import datetime
import decimal
import json
import os
import random
import re
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import unquote, urlparse

from osutil import private_file

DRIVERS = ("mysql", "mariadb", "pgsql", "sqlite")
DRIVER_LABELS = {"mysql": "MySQL", "mariadb": "MariaDB", "pgsql": "PostgreSQL", "sqlite": "SQLite"}
DEFAULT_PORTS = {"mysql": 3306, "mariadb": 3306, "pgsql": 5432}
SYSTEM_DATABASES = {"information_schema", "performance_schema", "mysql", "sys", "template0", "template1"}
IDLE_SECONDS = 120
MAX_CELL = 2000          # characters of a value sent to the grid
MAX_QUERY_ROWS = 1000    # rows per result set in the SQL editor
NAME_RE = re.compile(r"^[A-Za-z0-9_$\-. ]{1,128}$")

MOCK_FIRST_NAMES = (
    "James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda",
    "William", "Elizabeth", "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica",
    "Thomas", "Sarah", "Charles", "Karen", "Christopher", "Nancy", "Daniel", "Lisa",
    "Matthew", "Betty", "Anthony", "Margaret", "Mark", "Sandra", "Donald", "Ashley",
    "Steven", "Kimberly", "Paul", "Emily", "Andrew", "Donna", "Joshua", "Michelle",
    "Tariq", "Fatima", "Omar", "Amina", "Zayn", "Nour", "Kareem", "Layla", "Youssef", "Mariam"
)

MOCK_LAST_NAMES = (
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
    "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
    "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker",
    "Al-Mansoor", "Hassan", "Khalil", "Saeed", "Farah", "Saleh", "Darwish", "Nasser"
)

MOCK_CITIES = (
    "New York", "London", "Tokyo", "Paris", "Berlin", "Sydney", "Toronto",
    "Riyadh", "Dubai", "Cairo", "Singapore", "Amsterdam", "San Francisco", "Austin"
)

MOCK_COUNTRIES = ("US", "GB", "CA", "DE", "FR", "AU", "SA", "AE", "EG", "JP", "SG", "NL")

MOCK_COMPANIES = (
    "Apex Global", "NexSys Technologies", "Starlight Media", "CloudWave Inc.",
    "Quantum Digital", "Horizon Labs", "Vanguard Solutions", "Nova Core Systems",
    "HyperScale Logic", "AeroDynamics Co."
)

MOCK_WORDS = (
    "Platform", "Integration", "Security", "Optimization", "Architecture",
    "Framework", "Workflow", "Deployment", "Analytics", "Performance",
    "Database", "Automation", "Insight", "Gateway", "Matrix", "Engine"
)

MOCK_PHRASES = (
    "Provides automated integration and enterprise-grade performance monitoring.",
    "Designed to simplify modern web development workflows and optimize system resources.",
    "Features real-time relational schema visualization and low-memory background synchronization.",
    "Enables rapid prototyping with built-in code generation and automated testing capabilities.",
    "Engineered with security-first architecture and resilient distributed transaction management."
)


def _singularize(word):
    irregulars = {
        "people": "person", "children": "child", "men": "man", "women": "woman",
        "data": "datum", "criteria": "criterion", "analyses": "analysis",
        "statuses": "status", "quizzes": "quiz", "matrices": "matrix",
        "indices": "index", "vertices": "vertex"
    }
    lower = word.lower()
    if lower in irregulars:
        return irregulars[lower]
    if lower.endswith("ies") and len(lower) > 3 and lower[-4] not in "aeiou":
        return word[:-3] + "y"
    if lower.endswith(("ses", "xes", "ches", "shes")):
        return word[:-2]
    if lower.endswith("s") and not lower.endswith(("ss", "us", "is")):
        return word[:-1]
    return word


def _to_pascal(name):
    parts = name.split(".")[-1].split("_")
    if parts:
        parts[-1] = _singularize(parts[-1])
    return "".join(p.capitalize() for p in parts if p)


def _to_camel(name):
    parts = name.split(".")[-1].split("_")
    if not parts:
        return name
    return parts[0].lower() + "".join(p.capitalize() for p in parts[1:])


def _column_blueprint(c, unique_cols=()):
    name = c["name"]
    raw_type = (c.get("type") or "").strip().lower()
    nullable = bool(c.get("nullable"))
    default = c.get("default")
    is_unique = name in unique_cols

    len_match = re.search(r"\((\d+)\)", raw_type)
    length = int(len_match.group(1)) if len_match else None
    dec_match = re.search(r"\((\d+),\s*(\d+)\)", raw_type)

    if "bool" in raw_type or raw_type == "tinyint(1)":
        call = f"$table->boolean('{name}')"
    elif "tinyint" in raw_type:
        call = f"$table->tinyInteger('{name}')"
    elif "smallint" in raw_type:
        call = f"$table->smallInteger('{name}')"
    elif "mediumint" in raw_type:
        call = f"$table->mediumInteger('{name}')"
    elif "bigint" in raw_type:
        call = f"$table->bigInteger('{name}')"
    elif "int" in raw_type:
        call = f"$table->integer('{name}')"
    elif dec_match:
        call = f"$table->decimal('{name}', {dec_match.group(1)}, {dec_match.group(2)})"
    elif "decimal" in raw_type or "numeric" in raw_type:
        call = f"$table->decimal('{name}', 10, 2)"
    elif "float" in raw_type:
        call = f"$table->float('{name}')"
    elif "double" in raw_type or "real" in raw_type:
        call = f"$table->double('{name}')"
    elif "varchar" in raw_type or "character varying" in raw_type:
        if length and length != 255:
            call = f"$table->string('{name}', {length})"
        else:
            call = f"$table->string('{name}')"
    elif "char" in raw_type:
        call = f"$table->char('{name}', {length or 1})"
    elif "longtext" in raw_type:
        call = f"$table->longText('{name}')"
    elif "mediumtext" in raw_type:
        call = f"$table->mediumText('{name}')"
    elif "text" in raw_type:
        call = f"$table->text('{name}')"
    elif "json" in raw_type:
        call = f"$table->json('{name}')"
    elif "datetime" in raw_type:
        call = f"$table->dateTime('{name}')"
    elif "timestamp" in raw_type:
        call = f"$table->timestamp('{name}')"
    elif "date" in raw_type:
        call = f"$table->date('{name}')"
    elif "time" in raw_type:
        call = f"$table->time('{name}')"
    elif "uuid" in raw_type:
        call = f"$table->uuid('{name}')"
    elif "blob" in raw_type or "binary" in raw_type or "bytea" in raw_type:
        call = f"$table->binary('{name}')"
    elif "enum" in raw_type:
        opts = re.findall(r"'([^']*)'", raw_type)
        opts_str = ", ".join(f"'{o}'" for o in opts)
        call = f"$table->enum('{name}', [{opts_str}])"
    else:
        call = f"$table->string('{name}')"

    if "unsigned" in raw_type and not call.startswith("$table->unsigned") and "boolean" not in call:
        call += "->unsigned()"
    if nullable:
        call += "->nullable()"
    if is_unique:
        call += "->unique()"

    if default is not None:
        def_str = str(default).strip()
        def_upper = def_str.upper()
        if def_upper in ("CURRENT_TIMESTAMP", "CURRENT_TIMESTAMP()", "NOW()"):
            call += "->useCurrent()"
        elif def_str.lower() in ("true", "1") and ("bool" in raw_type or raw_type == "tinyint(1)"):
            call += "->default(true)"
        elif def_str.lower() in ("false", "0") and ("bool" in raw_type or raw_type == "tinyint(1)"):
            call += "->default(false)"
        elif re.fullmatch(r"^-?\d+(\.\d+)?$", def_str):
            call += f"->default({def_str})"
        else:
            clean = def_str.strip("'\"")
            if clean and clean != "NULL":
                esc = clean.replace("\\", "\\\\").replace("'", "\\'")
                call += f"->default('{esc}')"

    comment = c.get("comment")
    if comment:
        esc_c = comment.replace("\\", "\\\\").replace("'", "\\'")
        call += f"->comment('{esc_c}')"

    return call


def _generate_mock_value(c, fk_pool, row_idx, is_unique=False):
    name = c["name"].lower()
    raw_type = (c.get("type") or "").lower()

    if c["name"] in fk_pool and fk_pool[c["name"]]:
        return random.choice(fk_pool[c["name"]])

    if c.get("pk") and (c.get("auto") or "int" in raw_type or name == "id"):
        return None

    # Check for varchar/char length limit
    max_len = None
    m_len = re.search(r"\b(?:varchar|char)\s*\(\s*(\d+)\s*\)", raw_type)
    if m_len:
        max_len = int(m_len.group(1))

    # Short random suffix for uniqueness
    uid_suffix = uuid.uuid4().hex[:6] if is_unique else ""

    val = None
    if "uuid" in raw_type or name.endswith("_uuid") or name == "uuid":
        val = str(uuid.uuid4())
    elif name in ("created_at", "updated_at"):
        delta_s = random.randint(0, 30 * 86400)
        dt = datetime.datetime.now() - datetime.timedelta(seconds=delta_s)
        val = dt.strftime("%Y-%m-%d %H:%M:%S")
    elif name == "deleted_at":
        val = None
    elif "bool" in raw_type or raw_type == "tinyint(1)" or name.startswith(("is_", "has_", "can_")):
        val = random.choice([True, False])
    elif "password" in name or "secret" in name or "token" in name:
        if "token" in name:
            val = base64.b16encode(os.urandom(16)).decode().lower()
        else:
            val = "$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi"
    elif "email" in name or "mail" in name:
        fn = random.choice(MOCK_FIRST_NAMES).lower()
        ln = random.choice(MOCK_LAST_NAMES).lower()
        suffix = f"_{uid_suffix}" if uid_suffix else f"_{random.randint(10, 99)}"
        val = f"{fn}.{ln}{row_idx}{suffix}@example.com"
    elif "username" in name or "user_name" in name:
        fn = random.choice(MOCK_FIRST_NAMES).lower()
        suffix = f"_{uid_suffix}" if uid_suffix else f"_{random.randint(100, 999)}"
        val = f"{fn}_{row_idx}{suffix}"
    elif name in ("first_name", "fname"):
        val = random.choice(MOCK_FIRST_NAMES)
    elif name in ("last_name", "lname", "surname"):
        val = random.choice(MOCK_LAST_NAMES)
    elif any(k in name for k in ("full_name", "author", "creator", "client", "customer", "contact")) or name == "name":
        base = f"{random.choice(MOCK_FIRST_NAMES)} {random.choice(MOCK_LAST_NAMES)}"
        val = f"{base} {uid_suffix}".strip() if is_unique else base
    elif any(k in name for k in ("phone", "mobile", "tel", "fax")):
        val = f"+1-555-{random.randint(100, 999)}-{random.randint(1000, 9999)}"
    elif any(k in name for k in ("address", "street")):
        val = f"{random.randint(100, 9999)} {random.choice(MOCK_WORDS)} Street"
    elif "city" in name:
        val = random.choice(MOCK_CITIES)
    elif "country" in name:
        val = random.choice(MOCK_COUNTRIES)
    elif any(k in name for k in ("zip", "postal", "postcode")):
        val = str(random.randint(10000, 99999))
    elif any(k in name for k in ("company", "organization", "org_name", "business")):
        base = random.choice(MOCK_COMPANIES)
        val = f"{base} {uid_suffix}".strip() if is_unique else base
    elif any(k in name for k in ("title", "subject", "headline", "topic")):
        base = f"{random.choice(MOCK_WORDS)} {random.choice(MOCK_WORDS)} Solution"
        val = f"{base} {uid_suffix}".strip() if is_unique else base
    elif "slug" in name:
        suffix = f"-{uid_suffix}" if uid_suffix else ""
        val = f"{random.choice(MOCK_WORDS).lower()}-{random.choice(MOCK_WORDS).lower()}-{row_idx}{suffix}"
    elif any(k in name for k in ("url", "website", "link", "domain")):
        suffix = f"-{uid_suffix}" if uid_suffix else ""
        val = f"https://{random.choice(MOCK_WORDS).lower()}{suffix}.example.com"
    elif any(k in name for k in ("avatar", "image", "photo", "thumbnail", "cover")):
        val = f"https://images.unsplash.com/photo-{random.randint(1500000, 1600000)}?w=400"
    elif name in ("status", "state"):
        val = random.choice(["active", "pending", "inactive", "archived"])
    elif name in ("role", "type"):
        val = random.choice(["admin", "editor", "member", "guest"])
    elif any(k in name for k in ("description", "content", "body", "bio", "notes", "summary", "details", "comment")) or "text" in raw_type:
        val = random.choice(MOCK_PHRASES)
    elif "ip" in name:
        val = f"192.168.{random.randint(1, 100)}.{random.randint(1, 254)}"
    elif any(k in name for k in ("price", "amount", "cost", "total", "balance", "fee", "rate")):
        val = round(random.uniform(5.0, 999.0), 2)
    elif any(k in name for k in ("quantity", "qty", "count", "views", "hits", "sort", "order", "position", "age")):
        val = random.randint(1, 100)
    elif "date" in raw_type or "date" in name:
        d = datetime.date.today() - datetime.timedelta(days=random.randint(1, 365))
        val = d.strftime("%Y-%m-%d")
    elif "time" in raw_type or "time" in name:
        val = f"{random.randint(8, 22):02d}:{random.randint(0, 59):02d}:00"
    elif "json" in raw_type:
        val = json.dumps({"tags": ["laravel", "fast"], "verified": True, "level": random.randint(1, 5)})
    elif "enum" in raw_type:
        opts = re.findall(r"'([^']*)'", raw_type)
        val = random.choice(opts) if opts else "default"
    elif "int" in raw_type:
        val = random.randint(1, 1000)
    elif any(t in raw_type for t in ("decimal", "numeric", "float", "double")):
        val = round(random.uniform(1.0, 100.0), 2)
    else:
        base = f"{random.choice(MOCK_WORDS)} {row_idx}"
        val = f"{base}_{uid_suffix}" if is_unique else base

    # Fallback for NOT NULL columns without default
    if val is None and not c.get("nullable") and c.get("default") is None:
        if "int" in raw_type:
            val = 0
        elif any(t in raw_type for t in ("decimal", "numeric", "float", "double")):
            val = 0.0
        elif "bool" in raw_type or raw_type == "tinyint(1)":
            val = False
        elif "date" in raw_type:
            val = datetime.date.today().strftime("%Y-%m-%d")
        elif "time" in raw_type:
            val = "00:00:00"
        elif "json" in raw_type:
            val = "{}"
        else:
            val = "default"

    # Enforce column length truncation if varchar/char
    if max_len is not None and isinstance(val, str) and len(val) > max_len:
        val = val[:max_len]

    return val


class DBError(Exception):
    pass


def _mysql():
    try:
        import pymysql
    except ImportError as exc:
        raise DBError("MySQL support needs PyMySQL: sudo apt install python3-pymysql (or pip install pymysql)") from exc
    return pymysql


def _pg():
    try:
        import psycopg2
        return "psycopg2", psycopg2
    except ImportError:
        pass
    try:
        import psycopg
        return "psycopg", psycopg
    except ImportError as exc:
        raise DBError("PostgreSQL support needs psycopg: sudo apt install python3-psycopg2 (or pip install psycopg[binary])") from exc


def cell(value):
    """A JSON-friendly value for the grid. Returns (value, truncated, editable)."""
    if value is None or isinstance(value, (bool, int)):
        return value, False, True
    if isinstance(value, float):
        return value if value == value and value not in (float("inf"), float("-inf")) else str(value), False, True
    if isinstance(value, decimal.Decimal):
        return str(value), False, True  # keep the exact digits
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat(sep=" ") if isinstance(value, datetime.datetime) else value.isoformat(), False, True
    if isinstance(value, datetime.timedelta):
        return str(value), False, True
    if isinstance(value, memoryview):
        value = value.tobytes()
    if isinstance(value, (bytes, bytearray)):
        try:
            text = bytes(value).decode("utf-8")
            if "\x00" not in text:
                value = text
            else:
                raise UnicodeDecodeError("utf-8", b"", 0, 1, "nul")
        except UnicodeDecodeError:
            return f"(binary · {len(value):,} bytes)", False, False
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    value = str(value)
    if len(value) > MAX_CELL:
        return value[:MAX_CELL], True, True
    return value, False, True


# ── SQL splitting (used by the editor and by imports) ────────────────────────

class SQLSplitter:
    """Splits SQL text into statements, chunk by chunk, so a big dump never has
    to be in memory at once. Knows quotes, comments, PostgreSQL $$ bodies and
    the mysql client's DELIMITER command."""

    COMMENT_ONLY = re.compile(r"(--[^\n]*|#[^\n]*|/\*(?!!).*?\*/|\s)+", re.S)

    def __init__(self, driver):
        self.driver = driver
        self.delim = ";"
        self.mode = None
        self.buf = []
        self.pending = ""
        self._build()

    def _build(self):
        parts = ["'", '"', "`", "--", r"/\*", re.escape(self.delim), r"^[ \t]*DELIMITER[ \t]+\S+[ \t]*$"]
        if self.driver in ("mysql", "mariadb"):
            parts.append("#")
        if self.driver == "pgsql":
            parts.append(r"\$[A-Za-z_0-9]*\$")
        self.token = re.compile("|".join(parts), re.M | re.I)

    def _emit(self, out, text):
        self.buf.append(text)
        stmt = "".join(self.buf).strip()
        self.buf = []
        if stmt and self.COMMENT_ONLY.fullmatch(stmt) is None:
            out.append(stmt)

    def _scan(self, text, final=False):
        out, i, start, n = [], 0, 0, len(text)
        while i < n:
            mode = self.mode
            if mode is None:
                m = self.token.search(text, i)
                if not m:
                    break
                tok = m.group(0)
                if tok == self.delim:
                    self._emit(out, text[start:m.start()])
                    i = start = m.end()
                elif tok.strip().upper().startswith("DELIMITER") and len(tok.split()) == 2:
                    self._emit(out, text[start:m.start()])
                    self.delim = tok.split()[1]
                    self._build()
                    i = start = m.end()
                elif tok in ("'", '"', "`"):
                    self.mode = tok
                    i = m.end()
                elif tok in ("--", "#"):
                    self.mode = "line"
                    i = m.end()
                elif tok == "/*":
                    self.mode = "block"
                    i = m.end()
                elif tok.startswith("$"):
                    self.mode = tok
                    i = m.end()
                else:
                    i = m.end()
            elif mode == "line":
                j = text.find("\n", i)
                if j < 0:
                    i = n
                    break
                self.mode, i = None, j + 1
            elif mode == "block":
                j = text.find("*/", i)
                if j < 0:
                    i = n
                    break
                self.mode, i = None, j + 2
            elif mode in ("'", '"', "`"):
                backslash = self.driver in ("mysql", "mariadb") and mode != "`"
                while True:
                    j = text.find(mode, i)
                    if backslash:
                        b = text.find("\\", i)
                        if b != -1 and (j == -1 or b < j):
                            i = b + 2
                            continue
                    if j < 0:
                        i = n
                        break
                    if j + 1 < n and text[j + 1] == mode:  # doubled quote
                        i = j + 2
                        continue
                    if j + 1 == n and not final:  # maybe half of a doubled quote: decide with the next chunk
                        i = j
                        self.buf.append(text[start:i])
                        return out, text[i:]
                    self.mode, i = None, j + 1
                    break
            else:  # $tag$
                j = text.find(mode, i)
                if j < 0:
                    i = n
                    break
                self.mode, i = None, j + len(mode)
        self.buf.append(text[start:])
        return out, ""

    def feed(self, chunk):
        text = self.pending + chunk
        cut = text.rfind("\n") + 1  # tokens never span lines, so scan whole lines only
        if cut == 0:
            self.pending = text
            return []
        out, carry = self._scan(text[:cut])
        self.pending = carry + text[cut:]
        return out

    def finish(self):
        out, _ = self._scan(self.pending, final=True)
        self.pending = ""
        stmt_out = []
        self._emit(stmt_out, "")
        return out + stmt_out


def split_sql(text, driver):
    splitter = SQLSplitter(driver)
    return splitter.feed(text) + splitter.finish()


# ── a live connection ────────────────────────────────────────────────────────

class Session:
    def __init__(self, spec, database):
        self.driver = spec["driver"]
        self.database = database or ""
        self.lock = threading.RLock()
        self.used = time.time()
        self.pg_flavor = ""
        host, port = spec.get("_host") or spec.get("host") or "127.0.0.1", int(spec.get("_port") or spec.get("port") or DEFAULT_PORTS.get(self.driver, 0) or 0)
        try:
            if self.driver in ("mysql", "mariadb"):
                pymysql = _mysql()
                self.raw = pymysql.connect(host=host, port=port, user=spec.get("user") or "root",
                                           password=spec.get("password") or "", database=database or None,
                                           charset="utf8mb4", connect_timeout=8, autocommit=True,
                                           read_timeout=None, local_infile=False)
            elif self.driver == "pgsql":
                self.pg_flavor, module = _pg()
                kwargs = dict(host=host, port=port, user=spec.get("user") or "postgres",
                              password=spec.get("password") or "", connect_timeout=8)
                if self.pg_flavor == "psycopg2":
                    self.raw = module.connect(dbname=database or spec.get("database") or "postgres", **kwargs)
                    self.raw.autocommit = True
                else:
                    self.raw = module.connect(dbname=database or spec.get("database") or "postgres", autocommit=True, **kwargs)
            elif self.driver == "sqlite":
                path = spec.get("file") or ""
                if not path or not Path(path).is_file():
                    raise DBError(f"SQLite file not found: {path or '(none)'}")
                self.raw = sqlite3.connect(path, timeout=8, isolation_level=None, check_same_thread=False)
                self.raw.execute("PRAGMA foreign_keys = ON")
            else:
                raise DBError(f"Unsupported database type: {self.driver}")
        except DBError:
            raise
        except Exception as exc:  # noqa: BLE001 — driver errors differ per library
            raise DBError(friendly_error(exc)) from exc

    # quoting
    def q(self, ident):
        if self.driver in ("mysql", "mariadb"):
            return "`" + ident.replace("`", "``") + "`"
        return '"' + ident.replace('"', '""') + '"'

    def table_ref(self, table):
        if self.driver == "pgsql" and "." in table:
            schema, name = table.split(".", 1)
            return f"{self.q(schema)}.{self.q(name)}"
        return self.q(table)

    @property
    def ph(self):
        return "?" if self.driver == "sqlite" else "%s"

    def cursor(self, server_side=False):
        """A server-side cursor streams rows instead of loading the whole table."""
        if server_side and self.driver in ("mysql", "mariadb"):
            return self.raw.cursor(_mysql().cursors.SSCursor)
        if server_side and self.driver == "pgsql":
            return self.raw.cursor(name=f"ld_{uuid.uuid4().hex[:8]}", withhold=True)
        return self.raw.cursor()

    @staticmethod
    def execute(cur, sql, params=()):
        # MySQL/PostgreSQL drivers %-format the SQL only when params are given,
        # so a literal % must be written %% exactly when params are passed.
        if params:
            cur.execute(sql, tuple(params))
        else:
            cur.execute(sql)

    def all(self, sql, params=()):
        with self.lock:
            self.used = time.time()
            cur = self.raw.cursor()
            try:
                self.execute(cur, sql, params)
                return cur.fetchall() if cur.description else []
            except Exception as exc:  # noqa: BLE001
                raise DBError(friendly_error(exc)) from exc
            finally:
                cur.close()

    def one(self, sql, params=()):
        rows = self.all(sql, params)
        return rows[0] if rows else None

    def run(self, sql, params=()):
        with self.lock:
            self.used = time.time()
            cur = self.raw.cursor()
            try:
                self.execute(cur, sql, params)
                return cur.rowcount
            except Exception as exc:  # noqa: BLE001
                raise DBError(friendly_error(exc)) from exc
            finally:
                cur.close()

    def alive(self):
        try:
            with self.lock:
                if self.driver in ("mysql", "mariadb"):
                    self.raw.ping(reconnect=False)
                else:
                    self.raw.cursor().execute("SELECT 1")
            return True
        except Exception:  # noqa: BLE001
            return False

    def close(self):
        try:
            self.raw.close()
        except Exception:  # noqa: BLE001
            pass


def friendly_error(exc):
    text = str(exc)
    args = getattr(exc, "args", ())
    if len(args) >= 2 and isinstance(args[0], int) and isinstance(args[1], str):
        code, message = args[0], args[1]  # PyMySQL: (1045, "Access denied ...")
        if code == 2003:
            return "Can't reach the database server — is MySQL/MariaDB running?"
        return f"{message} ({code})"
    return text.strip().splitlines()[0] if text.strip() else exc.__class__.__name__


# ── connection specs found in projects ───────────────────────────────────────

def spec_from_env(env, base_path=""):
    """Turn a project's .env values into a connection spec (or None)."""
    url = env.get("DATABASE_URL") or env.get("DB_URL") or ""
    if url:
        spec = spec_from_url(url, base_path)
        if spec:
            return spec
    driver = (env.get("DB_CONNECTION") or "").lower()
    if driver in ("mysql", "mariadb", "pgsql", "postgres", "postgresql"):
        driver = "pgsql" if driver.startswith("postg") else driver
        return {"driver": driver, "host": env.get("DB_HOST") or "127.0.0.1",
                "port": env.get("DB_PORT") or str(DEFAULT_PORTS[driver]),
                "user": env.get("DB_USERNAME") or env.get("DB_USER") or "",
                "password": env.get("DB_PASSWORD") or "", "database": env.get("DB_DATABASE") or ""}
    if driver == "sqlite":
        path = env.get("DB_DATABASE") or "database/database.sqlite"
        if base_path and not os.path.isabs(path):
            path = os.path.join(base_path, path)
        return {"driver": "sqlite", "file": path}
    if env.get("POSTGRES_DB") or env.get("POSTGRES_USER"):
        return {"driver": "pgsql", "host": env.get("POSTGRES_HOST") or "127.0.0.1", "port": env.get("POSTGRES_PORT") or "5432",
                "user": env.get("POSTGRES_USER") or "postgres", "password": env.get("POSTGRES_PASSWORD") or "",
                "database": env.get("POSTGRES_DB") or ""}
    if env.get("DB_NAME") and env.get("DB_HOST"):  # common in Node and Django projects
        port = env.get("DB_PORT") or ""
        driver = "pgsql" if port == "5432" or "postgres" in (env.get("DB_ENGINE") or env.get("DB_DIALECT") or "").lower() else "mysql"
        return {"driver": driver, "host": env["DB_HOST"], "port": port or str(DEFAULT_PORTS[driver]),
                "user": env.get("DB_USER") or env.get("DB_USERNAME") or "", "password": env.get("DB_PASSWORD") or env.get("DB_PASS") or "",
                "database": env["DB_NAME"]}
    return None


def spec_from_url(url, base_path=""):
    if url.startswith("file:"):  # Prisma SQLite: file:./dev.db, relative to prisma/
        path = url[5:]
        if base_path and not os.path.isabs(path):
            path = os.path.normpath(os.path.join(base_path, "prisma", path))
        return {"driver": "sqlite", "file": path}
    parsed = urlparse(url)
    scheme = parsed.scheme.split("+")[0].lower()
    if scheme in ("sqlite", "sqlite3"):
        # sqlite:///relative.db and sqlite:////absolute/path.db (SQLAlchemy, dj-database-url)
        path = unquote(url.split("://", 1)[1]) if "://" in url else ""
        path = path[1:] if path.startswith("/") else path
        if base_path and not os.path.isabs(path):
            path = os.path.join(base_path, path)
        return {"driver": "sqlite", "file": path}
    driver = {"mysql": "mysql", "mariadb": "mariadb", "postgres": "pgsql", "postgresql": "pgsql", "pgsql": "pgsql"}.get(scheme)
    if not driver:
        return None
    return {"driver": driver, "host": parsed.hostname or "127.0.0.1", "port": str(parsed.port or DEFAULT_PORTS[driver]),
            "user": unquote(parsed.username or ""), "password": unquote(parsed.password or ""),
            "database": unquote(parsed.path.lstrip("/").split("?")[0])}


def literal(value, driver):
    """A SQL literal for dumps."""
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return ("TRUE" if value else "FALSE") if driver == "pgsql" else ("1" if value else "0")
    if isinstance(value, (int, float, decimal.Decimal)):
        return str(value)
    if isinstance(value, memoryview):
        value = value.tobytes()
    if isinstance(value, (bytes, bytearray)):
        return f"'\\x{bytes(value).hex()}'::bytea" if driver == "pgsql" else f"X'{bytes(value).hex()}'"
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time, datetime.timedelta)):
        value = str(value)
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    text = str(value).replace("'", "''")
    if driver in ("mysql", "mariadb"):
        text = text.replace("\\", "\\\\").replace("\x00", "\\0")
    return f"'{text}'"


# ── manager ──────────────────────────────────────────────────────────────────

class DatabaseManager:
    def __init__(self, config_dir, remote, auto_connections, vault=None):
        """auto_connections() -> list of specs found in settings and projects."""
        self.file = Path(config_dir) / "connections.json"
        self.remote = remote
        self.auto_connections = auto_connections
        self.vault = vault
        self.ephemeral = {}  # id -> spec, e.g. a server site's database opened this session
        self.pool = {}       # (conn id, database) -> Session
        self.lock = threading.Lock()
        self._reaper = None

    def rekey_secrets(self, old_vault_key: bytes | None, new_vault_key: bytes | None):
        """Migrate connections.json when vault is enabled, disabled, or master password changed."""
        from cryptography.fernet import Fernet
        old_f = Fernet(old_vault_key) if old_vault_key else None
        new_f = Fernet(new_vault_key) if new_vault_key else None

        def decrypt_val(val):
            if not val or not isinstance(val, str):
                return val
            if val.startswith("enc:") and old_f:
                try:
                    return old_f.decrypt(val[4:].encode("ascii")).decode("utf-8")
                except Exception:
                    return val
            return val

        def encrypt_val(val):
            if not val or not isinstance(val, str):
                return val
            if new_f:
                token = new_f.encrypt(val.encode("utf-8")).decode("ascii")
                return f"enc:{token}"
            return val

        items = self.saved()
        changed = False
        secret_keys = ("password", "ssh_password", "ssh_passphrase")
        for item in items:
            for k in secret_keys:
                if k in item and item[k]:
                    plain = decrypt_val(item[k])
                    new_val = encrypt_val(plain)
                    if new_val != item[k]:
                        item[k] = new_val
                        changed = True

        if changed:
            self._write(items)

    # specs
    def saved(self):
        try:
            data = json.loads(self.file.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (OSError, ValueError):
            return []

    def _write(self, items):
        self.file.parent.mkdir(parents=True, exist_ok=True)
        self.file.write_text(json.dumps(items, indent=2), encoding="utf-8")
        private_file(self.file)

    def all_specs(self):
        specs = []
        for spec in self.auto_connections():
            specs.append(spec)
        specs += [dict(s, source="saved") for s in self.saved()]
        specs += list(self.ephemeral.values())
        return specs

    def spec(self, conn_id):
        for s in self.all_specs():
            if s["id"] == conn_id:
                spec_copy = dict(s)
                if self.vault and self.vault.is_enabled():
                    for k in ("password", "ssh_password", "ssh_passphrase"):
                        val = spec_copy.get(k)
                        if val and self.vault.is_encrypted(val):
                            if not self.vault.is_unlocked():
                                raise DBError("Unlock vault to connect")
                            try:
                                spec_copy[k] = self.vault.decrypt(val)
                            except Exception as exc:
                                raise DBError(f"Vault error: {exc}") from exc
                return spec_copy
        raise DBError("That connection no longer exists — refresh the list.")

    def list(self):
        out = []
        for spec in self.all_specs():
            item = {k: v for k, v in spec.items() if k not in ("password", "ssh_password", "ssh_passphrase") and not k.startswith("_")}
            item["has_password"] = bool(spec.get("password"))
            item["has_ssh_password"] = bool(spec.get("ssh_password"))
            item["has_ssh_passphrase"] = bool(spec.get("ssh_passphrase"))
            item["label"] = DRIVER_LABELS.get(spec["driver"], spec["driver"])
            item["open"] = any(key[0] == spec["id"] for key in self.pool)
            out.append(item)
        return out

    def clean_spec(self, p):
        driver = p.get("driver")
        if driver not in DRIVERS:
            raise DBError("Pick a database type")
        name = (p.get("name") or "").strip()
        if not name or len(name) > 60:
            raise DBError("Give the connection a name")
        spec = {"id": p.get("id") or f"c{uuid.uuid4().hex[:8]}", "name": name, "driver": driver, "color": p.get("color") or ""}
        if driver == "sqlite":
            path = os.path.expanduser((p.get("file") or "").strip())
            if not path:
                raise DBError("Choose the SQLite database file")
            spec["file"] = path
        else:
            port = str(p.get("port") or DEFAULT_PORTS[driver]).strip()
            if not port.isdigit() or not 0 < int(port) < 65536:
                raise DBError("Port must be a number between 1 and 65535")
            spec.update({"host": (p.get("host") or "127.0.0.1").strip(), "port": port,
                         "user": (p.get("user") or "").strip(), "database": (p.get("database") or "").strip()})
            password = p.get("password")
            if password is None and p.get("id"):  # unchanged: keep the stored one
                password = next((s.get("password", "") for s in self.saved() if s["id"] == p["id"]), "")
            spec["password"] = password or ""

            # Dedicated SSH configuration (Navicat style: custom SSH settings or saved server)
            use_ssh = bool(p.get("use_ssh") or p.get("ssh_host") or p.get("server"))
            spec["use_ssh"] = use_ssh
            if use_ssh:
                ssh_mode = p.get("ssh_mode") or ("server" if p.get("server") and not p.get("ssh_host") else "custom")
                spec["ssh_mode"] = ssh_mode
                if ssh_mode == "server":
                    spec["server"] = p.get("server") or ""
                    spec["ssh_host"] = ""
                    spec["ssh_port"] = ""
                    spec["ssh_user"] = ""
                    spec["ssh_auth"] = ""
                    spec["ssh_password"] = ""
                    spec["ssh_key"] = ""
                    spec["ssh_passphrase"] = ""
                else:
                    spec["server"] = ""
                    spec["ssh_host"] = (p.get("ssh_host") or "").strip()
                    ssh_port = str(p.get("ssh_port") or 22).strip()
                    if ssh_port and not ssh_port.isdigit():
                        raise DBError("SSH port must be a valid number")
                    spec["ssh_port"] = ssh_port or "22"
                    spec["ssh_user"] = (p.get("ssh_user") or "").strip()
                    spec["ssh_auth"] = p.get("ssh_auth") or "password"
                    spec["ssh_key"] = os.path.expanduser((p.get("ssh_key") or "").strip())

                    ssh_pass = p.get("ssh_password")
                    if ssh_pass is None and p.get("id"):
                        ssh_pass = next((s.get("ssh_password", "") for s in self.saved() if s["id"] == p["id"]), "")
                    spec["ssh_password"] = ssh_pass or ""

                    ssh_passphrase = p.get("ssh_passphrase")
                    if ssh_passphrase is None and p.get("id"):
                        ssh_passphrase = next((s.get("ssh_passphrase", "") for s in self.saved() if s["id"] == p["id"]), "")
                    spec["ssh_passphrase"] = ssh_passphrase or ""
            else:
                spec["use_ssh"] = False
                spec["server"] = ""
                spec["ssh_host"] = ""
                spec["ssh_port"] = ""
                spec["ssh_user"] = ""
                spec["ssh_auth"] = ""
                spec["ssh_password"] = ""
                spec["ssh_key"] = ""
                spec["ssh_passphrase"] = ""
        return spec

    def save(self, p):
        spec = self.clean_spec(p)
        if self.vault and self.vault.is_enabled():
            for k in ("password", "ssh_password", "ssh_passphrase"):
                val = spec.get(k)
                if val:
                    if not self.vault.is_unlocked():
                        raise DBError("Unlock vault to connect")
                    spec[k] = self.vault.encrypt(val)
        items = [s for s in self.saved() if s["id"] != spec["id"]] + [spec]
        items.sort(key=lambda s: s["name"].lower())
        self._write(items)
        self.close_connection(spec["id"])
        if self.remote:
            try:
                self.remote.disconnect(f"dbssh_{spec['id']}")
            except Exception:
                pass
        return {k: v for k, v in spec.items() if k not in ("password", "ssh_password", "ssh_passphrase")}

    def remove(self, conn_id):
        self.close_connection(conn_id)
        if self.remote:
            try:
                self.remote.disconnect(f"dbssh_{conn_id}")
            except Exception:
                pass
        self._write([s for s in self.saved() if s["id"] != conn_id])
        self.ephemeral.pop(conn_id, None)
        return True

    def test_ssh(self, p):
        if self.remote is None:
            raise DBError("SSH is not available in this environment")
        if p.get("ssh_mode") == "server" and p.get("server"):
            return self.remote.test_connection(p["server"])
        ssh_host = (p.get("ssh_host") or "").strip()
        if not ssh_host:
            raise DBError("Enter an SSH host or IP address")
        ssh_pass = p.get("ssh_password") or ""
        ssh_passphrase = p.get("ssh_passphrase") or ""
        if self.vault and self.vault.is_enabled():
            for v in (ssh_pass, ssh_passphrase):
                if v and self.vault.is_encrypted(v) and not self.vault.is_unlocked():
                    raise DBError("Unlock vault to connect")
            if ssh_pass:
                ssh_pass = self.vault.decrypt(ssh_pass)
            if ssh_passphrase:
                ssh_passphrase = self.vault.decrypt(ssh_passphrase)

        server = {
            "id": "adhoc_test",
            "host": ssh_host,
            "port": str(p.get("ssh_port") or 22).strip(),
            "user": (p.get("ssh_user") or "").strip(),
            "key": os.path.expanduser((p.get("ssh_key") or "").strip()),
            "password": ssh_pass,
            "passphrase": ssh_passphrase,
        }
        return self.remote.test_connection(server)

    def test(self, p):
        if p.get("id") and p.get("existing"):
            spec = self.spec(p["id"])
        else:
            spec = self.clean_spec(p)
            if self.vault and self.vault.is_enabled():
                for k in ("password", "ssh_password", "ssh_passphrase"):
                    val = spec.get(k)
                    if val and self.vault.is_encrypted(val):
                        if not self.vault.is_unlocked():
                            raise DBError("Unlock vault to connect")
                        spec[k] = self.vault.decrypt(val)
        started = time.time()
        ssh_info = None
        use_ssh = spec.get("use_ssh") or bool(spec.get("ssh_host")) or bool(spec.get("server"))
        if use_ssh and spec.get("driver") != "sqlite":
            ssh_started = time.time()
            try:
                resolved = self._resolve(spec)
                ssh_ms = round((time.time() - ssh_started) * 1000)
                ssh_host = spec.get("ssh_host") or spec.get("server")
                ssh_info = {"ok": True, "ms": ssh_ms, "host": ssh_host}
            except Exception as exc:
                raise DBError(f"SSH Tunnel Failed: {exc}") from exc
        else:
            resolved = self._resolve(spec)

        session = Session(resolved, spec.get("database") or "")
        try:
            version = self._version(session)
        except Exception as exc:
            if ssh_info:
                raise DBError(f"SSH Tunnel connected ({ssh_info['ms']}ms), but Database connection failed: {exc}") from exc
            raise
        finally:
            session.close()
        total_ms = round((time.time() - started) * 1000)
        res = {"ok": True, "version": version, "ms": total_ms}
        if ssh_info:
            res["ssh"] = ssh_info
        return res

    def add_ephemeral(self, spec):
        spec = dict(spec)
        spec.setdefault("id", f"e{uuid.uuid4().hex[:8]}")
        self.ephemeral[spec["id"]] = spec
        return spec["id"]

    # pool
    def _resolve(self, spec):
        """Point a spec that goes through an SSH server at the local end of a tunnel."""
        if spec.get("driver") == "sqlite":
            return spec
        use_ssh = spec.get("use_ssh") or bool(spec.get("ssh_host")) or bool(spec.get("server"))
        if not use_ssh:
            return spec
        if self.remote is None:
            raise DBError("SSH tunnels are not available")

        ssh_mode = spec.get("ssh_mode") or ("server" if spec.get("server") and not spec.get("ssh_host") else "custom")
        if ssh_mode == "server" and spec.get("server"):
            server_id = spec["server"]
        elif spec.get("ssh_host"):
            adhoc = {
                "id": f"dbssh_{spec.get('id', 'adhoc')}",
                "name": f"DB SSH ({spec['ssh_host']})",
                "host": spec["ssh_host"],
                "port": str(spec.get("ssh_port") or 22),
                "user": spec.get("ssh_user") or "",
                "key": spec.get("ssh_key") or "",
                "password": spec.get("ssh_password") or "",
                "passphrase": spec.get("ssh_passphrase") or "",
            }
            self.remote.register_adhoc(adhoc)
            server_id = adhoc["id"]
        elif spec.get("server"):
            server_id = spec["server"]
        else:
            return spec

        port = self.remote.forward(server_id, spec.get("host") or "127.0.0.1",
                                   int(spec.get("port") or DEFAULT_PORTS.get(spec["driver"], 3306)))
        return dict(spec, _host="127.0.0.1", _port=port)

    def session(self, conn_id, database=""):
        spec = self.spec(conn_id)
        if spec["driver"] == "sqlite":
            database = "main"
        key = (conn_id, database or "")
        with self.lock:
            session = self.pool.get(key)
        if session is not None:
            if time.time() - session.used < 30 or session.alive():
                session.used = time.time()
                return session
            self._drop(key)
        session = Session(self._resolve(spec), database if spec["driver"] != "sqlite" else "")
        with self.lock:
            old = self.pool.get(key)
            self.pool[key] = session
        if old is not None:
            old.close()
        self._start_reaper()
        return session

    def _drop(self, key):
        with self.lock:
            session = self.pool.pop(key, None)
        if session:
            session.close()

    def close_connection(self, conn_id):
        for key in [k for k in list(self.pool) if k[0] == conn_id]:
            self._drop(key)
        return True

    def close_all(self):
        for key in list(self.pool):
            self._drop(key)

    def _start_reaper(self):
        if self._reaper and self._reaper.is_alive():
            return

        def reap():
            while True:
                time.sleep(30)
                with self.lock:
                    idle = [k for k, s in self.pool.items() if time.time() - s.used > IDLE_SECONDS]
                for key in idle:
                    self._drop(key)
                if not self.pool:
                    return

        self._reaper = threading.Thread(target=reap, daemon=True)
        self._reaper.start()

    def _version(self, s):
        if s.driver == "sqlite":
            return "SQLite " + sqlite3.sqlite_version
        row = s.one("SELECT VERSION()" if s.driver != "pgsql" else "SHOW server_version")
        return str(row[0]) if row else ""

    # browsing
    def databases(self, conn_id):
        spec = self.spec(conn_id)
        if spec["driver"] == "sqlite":
            return {"databases": [{"name": "main", "system": False}], "version": "SQLite " + sqlite3.sqlite_version}
        s = self.session(conn_id, spec.get("database") or "")
        if s.driver == "pgsql":
            names = [r[0] for r in s.all("SELECT datname FROM pg_database WHERE NOT datistemplate ORDER BY datname")]
        else:
            names = [r[0] for r in s.all("SHOW DATABASES")]
        return {"databases": [{"name": n, "system": n in SYSTEM_DATABASES or (s.driver == "pgsql" and n == "postgres")} for n in names],
                "version": self._version(s), "default": spec.get("database") or ""}

    def tables(self, conn_id, database):
        s = self.session(conn_id, database)
        items = []
        if s.driver in ("mysql", "mariadb"):
            rows = s.all("SELECT TABLE_NAME, TABLE_TYPE, TABLE_ROWS, DATA_LENGTH + INDEX_LENGTH, ENGINE, TABLE_COMMENT "
                         "FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s ORDER BY TABLE_NAME", (database,))
            for name, kind, rows_est, size, engine, comment in rows:
                items.append({"name": name, "view": kind == "VIEW", "rows": rows_est, "size": size, "engine": engine or "", "comment": comment or ""})
        elif s.driver == "pgsql":
            rows = s.all("""
                SELECT n.nspname, c.relname, c.relkind, c.reltuples::bigint, pg_total_relation_size(c.oid)
                FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE c.relkind IN ('r', 'v', 'm', 'p') AND n.nspname NOT IN ('pg_catalog', 'information_schema')
                  AND n.nspname NOT LIKE 'pg_toast%'
                ORDER BY n.nspname <> 'public', n.nspname, c.relname""")
            for schema, name, kind, rows_est, size in rows:
                items.append({"name": name if schema == "public" else f"{schema}.{name}", "view": kind in ("v", "m"),
                              "rows": max(rows_est, 0) if rows_est is not None else None, "size": size, "engine": "", "comment": ""})
        else:
            for name, kind in s.all("SELECT name, type FROM sqlite_master WHERE type IN ('table', 'view') "
                                    "AND name NOT LIKE 'sqlite_%' ORDER BY name"):
                items.append({"name": name, "view": kind == "view", "rows": None, "size": None, "engine": "", "comment": ""})
        return items

    def structure(self, conn_id, database, table):
        s = self.session(conn_id, database)
        columns, indexes, fks, ddl = [], [], [], ""
        if s.driver in ("mysql", "mariadb"):
            for row in s.all("SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_KEY, EXTRA, COLUMN_COMMENT "
                             "FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s ORDER BY ORDINAL_POSITION",
                             (database, table)):
                columns.append({"name": row[0], "type": row[1], "nullable": row[2] == "YES", "default": row[3],
                                "pk": row[4] == "PRI", "auto": "auto_increment" in (row[5] or ""), "extra": row[5] or "", "comment": row[6] or ""})
            grouped = {}
            for name, column, non_unique, kind in s.all(
                    "SELECT INDEX_NAME, COLUMN_NAME, NON_UNIQUE, INDEX_TYPE FROM information_schema.STATISTICS "
                    "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s ORDER BY INDEX_NAME, SEQ_IN_INDEX", (database, table)):
                entry = grouped.setdefault(name, {"name": name, "columns": [], "unique": not non_unique, "primary": name == "PRIMARY", "type": kind})
                entry["columns"].append(column)
            indexes = list(grouped.values())
            fk_map = {}
            for name, column, ref_table, ref_column, on_update, on_delete in s.all(
                    "SELECT k.CONSTRAINT_NAME, k.COLUMN_NAME, k.REFERENCED_TABLE_NAME, k.REFERENCED_COLUMN_NAME, r.UPDATE_RULE, r.DELETE_RULE "
                    "FROM information_schema.KEY_COLUMN_USAGE k JOIN information_schema.REFERENTIAL_CONSTRAINTS r "
                    "ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME "
                    "WHERE k.TABLE_SCHEMA = %s AND k.TABLE_NAME = %s ORDER BY k.CONSTRAINT_NAME, k.ORDINAL_POSITION", (database, table)):
                entry = fk_map.setdefault(name, {"name": name, "columns": [], "ref_table": ref_table, "ref_columns": [],
                                                 "on_update": on_update, "on_delete": on_delete})
                entry["columns"].append(column)
                entry["ref_columns"].append(ref_column)
            fks = list(fk_map.values())
            row = s.one(f"SHOW CREATE TABLE {s.q(table)}")
            ddl = row[1] if row else ""
        elif s.driver == "pgsql":
            schema, name = table.split(".", 1) if "." in table else ("public", table)
            pks = {r[0] for r in s.all("""
                SELECT a.attname FROM pg_index i
                JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
                WHERE i.indrelid = %s::regclass AND i.indisprimary""", (s.table_ref(table),))}
            for col, kind, nullable, default, comment in s.all("""
                SELECT c.column_name,
                       CASE WHEN c.data_type IN ('character varying', 'character') AND c.character_maximum_length IS NOT NULL
                            THEN c.data_type || '(' || c.character_maximum_length || ')'
                            WHEN c.data_type = 'USER-DEFINED' THEN c.udt_name ELSE c.data_type END,
                       c.is_nullable, c.column_default,
                       col_description((quote_ident(c.table_schema) || '.' || quote_ident(c.table_name))::regclass, c.ordinal_position)
                FROM information_schema.columns c WHERE c.table_schema = %s AND c.table_name = %s ORDER BY c.ordinal_position""",
                    (schema, name)):
                columns.append({"name": col, "type": kind, "nullable": nullable == "YES", "default": default, "pk": col in pks,
                                "auto": bool(default and "nextval(" in default), "extra": "", "comment": comment or ""})
            for idx_name, definition in s.all("SELECT indexname, indexdef FROM pg_indexes WHERE schemaname = %s AND tablename = %s ORDER BY indexname", (schema, name)):
                cols = re.search(r"\((.*)\)", definition)
                indexes.append({"name": idx_name, "columns": [c.strip().strip('"') for c in cols.group(1).split(",")] if cols else [],
                                "unique": "UNIQUE" in definition, "primary": idx_name.endswith("_pkey"), "type": (re.search(r"USING (\w+)", definition) or [None, ""])[1]})
            fk_map = {}
            for fk_name, col, ref_table, ref_col, on_update, on_delete in s.all("""
                SELECT tc.constraint_name, kcu.column_name, ccu.table_name, ccu.column_name, rc.update_rule, rc.delete_rule
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
                JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = tc.constraint_name
                JOIN information_schema.referential_constraints rc ON rc.constraint_name = tc.constraint_name
                WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = %s AND tc.table_name = %s""", (schema, name)):
                entry = fk_map.setdefault(fk_name, {"name": fk_name, "columns": [], "ref_table": ref_table, "ref_columns": [],
                                                    "on_update": on_update, "on_delete": on_delete})
                entry["columns"].append(col)
                entry["ref_columns"].append(ref_col)
            fks = list(fk_map.values())
            ddl = self._pg_ddl(s, table, columns, indexes)
        else:
            for _cid, col, kind, notnull, default, pk in s.all(f"PRAGMA table_info({s.q(table)})"):
                columns.append({"name": col, "type": kind, "nullable": not notnull, "default": default, "pk": bool(pk),
                                "auto": bool(pk) and kind.upper() == "INTEGER", "extra": "", "comment": ""})
            for row in s.all(f"PRAGMA index_list({s.q(table)})"):
                idx_name, unique = row[1], bool(row[2])
                cols = [r[2] for r in s.all(f"PRAGMA index_info({s.q(idx_name)})")]
                indexes.append({"name": idx_name, "columns": cols, "unique": unique, "primary": len(row) > 3 and row[3] == "pk", "type": ""})
            fk_map = {}
            for row in s.all(f"PRAGMA foreign_key_list({s.q(table)})"):
                entry = fk_map.setdefault(row[0], {"name": f"fk_{row[0]}", "columns": [], "ref_table": row[2], "ref_columns": [],
                                                   "on_update": row[5], "on_delete": row[6]})
                entry["columns"].append(row[3])
                entry["ref_columns"].append(row[4])
            fks = list(fk_map.values())
            row = s.one("SELECT sql FROM sqlite_master WHERE name = ?", (table,))
            ddl = (row[0] or "") if row else ""
        return {"columns": columns, "indexes": indexes, "foreign_keys": fks, "ddl": ddl}

    def hologram(self, conn_id, database):
        s = self.session(conn_id, database)
        tables = []
        relations = []

        if s.driver in ("mysql", "mariadb"):
            table_rows = s.all(
                "SELECT TABLE_NAME, TABLE_ROWS, DATA_LENGTH + INDEX_LENGTH, TABLE_COMMENT "
                "FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_TYPE = 'BASE TABLE' "
                "ORDER BY TABLE_NAME", (database,))
            col_rows = s.all(
                "SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_KEY, EXTRA, COLUMN_COMMENT "
                "FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = %s "
                "ORDER BY TABLE_NAME, ORDINAL_POSITION", (database,))
            table_cols = {}
            for tname, cname, ctype, nullable, default, ckey, extra, comment in col_rows:
                table_cols.setdefault(tname, []).append({
                    "name": cname, "type": ctype, "pk": ckey == "PRI",
                    "nullable": nullable == "YES", "default": default,
                    "auto": "auto_increment" in (extra or ""), "comment": comment or ""
                })
            fk_rows = s.all(
                "SELECT k.TABLE_NAME, k.COLUMN_NAME, k.REFERENCED_TABLE_NAME, k.REFERENCED_COLUMN_NAME, "
                "k.CONSTRAINT_NAME, r.UPDATE_RULE, r.DELETE_RULE "
                "FROM information_schema.KEY_COLUMN_USAGE k "
                "JOIN information_schema.REFERENTIAL_CONSTRAINTS r "
                "ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME "
                "WHERE k.TABLE_SCHEMA = %s AND k.REFERENCED_TABLE_NAME IS NOT NULL "
                "ORDER BY k.TABLE_NAME, k.ORDINAL_POSITION", (database,))
            for tname, col, ref_table, ref_col, cname, on_upd, on_del in fk_rows:
                relations.append({
                    "id": f"{tname}_{col}_{ref_table}_{ref_col}",
                    "source_table": tname, "source_col": col,
                    "target_table": ref_table, "target_col": ref_col,
                    "constraint": cname, "on_update": on_upd or "", "on_delete": on_del or "",
                    "inferred": False
                })
            for tname, rows_est, size, comment in table_rows:
                tables.append({
                    "name": tname, "rows": rows_est, "size": size, "comment": comment or "",
                    "columns": table_cols.get(tname, [])
                })

        elif s.driver == "pgsql":
            schema = "public"
            table_rows = s.all("""
                SELECT c.relname, c.reltuples::bigint, pg_total_relation_size(c.oid),
                       obj_description(c.oid, 'pg_class')
                FROM pg_class c
                JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE c.relkind IN ('r', 'p') AND n.nspname = %s
                ORDER BY c.relname""", (schema,))
            pks_by_table = {}
            for tname, attname in s.all("""
                SELECT c.relname, a.attname
                FROM pg_index i
                JOIN pg_class c ON c.oid = i.indrelid
                JOIN pg_namespace n ON n.oid = c.relnamespace
                JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum = ANY(i.indkey)
                WHERE n.nspname = %s AND i.indisprimary""", (schema,)):
                pks_by_table.setdefault(tname, set()).add(attname)
            col_rows = s.all("""
                SELECT c.table_name, c.column_name,
                       CASE WHEN c.data_type IN ('character varying', 'character') AND c.character_maximum_length IS NOT NULL
                            THEN c.data_type || '(' || c.character_maximum_length || ')'
                            WHEN c.data_type = 'USER-DEFINED' THEN c.udt_name ELSE c.data_type END,
                       c.is_nullable, c.column_default
                FROM information_schema.columns c
                WHERE c.table_schema = %s
                ORDER BY c.table_name, c.ordinal_position""", (schema,))
            table_cols = {}
            for tname, col, kind, nullable, default in col_rows:
                table_cols.setdefault(tname, []).append({
                    "name": col, "type": kind, "pk": col in pks_by_table.get(tname, set()),
                    "nullable": nullable == "YES", "default": default,
                    "auto": bool(default and "nextval(" in default), "comment": ""
                })
            fk_rows = s.all("""
                SELECT tc.table_name, kcu.column_name, ccu.table_name AS ref_table, ccu.column_name AS ref_col,
                       tc.constraint_name, rc.update_rule, rc.delete_rule
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
                JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = tc.constraint_name
                JOIN information_schema.referential_constraints rc ON rc.constraint_name = tc.constraint_name
                WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = %s""", (schema,))
            for tname, col, ref_table, ref_col, cname, on_upd, on_del in fk_rows:
                relations.append({
                    "id": f"{tname}_{col}_{ref_table}_{ref_col}",
                    "source_table": tname, "source_col": col,
                    "target_table": ref_table, "target_col": ref_col,
                    "constraint": cname, "on_update": on_upd or "", "on_delete": on_del or "",
                    "inferred": False
                })
            for tname, rows_est, size, comment in table_rows:
                tables.append({
                    "name": tname, "rows": max(rows_est, 0) if rows_est is not None else None,
                    "size": size, "comment": comment or "", "columns": table_cols.get(tname, [])
                })

        else:
            for tname, in s.all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name"):
                cols = []
                for _cid, col, kind, notnull, default, pk in s.all(f"PRAGMA table_info({s.q(tname)})"):
                    cols.append({
                        "name": col, "type": kind, "pk": bool(pk),
                        "nullable": not notnull, "default": default,
                        "auto": bool(pk) and (kind or "").upper() == "INTEGER",
                        "comment": ""
                    })
                for row in s.all(f"PRAGMA foreign_key_list({s.q(tname)})"):
                    relations.append({
                        "id": f"{tname}_{row[3]}_{row[2]}_{row[4]}",
                        "source_table": tname, "source_col": row[3],
                        "target_table": row[2], "target_col": row[4],
                        "constraint": f"fk_{row[0]}", "on_update": row[5] or "", "on_delete": row[6] or "",
                        "inferred": False
                    })
                tables.append({
                    "name": tname, "rows": None, "size": None, "comment": "", "columns": cols
                })

        relations += self._infer_relations(tables, relations)
        return {"tables": tables, "relations": relations, "database": database}

    @staticmethod
    def _infer_relations(tables, explicit_relations):
        existing = {(r["source_table"], r["source_col"]) for r in explicit_relations}
        table_map = {t["name"].lower(): t for t in tables}
        inferred = []
        for t in tables:
            tname = t["name"]
            for col in t.get("columns", []):
                cname = col["name"]
                if (tname, cname) in existing:
                    continue
                if not cname.endswith("_id") or len(cname) <= 3:
                    continue
                prefix = cname[:-3].lower()
                candidates = [
                    prefix + "s",
                    prefix + "es",
                    prefix[:-1] + "ies" if prefix.endswith("y") else None,
                    prefix
                ]
                matches = [c for c in candidates if c and c in table_map and c != tname.lower()]
                if not matches:
                    continue
                target_table = table_map[matches[0]]["name"]
                target_cols = [c["name"] for c in table_map[matches[0]].get("columns", [])]
                target_col = "id" if "id" in target_cols else (f"{prefix}_id" if f"{prefix}_id" in target_cols else (target_cols[0] if target_cols else ""))
                if target_col:
                    inferred.append({
                        "id": f"inf_{tname}_{cname}_{target_table}_{target_col}",
                        "source_table": tname,
                        "source_col": cname,
                        "target_table": target_table,
                        "target_col": target_col,
                        "constraint": "inferred",
                        "on_update": "",
                        "on_delete": "",
                        "inferred": True
                    })
        return inferred

    def _pg_ddl(self, s, table, columns, indexes):
        lines = []
        for c in columns:
            line = f"  {s.q(c['name'])} {c['type']}"
            if c["default"] is not None:
                line += f" DEFAULT {c['default']}"
            if not c["nullable"]:
                line += " NOT NULL"
            lines.append(line)
        pks = [c["name"] for c in columns if c["pk"]]
        if pks:
            lines.append(f"  PRIMARY KEY ({', '.join(s.q(p) for p in pks)})")
        ddl = f"CREATE TABLE {s.table_ref(table)} (\n" + ",\n".join(lines) + "\n);"
        extra = [i for i in indexes if not i["primary"]]
        if extra:
            defs = s.all("SELECT indexdef FROM pg_indexes WHERE schemaname = %s AND tablename = %s AND indexname = ANY(%s)",
                         (*(table.split(".", 1) if "." in table else ("public", table)), [i["name"] for i in extra]))
            ddl += "\n" + "\n".join(d[0] + ";" for d in defs)
        return ddl

    # rows
    def _identity(self, s, table, columns):
        """How rows of this table are addressed when editing: its primary key,
        or the engine's physical row id (SQLite rowid, PostgreSQL ctid)."""
        pks = [c["name"] for c in columns if c["pk"]]
        if pks:
            return pks, ""
        if s.driver == "sqlite":
            return ["__rowid__"], "rowid AS __rowid__"
        if s.driver == "pgsql":
            return ["__ctid__"], "ctid::text AS __ctid__"
        return [], ""

    def _where(self, s, columns, filters, search, raw_where):
        clauses, params = [], []
        names = {c["name"] for c in columns}
        for f in filters or []:
            col = f.get("column")
            op = (f.get("op") or "=").upper().strip()
            value = f.get("value")
            if col not in names:
                continue
            ref = s.q(col)
            if op in ("IS NULL", "IS NOT NULL"):
                clauses.append(f"{ref} {op}")
            elif op in ("=", "!=", "<", ">", "<=", ">="):
                clauses.append(f"{ref} {op.replace('!=', '<>')} {s.ph}")
                params.append(value)
            elif op in ("CONTAINS", "LIKE"):
                like_op = "ILIKE" if s.driver == "pgsql" else "LIKE"
                clauses.append(f"{ref}{'::text' if s.driver == 'pgsql' else ''} {like_op} {s.ph}")
                params.append(f"%{value}%" if op == "CONTAINS" else value)
            elif op == "NOT LIKE":
                like_op = "NOT ILIKE" if s.driver == "pgsql" else "NOT LIKE"
                clauses.append(f"{ref}{'::text' if s.driver == 'pgsql' else ''} {like_op} {s.ph}")
                params.append(value)
            elif op == "STARTS_WITH":
                like_op = "ILIKE" if s.driver == "pgsql" else "LIKE"
                clauses.append(f"{ref}{'::text' if s.driver == 'pgsql' else ''} {like_op} {s.ph}")
                params.append(f"{value}%")
            elif op == "ENDS_WITH":
                like_op = "ILIKE" if s.driver == "pgsql" else "LIKE"
                clauses.append(f"{ref}{'::text' if s.driver == 'pgsql' else ''} {like_op} {s.ph}")
                params.append(f"%{value}")
            elif op in ("IN", "NOT IN"):
                if isinstance(value, str):
                    items = [x.strip() for x in value.split(",") if x.strip()]
                elif isinstance(value, (list, tuple)):
                    items = [str(x).strip() for x in value if str(x).strip()]
                else:
                    items = [str(value).strip()] if value is not None else []
                if items:
                    phs = ", ".join([s.ph] * len(items))
                    clauses.append(f"{ref} {op} ({phs})")
                    params.extend(items)
        if search:
            like = []
            for c in columns:
                like.append(f"{s.q(c['name'])}::text ILIKE {s.ph}" if s.driver == "pgsql" else f"{s.q(c['name'])} LIKE {s.ph}")
                params.append(f"%{search}%")
            if like:
                clauses.append("(" + " OR ".join(like) + ")")
        if raw_where and raw_where.strip():
            raw = raw_where.strip().rstrip(";")
            if params and s.driver != "sqlite":  # see Session.execute
                raw = raw.replace("%", "%%")
            clauses.append(f"({raw})")
        return (" WHERE " + " AND ".join(clauses)) if clauses else "", params

    def rows(self, conn_id, database, table, page=1, limit=100, sort="", direction="ASC",
             filters=None, search="", where=""):
        s = self.session(conn_id, database)
        info = self.structure(conn_id, database, table)
        columns = info["columns"]
        identity, extra_select = self._identity(s, table, columns)
        page, limit = max(1, int(page or 1)), min(1000, max(1, int(limit or 100)))
        where_sql, params = self._where(s, columns, filters, (search or "").strip(), where)
        order = ""
        if sort and sort in {c["name"] for c in columns}:
            order = f" ORDER BY {s.q(sort)} {'DESC' if str(direction).upper() == 'DESC' else 'ASC'}"
        elif identity and identity[0] not in ("__ctid__",):
            order = " ORDER BY " + ", ".join("rowid" if i == "__rowid__" else s.q(i) for i in identity)

        estimated = False
        total = None
        if not where_sql and s.driver in ("mysql", "mariadb"):
            row = s.one("SELECT TABLE_ROWS FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s", (database, table))
            if row and row[0] and row[0] > 200000:  # COUNT(*) on a big InnoDB table takes seconds
                total, estimated = int(row[0]), True
        if total is None:
            total = s.one(f"SELECT COUNT(*) FROM {s.table_ref(table)}{where_sql}", tuple(params))[0]

        select = f"SELECT {extra_select + ', ' if extra_select else ''}* FROM {s.table_ref(table)}{where_sql}{order} LIMIT {limit} OFFSET {(page - 1) * limit}"
        with s.lock:
            s.used = time.time()
            cur = s.raw.cursor()
            try:
                try:
                    s.execute(cur, select, params)
                except Exception:
                    if not extra_select or s.driver != "sqlite":
                        raise
                    identity, extra_select = [], ""  # WITHOUT ROWID table
                    s.execute(cur, select.replace("rowid AS __rowid__, ", ""), params)
                names = [d[0] for d in cur.description]
                raw_rows = cur.fetchall()
            finally:
                cur.close()

        rows, truncated, binary = [], [], set()
        for r_index, raw in enumerate(raw_rows):
            out = []
            for c_index, value in enumerate(raw):
                value, cut, editable = cell(value)
                if cut:
                    truncated.append([r_index, c_index])
                if not editable:
                    binary.add(names[c_index])
                out.append(value)
            rows.append(out)
        meta = {c["name"]: c for c in columns}
        return {
            "columns": [dict(meta.get(n, {"name": n, "type": "", "nullable": True, "pk": False, "auto": False}),
                             hidden=n in ("__rowid__", "__ctid__"), binary=n in binary) for n in names],
            "identity": identity, "rows": rows, "truncated": truncated,
            "total": total, "estimated": estimated, "page": page, "limit": limit,
            "pages": max(1, -(-total // limit)), "view": info["ddl"].upper().startswith("CREATE VIEW") if info["ddl"] else False,
        }

    def cell_value(self, conn_id, database, table, key, column):
        s = self.session(conn_id, database)
        where, params = self._key_where(s, key)
        row = s.one(f"SELECT {s.q(column)} FROM {s.table_ref(table)} WHERE {where} LIMIT 1", tuple(params))
        if row is None:
            raise DBError("Row not found — it may have changed. Refresh.")
        value = row[0]
        if isinstance(value, (bytes, bytearray, memoryview)):
            return {"value": f"(binary · {len(bytes(value)):,} bytes)", "binary": True}
        return {"value": cell(value)[0] if not isinstance(value, str) else value, "binary": False}

    def _key_where(self, s, key):
        if not key:
            raise DBError("Can't tell which row to change — refresh and try again.")
        parts, params = [], []
        for col, value in key.items():
            if col == "__rowid__":
                parts.append(f"rowid = {s.ph}")
            elif col == "__ctid__":
                parts.append(f"ctid = {s.ph}::tid")
            elif value is None:
                parts.append(f"{s.q(col)} IS NULL")
                continue
            else:
                parts.append(f"{s.q(col)} = {s.ph}")
            params.append(value)
        return " AND ".join(parts), params

    def apply(self, conn_id, database, table, changes):
        """Save edits from the grid in one transaction: {"updates": [{"key", "values"}], "inserts": [{...}], "deletes": [{"key"}]}."""
        s = self.session(conn_id, database)
        info = self.structure(conn_id, database, table)
        names = {c["name"] for c in info["columns"]}
        counts = {"updated": 0, "inserted": 0, "deleted": 0}

        def check(cols):
            bad = [c for c in cols if c not in names]
            if bad:
                raise DBError(f"Unknown column: {bad[0]}")

        with s.lock:
            s.used = time.time()
            cur = s.raw.cursor()
            try:
                cur.execute("BEGIN")
                # Tables without a key are matched on every column; LIMIT 1 then
                # keeps one edit from touching identical duplicate rows (MySQL).
                limit = " LIMIT 1" if s.driver in ("mysql", "mariadb") else ""
                for item in changes.get("deletes") or []:
                    where, params = self._key_where(s, item.get("key"))
                    s.execute(cur, f"DELETE FROM {s.table_ref(table)} WHERE {where}{limit if item.get('match_all') else ''}", params)
                    counts["deleted"] += cur.rowcount
                for item in changes.get("updates") or []:
                    values = item.get("values") or {}
                    if not values:
                        continue
                    check(values)
                    where, params = self._key_where(s, item.get("key"))
                    sets = ", ".join(f"{s.q(c)} = {s.ph}" for c in values)
                    s.execute(cur, f"UPDATE {s.table_ref(table)} SET {sets} WHERE {where}{limit if item.get('match_all') else ''}",
                              (*values.values(), *params))
                    if cur.rowcount == 0:
                        raise DBError("A row you edited no longer matches — someone changed it. Refresh and try again.")
                    counts["updated"] += cur.rowcount
                for values in changes.get("inserts") or []:
                    values = dict(values)
                    check(values)
                    if values:
                        cols = ", ".join(s.q(c) for c in values)
                        marks = ", ".join(s.ph for _ in values)
                        s.execute(cur, f"INSERT INTO {s.table_ref(table)} ({cols}) VALUES ({marks})", tuple(values.values()))
                    else:
                        cur.execute(f"INSERT INTO {s.table_ref(table)} DEFAULT VALUES" if s.driver != "mysql" and s.driver != "mariadb"
                                    else f"INSERT INTO {s.table_ref(table)} () VALUES ()")
                    counts["inserted"] += 1
                cur.execute("COMMIT")
            except DBError:
                cur.execute("ROLLBACK")
                raise
            except Exception as exc:  # noqa: BLE001
                try:
                    cur.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                raise DBError(friendly_error(exc)) from exc
            finally:
                cur.close()
        return counts

    # SQL editor
    def query(self, conn_id, database, sql):
        s = self.session(conn_id, database)
        statements = split_sql(sql or "", s.driver)
        if not statements:
            raise DBError("Write a query first")
        results = []
        with s.lock:
            for index, statement in enumerate(statements):
                s.used = time.time()
                started = time.time()
                cur = s.raw.cursor()
                try:
                    cur.execute(statement)
                    ms = round((time.time() - started) * 1000, 1)
                    short = re.sub(r"\s+", " ", statement)[:120]
                    if cur.description:
                        names = [d[0] for d in cur.description]
                        fetched = cur.fetchmany(MAX_QUERY_ROWS + 1)
                        more = len(fetched) > MAX_QUERY_ROWS
                        rows = [[cell(v)[0] for v in r] for r in fetched[:MAX_QUERY_ROWS]]
                        results.append({"sql": short, "columns": names, "rows": rows, "more": more, "ms": ms})
                    else:
                        results.append({"sql": short, "affected": cur.rowcount, "ms": ms})
                except Exception as exc:  # noqa: BLE001
                    results.append({"sql": re.sub(r"\s+", " ", statement)[:120], "error": friendly_error(exc), "index": index})
                    break
                finally:
                    cur.close()
                with_rows = [r for r in results if r.get("rows")]
                if len(with_rows) > 5:  # a script of many SELECTs: keep the last five grids
                    with_rows[0]["rows"], with_rows[0]["dropped"] = [], True
        return {"results": results, "count": len(statements)}

    # databases & tables
    def create_database(self, conn_id, name, charset="utf8mb4", collation="utf8mb4_unicode_ci"):
        if not NAME_RE.fullmatch(name or ""):
            raise DBError("Use letters, numbers, - and _ for the database name")
        spec = self.spec(conn_id)
        s = self.session(conn_id, spec.get("database") or "")
        if s.driver == "sqlite":
            raise DBError("A SQLite connection is a single database file")
        if s.driver == "pgsql":
            s.run(f"CREATE DATABASE {s.q(name)}")
        else:
            if not re.fullmatch(r"[a-z0-9_]+", charset or "") or not re.fullmatch(r"[a-z0-9_]+", collation or ""):
                raise DBError("Invalid charset")
            s.run(f"CREATE DATABASE {s.q(name)} CHARACTER SET {charset} COLLATE {collation}")
        return True

    def drop_database(self, conn_id, name):
        if name in SYSTEM_DATABASES:
            raise DBError("System databases can't be dropped")
        spec = self.spec(conn_id)
        for key in [k for k in list(self.pool) if k == (conn_id, name)]:
            self._drop(key)
        s = self.session(conn_id, spec.get("database") if spec.get("database") != name else "")
        if s.driver == "sqlite":
            raise DBError("Delete the SQLite file instead")
        s.run(f"DROP DATABASE {s.q(name)}")
        return True

    def table_op(self, conn_id, database, table, op, target=""):
        s = self.session(conn_id, database)
        ref = s.table_ref(table)
        if op == "truncate":
            s.run(f"DELETE FROM {ref}" if s.driver == "sqlite" else f"TRUNCATE TABLE {ref}")
        elif op == "drop":
            is_view = False
            for t in self.tables(conn_id, database):
                if t["name"] == table:
                    is_view = t["view"]
            s.run(f"DROP {'VIEW' if is_view else 'TABLE'} {ref}")
        elif op == "rename":
            if not NAME_RE.fullmatch(target or ""):
                raise DBError("Invalid table name")
            if s.driver in ("mysql", "mariadb"):
                s.run(f"RENAME TABLE {ref} TO {s.q(target)}")
            else:
                s.run(f"ALTER TABLE {ref} RENAME TO {s.q(target.split('.')[-1])}")
        else:
            raise DBError("Unknown table operation")
        return True

    # export & import (streamed)
    def export(self, conn_id, database, tables, fmt, path, progress):
        s = self.session(conn_id, database)
        if not tables:
            tables = [t["name"] for t in self.tables(conn_id, database) if not t["view"]]
        if fmt in ("csv", "json") and len(tables) != 1:
            raise DBError("CSV and JSON export one table at a time")
        written = 0
        with open(path, "w", encoding="utf-8", newline="") as out, s.lock:
            if fmt == "sql":
                out.write(f"-- Laravel Dev export of {database} ({DRIVER_LABELS[s.driver]})\n-- {datetime.datetime.now():%Y-%m-%d %H:%M}\n\n")
                if s.driver in ("mysql", "mariadb"):
                    out.write("SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n")
            for table in tables:
                info = self.structure(conn_id, database, table)
                columns = [c["name"] for c in info["columns"]]
                if fmt == "sql":
                    ddl = info["ddl"]
                    out.write(f"-- Table {table}\nDROP TABLE IF EXISTS {s.table_ref(table)};\n{ddl.rstrip(';')};\n\n")
                    col_list = ", ".join(s.q(c) for c in columns)
                cur = s.cursor(server_side=True)
                try:
                    cur.execute(f"SELECT * FROM {s.table_ref(table)}")
                    if fmt == "csv":
                        import csv
                        writer = csv.writer(out)
                        writer.writerow(columns)
                    elif fmt == "json":
                        out.write("[\n")
                    first, batch = True, []
                    while True:
                        chunk = cur.fetchmany(500)
                        if not chunk:
                            break
                        for row in chunk:
                            written += 1
                            if fmt == "csv":
                                writer.writerow(["" if v is None else (cell(v)[0] if not isinstance(v, str) else v) for v in row])
                            elif fmt == "json":
                                record = {c: (v if isinstance(v, (str, int, float, bool)) or v is None else
                                              base64.b64encode(bytes(v)).decode() if isinstance(v, (bytes, bytearray, memoryview)) else str(v))
                                          for c, v in zip(columns, row)}
                                out.write(("" if first else ",\n") + "  " + json.dumps(record, ensure_ascii=False))
                                first = False
                            else:
                                batch.append("(" + ", ".join(literal(v, s.driver) for v in row) + ")")
                                if len(batch) >= 100:
                                    out.write(f"INSERT INTO {s.table_ref(table)} ({col_list}) VALUES\n" + ",\n".join(batch) + ";\n")
                                    batch = []
                        progress(written)
                    if fmt == "sql" and batch:
                        out.write(f"INSERT INTO {s.table_ref(table)} ({col_list}) VALUES\n" + ",\n".join(batch) + ";\n")
                    if fmt == "json":
                        out.write("\n]\n")
                    if fmt == "sql":
                        out.write("\n")
                finally:
                    cur.close()
            if fmt == "sql" and s.driver in ("mysql", "mariadb"):
                out.write("SET FOREIGN_KEY_CHECKS = 1;\n")
            s.used = time.time()
        return written

    def import_sql(self, conn_id, database, path, progress):
        s = self.session(conn_id, database)
        splitter = SQLSplitter(s.driver)
        done = 0
        line_hint = ""
        with open(path, encoding="utf-8", errors="replace") as handle, s.lock:
            cur = s.raw.cursor()
            try:
                while True:
                    chunk = handle.read(1 << 20)
                    statements = splitter.feed(chunk) if chunk else splitter.finish()
                    for statement in statements:
                        st_strip = statement.strip()
                        # Skip MariaDB 11 sandbox header comment which causes syntax errors in MySQL
                        if st_strip.startswith("/*M!999999"):
                            continue
                        line_hint = re.sub(r"\s+", " ", statement)[:100]
                        cur.execute(statement)
                        done += 1
                        if done % 200 == 0:
                            s.used = time.time()
                            progress(done)
                    if not chunk:
                        break
            except Exception as exc:  # noqa: BLE001
                raise DBError(f"Statement {done + 1} failed: {friendly_error(exc)}\n{line_hint}") from exc
            finally:
                cur.close()
        progress(done)
        return done

    # ── Laravel code & seeder generation (Phase 1) ───────────────────────────
    def generate_migration(self, conn_id, database, table):
        info = self.structure(conn_id, database, table)
        columns = info.get("columns", [])
        fks = info.get("foreign_keys", [])
        indexes = info.get("indexes", [])

        unique_single_cols = set()
        for idx in indexes:
            if idx.get("unique") and not idx.get("primary") and len(idx.get("columns", [])) == 1:
                unique_single_cols.add(idx["columns"][0])

        col_names = {c["name"] for c in columns}
        has_timestamps = "created_at" in col_names and "updated_at" in col_names
        has_soft_deletes = "deleted_at" in col_names

        fk_map = {}
        for fk in fks:
            for cname in fk.get("columns", []):
                fk_map[cname] = fk

        if not fk_map:
            try:
                holo = self.hologram(conn_id, database)
                for rel in holo.get("relations", []):
                    if rel.get("source_table") == table:
                        fk_map[rel["source_col"]] = {
                            "ref_table": rel["target_table"],
                            "ref_columns": [rel["target_col"]],
                            "on_delete": rel.get("on_delete", ""),
                        }
            except Exception:
                pass

        lines = []
        for c in columns:
            name = c["name"]
            if has_timestamps and name in ("created_at", "updated_at"):
                continue
            if has_soft_deletes and name == "deleted_at":
                continue

            raw_type = (c.get("type") or "").strip().lower()

            if c.get("pk") and (name == "id" or (c.get("auto") and "int" in raw_type)):
                if name == "id":
                    lines.append("$table->id();")
                else:
                    lines.append(f"$table->id('{name}');")
                continue
            elif c.get("pk") and "uuid" in raw_type:
                lines.append(f"$table->uuid('{name}')->primary();")
                continue

            if name in fk_map:
                fk = fk_map[name]
                ref_tbl = fk.get("ref_table")
                on_del = (fk.get("on_delete") or "").lower()
                call = f"$table->foreignId('{name}')"
                if c.get("nullable"):
                    call += "->nullable()"
                call += f"->constrained('{ref_tbl}')"
                if on_del == "cascade":
                    call += "->cascadeOnDelete()"
                elif on_del in ("set null", "null"):
                    call += "->nullOnDelete()"
                lines.append(call + ";")
                continue

            line = _column_blueprint(c, unique_single_cols)
            lines.append(line + ";")

        if has_timestamps:
            lines.append("$table->timestamps();")
        if has_soft_deletes:
            lines.append("$table->softDeletes();")

        body = "\n".join("            " + line for line in lines)
        model_name = _to_pascal(table)
        file_name = f"create_{table}_table.php"
        timestamp = datetime.datetime.now().strftime("%Y_%m_%d_%H%M%S")

        php_code = f"""<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{{
    /**
     * Run the migrations.
     */
    public function up(): void
    {{
        Schema::create('{table}', function (Blueprint $table) {{
{body}
        }});
    }}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {{
        Schema::dropIfExists('{table}');
    }}
}};
"""
        return {
            "table": table,
            "model": model_name,
            "file_name": f"{timestamp}_{file_name}",
            "code": php_code
        }

    def generate_model(self, conn_id, database, table):
        info = self.structure(conn_id, database, table)
        columns = info.get("columns", [])
        fks = info.get("foreign_keys", [])

        model_name = _to_pascal(table)
        col_names = {c["name"] for c in columns}
        has_timestamps = "created_at" in col_names and "updated_at" in col_names
        has_soft_deletes = "deleted_at" in col_names

        pk_col = next((c["name"] for c in columns if c.get("pk")), "id")
        pk_is_int = True
        for c in columns:
            if c["name"] == pk_col:
                pk_is_int = "int" in (c.get("type") or "").lower()

        fillable_cols = [c["name"] for c in columns if not c.get("pk") and c["name"] not in ("created_at", "updated_at", "deleted_at")]

        casts = {}
        for c in columns:
            name = c["name"]
            if name in ("id", "created_at", "updated_at", "deleted_at"):
                continue
            raw_type = (c.get("type") or "").lower()
            if "bool" in raw_type or raw_type == "tinyint(1)":
                casts[name] = "boolean"
            elif "json" in raw_type:
                casts[name] = "array"
            elif "date" in raw_type and "datetime" not in raw_type:
                casts[name] = "date"
            elif "datetime" in raw_type or "timestamp" in raw_type:
                casts[name] = "datetime"
            elif "decimal" in raw_type or "numeric" in raw_type:
                dec_match = re.search(r"\((\d+),\s*(\d+)\)", raw_type)
                precision = dec_match.group(2) if dec_match else "2"
                casts[name] = f"decimal:{precision}"

        relations = []
        belongs_to_seen = set()

        for fk in fks:
            ref_table = fk.get("ref_table")
            for cname in fk.get("columns", []):
                if not ref_table or cname in belongs_to_seen:
                    continue
                ref_model = _to_pascal(ref_table)
                method = cname[:-3] if cname.endswith("_id") and len(cname) > 3 else _to_camel(_singularize(ref_table))
                belongs_to_seen.add(cname)
                relations.append(f"""    /**
     * Get the {method} that owns the {model_name}.
     */
    public function {method}(): \\Illuminate\\Database\\Eloquent\\Relations\\BelongsTo
    {{
        return $this->belongsTo({ref_model}::class, '{cname}');
    }}""")

        holo = None
        try:
            holo = self.hologram(conn_id, database)
        except Exception:
            pass

        if holo:
            for rel in holo.get("relations", []):
                if rel.get("source_table") == table and rel.get("source_col") not in belongs_to_seen:
                    cname = rel["source_col"]
                    target_table = rel["target_table"]
                    ref_model = _to_pascal(target_table)
                    method = cname[:-3] if cname.endswith("_id") and len(cname) > 3 else _to_camel(_singularize(target_table))
                    belongs_to_seen.add(cname)
                    relations.append(f"""    /**
     * Get the {method} that owns the {model_name}.
     */
    public function {method}(): \\Illuminate\\Database\\Eloquent\\Relations\\BelongsTo
    {{
        return $this->belongsTo({ref_model}::class, '{cname}');
    }}""")

                if rel.get("target_table") == table:
                    src_table = rel["source_table"]
                    src_col = rel["source_col"]
                    src_model = _to_pascal(src_table)
                    method = _to_camel(src_table)
                    relations.append(f"""    /**
     * Get all {src_table} for the {model_name}.
     */
    public function {method}(): \\Illuminate\\Database\\Eloquent\\Relations\\HasMany
    {{
        return $this->hasMany({src_model}::class, '{src_col}');
    }}""")

        opt_table = f"    protected $table = '{table}';\n"
        opt_pk = f"    protected $primaryKey = '{pk_col}';\n" if pk_col != "id" else ""
        opt_incr = "    public $incrementing = false;\n" if not pk_is_int else ""
        opt_timestamps = "    public $timestamps = false;\n" if not has_timestamps else ""

        soft_deletes_import = "use Illuminate\\Database\\Eloquent\\SoftDeletes;\n" if has_soft_deletes else ""
        soft_deletes_trait = ", SoftDeletes" if has_soft_deletes else ""

        fillable_str = "\n".join(f"        '{col}'," for col in fillable_cols)
        casts_str = "\n".join(f"        '{k}' => '{v}'," for k, v in casts.items())
        relations_str = ("\n\n" + "\n\n".join(relations)) if relations else ""

        casts_block = f"""    protected $casts = [
{casts_str}
    ];""" if casts else "    protected $casts = [];"

        php_code = f"""<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;
{soft_deletes_import}
class {model_name} extends Model
{{
    use HasFactory{soft_deletes_trait};

{opt_table}{opt_pk}{opt_incr}{opt_timestamps}    protected $fillable = [
{fillable_str}
    ];

{casts_block}{relations_str}
}}
"""
        return {
            "table": table,
            "model": model_name,
            "file_name": f"{model_name}.php",
            "code": php_code
        }

    def seed_data(self, conn_id, database, table, count=25, mode="code"):
        count = max(1, min(int(count or 25), 5000))
        s = self.session(conn_id, database)
        info = self.structure(conn_id, database, table)
        columns = info.get("columns", [])
        fks = info.get("foreign_keys", [])

        unique_cols = set()
        for idx in info.get("indexes", []):
            cols = idx.get("columns", [])
            if idx.get("unique") and len(cols) == 1:
                unique_cols.add(cols[0])

        fk_pool = {}
        for fk in fks:
            ref_table = fk.get("ref_table")
            for cname in fk.get("columns", []):
                if not ref_table or cname in fk_pool:
                    continue
                try:
                    ref_col = fk.get("ref_columns", ["id"])[0] if fk.get("ref_columns") else "id"
                    rows = s.all(f"SELECT {s.q(ref_col)} FROM {s.table_ref(ref_table)} LIMIT 30")
                    fk_pool[cname] = [r[0] for r in rows if r[0] is not None]
                except Exception:
                    fk_pool[cname] = [1]
                if not fk_pool[cname]:
                    fk_pool[cname] = [1]

        for c in columns:
            cname = c["name"]
            if cname.endswith("_id") and cname not in fk_pool and len(cname) > 3:
                prefix = cname[:-3]
                for cand in (prefix + "s", prefix + "es", prefix[:-1] + "ies", prefix):
                    try:
                        rows = s.all(f"SELECT {s.q('id')} FROM {s.table_ref(cand)} LIMIT 30")
                        if rows:
                            fk_pool[cname] = [r[0] for r in rows if r[0] is not None]
                            break
                    except Exception:
                        pass
                if cname not in fk_pool or not fk_pool[cname]:
                    fk_pool[cname] = [1]

        model_name = _to_pascal(table)

        if mode == "code":
            sample_count = min(count, 50)
            records = []
            for i in range(sample_count):
                rec = {}
                for c in columns:
                    val = _generate_mock_value(c, fk_pool, i + 1, is_unique=(c["name"] in unique_cols))
                    if val is not None:
                        rec[c["name"]] = val
                records.append(rec)

            rec_blocks = []
            for r in records:
                lines = ["            ["]
                for k, v in r.items():
                    if isinstance(v, bool):
                        v_str = "true" if v else "false"
                    elif isinstance(v, (int, float)):
                        v_str = str(v)
                    else:
                        esc_v = str(v).replace("\\", "\\\\").replace("'", "\\'")
                        v_str = f"'{esc_v}'"
                    lines.append(f"                '{k}' => {v_str},")
                lines.append("            ],")
                rec_blocks.append("\n".join(lines))

            rec_str = "\n".join(rec_blocks)
            seeder_name = f"{model_name}Seeder"
            php_code = f"""<?php

namespace Database\\Seeders;

use Illuminate\\Database\\Seeder;
use Illuminate\\Support\\Facades\\DB;

class {seeder_name} extends Seeder
{{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {{
        DB::table('{table}')->insert([
{rec_str}
        ]);
    }}
}}
"""
            return {
                "table": table,
                "model": model_name,
                "file_name": f"{seeder_name}.php",
                "code": php_code,
                "count": sample_count
            }

        # Direct database insertion
        t0 = time.time()
        insertable_cols = [
            c for c in columns
            if not (c.get("pk") and (c.get("auto") or "int" in (c.get("type") or "").lower() or c["name"] == "id"))
        ]
        if not insertable_cols:
            raise DBError(f"No insertable columns found in {table}")

        col_clause = ", ".join(s.q(c["name"]) for c in insertable_cols)
        placeholders = ", ".join(s.ph for _ in insertable_cols)
        sql = f"INSERT INTO {s.table_ref(table)} ({col_clause}) VALUES ({placeholders})"

        inserted = 0
        batch_size = 50
        with s.lock:
            cur = s.raw.cursor()
            try:
                while inserted < count:
                    batch_len = min(batch_size, count - inserted)
                    batch_data = []
                    for _ in range(batch_len):
                        row_idx = inserted + len(batch_data) + 1
                        vals = []
                        for c in insertable_cols:
                            vals.append(_generate_mock_value(c, fk_pool, row_idx, is_unique=(c["name"] in unique_cols)))
                        batch_data.append(tuple(vals))

                    cur.executemany(sql, batch_data)
                    inserted += batch_len
                try:
                    s.raw.commit()
                except Exception:
                    pass
            except Exception as exc:
                try:
                    s.raw.rollback()
                except Exception:
                    pass
                raise DBError(f"Failed to seed data: {friendly_error(exc)}") from exc
            finally:
                cur.close()
            s.used = time.time()

        elapsed_ms = round((time.time() - t0) * 1000, 1)
        return {
            "table": table,
            "inserted": inserted,
            "ms": elapsed_ms
        }

    def save_code_to_project(self, site_name_or_path, file_type, file_name, code, overwrite=False):
        import sites

        if not site_name_or_path:
            raise DBError("Choose a project to save code to.")

        target_root = None
        try:
            site = sites.find_site(site_name_or_path)
            target_root = Path(site["path"]).resolve()
        except Exception:
            p = Path(site_name_or_path).expanduser().resolve()
            if p.is_dir():
                target_root = p

        if not target_root or not target_root.is_dir():
            raise DBError("Choose a valid Laravel project directory to save code.")

        # Sanitize and validate file name
        clean_name = (file_name or "").strip()
        if not re.match(r"^[A-Za-z0-9_]+\.php$", clean_name):
            raise DBError("Invalid file name. Must only contain letters, numbers, underscores and end with .php (e.g. User.php).")

        if file_type == "model":
            dest_dir = (target_root / "app" / "Models").resolve()
            target_file = (dest_dir / clean_name).resolve()
            if not target_file.is_relative_to(dest_dir):
                raise DBError("Invalid file path.")
            if target_file.is_file() and not overwrite:
                return {
                    "ok": False,
                    "exists": True,
                    "path": str(target_file),
                    "file_name": target_file.name,
                    "message": f"Model {clean_name} already exists in app/Models.",
                }
            dest_dir.mkdir(parents=True, exist_ok=True)

        elif file_type == "migration":
            dest_dir = (target_root / "database" / "migrations").resolve()
            dest_dir.mkdir(parents=True, exist_ok=True)
            # Check if a migration file for this table already exists
            pattern_suffix = clean_name
            if re.match(r"^\d{4}_\d{2}_\d{2}_\d{6}_", clean_name):
                pattern_suffix = clean_name.split("_", 4)[-1]
            existing_migrations = [m.name for m in dest_dir.glob(f"*{pattern_suffix}")]
            if existing_migrations and not overwrite:
                return {
                    "ok": False,
                    "exists": True,
                    "existing_migration": existing_migrations[0],
                    "path": str(dest_dir / existing_migrations[0]),
                    "file_name": clean_name,
                    "message": f"A migration for this table already exists: {existing_migrations[0]}",
                }

            if not re.match(r"^\d{4}_\d{2}_\d{2}_\d{6}_", clean_name):
                ts = datetime.datetime.now().strftime("%Y_%m_%d_%H%M%S")
                target_file = (dest_dir / f"{ts}_{clean_name}").resolve()
            else:
                target_file = (dest_dir / clean_name).resolve()

            if not target_file.is_relative_to(dest_dir):
                raise DBError("Invalid file path.")

        elif file_type == "seeder":
            dest_dir = (target_root / "database" / "seeders").resolve()
            target_file = (dest_dir / clean_name).resolve()
            if not target_file.is_relative_to(dest_dir):
                raise DBError("Invalid file path.")
            if target_file.is_file() and not overwrite:
                return {
                    "ok": False,
                    "exists": True,
                    "path": str(target_file),
                    "file_name": target_file.name,
                    "message": f"Seeder {clean_name} already exists in database/seeders.",
                }
            dest_dir.mkdir(parents=True, exist_ok=True)
        else:
            raise DBError(f"Unsupported file type: {file_type}")

        target_file.write_text(code, encoding="utf-8")
        return {
            "ok": True,
            "path": str(target_file),
            "file_name": target_file.name,
            "file_type": file_type,
            "site": target_root.name
        }

    # ── Phase 2: Schema Diff & Visual EXPLAIN ────────────────────────────────
    def explain_query(self, conn_id, database, sql):
        sql = (sql or "").strip().rstrip(";")
        if not sql:
            raise DBError("Please provide an SQL query to explain.")
        s = self.session(conn_id, database)

        with s.lock:
            cur = s.raw.cursor()
            try:
                if s.driver == "sqlite":
                    cur.execute(f"EXPLAIN QUERY PLAN {sql}")
                    rows = cur.fetchall()
                    parsed = _parse_sqlite_explain(rows, sql)
                    raw_plan = [list(r) for r in rows]
                elif s.driver in ("mysql", "mariadb"):
                    cur.execute(f"EXPLAIN {sql}")
                    rows = cur.fetchall()
                    cols = [c[0] for c in cur.description] if cur.description else []
                    parsed = _parse_mysql_explain(cols, rows, sql)
                    raw_plan = {"columns": cols, "rows": [list(r) for r in rows]}
                elif s.driver == "pgsql":
                    cur.execute(f"EXPLAIN (FORMAT JSON) {sql}")
                    row = cur.fetchone()
                    plan_json = row[0] if row else []
                    parsed = _parse_pgsql_explain(plan_json, sql)
                    raw_plan = plan_json
                else:
                    raise DBError(f"Unsupported database driver for EXPLAIN: {s.driver}")
            except Exception as exc:
                raise DBError(f"EXPLAIN failed: {friendly_error(exc)}") from exc
            finally:
                cur.close()
            s.used = time.time()

        return {
            "driver": s.driver,
            "sql": sql,
            "raw": raw_plan,
            "steps": parsed["steps"],
            "summary": parsed["summary"]
        }

    def schema_diff(self, src_conn, src_db, tgt_conn, tgt_db):
        src_s = self.session(src_conn, src_db)
        tgt_s = self.session(tgt_conn, tgt_db)

        src_tables_list = [t["name"] for t in self.tables(src_conn, src_db) if not t.get("view")]
        tgt_tables_list = [t["name"] for t in self.tables(tgt_conn, tgt_db) if not t.get("view")]

        src_tables_set = set(src_tables_list)
        tgt_tables_set = set(tgt_tables_list)

        missing_in_target = [t for t in src_tables_list if t not in tgt_tables_set]
        extra_in_target = [t for t in tgt_tables_list if t not in src_tables_set]
        common_tables = [t for t in src_tables_list if t in tgt_tables_set]

        diff_tables = []
        statements = []
        stmt_id = 0

        for tbl in missing_in_target:
            info = self.structure(src_conn, src_db, tbl)
            ddl = info.get("ddl") or ""
            if not ddl or (src_s.driver != tgt_s.driver and "sqlite" in (src_s.driver, tgt_s.driver)):
                lines = []
                for c in info.get("columns", []):
                    lines.append("  " + _format_col_def(c, tgt_s))
                pks = [c["name"] for c in info.get("columns", []) if c.get("pk")]
                if len(pks) > 1:
                    lines.append(f"  PRIMARY KEY ({', '.join(tgt_s.q(p) for p in pks)})")
                ddl = f"CREATE TABLE {tgt_s.table_ref(tbl)} (\n" + ",\n".join(lines) + "\n);"

            stmt_id += 1
            stmt = {
                "id": stmt_id,
                "table": tbl,
                "type": "create_table",
                "sql": ddl.strip().rstrip(";") + ";",
                "destructive": False,
                "description": f"Create missing table '{tbl}' in target"
            }
            statements.append(stmt)
            diff_tables.append({
                "name": tbl,
                "status": "missing_in_target",
                "missing_columns": [c["name"] for c in info.get("columns", [])],
                "modified_columns": [],
                "missing_indexes": [i["name"] for i in info.get("indexes", []) if not i.get("primary")],
                "sync_sql": [stmt["sql"]]
            })

        total_missing_cols = 0
        total_modified_cols = 0
        total_missing_indexes = 0

        for tbl in common_tables:
            src_info = self.structure(src_conn, src_db, tbl)
            tgt_info = self.structure(tgt_conn, tgt_db, tbl)

            src_cols = {c["name"]: c for c in src_info.get("columns", [])}
            tgt_cols = {c["name"]: c for c in tgt_info.get("columns", [])}

            table_missing_cols = []
            table_modified_cols = []
            table_missing_idx = []
            table_stmts = []

            for cname, c in src_cols.items():
                if cname not in tgt_cols:
                    table_missing_cols.append(cname)
                    total_missing_cols += 1
                    col_def = _format_col_def(c, tgt_s)
                    sql = f"ALTER TABLE {tgt_s.table_ref(tbl)} ADD COLUMN {col_def};"
                    stmt_id += 1
                    s_obj = {
                        "id": stmt_id,
                        "table": tbl,
                        "type": "add_column",
                        "sql": sql,
                        "destructive": False,
                        "description": f"Add missing column '{cname}' to '{tbl}'"
                    }
                    statements.append(s_obj)
                    table_stmts.append(sql)
                else:
                    tc = tgt_cols[cname]
                    src_type = (c.get("type") or "").strip().lower()
                    tgt_type = (tc.get("type") or "").strip().lower()
                    src_null = bool(c.get("nullable"))
                    tgt_null = bool(tc.get("nullable"))

                    src_norm = src_type.replace("character varying", "varchar").replace("integer", "int")
                    tgt_norm = tgt_type.replace("character varying", "varchar").replace("integer", "int")

                    if src_norm != tgt_norm or src_null != tgt_null:
                        table_modified_cols.append({
                            "column": cname,
                            "source_type": c.get("type"),
                            "target_type": tc.get("type"),
                            "source_nullable": src_null,
                            "target_nullable": tgt_null
                        })
                        total_modified_cols += 1
                        if tgt_s.driver in ("mysql", "mariadb"):
                            sql = f"ALTER TABLE {tgt_s.table_ref(tbl)} MODIFY COLUMN {_format_col_def(c, tgt_s)};"
                            stmt_id += 1
                            s_obj = {
                                "id": stmt_id,
                                "table": tbl,
                                "type": "modify_column",
                                "sql": sql,
                                "destructive": False,
                                "description": f"Modify column '{cname}' in '{tbl}' ({tgt_type} ➔ {c.get('type')})"
                            }
                            statements.append(s_obj)
                            table_stmts.append(sql)
                        elif tgt_s.driver == "pgsql":
                            sql = f"ALTER TABLE {tgt_s.table_ref(tbl)} ALTER COLUMN {tgt_s.q(cname)} TYPE {c.get('type')};"
                            stmt_id += 1
                            s_obj = {
                                "id": stmt_id,
                                "table": tbl,
                                "type": "modify_column",
                                "sql": sql,
                                "destructive": False,
                                "description": f"Alter column '{cname}' type in '{tbl}' ({tgt_type} ➔ {c.get('type')})"
                            }
                            statements.append(s_obj)
                            table_stmts.append(sql)

            src_idx = {i["name"]: i for i in src_info.get("indexes", []) if not i.get("primary")}
            tgt_idx = {i["name"]: i for i in tgt_info.get("indexes", []) if not i.get("primary")}

            for iname, idx in src_idx.items():
                if iname not in tgt_idx:
                    cols_str = ", ".join(tgt_s.q(co) for co in idx.get("columns", []))
                    if cols_str:
                        table_missing_idx.append(iname)
                        total_missing_indexes += 1
                        uniq = "UNIQUE " if idx.get("unique") else ""
                        clean_idx_name = f"idx_{tbl}_{idx.get('columns', ['col'])[0]}"
                        sql = f"CREATE {uniq}INDEX {tgt_s.q(clean_idx_name)} ON {tgt_s.table_ref(tbl)} ({cols_str});"
                        stmt_id += 1
                        s_obj = {
                            "id": stmt_id,
                            "table": tbl,
                            "type": "create_index",
                            "sql": sql,
                            "destructive": False,
                            "description": f"Create index '{clean_idx_name}' on '{tbl}'"
                        }
                        statements.append(s_obj)
                        table_stmts.append(sql)

            status = "altered" if (table_missing_cols or table_modified_cols or table_missing_idx) else "identical"
            diff_tables.append({
                "name": tbl,
                "status": status,
                "missing_columns": table_missing_cols,
                "modified_columns": table_modified_cols,
                "missing_indexes": table_missing_idx,
                "sync_sql": table_stmts
            })

        for tbl in extra_in_target:
            diff_tables.append({
                "name": tbl,
                "status": "extra_in_target",
                "missing_columns": [],
                "modified_columns": [],
                "missing_indexes": [],
                "sync_sql": []
            })

        status_order = {"missing_in_target": 1, "altered": 2, "extra_in_target": 3, "identical": 4}
        diff_tables.sort(key=lambda t: (status_order.get(t["status"], 5), t["name"].lower()))

        return {
            "source": {"conn": src_conn, "database": src_db, "driver": src_s.driver},
            "target": {"conn": tgt_conn, "database": tgt_db, "driver": tgt_s.driver},
            "stats": {
                "missing_tables": len(missing_in_target),
                "extra_tables": len(extra_in_target),
                "altered_tables": len([t for t in diff_tables if t["status"] == "altered"]),
                "identical_tables": len([t for t in diff_tables if t["status"] == "identical"]),
                "missing_columns": total_missing_cols,
                "modified_columns": total_modified_cols,
                "missing_indexes": total_missing_indexes,
                "total_statements": len(statements)
            },
            "tables": diff_tables,
            "statements": statements,
            "sync_sql": "\n\n".join(s["sql"] for s in statements)
        }

    def execute_sync(self, tgt_conn, tgt_db, statements, stop_on_error=True):
        s = self.session(tgt_conn, tgt_db)
        results = []
        executed = 0
        failed = 0
        stopped_early = False
        is_transactional = s.driver in ("pgsql", "sqlite")
        in_tx = False

        with s.lock:
            cur = s.raw.cursor()
            try:
                if is_transactional:
                    try:
                        cur.execute("BEGIN TRANSACTION" if s.driver == "sqlite" else "BEGIN")
                        in_tx = True
                    except Exception:
                        in_tx = False

                for item in statements:
                    sql = item.get("sql", "").strip() if isinstance(item, dict) else str(item).strip()
                    item_id = item.get("id") if isinstance(item, dict) else None
                    if not sql:
                        continue
                    t0 = time.time()
                    try:
                        cur.execute(sql)
                        ms = round((time.time() - t0) * 1000, 1)
                        results.append({"id": item_id, "sql": sql, "ok": True, "ms": ms})
                        executed += 1
                    except Exception as exc:
                        ms = round((time.time() - t0) * 1000, 1)
                        err_msg = friendly_error(exc)
                        results.append({"id": item_id, "sql": sql, "ok": False, "error": err_msg, "ms": ms})
                        failed += 1
                        if stop_on_error:
                            stopped_early = True
                            if in_tx:
                                try:
                                    cur.execute("ROLLBACK")
                                    in_tx = False
                                except Exception:
                                    pass
                            break

                if in_tx:
                    try:
                        cur.execute("COMMIT")
                    except Exception:
                        try:
                            cur.execute("ROLLBACK")
                        except Exception:
                            pass
            finally:
                cur.close()
            s.used = time.time()

        return {
            "executed": executed,
            "failed": failed,
            "stopped_early": stopped_early,
            "driver": s.driver,
            "results": results
        }


def _format_col_def(col, s):
    name = s.q(col["name"])
    raw_type = (col.get("type") or "TEXT").strip()
    default = col.get("default")
    nullable = bool(col.get("nullable", True))
    auto = bool(col.get("auto"))

    parts = [name, raw_type]
    if auto and s.driver in ("mysql", "mariadb"):
        parts.append("AUTO_INCREMENT")
    if not nullable:
        parts.append("NOT NULL")
    if default is not None:
        def_str = str(default).strip()
        if def_str.upper() in ("CURRENT_TIMESTAMP", "CURRENT_TIMESTAMP()", "NOW()"):
            parts.append("DEFAULT CURRENT_TIMESTAMP")
        elif def_str.lower() in ("true", "false"):
            parts.append(f"DEFAULT {def_str.upper()}")
        elif re.match(r"^-?\d+(\.\d+)?$", def_str):
            parts.append(f"DEFAULT {def_str}")
        else:
            clean = def_str.strip("'\"")
            esc = clean.replace("'", "''")
            parts.append(f"DEFAULT '{esc}'")
    return " ".join(parts)


def _parse_sqlite_explain(rows, sql):
    steps = []
    recommendations = []
    full_scans = 0

    for r in rows:
        detail = r[3] if len(r) > 3 else str(r)
        table_m = re.search(r"\b(SCAN|SEARCH)\s+([A-Za-z0-9_]+)", detail)
        tbl = table_m.group(2) if table_m else ""
        op_type = "info"
        severity = "good"
        warning = None

        if "SCAN" in detail and "USING INDEX" not in detail:
            op_type = "scan"
            severity = "critical"
            full_scans += 1
            warning = f"Full table scan on '{tbl}'. Every row is scanned without an index."
            if tbl:
                col_m = re.search(rf"\b{tbl}\.([A-Za-z0-9_]+)\b|\bWHERE\s+([A-Za-z0-9_]+)", sql, re.IGNORECASE)
                col_hint = col_m.group(1) or col_m.group(2) if col_m else "col"
                recommendations.append({
                    "table": tbl,
                    "message": f"Table '{tbl}' undergoes a full table scan without an index.",
                    "suggested_sql": f"CREATE INDEX idx_{tbl}_{col_hint} ON {tbl}({col_hint});"
                })
        elif "SEARCH" in detail and "USING INDEX" in detail:
            op_type = "index_lookup"
            severity = "good"
        elif "TEMP B-TREE" in detail:
            op_type = "sort"
            severity = "warning"
            warning = "Using temporary B-Tree for sorting/grouping."

        steps.append({
            "id": r[0] if len(r) > 0 else 0,
            "parent": r[1] if len(r) > 1 else 0,
            "table": tbl,
            "operation": detail,
            "type": op_type,
            "severity": severity,
            "warning": warning
        })

    status = "critical" if full_scans > 0 else ("warning" if any(s["severity"] == "warning" for s in steps) else "optimal")
    return {
        "steps": steps,
        "summary": {
            "status": status,
            "full_table_scans": full_scans,
            "recommendations": recommendations
        }
    }


def _parse_mysql_explain(cols, rows, sql):
    steps = []
    recommendations = []
    full_scans = 0
    uses_filesort = 0
    uses_temp = 0

    col_idx = {name.lower(): i for i, name in enumerate(cols)}

    for i, r in enumerate(rows):
        def val(k):
            idx = col_idx.get(k)
            return r[idx] if idx is not None and idx < len(r) else None

        tbl = val("table") or ""
        join_type = (val("type") or "").lower()
        key = val("key")
        extra = val("extra") or ""
        rows_est = val("rows")

        severity = "good"
        op_type = "index_lookup"
        warning = None

        if join_type == "all":
            severity = "critical"
            op_type = "scan"
            full_scans += 1
            warning = f"Full table scan on '{tbl}'. All estimated {rows_est or 'unknown'} rows are read without using an index."
            if tbl:
                col_m = re.search(rf"\b{tbl}\.([A-Za-z0-9_]+)\b|\bWHERE\s+([A-Za-z0-9_]+)", sql, re.IGNORECASE)
                col_hint = col_m.group(1) or col_m.group(2) if col_m else "id"
                recommendations.append({
                    "table": tbl,
                    "message": f"Table '{tbl}' has no matching index for this query.",
                    "suggested_sql": f"CREATE INDEX idx_{tbl}_{col_hint} ON {tbl}({col_hint});"
                })
        elif join_type == "index":
            severity = "warning"
            op_type = "index_scan"
            warning = f"Full index scan on '{tbl}' using key '{key}'."
        elif join_type == "range":
            severity = "info"
            op_type = "range"
        elif join_type in ("ref", "eq_ref", "const"):
            severity = "good"
            op_type = "index_lookup"

        if "using filesort" in extra.lower():
            uses_filesort += 1
            warning = (warning + " · " if warning else "") + "Using filesort for ordering."
        if "using temporary" in extra.lower():
            uses_temp += 1
            warning = (warning + " · " if warning else "") + "Using temporary table for grouping/sorting."

        steps.append({
            "id": val("id") or (i + 1),
            "table": tbl,
            "operation": f"{join_type.upper()} on {tbl}" if tbl else join_type.upper(),
            "type": op_type,
            "key": key,
            "rows": rows_est,
            "extra": extra,
            "severity": severity,
            "warning": warning
        })

    status = "critical" if full_scans > 0 else ("warning" if (uses_filesort or uses_temp) else "optimal")
    return {
        "steps": steps,
        "summary": {
            "status": status,
            "full_table_scans": full_scans,
            "uses_filesort": uses_filesort,
            "uses_temporary": uses_temp,
            "recommendations": recommendations
        }
    }


def _parse_pgsql_explain(plan_json, sql):
    steps = []
    recommendations = []
    full_scans = [0]

    def walk(node, parent_id=0):
        node_type = node.get("Node Type", "Node")
        rel_name = node.get("Relation Name", "")
        cost = node.get("Total Cost")
        rows = node.get("Plan Rows")
        filter_expr = node.get("Filter", "")
        index_name = node.get("Index Name", "")

        step_id = len(steps) + 1
        severity = "good"
        op_type = "operation"
        warning = None

        if "Seq Scan" in node_type:
            severity = "critical"
            op_type = "scan"
            full_scans[0] += 1
            warning = f"Sequential scan on '{rel_name}'. Total cost: {cost}."
            if rel_name:
                col_m = re.search(r"\(([A-Za-z0-9_]+)\s*=", filter_expr) if filter_expr else None
                col_hint = col_m.group(1) if col_m else "col"
                recommendations.append({
                    "table": rel_name,
                    "message": f"Table '{rel_name}' is scanned sequentially.",
                    "suggested_sql": f"CREATE INDEX idx_{rel_name}_{col_hint} ON {rel_name}({col_hint});"
                })
        elif "Index" in node_type:
            severity = "good"
            op_type = "index_lookup"

        steps.append({
            "id": step_id,
            "parent": parent_id,
            "table": rel_name,
            "operation": f"{node_type} on {rel_name}" if rel_name else node_type,
            "type": op_type,
            "key": index_name,
            "rows": rows,
            "cost": cost,
            "detail": filter_expr,
            "severity": severity,
            "warning": warning
        })

        for sub in node.get("Plans", []):
            walk(sub, step_id)

    root_plan = plan_json[0].get("Plan", {}) if isinstance(plan_json, list) and plan_json else (plan_json.get("Plan", {}) if isinstance(plan_json, dict) else {})
    if root_plan:
        walk(root_plan)

    status = "critical" if full_scans[0] > 0 else "optimal"
    return {
        "steps": steps,
        "summary": {
            "status": status,
            "full_table_scans": full_scans[0],
            "recommendations": recommendations
        }
    }
