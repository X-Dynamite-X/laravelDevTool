"""
ui/ai_assistant.py - AI Assistant and Diff Engine for laravel-dev-tool.
Supports diagnosing errors, generating code solutions via Ollama/Gemini/OpenAI/Anthropic,
and applying unified diffs safely within project boundaries.
"""

import os
import re
import difflib
import json
import urllib.parse
import urllib.request
import urllib.error
from pathlib import Path
from typing import Dict, Any, Optional, Tuple


def _validate_path_within_root(file_path: str, allowed_root: Optional[str] = None) -> Path:
    """Ensures file_path resolves inside allowed_root and never touches .git."""
    p = Path(file_path).resolve()
    if ".git" in p.parts:
        raise ValueError("Refusing to modify files inside .git directory.")
    if allowed_root:
        root = Path(allowed_root).resolve()
        if not p.is_relative_to(root):
            raise ValueError(f"Path '{file_path}' is outside project directory '{allowed_root}'.")
    return p


def generate_diff(original_text: str, new_text: str, filename: str = "file") -> str:
    """Generates standard unified diff between original and new text."""
    orig_lines = original_text.splitlines(keepends=True)
    new_lines = new_text.splitlines(keepends=True)
    if orig_lines and not orig_lines[-1].endswith("\n"):
        orig_lines[-1] += "\n"
    if new_lines and not new_lines[-1].endswith("\n"):
        new_lines[-1] += "\n"
    diff = difflib.unified_diff(
        orig_lines,
        new_lines,
        fromfile=f"a/{filename}",
        tofile=f"b/{filename}",
    )
    return "".join(diff)


def apply_file_changes(
    file_path: str,
    new_content: str,
    create_backup: bool = True,
    allowed_root: Optional[str] = None,
) -> Dict[str, Any]:
    """Safely applies changes to a file with optional .ldbak backup and root boundary check."""
    try:
        path = _validate_path_within_root(file_path, allowed_root)
    except ValueError as e:
        return {"success": False, "error": str(e)}

    if not path.is_file():
        return {"success": False, "error": f"File '{file_path}' does not exist."}

    backup_path = None
    if create_backup:
        backup_path = path.with_suffix(path.suffix + ".ldbak")
        try:
            backup_path.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
        except Exception as e:
            return {"success": False, "error": f"Could not create backup: {str(e)}"}

    try:
        path.write_text(new_content, encoding="utf-8")
        return {
            "success": True,
            "backup": str(backup_path) if backup_path else None,
            "file": str(path)
        }
    except Exception as e:
        if backup_path and backup_path.is_file():
            path.write_text(backup_path.read_text(encoding="utf-8"), encoding="utf-8")
        return {"success": False, "error": f"Failed to write file: {str(e)}"}


def revert_file_changes(file_path: str, allowed_root: Optional[str] = None) -> Dict[str, Any]:
    """Reverts file changes from .ldbak backup."""
    try:
        path = _validate_path_within_root(file_path, allowed_root)
    except ValueError as e:
        return {"success": False, "error": str(e)}

    backup_path = path.with_suffix(path.suffix + ".ldbak")
    if not backup_path.is_file():
        return {"success": False, "error": "No backup file (.ldbak) found to revert."}

    try:
        path.write_text(backup_path.read_text(encoding="utf-8"), encoding="utf-8")
        backup_path.unlink()
        return {"success": True, "file": str(path)}
    except Exception as e:
        return {"success": False, "error": f"Revert failed: {str(e)}"}


DEFAULT_MODELS = {
    "ollama": "llama3",
    "gemini": "gemini-2.5-flash",
    "openai": "gpt-4o-mini",
    "anthropic": "claude-sonnet-5-5",
}
PROVIDERS = tuple(DEFAULT_MODELS)


def _http_error_message(exc: Exception, provider: str) -> str:
    """Turns urllib errors into a short message that tells the user what to fix."""
    if isinstance(exc, urllib.error.HTTPError):
        detail = ""
        try:
            body = json.loads(exc.read().decode("utf-8", "replace"))
            err = body.get("error") if isinstance(body, dict) else None
            if isinstance(err, dict):
                detail = err.get("message") or ""
            elif isinstance(err, str):
                detail = err
        except Exception:
            pass
        hint = {401: "invalid API key", 403: "API key not allowed", 404: "unknown model", 429: "rate limited / quota exceeded"}.get(exc.code, "")
        parts = [f"{provider} returned HTTP {exc.code}"]
        if hint:
            parts.append(hint)
        if detail:
            parts.append(detail[:300])
        return " — ".join(parts)
    if isinstance(exc, urllib.error.URLError):
        return f"Could not reach {provider}: {exc.reason}"
    return f"{provider} request failed: {exc}"


def ask_local_ollama(prompt: str, model: str = "llama3", host: str = "http://127.0.0.1:11434") -> Tuple[Optional[str], str]:
    """Queries a local Ollama instance. Returns (reply, error)."""
    url = f"{host.rstrip('/')}/api/generate"
    payload = json.dumps({
        "model": model,
        "prompt": prompt,
        "stream": False
    }).encode("utf-8")

    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("response", ""), ""
    except Exception as exc:
        return None, _http_error_message(exc, "Ollama")


def ask_cloud_llm(prompt: str, provider: str, api_key: str, model: str = "") -> Tuple[Optional[str], str]:
    """Queries Gemini, OpenAI, or Anthropic with the standard library. Returns (reply, error)."""
    provider = (provider or "").lower().strip()
    if provider not in ("gemini", "openai", "anthropic"):
        return None, f"Unknown AI provider '{provider}'."
    if not api_key:
        return None, f"No API key configured for {provider}. Add it in Settings → AI Assistant."
    mdl = model or DEFAULT_MODELS[provider]
    try:
        if provider == "gemini":
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(mdl)}:generateContent"
            body = {"contents": [{"parts": [{"text": prompt}]}]}
            # Key goes in a header, not the URL, so it never lands in proxy/access logs.
            headers = {"Content-Type": "application/json", "x-goog-api-key": api_key}
            req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers)
            with urllib.request.urlopen(req, timeout=90) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data["candidates"][0]["content"]["parts"][0]["text"], ""

        if provider == "openai":
            url = "https://api.openai.com/v1/chat/completions"
            body = {"model": mdl, "messages": [{"role": "user", "content": prompt}], "temperature": 0.2}
            req = urllib.request.Request(
                url,
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data["choices"][0]["message"]["content"], ""

        url = "https://api.anthropic.com/v1/messages"
        body = {"model": mdl, "max_tokens": 8192, "messages": [{"role": "user", "content": prompt}]}
        req = urllib.request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
            },
        )
        with urllib.request.urlopen(req, timeout=90) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            text = "".join(block.get("text", "") for block in data.get("content", []) if block.get("type") == "text")
            return text, ""
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        return None, f"{provider} returned an unexpected response: {exc}"
    except Exception as exc:
        return None, _http_error_message(exc, provider)


def ask_llm(prompt: str, ai_config: Optional[Dict[str, Any]] = None) -> Tuple[Optional[str], str]:
    cfg = ai_config or {}
    provider = (cfg.get("provider") or "ollama").lower()
    model = cfg.get("model") or ""
    if provider == "ollama":
        return ask_local_ollama(prompt, model=model or DEFAULT_MODELS["ollama"],
                                host=cfg.get("ollama_url") or "http://127.0.0.1:11434")
    return ask_cloud_llm(prompt, provider=provider, api_key=cfg.get("api_key") or "", model=model)


class AISettings:
    """Stores the AI provider choice in <config>/ai.json.

    The API key is encrypted with the credential Vault when it is enabled (``enc:`` prefix),
    and re-keyed together with database secrets when the master password changes.
    """

    def __init__(self, config_dir, vault=None):
        self.file = Path(config_dir) / "ai.json"
        self.vault = vault

    def _read(self) -> Dict[str, Any]:
        try:
            data = json.loads(self.file.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _write(self, data: Dict[str, Any]) -> None:
        self.file.parent.mkdir(parents=True, exist_ok=True)
        self.file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        try:
            os.chmod(self.file, 0o600)
        except OSError:
            pass

    def public(self) -> Dict[str, Any]:
        data = self._read()
        key = data.get("api_key") or ""
        provider = data.get("provider") or "ollama"
        return {
            "provider": provider,
            "model": data.get("model") or "",
            "default_model": DEFAULT_MODELS.get(provider, ""),
            "default_models": DEFAULT_MODELS,
            "ollama_url": data.get("ollama_url") or "http://127.0.0.1:11434",
            "has_key": bool(key),
            "key_encrypted": key.startswith("enc:"),
            "providers": list(PROVIDERS),
        }

    def save(self, provider: str, model: str = "", ollama_url: str = "", api_key: Optional[str] = None) -> Dict[str, Any]:
        provider = (provider or "ollama").lower().strip()
        if provider not in PROVIDERS:
            raise ValueError(f"Unknown AI provider '{provider}'.")
        model = (model or "").strip()
        if model and not re.match(r"^[A-Za-z0-9._:/-]{1,100}$", model):
            raise ValueError("Invalid model name.")
        ollama_url = (ollama_url or "").strip() or "http://127.0.0.1:11434"
        if not re.match(r"^https?://[^\s]+$", ollama_url):
            raise ValueError("Ollama URL must start with http:// or https://")

        data = self._read()
        data.update({"provider": provider, "model": model, "ollama_url": ollama_url})
        if api_key is not None:  # None = keep the stored key, "" = remove it
            api_key = api_key.strip()
            if api_key and self.vault is not None and self.vault.is_enabled():
                api_key = self.vault.encrypt(api_key)  # raises if the vault is locked
            data["api_key"] = api_key
        self._write(data)
        return self.public()

    def call_config(self) -> Dict[str, Any]:
        """Full config including the decrypted API key, for making a request."""
        data = self._read()
        key = data.get("api_key") or ""
        if key.startswith("enc:"):
            if self.vault is None or not self.vault.is_unlocked():
                raise ValueError("Unlock the credential vault (Settings → Vault) to use the stored AI API key.")
            key = self.vault.decrypt(key)
        return {
            "provider": data.get("provider") or "ollama",
            "model": data.get("model") or "",
            "ollama_url": data.get("ollama_url") or "http://127.0.0.1:11434",
            "api_key": key,
        }

    def rekey(self, old_vault_key: Optional[bytes], new_vault_key: Optional[bytes]) -> None:
        """Vault migrator hook: re-encrypt (or decrypt) the stored key when the master key changes."""
        data = self._read()
        key = data.get("api_key") or ""
        if not key:
            return
        from cryptography.fernet import Fernet
        if key.startswith("enc:"):
            if not old_vault_key:
                return
            key = Fernet(old_vault_key).decrypt(key[4:].encode("ascii")).decode("utf-8")
        if new_vault_key:
            key = "enc:" + Fernet(new_vault_key).encrypt(key.encode("utf-8")).decode("ascii")
        data["api_key"] = key
        self._write(data)


def _resolve_error_file(project_path: str, file_hint: str, message: str, trace: str) -> tuple[Optional[Path], int]:
    """Finds the best project file & line referenced in the error or stack trace."""
    root = Path(project_path).resolve()
    candidates = []
    if file_hint:
        candidates.append((file_hint, 1))

    combined = f"{message}\n{trace}"
    for m in re.finditer(r"(/[^\s:()\"']+\.php)(?:\((\d+)\)|:(\d+))?", combined):
        fpath = m.group(1)
        fline = int(m.group(2) or m.group(3) or 1)
        candidates.append((fpath, fline))

    for m in re.finditer(r"\b((?:app|routes|config|database|resources)/[^\s:()\"']+\.php)(?:\((\d+)\)|:(\d+))?", combined):
        rel = m.group(1)
        fline = int(m.group(2) or m.group(3) or 1)
        candidates.append((str(root / rel), fline))

    # Prefer files inside the project (excluding vendor/)
    for fpath, fline in candidates:
        p = Path(fpath)
        if not p.is_absolute():
            p = root / p
        try:
            rp = p.resolve()
            if rp.is_file() and rp.is_relative_to(root) and "vendor" not in rp.relative_to(root).parts:
                return rp, fline
        except Exception:
            continue

    return None, 1


def _extract_code_block(response_text: str) -> Optional[str]:
    """Extracts the first fenced code block from an LLM response."""
    m = re.search(r"```(?:php|html|js|json|env)?\s*\n(.*?)```", response_text, re.DOTALL)
    if m:
        return m.group(1)
    return None


def propose_fix(
    project_path: str,
    error_message: str,
    file_path: str = "",
    line: int = 1,
    trace: str = "",
    custom_prompt: str = "",
    ai_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Analyzes a Laravel error or doctor issue, locates the relevant project file,
    queries the configured AI provider (or heuristic analyzer), and returns a unified diff.
    """
    root = Path(project_path).resolve()
    target_path, detected_line = _resolve_error_file(project_path, file_path, error_message, trace)
    line_num = int(line or detected_line or 1)

    original_content = ""
    rel_name = "file.php"
    has_backup = False

    if target_path and target_path.is_file():
        try:
            original_content = target_path.read_text(encoding="utf-8")
            rel_name = str(target_path.relative_to(root))
            has_backup = target_path.with_suffix(target_path.suffix + ".ldbak").is_file()
        except Exception:
            pass

    cfg = ai_config or {}
    provider = (cfg.get("provider") or "ollama").lower()

    prompt = (
        f"You are a senior Laravel developer fixing an issue in a local project.\n"
        f"Error: {error_message}\n"
        f"File: {rel_name} (line {line_num})\n"
    )
    if custom_prompt:
        prompt += f"Additional instructions: {custom_prompt}\n"
    if trace:
        prompt += f"Stack trace snippet:\n{trace[:1500]}\n"
    if original_content:
        prompt += (
            f"\nCurrent content of `{rel_name}`:\n```php\n{original_content}\n```\n\n"
            f"Provide a short explanation of the root cause, followed by the COMPLETE updated file inside a ```php ... ``` code block."
        )
    else:
        prompt += "\nExplain the cause of this issue and show the exact code or command to fix it."

    llm_reply, ai_error = ask_llm(prompt, cfg)

    proposed_content = original_content
    explanation = ""

    if llm_reply:
        extracted = _extract_code_block(llm_reply)
        if extracted and original_content:
            proposed_content = extracted
        explanation = re.sub(r"```.*?```", "", llm_reply, flags=re.DOTALL).strip() or llm_reply.strip()
    else:
        # Helpful heuristic diagnosis when no LLM is reachable yet
        explanation = (
            (f"AI provider unavailable: {ai_error}\n\n" if ai_error else "")
            + f"Diagnostic analysis for: {error_message}\n"
            f"• Target file: {rel_name} (around line {line_num})\n"
            f"• Tip: You can edit the code directly below to preview the Unified Diff and apply it with an automatic .ldbak backup, "
            f"or configure your preferred AI provider (Ollama / Gemini / OpenAI / Anthropic) in Settings."
        )

    diff_text = generate_diff(original_content, proposed_content, rel_name) if original_content else ""

    return {
        "ok": True,
        "provider": provider,
        "ai_connected": bool(llm_reply),
        "ai_error": ai_error,
        "file_path": str(target_path) if target_path else "",
        "rel_file": rel_name,
        "line": line_num,
        "has_backup": has_backup,
        "explanation": explanation,
        "original_content": original_content,
        "proposed_content": proposed_content,
        "diff": diff_text,
    }
