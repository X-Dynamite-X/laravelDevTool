"""
ui/ai_assistant.py - AI Assistant and Diff Engine for laravel-dev-tool.
Supports diagnosing errors, generating code solutions via Ollama/Gemini/OpenAI/Anthropic,
and applying unified diffs safely within project boundaries.
"""

import os
import re
import socket
import time
import difflib
import json
import urllib.parse
import urllib.request
import urllib.error
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple


def _validate_path_within_root(file_path: str, allowed_root: Optional[str] = None) -> Path:
    """Ensures file_path resolves inside allowed_root and never touches .git."""
    p = Path(file_path).resolve()
    if ".git" in p.parts:
        raise ValueError("Refusing to modify files inside .git directory.")
    if allowed_root:
        root = Path(allowed_root).resolve()
        if not p.is_relative_to(root):
            raise ValueError(f"Path '{file_path}' is outside project directory '{allowed_root}'.")
    return p


def generate_diff(original_text: str, new_text: str, filename: str = "file") -> str:
    """Generates standard unified diff between original and new text."""
    orig_lines = original_text.splitlines(keepends=True)
    new_lines = new_text.splitlines(keepends=True)
    if orig_lines and not orig_lines[-1].endswith("\n"):
        orig_lines[-1] += "\n"
    if new_lines and not new_lines[-1].endswith("\n"):
        new_lines[-1] += "\n"
    diff = difflib.unified_diff(
        orig_lines,
        new_lines,
        fromfile=f"a/{filename}",
        tofile=f"b/{filename}",
    )
    return "".join(diff)


def apply_file_changes(
    file_path: str,
    new_content: str,
    create_backup: bool = True,
    allowed_root: Optional[str] = None,
) -> Dict[str, Any]:
    """Safely applies changes to a file with optional .ldbak backup and root boundary check."""
    try:
        path = _validate_path_within_root(file_path, allowed_root)
    except ValueError as e:
        return {"success": False, "error": str(e)}

    if not path.is_file():
        return {"success": False, "error": f"File '{file_path}' does not exist."}

    backup_path = None
    if create_backup:
        backup_path = path.with_suffix(path.suffix + ".ldbak")
        try:
            backup_path.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
        except Exception as e:
            return {"success": False, "error": f"Could not create backup: {str(e)}"}

    try:
        path.write_text(new_content, encoding="utf-8")
        return {
            "success": True,
            "backup": str(backup_path) if backup_path else None,
            "file": str(path)
        }
    except Exception as e:
        if backup_path and backup_path.is_file():
            path.write_text(backup_path.read_text(encoding="utf-8"), encoding="utf-8")
        return {"success": False, "error": f"Failed to write file: {str(e)}"}


def revert_file_changes(file_path: str, allowed_root: Optional[str] = None) -> Dict[str, Any]:
    """Reverts file changes from .ldbak backup."""
    try:
        path = _validate_path_within_root(file_path, allowed_root)
    except ValueError as e:
        return {"success": False, "error": str(e)}

    backup_path = path.with_suffix(path.suffix + ".ldbak")
    if not backup_path.is_file():
        return {"success": False, "error": "No backup file (.ldbak) found to revert."}

    try:
        path.write_text(backup_path.read_text(encoding="utf-8"), encoding="utf-8")
        backup_path.unlink()
        return {"success": True, "file": str(path)}
    except Exception as e:
        return {"success": False, "error": f"Revert failed: {str(e)}"}


# Every provider the AI settings can use. "openai"-style providers share the chat-completions API;
# "custom" is any OpenAI-compatible server (LM Studio, vLLM, LiteLLM, …) at a URL the user gives.
PROVIDER_INFO: Dict[str, Dict[str, Any]] = {
    "ollama": {"label": "Ollama", "local": True, "default": "llama3", "key": False,
               "key_url": "https://ollama.com/download"},
    "anthropic": {"label": "Anthropic Claude", "default": "claude-sonnet-5-5", "key_prefix": "sk-ant-",
                  "key_url": "https://console.anthropic.com/settings/keys"},
    "openai": {"label": "OpenAI", "default": "gpt-4o-mini", "key_prefix": "sk-",
               "key_url": "https://platform.openai.com/api-keys", "base_url": "https://api.openai.com/v1"},
    "gemini": {"label": "Google Gemini", "default": "gemini-2.5-flash", "key_prefix": "AIza",
               "key_url": "https://aistudio.google.com/app/apikey"},
    "openrouter": {"label": "OpenRouter", "default": "openrouter/auto", "key_prefix": "sk-or-",
                   "key_url": "https://openrouter.ai/keys", "base_url": "https://openrouter.ai/api/v1"},
    "groq": {"label": "Groq", "default": "llama-3.3-70b-versatile", "key_prefix": "gsk_",
             "key_url": "https://console.groq.com/keys", "base_url": "https://api.groq.com/openai/v1"},
    "deepseek": {"label": "DeepSeek", "default": "deepseek-chat",
                 "key_url": "https://platform.deepseek.com/api_keys", "base_url": "https://api.deepseek.com/v1"},
    "mistral": {"label": "Mistral", "default": "mistral-small-latest",
                "key_url": "https://console.mistral.ai/api-keys", "base_url": "https://api.mistral.ai/v1"},
    "custom": {"label": "OpenAI-compatible", "default": "", "key": "optional"},
}
DEFAULT_MODELS = {pid: info["default"] for pid, info in PROVIDER_INFO.items()}
PROVIDERS = tuple(PROVIDER_INFO)
OPENAI_STYLE = tuple(pid for pid, info in PROVIDER_INFO.items() if info.get("base_url")) + ("custom",)
CLOUD_PROVIDERS = tuple(pid for pid in PROVIDERS if pid != "ollama")
URL_RE = re.compile(r"^https?://[^\s]+$")


def provider_label(provider: str) -> str:
    return (PROVIDER_INFO.get(provider) or {}).get("label") or (provider or "").capitalize()


def _chat_url(provider: str, base_url: str = "") -> str:
    base = (base_url if provider == "custom" else PROVIDER_INFO[provider]["base_url"]) or ""
    return base.rstrip("/") + "/chat/completions"


def _http_error_message(exc: Exception, provider: str) -> str:
    """Turns urllib errors into a short message that tells the user what to fix."""
    if isinstance(exc, urllib.error.HTTPError):
        detail = ""
        try:
            body = json.loads(exc.read().decode("utf-8", "replace"))
            err = body.get("error") if isinstance(body, dict) else None
            if isinstance(err, dict):
                detail = err.get("message") or ""
            elif isinstance(err, str):
                detail = err
        except Exception:
            pass
        hint = {401: "invalid API key", 403: "API key not allowed", 404: "unknown model", 429: "rate limited / quota exceeded"}.get(exc.code, "")
        parts = [f"{provider} returned HTTP {exc.code}"]
        if hint:
            parts.append(hint)
        if detail:
            parts.append(detail[:300])
        return " — ".join(parts)
    if isinstance(exc, urllib.error.URLError):
        return f"Could not reach {provider}: {exc.reason}"
    return f"{provider} request failed: {exc}"


CANCELLED = "Stopped by the user."


class ThinkFilter:
    """Drops <think>…</think> from a streamed answer (the reasoning of qwen3 / deepseek-r1).
    The dropped reasoning goes to `on_thought(text)` when one is given."""

    def __init__(self, on_thought=None):
        self.buf = ""
        self.in_think = False
        self.on_thought = on_thought

    def _thought(self, text: str):
        if text and self.on_thought:
            self.on_thought(text)

    def feed(self, text: str) -> str:
        self.buf += text or ""
        out = []
        while self.buf:
            if self.in_think:
                end = self.buf.find("</think>")
                if end < 0:
                    self._thought(self.buf[:-8])
                    self.buf = self.buf[-8:]  # keep a possible partial closing tag
                    break
                self._thought(self.buf[:end])
                self.buf = self.buf[end + 8:].lstrip()
                self.in_think = False
                continue
            start = self.buf.find("<think>")
            if start < 0:
                # Hold back a trailing "<thi" that may become "<think>" with the next chunk.
                keep = next((i for i in range(1, 7) if "<think>".startswith(self.buf[-i:])), 0)
                out.append(self.buf[:len(self.buf) - keep] if keep else self.buf)
                self.buf = self.buf[len(self.buf) - keep:] if keep else ""
                break
            out.append(self.buf[:start])
            self.buf = self.buf[start + 7:]
            self.in_think = True
        return "".join(out)

    def flush(self) -> str:
        rest, self.buf = ("" if self.in_think else self.buf), ""
        return rest


def _close_on_cancel(resp, cancel):
    """Closes a streaming response as soon as `cancel` is set, even while a read is blocked
    (Ollama sends nothing while it loads the model / reads a long prompt). Returns a function
    that ends the watcher."""
    import threading
    finished = threading.Event()
    if cancel is None:
        return finished.set

    def watch():
        while not finished.is_set():
            if cancel.wait(0.2):
                try:
                    sock = getattr(getattr(getattr(resp, "fp", None), "raw", None), "_sock", None)
                    if sock is not None:
                        sock.shutdown(socket.SHUT_RDWR)
                    resp.close()
                except Exception:
                    pass
                return

    threading.Thread(target=watch, daemon=True).start()
    return finished.set


OLLAMA_IDLE_TIMEOUT = 300   # seconds without any output (loading a large model counts here)
OLLAMA_TOTAL_TIMEOUT = 900  # whole answer


def _strip_think(text: str) -> str:
    """Reasoning models (qwen3, deepseek-r1) may put their reasoning in <think>…</think>."""
    return re.sub(r"(?s)<think>.*?</think>\s*", "", text or "").strip()


def ask_local_ollama(prompt: str, model: str = "llama3", host: str = "http://127.0.0.1:11434",
                     think: Optional[bool] = False, on_delta=None, cancel=None,
                     on_thinking=None) -> Tuple[Optional[str], str]:
    """Queries a local Ollama instance. Returns (reply, error).

    Streams the answer, so a long answer from a slow model never hits a fixed timeout: the
    request only fails after OLLAMA_IDLE_TIMEOUT seconds without output. `think=False` turns
    off the reasoning phase of thinking models (qwen3: ~50 s → ~8 s for a short answer);
    None leaves the model's default. The reasoning, when there is one, goes to on_thinking(text)."""
    url = f"{host.rstrip('/')}/api/generate"
    body = {"model": model, "prompt": prompt, "stream": True}
    if think is not None:
        body["think"] = think
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"})
    started = time.monotonic()
    parts: List[str] = []
    visible = ThinkFilter(on_thinking)
    try:
        with urllib.request.urlopen(req, timeout=OLLAMA_IDLE_TIMEOUT) as resp:
            stop_watch = _close_on_cancel(resp, cancel)
            for raw in resp:
                if cancel is not None and cancel.is_set():
                    return _strip_think("".join(parts)) or None, CANCELLED  # closing the stream stops Ollama
                if time.monotonic() - started > OLLAMA_TOTAL_TIMEOUT:
                    return None, f"Ollama did not finish within {OLLAMA_TOTAL_TIMEOUT // 60} minutes."
                line = raw.strip()
                if not line:
                    continue
                chunk = json.loads(line.decode("utf-8"))
                if chunk.get("error"):
                    return None, f"Ollama: {chunk['error']}"
                if on_thinking and chunk.get("thinking"):
                    on_thinking(chunk["thinking"])
                piece = chunk.get("response") or ""
                parts.append(piece)
                if on_delta and piece:
                    shown = visible.feed(piece)
                    if shown:
                        on_delta(shown)
                if chunk.get("done"):
                    break
            stop_watch()
        if cancel is not None and cancel.is_set():
            return _strip_think("".join(parts)) or None, CANCELLED
        if on_delta:
            tail = visible.flush()
            if tail:
                on_delta(tail)
        return _strip_think("".join(parts)), ""
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = json.loads(exc.read().decode("utf-8")).get("error", "")
        except Exception:
            pass
        if think is not None and "think" in detail.lower():
            # Models without a reasoning mode reject the option: ask again without it.
            return ask_local_ollama(prompt, model=model, host=host, think=None, on_delta=on_delta, cancel=cancel,
                                    on_thinking=on_thinking)
        if exc.code == 404:
            return None, f"Ollama has no model '{model}'. Run: ollama pull {model} (or pick another model in Settings → AI)."
        return None, f"Ollama returned HTTP {exc.code}" + (f" — {detail}" if detail else "")
    except (TimeoutError, socket.timeout):
        if cancel is not None and cancel.is_set():
            return _strip_think("".join(parts)) or None, CANCELLED
        return None, (f"Ollama sent nothing for {OLLAMA_IDLE_TIMEOUT // 60} minutes while answering with '{model}'. "
                      "The model may be too large for this machine; try a smaller one.")
    except Exception as exc:
        if cancel is not None and cancel.is_set():
            return _strip_think("".join(parts)) or None, CANCELLED
        return None, _http_error_message(exc, "Ollama")


def _bearer(api_key: str) -> Dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _cloud_stream(prompt: str, provider: str, api_key: str, mdl: str, on_delta, cancel,
                  base_url: str = "") -> Tuple[Optional[str], str]:
    """Server-sent events from Gemini / OpenAI / Anthropic; on_delta(text) for every piece."""
    if provider == "gemini":
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(mdl)}:streamGenerateContent?alt=sse"
        body = {"contents": [{"parts": [{"text": prompt}]}]}
        headers = {"Content-Type": "application/json", "x-goog-api-key": api_key}
    elif provider in OPENAI_STYLE:
        url = _chat_url(provider, base_url)
        body = {"model": mdl, "messages": [{"role": "user", "content": prompt}], "temperature": 0.2, "stream": True}
        headers = _bearer(api_key)
    else:
        url = "https://api.anthropic.com/v1/messages"
        body = {"model": mdl, "max_tokens": 8192, "stream": True, "messages": [{"role": "user", "content": prompt}]}
        headers = {"Content-Type": "application/json", "x-api-key": api_key, "anthropic-version": "2023-06-01"}
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers)
    parts: List[str] = []
    with urllib.request.urlopen(req, timeout=120) as resp:
        stop_watch = _close_on_cancel(resp, cancel)
        for raw in _safe_lines(resp, cancel):
            if cancel is not None and cancel.is_set():
                stop_watch()
                return "".join(parts) or None, CANCELLED
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if not data or data == "[DONE]":
                continue
            event = json.loads(data)
            if provider == "gemini":
                cands = event.get("candidates") or [{}]
                piece = "".join(p.get("text", "") for p in (cands[0].get("content") or {}).get("parts", []))
            elif provider in OPENAI_STYLE:
                if event.get("error"):
                    return None, f"{provider}: {(event.get('error') or {}).get('message', 'error')}"
                piece = ((event.get("choices") or [{}])[0].get("delta") or {}).get("content") or ""
            else:
                if event.get("type") == "error":
                    return None, f"anthropic: {(event.get('error') or {}).get('message', 'error')}"
                piece = (event.get("delta") or {}).get("text", "") if event.get("type") == "content_block_delta" else ""
            if piece:
                parts.append(piece)
                on_delta(piece)
        stop_watch()
    if cancel is not None and cancel.is_set():
        return "".join(parts) or None, CANCELLED
    return "".join(parts), ""


def _safe_lines(lines, cancel):
    """Iterates a response, ending quietly when it was closed because of `cancel`."""
    try:
        for line in lines:
            yield line
    except Exception:
        if cancel is None or not cancel.is_set():
            raise


def ask_cloud_llm(prompt: str, provider: str, api_key: str, model: str = "", on_delta=None,
                  cancel=None, base_url: str = "") -> Tuple[Optional[str], str]:
    """Queries a cloud provider (Gemini, Anthropic, OpenAI and the OpenAI-compatible ones) with the
    standard library. Returns (reply, error). With on_delta the answer is streamed piece by piece
    (and `cancel`, a threading.Event, stops it)."""
    provider = (provider or "").lower().strip()
    if provider not in CLOUD_PROVIDERS:
        return None, f"Unknown AI provider '{provider}'."
    if provider == "custom" and not base_url:
        return None, "Set the server URL of the OpenAI-compatible provider in Settings → AI Assistant."
    if not api_key and provider != "custom":
        return None, f"No API key configured for {provider_label(provider)}. Add it in Settings → AI Assistant."
    mdl = model or DEFAULT_MODELS[provider]
    if not mdl:
        return None, f"Choose a model for {provider_label(provider)} in Settings → AI Assistant."
    if on_delta is not None:
        try:
            return _cloud_stream(prompt, provider, api_key, mdl, on_delta, cancel, base_url)
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            return None, f"{provider} returned an unexpected response: {exc}"
        except Exception as exc:
            return None, _http_error_message(exc, provider)
    try:
        if provider == "gemini":
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(mdl)}:generateContent"
            body = {"contents": [{"parts": [{"text": prompt}]}]}
            # Key goes in a header, not the URL, so it never lands in proxy/access logs.
            headers = {"Content-Type": "application/json", "x-goog-api-key": api_key}
            req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers)
            with urllib.request.urlopen(req, timeout=90) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data["candidates"][0]["content"]["parts"][0]["text"], ""

        if provider in OPENAI_STYLE:
            body = {"model": mdl, "messages": [{"role": "user", "content": prompt}], "temperature": 0.2}
            req = urllib.request.Request(_chat_url(provider, base_url), data=json.dumps(body).encode("utf-8"),
                                         headers=_bearer(api_key))
            with urllib.request.urlopen(req, timeout=90) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data["choices"][0]["message"]["content"], ""

        url = "https://api.anthropic.com/v1/messages"
        body = {"model": mdl, "max_tokens": 8192, "messages": [{"role": "user", "content": prompt}]}
        req = urllib.request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
            },
        )
        with urllib.request.urlopen(req, timeout=90) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            text = "".join(block.get("text", "") for block in data.get("content", []) if block.get("type") == "text")
            return text, ""
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        return None, f"{provider} returned an unexpected response: {exc}"
    except Exception as exc:
        return None, _http_error_message(exc, provider)


def ask_llm(prompt: str, ai_config: Optional[Dict[str, Any]] = None, on_delta=None,
            cancel=None, on_thinking=None) -> Tuple[Optional[str], str]:
    cfg = ai_config or {}
    provider = (cfg.get("provider") or "ollama").lower()
    model = cfg.get("model") or ""
    if provider == "ollama":
        return ask_local_ollama(prompt, model=model or DEFAULT_MODELS["ollama"],
                                host=cfg.get("ollama_url") or "http://127.0.0.1:11434",
                                think=cfg.get("think", False), on_delta=on_delta, cancel=cancel,
                                on_thinking=on_thinking)
    return ask_cloud_llm(prompt, provider=provider, api_key=cfg.get("api_key") or "", model=model,
                         on_delta=on_delta, cancel=cancel, base_url=cfg.get("base_url") or "")


class AISettings:
    """Stores the AI provider choice in <config>/ai.json.

    Every provider keeps its own API key and model, so switching between them never loses a key:
      {"provider": active, "keys": {provider: key}, "models": {provider: model},
       "key_hints": {provider: "…abcd"}, "ollama_url": …, "custom_url": …}
    Keys are encrypted with the credential Vault when it is enabled (``enc:`` prefix), and re-keyed
    together with database secrets when the master password changes. The old single "api_key" /
    "model" fields are read as the active provider's.
    """

    def __init__(self, config_dir, vault=None):
        self.file = Path(config_dir) / "ai.json"
        self.vault = vault

    def _read(self) -> Dict[str, Any]:
        try:
            data = json.loads(self.file.read_text(encoding="utf-8"))
            data = data if isinstance(data, dict) else {}
        except Exception:
            data = {}
        provider = data.get("provider") if data.get("provider") in PROVIDERS else "ollama"
        data["provider"] = provider
        for field in ("keys", "models", "key_hints"):
            if not isinstance(data.get(field), dict):
                data[field] = {}
        if "api_key" in data:  # older file: one key for the active provider
            legacy = data.pop("api_key") or ""
            if legacy and provider != "ollama":
                data["keys"].setdefault(provider, legacy)
        if "model" in data:
            legacy = data.pop("model") or ""
            if legacy:
                data["models"].setdefault(provider, legacy)
        return data

    def _write(self, data: Dict[str, Any]) -> None:
        self.file.parent.mkdir(parents=True, exist_ok=True)
        self.file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        try:
            os.chmod(self.file, 0o600)
        except OSError:
            pass

    def public(self) -> Dict[str, Any]:
        data = self._read()
        provider = data["provider"]
        info = {}
        for pid, meta in PROVIDER_INFO.items():
            key = data["keys"].get(pid) or ""
            info[pid] = {
                "id": pid, "label": meta["label"], "local": bool(meta.get("local")),
                "needs_key": meta.get("key", True) is True, "key_optional": meta.get("key") == "optional",
                "key_url": meta.get("key_url", ""), "key_prefix": meta.get("key_prefix", ""),
                "default_model": meta["default"], "model": data["models"].get(pid) or "",
                "has_key": bool(key), "key_encrypted": key.startswith("enc:"),
                "key_hint": data["key_hints"].get(pid) or "",
            }
        key = data["keys"].get(provider) or ""
        return {
            "provider": provider,
            "model": data["models"].get(provider) or "",
            "default_model": DEFAULT_MODELS.get(provider, ""),
            "default_models": DEFAULT_MODELS,
            "ollama_url": data.get("ollama_url") or "http://127.0.0.1:11434",
            "custom_url": data.get("custom_url") or "",
            "has_key": bool(key),
            "key_encrypted": key.startswith("enc:"),
            "providers": list(PROVIDERS),
            "provider_info": info,
            "ready": self._ready(data, provider),
        }

    @staticmethod
    def _ready(data: Dict[str, Any], provider: str) -> bool:
        if provider == "ollama":
            return True
        if provider == "custom":
            return bool(data.get("custom_url")) and bool(data["models"].get("custom"))
        return bool(data["keys"].get(provider))

    def save(self, provider: Optional[str] = None, model: Optional[str] = None, ollama_url: Optional[str] = None,
             api_key: Optional[str] = None, custom_url: Optional[str] = None) -> Dict[str, Any]:
        """Makes `provider` the active one and updates what is given (None keeps a value;
        api_key "" removes that provider's key, model "" goes back to its default)."""
        data = self._read()
        provider = (provider or data["provider"]).lower().strip()
        if provider not in PROVIDERS:
            raise ValueError(f"Unknown AI provider '{provider}'.")
        if model is not None:
            model = model.strip()
            if model and not re.match(r"^[A-Za-z0-9._:/@-]{1,200}$", model):
                raise ValueError("Invalid model name.")
        if ollama_url is not None:
            ollama_url = ollama_url.strip() or "http://127.0.0.1:11434"
            if not URL_RE.match(ollama_url):
                raise ValueError("Ollama URL must start with http:// or https://")
        if custom_url is not None:
            custom_url = custom_url.strip().rstrip("/")
            if custom_url and not URL_RE.match(custom_url):
                raise ValueError("The server URL must start with http:// or https://")

        data["provider"] = provider
        if model is not None:
            if model:
                data["models"][provider] = model
            else:
                data["models"].pop(provider, None)
        if ollama_url is not None:
            data["ollama_url"] = ollama_url
        if custom_url is not None:
            data["custom_url"] = custom_url
        if api_key is not None and provider != "ollama":
            api_key = api_key.strip()
            if not api_key:
                data["keys"].pop(provider, None)
                data["key_hints"].pop(provider, None)
            else:
                if any(c.isspace() for c in api_key) or len(api_key) > 500:
                    raise ValueError("That does not look like an API key (it has spaces or is too long).")
                hint = "…" + api_key[-4:] if len(api_key) >= 12 else ""
                if self.vault is not None and self.vault.is_enabled():
                    api_key = self.vault.encrypt(api_key)  # raises if the vault is locked
                data["keys"][provider] = api_key
                data["key_hints"][provider] = hint
        self._write(data)
        return self.public()

    def _key(self, data: Dict[str, Any], provider: str) -> str:
        key = data["keys"].get(provider) or ""
        if key.startswith("enc:"):
            if self.vault is None or not self.vault.is_unlocked():
                raise ValueError("Unlock the credential vault (Settings → Vault) to use the stored AI API key.")
            key = self.vault.decrypt(key)
        return key

    def call_config(self, provider: Optional[str] = None) -> Dict[str, Any]:
        """Full config including the decrypted API key, for making a request (to the active provider,
        or to `provider`)."""
        data = self._read()
        provider = provider if provider in PROVIDERS else data["provider"]
        return {
            "provider": provider,
            "model": data["models"].get(provider) or "",
            "ollama_url": data.get("ollama_url") or "http://127.0.0.1:11434",
            "base_url": data.get("custom_url") or "",
            "api_key": self._key(data, provider) if provider != "ollama" else "",
        }

    def rekey(self, old_vault_key: Optional[bytes], new_vault_key: Optional[bytes]) -> None:
        """Vault migrator hook: re-encrypt (or decrypt) the stored keys when the master key changes."""
        data = self._read()
        if not data["keys"]:
            return
        from cryptography.fernet import Fernet
        for provider, key in list(data["keys"].items()):
            if not key:
                continue
            if key.startswith("enc:"):
                if not old_vault_key:
                    continue
                key = Fernet(old_vault_key).decrypt(key[4:].encode("ascii")).decode("utf-8")
            if new_vault_key:
                key = "enc:" + Fernet(new_vault_key).encrypt(key.encode("utf-8")).decode("ascii")
            data["keys"][provider] = key
        self._write(data)


# ---- model lists -------------------------------------------------------------------------------

_SKIP_MODEL = re.compile(r"embed|whisper|tts|audio|realtime|transcri|moderation|dall-e|image|davinci|babbage|"
                         r"guard|aqa|imagen|veo|search|computer-use|-instruct$", re.I)
_OPENAI_CHAT = re.compile(r"^(gpt-|o\d|chatgpt-)")
_MODELS_CACHE: Dict[Tuple[str, str], Tuple[float, List[Dict[str, str]]]] = {}
MODELS_CACHE_TTL = 600


def _get_json(url: str, headers: Dict[str, str], timeout: float = 15) -> Any:
    req = urllib.request.Request(url, headers={"Accept": "application/json", **headers})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _fetch_models(cfg: Dict[str, Any]) -> List[Dict[str, str]]:
    provider, key = cfg["provider"], cfg.get("api_key") or ""
    if provider == "ollama":
        tags = _get_json((cfg.get("ollama_url") or "http://127.0.0.1:11434").rstrip("/") + "/api/tags", {}, 5)
        out = []
        for m in tags.get("models") or []:
            size = (m.get("details") or {}).get("parameter_size") or ""
            out.append({"id": m["name"], "label": m["name"] + (f" · {size}" if size else ""), "group": "Installed"})
        return out
    if provider == "anthropic":
        data = _get_json("https://api.anthropic.com/v1/models?limit=1000",
                         {"x-api-key": key, "anthropic-version": "2023-06-01"})
        return [{"id": m["id"], "label": m.get("display_name") or m["id"]} for m in data.get("data") or []]
    if provider == "gemini":
        data = _get_json("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000", {"x-goog-api-key": key})
        out = []
        for m in data.get("models") or []:
            mid = (m.get("name") or "").removeprefix("models/")
            if "generateContent" in (m.get("supportedGenerationMethods") or []) and mid and not _SKIP_MODEL.search(mid):
                out.append({"id": mid, "label": m.get("displayName") or mid})
        return out
    base = cfg.get("base_url") if provider == "custom" else PROVIDER_INFO[provider]["base_url"]
    data = _get_json(base.rstrip("/") + "/models", {k: v for k, v in _bearer(key).items() if k != "Content-Type"})
    out = []
    for m in data.get("data") or []:
        mid = m.get("id") or ""
        if not mid or _SKIP_MODEL.search(mid) or (provider == "openai" and not _OPENAI_CHAT.match(mid)):
            continue
        entry = {"id": mid, "label": m.get("name") or mid}
        if provider == "openrouter":  # hundreds of models: group them by vendor
            entry["group"] = mid.split("/", 1)[0] if "/" in mid else "Other"
            if mid.endswith(":free"):
                entry["label"] += " · free"
        out.append(entry)
    return out


def list_models(cfg: Dict[str, Any], refresh: bool = False) -> Dict[str, Any]:
    """Models the provider offers to this key: {"models": [{id, label, group?}], "error", "live"}.
    Without a key (or when the request fails) only the default model is suggested."""
    provider = cfg.get("provider") or "ollama"
    meta = PROVIDER_INFO.get(provider) or {}
    cache_key = (provider, (cfg.get("api_key") or "")[-8:] + (cfg.get("base_url") or "") + (cfg.get("ollama_url") or ""))
    now = time.monotonic()
    if not refresh and cache_key in _MODELS_CACHE and now - _MODELS_CACHE[cache_key][0] < MODELS_CACHE_TTL:
        return {"models": _MODELS_CACHE[cache_key][1], "error": "", "live": True}
    fallback = [{"id": meta["default"], "label": meta["default"]}] if meta.get("default") else []
    if meta.get("key", True) is True and not cfg.get("api_key"):
        return {"models": fallback, "error": "", "live": False}
    if provider == "custom" and not cfg.get("base_url"):
        return {"models": [], "error": "", "live": False}
    try:
        models = _fetch_models(cfg)
    except Exception as exc:  # noqa: BLE001
        return {"models": fallback, "error": _http_error_message(exc, provider_label(provider)), "live": False}
    seen, unique = set(), []
    for m in models:
        if m["id"] not in seen and MODEL_ID_RE.match(m["id"]):
            seen.add(m["id"])
            unique.append(m)
    unique.sort(key=lambda m: (m.get("group") or "", m["id"]))
    if provider in ("anthropic", "gemini", "openai"):
        unique.sort(key=lambda m: m["id"], reverse=True)  # newest names first
    _MODELS_CACHE[cache_key] = (now, unique)
    return {"models": unique, "error": "", "live": True}


MODEL_ID_RE = re.compile(r"^[A-Za-z0-9._:/@-]{1,200}$")


def _resolve_error_file(project_path: str, file_hint: str, message: str, trace: str) -> tuple[Optional[Path], int]:
    """Finds the best project file & line referenced in the error or stack trace."""
    root = Path(project_path).resolve()
    candidates = []
    if file_hint:
        candidates.append((file_hint, 1))

    combined = f"{message}\n{trace}"
    for m in re.finditer(r"(/[^\s:()\"']+\.php)(?:\((\d+)\)|:(\d+))?", combined):
        fpath = m.group(1)
        fline = int(m.group(2) or m.group(3) or 1)
        candidates.append((fpath, fline))

    for m in re.finditer(r"\b((?:app|routes|config|database|resources)/[^\s:()\"']+\.php)(?:\((\d+)\)|:(\d+))?", combined):
        rel = m.group(1)
        fline = int(m.group(2) or m.group(3) or 1)
        candidates.append((str(root / rel), fline))

    # Prefer files inside the project (excluding vendor/)
    for fpath, fline in candidates:
        p = Path(fpath)
        if not p.is_absolute():
            p = root / p
        try:
            rp = p.resolve()
            if rp.is_file() and rp.is_relative_to(root) and "vendor" not in rp.relative_to(root).parts:
                return rp, fline
        except Exception:
            continue

    return None, 1


def _extract_code_block(response_text: str) -> Optional[str]:
    """Extracts the first fenced code block from an LLM response."""
    m = re.search(r"```(?:php|html|js|json|env)?\s*\n(.*?)```", response_text, re.DOTALL)
    if m:
        return m.group(1)
    return None


def propose_fix(
    project_path: str,
    error_message: str,
    file_path: str = "",
    line: int = 1,
    trace: str = "",
    custom_prompt: str = "",
    ai_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Analyzes a Laravel error or doctor issue, locates the relevant project file,
    queries the configured AI provider (or heuristic analyzer), and returns a unified diff.
    """
    root = Path(project_path).resolve()
    target_path, detected_line = _resolve_error_file(project_path, file_path, error_message, trace)
    line_num = int(line or detected_line or 1)

    original_content = ""
    rel_name = "file.php"
    has_backup = False

    if target_path and target_path.is_file():
        try:
            original_content = target_path.read_text(encoding="utf-8")
            rel_name = str(target_path.relative_to(root))
            has_backup = target_path.with_suffix(target_path.suffix + ".ldbak").is_file()
        except Exception:
            pass

    cfg = ai_config or {}
    provider = (cfg.get("provider") or "ollama").lower()

    prompt = (
        f"You are a senior Laravel developer fixing an issue in a local project.\n"
        f"Error: {error_message}\n"
        f"File: {rel_name} (line {line_num})\n"
    )
    if custom_prompt:
        prompt += f"Additional instructions: {custom_prompt}\n"
    if trace:
        prompt += f"Stack trace snippet:\n{trace[:1500]}\n"
    if original_content:
        prompt += (
            f"\nCurrent content of `{rel_name}`:\n```php\n{original_content}\n```\n\n"
            f"Provide a short explanation of the root cause, followed by the COMPLETE updated file inside a ```php ... ``` code block."
        )
    else:
        prompt += "\nExplain the cause of this issue and show the exact code or command to fix it."

    llm_reply, ai_error = ask_llm(prompt, cfg)

    proposed_content = original_content
    explanation = ""

    if llm_reply:
        extracted = _extract_code_block(llm_reply)
        if extracted and original_content:
            proposed_content = extracted
        explanation = re.sub(r"```.*?```", "", llm_reply, flags=re.DOTALL).strip() or llm_reply.strip()
    else:
        # Helpful heuristic diagnosis when no LLM is reachable yet
        explanation = (
            (f"AI provider unavailable: {ai_error}\n\n" if ai_error else "")
            + f"Diagnostic analysis for: {error_message}\n"
            f"• Target file: {rel_name} (around line {line_num})\n"
            f"• Tip: You can edit the code directly below to preview the Unified Diff and apply it with an automatic .ldbak backup, "
            f"or configure your preferred AI provider (Ollama / Gemini / OpenAI / Anthropic) in Settings."
        )

    diff_text = generate_diff(original_content, proposed_content, rel_name) if original_content else ""

    return {
        "ok": True,
        "provider": provider,
        "ai_connected": bool(llm_reply),
        "ai_error": ai_error,
        "file_path": str(target_path) if target_path else "",
        "rel_file": rel_name,
        "line": line_num,
        "has_backup": has_backup,
        "explanation": explanation,
        "original_content": original_content,
        "proposed_content": proposed_content,
        "diff": diff_text,
    }
