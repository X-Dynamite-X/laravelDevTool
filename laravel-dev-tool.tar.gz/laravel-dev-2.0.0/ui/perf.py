"""Performance Monitor & Dev Profiler Engine.
Collects and analyzes HTTP request timings from Nginx JSON access logs (Level 1)
and detailed queries, cache, external HTTP calls, and N+1 alerts via local UDP profiler (Level 2).
"""

from __future__ import annotations

import collections
import datetime
import json
import math
import os
from pathlib import Path
import queue
import re
import socket
import sqlite3
import threading
import time
import zlib
from typing import Any

# Static asset extensions and URL prefixes to ignore in Level 1 requests
STATIC_EXTENSIONS = (
    ".css", ".js", ".mjs", ".map", ".ico", ".png", ".jpg", ".jpeg", ".gif",
    ".svg", ".webp", ".woff", ".woff2", ".ttf", ".eot", ".otf", ".mp4",
    ".webm", ".mp3", ".wav", ".json", ".txt"
)
STATIC_PREFIXES = (
    "/@vite", "/build/", "/vendor/", "/assets/", "/favicon.ico", "/__vite_ping"
)

# Global in-memory storage for UDP profiler requests: site_name -> deque of requests
_SITE_REQUESTS: dict[str, collections.deque[dict[str, Any]]] = collections.defaultdict(lambda: collections.deque(maxlen=500))
_PERF_LOCK = threading.Lock()
_UDP_SERVER_INSTANCE = None


def normalize_sql(sql: str) -> str:
    """Normalize SQL by replacing literals, numbers, and lists to detect repeating patterns."""
    if not sql:
        return ""
    # Strip string literals
    s = re.sub(r"'[^']*'", "?", sql)
    # Strip numeric literals
    s = re.sub(r"\b0x[0-9a-fA-F]+\b", "?", s)
    s = re.sub(r"\b\d+\b", "?", s)
    # Normalize IN (?, ?, ...)
    s = re.sub(r"IN\s*\(\s*\?(?:\s*,\s*\?)*\s*\)", "IN (?)", s, flags=re.IGNORECASE)
    # Normalize whitespace
    return re.sub(r"\s+", " ", s).strip()


def interpolate_sql(sql: str, bindings: list[Any] | None) -> str:
    """Safely interpolate bindings into SQL query with question mark placeholders for display."""
    if not sql:
        return ""
    if not bindings:
        return sql

    parts = sql.split("?")
    if len(parts) - 1 != len(bindings):
        return sql

    out = []
    for i, part in enumerate(parts[:-1]):
        out.append(part)
        b = bindings[i]
        if b is None:
            out.append("NULL")
        elif isinstance(b, (int, float)):
            out.append(str(b))
        elif isinstance(b, bool):
            out.append("1" if b else "0")
        else:
            clean_str = str(b).replace("'", "''")
            out.append(f"'{clean_str}'")
    out.append(parts[-1])
    return "".join(out)


def get_query_type(sql: str) -> str:
    """Classify SQL statement by verb (SELECT, INSERT, UPDATE, DELETE, etc.)."""
    s = (sql or "").strip().upper()
    if s.startswith("SELECT"):
        return "SELECT"
    if s.startswith("INSERT"):
        return "INSERT"
    if s.startswith("UPDATE"):
        return "UPDATE"
    if s.startswith("DELETE"):
        return "DELETE"
    if any(s.startswith(w) for w in ("CREATE", "ALTER", "DROP", "TRUNCATE")):
        return "SCHEMA"
    return "QUERY"


def get_speed_classification(duration_ms: float) -> dict[str, str]:
    """Classify query execution time into Telescope speed tiers."""
    t = float(duration_ms or 0.0)
    if t < 5.0:
        return {"level": "fast", "label": "Fast (<5ms)", "css": "speed-fast"}
    if t < 30.0:
        return {"level": "normal", "label": "Normal (5-30ms)", "css": "speed-normal"}
    if t < 100.0:
        return {"level": "moderate", "label": "Moderate (30-100ms)", "css": "speed-moderate"}
    return {"level": "slow", "label": "Slow (>100ms)", "css": "speed-slow"}


def detect_n_plus_one(queries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Detect queries with identical normalized pattern repeated >= 5 times from same caller."""
    groups: dict[tuple[str, str], list[dict[str, Any]]] = collections.defaultdict(list)
    for q in queries:
        norm = normalize_sql(q.get("sql", ""))
        caller = f"{q.get('file', '')}:{q.get('line', 0)}"
        groups[(norm, caller)].append(q)

    alerts = []
    for (norm, caller), items in groups.items():
        if len(items) >= 5:
            first = items[0]
            total_time = round(sum(i.get("time_ms", 0.0) for i in items), 2)
            alerts.append({
                "pattern": norm,
                "count": len(items),
                "total_time_ms": total_time,
                "caller": caller,
                "file": first.get("file", ""),
                "line": first.get("line", 0),
                "suggestion": "Possible N+1 query. Consider eager loading relationships with ->with('...').",
            })
    return sorted(alerts, key=lambda a: a["count"], reverse=True)


def detect_duplicate_queries(queries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Detect queries with identical SQL and identical bindings executed > 1 times."""
    groups: dict[tuple[str, str], list[dict[str, Any]]] = collections.defaultdict(list)
    for q in queries:
        sql = q.get("sql", "").strip()
        bindings = tuple(str(b) for b in q.get("bindings", []))
        groups[(sql, str(bindings))].append(q)

    dupes = []
    for (sql, _), items in groups.items():
        if len(items) > 1:
            first = items[0]
            caller = f"{first.get('file', '')}:{first.get('line', 0)}"
            total_time = round(sum(i.get("time_ms", 0.0) for i in items), 2)
            dupes.append({
                "sql": sql,
                "count": len(items),
                "total_time_ms": total_time,
                "caller": caller,
                "file": first.get("file", ""),
                "line": first.get("line", 0),
                "suggestion": "Duplicate identical query executed multiple times. Consider memoization or cache.",
            })
    return sorted(dupes, key=lambda d: d["count"], reverse=True)


def detect_slow_queries(queries: list[dict[str, Any]], threshold_ms: float = 100.0) -> list[dict[str, Any]]:
    """Flag queries with execution time >= threshold."""
    slow = []
    for q in queries:
        t = float(q.get("time_ms", 0.0))
        if t >= threshold_ms:
            caller = f"{q.get('file', '')}:{q.get('line', 0)}"
            slow.append({
                "sql": q.get("sql", ""),
                "time_ms": t,
                "connection": q.get("connection", "default"),
                "caller": caller,
                "file": q.get("file", ""),
                "line": q.get("line", 0),
            })
    return sorted(slow, key=lambda s: s["time_ms"], reverse=True)


def generate_waterfall_timeline(req: dict[str, Any]) -> list[dict[str, Any]]:
    """Build waterfall timeline segments for request execution."""
    timeline = []
    dur = float(req.get("duration_ms", 0.0))
    boot = float(req.get("boot_ms", 0.0))

    if boot > 0:
        timeline.append({
            "name": "Framework Boot",
            "type": "boot",
            "start_ms": 0.0,
            "duration_ms": min(boot, dur),
            "percentage": min(100.0, round((boot / (dur or 1.0)) * 100, 1)),
        })

    # Database query time
    q_time = float(req.get("query_time_ms", 0.0))
    if q_time > 0:
        q_start = min(boot, dur)
        timeline.append({
            "name": f"Database ({req.get('query_count', 0)} queries)",
            "type": "database",
            "start_ms": round(q_start, 2),
            "duration_ms": min(q_time, dur),
            "percentage": min(100.0, round((q_time / (dur or 1.0)) * 100, 1)),
        })

    # External HTTP calls
    http_time = sum(float(h.get("duration_ms", 0.0)) for h in req.get("http_calls", []))
    if http_time > 0:
        h_start = min(boot + q_time, dur)
        timeline.append({
            "name": f"External HTTP ({len(req.get('http_calls', []))} calls)",
            "type": "http",
            "start_ms": round(h_start, 2),
            "duration_ms": min(http_time, dur),
            "percentage": min(100.0, round((http_time / (dur or 1.0)) * 100, 1)),
        })

    # Application execution (Controller & Views)
    app_time = max(0.0, dur - (boot + q_time + http_time))
    if app_time > 0:
        app_start = min(boot + q_time + http_time, dur)
        timeline.append({
            "name": f"Application ({req.get('action') or 'Controller & Views'})",
            "type": "app",
            "start_ms": round(app_start, 2),
            "duration_ms": round(app_time, 2),
            "percentage": min(100.0, round((app_time / (dur or 1.0)) * 100, 1)),
        })

    return timeline


# ── Level 1: Nginx JSON & Access Logs Reader ────────────────────────────────

COMBINED_LOG_RE = re.compile(
    r'^(\S+)\s+\S+\s+\S+\s+\[([^\]]+)\]\s+"([A-Z]+)\s+([^"\s]+)(?:\s+HTTP/[^"]+)?"\s+(\d{3})\s+(\d+|-)(?:\s+"([^"]*)"\s+"([^"]*)")?'
)


def get_nginx_requests(
    site_name: str,
    limit: int = 100,
    filter_assets: bool = True,
    status_filter: str = "",
    min_duration_ms: float = 0.0,
    search: str = ""
) -> dict[str, Any]:
    """Parse Nginx JSON access log or fall back to /var/log/nginx/access.log."""
    log_candidates = [
        Path(f"/var/log/nginx/laravel-dev/{site_name}.json"),
        Path(f"/var/log/nginx/laravel-dev/{site_name.replace('-', '_')}.json"),
        Path(f"/var/log/nginx/laravel-dev/{site_name.replace('_', '-')}.json"),
        Path.home() / ".config" / "laravel-dev" / "logs" / f"{site_name}.json",
    ]
    site_domain = ""
    site_type = ""
    try:
        import sites
        s = sites.find_site(site_name)
        if s:
            site_domain = (s.get("domain") or "").lower()
            site_type = (s.get("type") or "").lower()
            if site_domain:
                log_candidates.append(Path(f"/var/log/nginx/laravel-dev/{site_domain}.json"))
        # The other registered sites' domains, to skip their requests in the shared access.log.
        other_domains = [d for d in ((x.get("domain") or "").lower() for x in sites.list_sites()) if d and d != site_domain]
    except Exception:
        other_domains = []

    log_path = None
    is_json_format = False
    for cand in log_candidates:
        if cand.is_file() and cand.stat().st_size > 0:
            log_path = cand
            is_json_format = True
            break

    # No fallback to the shared /var/log/nginx/access.log: it mixes every site's
    # requests and has no timings, so the numbers would be misleading. A site whose
    # nginx config predates per-site JSON logs just needs a Repair.
    if not log_path:
        return {
            "ok": True,
            "exists": False,
            "needs_repair": True,
            "hint": "This site's nginx config has no per-request timing log yet. Run Repair once to regenerate it.",
            "log_file": str(log_candidates[0]),
            "summary": {
                "total": 0, "p50": 0, "p90": 0, "p95": 0, "p99": 0,
                "avg": 0, "error_count": 0, "error_rate": 0, "status_counts": {}, "slowest_paths": []
            },
            "requests": []
        }

    requests = []
    durations = []
    status_counts: dict[int, int] = collections.defaultdict(int)
    path_timings: dict[str, list[float]] = collections.defaultdict(list)
    error_count = 0

    search_lower = search.strip().lower()
    status_filter = status_filter.strip().lower()

    try:
        size = log_path.stat().st_size
        max_bytes = 4 * 1024 * 1024  # Read last 4MB
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            if size > max_bytes:
                f.seek(size - max_bytes)
                f.readline()  # discard partial line
            lines = f.readlines()
    except Exception as exc:
        return {"ok": False, "error": f"Failed to read access log: {exc}"}

    # Process in reverse (newest requests first)
    for line in reversed(lines):
        line = line.strip()
        if not line:
            continue

        if is_json_format:
            if not line.startswith("{"):
                continue
            try:
                entry = json.loads(line)
            except Exception:
                continue

            ua = entry.get("ua") or ""
            uri = entry.get("u") or "/"
            if "LaravelDev-Uptime" in ua or uri == "/up":
                continue

            clean_path = uri.split("?")[0]
            if filter_assets:
                if any(clean_path.lower().endswith(ext) for ext in STATIC_EXTENSIONS):
                    continue
                if any(clean_path.startswith(prefix) for prefix in STATIC_PREFIXES):
                    continue

            try:
                duration_sec = float(entry.get("rt") or 0.0)
                duration_ms = round(duration_sec * 1000, 1)
            except (ValueError, TypeError):
                duration_ms = 0.0

            status = int(entry.get("s") or 200)

            if min_duration_ms > 0 and duration_ms < min_duration_ms:
                continue

            if status_filter:
                if status_filter == "4xx" and not (400 <= status < 500):
                    continue
                if status_filter == "5xx" and not (500 <= status < 600):
                    continue
                if status_filter.isdigit() and status != int(status_filter):
                    continue

            if search_lower:
                method = (entry.get("m") or "").lower()
                if search_lower not in uri.lower() and search_lower not in method:
                    continue

            durations.append(duration_ms)
            status_counts[status] += 1
            if status >= 400:
                error_count += 1
            path_timings[clean_path].append(duration_ms)

            if len(requests) < limit:
                requests.append({
                    "time": entry.get("t") or "",
                    "method": entry.get("m") or "GET",
                    "uri": uri,
                    "path": clean_path,
                    "status": status,
                    "bytes": int(entry.get("b") or 0),
                    "duration_ms": duration_ms,
                    "upstream_time": entry.get("ut") or "",
                    "upstream_header_time": entry.get("uht") or "",
                    "upstream_connect_time": entry.get("uct") or "",
                    "upstream_status": entry.get("us") or "",
                    "upstream_addr": entry.get("uaddr") or "",
                    "ip": entry.get("ip") or "",
                    "host": entry.get("h") or "",
                    "referer": entry.get("ref") or "",
                    "user_agent": ua,
                })

        else:
            # Combined format fallback
            m = COMBINED_LOG_RE.match(line)
            if not m:
                continue
            ip, t_str, method, uri, s_str, b_str, ref, ua = m.groups()
            ua = ua or ""
            ref = ref or ""

            # Filter out internal uptime health checks
            if "LaravelDev-Uptime" in ua or uri == "/up":
                continue

            # Associate request with site
            ref_lower = ref.lower()
            if site_domain:
                # If referer is present and mentions another known domain, skip
                if ref_lower and ref_lower != "-" and site_domain not in ref_lower:
                    if any(d in ref_lower for d in other_domains):
                        continue

            clean_path = uri.split("?")[0]
            if filter_assets:
                if any(clean_path.lower().endswith(ext) for ext in STATIC_EXTENSIONS):
                    continue
                if any(clean_path.startswith(prefix) for prefix in STATIC_PREFIXES):
                    continue

            status = int(s_str)
            b_sent = int(b_str) if b_str and b_str.isdigit() else 0
            duration_ms = 1.0  # combined log doesn't include rt; fallback to 1ms

            if min_duration_ms > 0 and duration_ms < min_duration_ms:
                continue

            if status_filter:
                if status_filter == "4xx" and not (400 <= status < 500):
                    continue
                if status_filter == "5xx" and not (500 <= status < 600):
                    continue
                if status_filter.isdigit() and status != int(status_filter):
                    continue

            if search_lower:
                if search_lower not in uri.lower() and search_lower not in method.lower():
                    continue

            durations.append(duration_ms)
            status_counts[status] += 1
            if status >= 400:
                error_count += 1
            path_timings[clean_path].append(duration_ms)

            if len(requests) < limit:
                requests.append({
                    "time": t_str,
                    "method": method,
                    "uri": uri,
                    "path": clean_path,
                    "status": status,
                    "bytes": b_sent,
                    "duration_ms": duration_ms,
                    "upstream_time": "",
                    "upstream_status": str(status),
                    "upstream_addr": "",
                    "ip": ip,
                    "host": site_domain or "",
                    "referer": ref,
                    "user_agent": ua,
                })

    total = len(durations)
    durations_sorted = sorted(durations)

    def percentile(p: float) -> float:
        if not durations_sorted:
            return 0.0
        k = (len(durations_sorted) - 1) * (p / 100.0)
        f = math.floor(k)
        c = math.ceil(k)
        if f == c:
            return round(durations_sorted[int(k)], 1)
        d0 = durations_sorted[int(f)] * (c - k)
        d1 = durations_sorted[int(c)] * (k - f)
        return round(d0 + d1, 1)

    # Top 5 slowest paths
    slowest_paths = []
    for p, times in path_timings.items():
        slowest_paths.append({
            "path": p,
            "count": len(times),
            "avg_ms": round(sum(times) / len(times), 1),
            "max_ms": round(max(times), 1),
        })
    slowest_paths = sorted(slowest_paths, key=lambda x: x["max_ms"], reverse=True)[:5]

    summary = {
        "total": total,
        "p50": percentile(50),
        "p90": percentile(90),
        "p95": percentile(95),
        "p99": percentile(99),
        "avg": round(sum(durations) / total, 1) if total else 0.0,
        "error_count": error_count,
        "error_rate": round((error_count / total) * 100, 1) if total else 0.0,
        "status_counts": dict(status_counts),
        "slowest_paths": slowest_paths,
    }

    return {
        "ok": True,
        "exists": True,
        "log_file": str(log_path),
        "summary": summary,
        "requests": requests,
    }


# ── Level 2: UDP Profiler Server & Storage ───────────────────────────────────

def get_perf_db(site_name: str) -> sqlite3.Connection:
    """Get or initialize SQLite storage connection for a site."""
    dir_path = Path.home() / ".config" / "laravel-dev" / "perf"
    dir_path.mkdir(parents=True, exist_ok=True)
    db_file = dir_path / f"{site_name}.sqlite"
    conn = sqlite3.connect(str(db_file), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    with conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS requests (
                id TEXT PRIMARY KEY,
                created_at REAL,
                method TEXT,
                uri TEXT,
                route TEXT,
                action TEXT,
                status INTEGER,
                duration_ms REAL,
                memory_mb REAL,
                query_count INTEGER,
                query_time_ms REAL,
                n_plus_one_count INTEGER,
                data TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_req_created ON requests (created_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_req_route ON requests (route)")
    return conn


def resolve_canonical_site(payload_site: str, payload_path: str = "", payload_host: str = "", payload_folder: str = "") -> str:
    """Resolve incoming payload identifiers to registered site name in laravel-dev."""
    clean_site = (payload_site or "").strip()
    clean_host = (payload_host or "").strip().lower()
    clean_folder = (payload_folder or "").strip().lower()
    clean_path = (payload_path or "").rstrip("/\\").lower()

    try:
        import sites
        all_sites = sites.list_sites()
    except Exception:
        all_sites = []

    # 1. Path match
    if clean_path:
        for s in all_sites:
            s_path = (s.get("path") or "").rstrip("/\\").lower()
            if s_path and (clean_path == s_path or clean_path.startswith(s_path)):
                return s.get("name") or clean_site

    # 2. Name / Domain / Folder match
    s_lower = clean_site.lower()
    for s in all_sites:
        name = (s.get("name") or "").lower()
        domain = (s.get("domain") or "").lower()
        folder = Path(s.get("path") or "").name.lower()
        if s_lower in (name, domain, folder) or clean_host in (name, domain) or clean_folder in (name, folder):
            return s.get("name") or clean_site
        if s_lower.replace("_", "-") == name or s_lower.replace("-", "_") == name:
            return s.get("name") or clean_site

    return clean_site or "unknown"


def get_site_aliases(site_name: str) -> set[str]:
    """Return all possible lookup names for a site (hyphenated, underscored, folder, domain)."""
    aliases = {site_name, site_name.lower(), site_name.replace("-", "_"), site_name.replace("_", "-")}
    try:
        import sites
        s = sites.find_site(site_name)
        if s:
            if s.get("name"):
                aliases.add(s["name"])
                aliases.add(s["name"].lower())
            if s.get("domain"):
                aliases.add(s["domain"].lower())
            if s.get("path"):
                aliases.add(Path(s["path"]).name)
                aliases.add(Path(s["path"]).name.lower())
    except Exception:
        pass
    return {a for a in aliases if a}


class PerfUDPServer:
    """Lightweight UDP receiver on 127.0.0.1:9913 for Level 2 profiler packets."""

    def __init__(self, host: str = "127.0.0.1", port: int = 9913, emit_fn: Any = None):
        self.host = host
        self.port = port
        self.emit_fn = emit_fn
        self.sock: socket.socket | None = None
        self.running = False
        self.thread: threading.Thread | None = None
        self.db_queue: queue.Queue[tuple[str, dict[str, Any]]] = queue.Queue(maxsize=1000)
        self.db_thread: threading.Thread | None = None

    def start(self):
        if self.running:
            return
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind((self.host, self.port))
            self.sock.settimeout(1.0)
            self.running = True
        except Exception as exc:
            self.running = False
            return

        self.thread = threading.Thread(target=self._listen_loop, daemon=True)
        self.thread.start()

        self.db_thread = threading.Thread(target=self._db_worker, daemon=True)
        self.db_thread.start()

    def _listen_loop(self):
        while self.running and self.sock:
            try:
                data, _ = self.sock.recvfrom(65535)
                if not data:
                    continue
                self._handle_packet(data)
            except socket.timeout:
                continue
            except Exception:
                continue

    def _handle_packet(self, raw_bytes: bytes):
        try:
            payload = json.loads(raw_bytes.decode("utf-8", errors="replace"))
        except Exception:
            return

        raw_site = payload.get("site") or ""
        raw_path = payload.get("path") or ""
        raw_host = payload.get("host") or ""
        raw_folder = payload.get("folder") or ""
        ua = payload.get("user_agent") or ""
        uri = payload.get("uri") or ""

        # Ignore background uptime monitor checks completely
        if "LaravelDev-Uptime" in ua or uri == "/up":
            return

        site_name = resolve_canonical_site(raw_site, raw_path, raw_host, raw_folder)
        payload["canonical_site"] = site_name
        queries = payload.get("queries") or []

        # Enrich queries with SQL interpolation, classification and execution speed
        for q in queries:
            sql = q.get("sql") or ""
            b = q.get("bindings") or []
            q["interpolated_sql"] = interpolate_sql(sql, b)
            q["query_type"] = get_query_type(sql)
            q["speed"] = get_speed_classification(q.get("time_ms", 0.0))

        # Run analyzers
        n_plus_one = detect_n_plus_one(queries)
        duplicates = detect_duplicate_queries(queries)
        slow_queries = detect_slow_queries(queries, threshold_ms=100.0)

        payload["insights"] = {
            "n_plus_one": n_plus_one,
            "duplicates": duplicates,
            "slow_queries": slow_queries,
        }
        payload["n_plus_one_count"] = len(n_plus_one)
        payload["query_count"] = len(queries)
        payload["query_time_ms"] = round(sum(q.get("time_ms", 0.0) for q in queries), 2)
        payload["timeline"] = generate_waterfall_timeline(payload)

        with _PERF_LOCK:
            _SITE_REQUESTS[site_name].appendleft(payload)
            if raw_site and raw_site != site_name:
                _SITE_REQUESTS[raw_site].appendleft(payload)

        # Notify UI via live event if callback provided
        if self.emit_fn:
            try:
                self.emit_fn({"type": "perf_request", "site": site_name, "request": payload})
            except Exception:
                pass

        # Queue async DB save
        try:
            self.db_queue.put_nowait((site_name, payload))
        except queue.Full:
            pass

    def _db_worker(self):
        """Asynchronously writes requests to SQLite databases."""
        db_connections: dict[str, sqlite3.Connection] = {}
        while self.running:
            try:
                item = self.db_queue.get(timeout=1.0)
            except queue.Empty:
                continue

            site_name, payload = item
            try:
                if site_name not in db_connections:
                    db_connections[site_name] = get_perf_db(site_name)
                conn = db_connections[site_name]
                with conn:
                    conn.execute("""
                        INSERT OR REPLACE INTO requests
                        (id, created_at, method, uri, route, action, status, duration_ms, memory_mb, query_count, query_time_ms, n_plus_one_count, data)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        payload.get("id"),
                        float(payload.get("time") or time.time()),
                        payload.get("method") or "GET",
                        payload.get("uri") or "/",
                        payload.get("route") or "",
                        payload.get("action") or "",
                        int(payload.get("status") or 200),
                        float(payload.get("duration_ms") or 0.0),
                        float(payload.get("memory_peak_mb") or 0.0),
                        int(payload.get("query_count") or 0),
                        float(payload.get("query_time_ms") or 0.0),
                        int(payload.get("n_plus_one_count") or 0),
                        json.dumps(payload),
                    ))
            except Exception:
                pass
            finally:
                self.db_queue.task_done()

    def stop(self):
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass


def ensure_udp_server(emit_fn: Any = None):
    """Ensure background UDP listener is started with optional live UI callback."""
    global _UDP_SERVER_INSTANCE
    if _UDP_SERVER_INSTANCE is None:
        _UDP_SERVER_INSTANCE = PerfUDPServer(emit_fn=emit_fn)
        _UDP_SERVER_INSTANCE.start()
    elif emit_fn and not _UDP_SERVER_INSTANCE.emit_fn:
        _UDP_SERVER_INSTANCE.emit_fn = emit_fn
    return _UDP_SERVER_INSTANCE


def get_profiled_requests(
    site_name: str,
    limit: int = 50,
    n_plus_one_only: bool = False,
    route: str = ""
) -> dict[str, Any]:
    """Retrieve profiled requests from memory buffer or SQLite with analytics, skipping uptime pings."""
    ensure_udp_server()
    requests = []

    aliases = get_site_aliases(site_name)

    with _PERF_LOCK:
        in_memory = []
        seen_ids = set()
        for alias in aliases:
            for r in _SITE_REQUESTS.get(alias, []):
                rid = r.get("id")
                if rid and rid not in seen_ids:
                    seen_ids.add(rid)
                    in_memory.append(r)
        in_memory.sort(key=lambda x: float(x.get("time") or 0.0), reverse=True)

    route_lower = route.strip().lower()
    for req in in_memory:
        uri = req.get("uri") or ""
        ua = req.get("user_agent") or ""
        if uri == "/up" or "LaravelDev-Uptime" in ua:
            continue
        if n_plus_one_only and req.get("n_plus_one_count", 0) == 0:
            continue
        if route_lower and route_lower not in (req.get("route") or "").lower() and route_lower not in uri.lower():
            continue
        requests.append(req)
        if len(requests) >= limit:
            break

    # If memory has fewer than limit items, query SQLite to backfill
    remaining = limit - len(requests)
    if remaining > 0:
        for alias in aliases:
            try:
                conn = get_perf_db(alias)
                sql = "SELECT data FROM requests WHERE uri != '/up' AND (data NOT LIKE '%LaravelDev-Uptime%')"
                params = []
                if n_plus_one_only:
                    sql += " AND n_plus_one_count > 0"
                if route_lower:
                    sql += " AND (LOWER(route) LIKE ? OR LOWER(uri) LIKE ?)"
                    params.extend([f"%{route_lower}%", f"%{route_lower}%"])
                sql += " ORDER BY created_at DESC LIMIT ?"
                params.append(remaining)

                rows = conn.execute(sql, params).fetchall()
                for r in rows:
                    try:
                        parsed = json.loads(r["data"])
                        rid = parsed.get("id")
                        uri = parsed.get("uri") or ""
                        ua = parsed.get("user_agent") or ""
                        if rid and rid not in seen_ids and uri != "/up" and "LaravelDev-Uptime" not in ua:
                            seen_ids.add(rid)
                            requests.append(parsed)
                    except Exception:
                        pass
                if len(requests) >= limit:
                    break
            except Exception:
                pass

    # Ensure all queries are classified and formatted
    for req in requests:
        qs = req.get("queries") or []
        for q in qs:
            sql = q.get("sql") or ""
            b = q.get("bindings") or []
            if "interpolated_sql" not in q:
                q["interpolated_sql"] = interpolate_sql(sql, b)
            if "query_type" not in q:
                q["query_type"] = get_query_type(sql)
            if "speed" not in q:
                q["speed"] = get_speed_classification(q.get("time_ms", 0.0))

    # Aggregated metrics across retrieved requests
    total_reqs = len(requests)
    n_plus_one_total = sum(r.get("n_plus_one_count", 0) for r in requests)
    avg_queries = round(sum(r.get("query_count", 0) for r in requests) / total_reqs, 1) if total_reqs else 0
    avg_mem = round(sum(r.get("memory_peak_mb", 0.0) for r in requests) / total_reqs, 1) if total_reqs else 0
    avg_dur = round(sum(r.get("duration_ms", 0.0) for r in requests) / total_reqs, 1) if total_reqs else 0

    return {
        "ok": True,
        "site": site_name,
        "total": total_reqs,
        "avg_duration_ms": avg_dur,
        "avg_queries": avg_queries,
        "avg_memory_mb": avg_mem,
        "n_plus_one_total": n_plus_one_total,
        "requests": requests,
    }


def _iso_epoch(value: str) -> float:
    try:
        return datetime.datetime.fromisoformat(value).timestamp()
    except (TypeError, ValueError):
        return 0.0


def _nginx_id(method: str, uri: str, t: str) -> str:
    # crc32, not hash(): str hashes change on every start, so ids would go stale.
    return f"ng-{zlib.crc32(f'{method}:{uri}:{t[:19]}'.encode()):08x}"


def _nginx_network(nr: dict[str, Any]) -> dict[str, Any]:
    """What nginx saw of a request, in the shape the inspector's Timing/Headers tabs use."""
    def ms(v):
        try:
            return round(float(v) * 1000, 1)
        except (TypeError, ValueError):
            return None
    return {
        "total_ms": float(nr.get("duration_ms") or 0.0),
        "upstream_ms": ms(nr.get("upstream_time")),
        "upstream_header_ms": ms(nr.get("upstream_header_time")),
        "upstream_connect_ms": ms(nr.get("upstream_connect_time")),
        "upstream_status": nr.get("upstream_status") or "",
        "upstream_addr": nr.get("upstream_addr") or "",
        "bytes": nr.get("bytes") or 0,
        "remote_addr": nr.get("ip") or "",
        "host": nr.get("host") or "",
        "referer": nr.get("referer") or "",
        "user_agent": nr.get("user_agent") or "",
        "time_iso": nr.get("time") or "",
    }


def _nginx_item(nr: dict[str, Any]) -> dict[str, Any]:
    method = nr.get("method") or "GET"
    uri = nr.get("uri") or "/"
    t_iso = nr.get("time") or ""
    net = _nginx_network(nr)
    dur_ms = net["total_ms"]
    ut_ms = net["upstream_ms"] or 0.0
    timeline = []
    if ut_ms > 0:
        timeline.append({"name": "Upstream Application", "type": "app", "start_ms": 0.0,
                         "duration_ms": min(ut_ms, dur_ms),
                         "percentage": min(100.0, round((ut_ms / (dur_ms or 1.0)) * 100, 1))})
        overhead = max(0.0, dur_ms - ut_ms)
        if overhead > 0:
            timeline.append({"name": "Nginx Proxy / Network", "type": "boot", "start_ms": ut_ms,
                             "duration_ms": round(overhead, 1),
                             "percentage": min(100.0, round((overhead / (dur_ms or 1.0)) * 100, 1))})
    return {
        "id": _nginx_id(method, uri, t_iso),
        # nginx logs when the response ends; the request started duration earlier.
        "time": (_iso_epoch(t_iso) - dur_ms / 1000) if t_iso else 0.0,
        "time_iso": t_iso,
        "method": method,
        "uri": uri,
        "path": nr.get("path") or uri.split("?")[0],
        "status": int(nr.get("status") or 200),
        "duration_ms": dur_ms,
        "upstream_time_ms": ut_ms,
        "bytes": nr.get("bytes") or 0,
        "ip": nr.get("ip") or "",
        "host": nr.get("host") or "",
        "referer": nr.get("referer") or "",
        "user_agent": nr.get("user_agent") or "",
        "upstream_addr": nr.get("upstream_addr") or "",
        "upstream_status": nr.get("upstream_status") or "",
        "queries": [],
        "query_count": 0,
        "query_time_ms": 0.0,
        "n_plus_one_count": 0,
        "memory_peak_mb": 0.0,
        "timeline": timeline,
        "network": net,
        "source": "nginx",
    }


def _attach_network(profiled: list[dict[str, Any]], nginx_requests: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Pair each nginx log line with the profiler record of the same request (same
    method and path, started within a couple of seconds). Paired lines enrich the
    profiler record instead of showing up as a second row; the rest are returned."""
    by_key: dict[tuple[str, str], list[dict[str, Any]]] = collections.defaultdict(list)
    for r in profiled:
        by_key[((r.get("method") or "GET").upper(), (r.get("uri") or "/").split("?")[0])].append(r)
    unmatched = []
    for nr in nginx_requests:
        item = _nginx_item(nr)
        best = None
        for r in by_key.get((item["method"].upper(), item["path"]), []):
            if r.get("network"):
                continue
            gap = abs(float(r.get("time") or 0.0) - item["time"])
            if gap <= 3.0 and (best is None or gap < best[0]):
                best = (gap, r)
        if best:
            best[1]["network"] = item["network"]
        else:
            unmatched.append(item)
    return unmatched


def _with_network(site_name: str, req: dict[str, Any]) -> dict[str, Any]:
    if not req.get("network"):
        try:
            nginx = get_nginx_requests(site_name, limit=500, filter_assets=False).get("requests", [])
            _attach_network([req], nginx)
        except Exception:
            pass
    return req


def get_request_detail(site_name: str, request_id: str) -> dict[str, Any]:
    """Retrieve full detail for a single request including queries, timeline, and calls."""
    aliases = get_site_aliases(site_name)

    with _PERF_LOCK:
        for alias in aliases:
            for req in _SITE_REQUESTS.get(alias, []):
                if req.get("id") == request_id:
                    return {"ok": True, "request": _with_network(site_name, dict(req))}

    for alias in aliases:
        try:
            conn = get_perf_db(alias)
            row = conn.execute("SELECT data FROM requests WHERE id = ?", (request_id,)).fetchone()
            if row:
                req = json.loads(row["data"])
                for q in req.get("queries") or []:
                    sql = q.get("sql") or ""
                    b = q.get("bindings") or []
                    if "interpolated_sql" not in q:
                        q["interpolated_sql"] = interpolate_sql(sql, b)
                    if "query_type" not in q:
                        q["query_type"] = get_query_type(sql)
                    if "speed" not in q:
                        q["speed"] = get_speed_classification(q.get("time_ms", 0.0))
                return {"ok": True, "request": _with_network(site_name, req)}
        except Exception:
            pass

    # Nginx-only request (any framework)
    try:
        for nr in get_nginx_requests(site_name, limit=500, filter_assets=False).get("requests", []):
            item = _nginx_item(nr)
            if item["id"] == request_id:
                return {"ok": True, "request": item}
    except Exception:
        pass

    return {"ok": False, "error": f"Request {request_id} not found"}


def get_telescope_feed(
    site_name: str,
    limit: int = 100,
    category: str = "requests",  # "requests", "queries", "errors", "slow"
    search: str = "",
    status_filter: str = "",
    min_duration_ms: float = 0.0,
    filter_assets: bool = True,
) -> dict[str, Any]:
    """Unified Laravel Telescope-style monitoring feed for any framework."""
    ensure_udp_server()

    # 1. Fetch rich profiled requests (Level 2)
    profiled_res = get_profiled_requests(site_name, limit=limit, n_plus_one_only=False, route=search)
    profiled_requests = profiled_res.get("requests", [])

    # 2. Fetch Nginx requests (Level 1, works across all frameworks)
    nginx_res = get_nginx_requests(
        site_name, limit=limit, filter_assets=filter_assets,
        status_filter=status_filter, min_duration_ms=min_duration_ms, search=search
    )
    nginx_requests = nginx_res.get("requests", [])

    # 3. Merge: a request the profiler recorded is one row, enriched with nginx's view of it.
    profiled_requests = [dict(r) for r in profiled_requests]  # don't mutate the shared buffer
    merged_requests = profiled_requests + _attach_network(profiled_requests, nginx_requests)

    merged_requests.sort(key=lambda x: float(x.get("time") or 0.0), reverse=True)

    # Collect and aggregate queries across all requests
    seen_queries = collections.defaultdict(list)
    for req in merged_requests:
        for q in req.get("queries") or []:
            sql = q.get("sql", "").strip()
            norm = normalize_sql(sql)
            t_ms = float(q.get("time_ms") or 0.0)
            seen_queries[norm].append({
                "sql": sql,
                "normalized": norm,
                "bindings": q.get("bindings") or [],
                "time_ms": t_ms,
                "connection": q.get("connection") or "default",
                "file": q.get("file") or "",
                "line": q.get("line") or 0,
                "caller": f"{q.get('file', '')}:{q.get('line', 0)}",
                "request_id": req.get("id"),
                "request_uri": req.get("uri"),
                "request_method": req.get("method"),
                "request_time": req.get("time"),
                "start_ms": q.get("start_ms"),
            })

    aggregated_queries = []
    for norm, items in seen_queries.items():
        total_q_time = round(sum(i["time_ms"] for i in items), 2)
        times = sorted(i["time_ms"] for i in items)
        first = items[0]
        sql_str = first["sql"]
        b_list = first["bindings"]
        avg_time = round(total_q_time / len(items), 2)
        q_type = get_query_type(sql_str)
        speed_info = get_speed_classification(avg_time)
        interpolated = interpolate_sql(sql_str, b_list)

        aggregated_queries.append({
            "sql": sql_str,
            "interpolated_sql": interpolated,
            "query_type": q_type,
            "speed": speed_info,
            "normalized": norm,
            "bindings": b_list,
            "count": len(items),
            "total_time_ms": total_q_time,
            "avg_time_ms": avg_time,
            "slow": any(i["time_ms"] >= 50.0 for i in items),
            "connection": first["connection"],
            "caller": first["caller"],
            "file": first["file"],
            "line": first["line"],
            "is_n_plus_one": len(items) >= 5,
            "is_duplicate": len(items) > 1,
            "recent_requests": list({i["request_uri"] for i in items})[:3],
            "min_time_ms": round(min(times), 2),
            "max_time_ms": round(max(times), 2),
            "p95_time_ms": round(times[min(len(times) - 1, int(len(times) * 0.95))], 2),
            "request_count": len({i["request_id"] for i in items}),
            # Every run, newest first, for the query inspector (capped to keep the feed small).
            "executions": [{
                "time_ms": i["time_ms"],
                "bindings": i["bindings"],
                "interpolated_sql": interpolate_sql(i["sql"], i["bindings"]),
                "file": i["file"],
                "line": i["line"],
                "request_id": i["request_id"],
                "request": f"{i['request_method'] or ''} {i['request_uri'] or ''}".strip(),
                "request_time": i["request_time"],
                "start_ms": i["start_ms"],
            } for i in sorted(items, key=lambda i: float(i["request_time"] or 0.0), reverse=True)[:50]],
            "callers": [{"file": f, "line": l, "count": c} for (f, l), c in
                        collections.Counter((i["file"], i["line"]) for i in items if i["file"]).most_common(10)],
        })
    aggregated_queries.sort(key=lambda q: q["total_time_ms"], reverse=True)

    total_req_count = len(merged_requests)
    durations = [float(r.get("duration_ms") or 0.0) for r in merged_requests]
    durations_sorted = sorted(durations)

    def percentile(p: float) -> float:
        if not durations_sorted:
            return 0.0
        k = (len(durations_sorted) - 1) * (p / 100.0)
        f = math.floor(k)
        c = math.ceil(k)
        if f == c:
            return round(durations_sorted[int(k)], 1)
        d0 = durations_sorted[int(f)] * (c - k)
        d1 = durations_sorted[int(c)] * (k - f)
        return round(d0 + d1, 1)

    error_reqs = [r for r in merged_requests if int(r.get("status") or 200) >= 400]
    slow_reqs = [r for r in merged_requests if float(r.get("duration_ms") or 0.0) >= (min_duration_ms or 100.0)]
    total_queries_count = sum(len(r.get("queries") or []) for r in merged_requests)
    n1_total_count = sum(r.get("n_plus_one_count", 0) for r in merged_requests)

    framework_label = "Web App"
    try:
        import sites
        s = sites.find_site(site_name)
        if s:
            framework_label = s.get("type_label") or s.get("type", "").capitalize() or "Web App"
    except Exception:
        pass

    summary = {
        "total_requests": total_req_count,
        "avg_duration_ms": round(sum(durations) / total_req_count, 1) if total_req_count else 0.0,
        "p50_ms": percentile(50),
        "p95_ms": percentile(95),
        "p99_ms": percentile(99),
        "error_count": len(error_reqs),
        "error_rate": round((len(error_reqs) / total_req_count) * 100, 1) if total_req_count else 0.0,
        "total_queries": total_queries_count,
        "n_plus_one_count": n1_total_count,
        "framework": framework_label,
    }

    filtered_list = merged_requests
    if category == "queries":
        filtered_list = aggregated_queries
    elif category == "errors":
        filtered_list = error_reqs
    elif category == "slow":
        filtered_list = slow_reqs

    return {
        "ok": True,
        "site": site_name,
        "category": category,
        "framework": framework_label,
        "summary": summary,
        "requests": merged_requests[:limit] if category == "requests" else [],
        "queries": aggregated_queries[:limit] if category == "queries" else [],
        "errors": error_reqs[:limit] if category == "errors" else [],
        "slow": slow_reqs[:limit] if category == "slow" else [],
        "items": filtered_list[:limit],
        "nginx_needs_repair": bool(nginx_res.get("needs_repair")),
        "nginx_hint": nginx_res.get("hint") or "",
    }


def clear_perf_data(site_name: str) -> dict[str, Any]:
    """Clear memory buffer and SQLite storage for a site."""
    aliases = get_site_aliases(site_name)
    with _PERF_LOCK:
        for alias in aliases:
            if alias in _SITE_REQUESTS:
                _SITE_REQUESTS[alias].clear()

    for alias in aliases:
        try:
            conn = get_perf_db(alias)
            with conn:
                conn.execute("DELETE FROM requests")
        except Exception:
            pass

    return {"ok": True, "message": f"Cleared performance data for {site_name}"}


def check_profiler_status(site_path: str) -> dict[str, Any]:
    """Check if laravel-dev/profiler package is installed and active in .env."""
    path = Path(site_path).resolve()
    composer_file = path / "composer.json"
    env_file = path / ".env"

    installed = False
    if composer_file.is_file():
        try:
            cdata = json.loads(composer_file.read_text(encoding="utf-8"))
            dev_reqs = cdata.get("require-dev") or {}
            reqs = cdata.get("require") or {}
            installed = "laravel-dev/profiler" in dev_reqs or "laravel-dev/profiler" in reqs
        except Exception:
            installed = False

    active = False
    if env_file.is_file():
        try:
            content = env_file.read_text(encoding="utf-8")
            active = bool(re.search(r"^LARAVEL_DEV_PROFILER=(true|1)", content, re.MULTILINE | re.IGNORECASE))
        except Exception:
            active = False

    return {
        "installed": installed,
        "active": active,
    }

