"""Sites: settings, the project registry, what is running, and turning UI
requests into tasks.

Two modes:
  managed   Linux with the laravel-dev CLI. Nginx serves every project on a
            .test domain; anything that needs root goes through the CLI.
  portable  macOS and Windows (or LARAVEL_DEV_MODE=portable). Nothing on the
            system is changed: each project runs its own server on a
            localhost port (php artisan serve, npm run dev, manage.py runserver).
"""

import datetime
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

import apps
import envfile
import osutil
from osutil import HOME, IS_LINUX, IS_MAC, IS_WINDOWS
from tasks import TaskError

UI_DIR = Path(__file__).resolve().parent
BASE_DIR = Path(os.environ.get("LARAVEL_DEV_BASE_DIR") or UI_DIR.parent)
CLI = str(BASE_DIR / "bin" / "laravel-dev")
CONFIG_DIR = osutil.config_dir()
REGISTRY_DIR = CONFIG_DIR / "projects.d"
USER_CONFIG = CONFIG_DIR / "config.env"
PREFS_FILE = CONFIG_DIR / "app.json"
ENV_TYPES_FILE = CONFIG_DIR / "env-types.json"

MANAGED = IS_LINUX and os.access(CLI, os.X_OK) and os.environ.get("LARAVEL_DEV_MODE") != "portable"
MODE = "managed" if MANAGED else "portable"

NEW_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9.-]*$")
NAME_RE = re.compile(r"^[A-Za-z0-9._-]+$")
INSTANCE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,31}$")
DOMAIN_RE = re.compile(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")
REPO_RE = re.compile(r"^(https?://|ssh://|git@)\S+$")
UNIT_RE = re.compile(r"^(nginx|mysql|mariadb|postgresql|postgres|pgsql|redis|redis-server|supervisor|supervisord|cron|cronie|crond|mailpit|meilisearch|minio|php[0-9.]*-fpm)$")
PLACEMENTS = ("keep", "move", "copy", "symlink")

SERVICES = [
    (("nginx",), "Nginx", "Web server"),
    (("mysql", "mariadb"), "Database", "MySQL / MariaDB"),
    (("postgresql", "postgres"), "PostgreSQL", "Relational database (:5432)"),
    (("redis-server", "redis"), "Redis", "Cache & queues (:6379)"),
    (("supervisor", "supervisord"), "Supervisor", "Queue workers"),
    (("cron", "cronie", "crond"), "Cron", "Laravel scheduler"),
    (("mailpit",), "Mailpit", "Email testing (SMTP :1025, Web UI :8025)"),
    (("meilisearch",), "Meilisearch", "Full-text search engine (:7700)"),
    (("minio",), "MinIO", "Object storage (API :9000, Console :9001)"),
]
TOOLS = [  # what portable mode needs on PATH
    ("php", "PHP", ("-r", "echo PHP_VERSION;")), ("composer", "Composer", ("--version",)),
    ("node", "Node.js", ("--version",)), ("npm", "npm", ("--version",)),
    ("python3" if not IS_WINDOWS else "python", "Python", ("--version",)), ("git", "Git", ("--version",)),
    ("mysql", "MySQL client", ("--version",)),
]

DEFAULT_PREFS = {
    "editor": "",
    "theme": "system",
    "close_to_tray": True,
    "default_php": "",
    "notify_failed_jobs": True,
    "notify_log_errors": True,
    "notify_mail": True,
    "notify_task_fail": True,
}

PROCESSES = apps.AppProcesses(CONFIG_DIR / "runtime")


# ── config ───────────────────────────────────────────────────────────────────

def parse_env_file(path):
    try:
        return envfile.to_dict(Path(path).read_text(encoding="utf-8", errors="replace"))
    except OSError:
        return {}


def load_settings():
    settings = {
        "LARAVEL_SITES_DIR": str(HOME / "Sites"),
        "DB_TYPE": "mysql", "DB_HOST": "127.0.0.1", "DB_PORT": "3306",
        "DB_USER": "root", "DB_PASSWORD": "",
    }
    merged = {}
    if MANAGED:
        merged.update(parse_env_file(BASE_DIR / "config" / "config.env"))
    merged.update(parse_env_file(USER_CONFIG))
    if merged.get("LARAVEL_SITES_DIR") or merged.get("SITES_DIR"):
        merged["LARAVEL_SITES_DIR"] = merged.get("LARAVEL_SITES_DIR") or merged["SITES_DIR"]
    for key in settings:
        if key in merged:
            settings[key] = merged[key]
    settings["LARAVEL_SITES_DIR"] = os.path.expanduser(
        settings["LARAVEL_SITES_DIR"].replace("${HOME}", str(HOME)).replace("$HOME", str(HOME))
    )
    return settings


def bash_quote(value):
    return '"' + re.sub(r'([\\"$`])', r"\\\1", value) + '"'


def save_settings(updates):
    """Rewrite only the managed keys in the user config, keeping everything else."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        lines = USER_CONFIG.read_text(encoding="utf-8").splitlines()
    except OSError:
        lines = ["# Laravel Dev user settings (managed by the desktop app)."]
    pending = dict(updates)
    out = []
    for line in lines:
        key = line.split("=", 1)[0].strip().removeprefix("export ").strip() if "=" in line else ""
        if key in pending:
            out.append(f"{key}={bash_quote(pending.pop(key))}")
        else:
            out.append(line)
    out.extend(f"{key}={bash_quote(value)}" for key, value in pending.items())
    USER_CONFIG.write_text("\n".join(out) + "\n", encoding="utf-8")
    osutil.private_file(USER_CONFIG)


# ── launch at login ──────────────────────────────────────────────────────────

def app_command(hidden=True):
    """How to start this app again (used for launch-at-login)."""
    if MANAGED:
        return [CLI, "app", *(["--hidden"] if hidden else [])]
    launcher = os.environ.get("LARAVEL_DEV_LAUNCHER")  # set by the macOS app bundle
    if launcher and os.path.isfile(launcher):
        return [launcher, *(["--hidden"] if hidden else [])]
    python = sys.executable
    if IS_WINDOWS and python.lower().endswith("python.exe"):
        python = python[:-10] + "pythonw.exe"  # no console window
    return [python, str(UI_DIR / "app.py"), *(["--hidden"] if hidden else [])]


def autostart_file():
    if IS_WINDOWS:
        return Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / "Laravel Dev.cmd"
    if IS_MAC:
        return HOME / "Library" / "LaunchAgents" / "dev.laravel.LaravelDev.plist"
    return Path(os.environ.get("XDG_CONFIG_HOME") or HOME / ".config") / "autostart" / "laravel-dev.desktop"


def write_autostart(enabled):
    path = autostart_file()
    if not enabled:
        path.unlink(missing_ok=True)
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    argv = app_command(hidden=True)
    if IS_WINDOWS:
        path.write_text(f'@start "" {subprocess.list2cmdline(argv)}\r\n', encoding="utf-8")
    elif IS_MAC:
        args = "".join(f"<string>{a}</string>" for a in argv)
        path.write_text(
            '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
            '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>'
            f"<key>Label</key><string>dev.laravel.LaravelDev</string><key>ProgramArguments</key><array>{args}</array>"
            "<key>RunAtLoad</key><true/></dict></plist>\n", encoding="utf-8")
    else:
        path.write_text("[Desktop Entry]\nType=Application\nName=Laravel Dev\n"
                        f"Exec={shlex.join(argv)}\nIcon=laravel-dev\nX-GNOME-Autostart-enabled=true\n", encoding="utf-8")


def load_prefs():
    prefs = dict(DEFAULT_PREFS)
    try:
        prefs.update(json.loads(PREFS_FILE.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    prefs["autostart"] = autostart_file().exists()
    return prefs


def save_prefs(prefs):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = {key: prefs.get(key, default) for key, default in DEFAULT_PREFS.items()}
    PREFS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    write_autostart(bool(prefs.get("autostart")))


# ── system inspection ────────────────────────────────────────────────────────

run_quiet = osutil.run_quiet


PHP_INSTALLABLE = ("7.4", "8.0", "8.1", "8.2", "8.3", "8.4", "8.5")


def php_installable_list():
    if not MANAGED:
        return [{"version": v, "status": "installed"} for v in php_versions()]
    code, out = run_quiet([CLI, "php-installable"])
    if code != 0 or not out.strip():
        installed = set(php_versions())
        return [{"version": v, "status": "installed" if v in installed else "available"} for v in PHP_INSTALLABLE]
    results = []
    for line in out.splitlines():
        if ":" in line:
            v, status = line.strip().split(":", 1)
            results.append({"version": v, "status": status})
    return results


def php_versions():
    if MANAGED:
        code, out = run_quiet([CLI, "php-versions"])
        versions = [v for v in out.splitlines() if re.fullmatch(r"\d+\.\d+", v.strip())] if code == 0 else []
        return versions or ["8.4"]
    version = osutil.tool_version("php", ("-r", "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;"))
    return [version] if re.fullmatch(r"\d+\.\d+", version) else []


def php_binary(version):
    if version:
        found = shutil.which(f"php{version}")
        if found:
            return found
    found = shutil.which("php")
    if found:
        return found
    for cand in (HOME / ".config" / "herd-lite" / "bin" / "php", Path("/usr/local/bin/php"), Path("/usr/bin/php")):
        if cand.is_file() and os.access(str(cand), os.X_OK):
            return str(cand)
    return "php"


def composer_binary():
    found = shutil.which("composer")
    if found:
        return found
    for cand in (
        Path("/usr/local/bin/composer"),
        Path("/usr/bin/composer"),
        HOME / ".local" / "bin" / "composer",
        HOME / ".config" / "herd-lite" / "bin" / "composer",
    ):
        if cand.is_file() and os.access(str(cand), os.X_OK):
            return str(cand)
    return ""


def _is_php_script(path):
    if str(path).lower().endswith(".phar"):
        return True
    try:
        with open(path, "rb") as handle:
            head = handle.read(160)
        return b"php" in head.splitlines()[0].lower() if head else False
    except OSError:
        return False


def php_config_info(version: str) -> dict:
    """Read xdebug status and key php.ini directives for a given PHP version."""
    bin_name = f"php{version}"
    php_path = shutil.which(bin_name) or shutil.which("php") or "php"

    script = """
    $xdebug = extension_loaded('xdebug');
    $exts = get_loaded_extensions();
    sort($exts);
    echo json_encode([
        'xdebug' => $xdebug,
        'memory_limit' => ini_get('memory_limit') ?: '128M',
        'upload_max_filesize' => ini_get('upload_max_filesize') ?: '2M',
        'max_execution_time' => ini_get('max_execution_time') ?: '30',
        'post_max_size' => ini_get('post_max_size') ?: '8M',
        'extensions' => $exts,
    ]);
    """
    try:
        proc = subprocess.run([php_path, "-r", script], capture_output=True, text=True, timeout=5)
        if proc.returncode == 0 and proc.stdout:
            data = json.loads(proc.stdout)
            data["version"] = version
            return data
    except Exception:
        pass
    return {
        "version": version,
        "xdebug": False,
        "memory_limit": "128M",
        "upload_max_filesize": "2M",
        "max_execution_time": "30",
        "post_max_size": "8M",
        "extensions": [],
    }


def nginx_sites():
    """Index every nginx site config by file name, server_name and project root,
    so sites created before the registry existed are still recognised."""
    index = {"file": {}, "domain": {}, "root": {}}
    if not MANAGED:
        return index
    for folder in ("/etc/nginx/sites-available", "/etc/nginx/conf.d", "/etc/nginx/http.d"):
        try:
            files = sorted(Path(folder).iterdir())
        except OSError:
            continue
        for conf in files:
            if not conf.is_file() or ".bak" in conf.name or ".backup" in conf.name:
                continue
            try:
                text = conf.read_text(errors="replace")
            except OSError:
                continue
            php = re.search(r"php(\d+\.\d+)-fpm\.sock", text)
            names = re.search(r"^\s*server_name\s+([^;]+);", text, re.M)
            root = re.search(r"^\s*root\s+([^;]+);", text, re.M)
            ssl = bool(re.search(r"^\s*listen\s+[^;]*443\s+ssl", text, re.M))
            info = {
                "php": php.group(1) if php else "",
                "domain": names.group(1).split()[0].lower() if names else "",
                "root": root.group(1).strip() if root else "",
                "ssl": ssl,
            }
            index["file"][conf.name.removesuffix(".conf")] = info
            if info["domain"]:
                index["domain"].setdefault(info["domain"], info)
            if info["root"]:
                index["root"].setdefault(os.path.realpath(info["root"].removesuffix("/public")), info)
    return index


def nginx_lookup(index, name, domain, path):
    return (index["domain"].get(domain)
            or index["root"].get(os.path.realpath(path))
            or index["file"].get(name))


def git_branch(path):
    try:
        head = (Path(path) / ".git" / "HEAD").read_text().strip()
    except OSError:
        return ""
    return head.removeprefix("ref: refs/heads/") if head.startswith("ref:") else head[:8]


def find_reverb_processes():
    results = {}
    if not IS_LINUX:
        return results
    my_pid = os.getpid()
    for proc_dir in Path("/proc").glob("[0-9]*"):
        try:
            pid = int(proc_dir.name)
            if pid == my_pid:
                continue
            args = [a.decode("utf-8", errors="replace") for a in (proc_dir / "cmdline").read_bytes().split(b"\0") if a]
            if len(args) >= 2 and any(a.endswith("artisan") for a in args) and any("reverb:start" in a for a in args):
                results[os.path.realpath(proc_dir / "cwd")] = {"pid": pid, "cmd": " ".join(args)}
        except (OSError, ValueError):
            continue
    return results


def reverb_info(path, running_map):
    path_str = str(os.path.realpath(path))
    composer_file = Path(path) / "composer.json"
    has_reverb = (Path(path) / "config" / "reverb.php").is_file()
    if not has_reverb and composer_file.is_file():
        try:
            has_reverb = "laravel/reverb" in composer_file.read_text()
        except OSError:
            pass
    env = parse_env_file(Path(path) / ".env")
    if not has_reverb and (env.get("REVERB_APP_KEY") or env.get("BROADCAST_CONNECTION") == "reverb"):
        has_reverb = True
    if not has_reverb:
        return {"installed": False, "running": False}

    proc = running_map.get(path_str)
    host = env.get("REVERB_HOST") or "localhost"
    port = env.get("REVERB_PORT") or "8080"
    scheme = env.get("REVERB_SCHEME") or "http"
    return {
        "installed": True,
        "running": proc is not None,
        "pid": proc["pid"] if proc else None,
        "host": host, "port": port, "scheme": scheme,
        "url": f"{'wss' if scheme == 'https' else 'ws'}://{host}:{port}",
        "app_id": env.get("REVERB_APP_ID") or "",
        "app_key": env.get("REVERB_APP_KEY") or "",
        "managed": MANAGED,
    }


def is_process_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def find_tunnel_processes():
    tunnels = {}
    uid = os.getuid() if hasattr(os, "getuid") else 1000
    candidates = [
        HOME / ".config" / "laravel-dev" / "runtime" / "tunnels",
        Path(f"/tmp/laravel-dev-{uid}/runtime/tunnels"),
    ]
    for rdir in candidates:
        if not rdir.is_dir():
            continue
        for pid_file in rdir.glob("*.pid"):
            site = pid_file.stem
            try:
                pid = int(pid_file.read_text().strip())
                if pid > 0 and is_process_alive(pid):
                    url_file = rdir / f"{site}.url"
                    url = url_file.read_text().strip() if url_file.is_file() else ""
                    json_file = rdir / f"{site}.json"
                    mode = "quick"
                    started = 0
                    if json_file.is_file():
                        try:
                            meta = json.loads(json_file.read_text())
                            mode = meta.get("mode", "quick")
                            started = meta.get("started", 0)
                            if not url:
                                url = meta.get("url", "")
                        except Exception:
                            pass
                    tunnels[site] = {
                        "active": True,
                        "pid": pid,
                        "url": url,
                        "mode": mode,
                        "started": started,
                    }
            except Exception:
                continue
    return tunnels


def tunnel_info(name, tunnel_map):
    t = (tunnel_map or {}).get(name)
    if t:
        return t
    return {
        "active": False,
        "pid": None,
        "url": "",
        "mode": "quick",
        "started": 0,
    }


def running_workers():
    if not MANAGED:
        return []
    code, out = run_quiet(["ps", "-eo", "args"])
    return [line for line in out.splitlines() if "artisan queue:work" in line or "artisan horizon" in line] if code == 0 else []


def worker_running(path, workers):
    candidates = {str(path).rstrip("/"), os.path.realpath(path).rstrip("/")}
    return any(
        any(f"{cand}/artisan queue:work" in line or f"{cand}/artisan horizon" in line for cand in candidates)
        for line in workers
    )


# Same defaults as get_queue_config in core/SupervisorManager.sh.
WORKER_DEFAULTS = {"queues": "default", "processes": "1", "tries": "3", "timeout": "90", "sleep": "3"}
WORKER_KEYS = {"mode": "QUEUE_WORKER_MODE", "queues": "QUEUE_WORKER_QUEUES", "processes": "QUEUE_WORKER_NUMPROCS",
               "tries": "QUEUE_WORKER_TRIES", "timeout": "QUEUE_WORKER_TIMEOUT", "sleep": "QUEUE_WORKER_SLEEP"}
LOG_DIR = HOME / ".local" / "log" / "laravel-dev"
CRON_MARKER = "# laravel-dev:"


def worker_settings(name, path):
    record = parse_env_file(REGISTRY_DIR / f"{name}.env")
    settings = {key: record.get(env_key) or WORKER_DEFAULTS.get(key, "") for key, env_key in WORKER_KEYS.items()}
    try:
        has_horizon = "laravel/horizon" in (Path(path) / "composer.json").read_text(encoding="utf-8", errors="replace")
    except OSError:
        has_horizon = False
    settings["has_horizon"] = has_horizon
    settings["effective_mode"] = settings["mode"] or ("horizon" if has_horizon else "queue")
    return settings


def scheduler_status(name):
    """Whether the user's crontab runs this project's schedule:run (see core/CronManager.sh)."""
    if not MANAGED or not shutil.which("crontab"):
        return {"installed": False, "enabled": False, "service": "missing"}
    _code, out = run_quiet(["crontab", "-l"])
    enabled = any(line.rstrip().endswith(f"{CRON_MARKER}{name}") for line in out.splitlines())
    service, service_unit = "missing", "cron"
    for unit in ("cron", "cronie", "crond"):
        _code, state = run_quiet(["systemctl", "is-active", unit])
        if state in ("active", "inactive", "failed"):
            service, service_unit = state, unit
            if state == "active":
                break
    return {"installed": True, "enabled": enabled, "service": service, "unit": service_unit}


def crontab_active_sites() -> set[str]:
    """Read crontab once for the whole sites list to check active schedule:run jobs."""
    if not MANAGED or not shutil.which("crontab"):
        return set()
    code, out = run_quiet(["crontab", "-l"])
    if code != 0:
        return set()
    active = set()
    for line in out.splitlines():
        if CRON_MARKER in line:
            parts = line.split(CRON_MARKER, 1)
            if len(parts) == 2 and parts[1].strip():
                active.add(parts[1].strip())
    return active


def configured_worker_sites() -> set[str]:
    """Check supervisor configurations once for all sites."""
    conf_dir = Path("/etc/supervisor/conf.d")
    if not conf_dir.is_dir():
        return set()
    try:
        return {p.name.removeprefix("laravel-dev-").removesuffix(".conf")
                for p in conf_dir.glob("laravel-dev-*.conf")}
    except OSError:
        return set()


def log_errors_today(path: Path) -> int:
    """Fast check for error count in today's Laravel log (reading at most last 128KB)."""
    today_str = datetime.date.today().strftime("%Y-%m-%d")
    log_dir = path / "storage" / "logs"
    if not log_dir.is_dir():
        return 0
    daily_file = log_dir / f"laravel-{today_str}.log"
    target_file = daily_file if daily_file.is_file() else (log_dir / "laravel.log")
    if not target_file.is_file():
        return 0
    try:
        size = target_file.stat().st_size
        if size == 0:
            return 0
        read_bytes = min(size, 128 * 1024)
        with open(target_file, "rb") as f:
            if size > read_bytes:
                f.seek(size - read_bytes)
            chunk = f.read(read_bytes).decode("utf-8", errors="replace")
        count = 0
        for line in chunk.splitlines():
            if line.startswith(f"[{today_str}") and any(lvl in line for lvl in (".ERROR:", ".CRITICAL:", ".ALERT:", ".EMERGENCY:")):
                count += 1
        return count
    except Exception:
        return 0


def nginx_perf_chip(site_name: str) -> dict | None:
    """Fast check for recent Nginx p95 latency and 5xx errors from /var/log/nginx/laravel-dev/<name>.json."""
    log_file = Path(f"/var/log/nginx/laravel-dev/{site_name}.json")
    if not log_file.is_file():
        return None
    try:
        size = log_file.stat().st_size
        if size == 0:
            return None
        with open(log_file, "r", encoding="utf-8", errors="replace") as f:
            if size > 16384:
                f.seek(size - 16384)
                f.readline()
            lines = f.readlines()
        durations = []
        errors_5xx = 0
        for line in reversed(lines[-50:]):
            line = line.strip()
            if not line.startswith("{"):
                continue
            try:
                data = json.loads(line)
                rt = float(data.get("rt") or 0.0) * 1000.0
                durations.append(rt)
                if int(data.get("s") or 200) >= 500:
                    errors_5xx += 1
            except Exception:
                continue
        if not durations:
            return None
        durations.sort()
        idx = int(len(durations) * 0.95)
        p95 = round(durations[min(idx, len(durations) - 1)], 1)
        return {"p95": p95, "errors_5xx": errors_5xx}
    except Exception:
        return None


def log_tail(path):
    text = tail_file(path)
    return {"exists": text is not None, "text": text or ""}


def worker_log(name):
    return log_tail(LOG_DIR / f"laravel-dev-{name}.log")


def scheduler_log(name):
    return log_tail(LOG_DIR / f"laravel-dev-{name}-schedule.log")


# ── registry ─────────────────────────────────────────────────────────────────

def write_record(name, fields):
    """Same KEY="value" format as write_project_record in core/RegistryManager.sh."""
    osutil.private_dir(REGISTRY_DIR)
    lines = [f'PROJECT_NAME="{name}"']
    for key, value in fields.items():
        lines.append(f'{key}="{str(value).replace(chr(34), chr(92) + chr(34))}"')
    path = REGISTRY_DIR / f"{name}.env"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    osutil.private_file(path)


def update_record(name, updates):
    record_file = REGISTRY_DIR / f"{name}.env"
    if not record_file.is_file():
        raise ValueError(f"{name} is not linked")
    lines = [line for line in record_file.read_text().splitlines()
             if line.split("=", 1)[0] not in updates]
    for key, value in updates.items():
        escaped = str(value).replace('"', '\\"')
        lines.append(f'{key}="{escaped}"')
    record_file.write_text("\n".join(lines) + "\n")


def used_ports():
    ports = set()
    for record_file in REGISTRY_DIR.glob("*.env"):
        port = parse_env_file(record_file).get("PORT", "")
        if port.isdigit() and port != "80":
            ports.add(int(port))
    return ports


def sites_dir():
    return Path(load_settings()["LARAVEL_SITES_DIR"])


def is_park_enabled() -> bool:
    if not MANAGED:
        return False
    conf1 = Path("/etc/nginx/sites-available/00-laravel-dev-park")
    conf2 = Path("/etc/nginx/conf.d/00-laravel-dev-park.conf")
    conf3 = Path("/etc/nginx/sites-enabled/00-laravel-dev-park")
    return conf1.is_file() or conf2.is_file() or conf3.is_file()


def dns_status_info() -> dict:
    if not MANAGED:
        return {"installed": False, "enabled": False, "resolved_active": False, "resolves": False}
    code, out = run_quiet([CLI, "dns", "status"])
    if code == 0 and out.strip().startswith("{"):
        try:
            return json.loads(out)
        except Exception:
            pass
    return {"installed": False, "enabled": False, "resolved_active": False, "resolves": False}


def park_status_info() -> dict:
    return {"enabled": is_park_enabled()}


def debug_session_info(site_name: str) -> dict:
    if not MANAGED:
        return {"project": site_name, "supported": False, "armed": False, "checks": {}, "ready": False}
    code, out = run_quiet([CLI, "debug-session", "status", site_name], timeout=15)
    if code == 0 and out.strip().startswith("{"):
        try:
            return json.loads(out)
        except Exception:
            pass
    return {"project": site_name, "supported": False, "armed": False, "checks": {}, "ready": False,
            "error": out[-500:] if out else "debug-session status failed"}


def octane_logs(site_name: str, lines: int = 80) -> str:
    if not MANAGED:
        return ""
    _code, out = run_quiet([CLI, "octane", "logs", site_name, str(max(10, min(int(lines), 500)))], timeout=10)
    return out


def octane_status_info(site_name: str) -> dict:
    if not MANAGED:
        return {"project": site_name, "enabled": False, "server": "frankenphp", "port": 80, "workers": "auto", "running": False}
    code, out = run_quiet([CLI, "octane", "status", site_name])
    if code == 0 and out.strip().startswith("{"):
        try:
            return json.loads(out)
        except Exception:
            pass
    return {"project": site_name, "enabled": False, "server": "frankenphp", "port": 80, "workers": "auto", "running": False}


def list_sites():
    root = sites_dir()
    workers = running_workers()
    reverb_map = find_reverb_processes()
    tunnel_map = find_tunnel_processes()
    nginx = nginx_sites()
    cron_sites = crontab_active_sites()
    configured_workers = configured_worker_sites()
    sites = []
    known_paths = set()

    for record_file in sorted(REGISTRY_DIR.glob("*.env")):
        record = parse_env_file(record_file)
        name = record.get("PROJECT_NAME") or record_file.stem
        path = record.get("PROJECT_PATH") or str(root / name)
        known_paths.add(os.path.realpath(path))
        domain = record.get("DOMAIN") or f"{name}.test"
        conf = nginx_lookup(nginx, name, domain, path) or {}
        raw_type = record.get("PROJECT_TYPE") or "laravel"
        kind = raw_type if raw_type in ("laravel", *apps.APP_TYPES) else "node"  # e.g. nest, express
        effective_php = record.get("PHP_VERSION") or conf.get("php", "")
        site = site_entry(name, path, domain, True, workers, effective_php, kind, bool(conf.get("ssl")),
                          reverb_map, cron_sites=cron_sites, configured_workers=configured_workers, tunnel_map=tunnel_map)
        site["type_label"] = apps.TYPE_LABELS.get(raw_type, raw_type.capitalize())
        site["node_version"] = record.get("NODE_VERSION", "")
        site["runtime"] = record.get("RUNTIME", "php-fpm")
        site["octane_server"] = record.get("OCTANE_SERVER", "")
        site["octane_workers"] = record.get("OCTANE_WORKERS", "")
        aliases_raw = record.get("ALIASES") or record.get("PROJECT_ALIASES") or ""
        site["aliases"] = [a.strip() for a in aliases_raw.replace(",", " ").split() if a.strip()]
        site["wildcard"] = record.get("WILDCARD", "1") != "0"
        if site["process"]:
            site.update(app_state(name, path, site["type"], record))
            if not MANAGED:
                site["url"] = f"http://localhost:{site['port']}" if site["port"] else ""
                site["domain"] = f"localhost:{site['port']}" if site["port"] else name
        sites.append(site)

    if root.is_dir():
        for child in sorted(root.iterdir()):
            try:
                if not child.is_dir() or child.name.startswith(".") or os.path.realpath(child) in known_paths:
                    continue
            except OSError:
                continue
            kind = apps.detect_type(child)
            if not kind:
                continue
            # A Laravel folder nginx already serves (set up by an older version) counts as linked.
            conf = nginx_lookup(nginx, child.name, f"{child.name.lower()}.test", str(child)) if kind == "laravel" and MANAGED else None
            domain = conf["domain"] if conf and conf["domain"] else f"{child.name.lower()}.test"
            site = site_entry(child.name, str(child), domain, bool(conf), workers, (conf or {}).get("php", ""), kind,
                              bool((conf or {}).get("ssl")), reverb_map, cron_sites=cron_sites, configured_workers=configured_workers, tunnel_map=tunnel_map)
            if is_park_enabled() and kind == "laravel" and not conf:
                site["parked"] = True
                site["status"] = "parked"
                site["url"] = f"http://{domain}"
            if not MANAGED:
                site["domain"] = child.name
            sites.append(site)

    sites.sort(key=lambda site: (not site["linked"], site["name"].lower()))
    return sites


def site_entry(name, path, domain, linked, workers, php="", kind="laravel", ssl=False, reverb_map=None,
               cron_sites=None, configured_workers=None, tunnel_map=None):
    exists = Path(path).is_dir()
    scheme = "https" if ssl else "http"
    reverb = reverb_info(path, reverb_map or {}) if kind == "laravel" and exists else None
    tunnel = tunnel_info(name, tunnel_map or {})
    worker_on = worker_running(path, workers)
    worker_cfg = (name in configured_workers) if configured_workers is not None else (MANAGED and Path(f"/etc/supervisor/conf.d/laravel-dev-{name}.conf").exists())
    cron_on = (name in cron_sites) if cron_sites is not None else False
    err_count = log_errors_today(Path(path)) if (kind == "laravel" and exists) else 0

    return {
        "type": kind,
        "type_label": apps.TYPE_LABELS.get(kind, kind.capitalize()),
        "name": name,
        "path": path,
        "display_path": path.replace(str(HOME), "~", 1),
        "domain": domain,
        "url": f"{scheme}://{domain}",
        "ssl": ssl,
        "linked": linked,
        "exists": exists,
        "php": php,
        "branch": git_branch(path) if exists else "",
        "worker": worker_on,
        "worker_configured": worker_cfg,
        "cron": cron_on,
        "log_errors_today": err_count,
        "perf": nginx_perf_chip(name) if exists else None,
        "reverb": reverb,
        "tunnel": tunnel,
        # Runs its own server process (start/stop in the UI) instead of nginx + php-fpm.
        "process": kind != "laravel" or not MANAGED,
        "in_www": os.path.realpath(os.path.dirname(os.path.abspath(path))) == os.path.realpath(sites_dir()),
        "aliases": [],
        "wildcard": True,
    }


def app_state(name, path, kind, record):
    mode = record.get("RUN_MODE") or "dev"
    command = record.get("RUN_COMMAND") or apps.default_command(kind, mode, path)
    port = record.get("PORT") or ""
    return {
        "port": port if port != "80" else "",
        "mode": mode,
        "command": command,
        "custom_command": bool(record.get("RUN_COMMAND")),
        "running": PROCESSES.running(name, path),
    }


def find_site(name):
    for site in list_sites():
        if site["name"] == name:
            return site
    raise ValueError(f"Unknown site: {name}")


def site_details(name):
    site = find_site(name)
    path = Path(site["path"])
    details = dict(site)
    details["laravel"] = ""
    packages_installed = set()
    try:
        lock = json.loads((path / "composer.lock").read_text(encoding="utf-8", errors="replace"))
        for package in lock.get("packages", []) + lock.get("packages-dev", []):
            if package.get("name") == "laravel/framework":
                details["laravel"] = package.get("version", "").lstrip("v")
            packages_installed.add(package.get("name"))
    except (OSError, ValueError):
        pass

    if not packages_installed and (path / "composer.json").is_file():
        try:
            cj = json.loads((path / "composer.json").read_text(encoding="utf-8", errors="replace"))
            packages_installed.update((cj.get("require") or {}).keys())
            packages_installed.update((cj.get("require-dev") or {}).keys())
        except Exception:
            pass

    details["dev_tools"] = {
        "horizon": "laravel/horizon" in packages_installed,
        "telescope": "laravel/telescope" in packages_installed,
        "pulse": "laravel/pulse" in packages_installed,
    }

    details["has_package_json"] = (path / "package.json").is_file()
    details["node_modules_installed"] = (path / "node_modules").is_dir()
    details["npm_pm"] = apps.package_manager(path)
    details["npm_scripts"] = apps.scripts(path) if details["has_package_json"] else {}

    if site["type"] != "laravel":
        details["scripts"] = details["npm_scripts"] if site["type"] != "django" else {}
        details["package_manager"] = details["npm_pm"] if site["type"] != "django" else ""
        details["python"] = apps.venv_python(path) if site["type"] == "django" else ""
        details["has_deps"] = (path / ("requirements.txt" if site["type"] == "django" else "package.json")).is_file()
        details["deps_installed"] = details["node_modules_installed"] if site["type"] != "django" else details["python"] not in ("python3", "python")
    if site["process"]:
        details["default_commands"] = {m: apps.default_command(site["type"], m, path) for m in ("dev", "prod")}
    details["worker_configured"] = MANAGED and Path(f"/etc/supervisor/conf.d/laravel-dev-{name}.conf").exists()
    if site["type"] == "laravel":
        details["worker_settings"] = worker_settings(name, path)
        details["scheduler"] = scheduler_status(name)
    details["reverb"] = reverb_info(path, find_reverb_processes()) if site["type"] == "laravel" else None
    details["tunnel"] = tunnel_info(name, find_tunnel_processes())
    details["has_env"] = (path / ".env").is_file()
    details["git"] = None
    if (path / ".git").exists():
        code, out = run_quiet(["git", "-C", str(path), "status", "--porcelain=v1", "-b"])
        if code == 0:
            lines = out.splitlines()
            head = lines[0] if lines else ""
            ahead = re.search(r"ahead (\d+)", head)
            behind = re.search(r"behind (\d+)", head)
            details["git"] = {
                "branch": site["branch"],
                "upstream": "..." in head,
                "ahead": int(ahead.group(1)) if ahead else 0,
                "behind": int(behind.group(1)) if behind else 0,
                "changes": max(len(lines) - 1, 0),
            }
    return details


def git_extended_info(site_name: str) -> dict:
    site = find_site(site_name)
    path = Path(site["path"])
    if not (path / ".git").exists():
        return {"is_git": False, "branch": "", "branches": [], "files": [], "stashes": []}

    code, out = run_quiet(["git", "-C", str(path), "for-each-ref", "--format=%(refname)", "refs/heads", "refs/remotes"])
    branches = []
    for ref in (out.splitlines() if code == 0 else []):
        if ref.startswith("refs/remotes/") and ref.endswith("/HEAD"):
            continue  # origin/HEAD shortens to a bare "origin", which is not a branch
        branches.append(ref.removeprefix("refs/heads/").removeprefix("refs/remotes/"))

    code, curr = run_quiet(["git", "-C", str(path), "branch", "--show-current"])
    current_branch = curr.strip() if code == 0 else ""

    code, out = run_quiet(["git", "-C", str(path), "status", "--porcelain=v1"])
    files = []
    if code == 0 and out:
        for line in out.splitlines():
            if len(line) >= 4:
                status = line[:2].strip()
                fname = line[3:].strip()
                files.append({"status": status, "file": fname})

    code, out = run_quiet(["git", "-C", str(path), "stash", "list"])
    stashes = [s.strip() for s in out.splitlines() if s.strip()] if code == 0 else []

    return {
        "is_git": True,
        "branch": current_branch,
        "branches": branches,
        "files": files,
        "stashes": stashes,
    }


def git_file_diff(site_name: str, file_path: str = "") -> dict:
    site = find_site(site_name)
    path = Path(site["path"])
    cmd = ["git", "-C", str(path), "diff", "HEAD"]
    if file_path:
        cmd.extend(["--", file_path])
    code, out = run_quiet(cmd)
    if not out and file_path:
        f = path / file_path
        if f.is_file():
            try:
                out = f.read_text(encoding="utf-8", errors="replace")[:10000]
            except Exception:
                pass
    return {"diff": out}


def list_services():
    if not MANAGED:
        return []
    code, out = run_quiet(["systemctl", "list-unit-files", "--type=service", "--no-legend", "--plain"])
    units = {line.split()[0].removesuffix(".service") for line in out.splitlines() if line.strip()} if code == 0 else set()

    # Fallback/supplemental discovery for SysVinit, WSL, containers or standalone installs
    init_d = Path("/etc/init.d")
    if init_d.is_dir():
        try:
            for p in init_d.iterdir():
                if p.is_file() and os.access(p, os.X_OK):
                    units.add(p.name)
        except OSError:
            pass

    systemd_system = Path("/etc/systemd/system")
    if systemd_system.is_dir():
        try:
            for p in systemd_system.glob("*.service"):
                units.add(p.stem)
        except OSError:
            pass

    bin_map = {
        "nginx": "nginx",
        "mysql": "mysqld",
        "mariadb": "mariadbd",
        "postgresql": "psql",
        "redis-server": "redis-server",
        "redis": "redis-server",
        "supervisor": "supervisord",
        "supervisord": "supervisord",
        "cron": "cron",
        "mailpit": "mailpit",
        "meilisearch": "meilisearch",
        "minio": "minio",
    }
    for unit_name, bin_name in bin_map.items():
        if shutil.which(bin_name) or Path(f"/usr/local/bin/{bin_name}").is_file():
            units.add(unit_name)

    php_dir = Path("/etc/php")
    if php_dir.is_dir():
        try:
            for vdir in php_dir.iterdir():
                if vdir.is_dir() and (vdir / "fpm").is_dir():
                    units.add(f"php{vdir.name}-fpm")
        except OSError:
            pass

    rows = []
    installed_units = []
    for candidates, label, description in SERVICES:
        unit = next((u for u in candidates if u in units), None)
        if unit:
            row = {"unit": unit, "label": label, "description": description, "kind": "core" if label in ("Nginx", "Database") else "extra", "installed": True}
            rows.append(row)
            installed_units.append(row)
        elif label in ("Mailpit", "Redis", "Meilisearch", "MinIO", "PostgreSQL"):
            rows.append({"unit": candidates[0], "label": label, "description": description, "kind": "extra", "status": "not_installed", "installed": False})

    for unit in sorted(u for u in units if re.fullmatch(r"php[0-9.]*-fpm", u)):
        version = unit.removeprefix("php").removesuffix("-fpm") or "default"
        row = {"unit": unit, "label": f"PHP {version} FPM", "description": "PHP FastCGI", "kind": "core", "installed": True}
        rows.append(row)
        installed_units.append(row)

    if installed_units:
        systemctl_states = {}
        if shutil.which("systemctl"):
            scode, sout = run_quiet(["systemctl", "is-active", *[row["unit"] for row in installed_units]])
            if scode == 0 or any(s in sout for s in ("active", "inactive", "failed")):
                lines = sout.splitlines()
                for idx, r in enumerate(installed_units):
                    if idx < len(lines):
                        st = lines[idx].strip()
                        if st in ("active", "inactive", "failed"):
                            systemctl_states[r["unit"]] = st

        _ps_code, ps_out = run_quiet(["ps", "-eo", "comm"])
        comm_set = {line.strip().lower() for line in ps_out.splitlines()}

        def is_proc_active(u_name: str) -> bool:
            u_low = u_name.lower()
            if u_low in ("postgresql", "postgres"):
                return "postgres" in comm_set or "postmaster" in comm_set
            if u_low in ("mysql", "mariadb"):
                return "mysqld" in comm_set or "mariadbd" in comm_set
            if u_low in ("redis-server", "redis"):
                return "redis-server" in comm_set
            if u_low in ("supervisor", "supervisord"):
                return "supervisord" in comm_set
            if u_low in ("cron", "cronie", "crond"):
                return "cron" in comm_set or "crond" in comm_set
            if "php" in u_low and "-fpm" in u_low:
                return any(c.startswith("php") and c.endswith("fpm") for c in comm_set) or "php-fpm" in comm_set
            return u_low in comm_set

        def is_service_active_sysv(u_name: str) -> bool:
            sv_code, sv_out = run_quiet(["service", u_name, "status"])
            sv_l = sv_out.lower()
            if any(neg in sv_l for neg in ("not running", "stopped", "down", "inactive", "dead", "failed")):
                return False
            if sv_code == 0 and any(pos in sv_l for pos in ("is running", "active (running)", "online", "running")):
                return True
            return False

        for row in installed_units:
            u = row["unit"]
            if u in systemctl_states:
                row["status"] = systemctl_states[u]
            elif is_proc_active(u) or is_service_active_sysv(u):
                row["status"] = "active"
            else:
                row["status"] = "inactive"
    return rows


def list_supervisor_programs(site_name: str) -> list[dict]:
    """Scan supervisor config files for this project and report status."""
    conf_dir = Path("/etc/supervisor/conf.d")
    if not conf_dir.is_dir() or not MANAGED:
        return []

    # supervisorctl needs root (the socket is 0700 root) and fails for the desktop user;
    # then fall back to matching each program's command line in the process list.
    code, out = run_quiet(["supervisorctl", "status"])
    status_map = {}
    if code in (0, 3):  # 3 = some programs not running
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 2:
                group = parts[0].split(":")[0]
                if status_map.get(group) != "running":
                    status_map[group] = parts[1].lower()
    _ps_code, ps_out = run_quiet(["ps", "-eo", "args"])
    processes = ps_out.splitlines()

    other_sites = {f.stem for f in REGISTRY_DIR.glob("*.env")} - {site_name}
    programs = []
    for conf_file in conf_dir.glob(f"laravel-dev-{site_name}*.conf"):
        fname = conf_file.name
        stem = fname.removeprefix("laravel-dev-").removesuffix(".conf")
        if stem != site_name and (not stem.startswith(f"{site_name}-") or stem in other_sites):
            continue  # another project's program, e.g. "back-end" when looking at "back"
        prog_name = "worker"
        if fname != f"laravel-dev-{site_name}.conf":
            prog_name = fname.removeprefix(f"laravel-dev-{site_name}-").removesuffix(".conf")

        command = ""
        user = ""
        numprocs = 1
        try:
            content = conf_file.read_text(encoding="utf-8", errors="replace")
            for line in content.splitlines():
                if line.strip().startswith("command="):
                    command = line.strip().split("=", 1)[1]
                elif line.strip().startswith("user="):
                    user = line.strip().split("=", 1)[1].strip()
                elif line.strip().startswith("numprocs="):
                    try:
                        numprocs = int(line.strip().split("=", 1)[1])
                    except ValueError:
                        pass
        except Exception:
            pass

        supervisor_tag = f"laravel-dev-{site_name}" if prog_name == "worker" else f"laravel-dev-{site_name}-{prog_name}"
        if status_map:
            status = status_map.get(supervisor_tag, "stopped")
        else:
            status = "running" if command and any(line.strip() == command.strip() for line in processes) else "stopped"

        programs.append({
            "name": prog_name,
            "tag": supervisor_tag,
            "command": command,
            "user": user,
            "is_root": user == "root",
            "numprocs": numprocs,
            "status": status,
            "is_worker": prog_name == "worker",
            "log": f"laravel-dev-{site_name}.log" if prog_name == "worker" else f"laravel-dev-{site_name}-{prog_name}.log",
        })

    programs.sort(key=lambda x: (0 if x["is_worker"] else 1, x["name"]))
    return programs


def list_tools():
    return [{"bin": b, "label": label, "version": osutil.tool_version(b, args)} for b, label, args in TOOLS]


def tail_file(path, lines=300):
    try:
        with open(path, "rb") as handle:
            handle.seek(0, os.SEEK_END)
            size = handle.tell()
            handle.seek(max(size - 256 * 1024, 0))
            data = handle.read().decode("utf-8", errors="replace")
    except OSError:
        return None
    return "\n".join(data.splitlines()[-lines:])


# ── actions ──────────────────────────────────────────────────────────────────

def require(pattern, value, label):
    value = (value or "").strip()
    if not pattern.fullmatch(value):
        raise ValueError(f"Invalid {label}: {value or '(empty)'}")
    return value


def write_git_token(token):
    """Hand a clone token to the CLI's git askpass helper without putting it on argv."""
    runtime = CONFIG_DIR / "runtime"
    osutil.private_dir(runtime)
    token_file = runtime / "git-token"
    fd = os.open(token_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as handle:
        handle.write(f"{int(time.time()) + 900}\n{token}\n")


def run_step(argv, cwd=None, env=None, stdin=None):
    return ("run", argv, cwd, env, stdin)


def tool(name):
    path = shutil.which(name)
    if not path:
        raise ValueError(f"{name} is not installed or not on PATH")
    return path


def node_step(argv, cwd):
    """A Node command: on Linux/macOS load nvm/volta first (the app has no shell profile)."""
    if IS_WINDOWS:
        return run_step([tool(argv[0]), *argv[1:]], cwd)
    return run_step(["bash", "-c", apps.NODE_PRELUDE + 'exec "$@"', "ld", *argv], cwd)


def place_project(src, dest, mode):
    """Portable-mode version of `laravel-dev adopt`: returns a step."""
    def work(log):
        if os.path.lexists(dest):
            raise TaskError(f"{dest} already exists in the www folder. Choose another site name.")
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if mode == "move":
            log(f"Moving {src} -> {dest}\n")
            shutil.move(src, dest)
        elif mode == "copy":
            log(f"Copying {src} -> {dest} (this can take a while for node_modules / vendor)\n")
            shutil.copytree(src, dest, symlinks=True)
        else:
            log(f"Linking {dest} -> {src}\n")
            try:
                os.symlink(src, dest, target_is_directory=True)
            except OSError:
                if not IS_WINDOWS:
                    raise
                # Symlinks need Developer Mode on Windows; a junction does not.
                res = subprocess.run(["cmd", "/C", "mklink", "/J", dest, src], capture_output=True, text=True,
                                     creationflags=osutil.NO_WINDOW)
                if res.returncode != 0:
                    raise TaskError(res.stdout + res.stderr) from None
        log("Done.\n")
    return ("py", work)


def register_step(name, path_getter, kind, port, domain=""):
    """Portable mode: write the registry record once the project folder exists."""
    def work(log):
        path = path_getter()
        detected = kind or apps.detect_type(path) or "node"
        fields = {
            "PROJECT_TYPE": detected,
            "RUNTIME": "python" if detected == "django" else "php" if detected == "laravel" else "node",
            "PROJECT_PATH": path, "DOMAIN": domain or f"localhost:{port}", "PORT": port,
            "RUN_MODE": "dev", "RUN_COMMAND": "", "STATUS": "ready",
            "PACKAGE_MANAGER": apps.package_manager(path) if detected not in ("django", "laravel") else "",
        }
        write_record(name, fields)
        if detected == "laravel":
            env_path = Path(path) / ".env"
            if not env_path.exists() and (Path(path) / ".env.example").exists():
                shutil.copyfile(Path(path) / ".env.example", env_path)
            if env_path.exists():
                env_path.write_text(envfile.apply(env_path.read_text(encoding="utf-8"), {"APP_URL": f"http://localhost:{port}"}), encoding="utf-8")
        log(f"Linked {name} ({apps.TYPE_LABELS.get(detected, detected)}) on http://localhost:{port}\nStart it from Laravel Dev.\n")
    return ("py", work)


def parse_semver(v: str) -> tuple[int, ...]:
    clean = re.sub(r"^[vV]", "", v.strip())
    parts = []
    for token in clean.split("."):
        m = re.match(r"^(\d+)", token)
        parts.append(int(m.group(1)) if m else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def check_for_updates(config_dir: Path, current_version: str, force: bool = False) -> dict:
    cache_file = config_dir / "version-check.json"
    now = time.time()
    if not force and cache_file.is_file():
        try:
            cached = json.loads(cache_file.read_text(encoding="utf-8"))
            if now - cached.get("checked_at", 0) < 86400:
                return cached
        except Exception:
            pass

    res_data = {
        "checked_at": now,
        "current_version": current_version,
        "latest_version": current_version,
        "has_update": False,
        "release_url": "",
        "release_notes": "",
        "download_url": "",
        "error": None,
    }

    repo = "dynamite/laravel-dev-tool"
    for env_path in (config_dir / "config.env", BASE_DIR / "config" / "config.env"):
        if env_path.is_file():
            try:
                env_vals = parse_env_file(env_path)
                if env_vals.get("UPDATE_REPO"):
                    repo = env_vals["UPDATE_REPO"].strip().strip('"').strip("'")
                    break
            except Exception:
                pass

    url = f"https://api.github.com/repos/{repo}/releases/latest"
    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": f"laravel-dev-tool/{current_version}",
                "Accept": "application/vnd.github.v3+json",
            },
        )
        with urllib.request.urlopen(req, timeout=3.0) as resp:
            if resp.status == 200:
                payload = json.loads(resp.read().decode("utf-8"))
                tag = payload.get("tag_name", "").lstrip("v")
                latest_tuple = parse_semver(tag)
                current_tuple = parse_semver(current_version)
                has_update = latest_tuple > current_tuple

                tar_asset = None
                sha_asset = None
                for asset in payload.get("assets", []):
                    name = asset.get("name", "")
                    if name.endswith(".tar.gz") and "laravel-dev" in name:
                        tar_asset = asset.get("browser_download_url")
                    elif name.endswith(".sha256") and "laravel-dev" in name:
                        sha_asset = asset.get("browser_download_url")

                res_data.update({
                    "latest_version": tag,
                    "has_update": has_update,
                    "release_url": payload.get("html_url", ""),
                    "release_notes": (payload.get("body") or "")[:1000],
                    "download_url": tar_asset or payload.get("tarball_url", ""),
                    "sha256_url": sha_asset or "",
                })
    except Exception as exc:
        res_data["error"] = str(exc)

    if res_data.get("error") is None:
        try:
            cache_file.write_text(json.dumps(res_data, indent=2), encoding="utf-8")
        except Exception:
            pass

    return res_data


def build_action(action, p):
    """Translate a UI request into {"title", "steps", "site"}. All input is validated here."""
    versions = php_versions()

    def php(optional=False):
        version = (p.get("php") or "").strip()
        if optional and not version:
            return ""
        if not MANAGED and not version:
            return versions[0] if versions else ""
        if version not in versions:
            raise ValueError(f"PHP {version or '(none)'} is not installed")
        return version

    def domain():
        value = (p.get("domain") or "").strip().lower()
        return require(DOMAIN_RE, value, "domain") if value else ""

    def task(title, steps, site=None):
        return {"title": title, "steps": steps, "site": site}

    root = sites_dir()

    if action == "create":
        kind = (p.get("type") or "laravel").strip()
        if kind not in ("laravel", *apps.APP_TYPES):
            raise ValueError(f"Unsupported project type: {kind}")
        name = require(NEW_NAME_RE, p.get("name"), "site name")
        custom_domain = domain()
        if kind not in ("laravel", "next", "nuxt", "django"):
            raise ValueError("New projects can be Laravel, Next.js, Nuxt or Django")
        port = str(apps.allocate_port(used_ports()))
        label = f"Create {apps.TYPE_LABELS[kind]} {name}" if kind != "laravel" else f"Create {name}"
        if MANAGED:
            if kind != "laravel":
                return task(label, [run_step([CLI, "create-app", kind, name, port, custom_domain])], name)
            worker_flag = ["--worker"] if p.get("worker") else []
            starter = (p.get("starter") or "none").strip()
            db_choice = (p.get("db") or "sqlite").strip()
            pest_flag = "1" if p.get("pest") else "0"
            domain_arg = custom_domain if custom_domain else ""
            addons = (p.get("addons") or "").strip()
            addons_arg = [addons] if addons else []
            return task(label, [run_step([CLI, "create", name, php(), domain_arg, starter, db_choice, pest_flag] + addons_arg + worker_flag)], name)
        dest = root / name
        if dest.exists():
            raise ValueError(f"{dest} already exists")
        root.mkdir(parents=True, exist_ok=True)
        if kind == "laravel":
            steps = [run_step([tool("composer"), "create-project", "--no-interaction", "laravel/laravel", name], str(root))]
        elif kind == "next":
            steps = [node_step(["npx", "--yes", "create-next-app@latest", name, "--yes", "--skip-install", "--disable-git"], str(root)),
                     node_step(["npm", "install"], str(dest))]
        elif kind == "nuxt":
            steps = [node_step(["npx", "--yes", "nuxi@latest", "init", name, "--template", "minimal", "--packageManager", "npm",
                                "--no-gitInit", "--no-install", "--modules="], str(root)),
                     node_step(["npm", "install"], str(dest))]
        else:
            python = tool("python" if IS_WINDOWS else "python3")
            venv_py = str(dest / apps.VENV_PYTHON)
            steps = [("py", lambda log: dest.mkdir(parents=True)),
                     run_step([python, "-m", "venv", str(dest / ".venv")], str(dest)),
                     run_step([venv_py, "-m", "pip", "install", "--upgrade", "pip", "django"], str(dest)),
                     run_step([venv_py, "-m", "django", "startproject", "config", str(dest)], str(dest)),
                     ("py", lambda log: (dest / "requirements.txt").write_text(
                         subprocess.run([venv_py, "-m", "pip", "freeze"], capture_output=True, text=True,
                                        creationflags=osutil.NO_WINDOW).stdout))]
        return task(label, steps + [register_step(name, lambda: str(dest), kind, port)], name)

    if action == "link":
        name = require(NEW_NAME_RE, p.get("name"), "site name")
        path = os.path.realpath(os.path.expanduser((p.get("path") or "").strip()))
        if not os.path.isdir(path):
            raise ValueError("That folder does not exist.")
        placement = p.get("placement") or "keep"
        if placement not in PLACEMENTS:
            raise ValueError("Unknown placement")
        dest = str(root / name)
        if placement != "keep" and os.path.realpath(dest) == path:
            placement = "keep"
        if placement != "keep" and os.path.lexists(dest):
            raise ValueError(f"{dest} already exists in the www folder — choose another site name.")
        if kind == "laravel" and not Path(path, "public", "index.php").is_file():
            raise ValueError("That folder has no public/index.php — pick a Laravel project root.")
        target = path if placement == "keep" else dest
        port = str(apps.allocate_port(used_ports()))
        steps = []
        if MANAGED:
            if placement != "keep":
                steps.append(run_step([CLI, "adopt", placement, path, name]))
            if kind != "laravel":
                steps.append(run_step([CLI, "link-app", name, target, kind, port, domain()]))
            else:
                worker_flag = ["--worker"] if p.get("worker") else []
                steps.append(run_step([CLI, "link", name, target, php(), domain()] + worker_flag))
        else:
            if placement != "keep":
                steps.append(place_project(path, dest, placement))
            steps.append(register_step(name, lambda: target, kind, port))
        return task(f"Link {name}", steps, name)

    if action == "clone":
        name = require(NEW_NAME_RE, p.get("name"), "site name")
        repo = require(REPO_RE, p.get("repo"), "repository URL")
        port = str(apps.allocate_port(used_ports()))
        if MANAGED:
            if (p.get("token") or "").strip():
                write_git_token(p["token"].strip())
            return task(f"Clone {name}", [run_step([CLI, "git-clone", name, repo, php(), "", domain(), port])], name)
        dest = root / name
        if dest.exists():
            raise ValueError(f"{dest} already exists")
        root.mkdir(parents=True, exist_ok=True)
        url = repo
        token = (p.get("token") or "").strip()
        if token and url.startswith("https://"):
            url = "https://" + "x-access-token:" + token + "@" + url[len("https://"):]
        return task(f"Clone {name}", [run_step([tool("git"), "clone", "--progress", url, name], str(root)),
                                      register_step(name, lambda: str(dest), "", port)], name)

    if action in ("app-install", "app-build", "app-script", "manage"):
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        path = site["path"]
        if site["type"] == "django" and action in ("app-install", "manage"):
            py = apps.venv_python(path)
            if action == "app-install":
                if not Path(path, "requirements.txt").is_file():
                    raise ValueError("No requirements.txt in this project")
                return task(f"pip install · {site['name']}", [run_step([py, "-m", "pip", "install", "-r", "requirements.txt"], path)], site["name"])
            args = shlex.split(p.get("args") or "")
            if not args:
                raise ValueError("Type a manage.py command, e.g. migrate")
            return task(f"manage.py {args[0]} · {site['name']}", [run_step([py, "manage.py", *args], path)], site["name"])
        if action == "manage":
            raise ValueError("manage.py is only for Django projects")
        if not Path(path, "package.json").is_file():
            raise ValueError("No package.json in this project")
        pm = apps.package_manager(path)
        if action == "app-install":
            argv = [pm, "install"]
        elif action == "app-build":
            argv = [pm, "run", "build"]
        else:
            script = (p.get("script") or "").strip()
            if script not in apps.scripts(path):
                raise ValueError(f"package.json has no script called {script!r}")
            argv = [pm, "run", script]
        return task(f"{' '.join(argv)} · {site['name']}", [node_step(argv, path)], site["name"])

    if action == "npm":
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        path = site["path"]
        pm = (p.get("pm") or "").strip() or apps.package_manager(path)
        if pm not in ("npm", "pnpm", "yarn", "bun"):
            raise ValueError(f"Unsupported package manager: {pm}")
        raw_args = re.sub(r"^(npm|pnpm|yarn|bun)\s+", "", (p.get("args") or p.get("cmd") or "").strip())
        args = shlex.split(raw_args)
        if not args:
            raise ValueError(f"Type a {pm} command, e.g. run build or install")
        if args[0] not in ("init", "create") and not Path(path, "package.json").is_file():
            raise ValueError("No package.json found in this project")
        npm_builtins = {
            "install", "i", "add", "ci", "update", "up", "uninstall", "remove", "rm",
            "run", "run-script", "start", "test", "t", "stop", "restart", "init", "create",
            "audit", "outdated", "ls", "list", "exec", "dlx", "pkg", "cache", "config",
            "dedupe", "prune", "rebuild", "pack", "publish", "version", "view", "info",
            "why", "explain", "doctor", "help", "--version", "-v",
        }
        if pm == "npm" and args[0] not in npm_builtins and not args[0].startswith("-"):
            pkg_scripts = apps.scripts(path)
            if args[0] in pkg_scripts or args[0] == "build":
                args = ["run", *args]
        argv = [pm, *args]
        return task(f"{pm} {' '.join(args)} · {site['name']}", [node_step(argv, path)], site["name"])

    if action in ("unlink", "delete") and not MANAGED:
        name = require(NAME_RE, p.get("name"), "site name")
        site = find_site(name)

        def remove(log):
            if site.get("running"):
                PROCESSES.stop(name, site["path"])
            if action == "delete":
                target = os.path.realpath(site["path"])
                if target in (os.path.realpath(str(HOME)), os.path.realpath(str(sites_dir())), os.path.abspath(os.sep)):
                    raise TaskError(f"Refusing to delete {target}")
                if os.path.islink(site["path"]):
                    os.unlink(site["path"])
                elif os.path.isdir(target):
                    log(f"Deleting {target}\n")
                    shutil.rmtree(target)
            (REGISTRY_DIR / f"{name}.env").unlink(missing_ok=True)
            log(f"{'Deleted' if action == 'delete' else 'Unlinked'} {name}.\n")
        return task(f"{action.capitalize()} {name}", [("py", remove)], name)

    if not MANAGED and action in ("repair", "secure", "diagnose", "worker-setup", "worker", "worker-config", "cron",
                                  "reverb", "service", "services", "profiler"):
        raise ValueError("Not available on this system — on macOS and Windows each site runs its own server.")

    if action in ("repair", "secure", "unlink", "delete", "diagnose", "worker-setup"):
        name = require(NAME_RE, p.get("name"), "site name")
        site = next((s for s in list_sites() if s["name"] == name), None)
        if action in ("unlink", "delete"):
            if site and site.get("running"):
                PROCESSES.stop(name, site["path"])  # free the port and the folder first
        argv = [CLI, action, name]
        if action in ("repair", "worker-setup"):
            chosen_php = php(optional=True) or (site.get("php") if site and site.get("php") in versions else "")
            if chosen_php:
                argv.append(chosen_php)
        return task(f"{action.replace('-', ' ').capitalize()} {name}", [run_step(argv)], name)

    if action == "worker":
        name = require(NAME_RE, p.get("name"), "site name")
        op = require(re.compile(r"start|stop|restart"), p.get("op"), "worker action")
        return task(f"{op.capitalize()} worker · {name}", [run_step([CLI, "worker", op, name])], name)

    if action == "worker-config":
        name = require(NAME_RE, p.get("name"), "site name")
        opts = []
        mode = (p.get("mode") or "auto").strip()
        opts.append(f"mode={require(re.compile(r'auto|queue|horizon'), mode, 'worker mode')}")
        checks = {"queues": r"[A-Za-z0-9_.:-]+(,[A-Za-z0-9_.:-]+)*", "processes": r"[1-9]|1[0-9]|20",
                  "tries": r"[0-9]{1,3}", "timeout": r"[0-9]{1,5}", "sleep": r"[0-9]{1,3}"}
        for key, pattern in checks.items():
            value = str(p.get(key) or "").replace(" ", "")
            if value:
                opts.append(f"{key}={require(re.compile(pattern), value, key)}")
        return task(f"Worker settings · {name}", [run_step([CLI, "worker-config", name, *opts])], name)

    if action == "cron":
        name = require(NAME_RE, p.get("name"), "site name")
        op = require(re.compile(r"enable|disable"), p.get("op"), "scheduler action")
        site = find_site(name)
        argv = [CLI, "cron", op, name]
        if op == "enable" and site.get("php"):
            argv.append(site["php"])
        return task(f"{'Enable' if op == 'enable' else 'Disable'} scheduler · {name}", [run_step(argv)], name)

    if action == "profiler":
        # composer can take minutes, so this runs as a task with live output
        # instead of a request that would time out.
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        if site.get("type") != "laravel":
            raise ValueError("The SQL profiler needs a Laravel project.")
        op = require(re.compile(r"enable|disable"), p.get("op"), "profiler action")
        return task(f"{'Enable' if op == 'enable' else 'Disable'} profiler · {site['name']}",
                    [run_step([CLI, "profiler", op, site["name"]])], site["name"])

    if action == "schedule-run":
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        php_bin = php_binary(site.get("php"))
        index = p.get("index")
        cmd = p.get("command") or ""
        desc = p.get("description") or cmd or (f"task #{index}" if index is not None else "schedule:run")

        def run_schedule_step(log):
            log(f"Running scheduled task: {desc}...\n")
            import laravel_dev
            res = laravel_dev.run_scheduled_task(
                site["path"],
                php_bin=php_bin,
                command=cmd,
                task_index=index,
            )
            if res.get("output"):
                log(res["output"] + "\n")
            if not res.get("ok"):
                err = res.get("error") or "Execution failed"
                log(f"Error: {err}\n")
                raise TaskError(err)
            log("Task completed successfully.\n")

        return task(f"Schedule: {desc} · {site['name']}", [("py", run_schedule_step)], site["name"])

    if action == "backup":
        name = require(NAME_RE, p.get("name"), "site name")
        site = find_site(name)
        btype = (p.get("type") or "full").strip()
        if btype not in ("db", "storage", "full"):
            raise ValueError(f"Unknown backup type: {btype}")
        custom_name = (p.get("custom_name") or "").strip() or None
        if custom_name and not re.match(r"^[A-Za-z0-9._-]+$", custom_name):
            raise ValueError("Backup filename can only contain letters, numbers, dashes, dots, and underscores")

        def run_backup_step(log, is_cancelled=None):
            log(f"Starting {btype} snapshot for {name}...\n")
            import laravel_dev
            res = laravel_dev.create_backup(site["path"], backup_type=btype, custom_name=custom_name, log_fn=log, is_cancelled=is_cancelled)
            if not res.get("ok"):
                err = res.get("error") or "Backup failed"
                log(f"Error: {err}\n")
                raise TaskError(err)
            log(f"Snapshot created: {res.get('filename')} ({res.get('size_human')}) in {res.get('duration_ms')}ms\n")

        return task(f"Backup ({btype}) · {name}", [("py", run_backup_step)], name)

    if action == "backup-restore":
        name = require(NAME_RE, p.get("name"), "site name")
        site = find_site(name)
        filename = (p.get("filename") or "").strip()
        if not filename or not re.match(r"^[A-Za-z0-9._-]+$", filename):
            raise ValueError("Invalid backup filename")

        def run_restore_step(log):
            log(f"Restoring snapshot {filename} for {name}...\n")
            import laravel_dev
            res = laravel_dev.restore_backup(site["path"], filename=filename)
            if not res.get("ok"):
                err = res.get("error") or "Restore failed"
                log(f"Error: {err}\n")
                raise TaskError(err)
            log(f"{res.get('message', 'Restore completed.')}\n")

        return task(f"Restore {filename} · {name}", [("py", run_restore_step)], name)

    if action == "backup-upload":
        name = require(NAME_RE, p.get("name"), "site name")
        site = find_site(name)
        filename = require(re.compile(r"^[A-Za-z0-9._-]+$"), p.get("filename"), "backup filename")
        remote_id = require(re.compile(r"^[A-Za-z0-9._-]+$"), p.get("remote"), "remote server ID")
        remote_dir = str(p.get("remote_dir") or "").strip()

        def run_upload_step(log):
            log(f"Uploading snapshot {filename} to remote server {remote_id}...\n")
            import laravel_dev
            res = laravel_dev.upload_backup_remote(site["path"], filename=filename, remote_server_id=remote_id, remote_path=remote_dir, log_fn=log)
            if not res.get("ok"):
                err = res.get("error") or "Upload failed"
                log(f"Error: {err}\n")
                raise TaskError(err)
            log(f"{res.get('message', 'Upload completed.')}\n")

        return task(f"Upload backup {filename} · {name}", [("py", run_upload_step)], name)

    if action == "backup-prune":
        name = require(NAME_RE, p.get("name"), "site name")
        site = find_site(name)
        keep = int(p.get("keep") or 5)

        def run_prune_step(log):
            log(f"Pruning snapshots for {name} (keeping last {keep})...\n")
            import laravel_dev
            res = laravel_dev.prune_backups(site["path"], keep=keep)
            deleted = res.get("deleted", 0)
            log(f"Prune completed: kept {res.get('kept', 0)}, deleted {deleted} snapshot(s).\n")

        return task(f"Prune backups · {name}", [("py", run_prune_step)], name)

    if action == "app-update":
        def run_update_step(log):
            import hashlib
            import shutil
            import tarfile
            import urllib.request

            download_url = (p.get("download_url") or "").strip()
            sha256_url = (p.get("sha256_url") or "").strip()
            latest_version = (p.get("latest_version") or "latest").strip()

            cache_dir = Path.home() / ".cache" / "laravel-dev" / "updates"
            cache_dir.mkdir(parents=True, exist_ok=True)

            if not download_url:
                install_script = BASE_DIR / "install.sh"
                if not install_script.is_file():
                    raise ValueError(f"install.sh not found at {install_script}")
                log("No download URL provided. Running local install.sh...\n")
                res = subprocess.run(["bash", str(install_script)], cwd=str(BASE_DIR), capture_output=True, text=True)
                log(res.stdout + res.stderr)
                if res.returncode != 0:
                    raise ValueError(f"Update failed with code {res.returncode}")
                return

            tar_file = cache_dir / f"laravel-dev-{latest_version}.tar.gz"
            log(f"Downloading update from {download_url}...\n")
            req = urllib.request.Request(download_url, headers={"User-Agent": "laravel-dev-tool/update"})
            with urllib.request.urlopen(req, timeout=30.0) as resp:
                tar_bytes = resp.read()
            tar_file.write_bytes(tar_bytes)

            computed_sha = hashlib.sha256(tar_bytes).hexdigest()
            log(f"Computed SHA-256: {computed_sha}\n")

            if sha256_url:
                log(f"Fetching checksum from {sha256_url}...\n")
                try:
                    s_req = urllib.request.Request(sha256_url, headers={"User-Agent": "laravel-dev-tool/update"})
                    with urllib.request.urlopen(s_req, timeout=15.0) as resp:
                        expected_sha = resp.read().decode("utf-8").strip().split()[0]
                    log(f"Expected SHA-256: {expected_sha}\n")
                    if computed_sha.lower() != expected_sha.lower():
                        raise ValueError(f"Checksum mismatch! Computed: {computed_sha}, Expected: {expected_sha}")
                    log("✔ Checksum verified successfully!\n")
                except Exception as exc:
                    raise ValueError(f"Checksum verification failed: {exc}")
            else:
                log("Notice: No SHA-256 asset found on release. Proceeding with caution...\n")

            extract_dir = cache_dir / f"extract-{latest_version}"
            if extract_dir.exists():
                shutil.rmtree(extract_dir)
            extract_dir.mkdir(parents=True, exist_ok=True)

            log("Extracting update archive...\n")
            with tarfile.open(tar_file, "r:gz") as tar:
                try:
                    tar.extractall(extract_dir, filter="data")
                except TypeError:
                    tar.extractall(extract_dir)

            candidates = list(extract_dir.glob("**/install.sh"))
            if not candidates:
                raise ValueError("Could not find install.sh in update archive.")
            new_install = candidates[0]
            new_install.chmod(0o755)

            log(f"Executing extracted installer: {new_install}...\n")
            res = subprocess.run(["bash", str(new_install)], cwd=str(new_install.parent), capture_output=True, text=True)
            log(res.stdout + res.stderr)
            if res.returncode != 0:
                raise ValueError(f"Update installation failed with exit code {res.returncode}")
            log("\nUpdate completed successfully! 🎉 Please restart the app.\n")

        return task("Update Laravel Dev Tool", [("py", run_update_step)])

    if action == "reverb":
        name = require(NAME_RE, p.get("name"), "site name")
        op = require(re.compile(r"start|stop|restart|status|log"), p.get("op"), "reverb action")
        return task(f"{op.capitalize()} Reverb · {name}", [run_step([CLI, "reverb", op, name])], name)

    if action == "tunnel":
        name = require(NAME_RE, p.get("name"), "site name")
        op = require(re.compile(r"start|stop|restart|status|log|logs|token"), p.get("op"), "tunnel action")
        mode = (p.get("mode") or "quick").strip()
        token = (p.get("token") or "").strip()
        cmd = [CLI, "tunnel", op, name]
        if op in ("start", "restart"):
            if mode:
                cmd.extend(["--mode", mode])
            if token:
                cmd.extend(["--token", token])
        elif op == "token" and token:
            cmd.append(token)
        return task(f"{op.capitalize()} Cloudflare Tunnel · {name}", [run_step(cmd)], name)

    if action in ("terminal", "terminal-exec", "sh"):
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        cmd_str = (p.get("command") or p.get("cmd") or "").strip()
        if not cmd_str:
            raise ValueError("Command cannot be empty")
        shell_bin = os.environ.get("SHELL") or "/bin/bash"
        argv = [shell_bin, "-c", cmd_str]
        display_cmd = cmd_str if len(cmd_str) <= 32 else f"{cmd_str[:29]}…"
        return task(f"$ {display_cmd} · {site['name']}", [run_step(argv, site["path"])], site["name"])

    if action == "service":
        unit = require(UNIT_RE, p.get("unit"), "service")
        op = require(re.compile(r"start|stop|restart"), p.get("op"), "service action")
        return task(f"{op.capitalize()} {unit}", [run_step([CLI, "service", op, unit])])

    if action == "services":
        op = require(re.compile(r"start|stop"), p.get("op"), "action")
        return task(f"{op.capitalize()} all services", [run_step([CLI, op])])

    if action == "git":
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        op = require(re.compile(r"fetch|pull|push"), p.get("op"), "git action")
        argv = [CLI, f"git-{op}", site["path"]] if MANAGED else [tool("git"), op, *(["--ff-only"] if op == "pull" else [])]
        return task(f"Git {op} · {site['name']}", [run_step(argv, None if MANAGED else site["path"])], site["name"])

    if action == "git-checkout":
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        branch = require(re.compile(r"^[a-zA-Z0-9._/-]+$"), p.get("branch"), "branch name")
        git_bin = tool("git") or "git"
        if p.get("new"):
            argv = [git_bin, "checkout", "-b", branch]
        elif "/" in branch and not branch.startswith("refs/"):
            local_name = branch.split("/", 1)[1]
            argv = [git_bin, "checkout", "-B", local_name, "--track", branch]
        else:
            argv = [git_bin, "checkout", branch]
        return task(f"Git checkout {branch} · {site['name']}", [run_step(argv, site["path"])], site["name"])

    if action == "git-commit":
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        msg = str(p.get("message") or "").strip()
        if not msg:
            raise ValueError("Commit message cannot be empty")
        git_bin = tool("git") or "git"
        steps = [
            run_step([git_bin, "add", "-A"], site["path"]),
            run_step([git_bin, "commit", "-m", msg], site["path"]),
        ]
        return task(f"Git commit · {site['name']}", steps, site["name"])

    if action == "git-stash":
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        op = require(re.compile(r"^(push|pop|drop|clear)$"), p.get("op"), "stash operation")
        git_bin = tool("git") or "git"
        args = ["push", "-u"] if op == "push" else [op]
        return task(f"Git stash {op} · {site['name']}", [run_step([git_bin, "stash", *args], site["path"])], site["name"])

    if action in ("artisan", "composer"):
        site = find_site(require(NAME_RE, p.get("name"), "site name"))
        raw_args = (p.get("args") or p.get("cmd") or "").strip()
        binary = php_binary(site["php"])
        if action == "artisan":
            raw_args = re.sub(r"^(?:php\s+)?artisan\s+", "", raw_args)
            args = shlex.split(raw_args)
            if not args:
                raise ValueError("Type an artisan command, e.g. migrate")
            argv = [binary, "artisan", *args]
            return task(f"artisan {' '.join(args)} · {site['name']}", [run_step(argv, site["path"])], site["name"])
        raw_args = re.sub(r"^composer\s+", "", raw_args)
        args = shlex.split(raw_args) or ["install"]
        composer = composer_binary()
        if not composer:
            raise ValueError("composer is not installed")
        display_args = list(args)
        if "--no-interaction" not in args and "-n" not in args:
            args = [*args, "--no-interaction"]
        # composer is a PHP script on Linux/macOS (run it with the site's PHP and unlimited memory); a .bat on Windows.
        if IS_WINDOWS or not _is_php_script(composer):
            argv = [composer, *args]
        else:
            argv = [binary, "-d", "memory_limit=-1", composer, *args]
        env = dict(os.environ)
        env["COMPOSER_MEMORY_LIMIT"] = "-1"
        env["COMPOSER_NO_INTERACTION"] = "1"
        php_dir = os.path.dirname(binary)
        if php_dir and os.path.isdir(php_dir) and php_dir not in env.get("PATH", ""):
            env["PATH"] = f"{php_dir}{os.pathsep}{env.get('PATH', '')}"
        return task(f"composer {' '.join(display_args)} · {site['name']}", [run_step(argv, site["path"], env=env)], site["name"])

    if action == "php-install":
        version = (p.get("version") or "").strip()
        if version not in PHP_INSTALLABLE:
            raise ValueError(f"Unsupported PHP version: {version}")
        return task(f"Install PHP {version}", [run_step([CLI, "php-install", version])])

    if action in ("isolate", "site-php"):
        name = require(NAME_RE, p.get("name"), "site name")
        version = (p.get("version") or "").strip()
        if version not in versions:
            raise ValueError(f"PHP {version} is not installed")
        return task(f"Switch {name} to PHP {version}", [run_step([CLI, "isolate", name, version])], name)

    if action == "unisolate":
        name = require(NAME_RE, p.get("name"), "site name")
        return task(f"Reset {name} to default PHP", [run_step([CLI, "unisolate", name])], name)

    if action == "node-install":
        version = require(re.compile(r"^[0-9.]+$"), str(p.get("version") or ""), "node version")
        return task(f"Install Node.js {version}", [run_step([CLI, "node-install", version])])

    if action == "node-use":
        name = require(NAME_RE, p.get("name"), "site name")
        version = require(re.compile(r"^[0-9.]+$"), str(p.get("version") or ""), "node version")
        return task(f"Use Node.js {version} for {name}", [run_step([CLI, "node-use", name, version])], name)

    if action == "shim":
        op = require(re.compile(r"^(enable|disable)$"), p.get("op"), "shim operation")
        return task(f"{op.capitalize()} PHP CLI Shim", [run_step([CLI, "shim", op])])

    if action == "php-xdebug":
        version = (p.get("version") or "").strip()
        if version not in versions:
            raise ValueError(f"Unknown PHP version: {version}")
        state = "on" if p.get("enable") else "off"
        return task(f"Xdebug {state} · PHP {version}", [run_step([CLI, "php", version, "xdebug", state])])

    if action == "php-jit":
        version = (p.get("version") or "").strip()
        if version not in versions:
            raise ValueError(f"Unknown PHP version: {version}")
        return task(f"Xdebug JIT Trigger · PHP {version}", [run_step([CLI, "php-jit", version])])

    if action == "debug-session":
        site_name = require(NAME_RE, p.get("name"), "site name")
        op = require(re.compile(r"^(on|off)$"), p.get("op"), "operation")
        if op == "on":
            try:
                minutes = int(p.get("minutes") or 30)
            except (TypeError, ValueError):
                raise ValueError("Minutes must be a number.")
            if not 1 <= minutes <= 480:
                raise ValueError("Minutes must be between 1 and 480.")
            return task(f"Debug session ON ({minutes} min) · {site_name}",
                        [run_step([CLI, "debug-session", "on", site_name, str(minutes)])], site_name)
        return task(f"Debug session OFF · {site_name}", [run_step([CLI, "debug-session", "off", site_name])], site_name)

    if action == "debug-artisan":
        site_name = require(NAME_RE, p.get("name"), "site name")
        args_str = require(re.compile(r"^[A-Za-z0-9:._\-\s=/]+$"), (p.get("args") or "").strip(), "artisan arguments")
        return task(f"Debug artisan {args_str} · {site_name}", [run_step([CLI, "debug", site_name, "artisan", *args_str.split()])], site_name)

    if action == "php-ini":
        version = (p.get("version") or "").strip()
        if version not in versions:
            raise ValueError(f"Unknown PHP version: {version}")
        key = require(re.compile(r"memory_limit|upload_max_filesize|post_max_size|max_execution_time|max_input_time"
                                 r"|max_input_vars|display_errors|date\.timezone"), p.get("key"), "ini directive")
        val = require(re.compile(r"[A-Za-z0-9._/+-]{1,64}"), str(p.get("value") or ""), f"value for {key}")
        return task(f"php.ini {key}={val} · PHP {version}", [run_step([CLI, "php-ini", version, key, val])])

    if action == "php-ext":
        version = (p.get("version") or "").strip()
        if version not in versions:
            raise ValueError(f"Unknown PHP version: {version}")
        ext = require(re.compile(r"^[a-zA-Z0-9_-]+$"), p.get("ext"), "extension name")
        return task(f"Install PHP {version} {ext}", [run_step([CLI, "php-ext", version, "install", ext])])

    if action == "service-install":
        name = require(re.compile(r"^(mailpit|redis|redis-server|meilisearch|minio|postgresql|postgres)$"), p.get("name"), "service name")
        return task(f"Install {name}", [run_step([CLI, "service-install", name])])

    if action == "service-repair":
        name = require(re.compile(r"^(mailpit|redis|redis-server|meilisearch|minio|postgresql|postgres|pgsql|nginx|mysql|mariadb|all)$"), p.get("name"), "service name")
        return task(f"Repair {name}", [run_step([CLI, "service-repair", name])])

    if action == "service-env":
        site_name = require(NAME_RE, p.get("name"), "site name")
        service = require(re.compile(r"^(mailpit|redis|meilisearch|minio|postgresql)$"), p.get("service"), "service name")
        apply_service_to_site(site_name, service)
        return task(f"Configure {service} in {site_name}", [run_step(["echo", f"Configured {service} in {site_name} .env"])], site_name)

    if action == "npm":
        cmd = str(p.get("cmd") or "install").strip()
        npm_bin = shutil.which("npm") or "npm"
        return task(f"npm {cmd} · {site['name']}", [run_step([npm_bin, *cmd.split()], site["path"])], site["name"])

    if action == "supervisor-program":
        site_name = require(NAME_RE, p.get("name"), "site name")
        program = require(re.compile(r"^[a-zA-Z0-9_-]+$"), p.get("program"), "program name")
        op = require(re.compile(r"^(start|stop|restart|remove)$"), p.get("op"), "operation")
        return task(f"Supervisor {op} {program} · {site_name}", [run_step([CLI, "supervisor-program", site_name, program, op])], site_name)

    if action == "supervisor-create":
        site_name = require(NAME_RE, p.get("name"), "site name")
        program = require(re.compile(r"^[a-zA-Z0-9_-]+$"), p.get("program"), "program name")
        command = str(p.get("command") or "").strip()
        if not command:
            raise ValueError("Command is required for supervisor program")
        numprocs = str(int(p.get("numprocs") or 1))
        return task(f"Add supervisor program {program} · {site_name}", [run_step([CLI, "supervisor-create", site_name, program, command, numprocs])], site_name)

    if action == "dns":
        op = require(re.compile(r"^(enable|disable)$"), p.get("op"), "operation")
        return task(f"{op.capitalize()} Wildcard DNS (*.test)", [run_step([CLI, "dns", op])])

    if action == "park":
        op = require(re.compile(r"^(enable|disable)$"), p.get("op"), "operation")
        return task(f"{op.capitalize()} Parked Directories", [run_step([CLI, "park", op])])

    if action == "octane":
        site_name = require(NAME_RE, p.get("name"), "site name")
        op = require(re.compile(r"^(enable|disable|reload|restart)$"), p.get("op"), "operation")
        if op == "enable":
            server = require(re.compile(r"^(frankenphp|roadrunner|swoole)$"), p.get("server") or "frankenphp", "octane server")
            workers = str(p.get("workers") or "auto").strip()
            watch = "1" if p.get("watch") else "0"
            return task(f"Enable Octane ({server}) · {site_name}", [run_step([CLI, "octane", "enable", site_name, server, workers, watch])], site_name)
        elif op == "disable":
            return task(f"Disable Octane · {site_name}", [run_step([CLI, "octane", "disable", site_name])], site_name)
        elif op == "reload":
            return task(f"Reload Octane · {site_name}", [run_step([CLI, "octane", "reload", site_name])], site_name)
        elif op == "restart":
            return task(f"Restart Octane · {site_name}", [run_step([CLI, "octane", "restart", site_name])], site_name)

    if action == "team-apply":
        site_name = require(NAME_RE, p.get("name"), "site name")
        return task(f"Apply Team Config (herd.yml) · {site_name}", [run_step([CLI, "team", "apply", site_name])], site_name)

    if action == "team-export":
        site_name = require(NAME_RE, p.get("name"), "site name")
        filename = require(re.compile(r"^[A-Za-z0-9._-]+$"), p.get("filename") or "herd.yml", "filename")
        return task(f"Export {filename} · {site_name}", [run_step([CLI, "team", "export", site_name, filename])], site_name)

    if action == "workspace-create":
        site_name = require(NAME_RE, p.get("name"), "site name")
        branch = require(re.compile(r"^[A-Za-z0-9._\-/]+$"), p.get("branch"), "branch name")
        source_branch = (p.get("source_branch") or "").strip()
        cmd = [CLI, "workspace", "create", site_name, branch]
        if source_branch:
            cmd.append(require(re.compile(r"^[A-Za-z0-9._\-/]+$"), source_branch, "source branch"))
        return task(f"Create Workspace ({branch}) · {site_name}", [run_step(cmd)], site_name)

    if action == "workspace-delete":
        site_name = require(NAME_RE, p.get("name"), "site name")
        branch = require(re.compile(r"^[A-Za-z0-9._\-/]+$"), p.get("branch"), "branch name")
        return task(f"Delete Workspace ({branch}) · {site_name}", [run_step([CLI, "workspace", "delete", site_name, branch])], site_name)

    if action in ("service-instance-create", "service-instance-start", "service-instance-stop", "service-instance-delete"):
        srv_type = require(re.compile(r"^(redis|mysql|postgresql)$"), p.get("type") or "redis", "service type")
        srv_name = require(INSTANCE_NAME_RE, p.get("instance_name"), "instance name")
        verb = action.rsplit("-", 1)[1]
        if verb == "create":
            try:
                srv_port = int(p.get("port") or {"redis": 6380, "mysql": 3307, "postgresql": 5433}[srv_type])
            except (TypeError, ValueError):
                raise ValueError("Port must be a number.")
            if not 1024 <= srv_port <= 65535:
                raise ValueError("Port must be between 1024 and 65535.")
            return task(f"Create Service Instance {srv_type}:{srv_name}",
                        [run_step([CLI, "instance", "create", srv_type, srv_name, str(srv_port)])])
        return task(f"{verb.capitalize()} Service Instance {srv_type}:{srv_name}",
                    [run_step([CLI, "instance", verb, srv_type, srv_name])])

    raise ValueError(f"Unknown action: {action}")


def apply_service_to_site(site_name: str, service: str):
    site = find_site(site_name)
    env_path = Path(site["path"]) / ".env"
    if not env_path.is_file():
        raise ValueError(f".env file not found in {site['path']}")

    # Written by `laravel-dev service-install/service-repair minio`.
    minio_creds = parse_env_file(CONFIG_DIR / "minio.env") if (CONFIG_DIR / "minio.env").is_file() else {}
    configs = {
        "mailpit": {
            "MAIL_MAILER": "smtp",
            "MAIL_HOST": "127.0.0.1",
            "MAIL_PORT": "1025",
            "MAIL_ENCRYPTION": "null",
        },
        "redis": {
            "CACHE_STORE": "redis",
            "CACHE_DRIVER": "redis",
            "QUEUE_CONNECTION": "redis",
            "SESSION_DRIVER": "redis",
            "REDIS_HOST": "127.0.0.1",
            "REDIS_PORT": "6379",
        },
        "meilisearch": {
            "SCOUT_DRIVER": "meilisearch",
            "MEILISEARCH_HOST": "http://127.0.0.1:7700",
        },
        "minio": {
            "FILESYSTEM_DISK": "s3",
            "AWS_ACCESS_KEY_ID": minio_creds.get("MINIO_ROOT_USER") or "minioadmin",
            "AWS_SECRET_ACCESS_KEY": minio_creds.get("MINIO_ROOT_PASSWORD") or "minioadmin",
            "AWS_DEFAULT_REGION": "us-east-1",
            "AWS_BUCKET": "local",
            "AWS_ENDPOINT": "http://127.0.0.1:9000",
            "AWS_USE_PATH_STYLE_ENDPOINT": "true",
        },
        "postgresql": {
            "DB_CONNECTION": "pgsql",
            "DB_HOST": "127.0.0.1",
            "DB_PORT": "5432",
        },
    }
    if service not in configs:
        raise ValueError(f"Unknown service for .env configuration: {service}")

    changes = configs[service]
    text = env_path.read_text(encoding="utf-8", errors="replace")
    new_text = envfile.apply(text, envfile.validate_changes(changes))
    env_path.write_text(new_text, encoding="utf-8")
    return True


# ── environment variables (.env) ─────────────────────────────────────────────

def env_types():
    try:
        return json.loads(ENV_TYPES_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def set_env_type(scope, key, secret):
    data = env_types()
    entry = data.setdefault(scope, {})
    entry[key] = bool(secret)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    ENV_TYPES_FILE.write_text(json.dumps(data, indent=1), encoding="utf-8")


def env_payload(text, exists, files, current, scope, example_text=None):
    """What the Environment editor shows: variables, their kind, and keys .env.example has but this file lacks."""
    overrides = env_types().get(scope, {})
    items = envfile.parse(text) if exists else []
    keys = {i["key"] for i in items}
    variables = [{"key": i["key"], "value": i["value"],
                  "secret": overrides.get(i["key"], envfile.looks_secret(i["key"]))} for i in items]
    missing = []
    if example_text:
        example = envfile.parse(example_text)
        missing = [{"key": i["key"], "value": i["value"]} for i in example if i["key"] not in keys]
    return {"file": current, "files": files, "exists": exists, "variables": variables, "missing": missing,
            "hash": envfile.digest(text if exists else ""), "scope": scope}


def local_env_files(path):
    names = [n for n in envfile.ENV_FILES if (Path(path) / n).is_file()]
    for extra in sorted(p.name for p in Path(path).glob(".env.*")):
        if extra not in names and extra not in (".env.example", ".env.sample", ".env.dist") and not extra.endswith((".bak", "~")):
            names.append(extra)
    return names or [".env"]


def env_file_name(name):
    name = (name or ".env").strip()
    if not re.fullmatch(r"\.env(\.[A-Za-z0-9_.-]+)?", name) or name in (".env.example",):
        raise ValueError("Pick an .env file")
    return name


def read_local_env(site_name, file_name=""):
    site = find_site(require(NAME_RE, site_name, "site name"))
    path = Path(site["path"])
    files = local_env_files(path)
    current = env_file_name(file_name or files[0])
    target = path / current
    exists = target.is_file()
    text = target.read_text(encoding="utf-8", errors="replace") if exists else ""
    example = None
    for candidate in (".env.example", ".env.sample", ".env.dist"):
        if (path / candidate).is_file():
            example = (path / candidate).read_text(encoding="utf-8", errors="replace")
            break
    payload = env_payload(text, exists, files, current, f"local:{site['path']}", example)
    payload["type"] = site["type"]
    payload["config_cached"] = (path / "bootstrap" / "cache" / "config.php").is_file()
    payload["running"] = bool(site.get("running"))
    return payload


def write_local_env(site_name, file_name, changes, base_hash):
    site = find_site(require(NAME_RE, site_name, "site name"))
    target = Path(site["path"]) / env_file_name(file_name)
    text = target.read_text(encoding="utf-8", errors="replace") if target.is_file() else ""
    if base_hash and envfile.digest(text) != base_hash:
        raise ValueError("The file changed on disk since you opened it. Reload to see the latest values.")
    new_text = envfile.apply(text, envfile.validate_changes(changes))
    tmp = target.with_name(target.name + ".ld-tmp")
    tmp.write_text(new_text, encoding="utf-8")
    if target.exists() and not IS_WINDOWS:
        try:
            os.chmod(tmp, target.stat().st_mode & 0o777)
        except OSError:
            pass
    os.replace(tmp, target)
    return read_local_env(site_name, target.name)


_uptime_status = {}
_uptime_lock = threading.Lock()
_uptime_thread = None


def get_sites_uptime():
    with _uptime_lock:
        return dict(_uptime_status)


def start_uptime_monitor():
    global _uptime_thread
    if _uptime_thread and _uptime_thread.is_alive():
        return

    def _loop():
        while True:
            try:
                all_s = list_sites()
                for s in all_s:
                    if not s.get("linked"):
                        continue
                    dom = s.get("domain") or f"{s['name']}.test"
                    url = f"http://{dom}/up"
                    t0 = time.perf_counter()
                    code = 0
                    up = False
                    try:
                        req = urllib.request.Request(url, headers={"User-Agent": "LaravelDev-Uptime/1.0"})
                        with urllib.request.urlopen(req, timeout=3.0) as resp:
                            code = resp.status
                            up = 200 <= code < 400
                    except urllib.error.HTTPError as he:
                        code = he.code
                        if code == 404:
                            try:
                                req2 = urllib.request.Request(f"http://{dom}/", headers={"User-Agent": "LaravelDev-Uptime/1.0"})
                                with urllib.request.urlopen(req2, timeout=3.0) as resp2:
                                    code = resp2.status
                                    up = 200 <= code < 400
                            except urllib.error.HTTPError as he2:
                                code = he2.code
                                up = code < 500
                            except Exception:
                                up = False
                        else:
                            up = code < 500
                    except Exception:
                        code = 0
                        up = False
                    lat = round((time.perf_counter() - t0) * 1000, 1)

                    with _uptime_lock:
                        prev = _uptime_status.get(s["name"])
                        _uptime_status[s["name"]] = {
                            "up": up,
                            "status": code,
                            "latency_ms": lat,
                            "checked_at": datetime.datetime.now().isoformat(),
                        }
                    if prev and prev.get("up") and not up:
                        osutil.notify_desktop(f"Site Down: {s['name']}", f"{dom} is unreachable (HTTP {code})")
            except Exception:
                pass
            time.sleep(60)

    _uptime_thread = threading.Thread(target=_loop, daemon=True, name="laravel-dev-uptime")
    _uptime_thread.start()


# ── Multi-Domain & Wildcard Subdomains (Feature 6) ─────────────────────────

def get_site_domains(name: str) -> dict:
    site = find_site(name)
    record = parse_env_file(REGISTRY_DIR / f"{name}.env")
    aliases_raw = record.get("ALIASES") or record.get("PROJECT_ALIASES") or ""
    aliases = [a.strip() for a in aliases_raw.replace(",", " ").split() if a.strip()]
    wildcard = record.get("WILDCARD", "1") != "0"
    return {
        "ok": True,
        "name": name,
        "primary_domain": site.get("domain") or f"{name}.test",
        "aliases": aliases,
        "wildcard": wildcard,
        "ssl": bool(site.get("ssl", False)),
    }


def update_site_domains(name: str, aliases: list[str] | None = None, wildcard: bool = True) -> dict:
    site = find_site(name)
    if aliases is None:
        aliases = []
    clean_aliases = []
    for a in aliases:
        a = str(a).strip().lower()
        if a and a != site["domain"] and re.match(r"^(\*\.)?[a-z0-9][a-z0-9.-]*\.[a-z0-9-]+$", a):
            clean_aliases.append(a)
    clean_aliases = list(dict.fromkeys(clean_aliases))

    update_record(name, {
        "ALIASES": " ".join(clean_aliases),
        "WILDCARD": "1" if wildcard else "0",
    })

    # The nginx config is regenerated by the caller as a visible `repair` task
    # (it needs sudo and can take longer than a request should block).
    return {
        "ok": True,
        "needs_repair": MANAGED,
        "name": name,
        "primary_domain": site.get("domain") or f"{name}.test",
        "aliases": clean_aliases,
        "wildcard": wildcard,
    }

