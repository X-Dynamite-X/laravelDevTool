"""Encrypted Credential Vault for Laravel Dev Tool.
Protects database passwords, SSH keys, server credentials, and secrets using AES/Fernet + PBKDF2 (100k rounds).
Engineered for maximum security and zero memory overhead.
"""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import secrets

try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    HAS_CRYPTOGRAPHY = True
except ImportError:
    HAS_CRYPTOGRAPHY = False

from osutil import private_file


class VaultError(Exception):
    pass


class VaultManager:
    """Manages secure master-key encryption and credential storage."""

    def __init__(self, config_dir: Path):
        self.config_dir = Path(config_dir).resolve()
        self.vault_file = self.config_dir / "vault.json"
        self._cached_key: bytes | None = None
        self._unlocked = False

    def is_available(self) -> bool:
        return HAS_CRYPTOGRAPHY

    def is_enabled(self) -> bool:
        return self.vault_file.is_file()

    def is_unlocked(self) -> bool:
        return self._unlocked if self.is_enabled() else True

    def is_encrypted(self, val: str | None) -> bool:
        return bool(val and isinstance(val, str) and val.startswith("enc:"))

    def status(self) -> dict:
        """Check if vault is configured and whether it is currently unlocked."""
        is_enabled = self.is_enabled()
        available = self.is_available()
        res = {
            "available": available,
            "enabled": is_enabled,
            "unlocked": self.is_unlocked(),
            "cipher": "Fernet/AES-128-CBC + HMAC-SHA256" if available else None,
        }
        if not available:
            res["error"] = (
                "The python3-cryptography package is required to enable the credential vault. "
                "Install it with: sudo apt install python3-cryptography (or pip install cryptography)."
            )
        return res

    def set_master_key(self, master_password: str, old_password: str | None = None, migrator = None) -> dict:
        """Initialize or change the master password."""
        if not HAS_CRYPTOGRAPHY:
            raise VaultError(
                "The python3-cryptography package is required to enable the credential vault. "
                "Install it with: sudo apt install python3-cryptography (or pip install cryptography)."
            )

        password = (master_password or "").strip()
        if len(password) < 6:
            raise VaultError("Master password must be at least 6 characters long.")

        if self.is_enabled():
            # Changing master password
            if not old_password:
                raise VaultError("Current master password is required to change password.")
            try:
                data = json.loads(self.vault_file.read_text(encoding="utf-8"))
                old_salt = base64.b64decode(data["salt"])
                verifier = data["verifier"]
            except Exception as exc:
                raise VaultError(f"Corrupt vault configuration: {exc}")

            old_key = self._derive_key(old_password.encode("utf-8"), old_salt)
            try:
                if Fernet(old_key).decrypt(verifier.encode("ascii")) != b"LARAVEL_DEV_VAULT_OK":
                    raise VaultError("Incorrect old master password.")
            except Exception:
                raise VaultError("Incorrect old master password.")

            new_salt = secrets.token_bytes(16)
            new_key = self._derive_key(password.encode("utf-8"), new_salt)
            new_verifier = Fernet(new_key).encrypt(b"LARAVEL_DEV_VAULT_OK").decode("ascii")

            if migrator:
                migrator(old_key, new_key)

            data = {
                "version": 2,
                "salt": base64.b64encode(new_salt).decode("ascii"),
                "verifier": new_verifier,
            }
            self.vault_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
            private_file(self.vault_file)

            self._cached_key = new_key
            self._unlocked = True
            return {"ok": True, "message": "Master password changed and credentials re-encrypted."}

        # Initial setup
        salt = secrets.token_bytes(16)
        key = self._derive_key(password.encode("utf-8"), salt)
        verifier = Fernet(key).encrypt(b"LARAVEL_DEV_VAULT_OK").decode("ascii")

        data = {
            "version": 2,
            "salt": base64.b64encode(salt).decode("ascii"),
            "verifier": verifier,
        }

        self.vault_file.parent.mkdir(parents=True, exist_ok=True)
        self.vault_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        private_file(self.vault_file)

        self._cached_key = key
        self._unlocked = True

        if migrator:
            migrator(None, key)

        return {"ok": True, "message": "Master key configured and existing credentials encrypted."}

    def unlock(self, master_password: str) -> dict:
        """Verify master password and unlock vault for current session."""
        if not self.vault_file.is_file():
            return {"ok": True, "unlocked": True, "message": "Vault is not enabled."}

        if not HAS_CRYPTOGRAPHY:
            raise VaultError("The python3-cryptography package is required. Install it with: sudo apt install python3-cryptography")

        try:
            data = json.loads(self.vault_file.read_text(encoding="utf-8"))
            salt = base64.b64decode(data["salt"])
            verifier = data["verifier"]
        except Exception as exc:
            raise VaultError(f"Corrupt vault configuration: {exc}")

        password = (master_password or "").strip()
        key = self._derive_key(password.encode("utf-8"), salt)

        try:
            decrypted = Fernet(key).decrypt(verifier.encode("ascii"))
            if decrypted != b"LARAVEL_DEV_VAULT_OK":
                raise VaultError("Incorrect master password.")
        except Exception:
            raise VaultError("Incorrect master password.")

        self._cached_key = key
        self._unlocked = True
        return {"ok": True, "unlocked": True, "message": "Vault unlocked."}

    def lock(self) -> dict:
        """Lock the vault and clear the encryption key from memory."""
        self._cached_key = None
        self._unlocked = False
        return {"ok": True, "unlocked": False, "message": "Vault locked."}

    def disable_vault(self, master_password: str, migrator = None) -> dict:
        """Disable master key, decrypt all credentials to plaintext, and remove vault configuration."""
        if self.vault_file.is_file():
            self.unlock(master_password)  # Ensure password is valid before removing
            if migrator:
                migrator(self._cached_key, None)
            self.vault_file.unlink()
        self._cached_key = None
        self._unlocked = True
        return {"ok": True, "enabled": False, "message": "Vault disabled and secrets decrypted."}

    def encrypt(self, plaintext: str) -> str:
        """Encrypt string. If vault is not enabled, returns plaintext."""
        if not plaintext or not self.is_enabled():
            return plaintext

        if self.is_encrypted(plaintext):
            return plaintext

        if not self.is_unlocked() or not self._cached_key:
            raise VaultError("Unlock vault to connect")

        token = Fernet(self._cached_key).encrypt(plaintext.encode("utf-8")).decode("ascii")
        return f"enc:{token}"

    def decrypt(self, ciphertext: str) -> str:
        """Decrypt string. If vault is not enabled or string is not encrypted, returns ciphertext."""
        if not ciphertext or not self.is_enabled():
            return ciphertext

        if not self.is_encrypted(ciphertext):
            return ciphertext

        if not self.is_unlocked() or not self._cached_key:
            raise VaultError("Unlock vault to connect")

        token = ciphertext[4:]
        try:
            return Fernet(self._cached_key).decrypt(token.encode("ascii")).decode("utf-8")
        except Exception as exc:
            raise VaultError(f"Failed to decrypt secret: {exc}")

    def _derive_key(self, password: bytes, salt: bytes) -> bytes:
        """Derive 256-bit key using PBKDF2 with 100,000 SHA-256 iterations."""
        if not HAS_CRYPTOGRAPHY:
            raise VaultError("cryptography library unavailable")
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password))
