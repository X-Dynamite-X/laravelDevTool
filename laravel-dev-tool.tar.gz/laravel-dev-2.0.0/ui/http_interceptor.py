"""Outgoing HTTP Mock & Interceptor Engine for Laravel Dev.

Rules are kept in the app config and mirrored into the project's git-ignored
`storage/framework/cache/`, where the laravel-dev/profiler package applies the
enabled ones through `Http::fake()`. Outgoing calls are read back from the
requests the profiler recorded.
"""
from __future__ import annotations

import fnmatch
import json
import os
import re
import time
from pathlib import Path
from typing import Any
import osutil


def get_mock_file(site_name: str) -> Path:
    mock_dir = osutil.config_dir() / "http_mocks"
    mock_dir.mkdir(parents=True, exist_ok=True)
    return mock_dir / f"{site_name}.json"


def list_mock_rules(site_name: str) -> list[dict[str, Any]]:
    path = get_mock_file(site_name)
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


# storage/framework/cache/ is git-ignored by Laravel's skeleton and survives cache:clear.
PROJECT_MOCKS = Path("storage") / "framework" / "cache" / "laravel-dev-http-mocks.json"


def save_mock_rules(site_name: str, rules: list[dict[str, Any]], site_path: str | None = None) -> dict[str, Any]:
    path = get_mock_file(site_name)
    clean_rules = []
    for r in rules:
        clean_rules.append({
            "id": r.get("id") or f"rule_{int(time.time() * 1000)}",
            "url_pattern": str(r.get("url_pattern") or "*").strip(),
            "method": str(r.get("method") or "*").strip().upper(),
            "status": int(r.get("status") or 200),
            "response": r.get("response") if isinstance(r.get("response"), (dict, list)) else str(r.get("response") or "{}"),
            "headers": r.get("headers") if isinstance(r.get("headers"), dict) else {"Content-Type": "application/json"},
            "enabled": bool(r.get("enabled", True)),
        })
    path.write_text(json.dumps(clean_rules, indent=2), encoding="utf-8")
    if site_path:
        _sync_project_rules(Path(site_path), clean_rules)
    return {"ok": True, "count": len(clean_rules)}


def _sync_project_rules(site_path: Path, rules: list[dict[str, Any]]) -> None:
    target = site_path / PROJECT_MOCKS
    active = [r for r in rules if r.get("enabled")]
    if not active:
        target.unlink(missing_ok=True)  # no file = Http::fake() is never installed
        return
    if target.parent.is_dir():
        target.write_text(json.dumps(active, indent=2), encoding="utf-8")


def mocks_status(site_path: str) -> dict[str, Any]:
    """Whether the project can apply rules: they need the profiler package."""
    import perf
    profiler = perf.check_profiler_status(site_path)
    return {"profiler_installed": profiler["installed"], "rules_file": str(PROJECT_MOCKS)}


def match_mock_rule(site_name: str, url: str, method: str = "GET") -> dict[str, Any] | None:
    """Check if an outgoing request matches any active mock rule."""
    rules = list_mock_rules(site_name)
    method_upper = method.upper()

    for r in rules:
        if not r.get("enabled", True):
            continue
        rule_method = r.get("method", "*").upper()
        if rule_method != "*" and rule_method != method_upper:
            continue
        pattern = r.get("url_pattern", "*")
        if fnmatch.fnmatch(url, pattern) or fnmatch.fnmatch(url, f"*{pattern}*"):
            return {
                "matched": True,
                "rule_id": r.get("id"),
                "status": r.get("status", 200),
                "headers": r.get("headers", {}),
                "response": r.get("response", {}),
            }
    return None


def get_outgoing_http_logs(site_name: str, site_path: str, limit: int = 200) -> list[dict[str, Any]]:
    """Outgoing calls the profiler recorded, newest first, with the request that made them."""
    import perf
    calls: list[dict[str, Any]] = []
    for req in perf.get_profiled_requests(site_name, limit=100).get("requests", []):
        for i, call in enumerate(req.get("http_calls") or []):
            calls.append({
                "id": f"{req.get('id')}:{i}",
                "method": call.get("method") or "",
                "url": call.get("url") or "",
                "status": call.get("status") or 0,
                "duration_ms": call.get("duration_ms") or 0,
                "mocked": bool(call.get("mocked")),
                "rule_id": call.get("rule_id") or "",
                "time": req.get("time") or 0,
                "from": f"{req.get('method') or ''} {req.get('uri') or ''}".strip(),
            })
            if len(calls) >= limit:
                return calls
    return calls
