"use strict";

/* Remote servers over SSH: overview, services, Laravel sites and a file manager.
   Uses the helpers defined in app.js (icon, esc, api, toast, modals, drawer). */

const Servers = (() => {
  const S = {
    list: [],
    sshHosts: [],
    current: null, // server id
    tab: "overview",
    info: null,
    infoError: "",
    sites: null,
    files: { path: "", entries: [], hidden: false, loading: false, error: "" },
    site: null, // remote site open in the drawer
    siteTab: "actions",
    provisionStatus: null,
    releases: null,
    loaded: false,
  };
  let logTimer = null;

  const view = () => $("#view-servers");
  const server = () => S.list.find((s) => s.id === S.current);
  const address = (s) => `${s.user ? `${s.user}@` : ""}${s.host}${s.port && s.port !== "22" ? `:${s.port}` : ""}`;

  // What every remote task needs to know about a site.
  const sitePayload = (site) => ({ path: site.path, php: site.php, type: site.type || "laravel", pm2: site.pm2 ? site.pm2.id : null, unit: site.unit || "" });

  const DEPLOY_STEPS = {
    laravel: "<code>git pull</code>, <code>composer install --no-dev</code>, <code>migrate --force</code>, <code>optimize</code> and <code>queue:restart</code>",
    django: "<code>git pull</code>, <code>pip install -r requirements.txt</code>, <code>migrate</code>, <code>collectstatic</code>, then restarts the app",
    node: "<code>git pull</code>, installs dependencies (npm ci / pnpm / yarn / bun), <code>run build</code>, then restarts the app",
  };

  function runnerLabel(site) {
    if (site.pm2) return `pm2 · ${esc(site.pm2.name)} (${esc(site.pm2.status || "?")})`;
    if (site.unit) return `systemd · ${esc(site.unit)} (${esc(site.unit_status || "?")})`;
    return "";
  }

  function fmtBytes(n) {
    if (!n) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.min(Math.floor(Math.log(n) / Math.log(1024)), units.length - 1);
    return `${(n / 1024 ** i).toFixed(i ? 1 : 0)} ${units[i]}`;
  }

  function fmtUptime(sec) {
    sec = Number(sec) || 0;
    const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
    return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m`;
  }

  function fmtDate(ts) {
    const d = new Date(ts * 1000);
    return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }) + " " +
      d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
  }

  function joinPath(dir, name) {
    return (dir.endsWith("/") ? dir : dir + "/") + name;
  }

  function parentPath(path) {
    const parts = path.replace(/\/+$/, "").split("/");
    parts.pop();
    return parts.join("/") || "/";
  }

  /* ── data ─────────────────────────────────────────────── */
  async function loadList() {
    try {
      const data = await LD.call("servers");
      S.list = data.servers;
      S.sshHosts = data.ssh_hosts;
    } catch (err) {
      toast("error", "Couldn't load servers", err.message);
    }
    S.loaded = true;
    $("#nav-servers-count").textContent = S.list.length || "";
  }

  async function open(id, tab = "overview") {
    S.current = id;
    S.tab = tab;
    S.info = null;
    S.infoError = "";
    S.sites = null;
    S.files = { path: "", entries: [], hidden: S.files.hidden, loading: false, error: "" };
    render();
    await loadInfo();
  }

  async function loadInfo() {
    const id = S.current;
    try {
      const info = await LD.call("server_info", { id });
      if (S.current !== id) return;
      S.info = info;
      S.infoError = "";
      const entry = server();
      if (entry) entry.connected = true;
      try {
        const pStatus = await LD.call("forge_provision_status", { server: id });
        if (S.current === id) S.provisionStatus = pStatus.status;
      } catch {}
      if (S.tab === "sites" && !S.sites) loadSites();
      if (S.tab === "files" && !S.files.path) loadFiles(info.home || "~");
    } catch (err) {
      if (S.current !== id) return;
      S.infoError = err.message;
    }
    render();
  }

  async function loadSites() {
    const id = S.current;
    try {
      const sites = await LD.call("server_sites", { id });
      if (S.current === id) S.sites = sites;
    } catch (err) {
      if (S.current === id) S.sites = { error: err.message };
    }
    render();
  }

  async function loadFiles(path) {
    const id = S.current;
    S.files.loading = true;
    renderBody();
    try {
      const res = await LD.call("server_ls", { id, path, hidden: S.files.hidden });
      if (S.current !== id) return;
      Object.assign(S.files, { path: res.path, entries: res.entries, error: "" });
    } catch (err) {
      if (S.current === id) S.files.error = err.message;
    }
    S.files.loading = false;
    renderBody();
  }

  /* ── tasks (with the sudo-password round trip) ─────────── */
  async function runRemote(action, params, show = true) {
    const payload = { server: S.current, sudo: S.info?.sudo, ...params };
    try {
      const task = await LD.call("run", { action, params: payload });
      state.activeTask = task.id;
      if (show) openActivity();
    } catch (err) {
      if (err.message === "SUDO_PASSWORD_REQUIRED") {
        if (await askSudo()) return runRemote(action, params, show);
        return;
      }
      toast("error", "Couldn't start", err.message);
    }
  }

  function askSudo() {
    const s = server();
    return new Promise((resolve) => {
      openModal(`
        <form class="modal sm" id="sudo-form">
          <div class="modal-header"><h2>Sudo password</h2>
            <p>Needed to manage services on <b>${esc(s.name)}</b>. Kept in memory until you disconnect or quit.</p></div>
          <div class="modal-body">
            <label class="field"><span>Password for ${esc(S.info?.user || s.user || "your user")}</span><input name="password" type="password" autocomplete="off"></label>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary">Unlock</button>
          </div>
        </form>`, (root) => {
        const form = $("#sudo-form", root);
        $("[data-dismiss]", form).addEventListener("click", () => { closeModal(); resolve(false); });
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          const button = $("button[type=submit]", form);
          button.disabled = true;
          try {
            await LD.call("server_sudo", { id: S.current, password: form.elements.password.value });
            closeModal();
            resolve(true);
          } catch (err) {
            button.disabled = false;
            form.elements.password.classList.add("invalid");
            form.elements.password.select();
            toast("error", err.message);
          }
        });
      });
    });
  }

  /* ── rendering ────────────────────────────────────────── */
  function render() {
    if (state.view !== "servers") return;
    if (!S.current || !server()) return renderList();
    renderServer();
  }

  function renderList() {
    S.current = null;
    const importChips = S.sshHosts.length
      ? `<div class="import-hosts"><span class="muted">From ~/.ssh/config:</span>
          ${S.sshHosts.map((h) => `<button class="btn sm" data-srv-import="${esc(h)}">${icon("plus")}${esc(h)}</button>`).join("")}</div>`
      : "";

    let body;
    if (!S.loaded) {
      body = `<div class="site-list">${'<div class="skeleton"></div>'.repeat(2)}</div>`;
    } else if (!S.list.length) {
      body = `
        <div class="empty">
          <div class="empty-icon">${icon("cloud")}</div>
          <h2>Manage your servers over SSH</h2>
          <p>Connect a VPS to see its health, restart services, deploy Laravel sites and edit files — nothing is installed on the server.</p>
          <div class="actions"><button class="btn primary" data-srv-add>${icon("plus")}Add server</button></div>
          ${importChips}
        </div>`;
    } else {
      body = `
        <div class="server-grid">
          ${S.list.map((s) => `
            <div class="card server-card" data-srv-open="${esc(s.id)}">
              <div class="server-top">
                <div class="service-icon">${icon("server")}</div>
                <div style="min-width:0">
                  <div class="service-name">${esc(s.name)}</div>
                  <div class="service-desc mono">${esc(address(s))}</div>
                </div>
                <span class="service-status"><span class="dot ${s.connected ? "on" : "off"}"></span>${s.connected ? "Connected" : "Idle"}</span>
              </div>
              <div class="btn-row">
                <button class="btn sm primary" data-srv-open="${esc(s.id)}">Open</button>
                <button class="btn sm" data-srv-terminal="${esc(s.id)}">${icon("terminal")}SSH</button>
                <button class="btn sm" data-srv-files="${esc(s.id)}">${icon("folder")}Files</button>
              </div>
            </div>`).join("")}
        </div>
        ${importChips}`;
    }

    view().innerHTML = `
      <header class="view-header">
        <div><h1>Servers</h1><p class="subtitle">Remote machines managed over SSH.</p></div>
        <div class="header-actions">
          <button class="btn icon-btn" data-srv-reload title="Refresh">${icon("refresh")}</button>
          <button class="btn primary" data-srv-add>${icon("plus")}Add server</button>
        </div>
      </header>
      <div class="view-body">${body}</div>`;
  }

  function renderServer() {
    const s = server();
    const status = S.info ? `<span class="chip ok"><span class="dot on"></span>Connected</span>`
      : S.infoError ? `<span class="chip warn">${icon("alert")}Not connected</span>`
      : `<span class="chip"><span class="status-icon running" style="width:12px;height:12px"></span>Connecting…</span>`;
    view().innerHTML = `
      <header class="view-header">
        <div class="server-title">
          <button class="btn ghost icon-btn" data-srv-back title="All servers">${icon("back")}</button>
          <div>
            <h1>${esc(s.name)} ${status}</h1>
            <p class="subtitle mono">${esc(address(s))}${S.info?.os ? ` · ${esc(S.info.os)}` : ""}</p>
          </div>
        </div>
        <div class="header-actions">
          <button class="btn" data-srv-terminal="${esc(s.id)}">${icon("terminal")}SSH terminal</button>
          <button class="btn icon-btn" data-srv-edit title="Edit server">${icon("edit")}</button>
          <button class="btn icon-btn" data-srv-disconnect title="Disconnect">${icon("power")}</button>
        </div>
      </header>
      <div class="view-body">
        <div class="tabs">
          ${["overview", "sites", "files"].map((t) => `<button class="tab ${t === S.tab ? "active" : ""}" data-srv-tab="${t}">${{ overview: "Overview", sites: "Sites", files: "Files" }[t]}</button>`).join("")}
        </div>
        <div id="srv-body"></div>
      </div>`;
    renderBody();
  }

  function renderBody() {
    const el = $("#srv-body");
    if (!el) return;
    if (S.infoError) {
      el.innerHTML = `
        <div class="card error-card">
          <h3>${icon("alert")}Couldn't connect</h3>
          <pre class="log-view" style="height:auto;min-height:0">${esc(S.infoError)}</pre>
          <div class="btn-row" style="margin-top:12px">
            <button class="btn primary sm" data-srv-retry>${icon("refresh")}Try again</button>
            <button class="btn sm" data-srv-edit>${icon("edit")}Edit connection</button>
          </div>
          <p class="muted" style="margin-bottom:0">Password, passphrase and new host-key prompts open in a separate dialog. Key-based login via ssh-agent works automatically.</p>
        </div>`;
      return;
    }
    if (!S.info) {
      el.innerHTML = `<div class="connecting"><span class="status-icon running"></span>Connecting to ${esc(server().host)}…</div>`;
      return;
    }
    if (S.tab === "overview") el.innerHTML = overview();
    if (S.tab === "sites") el.innerHTML = sitesTab();
    if (S.tab === "files") el.innerHTML = filesTab();
  }

  function meter(label, used, total, detail) {
    const pct = total ? Math.round((used / total) * 100) : 0;
    const level = pct > 90 ? "bad" : pct > 75 ? "warn" : "";
    return `
      <div class="card stat">
        <div class="stat-label">${label}</div>
        <div class="stat-value">${pct}<small>%</small></div>
        <div class="meter ${level}"><span style="width:${pct}%"></span></div>
        <div class="stat-detail">${detail}</div>
      </div>`;
  }

  function overview() {
    const i = S.info;
    const load = (i.load || "").split(" ");
    const cpuPct = i.cpus ? Math.min(100, Math.round((parseFloat(load[0]) / Number(i.cpus)) * 100)) : 0;
    const sudoLabel = { root: "Logged in as root", nopasswd: "Passwordless sudo", password: i.sudo_cached ? "Sudo unlocked" : "Sudo asks for a password" }[i.sudo];
    const provisionBanner = S.provisionStatus ? `
      <div class="card" style="border-left:4px solid var(--ok);margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;padding:12px 16px;">
        <div><strong>${icon("check")} ${t("srv_provisioned_title", "Server Provisioned (Forge Mode)")}</strong>
          <span class="muted" style="margin-inline-start:8px">${t("srv_provisioned_at", "Provisioned on")} ${esc(S.provisionStatus.provisioned_at?.split("T")[0] || "")}</span>
        </div>
        <span class="chip ok">${icon("check")} Ready</span>
      </div>` : `
      <div class="card" style="border:1px dashed var(--accent);margin-bottom:16px;padding:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
        <div>
          <h3 style="margin:0 0 4px 0;display:flex;align-items:center;gap:8px;">${icon("zap")} ${t("srv_provision_cta", "Provision this server (Forge Mode)")}</h3>
          <p class="muted" style="margin:0;font-size:13px">${t("srv_provision_desc", "Automate server setup with 1-click: Nginx, PHP 8.3 & 8.4, MySQL/MariaDB, Redis, Supervisor, Node LTS, Composer, and UFW firewall.")}</p>
        </div>
        <button class="btn primary sm" data-forge-provision>${icon("play")} ${t("srv_provision_btn", "Provision Server")}</button>
      </div>`;

    return `
      <div class="stat-grid">
        <div class="card stat">
          <div class="stat-label">CPU load</div>
          <div class="stat-value">${esc(load[0] || "–")}</div>
          <div class="meter ${cpuPct > 90 ? "bad" : cpuPct > 75 ? "warn" : ""}"><span style="width:${cpuPct}%"></span></div>
          <div class="stat-detail">${esc(i.cpus || "?")} cores · 5m ${esc(load[1] || "–")} · 15m ${esc(load[2] || "–")}</div>
        </div>
        ${meter("Memory", Number(i.mem_used), Number(i.mem_total), `${fmtBytes(Number(i.mem_used))} of ${fmtBytes(Number(i.mem_total))}`)}
        ${meter("Disk /", Number(i.disk_used), Number(i.disk_total), `${fmtBytes(Number(i.disk_used))} of ${fmtBytes(Number(i.disk_total))}`)}
        <div class="card stat">
          <div class="stat-label">Uptime</div>
          <div class="stat-value">${esc(fmtUptime(i.uptime))}</div>
          <div class="stat-detail" style="margin-top:auto">${esc(i.hostname || "")}</div>
        </div>
      </div>

      ${provisionBanner}

      <div class="two-col">
        <div class="card">
          <h3>${icon("server")}Services <span class="right"><button class="btn ghost sm" data-srv-retry title="Refresh">${icon("refresh")}</button></span></h3>
          <div class="service-rows">
            ${i.units.length ? i.units.map((u) => `
              <div class="service-row">
                ${statusDot(u.status)}<span class="mono">${esc(u.unit)}</span><span class="muted">${esc(u.status)}</span>
                <span class="row-actions">
                  ${u.status === "active"
                    ? `<button class="btn ghost sm" data-srv-service="restart" data-unit="${esc(u.unit)}">${icon("refresh")}Restart</button>
                       <button class="btn ghost sm" data-srv-service="stop" data-unit="${esc(u.unit)}">${icon("stop")}Stop</button>`
                    : `<button class="btn ghost sm" data-srv-service="start" data-unit="${esc(u.unit)}">${icon("play")}Start</button>`}
                </span>
              </div>`).join("") : `<p class="muted">No known services (nginx, apache, mysql, php-fpm, redis…) found.</p>`}
          </div>
        </div>
        <div class="card">
          <h3>${icon("cpu")}System</h3>
          <dl class="info">
            <dt>OS</dt><dd><span class="text">${esc(i.os || "–")}</span></dd>
            <dt>Kernel</dt><dd class="mono">${esc(i.kernel || "–")}</dd>
            <dt>User</dt><dd>${esc(i.user)}</dd>
            <dt>Privileges</dt><dd>${esc(sudoLabel)}</dd>
            <dt>PHP</dt><dd>${esc(i.php || "not installed")}</dd>
            <dt>Tools</dt><dd>${["git", "composer"].map((t) => `<span class="chip ${i[t] ? "ok" : ""}">${t}</span>`).join("")}</dd>
          </dl>
        </div>
      </div>`;
  }

  function sitesTab() {
    if (!S.sites) return `<div class="connecting"><span class="status-icon running"></span>Looking for sites (nginx, pm2, /var/www, home folders)…</div>`;
    if (S.sites.error) return `<div class="card error-card"><h3>${icon("alert")}Couldn't scan sites</h3><p class="muted">${esc(S.sites.error)}</p></div>`;

    const toolbar = `
      <div class="sites-toolbar" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
        <span class="muted">${(S.sites && S.sites.length) ? `${S.sites.length} ${t("srv_sites_found", "site(s) found")}` : ""}</span>
        <button class="btn primary sm" data-forge-new-site>${icon("plus")} ${t("srv_new_remote_site", "New Site (Forge)")}</button>
      </div>`;

    if (!S.sites.length) return `${toolbar}<div class="empty"><div class="empty-icon">${icon("globe")}</div><h2>No sites found</h2><p>Laravel, Next.js, Nuxt and Django projects are discovered from nginx configs, pm2 processes and folders under /var/www, /srv and home directories.</p><button class="btn" data-srv-tab="files">${icon("folder")}Browse files</button></div>`;
    return `${toolbar}<div class="site-list">${S.sites.map((site, idx) => {
      const chips = [];
      if (site.down) chips.push(`<span class="chip warn">Maintenance</span>`);
      if (site.type && site.type !== "laravel") chips.push(typeChip(site));
      if (site.php) chips.push(`<span class="chip php">PHP ${esc(site.php)}</span>`);
      const running = site.pm2 ? site.pm2.status === "online" : site.unit ? site.unit_status === "active" : null;
      if (running !== null) chips.push(`<span class="chip ${running ? "ok" : "warn"}"><span class="dot ${running ? "on" : "off"}"></span>${site.pm2 ? "pm2" : "systemd"}</span>`);
      if (site.branch) chips.push(`<span class="chip branch">${icon("branch")}${esc(site.branch)}</span>`);
      return `
        <div class="site-row" data-rsite="${idx}">
          ${avatar(site.name)}
          <div class="site-main">
            <div class="site-name">${esc(site.name)}</div>
            <div class="site-meta">
              ${site.url ? `<a class="link" data-srv-url="${esc(site.url)}">${esc(site.domains[0])}</a><span class="sep">·</span>` : ""}
              <span class="path mono">${esc(site.path)}</span>
            </div>
          </div>
          <div class="site-chips">${chips.join("")}</div>
          <div class="site-actions">
            <button class="btn sm" data-srv-deploy="${idx}">${icon("rocket")}Deploy</button>
          </div>
        </div>`;
    }).join("")}</div>`;
  }

  function filesTab() {
    const f = S.files;
    const crumbs = [];
    let acc = "";
    for (const part of (f.path || "/").split("/").filter(Boolean)) {
      acc += "/" + part;
      crumbs.push(`<button class="crumb" data-srv-cd="${esc(acc)}">${esc(part)}</button>`);
    }
    const rows = f.entries.map((e, idx) => `
      <tr data-rfile="${idx}" class="${e.dir ? "is-dir" : ""}">
        <td class="name"><div>${icon(e.dir ? "folder" : "file")}<span>${esc(e.name)}</span>${e.link ? `<span class="chip">link</span>` : ""}</div></td>
        <td class="muted num">${e.dir ? "—" : fmtBytes(e.size)}</td>
        <td class="muted">${fmtDate(e.mtime)}</td>
        <td class="muted mono">${esc(e.mode)}</td>
        <td class="muted">${esc(e.owner)}</td>
        <td class="row-actions">
          ${e.dir ? "" : `<button class="btn ghost icon-btn sm" data-rf="edit" title="Open in editor">${icon("edit")}</button>`}
          <button class="btn ghost icon-btn sm" data-rf="download" title="Download">${icon("download")}</button>
          <button class="btn ghost icon-btn sm" data-rf="rename" title="Rename / move">${icon("rename")}</button>
          <button class="btn ghost icon-btn sm danger" data-rf="delete" title="Delete">${icon("trash")}</button>
        </td>
      </tr>`).join("");
    return `
      <div class="file-toolbar">
        <button class="btn icon-btn sm" data-srv-cd="${esc(parentPath(f.path || "/"))}" title="Up">${icon("up")}</button>
        <button class="btn icon-btn sm" data-srv-cd="${esc(S.info.home || "~")}" title="Home">${icon("home")}</button>
        <div class="crumbs"><button class="crumb" data-srv-cd="/">/</button>${crumbs.join('<span class="sep">/</span>')}</div>
        <button class="btn sm ${f.hidden ? "active-toggle" : ""}" data-srv-hidden title="Show hidden files">${icon("eye")}Hidden</button>
        <button class="btn icon-btn sm" data-srv-cd="${esc(f.path)}" title="Refresh">${icon("refresh")}</button>
        <button class="btn sm" data-srv-new="folder">${icon("folder")}New folder</button>
        <button class="btn sm" data-srv-new="file">${icon("file")}New file</button>
        <button class="btn sm primary" data-srv-upload>${icon("upload")}Upload</button>
      </div>
      ${f.error ? `<div class="card error-card"><p style="margin:0">${esc(f.error)}</p></div>` : ""}
      <div class="card file-card ${f.loading ? "loading" : ""}">
        <table class="files">
          <thead><tr><th>Name</th><th>Size</th><th>Modified</th><th>Mode</th><th>Owner</th><th></th></tr></thead>
          <tbody>${rows || `<tr><td colspan="6" class="muted" style="padding:20px">${f.loading ? "Loading…" : "Empty folder"}</td></tr>`}</tbody>
        </table>
      </div>
      <p class="muted file-hint">Files open in your editor; every save is uploaded back to the server automatically.</p>`;
  }

  /* ── remote site drawer ───────────────────────────────── */
  function openSite(idx) {
    S.site = S.sites[idx];
    S.siteTab = "actions";
    state.drawer = { name: null, tab: "overview", details: null, currentKey: null };
    const el = $("#site-drawer");
    el.classList.add("open");
    el.setAttribute("aria-hidden", "false");
    renderSite();
  }

  function renderSite() {
    const site = S.site;
    clearInterval(logTimer);
    const laravel = (site.type || "laravel") === "laravel";
    const tabs = laravel
      ? ["actions", "deployments", "workers", "cron", "ssl", "database", "env", "logs"]
      : ["actions", "env", "logs"];
    const tabLabels = {
      actions: t("srv_actions", "Actions"),
      deployments: t("srv_deployments", "Deployments"),
      workers: t("srv_workers", "Workers"),
      cron: t("srv_cron", "Cron"),
      ssl: t("srv_ssl", "SSL"),
      database: t("srv_database", "Database"),
      env: t("srv_env", "Environment"),
      logs: t("srv_logs", "Logs"),
    };

    const el = $("#site-drawer");
    el.innerHTML = `
      <div class="drawer-header">
        ${avatar(site.name, "lg")}
        <div style="min-width:0">
          <h2>${esc(site.name)}</h2>
          ${site.url ? `<a class="link" data-srv-url="${esc(site.url)}">${esc(site.url)}</a>` : `<span class="muted">No domain in nginx</span>`}
        </div>
        <button class="btn ghost icon-btn close" data-close-drawer title="Close (Esc)">${icon("x")}</button>
      </div>
      <div class="drawer-body">
        <div class="quick-actions">
          <button class="quick-action" data-rsa="browser" ${site.url ? "" : "disabled"}>${icon("browser")}Browser</button>
          <button class="quick-action" data-rsa="files">${icon("folder")}Files</button>
          <button class="quick-action" data-rsa="terminal">${icon("terminal")}SSH here</button>
          <button class="quick-action" data-rsite-tab="env">${icon("env")}Variables</button>
          <button class="quick-action" data-rsa="database">${icon("database")}Database</button>
        </div>
        <div class="tabs" style="overflow-x:auto;white-space:nowrap;">
          ${tabs.map((tKey) => `<button class="tab ${tKey === S.siteTab ? "active" : ""}" data-rsite-tab="${tKey}">${tabLabels[tKey] || tKey}</button>`).join("")}
        </div>
        <div id="rsite-tab"></div>
      </div>`;

    el.classList.toggle("wide", S.siteTab === "env" || S.siteTab === "deployments");
    const pane = $("#rsite-tab", el);
    if (S.siteTab === "env") {
      const laravelSite = (site.type || "laravel") === "laravel";
      EnvEditor.mount(pane, { server: S.current, path: site.path }, {
        afterSave: () => [
          ...(laravelSite ? [{ label: "Rebuild config cache", run: () => runRemote("remote-artisan", { path: site.path, php: site.php, args: "config:cache" }) }] : []),
          ...(site.pm2 || site.unit ? [{ label: "Restart app", run: () => runRemote("remote-restart", sitePayload(site)) }] : []),
          { label: "Deploy", run: () => runRemote("remote-deploy", sitePayload(site)) },
        ],
      });
      return;
    }
    if (S.siteTab === "logs") {
      pane.innerHTML = `
        <div class="log-toolbar"><span class="muted">${site.type === "laravel" ? "storage/logs/laravel.log" : site.pm2 ? "pm2 logs" : site.unit ? `journalctl -u ${esc(site.unit)}` : "Logs"} · refreshes every 5s</span>
          <button class="btn sm" data-rsa="log-refresh">${icon("refresh")}Refresh</button></div>
        <pre class="log-view" id="rlog-view">Loading…</pre>`;
      loadLog(true);
      logTimer = setInterval(() => loadLog(false), 5000);
      return;
    }
    if (S.siteTab === "deployments") {
      pane.innerHTML = `<div class="connecting"><span class="status-icon running"></span>${t("srv_loading_releases", "Loading releases…")}</div>`;
      LD.call("forge_list_releases", { server: S.current, path: site.path }).then((res) => {
        if (S.siteTab !== "deployments") return;
        const rels = res.releases || [];
        const cur = res.current || "";
        pane.innerHTML = `
          <div class="card">
            <h3>${icon("rocket")} ${t("srv_atomic_deploy_title", "Zero-Downtime Deployment")}</h3>
            <p class="muted" style="margin-top:0">${t("srv_atomic_deploy_desc", "Clones the release in isolation, builds assets, runs migrations, clears opcache, and flips symlink atomically.")}</p>
            <div style="display:grid;grid-template-columns:1fr 120px auto;gap:8px;align-items:end;margin-top:12px;">
              <label class="field" style="margin:0;"><span>${t("srv_repo_label", "Git Repository URL")}</span><input id="fd-repo" class="input sm" placeholder="git@github.com:owner/repo.git" spellcheck="false" value="${esc(site.repo || "")}"></label>
              <label class="field" style="margin:0;"><span>${t("srv_branch_label", "Branch")}</span><input id="fd-branch" class="input sm" value="${esc(site.branch || "main")}" spellcheck="false"></label>
              <button class="btn primary sm" data-forge-do-deploy>${icon("rocket")} ${t("srv_deploy_btn", "Deploy Now")}</button>
            </div>
          </div>
          <div class="card" style="margin-top:16px;">
            <h3>${icon("history")} ${t("srv_rollback_title", "Release History & Rollback")}</h3>
            ${cur ? `<div style="margin-bottom:12px;">${t("srv_active_release", "Active Release")}: <span class="chip ok">${esc(cur)}</span></div>` : ""}
            ${rels.length ? `
              <table class="files" style="width:100%;">
                <thead><tr><th>Release ID</th><th>Date</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                  ${rels.map((r) => `
                    <tr>
                      <td class="mono font-semibold">${esc(r.id)}</td>
                      <td class="muted">${fmtDate(r.timestamp)}</td>
                      <td>${r.active ? `<span class="chip ok">Current</span>` : `<span class="chip">Stored</span>`}</td>
                      <td>${r.active ? "—" : `<button class="btn sm ghost" data-forge-do-rollback="${esc(r.id)}">${icon("refresh")} ${t("srv_rollback_btn", "Rollback")}</button>`}</td>
                    </tr>
                  `).join("")}
                </tbody>
              </table>` : `<p class="muted">No atomic releases detected yet. Use Deploy Now to create the first release.</p>`}
          </div>`;
      }).catch((err) => {
        pane.innerHTML = `<div class="card error-card"><p>${esc(err.message)}</p></div>`;
      });
      return;
    }
    if (S.siteTab === "workers") {
      pane.innerHTML = `
        <div class="card">
          <h3>${icon("cpu")} ${t("srv_worker_title", "Background Queue Workers (Supervisor)")}</h3>
          <p class="muted" style="margin-top:0">${t("srv_worker_desc", "Manages persistent queue workers using Supervisor running under the web user.")}</p>
          <div style="display:grid;grid-template-columns:1fr 120px auto;gap:8px;align-items:end;margin-top:12px;">
            <label class="field" style="margin:0;"><span>${t("srv_worker_queue", "Queue Name(s)")}</span><input id="fw-queue" class="input sm" value="default" spellcheck="false"></label>
            <label class="field" style="margin:0;"><span>${t("srv_worker_procs", "Number of Processes")}</span><input id="fw-procs" class="input sm" type="number" min="1" max="16" value="1"></label>
            <button class="btn primary sm" data-forge-save-worker>${icon("play")} ${t("srv_worker_save_btn", "Save & Start Worker")}</button>
          </div>
        </div>`;
      return;
    }
    if (S.siteTab === "cron") {
      pane.innerHTML = `
        <div class="card">
          <h3>${icon("clock")} ${t("srv_cron_title", "Laravel Scheduler (Cron)")}</h3>
          <p class="muted" style="margin-top:0">${t("srv_cron_desc", "Executes the Laravel scheduled console commands every minute.")}</p>
          <pre class="log-view" style="height:auto;min-height:0;padding:8px 12px;margin:12px 0;">* * * * * cd ${esc(site.path)}/current && php artisan schedule:run >> /dev/null 2>&1</pre>
          <div class="btn-row">
            <button class="btn primary sm" data-forge-cron="enable">${icon("play")} ${t("srv_cron_enable_btn", "Enable Scheduler")}</button>
            <button class="btn sm danger" data-forge-cron="disable">${icon("stop")} ${t("srv_cron_disable_btn", "Disable Scheduler")}</button>
          </div>
        </div>`;
      return;
    }
    if (S.siteTab === "ssl") {
      pane.innerHTML = `
        <div class="card">
          <h3>${icon("shield")} ${t("srv_ssl_title", "Automated SSL Certificate (Let's Encrypt)")}</h3>
          <p class="muted" style="margin-top:0">${t("srv_ssl_desc", "Obtains and renews free SSL certificates via Certbot for Nginx.")}</p>
          <div style="margin:12px 0;">
            <span class="muted">Domain:</span> <strong>${esc(site.domains[0] || site.name)}</strong>
            ${site.ssl ? `<span class="chip ok" style="margin-inline-start:8px">${icon("check")} SSL Active</span>` : `<span class="chip warn" style="margin-inline-start:8px">HTTP Only</span>`}
          </div>
          <div style="display:flex;gap:8px;align-items:end;margin-top:12px;">
            <label class="field" style="margin:0;flex:1;"><span>${t("srv_ssl_email", "Contact Email")}</span><input id="fssl-email" class="input sm" type="email" placeholder="admin@example.com"></label>
            <button class="btn primary sm" data-forge-issue-ssl>${icon("shield")} ${t("srv_ssl_issue_btn", "Issue Certificate")}</button>
          </div>
        </div>`;
      return;
    }
    if (S.siteTab === "database") {
      const localSites = (state.sites || []).map((s) => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join("");
      pane.innerHTML = `
        <div class="card">
          <h3>${icon("database")} ${t("srv_db_pull_title", "Pull Production Database to Local")}</h3>
          <p class="muted" style="margin-top:0">${t("srv_db_pull_desc", "Dumps the remote database via SSH and imports it directly into your local development database.")}</p>
          <div class="notice" style="margin:12px 0;">${icon("shield")} <span>${t("srv_db_safety_notice", "Safety First: A complete local database snapshot will be created automatically before importing.")}</span></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px;">
            <label class="field"><span>${t("srv_db_target_local", "Local Target Site")}</span><select id="fdb-local-site" class="input sm">${localSites}</select></label>
            <label class="field"><span>${t("srv_db_exclude", "Exclude Tables")}</span><input id="fdb-exclude" class="input sm" value="sessions,jobs,telescope_entries"></label>
          </div>
          <div class="btn-row" style="margin-top:12px;">
            <button class="btn primary sm" data-forge-pull-db>${icon("download")} ${t("srv_db_pull_btn", "Pull Database Now")}</button>
          </div>
        </div>`;
      return;
    }
    const django = site.type === "django";
    const commands = laravel ? `
          <button class="btn sm" data-rsa="pull">${icon("download")}git pull</button>
          <button class="btn sm" data-rsa="composer">composer install</button>
          <button class="btn sm" data-ra="migrate --force">migrate</button>
          <button class="btn sm" data-ra="optimize:clear">optimize:clear</button>
          <button class="btn sm" data-ra="queue:restart">queue:restart</button>
          <button class="btn sm" data-rsa="${site.down ? "up" : "down"}">${site.down ? "Bring back up" : "Maintenance mode"}</button>` : `
          <button class="btn sm" data-rsa="pull">${icon("download")}git pull</button>
          <button class="btn sm" data-rsa="install">${django ? "pip install" : "Install dependencies"}</button>
          ${django ? `<button class="btn sm" data-rm="migrate --noinput">migrate</button>
                      <button class="btn sm" data-rm="collectstatic --noinput">collectstatic</button>`
                   : `<button class="btn sm" data-rsa="build">Build</button>`}
          ${site.pm2 || site.unit ? `<button class="btn sm" data-rsa="restart">${icon("refresh")}Restart</button>` : ""}`;
    const input = laravel
      ? `<form class="artisan-input" data-rartisan><span class="prefix">php artisan</span><input name="args" placeholder="about" spellcheck="false"><button class="btn sm" type="submit">Run</button></form>`
      : django
        ? `<form class="artisan-input" data-rmanage><span class="prefix">manage.py</span><input name="args" placeholder="showmigrations" spellcheck="false"><button class="btn sm" type="submit">Run</button></form>`
        : "";

    pane.innerHTML = `
      <div class="card">
        <dl class="info">
          <dt>Path</dt><dd><span class="text mono selectable" title="${esc(site.path)}">${esc(site.path)}</span>
            <button class="btn ghost icon-btn sm" data-copy="${esc(site.path)}" title="Copy path">${icon("copy")}</button></dd>
          <dt>Type</dt><dd>${laravel ? `<span class="chip type" style="--type:${TYPES.laravel.color}">Laravel</span>` : typeChip(site)}</dd>
          ${site.domains.length ? `<dt>Domains</dt><dd><span class="text">${esc(site.domains.join(", "))}</span></dd>` : ""}
          ${site.php ? `<dt>PHP</dt><dd>${esc(site.php)}</dd>` : ""}
          ${site.port ? `<dt>Port</dt><dd class="mono">${esc(site.port)}</dd>` : ""}
          ${runnerLabel(site) ? `<dt>Runs with</dt><dd>${runnerLabel(site)}</dd>` : ""}
          ${site.branch ? `<dt>Branch</dt><dd>${icon("branch")}${esc(site.branch)}</dd>` : ""}
          ${laravel ? `<dt>Status</dt><dd>${site.down ? `<span class="chip warn">Maintenance mode</span>` : `<span class="chip ok">Live</span>`}</dd>` : ""}
        </dl>
      </div>

      <div class="card deploy-card">
        <h3>${icon("rocket")}Deploy</h3>
        <p class="muted" style="margin-top:0">Runs ${DEPLOY_STEPS[site.type] || DEPLOY_STEPS.node}.</p>
        ${!laravel && !site.pm2 && !site.unit ? `<div class="notice">${icon("alert")}<span>No pm2 process or systemd unit runs this app, so deploy can't restart it.</span></div>` : ""}
        <button class="btn primary" data-rsa="deploy">${icon("rocket")}Deploy now</button>
      </div>

      <div class="card">
        <h3>${icon("terminal")}Commands</h3>
        <div class="btn-row">${commands}</div>
        ${input}
      </div>`;
  }

  async function loadLog(scrollToEnd) {
    const view = $("#rlog-view");
    if (!view || !S.site || !$("#site-drawer").classList.contains("open")) {
      clearInterval(logTimer); // drawer closed: stop polling the server
      return;
    }
    const atBottom = view.scrollHeight - view.scrollTop - view.clientHeight < 40;
    try {
      const log = await LD.call("server_log", { id: S.current, ...sitePayload(S.site) });
      const current = $("#rlog-view");
      if (!current) return;
      current.innerHTML = log.exists && log.text
        ? log.text.split("\n").map((line) => {
            const cls = /\.(ERROR|CRITICAL|ALERT|EMERGENCY):/.test(line) ? "log-line-error" : /\.WARNING:/.test(line) ? "log-line-warning" : "";
            return cls ? `<span class="${cls}">${esc(line)}</span>` : esc(line);
          }).join("\n")
        : `<span style="opacity:.6">${esc(log.hint || (log.exists ? "Log is empty." : "No log yet."))}</span>`;
      if (scrollToEnd || atBottom) current.scrollTop = current.scrollHeight;
    } catch (err) {
      const current = $("#rlog-view");
      if (current) current.textContent = err.message;
    }
  }

  /* ── server form ──────────────────────────────────────── */
  function serverModal(existing = {}) {
    openModal(`
      <form class="modal" id="server-form" novalidate>
        <div class="modal-header">
          <h2>${existing.id ? "Edit server" : "Add server"}</h2>
          <p>Uses your system SSH: keys, ssh-agent and <code>~/.ssh/config</code> aliases just work.</p>
        </div>
        <div class="modal-body">
          <label class="field"><span>Name</span><input name="name" placeholder="Production" value="${esc(existing.name || "")}"></label>
          <div class="grid-2">
            <label class="field"><span>Host or IP <small>(or ssh config alias)</small></span><input name="host" placeholder="203.0.113.10" spellcheck="false" value="${esc(existing.host || "")}"></label>
            <label class="field"><span>Port</span><input name="port" placeholder="22" inputmode="numeric" value="${esc(existing.port || "")}"></label>
          </div>
          <label class="field"><span>Username <small>(empty = from ssh config / your user)</small></span><input name="user" placeholder="forge" spellcheck="false" value="${esc(existing.user || "")}"></label>
          <label class="field"><span>Private key <small>(optional)</small></span>
            <span class="input-group" style="width:100%"><input name="key" placeholder="~/.ssh/id_ed25519" spellcheck="false" value="${esc(existing.key || "")}"><button type="button" class="btn" data-pick-key>Browse</button></span>
            <small>Password login works too — you'll be asked once per connection.</small>
          </label>
        </div>
        <div class="modal-footer">
          ${existing.id ? `<button type="button" class="btn danger" data-remove style="margin-right:auto">${icon("trash")}Remove</button>` : ""}
          <button type="button" class="btn" data-dismiss>Cancel</button>
          <button type="submit" class="btn primary">${existing.id ? "Save" : `${icon("plus")}Add & connect`}</button>
        </div>
      </form>`, (root) => {
      const form = $("#server-form", root);
      const f = form.elements;
      f.host.addEventListener("input", () => { if (!existing.name && !f.name.dataset.touched) f.name.value = f.host.value; });
      f.name.addEventListener("input", () => (f.name.dataset.touched = "1"));
      $("[data-dismiss]", form).addEventListener("click", closeModal);
      $("[data-pick-key]", form).addEventListener("click", async () => {
        const path = await api("pick_file", { title: "Choose a private key", current: "~/.ssh" });
        if (path) f.key.value = path;
      });
      $("[data-remove]", form)?.addEventListener("click", async () => {
        closeModal();
        if (!(await confirmModal({ title: `Remove ${existing.name}?`, danger: true, confirm: "Remove", message: "Only the saved connection is removed. Nothing changes on the server." }))) return;
        await api("server_remove", { id: existing.id });
        S.current = null;
        await loadList();
        render();
      });
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const saved = await LD.call("server_save", { id: existing.id, name: f.name.value, host: f.host.value, port: f.port.value, user: f.user.value, key: f.key.value });
          closeModal();
          await loadList();
          open(saved.id, S.tab);
        } catch (err) {
          toast("error", err.message);
        }
      });
    });
  }

  /* ── forge remote site modal ─────────────────────────── */
  async function forgeSiteModal() {
    let ghRepos = [];
    let cfZones = [];
    try {
      const g = await LD.call("gh_repos", {});
      if (g && g.repos) ghRepos = g.repos;
    } catch {}
    try {
      const c = await LD.call("cf_zones", {});
      if (c && c.zones) cfZones = c.zones;
    } catch {}

    const repoOptions = `<option value="">— Manual URL —</option>` + ghRepos.map((r) => `<option value="${esc(r.clone_url || r.html_url)}">${esc(r.full_name)}</option>`).join("");
    const zoneOptions = `<option value="">— None (Manage DNS elsewhere) —</option>` + cfZones.map((z) => `<option value="${esc(z.id)}">${esc(z.name)}</option>`).join("");

    openModal(`
      <form class="modal" id="forge-site-form" novalidate>
        <div class="modal-header">
          <h2>${icon("zap")} ${t("srv_create_site_title", "Create Remote Site")}</h2>
          <p>${t("srv_provision_desc", "Creates /var/www/<domain> isolated atomic releases, Nginx vhost, and database.")}</p>
        </div>
        <div class="modal-body">
          <div class="grid-2">
            <label class="field"><span>${t("srv_domain_label", "Domain Name")}</span><input name="domain" placeholder="app.example.com" required spellcheck="false"></label>
            <label class="field"><span>${t("srv_php_label", "PHP Version")}</span>
              <select name="php" class="input sm">
                <option value="8.3" selected>PHP 8.3</option>
                <option value="8.4">PHP 8.4</option>
                <option value="8.2">PHP 8.2</option>
              </select>
            </label>
          </div>
          <div class="grid-2">
            <label class="field"><span>${t("srv_db_engine_label", "Database Engine")}</span>
              <select name="db_engine" class="input sm">
                <option value="mysql" selected>MySQL / MariaDB</option>
                <option value="pgsql">PostgreSQL</option>
                <option value="none">None</option>
              </select>
            </label>
            <label class="field"><span>${t("srv_db_name_label", "Database Name (Optional)")}</span><input name="db_name" placeholder="Leave blank to auto-name" spellcheck="false"></label>
          </div>
          <label class="field"><span>${t("srv_repo_label", "Git Repository URL")}</span>
            <div style="display:flex;gap:8px;">
              <select id="fs-repo-picker" class="input sm" style="width:200px;">${repoOptions}</select>
              <input name="repo_url" placeholder="git@github.com:owner/repo.git" style="flex:1;" spellcheck="false">
            </div>
          </label>
          <div class="grid-2">
            <label class="field"><span>${t("srv_branch_label", "Branch")}</span><input name="branch" value="main" spellcheck="false"></label>
            <label class="field"><span>${t("srv_cf_zone_label", "Cloudflare DNS Zone")}</span><select name="cf_zone" class="input sm">${zoneOptions}</select></label>
          </div>
          <label class="checkbox" style="margin-top:8px;">
            <input type="checkbox" name="cf_proxied" checked>
            <span>${t("srv_cf_proxied", "Cloudflare Proxy (CDN + DDoS)")}</span>
          </label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>${t("cancel", "Cancel")}</button>
          <button type="submit" class="btn primary">${icon("plus")} ${t("srv_create_site_btn", "Create Site")}</button>
        </div>
      </form>`, (root) => {
      const form = $("#forge-site-form", root);
      $("[data-dismiss]", form).addEventListener("click", closeModal);
      $("#fs-repo-picker", form).addEventListener("change", (e) => {
        if (e.target.value) form.elements.repo_url.value = e.target.value;
      });
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const f = form.elements;
        const domain = f.domain.value.trim();
        if (!domain) return toast("error", "Domain required", "Please enter a valid domain name.");
        const php = f.php.value;
        const db_engine = f.db_engine.value;
        const db_name = f.db_name.value.trim();
        const repo_url = f.repo_url.value.trim();
        const branch = f.branch.value.trim() || "main";
        const cf_zone = f.cf_zone.value;
        const cf_proxied = f.cf_proxied.checked;

        closeModal();

        // 1. Cloudflare DNS setup if zone selected
        if (cf_zone) {
          try {
            toast("success", "Creating Cloudflare DNS record…");
            await LD.call("forge_dns_setup", { zone_id: cf_zone, domain, server_ip: server().host, proxied: cf_proxied });
          } catch (err) {
            toast("error", "Cloudflare DNS failed", err.message);
          }
        }

        // 2. Deploy key on server and GitHub if repo is provided
        if (repo_url) {
          try {
            const m = repo_url.match(/[:/]([^/]+\/[^/.]+)(\.git)?$/);
            const ghRepo = m ? m[1] : "";
            await LD.call("forge_deploy_key", { server: S.current, domain, github_repo: ghRepo });
          } catch {}
        }

        // 3. Create site task
        await runRemote("forge-site-create", { domain, php, db_engine, db_name, repo_url, branch });
        loadSites();
      });
    });
  }

  /* ── events ───────────────────────────────────────────── */
  document.addEventListener("click", async (e) => {
    const t = e.target;
    const d = (sel) => t.closest(sel);
    let el;

    if (d("[data-srv-add]")) return serverModal();
    if (d("[data-forge-provision]")) {
      if (!(await confirmModal({
        title: window.t("srv_provision_cta", "Provision this server (Forge Mode)"),
        confirm: window.t("srv_provision_btn", "Provision Server"),
        message: window.t("srv_provision_confirm", "Are you sure you want to provision this server? This will install system packages, web servers, databases, and configure UFW firewall rules.")
      }))) return;
      return runRemote("forge-provision", {});
    }
    if (d("[data-forge-new-site]")) return forgeSiteModal();
    if (d("[data-forge-do-deploy]")) {
      const repo = $("#fd-repo")?.value?.trim() || "";
      const branch = $("#fd-branch")?.value?.trim() || "main";
      if (!repo) return toast("error", "Repository required", "Enter a Git repository URL to deploy.");
      return runRemote("forge-deploy", { path: S.site.path, repo_url: repo, branch, php: S.site.php || "8.3" });
    }
    if ((el = d("[data-forge-do-rollback]"))) {
      const rel = el.dataset.forgeDoRollback;
      if (!(await confirmModal({
        title: window.t("srv_rollback_title", "Rollback Release"),
        confirm: window.t("srv_rollback_btn", "Rollback"),
        message: `Rollback ${esc(S.site.name)} to release <b>${esc(rel)}</b>?`
      }))) return;
      return runRemote("forge-rollback", { path: S.site.path, release: rel, php: S.site.php || "8.3" });
    }
    if (d("[data-forge-save-worker]")) {
      const queue = $("#fw-queue")?.value?.trim() || "default";
      const numprocs = +$("#fw-procs")?.value || 1;
      return runRemote("forge-worker", { path: S.site.path, queue, numprocs, php: S.site.php || "8.3" });
    }
    if ((el = d("[data-forge-cron]"))) {
      return runRemote("forge-cron", { path: S.site.path, php: S.site.php || "8.3", op: el.dataset.forgeCron });
    }
    if (d("[data-forge-issue-ssl]")) {
      const email = $("#fssl-email")?.value?.trim() || "";
      const domain = S.site.domains[0] || S.site.name;
      return runRemote("forge-ssl", { domain, email });
    }
    if (d("[data-forge-pull-db]")) {
      const localSite = $("#fdb-local-site")?.value || "";
      const exclude = $("#fdb-exclude")?.value?.trim() || "sessions,jobs,telescope_entries";
      if (!localSite) return toast("error", "Local site required", "Select a local target site to receive the database.");
      if (!(await confirmModal({
        title: window.t("srv_db_pull_title", "Pull Production Database to Local"),
        confirm: window.t("srv_db_pull_btn", "Pull Database Now"),
        danger: true,
        message: `This will dump the remote database from <b>${esc(S.site.name)}</b> and import it into your local project <b>${esc(localSite)}</b>.<br><br><b>A local backup snapshot will be created automatically before importing.</b>`
      }))) return;
      try {
        toast("success", "Pulling remote database… (creating snapshot first)");
        const res = await LD.call("forge_db_pull", { server: S.current, path: S.site.path, local_site: localSite, exclude });
        if (res.ok) {
          toast("success", "Database imported", res.message);
        } else {
          toast("error", "Database pull failed", res.error);
        }
      } catch (err) {
        toast("error", "Database pull failed", err.message);
      }
      return;
    }
    if ((el = d("[data-srv-import]"))) return serverModal({ name: el.dataset.srvImport, host: el.dataset.srvImport });
    if (d("[data-srv-reload]")) { await loadList(); return render(); }
    if ((el = d("[data-srv-terminal]"))) { e.stopPropagation(); return api("server_terminal", { id: el.dataset.srvTerminal }); }
    if ((el = d("[data-srv-files]"))) { e.stopPropagation(); return open(el.dataset.srvFiles, "files"); }
    if ((el = d("[data-srv-open]"))) return open(el.dataset.srvOpen);
    if (d("[data-srv-back]")) { S.current = null; await loadList(); return render(); }
    if (d("[data-srv-edit]")) return serverModal(server());
    if (d("[data-srv-retry]")) { S.infoError = ""; S.info = null; render(); return loadInfo(); }
    if (d("[data-srv-disconnect]")) {
      await api("server_disconnect", { id: S.current });
      toast("success", "Disconnected");
      S.current = null;
      await loadList();
      return render();
    }
    if ((el = d("[data-srv-tab]"))) {
      S.tab = el.dataset.srvTab;
      render();
      if (S.tab === "sites" && !S.sites && S.info) loadSites();
      if (S.tab === "files" && !S.files.path && S.info) loadFiles(S.info.home || "~");
      return;
    }
    if ((el = d("[data-srv-service]"))) return runRemote("remote-service", { unit: el.dataset.unit, op: el.dataset.srvService }, false);
    if ((el = d("[data-srv-url]"))) { e.stopPropagation(); return api("open", { target: "url", url: el.dataset.srvUrl }); }
    if ((el = d("[data-srv-deploy]"))) {
      e.stopPropagation();
      const site = S.sites[+el.dataset.srvDeploy];
      if (!(await confirmModal({ title: `Deploy ${site.name}?`, confirm: "Deploy", message: `Runs ${DEPLOY_STEPS[site.type] || DEPLOY_STEPS.node} in <b>${esc(site.path)}</b> on ${esc(server().name)}.` }))) return;
      return runRemote("remote-deploy", sitePayload(site));
    }
    if ((el = d("[data-rsite]"))) return openSite(+el.dataset.rsite);

    // files
    if ((el = d("[data-srv-cd]"))) return loadFiles(el.dataset.srvCd);
    if (d("[data-srv-hidden]")) { S.files.hidden = !S.files.hidden; return loadFiles(S.files.path); }
    if (d("[data-srv-upload]")) return api("server_upload", { id: S.current, dir: S.files.path });
    if ((el = d("[data-srv-new]"))) {
      const kind = el.dataset.srvNew;
      const name = await promptModal(kind === "folder" ? "New folder" : "New file", "Name", "");
      if (!name) return;
      await api("server_file_op", { id: S.current, op: kind === "folder" ? "mkdir" : "touch", path: joinPath(S.files.path, name) });
      return loadFiles(S.files.path);
    }
    if ((el = d("[data-rf]"))) {
      e.stopPropagation();
      const entry = S.files.entries[+el.closest("[data-rfile]").dataset.rfile];
      const path = joinPath(S.files.path, entry.name);
      const op = el.dataset.rf;
      if (op === "edit") return editFile(path);
      if (op === "download") return api("server_download", { id: S.current, path, dir: entry.dir });
      if (op === "rename") {
        const target = await promptModal("Rename or move", "New path", path);
        if (!target || target === path) return;
        await api("server_file_op", { id: S.current, op: "rename", path, target: target.startsWith("/") ? target : joinPath(S.files.path, target) });
        return loadFiles(S.files.path);
      }
      if (op === "delete") {
        if (!(await confirmModal({ title: `Delete ${entry.name}?`, danger: true, confirm: "Delete", message: `<span class="mono">${esc(path)}</span>${entry.dir ? " and everything inside it" : ""} will be permanently removed from the server.` }))) return;
        await api("server_file_op", { id: S.current, op: "delete", path });
        return loadFiles(S.files.path);
      }
    }
    if ((el = d("[data-rfile]"))) {
      const entry = S.files.entries[+el.dataset.rfile];
      const path = joinPath(S.files.path, entry.name);
      return entry.dir || entry.link ? loadFiles(path) : editFile(path);
    }

    // remote site drawer
    if ((el = d("[data-rsite-tab]"))) {
      if (S.siteTab === "env" && el.dataset.rsiteTab !== "env" && EnvEditor.dirty()
          && !(await confirmModal({ title: "Discard changes?", message: "You have unsaved environment variables.", confirm: "Discard", danger: true }))) return;
      S.siteTab = el.dataset.rsiteTab;
      return renderSite();
    }
    if ((el = d("[data-ra]"))) return runRemote("remote-artisan", { path: S.site.path, php: S.site.php, args: el.dataset.ra });
    if ((el = d("[data-rm]"))) return runRemote("remote-manage", { ...sitePayload(S.site), args: el.dataset.rm });
    if ((el = d("[data-rsa]"))) {
      const site = S.site;
      switch (el.dataset.rsa) {
        case "browser": return api("open", { target: "url", url: site.url });
        case "files": closeDrawer(); S.tab = "files"; render(); return loadFiles(site.path);
        case "terminal": return api("server_terminal", { id: S.current, path: site.path });
        case "env": return editFile(joinPath(site.path, ".env"));
        case "database":
          try {
            toast("success", "Opening the database through SSH…");
            const target = await LD.call("server_db", { id: S.current, path: site.path });
            closeDrawer();
            setView("database");
            return Database.open(target.conn, target.database);
          } catch (err) {
            return toast("error", "Couldn't open the database", err.message);
          }
        case "log": S.siteTab = "logs"; return renderSite();
        case "log-refresh": return loadLog(true);
        case "deploy": return runRemote("remote-deploy", sitePayload(site));
        case "restart": return runRemote("remote-restart", sitePayload(site));
        case "install": case "build": return runRemote("remote-app", { ...sitePayload(site), op: el.dataset.rsa });
        case "pull": return runRemote("remote-git", { path: site.path, op: "pull" });
        case "composer": return runRemote("remote-composer", { path: site.path, php: site.php });
        case "down": case "up": return runRemote("remote-maintenance", { path: site.path, php: site.php, op: el.dataset.rsa });
      }
    }
  });

  document.addEventListener("submit", (e) => {
    if (e.target.matches("[data-rmanage]")) {
      e.preventDefault();
      const margs = e.target.elements.args.value.trim().replace(/^(python3?\s+)?manage\.py\s+/, "");
      if (margs) runRemote("remote-manage", { ...sitePayload(S.site), args: margs });
      e.target.elements.args.value = "";
      return;
    }
    if (!e.target.matches("[data-rartisan]")) return;
    e.preventDefault();
    const args = e.target.elements.args.value.trim().replace(/^(php\s+)?artisan\s+/, "");
    if (!args) return;
    runRemote("remote-artisan", { path: S.site.path, php: S.site.php, args });
    e.target.elements.args.value = "";
  });

  async function editFile(path) {
    try {
      await LD.call("server_edit", { id: S.current, path });
      toast("success", `Opened ${path.split("/").pop()}`, "Saving it uploads the file back to the server.");
    } catch (err) {
      toast("error", "Couldn't open file", err.message);
    }
  }

  return {
    closeSite() {
      S.site = null;
      clearInterval(logTimer);
    },
    async show() {
      if (!S.loaded) await loadList();
      render();
    },
    onEvent(event) {
      if (event.type === "remote-file") {
        event.ok ? toast("success", `Saved to server: ${event.path.split("/").pop()}`)
                 : toast("error", `Upload failed: ${event.path.split("/").pop()}`, event.error);
      }
      if (event.type === "transfer") {
        event.ok ? toast("success", event.label) : toast("error", "Transfer failed", event.error);
        if (event.ok && S.tab === "files" && S.current) loadFiles(S.files.path);
      }
    },
    onTaskDone(task) {
      // Remote task titles end with "· <server name>"; refresh that server's view.
      if (!S.current || !server() || !S.info || !task.title.endsWith(`· ${server().name}`)) return;
      LD.call("server_info", { id: S.current }).then((info) => { S.info = info; if (S.tab === "overview") renderBody(); }).catch(() => {});
      if (S.tab === "sites") loadSites();
    },
  };
})();
window.Servers = Servers;
loadServersCount();

async function loadServersCount() {
  try {
    const data = await LD.call("servers");
    $("#nav-servers-count").textContent = data.servers.length || "";
  } catch { /* shown when the page opens */ }
}

/* ── demo data for designing in a browser ─────────────── */
{
  const base = Demo.handle;
  const demoServers = [
    { id: "prod", name: "Production", host: "203.0.113.10", user: "forge", port: "", key: "", connected: true },
    { id: "staging", name: "Staging", host: "staging", user: "", port: "2222", key: "", connected: false },
  ];
  Demo.handle = function (id, method, params) {
    const ok = (data) => setTimeout(() => LD.resolve(id, { ok: true, data }), 160);
    switch (method) {
      case "servers": return ok({ servers: demoServers, ssh_hosts: ["roayat", "do-box"] });
      case "server_info": return ok({
        hostname: "prod-01", os: "Ubuntu 24.04.1 LTS", kernel: "6.8.0-45-generic", uptime: "1893210", load: "0.42 0.37 0.30",
        cpus: "4", mem_total: "8264736768", mem_used: "5123637248", disk_total: "84321009664", disk_used: "71028514816",
        user: "forge", home: "/home/forge", sudo: "password", php: "8.3.12", git: "yes", composer: "yes", sudo_cached: false,
        units: [{ unit: "nginx", status: "active" }, { unit: "mysql", status: "active" }, { unit: "redis-server", status: "active" },
          { unit: "supervisor", status: "active" }, { unit: "php8.3-fpm", status: "active" }, { unit: "php8.2-fpm", status: "inactive" }],
      });
      case "server_sites": return ok([
        { name: "shop", path: "/home/forge/shop.example.com", domains: ["shop.example.com", "www.shop.example.com"], url: "https://shop.example.com", php: "8.3", ssl: true, branch: "main", down: false },
        { name: "api", path: "/var/www/api", domains: ["api.example.com"], url: "https://api.example.com", php: "8.3", ssl: true, branch: "production", down: true },
        { name: "storefront", type: "nuxt", path: "/var/www/storefront", domains: ["example.com"], url: "https://example.com", php: "", ssl: true, branch: "main", down: false, port: "3000", pm2: { id: 0, name: "storefront", status: "online" } },
        { name: "admin", type: "django", path: "/srv/admin", domains: ["admin.example.com"], url: "https://admin.example.com", php: "", ssl: true, branch: "main", down: false, unit: "gunicorn-admin", unit_status: "active" },
      ]);
      case "server_ls": return ok({ path: params.path === "~" ? "/home/forge" : params.path, entries: [
        { name: "app", dir: true, link: false, size: 4096, mtime: 1761000000, mode: "755", owner: "forge" },
        { name: "public", dir: true, link: false, size: 4096, mtime: 1761100000, mode: "755", owner: "forge" },
        { name: "storage", dir: true, link: false, size: 4096, mtime: 1761200000, mode: "775", owner: "www-data" },
        { name: ".env", dir: false, link: false, size: 1834, mtime: 1761300000, mode: "640", owner: "forge" },
        { name: "artisan", dir: false, link: false, size: 425, mtime: 1760000000, mode: "755", owner: "forge" },
        { name: "composer.json", dir: false, link: false, size: 2412, mtime: 1760500000, mode: "644", owner: "forge" },
      ] });
      case "server_log": return ok({ exists: true, text: "[2026-10-22 09:12:01] production.INFO: Payment captured\n[2026-10-22 09:14:44] production.ERROR: SQLSTATE[HY000] Connection refused" });
      default: return base.call(this, id, method, params);
    }
  };
}
