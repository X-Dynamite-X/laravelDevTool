"use strict";

/* ── Laravel Development Tools ───────────────────────────────────────────────
   Interactive Web Tinker, Structured Real-Time Log Viewer, and Local Mailbox.
   Optimized for < 10MB memory footprint and blazing responsiveness.
───────────────────────────────────────────────────────────────────────────── */

const LaravelDev = (() => {
  const activePollers = new Set();
  let currentSite = null;
  let activeTinkerSite = null;

  function poll(fn, ms) {
    let timer = null;
    let stopped = false;
    let inFlight = false;

    async function tick() {
      if (stopped) return;
      if (document.hidden) return;
      inFlight = true;
      try {
        await fn();
      } catch (err) {
        // Handled in caller
      } finally {
        inFlight = false;
        if (!stopped) {
          const delay = typeof ms === "function" ? ms() : ms;
          timer = setTimeout(tick, delay);
        }
      }
    }

    function onVisibility() {
      if (!stopped && !document.hidden && !inFlight && timer === null) {
        tick();
      }
    }

    document.addEventListener("visibilitychange", onVisibility);

    const poller = {
      stop() {
        stopped = true;
        if (timer !== null) {
          clearTimeout(timer);
          timer = null;
        }
        document.removeEventListener("visibilitychange", onVisibility);
        activePollers.delete(poller);
      },
      restart() {
        if (timer !== null) clearTimeout(timer);
        const delay = typeof ms === "function" ? ms() : ms;
        timer = setTimeout(tick, delay);
      }
    };

    activePollers.add(poller);
    const initialDelay = typeof ms === "function" ? ms() : ms;
    timer = setTimeout(tick, initialDelay);
    return poller;
  }

  function showPollError(container, error, retryFn) {
    if (!container) return;
    let banner = $(".poll-error-banner", container);
    const msg = error?.message || String(error || "Unknown error");
    if (!banner) {
      banner = document.createElement("div");
      banner.className = "poll-error-banner";
      banner.style.cssText = "display:flex;align-items:center;justify-content:space-between;padding:6px 12px;margin-bottom:10px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);border-radius:6px;font-size:12px;color:var(--danger);gap:8px;";
      container.prepend(banner);
    }
    banner.innerHTML = `
      <span style="display:flex;align-items:center;gap:6px">
        ${icon("alert")} Couldn't refresh: ${esc(msg)}
      </span>
      <button class="btn sm ghost" style="padding:2px 8px;font-size:11px" id="btn-retry-poll">Retry</button>
    `;
    const retryBtn = $("#btn-retry-poll", banner);
    if (retryBtn && retryFn) {
      retryBtn.addEventListener("click", () => {
        banner.remove();
        retryFn();
      });
    }
  }

  function clearPollError(container) {
    if (!container) return;
    const banner = $(".poll-error-banner", container);
    if (banner) banner.remove();
  }

  // ── 1. Interactive Web Tinker ─────────────────────────────────────────────

  const TINKER_SNIPPETS = [
    { label: "User count", code: "App\\Models\\User::count();" },
    { label: "First user", code: "App\\Models\\User::first();" },
    { label: "Recent 5 users", code: "App\\Models\\User::latest()->take(5)->get();" },
    { label: "Laravel version", code: "app()->version();" },
    { label: "App name config", code: "config('app.name');" },
    { label: "Database connection", code: "DB::connection()->getDatabaseName();" },
    { label: "All registered routes count", code: "count(Route::getRoutes());" },
    { label: "Cache put & get test", code: "Cache::put('dev_test', 'works!', 60);\nCache::get('dev_test');" },
  ];

  function getTinkerHistory() {
    try {
      return JSON.parse(localStorage.getItem("ld_tinker_history") || "[]");
    } catch {
      return [];
    }
  }

  function addTinkerHistory(code) {
    if (!code || !code.trim()) return;
    try {
      let history = getTinkerHistory().filter((c) => c.trim() !== code.trim());
      history.unshift(code.trim());
      if (history.length > 25) history = history.slice(0, 25);
      localStorage.setItem("ld_tinker_history", JSON.stringify(history));
    } catch { /* ignore storage errors */ }
  }

  function mountTinker(container, site) {
    destroy();
    currentSite = site;
    const draftKey = `ld_tinker_draft_${site.name}`;
    const initialCode = localStorage.getItem(draftKey) || "// Type PHP or Eloquent expressions:\nApp\\Models\\User::count();";

    const historyItems = getTinkerHistory();

    container.innerHTML = `
      <div class="tinker-container">
        <div class="tinker-toolbar">
          <button class="btn primary sm" id="tinker-run-btn" title="Execute (Ctrl+Enter)">
            ${icon("play")}Run <kbd>Ctrl+Enter</kbd>
          </button>
          <button class="btn danger sm" id="tinker-stop-btn" style="display:none" title="Stop execution">
            ${icon("stop")}Stop
          </button>
          <select class="input sm" id="tinker-snippets-select" style="max-width:180px">
            <option value="">Snippets…</option>
            ${TINKER_SNIPPETS.map((s, i) => `<option value="${i}">${esc(s.label)}</option>`).join("")}
          </select>
          <select class="input sm" id="tinker-history-select" style="max-width:160px">
            <option value="">History (${historyItems.length})…</option>
            ${historyItems.map((h, i) => `<option value="${i}">${esc(h.slice(0, 32).replace(/\n/g, " "))}…</option>`).join("")}
          </select>
          <button class="btn ghost sm" id="tinker-clear-btn" title="Clear Editor">
            ${icon("trash")}Clear
          </button>
          <a href="tinkerwell://?project=${encodeURIComponent(site.path)}" class="btn ghost sm" id="tinker-tinkerwell-btn" title="Open in Tinkerwell (Desktop App)" style="text-decoration:none">
            ${icon("code")}Tinkerwell
          </a>
          <span class="tinker-status" id="tinker-status" style="margin-left:auto">
            <span class="chip sm">Ready</span>
          </span>
        </div>

        <div class="tinker-editor-wrap">
          <textarea id="tinker-editor" class="tinker-editor" spellcheck="false" placeholder="Write PHP / Eloquent code, e.g. App\\Models\\User::first();">${esc(initialCode)}</textarea>
        </div>

        <div class="tinker-output-pane">
          <div class="tinker-output-header">
            <span class="text sm bold" style="display:flex;align-items:center;gap:6px">
              ${icon("terminal")}Output
            </span>
            <div style="display:flex;align-items:center;gap:6px">
              <span id="tinker-timing" class="muted sm"></span>
              <button class="btn ghost icon-btn sm" id="tinker-copy-btn" title="Copy Output">${icon("copy")}</button>
            </div>
          </div>
          <pre class="tinker-output-body" id="tinker-output"><span class="muted">// Click Run or press Ctrl+Enter to execute</span></pre>
        </div>
      </div>`;

    const editor = $("#tinker-editor", container);
    const runBtn = $("#tinker-run-btn", container);
    const stopBtn = $("#tinker-stop-btn", container);
    const clearBtn = $("#tinker-clear-btn", container);
    const snippetsSelect = $("#tinker-snippets-select", container);
    const historySelect = $("#tinker-history-select", container);
    const outputEl = $("#tinker-output", container);
    const statusEl = $("#tinker-status", container);
    const timingEl = $("#tinker-timing", container);
    const copyBtn = $("#tinker-copy-btn", container);

    // Auto-save draft
    editor.addEventListener("input", () => {
      localStorage.setItem(draftKey, editor.value);
    });

    // Handle Tab and Ctrl+Enter / Cmd+Enter
    editor.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
        e.preventDefault();
        runTinkerCode();
      } else if (e.key === "Tab") {
        e.preventDefault();
        const start = editor.selectionStart;
        const end = editor.selectionEnd;
        editor.value = editor.value.substring(0, start) + "    " + editor.value.substring(end);
        editor.selectionStart = editor.selectionEnd = start + 4;
        localStorage.setItem(draftKey, editor.value);
      }
    });

    runBtn.addEventListener("click", runTinkerCode);

    clearBtn.addEventListener("click", () => {
      editor.value = "";
      localStorage.setItem(draftKey, "");
      editor.focus();
    });

    snippetsSelect.addEventListener("change", () => {
      const idx = snippetsSelect.value;
      if (idx !== "") {
        const snip = TINKER_SNIPPETS[Number(idx)];
        if (snip) {
          editor.value = snip.code;
          localStorage.setItem(draftKey, snip.code);
          editor.focus();
        }
        snippetsSelect.value = "";
      }
    });

    historySelect.addEventListener("change", () => {
      const idx = historySelect.value;
      if (idx !== "") {
        const item = historyItems[Number(idx)];
        if (item) {
          editor.value = item;
          localStorage.setItem(draftKey, item);
          editor.focus();
        }
        historySelect.value = "";
      }
    });

    copyBtn.addEventListener("click", () => {
      const text = outputEl.innerText;
      if (text) {
        navigator.clipboard?.writeText(text);
        toast("success", "Output copied to clipboard");
      }
    });

    stopBtn.addEventListener("click", stopTinkerCode);

    async function stopTinkerCode() {
      try {
        await LD.call("tinker_stop", { name: site.name });
        toast("info", "Tinker stop signal sent");
      } catch (err) {
        toast("error", "Couldn't stop Tinker", err.message);
      }
    }

    async function runTinkerCode() {
      const code = editor.value.trim();
      if (!code) {
        toast("error", "Code is empty");
        return;
      }

      activeTinkerSite = site.name;
      runBtn.style.display = "none";
      stopBtn.style.display = "inline-flex";
      statusEl.innerHTML = `<span class="chip sm" style="color:var(--accent)">Executing…</span>`;
      timingEl.innerText = "";

      try {
        const res = await LD.call("tinker", { name: site.name, code });
        addTinkerHistory(code);

        if (res.ok) {
          statusEl.innerHTML = `<span class="chip sm text-green">Success</span>`;
          timingEl.innerText = `${res.duration_ms}ms`;
          outputEl.innerHTML = res.output ? esc(res.output) : `<span class="muted">// (Executed with return value null / void)</span>`;
        } else {
          statusEl.innerHTML = `<span class="chip sm danger">Error</span>`;
          timingEl.innerText = `${res.duration_ms}ms`;
          let errContent = "";
          if (res.output) errContent += `${esc(res.output)}\n\n`;
          errContent += `<span class="text-danger">${esc(res.error || "Execution failed")}</span>`;
          outputEl.innerHTML = errContent;
        }
      } catch (err) {
        statusEl.innerHTML = `<span class="chip sm danger">Failed</span>`;
        outputEl.innerHTML = `<span class="text-danger">${esc(err.message)}</span>`;
      } finally {
        if (activeTinkerSite === site.name) activeTinkerSite = null;
        runBtn.style.display = "inline-flex";
        stopBtn.style.display = "none";
        runBtn.disabled = false;
        runBtn.innerHTML = `${icon("play")}Run <kbd>Ctrl+Enter</kbd>`;
      }
    }
  }

  // ── 2. Structured Real-Time Log Viewer ─────────────────────────────────────

  let logFilter = "all";
  let logSearch = "";
  let logViewMode = "structured"; // "structured" | "raw"
  let logFollow = true;
  let selectedLogFile = "laravel.log";
  let logOffset = 0;
  let logInode = 0;
  let cachedLogEntries = [];
  let logStats = { total: 0, errors: 0, warnings: 0, info: 0 }; // whole tail, not just the last increment
  let rawLogText = "";
  const openTraces = new Set();
  let availableLogFiles = [];

  function mountLogs(container, site) {
    destroy();
    currentSite = site;
    logOffset = 0;
    logInode = 0;
    cachedLogEntries = [];
    rawLogText = "";
    openTraces.clear();
    selectedLogFile = "laravel.log";
    availableLogFiles = [];
    let aggFilter = "all";
    const hiddenPatterns = new Set();
    let activeCardIdx = -1;

    const isAppLog = logSource(site) === "app";
    if (isAppLog) {
      logViewMode = "raw";
    }

    container.innerHTML = `
      <div class="log-viewer-container">
        <div class="log-toolbar-wrap">
          <div class="flex-between-wrap">
            <div class="log-filter-row" id="log-level-filters" ${isAppLog ? "hidden" : ""}>
              <button class="btn sm log-pill ${logFilter === "all" ? "active" : ""}" data-log-filter="all">All <span class="badge sm" id="cnt-all">0</span></button>
              <button class="btn sm log-pill ${logFilter === "errors" ? "active" : ""} text-red" data-log-filter="errors">Errors <span class="badge sm" id="cnt-errors">0</span></button>
              <button class="btn sm log-pill ${logFilter === "warnings" ? "active" : ""} text-amber" data-log-filter="warnings">Warnings <span class="badge sm" id="cnt-warnings">0</span></button>
              <button class="btn sm log-pill ${logFilter === "info" ? "active" : ""}" data-log-filter="info" style="color:#3b82f6">Info <span class="badge sm" id="cnt-info">0</span></button>
              <span class="muted text xs" style="margin-left:4px" title="Counts reflect up to the last 512 KB of parsed log entries">last 512 KB</span>
            </div>

            <div style="display:flex;align-items:center;gap:6px;margin-left:auto;flex-wrap:wrap">
              ${!isAppLog ? `<select id="log-file-select" class="select sm" style="max-width:160px;font-family:var(--mono);font-size:11.5px" title="Select log file"><option value="laravel.log">laravel.log</option></select>` : ""}
              ${!isAppLog ? `
              <div class="seg" id="log-mode-seg">
                <button class="${logViewMode === "structured" ? "active" : ""}" data-mode="structured">Cards</button>
                <button class="${logViewMode === "aggregated" ? "active" : ""}" data-mode="aggregated">Issues</button>
                <button class="${logViewMode === "raw" ? "active" : ""}" data-mode="raw">Raw</button>
              </div>` : ""}
              <button class="btn sm ${logFollow ? "active-toggle" : ""}" id="log-follow-btn" title="Auto-scroll to latest entries">${icon("pulse")}Follow</button>
              ${site.type === "laravel" && runsServer(site) ? `<button class="btn sm" data-log-source>${icon("layers")}${logSource(site) === "app" ? "laravel.log" : "Server output"}</button>` : ""}
              <button class="btn sm icon-btn" id="log-refresh-btn" title="Refresh">${icon("refresh")}</button>
              ${isAppLog ? "" : `<button class="btn sm icon-btn" id="log-clear-btn" title="Clear log">${icon("trash")}</button>`}
            </div>
          </div>

          <div style="position:relative;margin-top:4px" ${isAppLog ? "hidden" : ""}>
            <input type="search" id="log-search-input" class="input sm" style="width:100%;padding-left:30px" placeholder="Filter message or stack trace..." value="${esc(logSearch)}">
            <span style="position:absolute;left:9px;top:50%;transform:translateY(-50%);opacity:.5">${icon("search")}</span>
          </div>
        </div>

        <div id="log-content-area" style="margin-top:8px">
          <div class="log-cards" id="log-cards" ${logViewMode !== "structured" || isAppLog ? "hidden" : ""}>
            <div style="padding:24px;text-align:center;color:var(--muted)">Loading logs…</div>
          </div>
          <div class="log-aggregated" id="log-aggregated" ${logViewMode !== "aggregated" || isAppLog ? "hidden" : ""}></div>
          <pre class="log-view" id="log-view-raw" ${logViewMode !== "raw" && !isAppLog ? "hidden" : ""}></pre>
        </div>
      </div>`;

    // Filter clicks
    const filterRow = $("#log-level-filters", container);
    if (filterRow) {
      filterRow.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-log-filter]");
        if (btn) {
          logFilter = btn.dataset.logFilter;
          $$(".log-pill", filterRow).forEach((b) => b.classList.toggle("active", b === btn));
          renderCards();
        }
      });
    }

    // Log file select
    const fileSelect = $("#log-file-select", container);
    if (fileSelect) {
      fileSelect.addEventListener("change", () => {
        selectedLogFile = fileSelect.value;
        logOffset = 0;
        logInode = 0;
        cachedLogEntries = [];
        rawLogText = "";
        openTraces.clear();
        fetchAndRenderLogs(false, true);
      });
    }

    // Mode toggle
    const seg = $("#log-mode-seg", container);
    if (seg) {
      seg.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-mode]");
        if (btn) {
          logViewMode = btn.dataset.mode;
          $$("button", seg).forEach((b) => b.classList.toggle("active", b === btn));
          const cardsEl = $("#log-cards", container);
          const rawEl = $("#log-view-raw", container);
          const aggEl = $("#log-aggregated", container);
          if (cardsEl) cardsEl.hidden = logViewMode !== "structured";
          if (rawEl) rawEl.hidden = logViewMode !== "raw";
          if (aggEl) aggEl.hidden = logViewMode !== "aggregated";

          if (logViewMode === "aggregated") {
            renderAggregatedIssues();
          } else {
            logOffset = 0;
            logInode = 0;
            cachedLogEntries = [];
            rawLogText = "";
            fetchAndRenderLogs(false, true);
          }
        }
      });
    }

    async function renderAggregatedIssues() {
      const area = $("#log-aggregated", container);
      if (!area) return;
      area.innerHTML = `<div style="padding:28px;text-align:center;color:var(--muted)">${icon("pulse")} Grouping issues by exception & call site…</div>`;
      try {
        const res = await LD.call("log_errors_aggregated", { name: site.name, file: selectedLogFile });
        if (!res.ok) throw new Error(res.error || "Failed to load issues");
        const issues = res.issues || [];
        if (!issues.length) {
          area.innerHTML = `<div class="card" style="padding:36px;text-align:center;color:var(--muted)">${icon("check")} No errors recorded in ${esc(selectedLogFile)}. Clean bill of health!</div>`;
          return;
        }

        area.innerHTML = `
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;padding:8px 12px;background:var(--surface-2);border-radius:var(--radius-sm)">
            <div style="display:flex;align-items:center;gap:10px">
              <span class="chip sm" style="font-weight:700">${res.total_issues} Unique Issues</span>
              <span class="chip sm ${res.unresolved_count > 0 ? 'text-red' : ''}">${res.unresolved_count} Unresolved</span>
            </div>
            <div style="display:flex;align-items:center;gap:6px">
              <button class="btn xs ${aggFilter === 'all' ? 'active' : ''}" data-agg-filter="all">All</button>
              <button class="btn xs ${aggFilter === 'unresolved' ? 'active' : ''}" data-agg-filter="unresolved">Unresolved</button>
              <button class="btn xs ${aggFilter === 'resolved' ? 'active' : ''}" data-agg-filter="resolved">Resolved</button>
            </div>
          </div>
          <div class="issues-list" style="display:flex;flex-direction:column;gap:10px">
            ${issues.filter(i => {
              if (aggFilter === 'unresolved') return !i.resolved;
              if (aggFilter === 'resolved') return i.resolved;
              return true;
            }).map(i => `
              <div class="card issue-card" style="border-left:4px solid ${i.resolved ? 'var(--green)' : 'var(--red)'};padding:12px 14px;opacity:${i.resolved ? '0.75' : '1'}">
                <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:6px">
                  <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                    <span class="badge sm" style="font-family:var(--mono);font-weight:700;background:rgba(239,68,68,0.12);color:var(--red)">${esc(i.type)}</span>
                    <span class="chip sm" style="font-weight:700">${i.count}x</span>
                    ${i.resolved ? `<span class="chip sm" style="color:var(--green)">✓ Resolved</span>` : `<span class="chip sm text-red">Active</span>`}
                  </div>
                  <div style="display:flex;align-items:center;gap:6px">
                    <button class="btn xs ghost" data-ai-fix-agg="${esc(i.signature)}" title="Analyze and fix with AI">${icon("sparkles")} ${t("ai_fix", "AI Fix")}</button>
                    <button class="btn xs ${i.resolved ? 'ghost' : 'primary'}" data-resolve-sig="${esc(i.signature)}" data-current-state="${i.resolved}">${i.resolved ? 'Reopen' : 'Mark Resolved'}</button>
                    ${i.trace ? `<button class="btn xs ghost" data-toggle-sig-trace="${esc(i.signature)}">${icon("code")} Trace</button>` : ''}
                  </div>
                </div>
                <div style="font-family:var(--mono);font-size:12.5px;color:var(--text);margin-bottom:6px;word-break:break-word">${esc(i.message)}</div>
                <div style="display:flex;align-items:center;justify-content:space-between;font-size:11.5px;color:var(--muted);flex-wrap:wrap;gap:8px">
                  <div>
                    ${i.file ? `<button class="btn ghost xs link" data-open-issue-file="${esc(i.file)}" data-line="${i.line || 1}" style="padding:0">${icon("file")} ${esc(i.file)}:${i.line || 1}</button>` : ''}
                  </div>
                  <div>First seen: ${esc(i.first_seen)} · Last seen: ${esc(i.last_seen)}</div>
                </div>
                ${i.trace ? `<pre id="sig-trace-${esc(i.signature.replace(/[^a-zA-Z0-9_\-]/g, '_'))}" class="log-trace" hidden style="margin-top:8px">${esc(i.trace)}</pre>` : ''}
              </div>
            `).join('')}
          </div>
        `;

        // Handlers
        $$("[data-agg-filter]", area).forEach(btn => {
          btn.addEventListener("click", () => {
            aggFilter = btn.dataset.aggFilter;
            renderAggregatedIssues();
          });
        });
        $$("[data-ai-fix-agg]", area).forEach(btn => {
          btn.addEventListener("click", () => {
            const sig = btn.dataset.aiFixAgg;
            const issue = issues.find(x => x.signature === sig);
            if (issue && window.openAiFixModal) {
              window.openAiFixModal(site.name, {
                message: `${issue.type}: ${issue.message}`,
                file: issue.file || "",
                line: issue.line || 1,
                trace: issue.trace || "",
              });
            }
          });
        });
        $$("[data-resolve-sig]", area).forEach(btn => {
          btn.addEventListener("click", async () => {
            const sig = btn.dataset.resolveSig;
            const cur = btn.dataset.currentState === "true";
            await LD.call("log_error_resolve", { name: site.name, signature: sig, resolved: !cur });
            toast("success", !cur ? "Issue marked as resolved" : "Issue reopened");
            renderAggregatedIssues();
          });
        });
        $$("[data-toggle-sig-trace]", area).forEach(btn => {
          btn.addEventListener("click", () => {
            const sig = btn.dataset.toggleSigTrace.replace(/[^a-zA-Z0-9_\-]/g, '_');
            const el = $(`#sig-trace-${sig}`, area);
            if (el) el.hidden = !el.hidden;
          });
        });
        $$("[data-open-issue-file]", area).forEach(btn => {
          btn.addEventListener("click", () => {
            LD.call("open_file", { path: btn.dataset.openIssueFile, line: parseInt(btn.dataset.line || "1", 10) });
          });
        });
      } catch (err) {
        area.innerHTML = `<div class="card" style="padding:24px;color:var(--red)">Failed to load issues: ${esc(err.message)}</div>`;
      }
    }

    // Follow toggle
    const followBtn = $("#log-follow-btn", container);
    if (followBtn) {
      followBtn.addEventListener("click", () => {
        logFollow = !logFollow;
        followBtn.classList.toggle("active-toggle", logFollow);
        if (logFollow) {
          const rawArea = $("#log-view-raw");
          const cardsArea = $("#log-cards");
          if (rawArea && !rawArea.hidden) rawArea.scrollTop = rawArea.scrollHeight;
          if (cardsArea && !cardsArea.hidden) cardsArea.scrollTop = 0;
        }
      });
    }

    // Search input
    const searchInput = $("#log-search-input", container);
    let searchDebounce = null;
    if (searchInput) {
      searchInput.addEventListener("input", () => {
        clearTimeout(searchDebounce);
        searchDebounce = setTimeout(() => {
          logSearch = searchInput.value.toLowerCase().trim();
          renderCards();
        }, 150);
      });
    }

    // Refresh & Clear
    $("#log-refresh-btn", container)?.addEventListener("click", () => fetchAndRenderLogs(false, true));

    const clearBtn = $("#log-clear-btn", container);
    if (clearBtn) {
      clearBtn.addEventListener("click", async () => {
        if (!(await confirmModal({ title: `Clear ${selectedLogFile}?`, message: `This empties storage/logs/${selectedLogFile} permanently.`, confirm: "Clear", danger: true }))) return;
        await LD.call("clear_log", { name: site.name });
        toast("success", "Log cleared");
        fetchAndRenderLogs(false, true);
      });
    }

    // Card interactions (toggle trace, copy, hide similar, copy md)
    const cardsArea = $("#log-cards", container);
    if (cardsArea) {
      cardsArea.addEventListener("click", (e) => {
        const unhideBtn = e.target.closest("[data-unhide]");
        if (unhideBtn) {
          hiddenPatterns.delete(unhideBtn.dataset.unhide);
          renderCards();
          return;
        }

        if (e.target.closest("#clear-all-hidden")) {
          hiddenPatterns.clear();
          renderCards();
          return;
        }

        const hideBtn = e.target.closest("[data-hide-similar]");
        if (hideBtn) {
          const id = hideBtn.dataset.hideSimilar;
          const entry = cachedLogEntries.find((item) => String(item.id) === String(id));
          if (entry && entry.message) {
            const pat = entry.message.slice(0, 45);
            hiddenPatterns.add(pat);
            toast("info", "Hidden similar entries", pat);
            renderCards();
          }
          return;
        }

        const copyMdBtn = e.target.closest("[data-copy-md]");
        if (copyMdBtn) {
          const id = copyMdBtn.dataset.copyMd;
          const entry = cachedLogEntries.find((item) => String(item.id) === String(id));
          if (entry) {
            const md = `### [${entry.level}] ${entry.date} (${entry.env})\n> ${entry.message}\n\n` +
              (entry.trace ? `\`\`\`stacktrace\n${entry.trace}\n\`\`\`` : "");
            navigator.clipboard?.writeText(md);
            toast("success", "Copied log entry as Markdown");
          }
          return;
        }

        const traceFilterBtn = e.target.closest("[data-trace-filter]");
        if (traceFilterBtn) {
          const tid = traceFilterBtn.dataset.traceFilter;
          const inp = $("#log-search-input", container);
          if (inp) inp.value = tid;
          logSearch = tid.toLowerCase().trim();
          selectedLogFile = "__all__";
          fetchAndRenderLogs(false, true);
          return;
        }

        const aiFixBtn = e.target.closest("[data-ai-fix-log]");
        if (aiFixBtn) {
          const id = aiFixBtn.dataset.aiFixLog;
          const entry = cachedLogEntries.find((item) => String(item.id) === String(id));
          if (entry && window.openAiFixModal && currentSite) {
            window.openAiFixModal(currentSite.name, {
              message: entry.message,
              trace: entry.trace || "",
              file: entry.file || "",
              line: entry.line || 1,
            });
          }
          return;
        }

        const traceBtn = e.target.closest("[data-toggle-trace]");
        if (traceBtn) {
          const id = traceBtn.dataset.toggleTrace;
          const traceEl = $(`#trace-${id}`, cardsArea);
          if (traceEl) {
            const willOpen = traceEl.hidden;
            traceEl.hidden = !willOpen;
            if (willOpen) openTraces.add(id);
            else openTraces.delete(id);
            traceBtn.innerHTML = `${icon("code")}${willOpen ? "Hide Trace" : `Trace (${traceEl.dataset.lines || 0})`}`;
          }
          return;
        }

        const copyBtn = e.target.closest("[data-copy-trace]");
        if (copyBtn) {
          const id = copyBtn.dataset.copyTrace;
          const traceEl = $(`#trace-${id}`, cardsArea);
          if (traceEl) {
            navigator.clipboard?.writeText(traceEl.innerText);
            toast("success", "Stack trace copied");
          }
        }
      });
    }

    // Keyboard shortcuts (j/k/e and /)
    const onLogKeyDown = (e) => {
      if (state.drawer?.tab !== "logs") return;
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) {
        if (e.key === "Escape") document.activeElement.blur();
        return;
      }
      if (e.key === "/") {
        e.preventDefault();
        const inp = $("#log-search-input", container);
        if (inp) { inp.focus(); inp.select(); }
        return;
      }
      const cards = $$(".log-card", $("#log-cards", container));
      if (!cards.length) return;
      if (e.key === "j" || e.key === "ArrowDown") {
        e.preventDefault();
        activeCardIdx = Math.min(activeCardIdx + 1, cards.length - 1);
        cards.forEach((c, idx) => c.style.outline = idx === activeCardIdx ? "2px solid var(--accent)" : "none");
        cards[activeCardIdx]?.scrollIntoView({ block: "nearest", behavior: "smooth" });
      } else if (e.key === "k" || e.key === "ArrowUp") {
        e.preventDefault();
        activeCardIdx = Math.max(activeCardIdx - 1, 0);
        cards.forEach((c, idx) => c.style.outline = idx === activeCardIdx ? "2px solid var(--accent)" : "none");
        cards[activeCardIdx]?.scrollIntoView({ block: "nearest", behavior: "smooth" });
      } else if (e.key === "e") {
        if (activeCardIdx >= 0 && cards[activeCardIdx]) {
          const btn = cards[activeCardIdx].querySelector("[data-toggle-trace]");
          if (btn) btn.click();
        }
      }
    };
    window.addEventListener("keydown", onLogKeyDown);

    fetchAndRenderLogs(false, true);
    poll(() => fetchAndRenderLogs(true), 3000);
  }

  function renderCards() {
    const cardsArea = $("#log-cards");
    if (!cardsArea) return;

    if (!cachedLogEntries.length) {
      cardsArea.innerHTML = `<div style="padding:32px;text-align:center;color:var(--muted)">No log entries found.</div>`;
      return;
    }

    const filtered = cachedLogEntries.filter((e) => {
      if (logFilter === "errors" && !["EMERGENCY", "ALERT", "CRITICAL", "ERROR"].includes(e.level)) return false;
      if (logFilter === "warnings" && e.level !== "WARNING") return false;
      if (logFilter === "info" && !["NOTICE", "INFO", "DEBUG"].includes(e.level)) return false;

      if (hiddenPatterns.size > 0 && e.message) {
        for (const pat of hiddenPatterns) {
          if (e.message.includes(pat)) return false;
        }
      }

      if (logSearch) {
        const matchMsg = e.message && e.message.toLowerCase().includes(logSearch);
        const matchTrace = e.trace && e.trace.toLowerCase().includes(logSearch);
        const matchDate = e.date && e.date.toLowerCase().includes(logSearch);
        const matchTraceId = (e.trace_id || e.request_id || e.job_id || "").toLowerCase().includes(logSearch);
        if (!matchMsg && !matchTrace && !matchDate && !matchTraceId) return false;
      }
      return true;
    });

    let chipsHtml = "";
    if (hiddenPatterns.size > 0) {
      chipsHtml = `
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:10px;padding:6px 10px;background:var(--surface-2);border-radius:6px;font-size:12px">
          <span class="muted">Hidden filters:</span>
          ${Array.from(hiddenPatterns).map((pat) => `
            <span class="chip sm" style="cursor:pointer;background:var(--surface-3);border:1px solid var(--border)" data-unhide="${esc(pat)}" title="Click to unhide">
              ${esc(pat.slice(0, 32))}… ✕
            </span>
          `).join("")}
          <button class="btn ghost xs" id="clear-all-hidden" style="margin-left:auto;font-size:11px">Unhide all</button>
        </div>`;
    }

    if (!filtered.length) {
      cardsArea.innerHTML = chipsHtml + `
        <div style="padding:48px 20px;text-align:center;color:var(--muted)">
          <div style="width:44px;height:44px;border-radius:12px;background:var(--surface-2);display:grid;place-items:center;margin:0 auto 12px;opacity:.6">
            ${icon("file")}
          </div>
          <b style="color:var(--text);font-size:14px;display:block;margin-bottom:4px">
            ${cachedLogEntries.length ? "No matching entries" : "No logs yet"}
          </b>
          <span style="font-size:12.5px">
            ${cachedLogEntries.length ? "Try clearing search or level filters." : "Errors will appear here."}
          </span>
        </div>`;
      return;
    }

    // Limit to 120 items rendered in DOM for performance
    cardsArea.innerHTML = chipsHtml + filtered.slice(0, 120).map((e) => {
      const isErr = ["EMERGENCY", "ALERT", "CRITICAL", "ERROR"].includes(e.level);
      const isWarn = e.level === "WARNING";
      const levelCls = isErr ? "error" : isWarn ? "warning" : "info";
      const hasTrace = Boolean(e.trace && e.trace.trim());
      const traceLines = hasTrace ? e.trace.split("\n").length : 0;
      const isOpen = openTraces.has(e.id);
      const traceBadge = (e.trace_id || e.request_id || e.job_id)
        ? `<span class="chip sm" style="font-family:var(--mono);font-size:10px;cursor:pointer;background:var(--surface-2)" data-trace-filter="${esc(e.trace_id || e.request_id || e.job_id)}" title="Filter by Trace ID">${icon("tag")}${esc((e.trace_id || e.request_id || e.job_id).slice(0, 16))}</span>`
        : "";

      return `
        <div class="log-card ${levelCls}">
          <div class="log-card-header">
            <span class="log-badge ${levelCls}">${esc(e.level)}</span>
            <span class="log-date">${esc(e.date)}</span>
            <span class="chip sm" style="font-family:var(--mono);font-size:11px">${esc(e.env)}</span>
            ${traceBadge}
            <div style="margin-left:auto;display:flex;gap:4px">
              ${isErr ? `<button class="btn ghost sm" data-ai-fix-log="${e.id}" title="Analyze and fix with AI">${icon("sparkles")} ${t("ai_fix", "AI Fix")}</button>` : ""}
              <button class="btn ghost icon-btn sm" data-hide-similar="${e.id}" title="Hide similar entries">${icon("eye-off")}</button>
              <button class="btn ghost sm" data-copy-md="${e.id}" title="Copy entry as Markdown">${icon("copy")}MD</button>
              ${hasTrace ? `<button class="btn ghost sm" data-toggle-trace="${e.id}">${icon("code")}${isOpen ? "Hide Trace" : `Trace (${traceLines})`}</button>` : ""}
              ${hasTrace ? `<button class="btn ghost icon-btn sm" data-copy-trace="${e.id}" title="Copy Trace">${icon("copy")}</button>` : ""}
            </div>
          </div>
          <div class="log-msg">${esc(e.message)}</div>
          ${hasTrace ? `<pre class="log-trace" id="trace-${e.id}" data-lines="${traceLines}" ${isOpen ? "" : "hidden"}>${esc(e.trace)}</pre>` : ""}
        </div>`;
    }).join("");
  }

  async function fetchAndRenderLogs(isInterval = false, forceReset = false) {
    if (!currentSite || state.drawer.tab !== "logs") return;
    const cardsArea = $("#log-cards");
    const rawArea = $("#log-view-raw");
    const container = $("#log-content-area") || cardsArea?.parentElement;

    if (forceReset) {
      logOffset = 0;
      logInode = 0;
      cachedLogEntries = [];
      rawLogText = "";
    }

    try {
      const isAppLog = logSource(currentSite) === "app";
      if (isAppLog) {
        const res = await LD.call("app_log", { name: currentSite.name });
        if (!cardsArea || !rawArea) return;
        clearPollError(container);
        cardsArea.hidden = true;
        rawArea.hidden = false;
        rawArea.innerHTML = res.exists && res.text
          ? res.text.split("\n").map((line) => {
              const cls = /\.(ERROR|CRITICAL|ALERT|EMERGENCY):/.test(line) ? "log-line-error" : /\.WARNING:/.test(line) ? "log-line-warning" : "";
              return cls ? `<span class="${cls}">${esc(line)}</span>` : esc(line);
            }).join("\n")
          : `<span style="opacity:.6">${res.exists ? "Log is empty." : "No output recorded yet."}</span>`;
        if (logFollow) rawArea.scrollTop = rawArea.scrollHeight;
        return;
      }

      // Laravel site log
      const res = await LD.call("log", {
        name: currentSite.name,
        file: selectedLogFile,
        offset: logOffset,
        inode: logInode,
        mode: logViewMode,
      });

      if (!cardsArea || !rawArea) return;
      clearPollError(container);

      // Update log file options if available
      if (Array.isArray(res.log_files) && res.log_files.length) {
        availableLogFiles = res.log_files;
        const fileSelect = $("#log-file-select");
        if (fileSelect) {
          const currentVal = fileSelect.value || selectedLogFile;
          const optionsHtml = availableLogFiles.map((f) => `<option value="${esc(f)}" ${f === currentVal ? "selected" : ""}>${esc(f)}</option>`).join("");
          if (fileSelect.innerHTML !== optionsHtml) {
            fileSelect.innerHTML = optionsHtml;
          }
        }
      }

      // Handle reset or incremental payload
      if (res.reset) {
        logOffset = res.offset || 0;
        logInode = res.inode || 0;
        cachedLogEntries = res.entries || [];
        rawLogText = res.raw || res.text || "";
        if (res.stats) logStats = { ...res.stats };
      } else {
        // An incremental read reports stats for the new lines only.
        for (const key of Object.keys(logStats)) logStats[key] += res.stats?.[key] || 0;
        logOffset = res.offset || logOffset;
        logInode = res.inode || logInode;
        if (Array.isArray(res.entries) && res.entries.length) {
          cachedLogEntries = [...res.entries, ...cachedLogEntries].slice(0, 500);
        }
        if (res.raw) {
          rawLogText += res.raw;
          if (rawLogText.length > 512 * 1024) {
            rawLogText = rawLogText.slice(-512 * 1024);
          }
        }
      }

      // Update stats counters
      const totalCount = cachedLogEntries.length;
      const errorCount = cachedLogEntries.filter((e) => ["EMERGENCY", "ALERT", "CRITICAL", "ERROR"].includes(e.level)).length;
      const warnCount = cachedLogEntries.filter((e) => e.level === "WARNING").length;
      const infoCount = cachedLogEntries.filter((e) => ["NOTICE", "INFO", "DEBUG"].includes(e.level)).length;

      const cntAll = $("#cnt-all");
      const cntErrors = $("#cnt-errors");
      const cntWarnings = $("#cnt-warnings");
      const cntInfo = $("#cnt-info");

      if (cntAll) cntAll.innerText = logStats.total || totalCount;
      if (cntErrors) cntErrors.innerText = logStats.errors || errorCount;
      if (cntWarnings) cntWarnings.innerText = logStats.warnings || warnCount;
      if (cntInfo) cntInfo.innerText = logStats.info || infoCount;

      if (logViewMode === "raw") {
        cardsArea.hidden = true;
        rawArea.hidden = false;
        rawArea.innerHTML = (rawLogText || res.text)
          ? (rawLogText || res.text).split("\n").map((line) => {
              const cls = /\.(ERROR|CRITICAL|ALERT|EMERGENCY):/.test(line) ? "log-line-error" : /\.WARNING:/.test(line) ? "log-line-warning" : "";
              return cls ? `<span class="${cls}">${esc(line)}</span>` : esc(line);
            }).join("\n")
          : `<span style="opacity:.6">${res.exists ? "Log is empty." : "No logs yet — errors will appear here."}</span>`;
        if (logFollow) rawArea.scrollTop = rawArea.scrollHeight;
      } else {
        cardsArea.hidden = false;
        rawArea.hidden = true;
        renderCards();
        if (logFollow && !isInterval) cardsArea.scrollTop = 0;
      }
    } catch (err) {
      const cardsArea = $("#log-cards");
      const container = $("#log-content-area") || cardsArea?.parentElement;
      if (container) {
        showPollError(container, err, () => fetchAndRenderLogs(false, true));
      }
    }
  }

  // ── 3. Local Mailbox (Mailpit & Zero-Config Log Mailer) ─────────────────────

  let selectedMailId = null;
  let cachedMessages = [];
  let mailSearch = "";
  let mailViewFormat = "html"; // "html" | "text" | "raw"
  let cachedMailSource = "none";
  let messageBodies = new Map();

  function prepareEmailHtml(rawHtml) {
    const html = String(rawHtml || "");
    const baseHead = `<meta charset="utf-8"><base target="_blank"><style>:root{color-scheme:light;}html,body{background-color:#ffffff;color:#18181b;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;}</style>`;
    if (/<head[\s>]/i.test(html)) {
      return html.replace(/<head([^>]*)>/i, `<head$1>${baseHead}`);
    }
    if (/<html[\s>]/i.test(html)) {
      return html.replace(/<html([^>]*)>/i, `<html$1><head>${baseHead}</head>`);
    }
    return `<!DOCTYPE html><html lang="en"><head>${baseHead}</head><body style="margin:16px">${html}</body></html>`;
  }

  function mountMail(container, site) {
    destroy();
    currentSite = site;
    selectedMailId = null;
    cachedMessages = [];
    messageBodies = new Map();
    cachedMailSource = "none";

    let mailActiveMode = "inbox";
    let selectedMailable = null;
    let previewDevice = "desktop";

    container.innerHTML = `
      <div class="mail-container">
        <div class="mail-sidebar">
          <div class="mail-sidebar-header">
            <div style="display:flex;align-items:center;justify-content:space-between">
              <span class="text sm bold" style="display:flex;align-items:center;gap:6px">
                ${icon("mail")}Mail <span class="badge sm" id="mail-count-badge">0</span>
              </span>
              <div style="display:flex;align-items:center;gap:4px">
                <button class="btn ghost icon-btn sm" id="mail-refresh-btn" title="Refresh">${icon("refresh")}</button>
                <button class="btn ghost icon-btn sm" id="mail-clear-btn" title="Clear Mailbox">${icon("trash")}</button>
              </div>
            </div>
            <div class="seg" id="mail-mode-seg" style="margin-top:6px;width:100%">
              <button class="active" data-mail-mode="inbox" style="flex:1">Inbox</button>
              <button data-mail-mode="mailables" style="flex:1">Mailables</button>
              <button data-mail-mode="notifications" style="flex:1">Notifications</button>
            </div>
            <div style="margin-top:8px">
              <input type="search" id="mail-search-input" class="input sm" style="width:100%" placeholder="Filter emails..." value="${esc(mailSearch)}">
            </div>
            <div id="mail-source-status" style="margin-top:6px;font-size:11px;color:var(--muted);display:flex;align-items:center;justify-content:space-between"></div>
          </div>
          <div class="mail-list" id="mail-list">
            <div style="padding:24px;text-align:center;color:var(--muted)">Checking mailbox…</div>
          </div>
        </div>

        <div class="mail-reader" id="mail-reader">
          <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);flex-direction:column;gap:8px">
            <span style="opacity:.4">${icon("mail")}</span>
            <span>Select an email from the inbox list to read it</span>
          </div>
        </div>
      </div>`;

    // Refresh & Clear
    $("#mail-refresh-btn", container)?.addEventListener("click", () => fetchAndRenderMail());

    const clearBtn = $("#mail-clear-btn", container);
    if (clearBtn) {
      clearBtn.addEventListener("click", async () => {
        if (cachedMailSource === "log") {
          toast("info", "Log emails cannot be cleared", "Emails are recorded inside storage/logs/laravel.log.");
          return;
        }

        const ids = cachedMessages.map((m) => m.id);
        if (!ids.length) {
          toast("info", "Inbox is empty");
          return;
        }

        const confirmed = await confirmModal({
          title: `Clear emails for ${site.name}?`,
          message: `Delete ${ids.length} captured email(s) for this project? This will not affect other projects in Mailpit.`,
          confirm: "Clear Project Emails",
          danger: true,
        });
        if (!confirmed) return;

        try {
          await LD.call("mail_clear", { name: site.name, ids });
          toast("success", "Project emails cleared");
          selectedMailId = null;
          messageBodies.clear();
          fetchAndRenderMail();
        } catch (err) {
          toast("error", "Couldn't clear mail", err.message);
        }
      });
    }

    const mailModeSeg = $("#mail-mode-seg", container);
    mailModeSeg?.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-mail-mode]");
      if (btn) {
        mailActiveMode = btn.dataset.mailMode;
        $$("button", mailModeSeg).forEach((b) => b.classList.toggle("active", b === btn));
        if (mailActiveMode === "mailables") {
          loadAndRenderMailables();
        } else if (mailActiveMode === "notifications") {
          loadAndRenderNotifications();
        } else {
          fetchAndRenderMail();
        }
      }
    });

    async function loadAndRenderMailables() {
      const listEl = $("#mail-list", container);
      const readerEl = $("#mail-reader", container);
      const countBadge = $("#mail-count-badge", container);
      const statusEl = $("#mail-source-status", container);
      if (!listEl || !readerEl) return;

      listEl.innerHTML = `<div class="loading-pane sm">${icon("pulse")} Scanning app/Mail…</div>`;
      if (statusEl) statusEl.innerHTML = `<span>Source: <b>app/Mail</b></span>`;

      try {
        const res = await LD.call("mailables_list", { name: site.name });
        const mailables = res.mailables || [];
        if (countBadge) countBadge.textContent = mailables.length;

        if (!mailables.length) {
          listEl.innerHTML = `<div class="muted sm" style="padding:20px;text-align:center">No Mailable classes found in app/Mail. Use Artisan Make to generate one!</div>`;
          readerEl.innerHTML = `
            <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);flex-direction:column;gap:8px">
              <span style="opacity:.4">${icon("mail")}</span>
              <span>No Mailables found in this project</span>
            </div>
          `;
          return;
        }

        listEl.innerHTML = mailables.map((m) => `
          <div class="mail-item ${m === selectedMailable ? 'active' : ''}" data-mailable="${esc(m)}" style="padding:10px 12px;cursor:pointer;border-bottom:1px solid var(--border)">
            <b style="font-family:var(--mono);font-size:12.5px;display:block">${esc(m)}</b>
            <span class="muted xs">App\\Mail\\${esc(m)}</span>
          </div>
        `).join("");

        $$("[data-mailable]", listEl).forEach((item) => {
          item.addEventListener("click", () => {
            selectMailable(item.dataset.mailable);
          });
        });

        if (mailables.length && !selectedMailable) {
          selectMailable(mailables[0]);
        }
      } catch (err) {
        listEl.innerHTML = `<div style="padding:16px;color:var(--red);font-size:12px">${esc(err.message)}</div>`;
      }
    }

    async function selectMailable(mailableName) {
      selectedMailable = mailableName;
      const listEl = $("#mail-list", container);
      const readerEl = $("#mail-reader", container);
      if (!readerEl) return;

      $$("[data-mailable]", listEl).forEach((el) => {
        el.classList.toggle("active", el.dataset.mailable === mailableName);
      });

      readerEl.innerHTML = `
        <div style="display:flex;flex-direction:column;height:100%">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid var(--border);background:var(--surface-2);flex-wrap:wrap;gap:8px">
            <div style="display:flex;align-items:center;gap:8px">
              <b style="font-family:var(--mono);font-size:13px">${esc(mailableName)}</b>
              <button class="btn ghost icon-btn xs" id="btn-open-mailable-file" title="Open in editor">${icon("code")}</button>
            </div>
            <div style="display:flex;align-items:center;gap:6px">
              <div class="seg" id="mailable-viewport-seg">
                <button class="${previewDevice === 'desktop' ? 'active' : ''}" data-device="desktop">${icon("browser")} Desktop</button>
                <button class="${previewDevice === 'mobile' ? 'active' : ''}" data-device="mobile">${icon("pulse")} Mobile (375px)</button>
              </div>
              <button class="btn sm icon-btn" id="btn-mailable-reload" title="Re-render">${icon("refresh")}</button>
            </div>
          </div>
          <div id="mailable-render-frame-wrap" style="flex:1;overflow:auto;background:var(--bg);display:flex;justify-content:center;padding:12px">
            <div class="loading-pane">${icon("pulse")} Rendering mailable HTML…</div>
          </div>
        </div>
      `;

      $("#btn-open-mailable-file", readerEl)?.addEventListener("click", () => {
        const rel = mailableName.replace(/\\/g, "/") + ".php";
        LD.call("open_file", { path: `app/Mail/${rel}` });
      });

      $("#btn-mailable-reload", readerEl)?.addEventListener("click", () => renderHtml());

      const vpSeg = $("#mailable-viewport-seg", readerEl);
      vpSeg?.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-device]");
        if (btn) {
          previewDevice = btn.dataset.device;
          $$("button", vpSeg).forEach((b) => b.classList.toggle("active", b === btn));
          const fWrap = $("#mailable-render-frame-wrap", readerEl);
          const ifr = fWrap?.querySelector("iframe");
          if (ifr) {
            ifr.style.width = previewDevice === "mobile" ? "375px" : "100%";
            ifr.style.boxShadow = previewDevice === "mobile" ? "0 4px 20px rgba(0,0,0,0.15)" : "none";
          }
        }
      });

      async function renderHtml() {
        const frameWrap = $("#mailable-render-frame-wrap", readerEl);
        if (!frameWrap) return;
        frameWrap.innerHTML = `<div class="loading-pane">${icon("pulse")} Rendering mailable HTML…</div>`;
        try {
          const res = await LD.call("mailable_render", { name: site.name, mailable: mailableName });
          if (!res.ok) throw new Error(res.error || "Failed to render mailable");

          const isMob = previewDevice === "mobile";
          frameWrap.innerHTML = `
            <iframe title="Mailable HTML preview" sandbox="allow-popups allow-popups-to-escape-sandbox" style="width:${isMob ? '375px' : '100%'};height:100%;min-height:460px;border:1px solid var(--border);border-radius:8px;background:#fff;color-scheme:light;display:block;${isMob ? 'box-shadow:0 4px 20px rgba(0,0,0,0.15);' : ''}"></iframe>
          `;
          const ifr = frameWrap.querySelector("iframe");
          if (ifr) ifr.srcdoc = prepareEmailHtml(res.html || "<p>(Empty output)</p>");
        } catch (err) {
          frameWrap.innerHTML = `
            <div class="card" style="padding:20px;color:var(--red);max-width:500px;margin:20px auto">
              <b>${icon("alert")} Render Error</b>
              <p class="muted sm" style="margin-top:6px">${esc(err.message)}</p>
            </div>
          `;
        }
      }

      renderHtml();
    }

    let selectedNotif = null;
    let selectedChannel = "mail";

    async function loadAndRenderNotifications() {
      const listEl = $("#mail-list", container);
      const readerEl = $("#mail-reader", container);
      const countBadge = $("#mail-count-badge", container);
      const statusEl = $("#mail-source-status", container);
      if (!listEl || !readerEl) return;

      listEl.innerHTML = `<div class="loading-pane sm">${icon("pulse")} Scanning app/Notifications…</div>`;
      if (statusEl) statusEl.innerHTML = `<span>Source: <b>app/Notifications</b></span>`;

      try {
        const res = await LD.call("notifications_list", { name: site.name, site_path: site.path });
        const notifs = res.notifications || [];
        if (countBadge) countBadge.textContent = notifs.length;

        if (!notifs.length) {
          listEl.innerHTML = `<div class="muted sm" style="padding:20px;text-align:center">No Notification classes found in app/Notifications.</div>`;
          readerEl.innerHTML = `
            <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);flex-direction:column;gap:8px">
              <span style="opacity:.4">${icon("bell")}</span>
              <span>No Notifications found in this project</span>
            </div>
          `;
          return;
        }

        listEl.innerHTML = notifs.map((n) => `
          <div class="mail-item ${n.name === selectedNotif?.name ? 'active' : ''}" data-notif="${esc(n.name)}" style="padding:10px 12px;cursor:pointer;border-bottom:1px solid var(--border)">
            <b style="font-family:var(--mono);font-size:12.5px;display:block">${esc(n.name)}</b>
            <div style="display:flex;gap:4px;margin-top:4px;flex-wrap:wrap">
              ${(n.channels || []).map(c => `<span class="badge sm muted" style="font-size:10px">${esc(c)}</span>`).join("")}
            </div>
          </div>
        `).join("");

        $$("[data-notif]", listEl).forEach((item) => {
          item.addEventListener("click", () => {
            const notifObj = notifs.find(x => x.name === item.dataset.notif);
            if (notifObj) selectNotification(notifObj);
          });
        });

        if (notifs.length && !selectedNotif) {
          selectNotification(notifs[0]);
        }
      } catch (err) {
        listEl.innerHTML = `<div style="padding:16px;color:var(--red);font-size:12px">${esc(err.message)}</div>`;
      }
    }

    async function selectNotification(notif) {
      selectedNotif = notif;
      selectedChannel = (notif.channels && notif.channels[0]) || "mail";
      const listEl = $("#mail-list", container);
      const readerEl = $("#mail-reader", container);
      if (!readerEl) return;

      $$("[data-notif]", listEl).forEach((el) => {
        el.classList.toggle("active", el.dataset.notif === notif.name);
      });

      async function renderChannelContent() {
        const pane = $("#notif-channel-pane", readerEl);
        if (!pane) return;
        pane.innerHTML = `<div class="loading-pane">${icon("pulse")} Generating ${selectedChannel} preview…</div>`;

        try {
          const prev = await LD.call("notification_preview", {
            name: site.name,
            site_path: site.path,
            class_name: notif.name,
            channel: selectedChannel,
          });

          if (selectedChannel === "sms") {
            pane.innerHTML = `
              <div class="sms-phone-mockup">
                <div class="sms-phone-header">
                  <div>Messages</div>
                  <b style="color:#fff;font-size:12px">${esc(prev.sender || "NOTIFICATION")}</b>
                  <div>To: ${esc(prev.to || "+1 555-0192")}</div>
                </div>
                <div class="sms-bubble">
                  ${esc(prev.message || "")}
                </div>
                <div class="sms-time">Delivered · Today</div>
                <div style="margin-top:auto;padding-top:14px;border-top:1px solid #1f2937;font-size:11px;color:#9ca3af;text-align:center">
                  ${prev.character_count} chars · ${prev.segments} SMS segment(s)
                </div>
              </div>
            `;
          } else if (selectedChannel === "slack" || selectedChannel === "webhook") {
            pane.innerHTML = `
              <div class="slack-message-card">
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
                  <img src="${esc(prev.bot_icon || '')}" width="28" height="28" style="border-radius:4px" onerror="this.style.display='none'">
                  <div>
                    <b style="font-size:13px">${esc(prev.bot_name || 'Notifier')}</b>
                    <span class="badge sm muted" style="margin-left:6px">APP</span>
                  </div>
                </div>
                <h4 style="margin:0 0 6px 0">${esc(prev.title || '')}</h4>
                <p style="margin:0;font-size:13px;line-height:1.5">${esc(prev.text || '')}</p>
                ${prev.fields ? `
                  <div class="slack-fields-grid">
                    ${prev.fields.map(f => `
                      <div>
                        <div style="font-size:11px;font-weight:600;color:var(--text-muted)">${esc(f.title)}</div>
                        <div style="font-size:12px;font-family:var(--mono)">${esc(f.value)}</div>
                      </div>
                    `).join('')}
                  </div>
                ` : ''}
              </div>
            `;
          } else if (selectedChannel === "database") {
            pane.innerHTML = `
              <div class="card" style="margin:20px auto;max-width:620px">
                <h4 style="margin:0 0 10px 0">${icon("database")} Database Record Preview</h4>
                <table class="cache-table">
                  <tr><th style="width:140px">UUID</th><td style="font-family:var(--mono);font-size:12px">${esc(prev.id)}</td></tr>
                  <tr><th>Type</th><td style="font-family:var(--mono);font-size:12px">${esc(prev.type)}</td></tr>
                  <tr><th>Notifiable</th><td style="font-family:var(--mono);font-size:12px">${esc(prev.notifiable_type)} (#${esc(String(prev.notifiable_id))})</td></tr>
                  <tr><th>Created</th><td style="font-size:12px">${esc(prev.created_at)}</td></tr>
                  <tr><th>Data JSON</th><td><pre class="cache-modal-pre" style="margin:0">${esc(JSON.stringify(prev.data, null, 2))}</pre></td></tr>
                </table>
              </div>
            `;
          } else {
            // Mail channel
            pane.innerHTML = `
              <div style="display:flex;flex-direction:column;height:100%">
                <div style="padding:10px 14px;background:var(--surface);border-bottom:1px solid var(--border);font-size:12px">
                  <div>Subject: <b>${esc(prev.subject || '')}</b></div>
                  <div class="muted" style="margin-top:2px">From: ${esc(prev.from || '')} · To: ${esc(prev.to || '')}</div>
                </div>
                <div style="flex:1;overflow:auto;display:flex;justify-content:center;padding:12px;background:var(--bg)">
                  <iframe title="Notification email preview" sandbox="allow-popups allow-popups-to-escape-sandbox" style="width:100%;max-width:620px;height:480px;border:1px solid var(--border);border-radius:8px;background:#fff;color-scheme:light;display:block"></iframe>
                </div>
              </div>
            `;
            const notifIframe = pane.querySelector("iframe");
            if (notifIframe) notifIframe.srcdoc = prepareEmailHtml(prev.html || "");
          }
        } catch (err) {
          pane.innerHTML = `<div class="card error-pane">${esc(err.message)}</div>`;
        }
      }

      readerEl.innerHTML = `
        <div style="display:flex;flex-direction:column;height:100%">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid var(--border);background:var(--surface-2);flex-wrap:wrap;gap:8px">
            <div style="display:flex;align-items:center;gap:8px">
              <b style="font-family:var(--mono);font-size:13px">${esc(notif.name)}</b>
              <button class="btn ghost icon-btn xs" id="btn-open-notif-file" title="Open in editor">${icon("code")}</button>
            </div>
            <div class="seg" id="notif-channel-seg">
              ${(notif.channels || ["mail"]).map(c => `
                <button class="${c === selectedChannel ? 'active' : ''}" data-channel="${esc(c)}">${esc(c.toUpperCase())}</button>
              `).join('')}
            </div>
          </div>
          <div id="notif-channel-pane" style="flex:1;overflow:auto;background:var(--bg)"></div>
        </div>
      `;

      $("#btn-open-notif-file", readerEl)?.addEventListener("click", () => {
        LD.call("open_file", { path: notif.relative_path || `app/Notifications/${notif.name}.php` });
      });

      const chanSeg = $("#notif-channel-seg", readerEl);
      chanSeg?.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-channel]");
        if (btn) {
          selectedChannel = btn.dataset.channel;
          $$("button", chanSeg).forEach(b => b.classList.toggle("active", b === btn));
          renderChannelContent();
        }
      });

      renderChannelContent();
    }

    // Search
    const searchInput = $("#mail-search-input", container);
    if (searchInput) {
      searchInput.addEventListener("input", () => {
        mailSearch = searchInput.value.toLowerCase().trim();
        renderMailList();
      });
    }

    // Mail selection
    const listEl = $("#mail-list", container);
    if (listEl) {
      listEl.addEventListener("click", (e) => {
        const item = e.target.closest("[data-mail-id]");
        if (item) {
          selectMail(item.dataset.mailId);
        }
      });
    }

    fetchAndRenderMail();
    poll(() => fetchAndRenderMail(true), 10000);
  }

  async function fetchAndRenderMail(isInterval = false) {
    if (!currentSite || state.drawer.tab !== "mail") return;

    try {
      const res = await LD.call("mail", { name: currentSite.name });
      cachedMessages = res.messages || [];
      cachedMailSource = res.source || "none";

      const statusEl = $("#mail-source-status");
      if (statusEl) {
        if (res.source === "mailpit") {
          statusEl.innerHTML = `
            <span class="text-green">● Mailpit</span>
            <a href="${esc(res.mailpit_url || 'http://127.0.0.1:8025')}" target="_blank" class="btn ghost sm" style="font-size:10.5px;padding:1px 5px" title="Open Mailpit Web UI in browser">
              ${icon("external")}:8025
            </a>`;
        } else {
          statusEl.innerHTML = `<span>● Zero-Config</span> <code>laravel.log</code>`;
        }
      }

      const clearBtn = $("#mail-clear-btn");
      if (clearBtn) {
        if (res.source === "log") {
          clearBtn.disabled = true;
          clearBtn.title = "Emails are part of laravel.log";
          clearBtn.style.opacity = "0.4";
        } else {
          clearBtn.disabled = false;
          clearBtn.title = "Clear project emails";
          clearBtn.style.opacity = "1";
        }
      }

      const countBadge = $("#mail-count-badge");
      if (countBadge) countBadge.innerText = cachedMessages.length;

      if (!selectedMailId && cachedMessages.length) {
        selectMail(cachedMessages[0].id);
      } else {
        renderMailList();
        renderActiveMail();
      }
    } catch (err) {
      const listEl = $("#mail-list");
      if (listEl && !isInterval) {
        listEl.innerHTML = `<div style="padding:16px;color:var(--danger)">Couldn't load mail: ${esc(err.message)}</div>`;
      }
    }
  }

  async function selectMail(id) {
    selectedMailId = id;
    renderMailList();

    const readerEl = $("#mail-reader");
    if (!readerEl) return;

    if (!messageBodies.has(id)) {
      const msgMeta = cachedMessages.find((m) => m.id === id);
      readerEl.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);gap:8px">
          ${icon("refresh", "spin")} Loading message content…
        </div>`;

      try {
        const bodyRes = await LD.call("mail_message", {
          name: currentSite.name,
          id,
          source: msgMeta?.source || "mailpit",
        });
        messageBodies.set(id, bodyRes);
        renderMailList();
      } catch (err) {
        readerEl.innerHTML = `<div style="padding:24px;color:var(--danger)">Failed to load message: ${esc(err.message)}</div>`;
        return;
      }
    }

    renderActiveMail();
  }

  function renderMailList() {
    const listEl = $("#mail-list");
    if (!listEl) return;

    const filtered = cachedMessages.filter((m) => {
      if (!mailSearch) return true;
      return (
        m.subject.toLowerCase().includes(mailSearch) ||
        m.from.toLowerCase().includes(mailSearch) ||
        m.to.toLowerCase().includes(mailSearch)
      );
    });

    if (!filtered.length) {
      listEl.innerHTML = `
        <div style="padding:28px 16px;text-align:center;color:var(--muted);font-size:12.5px">
          ${cachedMessages.length ? "No emails match your search." : "No emails captured for this project yet.<br><br><span style=\"font-size:11.5px;line-height:1.4;display:inline-block\">Emails sent via <code>MAIL_MAILER=smtp</code> (:1025) or <code>MAIL_MAILER=log</code> appear here.</span>"}
        </div>`;
      return;
    }

    listEl.innerHTML = filtered.map((m) => {
      const isActive = m.id === selectedMailId;
      const cached = messageBodies.get(m.id);
      const hasHtml = Boolean((cached?.html || m.html) && (cached?.html || m.html).trim());

      return `
        <div class="mail-item ${isActive ? "active" : ""}" data-mail-id="${esc(m.id)}">
          <div class="mail-item-subject">${esc(m.subject)}</div>
          <div class="mail-item-from">From: ${esc(m.from)}</div>
          <div style="display:flex;align-items:center;justify-content:space-between;margin-top:4px">
            <span class="mail-item-date">${esc(m.date)}</span>
            <span class="chip sm" style="font-size:10px;padding:0 4px">${hasHtml ? "HTML" : "Text"}</span>
          </div>
        </div>`;
    }).join("");
  }

  function renderActiveMail() {
    const readerEl = $("#mail-reader");
    if (!readerEl) return;

    const msgMeta = cachedMessages.find((m) => m.id === selectedMailId);
    if (!msgMeta) {
      if (!cachedMessages.length) {
        readerEl.innerHTML = `
          <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);flex-direction:column;gap:12px;padding:30px;text-align:center">
            <div style="width:48px;height:48px;border-radius:12px;background:var(--surface-2);display:grid;place-items:center;color:var(--muted)">
              ${icon("mail")}
            </div>
            <b style="color:var(--text);font-size:15px">No emails captured yet</b>
            <p style="max-width:380px;font-size:13px;line-height:1.5;margin:0">
              ${cachedMailSource === "mailpit"
                ? "Mailpit is listening on <code>127.0.0.1:1025</code>. Outgoing emails sent by your app will appear here."
                : "Mailpit captures outgoing development emails without touching real inboxes. Install Mailpit or use <code>MAIL_MAILER=log</code> in your <code>.env</code>."}
            </p>
            ${cachedMailSource !== "mailpit" ? `
              <button class="btn sm primary" id="btn-show-mailpit-info">${icon("download")}Install Mailpit</button>
            ` : ""}
          </div>`;
        const mailpitBtn = $("#btn-show-mailpit-info", readerEl);
        if (mailpitBtn) {
          mailpitBtn.addEventListener("click", () => {
            confirmModal({
              title: "Install Mailpit",
              message: "Install Mailpit via CLI with the following command:<br><br><pre style=\"background:var(--surface-2);padding:8px;border-radius:6px;font-family:var(--mono);font-size:12px\">curl -sL https://raw.githubusercontent.com/axllent/mailpit/develop/install.sh | bash</pre>Once installed, start it with <code>mailpit</code> or enable the systemd service.",
              confirm: "Got it",
            });
          });
        }
        return;
      }
      readerEl.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);flex-direction:column;gap:8px">
          <span style="opacity:.4">${icon("mail")}</span>
          <span>Select an email from the inbox list to read it</span>
        </div>`;
      return;
    }

    const bodyData = messageBodies.get(selectedMailId) || msgMeta;
    const hasHtml = Boolean(bodyData.html && bodyData.html.trim());
    const hasText = Boolean(bodyData.text && bodyData.text.trim());

    const effectiveFormat = (mailViewFormat === "html" && !hasHtml)
      ? (hasText ? "text" : "raw")
      : mailViewFormat;

    readerEl.innerHTML = `
      <div class="mail-reader-header">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
          <h3 class="mail-reader-subject">${esc(msgMeta.subject)}</h3>
          <div class="seg" id="mail-format-seg">
            ${hasHtml ? `<button type="button" class="${effectiveFormat === "html" ? "active" : ""}" data-format="html">HTML</button>` : ""}
            <button type="button" class="${effectiveFormat === "text" ? "active" : ""}" data-format="text">Text</button>
            <button type="button" class="${effectiveFormat === "raw" ? "active" : ""}" data-format="raw">Headers</button>
          </div>
        </div>

        <div class="mail-meta-grid">
          <b>From:</b> <span>${esc(msgMeta.from)}</span>
          <b>To:</b> <span>${esc(msgMeta.to)}</span>
          <b>Date:</b> <span>${esc(msgMeta.date)}</span>
        </div>
      </div>

      <div class="mail-reader-body" id="mail-body-container">
        ${effectiveFormat === "html" && hasHtml
          ? `<iframe class="mail-iframe" title="Email HTML content" sandbox="allow-popups allow-popups-to-escape-sandbox"></iframe>`
          : effectiveFormat === "text"
            ? `<pre class="mail-text-view">${esc(bodyData.text || "(No plaintext content)")}</pre>`
            : `<pre class="mail-text-view">${esc(bodyData.raw || "(No raw headers recorded)")}</pre>`
        }
      </div>`;

    if (effectiveFormat === "html" && hasHtml) {
      const mailIframe = readerEl.querySelector(".mail-iframe");
      if (mailIframe) mailIframe.srcdoc = prepareEmailHtml(bodyData.html);
    }

    const seg = $("#mail-format-seg", readerEl);
    if (seg) {
      seg.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-format]");
        if (btn) {
          mailViewFormat = btn.dataset.format;
          renderActiveMail();
        }
      });
    }
  }

  // ── 4. Queue Workers, Failed Jobs & Cron Schedule Dashboard ────────────────

  let queueSubTab = "workers"; // "workers" | "supervisor" | "schedule"
  let queuePollTimer = null;

  function mountQueue(container, site) {
    destroy();
    currentSite = site;

    container.innerHTML = `
      <div class="queue-container">
        <div class="queue-header-bar">
          <div class="seg" id="queue-subtab-seg">
            <button class="${queueSubTab === "workers" ? "active" : ""}" data-subtab="workers">${icon("layers")}Queues & Jobs</button>
            <button class="${queueSubTab === "supervisor" ? "active" : ""}" data-subtab="supervisor">${icon("settings")}Supervisor</button>
            <button class="${queueSubTab === "schedule" ? "active" : ""}" data-subtab="schedule">${icon("pulse")}Cron & Schedule</button>
          </div>
          <div style="display:flex;align-items:center;gap:6px;margin-left:auto">
            <button class="btn sm icon-btn" id="queue-refresh-btn" title="Refresh">${icon("refresh")}</button>
          </div>
        </div>

        <div id="queue-tab-content" style="margin-top:12px"></div>
      </div>`;

    // Subtab switcher
    const seg = $("#queue-subtab-seg", container);
    seg.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-subtab]");
      if (btn) {
        queueSubTab = btn.dataset.subtab;
        $$("button", seg).forEach((b) => b.classList.toggle("active", b === btn));
        renderQueueContent();
      }
    });

    $("#queue-refresh-btn", container).addEventListener("click", () => renderQueueContent());

    renderQueueContent();
    poll(() => renderQueueContent(true), () => (queueSubTab === "schedule" ? 30000 : 6000));
  }

  async function renderQueueContent(isInterval = false) {
    const content = $("#queue-tab-content");
    if (!content || !currentSite || state.drawer.tab !== "queue") return;

    if (queueSubTab === "workers") {
      await renderWorkersAndJobs(content, isInterval);
    } else if (queueSubTab === "supervisor") {
      await renderSupervisor(content, isInterval);
    } else {
      await renderScheduleList(content, isInterval);
    }
  }

  async function renderWorkersAndJobs(content, isInterval) {
    if (!isInterval) {
      content.innerHTML = `<div style="padding:28px;text-align:center;color:var(--muted)">Checking queue workers and jobs…</div>`;
    }

    try {
      const res = await LD.call("queue_status", { name: currentSite.name });
      if (!res.ok || res.error) {
        showPollError(content, { message: res.error || "Failed to query queue status" }, () => renderQueueContent());
      } else {
        clearPollError(content);
      }

      const workerRunning = Boolean(res.worker_running);
      const failed = res.failed_jobs || [];
      const pending = res.pending_jobs || [];
      const queueCounts = res.queue_counts || {};
      const devTools = res.dev_tools || currentSite.dev_tools || {};
      const hasHorizon = Boolean(devTools.horizon);
      const horizonStatus = res.horizon_status || "";

      content.innerHTML = `
        <!-- Worker status card -->
        <div class="card" data-worker-card style="margin-bottom:14px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
            <div style="display:flex;align-items:center;gap:10px">
              <span class="dot ${workerRunning ? "on" : "off"}"></span>
              <div>
                <b>Queue Worker: ${!currentSite.worker_configured ? "Not Configured" : (workerRunning ? "Running" : "Stopped")}</b>
                <div class="muted sm">${!currentSite.worker_configured ? "Keep <code>queue:work</code> running in background with Supervisor" : "Managed via Supervisor & artisan queue:work"}</div>
              </div>
            </div>
            <div class="btn-row">
              ${!currentSite.worker_configured
                ? `<button class="btn sm primary" data-worker-setup>${icon("layers")}Set up worker</button>`
                : (workerRunning
                    ? `<button class="btn sm" data-worker-act="restart">${icon("refresh")}Restart Worker</button>
                       <button class="btn sm danger" data-worker-act="stop">${icon("stop")}Stop</button>`
                    : `<button class="btn sm primary" data-worker-act="start">${icon("play")}Start Worker</button>`)}
            </div>
          </div>
          ${hasHorizon ? `
            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);flex-wrap:wrap;gap:8px">
              <div style="display:flex;align-items:center;gap:8px">
                <span class="muted sm" style="font-weight:600">Horizon:</span>
                <span class="chip sm ${horizonStatus === "running" ? "ok" : (horizonStatus === "paused" ? "warn" : "danger")}">${esc(horizonStatus || "inactive")}</span>
              </div>
              <button class="btn sm ghost" data-open-url="${esc(currentSite.url)}/horizon">${icon("browser")}Open /horizon</button>
            </div>
          ` : ""}
        </div>

        <!-- Failed Jobs Section -->
        <div class="queue-section" style="margin-bottom:16px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
            <h3 style="margin:0;display:flex;align-items:center;gap:8px;font-size:14px">
              ${icon("alert")}Failed Jobs
              <span class="chip sm ${failed.length ? "danger" : ""}" id="badge-failed-count">${failed.length}</span>
            </h3>
            ${failed.length ? `
              <div class="btn-row">
                <button class="btn sm" id="btn-retry-all">${icon("refresh")}Retry All</button>
                <button class="btn sm danger" id="btn-flush-all">${icon("trash")}Flush All</button>
              </div>` : ""}
          </div>

          ${(!res.ok || res.error)
            ? `<div class="card" style="text-align:center;padding:24px;border-color:rgba(239,68,68,0.25)">
                 <span class="text-red" style="display:inline-block;margin-bottom:6px">${icon("alert")}</span>
                 <p style="margin:0;font-weight:600;color:var(--danger)">Couldn't retrieve failed jobs</p>
                 <div class="muted sm" style="margin-top:4px">${esc(res.error || "Database or queue table unreachable")}</div>
               </div>`
            : !failed.length
              ? `<div class="card" style="text-align:center;padding:24px;color:var(--muted)">
                   <span class="text-green" style="display:inline-block;margin-bottom:6px">${icon("check")}</span>
                   <p style="margin:0">No failed jobs. Your queue pipeline is completely healthy!</p>
                 </div>`
              : `<div class="queue-jobs-list">
                 ${failed.map((j) => `
                   <div class="job-card failed" data-job-id="${esc(j.id)}">
                     <div class="job-card-header">
                       <span class="job-class">${esc(j.class)}</span>
                       <span class="chip sm" style="font-family:var(--mono)">${esc(j.queue)}</span>
                       <span class="chip sm muted">${esc(j.connection)}</span>
                       <span class="muted sm" style="margin-left:auto;font-family:var(--mono)">${esc(j.failed_at)}</span>
                       <div class="btn-row" style="margin-left:8px">
                         <button class="btn sm ghost" data-job-retry="${esc(j.id)}" title="Retry Job">${icon("refresh")}Retry</button>
                         <button class="btn sm ghost danger" data-job-forget="${esc(j.id)}" title="Delete">${icon("trash")}</button>
                       </div>
                     </div>
                     ${j.exception_short ? `<div class="job-error-msg">${esc(j.exception_short)}</div>` : ""}
                     <div style="display:flex;align-items:center;gap:6px;margin-top:6px;flex-wrap:wrap">
                       ${j.exception ? `
                         <button class="btn sm ghost" data-toggle-job-trace="${esc(j.id)}">${icon("code")}Stack Trace</button>
                         <button class="btn sm ghost icon-btn" data-copy-job-trace="${esc(j.id)}" title="Copy Trace">${icon("copy")}</button>
                       ` : ""}
                       ${j.payload ? `
                         <button class="btn sm ghost" data-toggle-job-payload="${esc(j.id)}">${icon("database")}Payload</button>
                       ` : ""}
                     </div>
                     ${j.exception ? `<pre class="job-trace-pre" id="job-trace-${esc(j.id)}" hidden>${esc(j.exception)}</pre>` : ""}
                     ${j.payload ? `<pre class="job-trace-pre" id="job-payload-${esc(j.id)}" style="background:var(--surface-2);color:var(--text);border-color:var(--border)" hidden>${esc(JSON.stringify(j.payload, null, 2))}</pre>` : ""}
                   </div>`).join("")}
               </div>`}
        </div>

        <!-- Pending Jobs Section -->
        <div class="queue-section">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
            <h3 style="margin:0;display:flex;align-items:center;gap:8px;font-size:14px">
              ${icon("layers")}Pending Jobs
              <span class="chip sm">${pending.length}</span>
              ${Object.entries(queueCounts).map(([q, cnt]) => `<span class="chip sm muted" title="Queue: ${esc(q)}">${esc(q)}: ${cnt}</span>`).join(" ")}
            </h3>
            ${pending.length ? `
              <button class="btn sm ghost danger" id="btn-clear-pending">${icon("trash")}Clear All Pending</button>
            ` : ""}
          </div>
          ${!pending.length
            ? `<div class="card" style="text-align:center;padding:20px;color:var(--muted)">
                 No pending jobs in database queue table.
               </div>`
            : `<div class="queue-jobs-list">
                 ${pending.map((p) => `
                   <div class="job-card pending">
                     <div class="job-card-header">
                       <span class="job-class">${esc(p.class)}</span>
                       <span class="chip sm">${esc(p.queue)}</span>
                       <span class="chip sm muted">Attempts: ${p.attempts}</span>
                       <span class="muted sm" style="margin-left:auto">${esc(p.created_at || p.available_at)}</span>
                       ${p.payload ? `<button class="btn sm ghost" data-toggle-job-payload="pending-${esc(p.id)}" style="margin-left:8px">${icon("database")}Payload</button>` : ""}
                     </div>
                     ${p.payload ? `<pre class="job-trace-pre" id="job-payload-pending-${esc(p.id)}" style="background:var(--surface-2);color:var(--text);border-color:var(--border)" hidden>${esc(JSON.stringify(p.payload, null, 2))}</pre>` : ""}
                   </div>`).join("")}
               </div>`}
        </div>`;

      // Event handlers for workers
      const setupBtn = $("[data-worker-setup]", content);
      if (setupBtn) {
        setupBtn.addEventListener("click", async () => {
          setupBtn.disabled = true;
          try {
            await runAction("worker-setup", { name: currentSite.name, php: currentSite.php || "" });
            toast("info", "Setting up worker…");
          } catch (err) {
            setupBtn.disabled = false;
            toast("error", "Couldn't set up worker", err.message);
          }
        });
      }

      $$("[data-worker-act]", content).forEach((btn) => {
        btn.addEventListener("click", async () => {
          const op = btn.dataset.workerAct;
          btn.disabled = true;
          try {
            await runAction("worker", { name: currentSite.name, op }, { show: false });
            toast("success", `Worker ${op} requested`);
            setTimeout(() => renderQueueContent(), 800);
          } catch (err) {
            toast("error", "Worker action failed", err.message);
          }
        });
      });

      // Retry all
      const retryAllBtn = $("#btn-retry-all", content);
      if (retryAllBtn) {
        retryAllBtn.addEventListener("click", async () => {
          if (!(await confirmModal({ title: "Retry all failed jobs?", message: "Every failed job will be pushed back onto the queue for execution.", confirm: "Retry All" }))) return;
          retryAllBtn.disabled = true;
          const ret = await LD.call("queue_retry", { name: currentSite.name, id: "all" });
          toast("success", ret.output || "All failed jobs retried");
          renderQueueContent();
        });
      }

      // Flush all
      const flushAllBtn = $("#btn-flush-all", content);
      if (flushAllBtn) {
        flushAllBtn.addEventListener("click", async () => {
          if (!(await confirmModal({ title: "Delete all failed jobs?", message: "This permanently deletes all failed jobs from the failed_jobs table.", confirm: "Delete All", danger: true }))) return;
          flushAllBtn.disabled = true;
          const ret = await LD.call("queue_forget", { name: currentSite.name, id: "all" });
          toast("success", ret.output || "All failed jobs flushed");
          renderQueueContent();
        });
      }

      // Clear all pending
      const clearPendingBtn = $("#btn-clear-pending", content);
      if (clearPendingBtn) {
        clearPendingBtn.addEventListener("click", async () => {
          if (!(await confirmModal({ title: "Clear pending queue jobs?", message: "This will remove all pending jobs currently in the database queue.", confirm: "Clear Pending", danger: true }))) return;
          clearPendingBtn.disabled = true;
          const ret = await LD.call("queue_delete_pending", { name: currentSite.name, id: "all" });
          toast("success", ret.output || "Pending jobs cleared");
          renderQueueContent();
        });
      }

      // Single job retry & delete
      content.addEventListener("click", async (e) => {
        const retryBtn = e.target.closest("[data-job-retry]");
        if (retryBtn) {
          const id = retryBtn.dataset.jobRetry;
          retryBtn.disabled = true;
          const ret = await LD.call("queue_retry", { name: currentSite.name, id });
          toast("success", ret.output || `Job #${id} retried`);
          renderQueueContent();
          return;
        }

        const forgetBtn = e.target.closest("[data-job-forget]");
        if (forgetBtn) {
          const id = forgetBtn.dataset.jobForget;
          if (!(await confirmModal({ title: "Delete failed job?", message: `Permanently delete failed job #${id}?`, confirm: "Delete", danger: true }))) return;
          forgetBtn.disabled = true;
          const ret = await LD.call("queue_forget", { name: currentSite.name, id });
          toast("success", ret.output || `Job #${id} deleted`);
          renderQueueContent();
          return;
        }

        const toggleTraceBtn = e.target.closest("[data-toggle-job-trace]");
        if (toggleTraceBtn) {
          const id = toggleTraceBtn.dataset.toggleJobTrace;
          const traceEl = $(`#job-trace-${CSS.escape(id)}`, content);
          if (traceEl) {
            traceEl.hidden = !traceEl.hidden;
            toggleTraceBtn.innerText = traceEl.hidden ? "Stack Trace" : "Hide Trace";
          }
          return;
        }

        const togglePayloadBtn = e.target.closest("[data-toggle-job-payload]");
        if (togglePayloadBtn) {
          const id = togglePayloadBtn.dataset.toggleJobPayload;
          const payloadEl = $(`#job-payload-${CSS.escape(id)}`, content);
          if (payloadEl) {
            payloadEl.hidden = !payloadEl.hidden;
            togglePayloadBtn.innerText = payloadEl.hidden ? "Payload" : "Hide Payload";
          }
          return;
        }

        const copyTraceBtn = e.target.closest("[data-copy-job-trace]");
        if (copyTraceBtn) {
          const id = copyTraceBtn.dataset.copyJobTrace;
          const traceEl = $(`#job-trace-${CSS.escape(id)}`, content);
          if (traceEl) {
            navigator.clipboard?.writeText(traceEl.innerText);
            toast("success", "Stack trace copied");
          }
        }
      });

    } catch (err) {
      content.innerHTML = `<div style="padding:20px;color:var(--danger)">Couldn't load queue status: ${esc(err.message)}</div>`;
    }
  }

  async function renderScheduleList(content, isInterval) {
    if (!isInterval) {
      content.innerHTML = `<div style="padding:28px;text-align:center;color:var(--muted)">Inspecting scheduled tasks…</div>`;
    }

    try {
      const res = await LD.call("schedule_list", { name: currentSite.name });
      if (!res.ok || res.error) {
        showPollError(content, { message: res.error || "Failed to load schedule" }, () => renderScheduleList(content));
      } else {
        clearPollError(content);
      }

      const tasks = res.tasks || [];
      const logOpen = Boolean($("#scheduler-log", content) && !$("#scheduler-log", content).hidden);

      content.innerHTML = `
        ${schedulerCard(currentSite)}
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
          <div>
            <h3 style="margin:0;display:flex;align-items:center;gap:8px;font-size:14px">
              ${icon("pulse")}Scheduled Tasks
              <span class="chip sm">${tasks.length}</span>
            </h3>
            <span class="muted sm">Defined in routes/console.php or app/Console/Kernel.php</span>
          </div>
          <button class="btn sm primary" id="btn-run-all-due">${icon("play")}Run Due (schedule:run)</button>
        </div>

        ${(!res.ok || res.error)
          ? `<div class="card" style="text-align:center;padding:24px;border-color:rgba(239,68,68,0.25)">
               <span class="text-red" style="display:inline-block;margin-bottom:6px">${icon("alert")}</span>
               <p style="margin:0;font-weight:600;color:var(--danger)">Couldn't retrieve scheduled tasks</p>
               <div class="muted sm" style="margin-top:4px">${esc(res.error || "Failed to load Laravel schedule")}</div>
             </div>`
          : !tasks.length
            ? `<div class="card" style="text-align:center;padding:28px;color:var(--muted)">
                 No scheduled tasks found for this project.
               </div>`
            : `<div class="schedule-table-wrap">
                 <table class="schedule-table">
                   <thead>
                     <tr>
                       <th>Cron</th>
                       <th>Task</th>
                       <th>Last Run</th>
                       <th>Next Due</th>
                       <th style="text-align:right">Action</th>
                     </tr>
                   </thead>
                   <tbody>
                     ${tasks.map((t) => `
                       <tr>
                         <td><code class="schedule-cron">${esc(t.cron || t.expression || "")}</code></td>
                         <td>
                           <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                             <span class="chip sm ${t.type === 'job' ? 'php' : t.type === 'closure' ? 'muted' : 'info'}">${esc(t.type || 'command')}</span>
                             <b class="schedule-cmd">${esc(t.command)}</b>
                             ${t.without_overlapping ? `<span class="chip sm warn" title="Without overlapping enabled">mutex</span>` : ""}
                           </div>
                           ${t.description && t.description !== t.command ? `<div class="muted sm" style="margin-top:2px">${esc(t.description)}</div>` : ""}
                         </td>
                         <td>
                           ${t.last_run
                             ? t.last_run.status === "DONE"
                               ? `<span class="chip sm" style="color:var(--green)">${icon("check")}${esc(t.last_run.duration)}</span>`
                               : `<span class="chip sm" style="color:var(--red)" title="Failed during last run: ${esc(t.last_run.time)}">${icon("alert")}FAIL (${esc(t.last_run.duration)})</span>`
                             : `<span class="muted sm">—</span>`}
                         </td>
                         <td><span class="chip sm" style="font-size:11px">${esc(t.next_due || "Scheduled")}</span></td>
                         <td style="text-align:right">
                           ${t.can_run === false
                             ? `<button class="btn sm ghost" disabled title="${esc(t.run_reason || "Cannot run task")}">${icon("play")}Run Now</button>`
                             : `<button class="btn sm ghost" data-run-index="${t.index !== undefined ? t.index : ''}" data-run-cmd="${esc(t.command)}" data-run-desc="${esc(t.description || t.command)}" title="Execute task now">${icon("play")}Run Now</button>`}
                         </td>
                       </tr>`).join("")}
                   </tbody>
                 </table>
               </div>`}

        <div id="schedule-run-result" style="margin-top:14px" hidden>
          <div class="card">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
              <b>Execution Result</b>
              <span id="schedule-run-time" class="chip sm"></span>
            </div>
            <pre id="schedule-run-output" style="margin:0;padding:10px;background:var(--surface-2);border-radius:6px;max-height:250px;overflow:auto;font-family:var(--mono);font-size:12px"></pre>
          </div>
        </div>`;

      bindSchedulerCard(content, logOpen);

      // Run all due
      const runAllDueBtn = $("#btn-run-all-due", content);
      if (runAllDueBtn) {
        runAllDueBtn.addEventListener("click", () => executeScheduleTask("schedule:run", null, "schedule:run"));
      }

      // Run specific command
      $$("[data-run-index]", content).forEach((btn) => {
        btn.addEventListener("click", () => {
          const idx = btn.dataset.runIndex;
          const cmd = btn.dataset.runCmd;
          const desc = btn.dataset.runDesc;
          executeScheduleTask(cmd, idx, desc);
        });
      });

      async function executeScheduleTask(cmd, index = null, desc = "") {
        const resultPane = $("#schedule-run-result", content);
        const timeEl = $("#schedule-run-time", content);
        const outEl = $("#schedule-run-output", content);

        resultPane.hidden = false;
        timeEl.innerText = "Starting…";
        outEl.innerText = `Dispatching task: ${desc || cmd}…\nCheck Activity drawer for live log output.`;

        try {
          const task = await runAction("schedule-run", {
            name: currentSite.name,
            command: cmd,
            index: index !== null && index !== undefined && index !== "" ? Number(index) : null,
            description: desc || cmd
          }, { show: false });

          if (task) {
            timeEl.innerText = "Task running";
            outEl.innerText = `Task started (ID: ${task.id}).\nExecuting ${desc || cmd} in background.\nTrack real-time output in the Activity drawer.`;
            toast("info", `Running ${desc || cmd}`);
          }
        } catch (err) {
          timeEl.innerText = "Failed";
          outEl.innerText = err.message;
          toast("error", "Execution failed", err.message);
        }
      }

    } catch (err) {
      showPollError(content, err, () => renderScheduleList(content));
    }
  }

  // ── Scheduler: the cron entry that runs schedule:run every minute ─────────

  function schedulerCard(site) {
    if (!managed()) {
      return `<div class="card" style="margin-bottom:14px"><p class="muted" style="margin:0">
        The cron scheduler is managed on Linux only. Here, run <code>php artisan schedule:work</code> in a terminal.</p></div>`;
    }
    const sch = site.scheduler || {};
    const serviceDown = sch.enabled && sch.service !== "active";
    return `
      <div class="card" style="margin-bottom:14px">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
          <div style="display:flex;align-items:center;gap:10px">
            <span class="dot ${sch.enabled && !serviceDown ? "on" : "off"}"></span>
            <div>
              <b>Scheduler: ${sch.enabled ? "Enabled" : "Disabled"}</b>
              <div class="muted sm">${sch.enabled
                ? "Cron runs <code>php artisan schedule:run</code> every minute"
                : "Scheduled tasks only run when you press Run. Enable to add a cron entry."}</div>
            </div>
          </div>
          <div class="btn-row">
            <button class="btn sm ghost" data-scheduler-log>${icon("terminal")}Output</button>
            ${sch.enabled
              ? `<button class="btn sm danger" data-scheduler="disable">${icon("stop")}Disable</button>`
              : `<button class="btn sm primary" data-scheduler="enable">${icon("play")}Enable cron</button>`}
            <button class="btn sm" data-run-schedule-work="${esc(site.name)}" title="Run schedule:work via Supervisor">${icon("layers")}Run with Supervisor (schedule:work)</button>
          </div>
        </div>
        ${serviceDown ? `<p class="muted sm" style="margin:10px 0 0;color:var(--danger)">The cron service is ${esc(sch.service || "not running")}, so nothing will fire.
          <button class="btn sm" data-scheduler-service>Start cron</button></p>` : ""}
        <pre id="scheduler-log" class="ld-log-tail" hidden></pre>
      </div>`;
  }

  async function loadTail(method, el, emptyText) {
    try {
      const res = await LD.call(method, { name: currentSite.name });
      el.textContent = res.exists && res.text.trim() ? res.text : emptyText;
      el.scrollTop = el.scrollHeight;
    } catch (err) {
      el.textContent = err.message;
    }
  }

  function bindSchedulerCard(content, logOpen) {
    const logEl = $("#scheduler-log", content);
    const showLog = () => {
      logEl.hidden = false;
      loadTail("scheduler_log", logEl, "No scheduler output yet. It appears here after the first minute with cron enabled.");
    };
    if (logEl && logOpen) showLog();
    $("[data-scheduler-log]", content)?.addEventListener("click", () => (logEl.hidden ? showLog() : (logEl.hidden = true)));
    $("[data-scheduler]", content)?.addEventListener("click", (e) => {
      runAction("cron", { name: currentSite.name, op: e.currentTarget.dataset.scheduler }, { show: false });
    });
    $("[data-scheduler-service]", content)?.addEventListener("click", () => {
      runAction("service", { unit: currentSite.scheduler?.unit || "cron", op: "start" }, { show: false });
    });
    $("[data-run-schedule-work]", content)?.addEventListener("click", async () => {
      const phpBin = currentSite.php ? `php${currentSite.php}` : "php";
      await runAction("supervisor-create", {
        name: currentSite.name,
        program: "schedule",
        command: `${phpBin} ${currentSite.path}/artisan schedule:work`,
        numprocs: 1,
      });
      toast("success", "Created supervisor program: schedule:work");
    });
  }

  // ── Supervisor: worker program settings and output ───────────────────────

  async function renderSupervisor(content, isInterval) {
    const site = currentSite;
    if (!managed()) {
      content.innerHTML = `<div class="card"><p class="muted" style="margin:0">Supervisor is managed on Linux only. Here, run <code>php artisan queue:work</code> in a terminal.</p></div>`;
      return;
    }

    if (isInterval && $("#worker-settings-form", content)) {
      // Don't wipe forms during periodic background refresh
      return;
    }

    let programs = [];
    try {
      programs = await LD.call("supervisor_programs", { name: site.name });
    } catch {}

    const ws = site.worker_settings || {};
    const horizon = ws.effective_mode === "horizon";

    const programsHtml = programs.map((p) => {
      const active = p.status === "running";
      const isMainWorker = p.name === "worker";
      const displayName = isMainWorker ? (horizon ? "Horizon" : "Queue Worker") : p.name;
      return `
        <div class="card" style="margin-bottom:12px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
            <div style="display:flex;align-items:center;gap:10px">
              <span class="dot ${active ? "on" : "off"}"></span>
              <div>
                <div style="display:flex;align-items:center;gap:6px">
                  <b>${esc(displayName)}: ${active ? "Running" : "Stopped"}</b>
                  ${p.is_root ? `<span class="chip sm warn" title="Worker runs as root. Files created in storage/ will belong to root.">${icon("alert")} Runs as root</span>` : ""}
                </div>
                <div class="muted sm" style="font-family:var(--mono)">${esc(p.command || "")}</div>
              </div>
            </div>
            <div class="btn-row">
              ${p.is_root ? `<button class="btn sm warn" data-sv-recreate-worker title="Recreate supervisor configuration with standard user permissions">${icon("wrench")}Recreate</button>` : ""}
              ${active
                ? `<button class="btn sm" data-sv-prog-op="${esc(p.name)}" data-op="restart">${icon("refresh")}Restart</button>
                   <button class="btn sm danger" data-sv-prog-op="${esc(p.name)}" data-op="stop">${icon("stop")}Stop</button>`
                : `<button class="btn sm primary" data-sv-prog-op="${esc(p.name)}" data-op="start">${icon("play")}Start</button>`}
              ${!isMainWorker
                ? `<button class="btn sm ghost danger" data-sv-prog-remove="${esc(p.name)}" title="Remove supervisor program">${icon("trash")}</button>`
                : ""}
            </div>
          </div>
          <details style="margin-top:10px">
            <summary class="muted sm" style="cursor:pointer">Output (${esc(p.log)})</summary>
            <pre id="sv-log-${esc(p.name)}" class="ld-log-tail" style="margin-top:6px">Loading…</pre>
          </details>
        </div>
      `;
    }).join("");

    const phpBin = site.php ? `php${site.php}` : "php";

    content.innerHTML = `
      ${programsHtml || `
        <div class="card" style="margin-bottom:14px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
            <div style="display:flex;align-items:center;gap:10px">
              <span class="dot off"></span>
              <div>
                <b>Queue Worker: Not configured</b>
                <div class="muted sm">Supervisor keeps your background workers running.</div>
              </div>
            </div>
            <button class="btn sm primary" data-sv-setup>${icon("layers")}Set up worker</button>
          </div>
        </div>
      `}

      <form class="card" id="add-sv-program-form" style="margin-bottom:14px">
        <h3 style="margin:0 0 10px">${icon("plus")}Add Supervisor Program</h3>
        <div class="worker-grid">
          <label>Preset
            <select id="sv-preset-select">
              <option value="custom">Custom Command</option>
              <option value="schedule">Schedule Worker (schedule:work)</option>
              <option value="reverb">Reverb WebSocket (reverb:start)</option>
              <option value="pulse">Pulse Monitor (pulse:check)</option>
            </select>
          </label>
          <label>Program Name
            <input name="program" id="sv-prog-name" placeholder="e.g. schedule, reverb" required spellcheck="false">
          </label>
          <label style="grid-column:span 2">Artisan Command
            <input name="command" id="sv-prog-cmd" placeholder="e.g. ${phpBin} ${esc(site.path)}/artisan schedule:work" required spellcheck="false">
          </label>
          <label>Processes
            <input name="numprocs" type="number" min="1" max="10" value="1">
          </label>
        </div>
        <div style="display:flex;align-items:center;justify-content:flex-end;margin-top:12px">
          <button class="btn sm primary" type="submit">${icon("plus")}Create Program</button>
        </div>
      </form>

      <form class="card" id="worker-settings-form" style="margin-bottom:14px">
        <h3 style="margin:0 0 10px">${icon("settings")}Queue Worker Settings</h3>
        <div class="worker-grid">
          <label>Mode
            <select name="mode">
              <option value="auto" ${!ws.mode ? "selected" : ""}>Auto (${ws.has_horizon ? "Horizon" : "queue:work"})</option>
              <option value="queue" ${ws.mode === "queue" ? "selected" : ""}>queue:work</option>
              <option value="horizon" ${ws.mode === "horizon" ? "selected" : ""} ${ws.has_horizon ? "" : "disabled"}>Horizon${ws.has_horizon ? "" : " (not installed)"}</option>
            </select>
          </label>
          <label data-queue-only>Queues <input name="queues" value="${esc(ws.queues || "default")}" placeholder="high,default" spellcheck="false"></label>
          <label data-queue-only>Processes <input name="processes" type="number" min="1" max="20" value="${esc(ws.processes || "1")}"></label>
          <label data-queue-only>Tries <input name="tries" type="number" min="0" max="999" value="${esc(ws.tries || "3")}"></label>
          <label data-queue-only>Timeout (s) <input name="timeout" type="number" min="0" max="99999" value="${esc(ws.timeout || "90")}"></label>
          <label data-queue-only>Sleep (s) <input name="sleep" type="number" min="0" max="999" value="${esc(ws.sleep || "3")}"></label>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:12px;flex-wrap:wrap">
          <span class="muted sm">${site.worker_configured ? "Saving rewrites the Supervisor queue program and restarts it." : "Saved now, applied when worker starts."}</span>
          <button class="btn sm primary" type="submit">${icon("check")}Save Worker Settings</button>
        </div>
      </form>
    `;

    const form = $("#worker-settings-form", content);
    if (form) {
      const syncMode = () => {
        const mode = form.mode.value === "auto" ? (ws.has_horizon ? "horizon" : "queue") : form.mode.value;
        $$("[data-queue-only]", form).forEach((el) => { el.hidden = mode === "horizon"; });
      };
      form.mode.addEventListener("change", syncMode);
      syncMode();
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(form));
        runAction("worker-config", { name: site.name, ...data }, { show: false });
      });
    }

    const presetSelect = $("#sv-preset-select", content);
    const progNameInput = $("#sv-prog-name", content);
    const progCmdInput = $("#sv-prog-cmd", content);

    const presets = {
      schedule: { name: "schedule", cmd: `${phpBin} ${site.path}/artisan schedule:work` },
      reverb: { name: "reverb", cmd: `${phpBin} ${site.path}/artisan reverb:start` },
      pulse: { name: "pulse", cmd: `${phpBin} ${site.path}/artisan pulse:check` },
      custom: { name: "", cmd: `${phpBin} ${site.path}/artisan ` },
    };

    presetSelect?.addEventListener("change", () => {
      const p = presets[presetSelect.value];
      if (p) {
        progNameInput.value = p.name;
        progCmdInput.value = p.cmd;
      }
    });

    $("#add-sv-program-form", content)?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const addForm = e.target;
      const prog = addForm.elements.program.value.trim();
      const cmd = addForm.elements.command.value.trim();
      const num = addForm.elements.numprocs.value.trim();
      if (!prog || !cmd) return;
      await runAction("supervisor-create", { name: site.name, program: prog, command: cmd, numprocs: num });
      setTimeout(() => renderSupervisor(content, false), 1500);
    });

    $("[data-sv-setup]", content)?.addEventListener("click", () => runAction("worker-setup", { name: site.name }));
    $$("[data-sv-recreate-worker]", content).forEach((btn) => {
      btn.addEventListener("click", () => runAction("worker-setup", { name: site.name, php: site.php || "" }));
    });

    $$("[data-sv-prog-op]", content).forEach((btn) => {
      btn.addEventListener("click", async () => {
        const prog = btn.dataset.svProgOp;
        const op = btn.dataset.op;
        await runAction("supervisor-program", { name: site.name, program: prog, op });
        setTimeout(() => renderSupervisor(content, false), 1500);
      });
    });

    $$("[data-sv-prog-remove]", content).forEach((btn) => {
      btn.addEventListener("click", async () => {
        const prog = btn.dataset.svProgRemove;
        if (!(await confirmModal({ title: `Remove supervisor program ${prog}?`, message: "This stops the process and deletes the supervisor config file.", confirm: "Remove", danger: true }))) return;
        await runAction("supervisor-program", { name: site.name, program: prog, op: "remove" });
        setTimeout(() => renderSupervisor(content, false), 1500);
      });
    });

    // Load logs for all programs
    programs.forEach((p) => {
      const el = $(`#sv-log-${p.name}`, content);
      if (el) {
        LD.call("supervisor_program_log", { name: site.name, program: p.name }).then((res) => {
          el.textContent = res.exists && res.text ? res.text : "No output recorded yet.";
        }).catch(() => { el.textContent = "Could not load log."; });
      }
    });
  }

  // ── 5. One-Click Deploy, Server Health & Backups Engine ───────────────────

  let deploySubTab = "deploy"; // "deploy" | "backups"

  function mountDeploy(container, site) {
    destroy();
    currentSite = site;

    container.innerHTML = `
      <div class="deploy-container">
        <div class="deploy-header-bar">
          <div class="seg" id="deploy-subtab-seg">
            <button class="${deploySubTab === "deploy" ? "active" : ""}" data-subtab="deploy">${icon("rocket")}Deploy & Health</button>
            <button class="${deploySubTab === "cloud" ? "active" : ""}" data-subtab="cloud">${icon("cloud")}Laravel Cloud</button>
            <button class="${deploySubTab === "backups" ? "active" : ""}" data-subtab="backups">${icon("download")}Backups & Snapshots</button>
          </div>
          <div style="display:flex;align-items:center;gap:6px;margin-left:auto">
            <button class="btn sm icon-btn" id="deploy-refresh-btn" title="Refresh">${icon("refresh")}</button>
          </div>
        </div>

        <div id="deploy-tab-content" style="margin-top:12px"></div>
      </div>`;

    const seg = $("#deploy-subtab-seg", container);
    seg.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-subtab]");
      if (btn) {
        deploySubTab = btn.dataset.subtab;
        $$("button", seg).forEach((b) => b.classList.toggle("active", b === btn));
        renderDeployContent();
      }
    });

    $("#deploy-refresh-btn", container).addEventListener("click", () => renderDeployContent());

    renderDeployContent();
  }

  async function renderDeployContent() {
    const content = $("#deploy-tab-content");
    if (!content || !currentSite || state.drawer.tab !== "deploy") return;

    if (deploySubTab === "deploy") {
      await renderDeployTargetAndHealth(content);
    } else if (deploySubTab === "cloud") {
      await renderCloudDeploy(content);
    } else {
      await renderBackupsList(content);
    }
  }

  async function renderCloudDeploy(content) {
    content.innerHTML = `<div style="padding:28px;text-align:center;color:var(--muted)">Checking Laravel Cloud status…</div>`;
    try {
      const res = await LD.call("cloud_status", { name: currentSite.name });
      const cli = res?.cli || {};
      const proj = res?.project || {};

      const isCli = !!cli.installed;
      const isAuth = !!cli.authenticated;
      const appName = proj.app_name || currentSite.name;
      const envName = proj.environment || "production";
      const liveUrl = proj.url || `https://${appName}.laravel.cloud`;

      content.innerHTML = `
        <div class="card mb-md" style="border-left:4px solid var(--accent)">
          <div class="flex-between mb-sm">
            <h3 style="margin:0;display:flex;align-items:center;gap:8px;font-size:14px">
              ${icon("cloud")} Laravel Cloud Integration
            </h3>
            <span class="chip sm ${isCli ? 'ok' : 'muted'}">${isCli ? 'CLI Ready' : 'CLI Not Installed'}</span>
          </div>
          <p class="muted sm" style="margin:0 0 12px">
            Deploy your Laravel application directly to managed Laravel Cloud infrastructure with automatic Prepare, Build, and Release pipeline execution.
          </p>
          <div style="display:flex;gap:12px;flex-wrap:wrap;font-size:13px;background:var(--bg);padding:10px 14px;border-radius:8px;border:1px solid var(--border)">
            <div><b>CLI:</b> <code>${esc(cli.version || 'not found')}</code></div>
            <div><b>Account:</b> <span class="chip sm ${isAuth ? 'ok' : 'muted'}">${esc(cli.user || (isAuth ? 'Authenticated' : 'Not signed in'))}</span></div>
            <div><b>Project:</b> <b>${esc(appName)}</b></div>
            <div><b>Target URL:</b> <a href="${esc(liveUrl)}" target="_blank" class="link">${esc(liveUrl)}</a></div>
          </div>
        </div>

        <div class="card mb-md">
          <div class="flex-between mb-sm">
            <h3 style="margin:0;font-size:14px">${icon("rocket")} 3-Stage Deployment Pipeline</h3>
            <div style="display:flex;gap:8px;align-items:center">
              <select id="cloud-env-select" class="input sm" style="width:130px">
                <option value="production" ${envName === 'production' ? 'selected' : ''}>Production</option>
                <option value="staging" ${envName === 'staging' ? 'selected' : ''}>Staging</option>
              </select>
              <button class="btn primary sm" id="btn-cloud-deploy">${icon("rocket")} Deploy to Cloud</button>
            </div>
          </div>

          <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:12px;margin:16px 0" id="cloud-pipeline-steps">
            <div class="cloud-stage-box" id="stage-prepare" style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <span style="font-weight:600;font-size:13px">1. Prepare</span>
                <span class="chip sm muted stage-badge">Ready</span>
              </div>
              <p class="muted xs" style="margin:0">Preflight checks, composer validate & Git status</p>
            </div>
            <div class="cloud-stage-box" id="stage-build" style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <span style="font-weight:600;font-size:13px">2. Build</span>
                <span class="chip sm muted stage-badge">Pending</span>
              </div>
              <p class="muted xs" style="margin:0">Packaging, asset compilation & container build</p>
            </div>
            <div class="cloud-stage-box" id="stage-release" style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <span style="font-weight:600;font-size:13px">3. Release</span>
                <span class="chip sm muted stage-badge">Pending</span>
              </div>
              <p class="muted xs" style="margin:0">Database migrations, cache warm-up & traffic swap</p>
            </div>
          </div>

          <div id="cloud-result-banner" style="display:none;margin-top:12px;padding:12px 16px;border-radius:8px;background:rgba(34,197,94,0.1);border:1px solid #22c55e">
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
              <div>
                <b style="color:#22c55e;display:flex;align-items:center;gap:6px">${icon("check")} Successfully Deployed!</b>
                <span class="sm">Your app is live at <a href="${esc(liveUrl)}" id="cloud-live-link" target="_blank" class="link" style="font-weight:600">${esc(liveUrl)}</a></span>
              </div>
              <div style="display:flex;gap:6px">
                <button class="btn sm" id="btn-copy-cloud-url">${icon("copy")} Copy URL</button>
                <a href="${esc(liveUrl)}" target="_blank" class="btn primary sm">${icon("external-link")} Open Live</a>
              </div>
            </div>
          </div>

          <div style="margin-top:14px">
            <span style="font-size:12px;font-weight:600;color:var(--muted)">Deployment Logs</span>
            <pre id="cloud-deploy-log" style="background:#0f172a;color:#f8fafc;padding:12px;border-radius:8px;font-family:var(--mono);font-size:12px;max-height:220px;overflow-y:auto;margin-top:6px;line-height:1.5">// Ready to deploy. Click 'Deploy to Cloud' above.</pre>
          </div>
        </div>
      `;

      const deployBtn = $("#btn-cloud-deploy", content);
      const logEl = $("#cloud-deploy-log", content);
      const resBanner = $("#cloud-result-banner", content);
      const liveLink = $("#cloud-live-link", content);
      const copyUrlBtn = $("#btn-copy-cloud-url", content);

      deployBtn?.addEventListener("click", async () => {
        deployBtn.disabled = true;
        deployBtn.innerHTML = `${icon("loader")} Deploying…`;
        resBanner.style.display = "none";
        logEl.textContent = `[${new Date().toLocaleTimeString()}] Starting Laravel Cloud deployment pipeline...\n`;

        const updateStage = (stageName, status, duration = null) => {
          const box = $(`#stage-${stageName}`, content);
          if (!box) return;
          const badge = $(".stage-badge", box);
          if (badge) {
            badge.className = `chip sm stage-badge ${status === 'completed' ? 'ok' : status === 'running' ? 'warn' : status === 'failed' ? 'danger' : 'muted'}`;
            badge.textContent = status === 'completed' ? (duration ? `Done (${duration}ms)` : 'Done') : status;
          }
        };

        updateStage("prepare", "running");

        try {
          const env = $("#cloud-env-select", content)?.value || "production";
          const dres = await LD.call("cloud_deploy", { name: currentSite.name, environment: env });

          if (dres?.stages) {
            for (const st of dres.stages) {
              updateStage(st.name, st.status, st.duration_ms);
            }
          }

          if (dres?.logs) {
            logEl.textContent = dres.logs.join("\n");
          }

          if (dres?.ok) {
            updateStage("release", "completed");
            resBanner.style.display = "block";
            const u = dres.url || liveUrl;
            if (liveLink) {
              liveLink.href = u;
              liveLink.textContent = u;
            }
            if (copyUrlBtn) {
              copyUrlBtn.onclick = () => {
                navigator.clipboard.writeText(u);
                toast("success", "URL Copied", u);
              };
            }
            toast("success", "Deployment Complete", `Deployed ${currentSite.name} to Laravel Cloud`);
          } else {
            toast("error", "Deployment Failed", dres?.error || "Check deploy logs");
          }
        } catch (err) {
          logEl.textContent += `\nError: ${err.message}`;
          toast("error", "Deploy Error", err.message);
        } finally {
          deployBtn.disabled = false;
          deployBtn.innerHTML = `${icon("rocket")} Deploy to Cloud`;
        }
      });
    } catch (err) {
      content.innerHTML = `<div class="card danger">Error loading Laravel Cloud status: ${esc(err.message)}</div>`;
    }
  }

  async function renderDeployTargetAndHealth(content) {
    content.innerHTML = `<div style="padding:28px;text-align:center;color:var(--muted)">Loading deployment configuration…</div>`;

    try {
      const [target, serversRes, siteDetails] = await Promise.all([
        LD.call("deploy_target_get", { name: currentSite.name }),
        LD.call("servers"),
        LD.call("site", { name: currentSite.name }).catch(() => null),
      ]);

      const serversList = serversRes.servers || [];
      const currentServerId = target.server || (serversList[0]?.id || "");
      const currentPath = target.path || "";
      const currentBranch = target.branch || "main";

      // If server linked, attempt fetching live health info
      let serverInfo = null;
      let serverObj = serversList.find((s) => s.id === currentServerId);
      if (currentServerId) {
        try {
          serverInfo = await LD.call("server_info", { id: currentServerId });
        } catch { /* server might be unreachable */ }
      }

      // Local git status checks
      const git = siteDetails?.git;
      let gitNoticeHtml = "";
      if (git && git.ahead > 0) {
        gitNoticeHtml = `
          <div class="card" style="margin-bottom:14px;border-left:4px solid var(--amber);background:var(--amber-soft)">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
              <div>
                <b style="color:var(--amber);display:flex;align-items:center;gap:6px">
                  ${icon("alert")}Unpushed Local Commits
                </b>
                <span style="font-size:13px">You have <b>${git.ahead}</b> commit${git.ahead > 1 ? "s" : ""} on <code>${esc(git.branch || "main")}</code> ahead of remote. The server will not receive these changes unless pushed first.</span>
              </div>
              <button class="btn sm" id="btn-git-push" style="white-space:nowrap">${icon("upload")}Push Commits Now</button>
            </div>
          </div>`;
      } else if (git && git.changes > 0) {
        gitNoticeHtml = `
          <div class="card" style="margin-bottom:14px;border-left:4px solid var(--blue,#3b82f6);background:rgba(59,130,246,0.08)">
            <span style="font-size:13px"><b>Note:</b> You have <b>${git.changes}</b> uncommitted local change${git.changes > 1 ? "s" : ""} in your working directory.</span>
          </div>`;
      }

      if (!serversList.length) {
        content.innerHTML = `
          ${gitNoticeHtml}
          <div class="card" style="text-align:center;padding:40px 20px">
            <div style="width:48px;height:48px;border-radius:12px;background:var(--surface-2);display:grid;place-items:center;margin:0 auto 12px;color:var(--accent)">
              ${icon("cloud")}
            </div>
            <h3 style="margin:0 0 8px;font-size:15px">Link a server</h3>
            <p class="muted" style="max-width:380px;margin:0 auto 18px;font-size:13px;line-height:1.5">
              Connect your remote VPS or cloud server via SSH to enable automated deployments, health metrics, and rollback.
            </p>
            <button class="btn primary sm" id="btn-goto-servers">${icon("server")}Add a Server</button>
          </div>`;
        const gotoBtn = $("#btn-goto-servers", content);
        if (gotoBtn) {
          gotoBtn.addEventListener("click", () => {
            window.setView?.("servers");
          });
        }
        return;
      }

      content.innerHTML = `
        ${gitNoticeHtml}

        <!-- Linked Server Target Card -->
        <div class="card mb-md">
          <div class="flex-between mb-sm">
            <h3 style="margin:0;display:flex;align-items:center;gap:8px;font-size:14px">
              ${icon("cloud")}Remote Deployment Target
            </h3>
            ${target.server ? `<span class="chip sm text-green">Linked</span>` : `<span class="chip sm muted">Not linked</span>`}
          </div>

          <form id="deploy-target-form" style="display:flex;flex-direction:column;gap:10px">
            <div class="grid-2col">
              <label class="field">
                <span>Remote Server</span>
                <select name="server" class="input sm" ${!serversList.length ? "disabled" : ""}>
                  ${!serversList.length ? `<option value="">No remote servers added yet</option>` : ""}
                  ${serversList.map((s) => `<option value="${esc(s.id)}" ${s.id === currentServerId ? "selected" : ""}>${esc(s.name)} (${esc(s.host)})</option>`).join("")}
                </select>
              </label>

              <label class="field">
                <span>Git Branch</span>
                <input name="branch" class="input sm" value="${esc(currentBranch)}" placeholder="main" required>
              </label>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
              <label class="field">
                <span>Remote Project Path</span>
                <input name="path" class="input sm" value="${esc(currentPath)}" placeholder="/var/www/my-project" required>
              </label>

              <label class="field">
                <span>Remote Server PHP Version</span>
                <input name="server_php" class="input sm" value="${esc(target.server_php || "")}" placeholder="e.g. 8.3 (blank for default)">
              </label>
            </div>

            <div style="display:flex;align-items:center;gap:8px;margin-top:4px">
              <button class="btn sm primary" type="submit">${icon("check")}Save Deployment Target</button>
              ${serverObj ? `<button class="btn sm ghost" type="button" id="btn-open-server-term">${icon("terminal")}Open Server Terminal</button>` : ""}
            </div>
          </form>
        </div>

        <!-- Live Server Health Card -->
        ${serverInfo ? `
          <div class="card" style="margin-bottom:14px">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
              <div style="display:flex;align-items:center;gap:8px">
                <span class="dot on"></span>
                <b>Server Health: ${esc(serverObj?.name || serverInfo.hostname)}</b>
              </div>
              <span class="chip sm" style="font-family:var(--mono)">${esc(serverInfo.os || "")}</span>
            </div>

            <div class="server-health-grid">
              <div class="health-stat-box">
                <span class="stat-lbl">CPU Load</span>
                <span class="stat-num">${esc((serverInfo.load || "").split(" ")[0] || "–")}</span>
                <span class="muted sm">${esc(serverInfo.cpus || "1")} cores</span>
              </div>
              <div class="health-stat-box">
                <span class="stat-lbl">RAM Usage</span>
                <span class="stat-num">${serverInfo.mem_total ? Math.round((Number(serverInfo.mem_used) / Number(serverInfo.mem_total)) * 100) + "%" : "–"}</span>
                <span class="muted sm">${serverInfo.mem_used ? fmt_bytes_js(Number(serverInfo.mem_used)) : ""}</span>
              </div>
              <div class="health-stat-box">
                <span class="stat-lbl">Disk /</span>
                <span class="stat-num">${serverInfo.disk_total ? Math.round((Number(serverInfo.disk_used) / Number(serverInfo.disk_total)) * 100) + "%" : "–"}</span>
                <span class="muted sm">${serverInfo.disk_used ? fmt_bytes_js(Number(serverInfo.disk_used)) : ""}</span>
              </div>
              <div class="health-stat-box">
                <span class="stat-lbl">Uptime</span>
                <span class="stat-num">${serverInfo.uptime ? Math.round(Number(serverInfo.uptime) / 86400) + "d" : "–"}</span>
                <span class="muted sm">online</span>
              </div>
            </div>
          </div>` : ""}

        <!-- One-Click Deploy Card -->
        ${target.server && target.path ? `
          <div class="card deploy-action-card">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
              <div>
                <h3 style="margin:0;font-size:15px;display:flex;align-items:center;gap:8px">
                  ${icon("rocket")}One-Click Deploy & Rollback
                </h3>
                <span class="muted sm">Deploy latest code to <b>${esc(serverObj?.name || "Server")}</b></span>
              </div>
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <button class="btn ghost danger" id="btn-run-rollback" style="padding:8px 14px">
                  ${icon("rotate-ccw")}Rollback Previous
                </button>
                <button class="btn primary" id="btn-run-deploy" style="padding:8px 18px;font-weight:600">
                  ${icon("rocket")}Deploy to ${esc(serverObj?.name || "Server")}
                </button>
              </div>
            </div>

            <div style="margin-bottom:12px;background:var(--surface);padding:8px 12px;border-radius:6px;border:1px solid var(--border)">
              <label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer">
                <input type="checkbox" id="deploy-maint-chk" checked>
                <span><b>Maintenance mode:</b> Run <code>artisan down --retry=60</code> during deploy (auto-recovers via trap even on failure)</span>
              </label>
            </div>

            <div class="deploy-steps-preview">
              <div class="deploy-step">1. <code>php artisan down --retry=60</code> (if maintenance mode enabled)</div>
              <div class="deploy-step">2. <code>git rev-parse HEAD > .ld-last-deploy</code></div>
              <div class="deploy-step">3. <code>git pull --ff-only</code></div>
              <div class="deploy-step">4. <code>composer install --no-dev --optimize-autoloader</code></div>
              <div class="deploy-step">5. <code>php artisan migrate --force</code></div>
              <div class="deploy-step">6. <code>php artisan optimize</code></div>
              <div class="deploy-step">7. <code>php artisan queue:restart</code></div>
              <div class="deploy-step">8. <code>php artisan up</code></div>
            </div>
          </div>

          <!-- Deployment History Card -->
          <div class="card" style="margin-top:14px">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
              <h3 style="margin:0;font-size:14px;display:flex;align-items:center;gap:8px">
                ${icon("history")}Deployment History
              </h3>
              ${(target.history && target.history.length > 0) ? `<span class="muted sm">${target.history.length} record(s)</span>` : ""}
            </div>
            ${(target.history && target.history.length > 0) ? `
              <div class="table-wrap">
                <table class="table sm">
                  <thead>
                    <tr>
                      <th>Time</th>
                      <th>Action</th>
                      <th>Status</th>
                      <th>Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${target.history.map((h) => `
                      <tr>
                        <td style="white-space:nowrap;font-family:var(--mono);font-size:12px">${esc(h.timestamp)}</td>
                        <td><span class="chip sm" style="text-transform:capitalize">${esc(h.action)}</span></td>
                        <td>
                          <span class="chip sm ${h.status === "success" ? "success" : "danger"}">
                            ${esc(h.status)}
                          </span>
                        </td>
                        <td class="muted" style="font-size:12px">${esc(h.message || "–")}</td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              </div>
            ` : `<div style="padding:14px;text-align:center;color:var(--muted);font-size:13px">No deployments recorded yet.</div>`}
          </div>
        ` : ""}`;

      // Form submit
      const form = $("#deploy-target-form", content);
      if (form) {
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(form);
          const server = fd.get("server");
          const path = fd.get("path");
          const branch = fd.get("branch");
          const server_php = (fd.get("server_php") || "").trim();

          try {
            await LD.call("deploy_target_save", { name: currentSite.name, server, path, branch, server_php });
            toast("success", "Deployment target saved");
            renderDeployContent();
          } catch (err) {
            toast("error", "Couldn't save target", err.message);
          }
        });
      }

      // Open terminal
      const termBtn = $("#btn-open-server-term", content);
      if (termBtn) {
        termBtn.addEventListener("click", () => {
          LD.call("server_terminal", { id: currentServerId, path: currentPath });
        });
      }

      // Push button
      const pushBtn = $("#btn-git-push", content);
      if (pushBtn) {
        pushBtn.addEventListener("click", async () => {
          try {
            await runAction("git", { name: currentSite.name, op: "push" });
            toast("info", "Git push started");
          } catch (err) {
            toast("error", "Git push failed", err.message);
          }
        });
      }

      // Run deploy
      const deployBtn = $("#btn-run-deploy", content);
      if (deployBtn) {
        deployBtn.addEventListener("click", async () => {
          const down = Boolean($("#deploy-maint-chk", content)?.checked);
          if (!(await confirmModal({
            title: `Deploy ${currentSite.name}?`,
            message: `This executes the deployment pipeline on <b>${esc(serverObj?.name || "remote server")}</b> in directory <code>${esc(currentPath)}</code>.${down ? "<br><br><b>Maintenance mode</b> will be active during migration." : ""}`,
            confirm: "Deploy Now",
          }))) return;

          try {
            await runAction("remote-deploy", {
              server: currentServerId,
              path: currentPath,
              php: target.server_php || "",
              down: down,
              name: currentSite.name,
            });
          } catch (err) {
            toast("error", "Deploy failed to start", err.message);
          }
        });
      }

      // Rollback
      const rollbackBtn = $("#btn-run-rollback", content);
      if (rollbackBtn) {
        rollbackBtn.addEventListener("click", async () => {
          if (!(await confirmModal({
            title: `Rollback ${currentSite.name}?`,
            message: `This resets the remote codebase to the commit recorded prior to the last deployment (<code>git reset --hard</code>), reinstalls composer packages, and re-optimizes the application.`,
            confirm: "Rollback Now",
            danger: true,
          }))) return;

          const down = Boolean($("#deploy-maint-chk", content)?.checked);
          try {
            await runAction("remote-rollback", {
              server: currentServerId,
              path: currentPath,
              php: target.server_php || "",
              down: down,
              name: currentSite.name,
            });
          } catch (err) {
            toast("error", "Rollback failed to start", err.message);
          }
        });
      }

    } catch (err) {
      content.innerHTML = `<div style="padding:20px;color:var(--danger)">Error: ${esc(err.message)}</div>`;
    }
  }

  async function renderBackupsList(content) {
    content.innerHTML = `<div style="padding:28px;text-align:center;color:var(--muted)">Loading backups…</div>`;

    try {
      const [backups, estimate, schedule, servers] = await Promise.all([
        LD.call("backup_list", { name: currentSite.name }),
        LD.call("backup_estimate", { name: currentSite.name }).catch(() => null),
        LD.call("backup_schedule_get", { name: currentSite.name }).catch(() => null),
        LD.call("servers").catch(() => []),
      ]);

      const estHtml = estimate ? `
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px">
          <span class="chip sm" title="Expected size of database dump">${icon("database")} DB ~${esc(estimate.db_human)}</span>
          <span class="chip sm" title="Expected size of storage media">${icon("folder")} Storage ~${esc(estimate.storage_human)}</span>
          <span class="chip sm" title="Expected size of full snapshot">${icon("layers")} Total ~${esc(estimate.total_human)}</span>
        </div>` : "";

      content.innerHTML = `
        <div class="card" style="margin-bottom:14px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
            <div>
              <b style="display:flex;align-items:center;gap:6px">${icon("download")}Create Instant Snapshot</b>
              <span class="muted sm">Streamed directly to disk with live progress and cancel support</span>
              ${estHtml}
            </div>
            <div class="btn-row">
              <button class="btn sm primary" data-act-backup="full" title="Expected size: ~${estimate ? esc(estimate.total_human) : 'unknown'}" aria-label="Create full snapshot">${icon("layers")}Full Snapshot</button>
              <button class="btn sm" data-act-backup="db" title="Expected size: ~${estimate ? esc(estimate.db_human) : 'unknown'}" aria-label="Create database dump">${icon("database")}Database Dump</button>
              <button class="btn sm" data-act-backup="storage" title="Expected size: ~${estimate ? esc(estimate.storage_human) : 'unknown'}" aria-label="Create storage media backup">${icon("folder")}Storage Media</button>
            </div>
          </div>
        </div>

        <!-- Schedule & Retention Card -->
        <div class="card" style="margin-bottom:14px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
            <div style="display:flex;align-items:center;gap:8px">
              <b>${icon("pulse")}Scheduled Backups &amp; Retention</b>
              <span class="chip sm ${schedule?.enabled ? "ok" : ""}">${schedule?.enabled ? `Active · ${schedule.frequency}` : "Disabled"}</span>
              ${schedule?.last_run ? `<span class="muted sm">Last run: ${esc(schedule.last_run)}</span>` : ""}
            </div>
            <div class="btn-row">
              <button class="btn sm" id="btn-prune-backups" title="Keep the configured number of snapshots and delete older ones">${icon("trash")}Prune Old Backups</button>
            </div>
          </div>

          <form id="backup-schedule-form" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(160px, 1fr));gap:10px;align-items:end">
            <label class="field" style="margin:0">
              <span class="sm">Frequency</span>
              <select name="frequency" class="input sm">
                <option value="off" ${!schedule?.enabled ? "selected" : ""}>Disabled (Manual only)</option>
                <option value="daily" ${schedule?.enabled && schedule.frequency === "daily" ? "selected" : ""}>Daily (02:00 AM)</option>
                <option value="weekly" ${schedule?.enabled && schedule.frequency === "weekly" ? "selected" : ""}>Weekly (Sun 03:00 AM)</option>
              </select>
            </label>

            <label class="field" style="margin:0">
              <span class="sm">Snapshot Type</span>
              <select name="type" class="input sm">
                <option value="full" ${schedule?.type === "full" ? "selected" : ""}>Full (DB + Storage + Env)</option>
                <option value="db" ${schedule?.type === "db" ? "selected" : ""}>Database only</option>
                <option value="storage" ${schedule?.type === "storage" ? "selected" : ""}>Storage media only</option>
              </select>
            </label>

            <label class="field" style="margin:0">
              <span class="sm">Retention</span>
              <select name="retention" class="input sm">
                <option value="3" ${schedule?.retention === 3 ? "selected" : ""}>Keep last 3 snapshots</option>
                <option value="5" ${!schedule?.retention || schedule?.retention === 5 ? "selected" : ""}>Keep last 5 snapshots</option>
                <option value="7" ${schedule?.retention === 7 ? "selected" : ""}>Keep last 7 snapshots</option>
                <option value="14" ${schedule?.retention === 14 ? "selected" : ""}>Keep last 14 snapshots</option>
                <option value="30" ${schedule?.retention === 30 ? "selected" : ""}>Keep last 30 snapshots</option>
              </select>
            </label>

            <label class="field" style="margin:0">
              <span class="sm">Offsite Upload (SSH)</span>
              <select name="remote" class="input sm">
                <option value="">None (Local only)</option>
                ${(servers || []).map((s) => `<option value="${esc(s.id)}" ${schedule?.remote === s.id ? "selected" : ""}>${esc(s.name || s.host)} (${esc(s.host)})</option>`).join("")}
              </select>
            </label>

            <button type="submit" class="btn sm primary" style="height:32px">${icon("check")}Save Schedule</button>
          </form>
        </div>

        <div class="queue-section">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
            <h3 style="margin:0;font-size:14px;display:flex;align-items:center;gap:6px">
              ${icon("file")}Saved Snapshots
              <span class="chip sm">${backups.length}</span>
            </h3>
          </div>

          ${!backups.length
            ? `<div class="card" style="text-align:center;padding:28px;color:var(--muted)">
                 No snapshots created yet. Click one of the buttons above to create your first backup.
               </div>`
            : `<div class="queue-jobs-list">
                 ${backups.map((b) => `
                   <div class="job-card" style="border-left-color:var(--accent)">
                     <div class="job-card-header" style="flex-wrap:wrap;gap:6px">
                       <span class="job-class">${esc(b.filename)}</span>
                       <span class="chip sm" style="text-transform:uppercase">${esc(b.type)}</span>
                       <span class="chip sm muted">${esc(b.size_human)}</span>
                       ${b.manifest?.db_driver ? `<span class="chip sm info">${esc(b.manifest.db_driver)}</span>` : ""}
                       ${b.manifest?.db_name ? `<span class="chip sm muted" title="Database name">${esc(b.manifest.db_name)}</span>` : ""}
                       ${b.manifest?.tables?.length ? `<span class="chip sm" title="${esc(b.manifest.tables.slice(0, 15).join(', '))}${b.manifest.tables.length > 15 ? '…' : ''}">${b.manifest.tables.length} tables</span>` : ""}
                       <span class="muted sm" style="margin-left:auto">${esc(b.created_at)}</span>
                       <div class="btn-row" style="margin-left:8px">
                         ${(servers || []).length ? `<button class="btn sm ghost" data-upload-backup="${esc(b.filename)}" title="Upload to remote SSH server">${icon("upload")}Offsite</button>` : ""}
                         <button class="btn sm ghost" data-restore-backup="${esc(b.filename)}" title="Restore">${icon("refresh")}Restore</button>
                         <button class="btn sm ghost danger" data-delete-backup="${esc(b.filename)}" title="Delete">${icon("trash")}</button>
                       </div>
                     </div>
                   </div>`).join("")}
               </div>`}
        </div>`;

      // Schedule form handler
      const schedForm = $("#backup-schedule-form", content);
      if (schedForm) {
        schedForm.addEventListener("submit", async (e) => {
          e.preventDefault();
          const freq = schedForm.frequency.value;
          const btype = schedForm.type.value;
          const ret = Number(schedForm.retention.value);
          const rem = schedForm.remote.value;
          try {
            await LD.call("backup_schedule_set", {
              name: currentSite.name,
              frequency: freq,
              type: btype,
              retention: ret,
              remote: rem,
            });
            toast("success", "Backup schedule updated");
            renderBackupsList(content);
          } catch (err) {
            toast("error", "Failed to update schedule", err.message);
          }
        });
      }

      // Prune handler
      const pruneBtn = $("#btn-prune-backups", content);
      if (pruneBtn) {
        pruneBtn.addEventListener("click", async () => {
          const keep = Number(schedForm?.retention?.value || schedule?.retention || 5);
          if (!(await confirmModal({
            title: "Prune old backups?",
            message: `This will keep the newest <b>${keep}</b> snapshots and permanently delete older ones.`,
            confirm: "Prune",
            danger: true,
          }))) return;

          pruneBtn.disabled = true;
          try {
            await runAction("backup-prune", { name: currentSite.name, keep });
            setTimeout(() => renderBackupsList(content), 1200);
          } catch (err) {
            toast("error", "Pruning failed", err.message);
          } finally {
            pruneBtn.disabled = false;
          }
        });
      }

      // Create backup handlers
      $$("[data-act-backup]", content).forEach((btn) => {
        btn.addEventListener("click", async () => {
          const btype = btn.dataset.actBackup;
          btn.disabled = true;
          try {
            await runAction("backup", { name: currentSite.name, type: btype });
            setTimeout(() => renderBackupsList(content), 1200);
          } catch (err) {
            toast("error", "Backup failed", err.message);
          } finally {
            btn.disabled = false;
          }
        });
      });

      // Restore, delete & upload handlers
      content.addEventListener("click", async (e) => {
        const uploadBtn = e.target.closest("[data-upload-backup]");
        if (uploadBtn) {
          const fn = uploadBtn.dataset.uploadBackup;
          const sList = servers || [];
          if (!sList.length) return toast("error", "No SSH servers", "Please configure a remote SSH server first.");
          let chosenServerId = sList[0].id;
          if (sList.length > 1) {
            const promptOptions = sList.map((s) => s.id).join(", ");
            chosenServerId = await promptModal("Upload Snapshot to SSH", `Server ID (${promptOptions}):`, chosenServerId);
          }
          if (!chosenServerId) return;
          uploadBtn.disabled = true;
          try {
            await runAction("backup-upload", { name: currentSite.name, filename: fn, remote: chosenServerId });
          } catch (err) {
            toast("error", "Upload failed", err.message);
          } finally {
            uploadBtn.disabled = false;
          }
          return;
        }

        const restoreBtn = e.target.closest("[data-restore-backup]");
        if (restoreBtn) {
          const fn = restoreBtn.dataset.restoreBackup;
          const backupItem = backups.find((x) => x.filename === fn);
          const manifestDetails = backupItem?.manifest
            ? `<div style="margin-top:8px;padding:8px;background:var(--surface-2);border-radius:6px;font-size:12px;font-family:var(--mono)">Driver: ${esc(backupItem.manifest.db_driver)} · DB: ${esc(backupItem.manifest.db_name)} · Tables: ${backupItem.manifest.tables.length}</div>`
            : "";

          if (!(await confirmModal({
            title: `Restore backup ${fn}?`,
            message: `This will restore the database and media files from snapshot <b>${esc(fn)}</b>.${manifestDetails}`,
            confirm: "Restore",
            danger: true,
          }))) return;

          restoreBtn.disabled = true;
          try {
            await runAction("backup-restore", { name: currentSite.name, filename: fn });
            setTimeout(() => renderBackupsList(content), 1200);
          } catch (err) {
            toast("error", "Restore failed", err.message);
          } finally {
            restoreBtn.disabled = false;
          }
          return;
        }

        const delBtn = e.target.closest("[data-delete-backup]");
        if (delBtn) {
          const fn = delBtn.dataset.deleteBackup;
          if (!(await confirmModal({
            title: `Delete backup?`,
            message: `Permanently delete snapshot <b>${esc(fn)}</b>?`,
            confirm: "Delete",
            danger: true,
          }))) return;

          delBtn.disabled = true;
          try {
            await LD.call("backup_delete", { name: currentSite.name, filename: fn });
            toast("success", `Deleted ${fn}`);
            renderBackupsList(content);
          } catch (err) {
            toast("error", "Delete failed", err.message);
          }
        }
      });

    } catch (err) {
      content.innerHTML = `<div style="padding:20px;color:var(--danger)">Couldn't load backups: ${esc(err.message)}</div>`;
    }
  }

  function fmt_bytes_js(size) {
    if (!size) return "0 B";
    let s = Number(size);
    const units = ["B", "KB", "MB", "GB", "TB"];
    for (let u of units) {
      if (s < 1024) return (u === "B" ? s : s.toFixed(1)) + " " + u;
      s /= 1024;
    }
    return s.toFixed(1) + " TB";
  }

  function update(site) {
    if (!site || !currentSite || currentSite.name !== site.name) return;
    currentSite = site;

    // Update worker status card if present in queue tab
    const workerCard = $("#queue-tab-content [data-worker-card]");
    if (workerCard) {
      const isRunning = Boolean(site.worker);
      const dot = $(".dot", workerCard);
      if (dot) dot.className = `dot ${isRunning ? "on" : "off"}`;
      const title = $("b", workerCard);
      if (title) title.innerText = `Queue Worker: ${isRunning ? "Running" : "Stopped"}`;
      const btnRow = $(".btn-row", workerCard);
      if (btnRow) {
        btnRow.innerHTML = isRunning
          ? `<button class="btn sm" data-worker-act="restart">${icon("refresh")}Restart Worker</button>
             <button class="btn sm danger" data-worker-act="stop">${icon("stop")}Stop</button>`
          : `<button class="btn sm primary" data-worker-act="start">${icon("play")}Start Worker</button>`;
      }
    }
  }

  // ── Routes Tab ─────────────────────────────────────────────────────────────
  function mountRoutes(container, site) {
    currentSite = site;
    let routes = [];
    let query = "";
    let methodFilter = "ALL";
    let loading = true;
    let error = "";

    container.innerHTML = `
      <div class="routes-container">
        <div class="routes-toolbar">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <div class="search" style="width:280px">
              ${icon("search")}
              <input type="search" id="routes-search" placeholder="Search URI, name, action…" autocomplete="off">
            </div>
            <div class="route-method-pills" id="routes-method-pills">
              <button class="route-method-pill active" data-m="ALL">ALL</button>
              <button class="route-method-pill" data-m="GET">GET</button>
              <button class="route-method-pill" data-m="POST">POST</button>
              <button class="route-method-pill" data-m="PUT">PUT/PATCH</button>
              <button class="route-method-pill" data-m="DELETE">DELETE</button>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn sm" id="routes-open-tester-btn">${icon("zap")} Test Route</button>
            <span class="chip sm" id="routes-count-chip">—</span>
            <button class="btn sm icon-btn" id="routes-refresh-btn" title="Refresh routes (force reload)" aria-label="Refresh routes">${icon("refresh")}</button>
          </div>
        </div>
        <div id="routes-content" style="min-height:200px">
          <div class="loading-pane">${icon("pulse")} Loading routes…</div>
        </div>

        <!-- Route Tester Modal (Task 7.3) -->
        <div id="route-tester-modal" class="modal-scrim" hidden>
          <div class="modal card" style="max-width:760px;max-height:85vh;display:flex;flex-direction:column;padding:0;overflow:hidden">
            <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between;padding:12px 18px;border-bottom:1px solid var(--border);background:var(--surface-2)">
              <div style="display:flex;align-items:center;gap:10px">
                <span style="color:var(--accent)">${icon("zap")}</span>
                <b style="font-size:14px">Route Tester (API Client)</b>
              </div>
              <button class="btn ghost icon-btn sm" id="btn-route-tester-close" aria-label="Close">${icon("x")}</button>
            </div>
            <div style="padding:16px;overflow-y:auto;flex:1">
              <div style="display:flex;gap:8px;margin-bottom:12px">
                <select id="route-test-method" style="width:110px;font-family:var(--mono);font-weight:700">
                  <option value="GET">GET</option>
                  <option value="POST">POST</option>
                  <option value="PUT">PUT</option>
                  <option value="PATCH">PATCH</option>
                  <option value="DELETE">DELETE</option>
                </select>
                <input type="text" id="route-test-uri" style="flex:1;font-family:var(--mono);font-size:13px" placeholder="/api/users">
                <button class="btn primary" id="btn-route-test-send">${icon("play")} Send</button>
              </div>

              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
                <div>
                  <label style="font-size:11px;font-weight:600;color:var(--muted);display:block;margin-bottom:4px">Bearer Token (Authorization)</label>
                  <input type="text" id="route-test-token" placeholder="Optional Bearer token" style="font-family:var(--mono);font-size:12px;width:100%">
                </div>
                <div>
                  <label style="font-size:11px;font-weight:600;color:var(--muted);display:block;margin-bottom:4px">Custom Header</label>
                  <input type="text" id="route-test-header-extra" placeholder="Accept: application/json" style="font-family:var(--mono);font-size:12px;width:100%">
                </div>
              </div>

              <div id="route-test-body-wrap" style="margin-bottom:14px">
                <label style="font-size:11px;font-weight:600;color:var(--muted);display:block;margin-bottom:4px">Request Body (JSON)</label>
                <textarea id="route-test-body" style="width:100%;min-height:85px;font-family:var(--mono);font-size:12px" placeholder='{"key": "value"}'></textarea>
              </div>

              <!-- Response Pane -->
              <div id="route-test-response-wrap" style="display:none;border-top:1px solid var(--border);padding-top:12px">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
                  <div style="display:flex;align-items:center;gap:8px">
                    <span id="route-test-resp-status" class="perf-status-badge s2xx">200 OK</span>
                    <span id="route-test-resp-time" class="chip sm" style="font-family:var(--mono)">0 ms</span>
                    <span id="route-test-resp-size" class="chip sm" style="font-family:var(--mono)">0 B</span>
                  </div>
                  <button class="btn sm ghost" id="btn-route-test-copy-resp">${icon("copy")} Copy</button>
                </div>
                <pre id="route-test-resp-body" class="terminal" style="max-height:280px;overflow:auto;margin:0;font-size:12px;padding:12px"></pre>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    const contentEl = $("#routes-content", container);
    const countChip = $("#routes-count-chip", container);
    const searchInput = $("#routes-search", container);
    const pillsWrap = $("#routes-method-pills", container);
    const refreshBtn = $("#routes-refresh-btn", container);

    const testerModal = $("#route-tester-modal", container);
    const testerCloseBtn = $("#btn-route-tester-close", testerModal);
    const testerMethod = $("#route-test-method", testerModal);
    const testerUri = $("#route-test-uri", testerModal);
    const testerToken = $("#route-test-token", testerModal);
    const testerHeaderExtra = $("#route-test-header-extra", testerModal);
    const testerBody = $("#route-test-body", testerModal);
    const testerSendBtn = $("#btn-route-test-send", testerModal);
    const testerRespWrap = $("#route-test-response-wrap", testerModal);
    const testerRespStatus = $("#route-test-resp-status", testerModal);
    const testerRespTime = $("#route-test-resp-time", testerModal);
    const testerRespSize = $("#route-test-resp-size", testerModal);
    const testerRespBody = $("#route-test-resp-body", testerModal);
    const testerCopyRespBtn = $("#btn-route-test-copy-resp", testerModal);

    testerCloseBtn?.addEventListener("click", () => { testerModal.hidden = true; });
    testerModal?.addEventListener("click", (e) => { if (e.target === testerModal) testerModal.hidden = true; });

    $("#routes-open-tester-btn", container)?.addEventListener("click", () => {
      const savedToken = localStorage.getItem("ld_token_" + site.name);
      if (savedToken && !testerToken.value) testerToken.value = savedToken;
      testerModal.hidden = false;
    });

    testerCopyRespBtn?.addEventListener("click", () => {
      copyText(testerRespBody.textContent || "");
    });

    testerSendBtn?.addEventListener("click", async () => {
      testerSendBtn.disabled = true;
      testerSendBtn.innerHTML = `${icon("pulse")} Sending…`;
      testerRespWrap.style.display = "block";
      testerRespBody.textContent = "Connecting to application…";

      const headers = {};
      const token = testerToken.value.trim();
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
        try { localStorage.setItem("ld_token_" + site.name, token); } catch (e) {}
      }
      const extraH = testerHeaderExtra.value.trim();
      if (extraH && extraH.includes(":")) {
        const [hk, hv] = extraH.split(/:\s*/, 2);
        headers[hk] = hv;
      }

      try {
        const res = await LD.call("route_test", {
          name: site.name,
          method: testerMethod.value,
          uri: testerUri.value.trim(),
          headers,
          body: testerBody.value.trim(),
        });

        if (!res.ok && res.error) {
          testerRespStatus.className = "perf-status-badge s5xx";
          testerRespStatus.textContent = "Error";
          testerRespTime.textContent = `${res.duration_ms || 0} ms`;
          testerRespSize.textContent = "0 B";
          testerRespBody.textContent = `Request failed: ${res.error}`;
          return;
        }

        const s = res.status || 200;
        testerRespStatus.className = `perf-status-badge s${Math.floor(s / 100)}xx`;
        testerRespStatus.textContent = `${s} ${s === 200 ? 'OK' : (s === 404 ? 'Not Found' : '')}`;
        testerRespTime.textContent = `${res.duration_ms || 0} ms`;
        testerRespSize.textContent = res.size_bytes ? `${Math.round(res.size_bytes / 1024 * 10) / 10} KB` : '0 B';

        if (res.json) {
          testerRespBody.textContent = JSON.stringify(res.json, null, 2);
        } else {
          testerRespBody.textContent = res.text || "(empty response body)";
        }
      } catch (err) {
        testerRespStatus.className = "perf-status-badge s5xx";
        testerRespStatus.textContent = "Exception";
        testerRespBody.textContent = `Client error: ${err.message}`;
      } finally {
        testerSendBtn.disabled = false;
        testerSendBtn.innerHTML = `${icon("play")} Send`;
      }
    });

    async function loadRoutes(force = false) {
      loading = true;
      error = "";
      refreshBtn.disabled = true;
      contentEl.innerHTML = `<div class="loading-pane">${icon("pulse")} Scanning application routes…</div>`;
      try {
        const res = await LD.call("site_routes", { name: site.name, force });
        if (!res.ok) {
          throw new Error(res.error || "Failed to load routes");
        }
        routes = res.routes || [];
        renderTable();
      } catch (err) {
        error = err.message;
        contentEl.innerHTML = `
          <div class="error-pane" style="padding:28px;text-align:center">
            <p style="color:var(--red);margin-bottom:12px">${icon("alert")} Couldn't load routes: ${esc(error)}</p>
            <button class="btn sm" id="routes-retry-btn">${icon("refresh")} Try Again</button>
          </div>
        `;
        $("#routes-retry-btn", contentEl)?.addEventListener("click", () => loadRoutes(true));
      } finally {
        loading = false;
        refreshBtn.disabled = false;
      }
    }

    function renderTable() {
      const q = query.trim().toLowerCase();
      const filtered = routes.filter((r) => {
        if (methodFilter !== "ALL") {
          const methods = (r.method || "").split("|").map((m) => m.toUpperCase());
          if (methodFilter === "PUT") {
            if (!methods.includes("PUT") && !methods.includes("PATCH")) return false;
          } else if (!methods.includes(methodFilter)) {
            return false;
          }
        }
        if (!q) return true;
        const hay = [r.uri, r.name, r.action, ...(r.middleware || [])].join(" ").toLowerCase();
        return hay.includes(q);
      });

      countChip.textContent = `${filtered.length} / ${routes.length} routes`;

      if (!filtered.length) {
        contentEl.innerHTML = `
          <div class="card" style="text-align:center;padding:32px;color:var(--muted)">
            ${icon("search")} No routes match your filter.
          </div>
        `;
        return;
      }

      contentEl.innerHTML = `
        <div class="routes-table-wrap">
          <table class="routes-table">
            <thead>
              <tr>
                <th style="width:70px">Method</th>
                <th>URI</th>
                <th>Name</th>
                <th>Action</th>
                <th>Middleware</th>
              </tr>
            </thead>
            <tbody>
              ${filtered.map((r) => {
                const primaryMethod = (r.method || "GET").split("|")[0].toLowerCase();
                const methodCls = primaryMethod === "delete" ? "delete" : primaryMethod === "post" ? "post" : (primaryMethod === "put" || primaryMethod === "patch") ? "put" : "get";
                const isNavigable = !r.uri.includes("{") && site.url;
                const uriHtml = isNavigable
                  ? `<a href="#" data-open-route-url="${esc(site.url + '/' + r.uri.replace(/^\//, ''))}" class="link routes-uri" title="Open in browser">${esc(r.uri)}</a>`
                  : `<span class="routes-uri">${esc(r.uri)}</span>`;

                const actionHtml = r.file
                  ? `<button class="btn ghost sm routes-action-btn" data-open-ctrl-file="${esc(r.file)}" data-line="${esc(r.line || 1)}" title="Open in editor (${esc(r.file)}:${esc(r.line || 1)})">${icon("code")} <span>${esc(r.action)}</span></button>`
                  : `<span class="routes-action-btn muted" title="${esc(r.action)}">${esc(r.action)}</span>`;

                const mwHtml = (r.middleware || []).slice(0, 3).map((m) => `<span class="chip xs muted" style="font-size:10.5px">${esc(m)}</span>`).join(" ") +
                  ((r.middleware || []).length > 3 ? ` <span class="muted sm" title="${esc((r.middleware || []).join(', '))}">+${(r.middleware || []).length - 3}</span>` : "");

                return `
                  <tr>
                    <td><span class="route-method ${methodCls}">${esc(r.method)}</span></td>
                    <td>
                      <div style="display:flex;align-items:center;gap:6px">
                        ${uriHtml}
                        <button class="btn ghost icon-btn xs" data-copy-route-uri="${esc(r.uri)}" title="Copy URI" aria-label="Copy URI">${icon("copy")}</button>
                        <button class="btn ghost icon-btn xs" data-try-route="${esc(r.uri)}" data-method="${esc((r.method || 'GET').split('|')[0])}" title="Try in API client" aria-label="Try in API client">${icon("play")}</button>
                      </div>
                    </td>
                    <td><span class="muted sm">${esc(r.name || "—")}</span></td>
                    <td>${actionHtml}</td>
                    <td>${mwHtml || '<span class="muted sm">—</span>'}</td>
                  </tr>
                `;
              }).join("")}
            </tbody>
          </table>
        </div>
      `;

      // Handlers
      $$("[data-try-route]", contentEl).forEach((btn) => {
        btn.addEventListener("click", () => {
          testerMethod.value = (btn.dataset.method || "GET").toUpperCase();
          testerUri.value = btn.dataset.tryRoute || "/";
          const savedToken = localStorage.getItem("ld_token_" + site.name);
          if (savedToken && !testerToken.value) testerToken.value = savedToken;
          testerModal.hidden = false;
        });
      });

      $$("[data-copy-route-uri]", contentEl).forEach((btn) => {
        btn.addEventListener("click", () => {
          navigator.clipboard?.writeText(btn.dataset.copyRouteUri);
          toast("success", "URI copied to clipboard");
        });
      });

      $$("[data-open-route-url]", contentEl).forEach((a) => {
        a.addEventListener("click", (e) => {
          e.preventDefault();
          LD.call("open", { target: "url", url: a.dataset.openRouteUrl });
        });
      });

      $$("[data-open-ctrl-file]", contentEl).forEach((btn) => {
        btn.addEventListener("click", () => {
          const path = btn.dataset.openCtrlFile;
          const line = parseInt(btn.dataset.line || "1", 10);
          LD.call("open_file", { path, line }).catch((err) => {
            toast("error", "Couldn't open file", err.message);
          });
        });
      });
    }

    searchInput.addEventListener("input", (e) => {
      query = e.target.value;
      renderTable();
    });

    $$(".route-method-pill", pillsWrap).forEach((pill) => {
      pill.addEventListener("click", () => {
        $$(".route-method-pill", pillsWrap).forEach((p) => p.classList.remove("active"));
        pill.classList.add("active");
        methodFilter = pill.dataset.m;
        renderTable();
      });
    });

    refreshBtn.addEventListener("click", () => loadRoutes(true));

    loadRoutes(false);
  }

  // ── Dumps Tab ─────────────────────────────────────────────────────────────
  let activeDumpsContainer = null;
  let activeDumpsSite = null;
  let dumpSeq = 0;

  // Window message listener for auto-resizing sandboxed dump iframes
  window.addEventListener("message", (e) => {
    if (e.data && e.data.type === "ld-dump-resize" && e.data.id) {
      const frame = document.getElementById(e.data.id);
      if (frame) {
        frame.style.height = Math.max(36, (e.data.height || 0) + 6) + "px";
      }
    }
  });

  function createDumpCard(d) {
    dumpSeq++;
    const frameId = `dump-frame-${dumpSeq}-${Date.now()}`;
    const card = document.createElement("div");
    card.className = "dump-card";
    const srcLabel = d.rel_file ? `${esc(d.rel_file)}${d.line ? `:${d.line}` : ''}` : "dump()";
    card.innerHTML = `
      <div class="dump-card-header">
        <div style="display:flex;align-items:center;gap:8px">
          <span class="chip sm muted">${esc(d.timestamp || 'now')}</span>
          <b style="font-size:12px;font-family:var(--mono)">${srcLabel}</b>
        </div>
        ${d.file ? `
          <button class="btn ghost sm" data-open-dump-file="${esc(d.file)}" data-line="${esc(d.line || 1)}" title="Open in editor">
            ${icon("code")} Open
          </button>
        ` : ''}
      </div>
      <div class="dump-body">
        <iframe id="${frameId}" class="dump-frame" sandbox="allow-scripts" style="width:100%;border:none;min-height:40px;background:transparent;display:block;"></iframe>
      </div>
    `;

    const openBtn = card.querySelector("[data-open-dump-file]");
    if (openBtn) {
      openBtn.addEventListener("click", () => {
        const path = openBtn.dataset.openDumpFile;
        const line = parseInt(openBtn.dataset.line || "1", 10);
        LD.call("open_file", { path, line }).catch((err) => {
          toast("error", "Couldn't open file", err.message);
        });
      });
    }

    const iframe = card.querySelector(`#${frameId}`);
    if (iframe) {
      const isDark = document.body.classList.contains("dark") || window.matchMedia("(prefers-color-scheme: dark)").matches;
      const docHtml = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
  body { margin:0; padding:6px 8px; font-family: monospace; background:transparent; color:${isDark ? '#e2e8f0' : '#1e293b'}; font-size:12px; overflow-y:hidden; }
  pre.sf-dump { margin:0 !important; background:transparent !important; font-size:12px !important; }
  pre.sf-dump span { font-family: monospace; }
</style>
</head><body>
${d.html || esc(d.raw || '')}
<script>
  function sendH() {
    var h = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
    window.parent.postMessage({ type: 'ld-dump-resize', id: '${frameId}', height: h }, '*');
  }
  window.addEventListener('DOMContentLoaded', sendH);
  window.addEventListener('load', sendH);
  if (window.ResizeObserver) {
    new ResizeObserver(sendH).observe(document.body);
  }
<\/script>
</body></html>`;
      iframe.srcdoc = docHtml;
    }

    return card;
  }

  function onDumpEvent(dump) {
    if (!activeDumpsContainer || !activeDumpsSite) return;
    if (dump.site && dump.site !== activeDumpsSite.name) return;

    const listEl = $("#dumps-list", activeDumpsContainer);
    if (!listEl) return;

    const empty = $(".dumps-empty", listEl);
    if (empty) empty.remove();

    const card = createDumpCard(dump);
    listEl.prepend(card);

    const countEl = $("#dumps-count-chip", activeDumpsContainer);
    if (countEl) {
      const cur = parseInt(countEl.textContent, 10) || 0;
      countEl.textContent = `${cur + 1}`;
    }
  }

  async function mountDumps(container, site) {
    currentSite = site;
    activeDumpsContainer = container;
    activeDumpsSite = site;

    container.innerHTML = `
      <div class="dumps-container">
        <div class="card" style="margin-bottom:12px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
            <div>
              <b style="display:flex;align-items:center;gap:6px">${icon("zap")} VarDumper &amp; dump() Server</b>
              <span class="muted sm">Real-time dump() captures listening on <code>127.0.0.1:9912</code></span>
            </div>
            <div style="display:flex;align-items:center;gap:10px">
              <label class="row" style="margin:0;gap:8px;cursor:pointer">
                <span style="font-size:12px;font-weight:550">Intercept in this project</span>
                <input type="checkbox" class="switch" id="dumps-toggle-switch">
              </label>
              <span class="chip sm" id="dumps-count-chip">0</span>
              <button class="btn sm ghost danger" id="dumps-clear-btn" title="Clear all dumps" aria-label="Clear all dumps">${icon("trash")}</button>
            </div>
          </div>
        </div>
        <div id="dumps-cache-warning" hidden></div>
        <div id="dumps-list">
          <div class="loading-pane">${icon("pulse")} Loading dumps…</div>
        </div>
      </div>
    `;

    const listEl = $("#dumps-list", container);
    const countEl = $("#dumps-count-chip", container);
    const toggleSwitch = $("#dumps-toggle-switch", container);
    const clearBtn = $("#dumps-clear-btn", container);
    const warningEl = $("#dumps-cache-warning", container);

    async function refreshStatus() {
      try {
        const st = await LD.call("dumps_status", { name: site.name });
        toggleSwitch.checked = !!st.site_active;
        if (warningEl) {
          if (st.config_cached) {
            warningEl.innerHTML = `
              <div class="card warning" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;padding:10px 14px;background:var(--card-bg, #fff);border-inline-start:4px solid var(--amber)">
                <div style="display:flex;align-items:center;gap:10px">
                  <span style="color:var(--amber);font-size:18px">${icon("alert")}</span>
                  <div>
                    <b>Configuration is cached</b>
                    <div class="muted sm">Laravel will not read <code>VAR_DUMPER_SERVER</code> while config is cached. Run <code>config:clear</code> to intercept dumps.</div>
                  </div>
                </div>
                <button class="btn sm" id="btn-clear-dump-config-cache">${icon("refresh")} Run config:clear</button>
              </div>
            `;
            warningEl.hidden = false;
            $("#btn-clear-dump-config-cache", warningEl)?.addEventListener("click", async () => {
              try {
                await LD.call("run", { action: "artisan", params: { name: site.name, args: "config:clear" } });
                toast("success", "Configuration cache cleared");
                refreshStatus();
              } catch (e) {
                toast("error", "Failed to clear config cache", e.message);
              }
            });
          } else {
            warningEl.hidden = true;
            warningEl.innerHTML = "";
          }
        }
      } catch (err) {}
    }

    async function loadDumps() {
      try {
        const dumps = await LD.call("dumps_list", { name: site.name });
        countEl.textContent = `${dumps.length}`;
        if (!dumps.length) {
          listEl.innerHTML = `
            <div class="card dumps-empty" style="text-align:center;padding:32px;color:var(--muted)">
              ${icon("terminal")} No dumps captured yet.<br>
              <span style="font-size:12px;margin-top:6px;display:inline-block">Call <code>dump($var)</code> or <code>dd($var)</code> anywhere in this project.</span>
            </div>
          `;
          return;
        }

        listEl.innerHTML = "";
        dumps.forEach((d) => {
          listEl.appendChild(createDumpCard(d));
        });
      } catch (err) {
        listEl.innerHTML = `<div class="card" style="color:var(--red);padding:20px">${icon("alert")} Couldn't load dumps: ${esc(err.message)}</div>`;
      }
    }

    toggleSwitch.addEventListener("change", async () => {
      const enable = toggleSwitch.checked;
      toggleSwitch.disabled = true;
      try {
        const res = await LD.call("dumps_toggle", { name: site.name, enable });
        if (!res.ok) throw new Error(res.error || "Toggle failed");
        toast("success", enable ? "Dumps interception enabled (.env updated)" : "Dumps interception disabled");
      } catch (err) {
        toast("error", "Failed to toggle dumps", err.message);
        toggleSwitch.checked = !enable;
      } finally {
        toggleSwitch.disabled = false;
      }
    });

    clearBtn.addEventListener("click", async () => {
      await LD.call("dumps_clear");
      loadDumps();
      toast("info", "Dumps cleared");
    });

    refreshStatus();
    loadDumps();
  }

  let activeTestsResults = null;

  function mountTests(site, container) {
    currentSite = site;
    let filterQuery = "";
    let isRunning = false;
    let discoveryData = null;
    let stopOnFailure = false;
    let lastFailedCases = [];

    container.innerHTML = `
      <div class="tests-container" style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
        <!-- Left Sidebar: Test Suites Tree -->
        <div class="card" id="tests-tree-card" style="width:280px;min-width:260px;padding:12px;display:flex;flex-direction:column;gap:10px">
          <div style="display:flex;align-items:center;justify-content:space-between">
            <b style="font-size:13px">${icon("box")} Test Suites</b>
            <span class="chip xs" id="tests-runner-badge" style="text-transform:uppercase;font-weight:700">…</span>
          </div>
          <input type="search" id="tests-tree-filter" placeholder="Filter suites & files…" class="input sm" style="width:100%">
          <div id="tests-tree-pane" style="max-height:65vh;overflow-y:auto;display:flex;flex-direction:column;gap:6px">
            <div class="muted xs" style="padding:14px;text-align:center">${icon("pulse")} Discovering test files…</div>
          </div>
        </div>

        <!-- Right Main Panel: Results & Runner -->
        <div style="flex:1;min-width:320px;display:flex;flex-direction:column;gap:12px">
          <!-- Toolbar Card -->
          <div class="card" style="padding:12px 14px;display:flex;flex-direction:column;gap:10px">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
              <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:240px">
                <input type="text" class="input sm" id="tests-filter" placeholder="Filter by test name, method, or file…" value="${esc(filterQuery)}" style="flex:1">
                <button class="btn sm primary" id="tests-run-btn">${icon("play")}Run Tests</button>
                <button class="btn sm danger" id="tests-run-failed-btn" style="display:none">${icon("refresh")}Run Failed (<span id="tests-failed-cnt">0</span>)</button>
              </div>
              <div id="tests-summary-bar" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap"></div>
            </div>

            <!-- Options Row -->
            <div style="display:flex;align-items:center;gap:16px;font-size:12px;color:var(--text-muted);border-top:1px solid var(--border);padding-top:8px">
              <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
                <input type="checkbox" id="tests-coverage-toggle">
                <span>Code Coverage</span>
              </label>
              <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
                <input type="checkbox" id="tests-stop-on-fail-toggle">
                <span>Stop on Failure</span>
              </label>
              <span class="spacer"></span>
              <button class="btn xs ghost" id="tests-btn-refresh-discovery" title="Rescan test directory">${icon("refresh")} Rescan</button>
            </div>
          </div>

          <!-- Progress Bar (hidden by default) -->
          <div id="tests-progress-bar-wrap" style="display:none;background:var(--border);height:6px;border-radius:3px;overflow:hidden">
            <div id="tests-progress-bar-fill" style="display:flex;height:100%;width:100%">
              <div id="tests-bar-pass" style="background:var(--green);width:0%"></div>
              <div id="tests-bar-fail" style="background:var(--red);width:0%"></div>
            </div>
          </div>

          <!-- Main Results Pane -->
          <div id="tests-main-pane"></div>
        </div>
      </div>
    `;

    const mainPane = $("#tests-main-pane", container);
    const summaryBar = $("#tests-summary-bar", container);
    const filterInput = $("#tests-filter", container);
    const runBtn = $("#tests-run-btn", container);
    const runFailedBtn = $("#tests-run-failed-btn", container);
    const failedCntSpan = $("#tests-failed-cnt", container);
    const treePane = $("#tests-tree-pane", container);
    const runnerBadge = $("#tests-runner-badge", container);
    const treeFilterInput = $("#tests-tree-filter", container);
    const progressBarWrap = $("#tests-progress-bar-wrap", container);
    const barPass = $("#tests-bar-pass", container);
    const barFail = $("#tests-bar-fail", container);

    filterInput.addEventListener("input", (e) => {
      filterQuery = e.target.value.trim();
    });

    filterInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        runTests(filterQuery);
      }
    });

    runBtn.addEventListener("click", () => runTests(filterQuery));

    runFailedBtn?.addEventListener("click", () => {
      if (!lastFailedCases.length) return;
      const filter = lastFailedCases.map((c) => c.name).join("|");
      filterInput.value = filter;
      filterQuery = filter;
      runTests(filter);
    });

    $("#tests-stop-on-fail-toggle", container)?.addEventListener("change", (e) => {
      stopOnFailure = e.target.checked;
    });

    $("#tests-btn-refresh-discovery", container)?.addEventListener("click", () => {
      discover();
    });

    treeFilterInput?.addEventListener("input", (e) => {
      renderTree(e.target.value.toLowerCase().trim());
    });

    container.addEventListener("click", (e) => {
      const openBtn = e.target.closest("[data-open-file]");
      if (openBtn) {
        const file = openBtn.dataset.openFile;
        const line = openBtn.dataset.line;
        LD.call("open_file", { file, line }).catch(() => {});
        return;
      }
      const singleBtn = e.target.closest("[data-run-single]");
      if (singleBtn) {
        const testName = singleBtn.dataset.runSingle;
        filterInput.value = testName;
        filterQuery = testName;
        runTests(testName);
        return;
      }
      const runFileBtn = e.target.closest("[data-run-file]");
      if (runFileBtn) {
        const fname = runFileBtn.dataset.runFile;
        filterInput.value = fname;
        filterQuery = fname;
        runTests(fname);
        return;
      }
    });

    async function discover() {
      try {
        const res = await LD.call("tests_discover", { name: site.name });
        discoveryData = res;
        runnerBadge.textContent = res.runner || "PHPUnit";
        if (res.runner === "pest") {
          runnerBadge.style.color = "var(--green)";
        }
        renderTree();
      } catch (err) {
        treePane.innerHTML = `<div class="muted xs" style="padding:10px;color:var(--red)">Failed to discover: ${esc(err.message)}</div>`;
      }
    }

    function renderTree(filterText = "") {
      if (!discoveryData || !discoveryData.suites) return;
      const suites = discoveryData.suites;

      const html = suites.map((s) => {
        const matchedFiles = s.files.filter((f) => !filterText || f.name.toLowerCase().includes(filterText) || f.tests.some((t) => t.name.toLowerCase().includes(filterText)));
        if (!matchedFiles.length) return "";

        return `
          <div style="display:flex;flex-direction:column;gap:4px">
            <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:0.04em;padding:4px 2px;display:flex;align-items:center;justify-content:space-between">
              <span>${esc(s.name)}</span>
              <span class="chip xs muted">${matchedFiles.length} files</span>
            </div>
            ${matchedFiles.map((f) => `
              <div style="background:var(--surface-2);border-radius:6px;padding:6px 8px;border:1px solid var(--border)">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:6px">
                  <span style="font-family:var(--mono);font-size:11.5px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(f.rel_path)}">
                    ${esc(f.name)}
                  </span>
                  <div style="display:flex;align-items:center;gap:4px">
                    <span class="chip xs" style="font-size:10px">${f.test_count}</span>
                    <button class="btn xs ghost icon-btn" data-run-file="${esc(f.name)}" title="Run ${esc(f.name)}" aria-label="Run file">${icon("play")}</button>
                  </div>
                </div>
                ${f.tests && f.tests.length ? `
                  <div style="margin-top:4px;padding-left:6px;border-left:2px solid var(--border);display:flex;flex-direction:column;gap:2px">
                    ${f.tests.slice(0, 5).map((t) => `
                      <div style="display:flex;align-items:center;justify-content:space-between;font-size:11px;color:var(--text-muted)">
                        <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:160px" title="${esc(t.name)}">${esc(t.name)}</span>
                        <button class="btn xs ghost icon-btn" data-run-single="${esc(t.name)}" style="padding:0 2px" title="Run test">${icon("play")}</button>
                      </div>
                    `).join("")}
                    ${f.tests.length > 5 ? `<span class="muted xs">+${f.tests.length - 5} more</span>` : ""}
                  </div>
                ` : ""}
              </div>
            `).join("")}
          </div>
        `;
      }).join("");

      treePane.innerHTML = html || `<div class="muted xs" style="padding:14px;text-align:center">No test suites found</div>`;
    }

    async function runTests(filter = "") {
      if (isRunning) return;
      isRunning = true;
      runBtn.disabled = true;
      runBtn.innerHTML = `${icon("pulse")}Running…`;
      progressBarWrap.style.display = "none";
      mainPane.innerHTML = `
        <div class="card" style="text-align:center;padding:36px">
          <div class="loading-pane">${icon("pulse")}Running test suite with JUnit XML log…</div>
        </div>
      `;

      try {
        const withCoverage = $("#tests-coverage-toggle", container)?.checked;
        const res = await LD.call("tests_run", {
          name: site.name,
          filter,
          coverage: withCoverage,
          stop_on_failure: stopOnFailure,
        });
        activeTestsResults = res;
        renderResults(res);
      } catch (err) {
        mainPane.innerHTML = `
          <div class="card" style="padding:24px;text-align:center">
            <p style="color:var(--red);margin-bottom:12px">${icon("alert")} Failed to execute tests: ${esc(err.message)}</p>
            <button class="btn sm" id="tests-retry-btn">${icon("refresh")}Try Again</button>
          </div>
        `;
        $("#tests-retry-btn", mainPane)?.addEventListener("click", () => runTests(filter));
      } finally {
        isRunning = false;
        runBtn.disabled = false;
        runBtn.innerHTML = `${icon("play")}Run Tests`;
      }
    }

    function renderResults(res) {
      if (!res.ok && (!res.cases || !res.cases.length)) {
        summaryBar.innerHTML = `<span class="chip sm" style="color:var(--red)">Execution Failed</span>`;
        mainPane.innerHTML = `
          <div class="card">
            <h3 style="color:var(--red)">${icon("alert")} Execution Error</h3>
            <p class="muted sm">${esc(res.error || "No test output available.")}</p>
            ${res.raw_output ? `<pre class="terminal" style="max-height:280px;overflow-y:auto">${esc(res.raw_output)}</pre>` : ""}
          </div>
        `;
        return;
      }

      lastFailedCases = (res.cases || []).filter((c) => c.status === "failed" || c.status === "error");
      if (lastFailedCases.length > 0) {
        runFailedBtn.style.display = "inline-flex";
        failedCntSpan.textContent = lastFailedCases.length;
      } else {
        runFailedBtn.style.display = "none";
      }

      // Progress bar
      const total = res.total || 0;
      if (total > 0) {
        progressBarWrap.style.display = "block";
        const passPct = Math.round((res.passed / total) * 100);
        const failPct = Math.round(((res.failed + res.errors) / total) * 100);
        barPass.style.width = `${passPct}%`;
        barFail.style.width = `${failPct}%`;
      } else {
        progressBarWrap.style.display = "none";
      }

      let covChip = "";
      if (res.coverage) {
        if (res.coverage.ok) {
          covChip = `<span class="chip sm" style="font-weight:700;color:var(--green)">Coverage: ${res.coverage.percent}%</span>`;
        } else {
          covChip = `<span class="chip sm text-amber" title="${esc(res.coverage.error || '')}">No Coverage</span>`;
        }
      }

      summaryBar.innerHTML = `
        <span class="chip sm" style="color:var(--green);font-weight:700">${res.passed} passed</span>
        ${res.failed || res.errors ? `<span class="chip sm" style="color:var(--red);font-weight:700">${res.failed + res.errors} failed</span>` : ""}
        ${res.skipped ? `<span class="chip sm muted">${res.skipped} skipped</span>` : ""}
        ${covChip}
        <span class="chip sm" style="font-family:var(--mono)">${res.time}s</span>
      `;

      let coverageCardHtml = "";
      if (res.coverage && res.coverage.ok) {
        coverageCardHtml = `
          <div class="card" style="margin-bottom:12px;padding:12px 16px;background:var(--surface-2)">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
              <b>${icon("chart")} Code Coverage: ${res.coverage.percent}%</b>
              <span class="muted sm">${res.coverage.covered_statements} / ${res.coverage.statements} statements</span>
            </div>
            <div style="background:var(--border);height:6px;border-radius:3px;overflow:hidden;margin-bottom:8px">
              <div style="background:var(--green);height:100%;width:${Math.min(res.coverage.percent, 100)}%"></div>
            </div>
            <details>
              <summary class="muted sm" style="cursor:pointer">Per-file breakdown (${(res.coverage.files || []).length} files)</summary>
              <div style="margin-top:8px;display:flex;flex-direction:column;gap:3px;max-height:180px;overflow-y:auto">
                ${(res.coverage.files || []).map((f) => `
                  <div style="display:flex;align-items:center;justify-content:space-between;font-size:12px;padding:3px 0;border-bottom:1px solid var(--border)">
                    <span style="font-family:var(--mono)">${esc(f.file)}</span>
                    <span class="chip xs ${f.percent >= 80 ? 'text-green' : (f.percent >= 50 ? 'text-amber' : 'text-red')}" style="font-weight:700">${f.percent}%</span>
                  </div>
                `).join("")}
              </div>
            </details>
          </div>
        `;
      }

      const casesHtml = (res.cases || []).map((c) => {
        const passed = c.status === "passed";
        const skipped = c.status === "skipped";
        const statusColor = passed ? "var(--green)" : (skipped ? "var(--muted)" : "var(--red)");
        const statusIcon = passed ? "check" : (skipped ? "minus" : "alert");

        return `
          <div class="card" style="margin-bottom:8px;padding:12px 16px;border-left:4px solid ${statusColor}">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
              <div style="display:flex;align-items:center;gap:8px">
                <span style="color:${statusColor}">${icon(statusIcon)}</span>
                <b>${esc(c.name)}</b>
                ${c.class ? `<span class="muted sm">(${esc(c.class)})</span>` : ""}
              </div>
              <div style="display:flex;align-items:center;gap:6px">
                <span class="chip sm" style="font-family:var(--mono)">${c.time}s</span>
                <button class="btn sm ghost icon-btn" data-run-single="${esc(c.name)}" title="Run this test only" aria-label="Run this test only">${icon("play")}</button>
              </div>
            </div>

            ${!passed && !skipped ? `
              <div style="margin-top:10px;display:flex;flex-direction:column;gap:8px">
                <!-- Assertion Diff View if available -->
                ${c.expected || c.actual ? `
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px">
                    <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:6px;padding:8px">
                      <b style="color:var(--green);font-size:11px;text-transform:uppercase">Expected</b>
                      <pre style="margin:4px 0 0;font-family:var(--mono);font-size:11.5px;white-space:pre-wrap;max-height:160px;overflow-y:auto">${esc(c.expected || '')}</pre>
                    </div>
                    <div style="background:var(--surface-2);border:1px solid var(--red);border-radius:6px;padding:8px">
                      <b style="color:var(--red);font-size:11px;text-transform:uppercase">Actual</b>
                      <pre style="margin:4px 0 0;font-family:var(--mono);font-size:11.5px;color:var(--red);white-space:pre-wrap;max-height:160px;overflow-y:auto">${esc(c.actual || '')}</pre>
                    </div>
                  </div>
                ` : ""}

                <!-- Failure Message & Trace -->
                ${c.message ? `
                  <pre style="background:var(--surface-2);color:var(--red);padding:10px;border-radius:6px;font-size:11.5px;font-family:var(--mono);overflow-x:auto;white-space:pre-wrap;margin:0">${esc(c.message)}</pre>
                ` : ""}

                ${c.file ? `
                  <div style="display:flex;align-items:center;gap:8px">
                    <button class="btn sm ghost" data-open-file="${esc(c.file)}" data-line="${esc(c.line || '1')}">
                      ${icon("code")}Open in editor (${esc(c.file.split(/[\\/]/).pop())}:${esc(c.line || '1')})
                    </button>
                  </div>
                ` : ""}
              </div>
            ` : ""}
          </div>
        `;
      }).join("") || `<div class="card muted sm" style="text-align:center;padding:24px">No test cases matched filter.</div>`;

      mainPane.innerHTML = `
        ${coverageCardHtml}
        <div style="display:flex;flex-direction:column;gap:4px">
          ${casesHtml}
        </div>
        ${res.raw_output ? `
          <details style="margin-top:14px">
            <summary class="muted sm" style="cursor:pointer">Console Output</summary>
            <pre class="terminal" style="margin-top:8px;max-height:240px;overflow-y:auto">${esc(res.raw_output)}</pre>
          </details>
        ` : ""}
      `;
    }

    if (activeTestsResults) {
      renderResults(activeTestsResults);
    } else {
      mainPane.innerHTML = `
        <div class="card" style="text-align:center;padding:36px">
          <div style="width:48px;height:48px;margin:0 auto 14px;border-radius:50%;background:var(--surface-2);display:grid;place-items:center;color:var(--accent)">
            ${icon("sparkles")}
          </div>
          <h3 style="margin:0 0 6px">Run Your Test Suite</h3>
          <p class="muted sm" style="margin:0 0 16px;max-width:380px;display:inline-block">
            Execute Pest or PHPUnit tests and view structured assertions, failure traces, assertion diffs, and code coverage.
          </p>
          <div>
            <button class="btn primary sm" id="tests-run-first-btn">${icon("play")}Run All Tests</button>
          </div>
        </div>
      `;
      $("#tests-run-first-btn", mainPane)?.addEventListener("click", () => runTests());
    }

    discover();
  }

  // ── Performance Monitor & Profiler (Phase 6) ─────────────────────────────
  let activePerfPoller = null;
  let activePerfContainer = null;
  let activePerfSite = null;
  let activePerfRefreshFn = null;

  async function mountPerf(container, site) {
    currentSite = site;
    activePerfContainer = container;
    activePerfSite = site;
    if (activePerfPoller) {
      activePerfPoller.stop();
      activePerfPoller = null;
    }

    let activeCategory = "requests"; // "requests", "queries", "errors", "slow"
    let filterAssets = true;
    let statusFilter = "";
    let minDuration = 0;
    let searchQuery = "";
    let lastFeedData = null;

    container.innerHTML = `
      <div class="perf-container">
        <!-- Telescope Header Navigation Bar -->
        <div class="card" style="margin-bottom:12px;padding:12px 16px">
          <div class="telescope-header-bar" style="margin-bottom:10px">
            <div class="telescope-nav-pills" role="tablist">
              <button class="telescope-nav-pill active" data-cat="requests" role="tab" aria-selected="true">
                ${icon("globe")} ${window.t ? window.t("requests", "Requests") : "Requests"}
                <span class="chip sm" id="pill-count-requests">0</span>
              </button>
              <button class="telescope-nav-pill" data-cat="queries" role="tab" aria-selected="false">
                ${icon("database")} ${window.t ? window.t("queries", "Queries") : "Queries"}
                <span class="chip sm" id="pill-count-queries">0</span>
              </button>
              <button class="telescope-nav-pill" data-cat="errors" role="tab" aria-selected="false">
                ${icon("alert")} ${window.t ? window.t("errors", "Errors") : "Errors"}
                <span class="chip sm" id="pill-count-errors">0</span>
              </button>
              <button class="telescope-nav-pill" data-cat="slow" role="tab" aria-selected="false">
                ${icon("clock")} ${window.t ? window.t("slow", "Slow (>100ms)") : "Slow (>100ms)"}
                <span class="chip sm" id="pill-count-slow">0</span>
              </button>
              <button class="telescope-nav-pill" data-cat="http_client" role="tab" aria-selected="false">
                ${icon("share")} HTTP Mocks &amp; Calls
                <span class="chip sm" id="pill-count-http">0</span>
              </button>
              <button class="telescope-nav-pill" data-cat="webhooks" role="tab" aria-selected="false">
                ${icon("cloud")} ${window.t ? window.t("webhooks", "Webhooks") : "Webhooks"}
                <span class="chip sm" id="pill-count-webhooks">0</span>
              </button>
            </div>

            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
              <span class="chip sm info" id="telescope-framework-badge" style="font-weight:600">Framework</span>
              <span class="chip sm ok" style="display:inline-flex;align-items:center;gap:6px" title="Real-time request streaming active">
                <span class="telescope-live-dot"></span>
                <span>Live</span>
              </span>
              <div id="perf-profiler-toggle-wrap" style="display:flex;align-items:center;gap:6px">
                <label class="row" style="margin:0;gap:6px;cursor:pointer" title="Zero-overhead profiler for deep Eloquent SQL metrics">
                  <span style="font-size:12px;font-weight:550">${window.t ? window.t("live_profiler", "Live Profiler") : "Live Profiler"}</span>
                  <input type="checkbox" class="switch" id="perf-profiler-switch">
                </label>
              </div>
              <button class="btn sm ghost danger icon-btn" id="perf-clear-btn" title="Clear request history" aria-label="Clear request history">${icon("trash")}</button>
              <button class="btn sm ghost" id="perf-refresh-btn">${icon("refresh")} ${window.t ? window.t("refresh", "Refresh") : "Refresh"}</button>
            </div>
          </div>

          <!-- Dynamic Filters Strip -->
          <div id="perf-filters-strip" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding-top:10px;border-top:1px solid var(--border)">
            <input type="search" id="perf-search-input" placeholder="Search URI, route, or SQL query…" style="height:30px;font-size:12px;max-width:260px">
            <select id="perf-status-select" style="height:30px;font-size:12px">
              <option value="">All Statuses</option>
              <option value="2xx">2xx Success</option>
              <option value="3xx">3xx Redirect</option>
              <option value="4xx">4xx Client Error</option>
              <option value="5xx">5xx Server Error</option>
              <option value="404">404 Not Found</option>
              <option value="500">500 Server Error</option>
            </select>
            <select id="perf-duration-select" style="height:30px;font-size:12px">
              <option value="0">All Durations</option>
              <option value="50">&gt; 50 ms</option>
              <option value="100">&gt; 100 ms</option>
              <option value="250">&gt; 250 ms</option>
              <option value="500">&gt; 500 ms</option>
              <option value="1000">&gt; 1 s</option>
            </select>
            <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;margin:0">
              <input type="checkbox" id="perf-filter-assets-chk" checked>
              <span>${window.t ? window.t("filter_assets", "Filter static assets") : "Filter static assets"}</span>
            </label>
          </div>
        </div>

        <!-- Summary Stats Grid -->
        <div class="perf-stats-grid" id="perf-stats-grid"></div>

        <!-- Main Content Area -->
        <div id="perf-main-pane">
          <div class="loading-pane">${icon("pulse")} Loading Telescope feed…</div>
        </div>

      </div>
    `;

    const navPills = $$(".telescope-nav-pill", container);
    const pillCountRequests = $("#pill-count-requests", container);
    const pillCountQueries = $("#pill-count-queries", container);
    const pillCountErrors = $("#pill-count-errors", container);
    const pillCountSlow = $("#pill-count-slow", container);
    const pillCountWebhooks = $("#pill-count-webhooks", container);
    const frameworkBadge = $("#telescope-framework-badge", container);

    const profilerToggleWrap = $("#perf-profiler-toggle-wrap", container);
    const profilerSwitch = $("#perf-profiler-switch", container);
    const clearBtn = $("#perf-clear-btn", container);
    const refreshBtn = $("#perf-refresh-btn", container);

    const searchInput = $("#perf-search-input", container);
    const statusSelect = $("#perf-status-select", container);
    const durationSelect = $("#perf-duration-select", container);
    const filterAssetsChk = $("#perf-filter-assets-chk", container);

    const statsGrid = $("#perf-stats-grid", container);
    const mainPane = $("#perf-main-pane", container);


    // Nav pill category switches
    navPills.forEach(pill => {
      pill.addEventListener("click", () => {
        const cat = pill.dataset.cat;
        if (cat === activeCategory) return;
        activeCategory = cat;
        navPills.forEach(p => {
          const isActive = p.dataset.cat === cat;
          p.classList.toggle("active", isActive);
          p.setAttribute("aria-selected", isActive ? "true" : "false");
        });
        loadView();
      });
    });

    async function checkProfilerStatus() {
      try {
        const st = await LD.call("perf_status", { name: site.name });
        profilerSwitch.checked = !!st.profiler_active;
        if (st.profiler_supported === false) {
          profilerToggleWrap.style.display = "none";
        } else {
          profilerToggleWrap.style.display = "flex";
          profilerSwitch.title = st.profiler_installed
            ? "Toggle live deep Eloquent query profiler"
            : "Enable to install and activate the Laravel Dev profiler";
        }
        return st;
      } catch (e) {
        return null;
      }
    }

    profilerSwitch.addEventListener("change", async () => {
      const enable = profilerSwitch.checked;
      if (enable) {
        const ok = await confirmModal({
          title: "Enable the SQL profiler?",
          message: `This runs <code>composer require --dev laravel-dev/profiler</code> in ${esc(site.name)}.
            <code>composer.json</code> will point at a folder on this machine, so <b>don't commit that change</b>
            — turn the profiler off before committing, or leave composer.json/composer.lock out of the commit.`,
          confirm: "Enable",
        });
        if (!ok) { profilerSwitch.checked = false; return; }
      }
      profilerSwitch.disabled = true;
      // composer runs as a task: its output streams into Activity, and the switch
      // settles on the real state once the task ends.
      const task = await runAction("profiler", { name: site.name, op: enable ? "enable" : "disable" });
      if (!task) {
        profilerSwitch.checked = !enable;
        profilerSwitch.disabled = false;
        return;
      }
      const onDone = async (e) => {
        if (e.detail.id !== task.id) return;
        window.removeEventListener("ld:task-done", onDone);
        const st = await checkProfilerStatus();
        profilerSwitch.disabled = false;
        if (e.detail.status === "success" && st && !!st.profiler_active === enable) {
          if (enable) toast("info", "Profiler is on", "Open a page of the site to see its queries here.");
          loadView();
        }
      };
      window.addEventListener("ld:task-done", onDone);
    });

    clearBtn.addEventListener("click", async () => {
      await LD.call("perf_clear", { name: site.name });
      toast("info", "Performance history cleared");
      loadView();
    });

    refreshBtn.addEventListener("click", () => loadView());

    searchInput.addEventListener("input", () => {
      searchQuery = searchInput.value;
      loadView();
    });

    statusSelect.addEventListener("change", () => {
      statusFilter = statusSelect.value;
      loadView();
    });

    durationSelect.addEventListener("change", () => {
      minDuration = parseFloat(durationSelect.value) || 0;
      loadView();
    });

    filterAssetsChk.addEventListener("change", () => {
      filterAssets = filterAssetsChk.checked;
      loadView();
    });

    async function loadView() {
      try {
        const feed = await LD.call("perf_telescope", {
          name: site.name,
          category: activeCategory,
          limit: 100,
          search: searchQuery,
          status: statusFilter,
          min_duration_ms: minDuration,
          filter_assets: filterAssets,
        });

        lastFeedData = feed;
        const s = feed.summary || {};
        let repairNote = $("#perf-repair-note", container);
        if (feed.nginx_needs_repair && !repairNote) {
          repairNote = document.createElement("div");
          repairNote.id = "perf-repair-note";
          repairNote.className = "card warn-pane";
          repairNote.style.cssText = "display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:12px";
          repairNote.innerHTML = `<div style="display:flex;gap:10px;align-items:flex-start;font-size:12.5px">${icon("alert")}<span>${esc(feed.nginx_hint)}</span></div>
            <button class="btn sm primary" data-perf-repair>${icon("wrench")}Repair ${esc(site.name)}</button>`;
          statsGrid.before(repairNote);
          $("[data-perf-repair]", repairNote).addEventListener("click", () => runAction("repair", { name: site.name }));
        } else if (!feed.nginx_needs_repair && repairNote) {
          repairNote.remove();
        }
        const fw = feed.framework || site.type_label || "Web App";

        frameworkBadge.textContent = fw;
        pillCountRequests.textContent = s.total_requests || 0;
        pillCountQueries.textContent = s.total_queries || 0;

        const errCount = s.error_count || 0;
        pillCountErrors.textContent = errCount;
        pillCountErrors.className = `chip sm ${errCount > 0 ? 'danger' : ''}`;

        const slowCount = (feed.slow || []).length || (s.p95_ms > 100 ? "!" : "0");
        pillCountSlow.textContent = slowCount;
        pillCountSlow.className = `chip sm ${slowCount !== "0" && slowCount !== 0 ? 'warn' : ''}`;

        // Summary Stats Grid
        statsGrid.innerHTML = `
          <div class="perf-stat-card">
            <span class="perf-stat-label">${window.t ? window.t("requests", "Total Requests") : "Total Requests"}</span>
            <span class="perf-stat-val">${s.total_requests || 0}</span>
          </div>
          <div class="perf-stat-card">
            <span class="perf-stat-label">P50 (Median)</span>
            <span class="perf-stat-val ${(s.p50_ms || 0) > 100 ? 'warn' : 'good'}">${s.p50_ms || 0} <small style="font-size:12px;font-weight:normal">ms</small></span>
          </div>
          <div class="perf-stat-card">
            <span class="perf-stat-label">P95 (Peak)</span>
            <span class="perf-stat-val ${(s.p95_ms || 0) > 300 ? 'bad' : ((s.p95_ms || 0) > 100 ? 'warn' : 'good')}">${s.p95_ms || 0} <small style="font-size:12px;font-weight:normal">ms</small></span>
          </div>
          <div class="perf-stat-card">
            <span class="perf-stat-label">${window.t ? window.t("executed_queries", "Database Queries") : "Database Queries"}</span>
            <span class="perf-stat-val">${s.total_queries || 0} ${s.n_plus_one_count > 0 ? `<small style="font-size:11px;color:var(--amber)">(${s.n_plus_one_count} N+1)</small>` : ''}</span>
          </div>
          <div class="perf-stat-card">
            <span class="perf-stat-label">${window.t ? window.t("errors", "Error Rate") : "Error Rate"}</span>
            <span class="perf-stat-val ${(s.error_rate || 0) > 0 ? 'bad' : 'good'}">${s.error_rate || 0}% <small style="font-size:11px;font-weight:normal;color:var(--muted)">(${s.error_count || 0})</small></span>
          </div>
        `;

        if (pillCountWebhooks) {
          LD.call("webhooks_list", { name: site.name, limit: 1 }).then(r => {
            pillCountWebhooks.textContent = (r.webhooks || []).length;
          }).catch(() => {});
        }

        // Render Active Category
        if (activeCategory === "webhooks") {
          statsGrid.style.display = "none";
          document.getElementById("perf-filters-strip")?.style.setProperty("display", "none");
          renderWebhooksView();
          return;
        } else {
          statsGrid.style.display = "grid";
          document.getElementById("perf-filters-strip")?.style.removeProperty("display");
        }

        if (activeCategory === "requests") {
          renderRequestsView(feed.requests || feed.items || []);
        } else if (activeCategory === "queries") {
          renderQueriesView(feed.queries || feed.items || []);
        } else if (activeCategory === "errors") {
          renderErrorsView(feed.errors || feed.items || []);
        } else if (activeCategory === "slow") {
          renderSlowView(feed.slow || feed.items || []);
        } else if (activeCategory === "http_client") {
          renderHttpMocksView();
        }
      } catch (err) {
        mainPane.innerHTML = `<div class="card error-pane">${icon("alert")} Failed to load Telescope feed: ${esc(err.message)}</div>`;
      }
    }

    let knownRequestIds = new Set();
    let querySubfilter = "ALL";

    function formatSql(sql) {
      if (!sql) return "";
      let s = esc(sql);

      // Major SQL keywords
      const keywords = [
        "SELECT", "FROM", "WHERE", "AND", "OR", "JOIN", "LEFT JOIN", "RIGHT JOIN",
        "INNER JOIN", "OUTER JOIN", "CROSS JOIN", "ON", "GROUP BY", "ORDER BY",
        "HAVING", "LIMIT", "OFFSET", "INSERT INTO", "VALUES", "UPDATE", "SET",
        "DELETE FROM", "DELETE", "CREATE TABLE", "DROP TABLE", "ALTER TABLE",
        "INDEX", "AS", "IN", "IS", "NULL", "NOT", "LIKE", "BETWEEN", "EXISTS",
        "UNION", "ALL", "CASE", "WHEN", "THEN", "ELSE", "END", "ASC", "DESC",
        "COUNT", "SUM", "AVG", "MIN", "MAX", "COALESCE", "DISTINCT", "SHOW", "USE"
      ];

      // Highlight strings ('...')
      s = s.replace(/'([^']*)'/g, '<span class="sql-string">\'$1\'</span>');
      // Highlight backticked identifiers (`...`)
      s = s.replace(/`([^`]+)`/g, '<span class="sql-ident">`$1`</span>');
      // Highlight placeholders (?)
      s = s.replace(/\?/g, '<span class="sql-placeholder">?</span>');
      // Highlight numbers
      s = s.replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="sql-number">$1</span>');
      // Highlight keywords
      const kwRegex = new RegExp(`\\b(${keywords.join("|")})\\b`, "gi");
      s = s.replace(kwRegex, (m) => `<span class="sql-kw">${m.toUpperCase()}</span>`);

      return s;
    }

    function interpolateSql(sql, bindings) {
      if (!sql) return "";
      if (!bindings || !bindings.length) return sql;
      const parts = sql.split("?");
      if (parts.length - 1 !== bindings.length) return sql;
      let res = "";
      for (let i = 0; i < parts.length - 1; i++) {
        res += parts[i];
        const b = bindings[i];
        if (b === null || b === undefined) {
          res += "NULL";
        } else if (typeof b === "number") {
          res += b;
        } else if (typeof b === "boolean") {
          res += b ? "1" : "0";
        } else {
          const clean = String(b).replace(/'/g, "''");
          res += `'${clean}'`;
        }
      }
      res += parts[parts.length - 1];
      return res;
    }

    // ── 1. REQUESTS VIEW (All Frameworks) ──────────────────────────────────
    function renderRequestsView(requests) {
      if (!requests.length) {
        mainPane.innerHTML = `
          <div class="telescope-empty-state">
            <div style="font-size:32px;margin-bottom:10px;color:var(--accent)">${icon("globe")}</div>
            <h3>Listening for ${esc(site.domain)} requests…</h3>
            <p class="muted sm" style="max-width:480px;margin:6px auto 16px">
              Telescope captures live HTTP traffic, response times, and database queries across all frameworks (Laravel, Next.js, Nuxt, Django, Express, Vite).
              Open your browser and navigate your application to see live requests here.
            </p>
            <button class="btn primary sm" onclick="window.open('http://${esc(site.domain)}', '_blank')">
              ${icon("browser")} Open http://${esc(site.domain)}
            </button>
          </div>
        `;
        return;
      }

      const maxDuration = Math.max(...requests.map(r => r.duration_ms || 0), 100);

      const rowsHtml = requests.map((r, index) => {
        const m = (r.method || 'GET').toLowerCase();
        const s = Number(r.status || 200);
        const sClass = `s${Math.floor(s / 100)}xx`;
        const pct = Math.min(100, Math.max(5, ((r.duration_ms || 0) / maxDuration) * 100));
        const fillClass = (r.duration_ms || 0) > 300 ? 'slow' : ((r.duration_ms || 0) > 100 ? 'moderate' : 'fast');
        const timeFormatted = r.time_iso ? r.time_iso.replace(/T/, ' ').replace(/\+.*/, '') : '';
        const n1Count = r.n_plus_one_count || 0;
        const qCount = r.query_count || (r.queries ? r.queries.length : 0);
        const isNew = knownRequestIds.size > 0 && !knownRequestIds.has(r.id);

        return `
          <tr class="telescope-request-row ${isNew ? 'telescope-row-new' : ''}" data-inspect-id="${esc(r.id)}" title="Inspect request details">
            <td style="width:70px"><span class="perf-method ${m}">${esc(r.method || 'GET')}</span></td>
            <td style="min-width:200px;max-width:340px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
              <span style="font-family:var(--mono);font-size:12.5px;font-weight:600;color:var(--text)" title="${esc(r.uri || r.path || '/')}">${esc(r.uri || r.path || '/')}</span>
              ${r.route ? `<span class="chip sm muted" style="margin-inline-start:6px;font-family:var(--mono);font-size:10px">${esc(r.route)}</span>` : ''}
              ${r.action ? `<div class="muted sm" style="font-family:var(--mono);font-size:10.5px">${esc(r.action)}</div>` : ''}
            </td>
            <td style="width:75px"><span class="perf-status-badge ${sClass}">${s}</span></td>
            <td style="width:160px">
              <div class="perf-bar-wrapper">
                <div class="perf-bar-track"><div class="perf-bar-fill ${fillClass}" style="width:${pct}%"></div></div>
                <b style="font-size:11px;font-family:var(--mono);width:55px;text-align:right">${r.duration_ms || 0} ms</b>
              </div>
            </td>
            <td style="width:130px">
              ${qCount > 0
                ? `<span class="chip sm" style="font-family:var(--mono)">${icon("database")} ${qCount} (${r.query_time_ms || 0}ms)</span>`
                : (r.upstream_time_ms > 0 ? `<span class="chip sm muted" style="font-family:var(--mono);font-size:11px">App: ${r.upstream_time_ms}ms</span>` : '<span class="muted sm">—</span>')}
              ${n1Count > 0 ? `<span class="chip sm danger" style="margin-inline-start:4px" title="N+1 query bottleneck">N+1</span>` : ''}
            </td>
            <td style="width:80px;font-size:11px;color:var(--muted);font-family:var(--mono)">
              ${r.bytes ? `${Math.round(r.bytes / 1024 * 10) / 10} KB` : (r.memory_peak_mb ? `${r.memory_peak_mb} MB` : '—')}
            </td>
            <td style="width:130px;font-size:11px;color:var(--muted)">${esc(timeFormatted || 'Just now')}</td>
            <td style="width:36px;text-align:right">
              <button class="btn sm ghost icon-btn" title="Inspect Request">${icon("chevron-right")}</button>
            </td>
          </tr>
        `;
      }).join("");

      // Update known IDs
      requests.forEach(r => knownRequestIds.add(r.id));

      mainPane.innerHTML = `
        <div class="card" style="padding:0;overflow:hidden">
          <table class="perf-table">
            <thead>
              <tr>
                <th>Method</th>
                <th>Request Path &amp; Route</th>
                <th>Status</th>
                <th>Response Time</th>
                <th>Queries / App</th>
                <th>Size / Mem</th>
                <th>Timestamp</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
            </tbody>
          </table>
        </div>
      `;

      $$("[data-inspect-id]", mainPane).forEach(row => {
        row.addEventListener("click", () => Inspector.openRequest(site, row.dataset.inspectId, { list: requests, formatSql }));
      });
    }

    // ── 2. QUERIES VIEW (Aggregated SQL with Syntax Highlighting & Types) ───
    function renderQueriesView(queries) {
      if (!queries.length) {
        mainPane.innerHTML = `
          <div class="telescope-empty-state">
            <div style="font-size:32px;margin-bottom:10px;color:var(--accent)">${icon("database")}</div>
            <h3>No Database Queries Captured Yet</h3>
            <p class="muted sm" style="max-width:480px;margin:6px auto 16px">
              ${profilerSwitch.checked
                ? "The live profiler is active! Send database queries or browse dynamic pages on your site to see executed SQL statements, timings, and N+1 bottlenecks."
                : "Enable the Live Profiler above to track Eloquent & SQL queries, execution latency, and N+1 detection in real time."}
            </p>
            ${!profilerSwitch.checked ? `<button class="btn primary sm" id="btn-enable-profiler-queries">${icon("zap")} Enable Live Profiler</button>` : ''}
          </div>
        `;
        $("#btn-enable-profiler-queries", mainPane)?.addEventListener("click", () => {
          profilerSwitch.checked = true;
          profilerSwitch.dispatchEvent(new Event("change"));
        });
        return;
      }

      // Counts per query type
      const counts = {
        ALL: queries.length,
        SELECT: queries.filter(q => (q.query_type || '').toUpperCase() === 'SELECT').length,
        INSERT: queries.filter(q => (q.query_type || '').toUpperCase() === 'INSERT').length,
        UPDATE: queries.filter(q => (q.query_type || '').toUpperCase() === 'UPDATE').length,
        DELETE: queries.filter(q => (q.query_type || '').toUpperCase() === 'DELETE').length,
        SLOW: queries.filter(q => q.slow || (q.avg_time_ms || 0) >= 50).length,
        N1: queries.filter(q => q.is_n_plus_one).length,
      };

      // Filtered queries list
      let filtered = queries;
      if (querySubfilter === "SELECT") filtered = queries.filter(q => (q.query_type || '').toUpperCase() === 'SELECT');
      else if (querySubfilter === "INSERT") filtered = queries.filter(q => (q.query_type || '').toUpperCase() === 'INSERT');
      else if (querySubfilter === "UPDATE") filtered = queries.filter(q => (q.query_type || '').toUpperCase() === 'UPDATE');
      else if (querySubfilter === "DELETE") filtered = queries.filter(q => (q.query_type || '').toUpperCase() === 'DELETE');
      else if (querySubfilter === "SLOW") filtered = queries.filter(q => q.slow || (q.avg_time_ms || 0) >= 50);
      else if (querySubfilter === "N1") filtered = queries.filter(q => q.is_n_plus_one);

      const filterBarHtml = `
        <div class="telescope-subfilter-bar">
          <button class="telescope-subfilter-btn ${querySubfilter === 'ALL' ? 'active' : ''}" data-qf="ALL">All (${counts.ALL})</button>
          <button class="telescope-subfilter-btn ${querySubfilter === 'SELECT' ? 'active' : ''}" data-qf="SELECT">SELECT (${counts.SELECT})</button>
          <button class="telescope-subfilter-btn ${querySubfilter === 'INSERT' ? 'active' : ''}" data-qf="INSERT">INSERT (${counts.INSERT})</button>
          <button class="telescope-subfilter-btn ${querySubfilter === 'UPDATE' ? 'active' : ''}" data-qf="UPDATE">UPDATE (${counts.UPDATE})</button>
          <button class="telescope-subfilter-btn ${querySubfilter === 'DELETE' ? 'active' : ''}" data-qf="DELETE">DELETE (${counts.DELETE})</button>
          <button class="telescope-subfilter-btn ${querySubfilter === 'SLOW' ? 'active' : ''}" data-qf="SLOW">Slow &gt;50ms (${counts.SLOW})</button>
          <button class="telescope-subfilter-btn ${querySubfilter === 'N1' ? 'active' : ''}" data-qf="N1">N+1 Alerts (${counts.N1})</button>
        </div>
      `;

      if (!filtered.length) {
        mainPane.innerHTML = `
          ${filterBarHtml}
          <div class="telescope-empty-state">
            <h4>No queries match the selected filter "${esc(querySubfilter)}"</h4>
          </div>
        `;
        bindSubfilters();
        return;
      }

      const cardsHtml = filtered.map((q, idx) => {
        const isSlow = q.slow || q.avg_time_ms >= 50;
        const isN1 = q.is_n_plus_one || q.count >= 5;
        const isDupe = q.is_duplicate || q.count > 1;
        const speedClass = q.speed?.css || (q.avg_time_ms < 5 ? 'speed-fast' : (q.avg_time_ms < 30 ? 'speed-normal' : (q.avg_time_ms < 100 ? 'speed-moderate' : 'speed-slow')));
        const qType = (q.query_type || 'query').toLowerCase();
        const interp = q.interpolated_sql || interpolateSql(q.sql, q.bindings) || q.sql;

        return `
          <div class="telescope-query-card" id="q-card-${idx}" data-q-idx="${idx}" tabindex="0" title="Open in inspector">
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px">
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <span class="query-badge ${qType}">${esc(q.query_type || 'SQL')}</span>
                <span class="chip sm ${speedClass}" style="font-family:var(--mono);font-weight:700" title="Execution latency">${q.avg_time_ms} ms</span>
                <span class="telescope-query-count-badge">${icon("database")} Executed ${q.count} ${q.count === 1 ? 'time' : 'times'}</span>
                <span class="chip sm" style="font-family:var(--mono);font-size:11px">Total: <b>${q.total_time_ms} ms</b></span>
                ${isSlow ? `<span class="chip sm danger">${icon("clock")} Slow</span>` : ''}
                ${isN1 ? `<span class="chip sm danger">${icon("alert")} N+1 Bottleneck</span>` : ''}
                ${isDupe ? `<span class="chip sm warn" title="Identical query executed multiple times">Duplicate</span>` : ''}
                <span class="chip sm muted" style="font-size:11px">${esc(q.connection || 'default')}</span>
              </div>
              <div style="display:flex;align-items:center;gap:6px">
                <button class="btn sm ghost" data-toggle-sql="${idx}" title="Toggle between raw SQL and interpolated bindings">${icon("zap")} <span class="toggle-label">Raw SQL</span></button>
                <button class="btn sm ghost" data-copy-sql="${esc(interp)}" title="Copy executable SQL statement">${icon("copy")} Copy</button>
                <button class="btn sm ghost" data-explain-sql="${esc(interp)}" title="Explain SQL query plan in Database manager">${icon("search")} ${window.t ? window.t("explain_query", "Explain") : "Explain"}</button>
                ${q.file ? `
                  <button class="btn sm ghost" data-open-editor="${esc(q.file)}" data-line="${esc(q.line || 1)}" title="Open query caller in code editor">
                    ${icon("code")} ${esc(q.file.split(/[\\/]/).pop())}:${esc(q.line || 1)}
                  </button>
                ` : ''}
              </div>
            </div>

            <pre class="sql-highlight" id="sql-view-${idx}" data-raw="${esc(q.sql)}" data-interpolated="${esc(interp)}" data-mode="interpolated">${formatSql(interp)}</pre>

            ${q.bindings && q.bindings.length ? `
              <div class="muted sm" style="font-family:var(--mono);font-size:11px;margin-bottom:6px">
                Bindings: [${q.bindings.map(b => JSON.stringify(b)).join(", ")}]
              </div>
            ` : ''}

            ${q.recent_requests && q.recent_requests.length ? `
              <div class="muted sm" style="font-size:11px;display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                <span>Triggered on:</span>
                ${q.recent_requests.map(u => `<code style="font-size:10.5px">${esc(u)}</code>`).join(" ")}
              </div>
            ` : ''}
          </div>
        `;
      }).join("");

      mainPane.innerHTML = `
        ${filterBarHtml}
        <div>${cardsHtml}</div>
      `;

      bindSubfilters();

      // Bind Toggle Interpolated / Raw SQL
      $$("[data-toggle-sql]", mainPane).forEach(btn => {
        btn.addEventListener("click", () => {
          const idx = btn.dataset.toggleSql;
          const pre = $(`#sql-view-${idx}`, mainPane);
          const label = $(".toggle-label", btn);
          if (!pre) return;
          if (pre.dataset.mode === "interpolated") {
            pre.dataset.mode = "raw";
            pre.innerHTML = formatSql(pre.dataset.raw);
            if (label) label.textContent = "Interpolated";
          } else {
            pre.dataset.mode = "interpolated";
            pre.innerHTML = formatSql(pre.dataset.interpolated);
            if (label) label.textContent = "Raw SQL";
          }
        });
      });

      // Bind Copy SQL
      $$("[data-copy-sql]", mainPane).forEach(btn => {
        btn.addEventListener("click", () => {
          copyText(btn.dataset.copySql);
          toast("success", "SQL copied to clipboard");
        });
      });

      // A card opens the query inspector; its own buttons keep their actions.
      $$("[data-q-idx]", mainPane).forEach(card => {
        const open = (tab) => Inspector.openQuery(site, filtered[Number(card.dataset.qIdx)], { list: filtered, formatSql, tab });
        card.addEventListener("click", (e) => { if (!e.target.closest("button, a")) open(); });
        card.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target === card) open(); });
        $("[data-explain-sql]", card)?.addEventListener("click", () => open("explain"));
      });

      // Bind Open Editor
      $$("[data-open-editor]", mainPane).forEach(btn => {
        btn.addEventListener("click", () => {
          const p = btn.dataset.openEditor;
          const l = parseInt(btn.dataset.line || "1", 10);
          LD.call("open_file", { name: site.name, path: p, line: l }).catch(e => toast("error", "Couldn't open file", e.message));
        });
      });

      function bindSubfilters() {
        $$("[data-qf]", mainPane).forEach(btn => {
          btn.addEventListener("click", () => {
            querySubfilter = btn.dataset.qf;
            renderQueriesView(queries);
          });
        });
      }
    }

    // ── 3. ERRORS VIEW (4xx and 5xx) ───────────────────────────────────────
    function renderErrorsView(errors) {
      if (!errors.length) {
        mainPane.innerHTML = `
          <div class="telescope-empty-state">
            <div style="font-size:32px;margin-bottom:10px;color:var(--green)">${icon("check-circle")}</div>
            <h3>No HTTP Errors Recorded</h3>
            <p class="muted sm" style="max-width:440px;margin:6px auto">
              Everything is running smoothly! No 4xx client errors or 5xx server exceptions have been encountered on ${esc(site.domain)}.
            </p>
          </div>
        `;
        return;
      }
      renderRequestsView(errors);
    }

    // ── 4. SLOW REQUESTS VIEW (>100ms) ────────────────────────────────────
    function renderSlowView(slowRequests) {
      if (!slowRequests.length) {
        mainPane.innerHTML = `
          <div class="telescope-empty-state">
            <div style="font-size:32px;margin-bottom:10px;color:var(--green)">${icon("zap")}</div>
            <h3>No Slow Requests Detected</h3>
            <p class="muted sm" style="max-width:440px;margin:6px auto">
              All requests to ${esc(site.domain)} responded in under 100ms. Blazing fast!
            </p>
          </div>
        `;
        return;
      }
      renderRequestsView(slowRequests);
    }

    // ── 5. OUTGOING HTTP MOCKS & CALLS VIEW (Feature 11) ───────────────────
    async function renderHttpMocksView() {
      mainPane.innerHTML = `<div class="loading-pane sm">${icon("pulse")} Loading HTTP mocks & outgoing calls...</div>`;

      try {
        const [mocksRes, logsRes] = await Promise.all([
          LD.call("http_mocks_list", { name: site.name }),
          LD.call("http_outgoing_logs", { name: site.name }),
        ]);

        const rules = mocksRes.rules || [];
        const calls = logsRes.calls || [];

        const httpCountBadge = $("#pill-count-http", container);
        if (httpCountBadge) httpCountBadge.textContent = rules.length + calls.length;

        mainPane.innerHTML = `
          <div style="display:flex;flex-direction:column;gap:16px">
            <div class="card" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
              <div>
                <h3 style="margin:0 0 4px 0">${icon("share")} Outgoing HTTP Mock &amp; Interceptor</h3>
                <div class="muted" style="font-size:12px">Active rules: <b>${rules.filter(r => r.enabled).length}</b> · Recorded external calls: <b>${calls.length}</b></div>
              </div>
              <div style="display:flex;gap:8px">
                <button id="btn-new-mock-rule" class="btn sm primary">${icon("plus")} Add Mock Rule</button>
              </div>
            </div>

            ${mocksRes.profiler_installed ? "" : `
              <div class="card warn-pane" style="display:flex;gap:10px;align-items:flex-start">
                ${icon("alert")}
                <div style="font-size:12.5px">
                  <b>Rules aren't applied yet.</b> Mocking and call recording run inside the Laravel Dev profiler package.
                  Enable it from the <b>Performance</b> tab; rules then apply to web requests, queue jobs and artisan commands.
                </div>
              </div>`}

            <div class="card">
              <h4 style="margin:0 0 10px 0">${icon("code")} Mock Rules</h4>
              ${!rules.length ? `<div class="muted sm" style="padding:16px 0">No mock rules active. Click "Add Mock Rule" to fake third-party APIs (Stripe, OpenAI, GitHub, etc.)</div>` : `
                <div style="display:flex;flex-direction:column;gap:8px">
                  ${rules.map(r => `
                    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:var(--surface-2);border-radius:6px;border:1px solid var(--border);flex-wrap:wrap;gap:10px">
                      <div style="display:flex;align-items:center;gap:10px">
                        <span class="perf-method ${(r.method || 'get').toLowerCase()}">${esc(r.method || '*')}</span>
                        <code style="font-size:13px;font-family:var(--mono)">${esc(r.url_pattern)}</code>
                        <span class="badge sm ok" style="font-size:11px">Status ${r.status || 200}</span>
                      </div>
                      <div style="display:flex;align-items:center;gap:10px">
                        <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer">
                          <span>${r.enabled ? "Active" : "Disabled"}</span>
                          <input type="checkbox" class="switch" data-toggle-rule="${esc(r.id)}" ${r.enabled ? "checked" : ""}>
                        </label>
                        <button class="btn sm danger icon-btn" data-del-rule="${esc(r.id)}" title="Delete rule">${icon("trash")}</button>
                      </div>
                    </div>
                  `).join('')}
                </div>
              `}
            </div>

            <div class="card">
              <h4 style="margin:0 0 10px 0">${icon("globe")} Captured External HTTP Calls</h4>
              ${!calls.length ? `<div class="muted sm" style="padding:16px 0">No external HTTP calls recorded yet. Calls made with Laravel's <code>Http</code> client during profiled requests appear here.</div>` : `
                <table class="telescope-table">
                  <thead>
                    <tr>
                      <th style="width:70px">Method</th>
                      <th>Target Endpoint</th>
                      <th style="width:80px">Status</th>
                      <th style="width:90px">Duration</th>
                      <th style="width:90px">Mocked</th>
                      <th style="width:70px;text-align:right">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${calls.map(c => `
                      <tr class="telescope-request-row">
                        <td><span class="perf-method ${(c.method || 'get').toLowerCase()}">${esc(c.method || "—")}</span></td>
                        <td style="font-family:var(--mono);font-size:12px;word-break:break-all">${esc(c.url)}<div class="muted" style="font-family:var(--font);font-size:11px">from ${esc(c.from || "—")}</div></td>
                        <td><span class="perf-status-badge s${String(c.status || 0)[0]}xx">${c.status || "—"}</span></td>
                        <td style="font-family:var(--mono);font-size:12px">${c.duration_ms || 0}ms</td>
                        <td>${c.mocked ? '<span class="badge sm info">MOCKED</span>' : '<span class="badge sm muted">LIVE</span>'}</td>
                        <td style="text-align:right">
                          <button class="btn sm ghost" data-inspect-call="${esc(c.id)}" title="Inspect call">${icon("search")}</button>
                        </td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              `}
            </div>
          </div>
        `;

        // Bind delete rule
        $$("[data-del-rule]", mainPane).forEach(btn => {
          btn.addEventListener("click", async () => {
            const id = btn.dataset.delRule;
            const updated = rules.filter(r => r.id !== id);
            await LD.call("http_mocks_save", { name: site.name, rules: updated });
            toast("info", "Mock rule deleted");
            renderHttpMocksView();
          });
        });

        // Bind toggle rule
        $$("[data-toggle-rule]", mainPane).forEach(chk => {
          chk.addEventListener("change", async () => {
            const id = chk.dataset.toggleRule;
            const target = rules.find(r => r.id === id);
            if (target) {
              target.enabled = chk.checked;
              await LD.call("http_mocks_save", { name: site.name, rules });
              toast("info", `Rule ${chk.checked ? "enabled" : "disabled"}`);
            }
          });
        });

        // Bind inspect call
        $$("[data-inspect-call]", mainPane).forEach(btn => {
          btn.addEventListener("click", () => {
            const id = btn.dataset.inspectCall;
            const item = calls.find(c => c.id === id);
            if (!item) return;

            openModal(`
              <div class="modal md">
                <div class="modal-header">
                  <h2>${icon("share")} Outgoing Call: ${esc(item.method)} ${esc(item.url)}</h2>
                </div>
                <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
                  <div style="display:flex;gap:16px;font-size:12px" class="muted">
                    <span>Status: <b>${item.status}</b></span>
                    <span>Duration: <b>${item.duration_ms}ms</b></span>
                    <span>Type: <b>${item.mocked ? `Mocked (rule ${esc(item.rule_id)})` : "Live API Call"}</b></span>
                  </div>
                  <div class="muted" style="font-size:12px">Made while handling <code>${esc(item.from || "—")}</code>${item.time ? ` at ${esc(new Date(item.time * 1000).toLocaleString())}` : ""}.</div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn primary" data-dismiss>Close</button>
                </div>
              </div>
            `);
          });
        });

        // Bind Add Rule
        $("#btn-new-mock-rule", mainPane)?.addEventListener("click", () => {
          openModal(`
            <form class="modal md" id="form-new-mock-rule">
              <div class="modal-header">
                <h2>${icon("plus")} Add Outgoing HTTP Mock Rule</h2>
              </div>
              <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
                <label class="field">
                  <span>URL Match Pattern (e.g. <code>api.openai.com/*</code> or <code>api.stripe.com/v1/charges*</code>)</span>
                  <input type="text" name="url_pattern" required placeholder="https://api.external.com/*" class="input sm" style="font-family:var(--mono)">
                </label>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                  <label class="field">
                    <span>HTTP Method</span>
                    <select name="method" class="input sm">
                      <option value="*">ANY (*)</option>
                      <option value="GET">GET</option>
                      <option value="POST">POST</option>
                      <option value="PUT">PUT</option>
                      <option value="DELETE">DELETE</option>
                    </select>
                  </label>
                  <label class="field">
                    <span>Response HTTP Status</span>
                    <input type="number" name="status" value="200" class="input sm">
                  </label>
                </div>
                <label class="field">
                  <span>Mocked JSON Response Body</span>
                  <textarea name="response" rows="6" class="input sm" style="font-family:var(--mono);font-size:12px">{\n  "ok": true,\n  "mocked": true\n}</textarea>
                </label>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn" data-dismiss>Cancel</button>
                <button type="submit" class="btn primary">${icon("check")} Save Mock Rule</button>
              </div>
            </form>
          `, (modalRoot) => {
            const form = $("#form-new-mock-rule", modalRoot);
            form?.addEventListener("submit", async (e) => {
              e.preventDefault();
              let parsedRes = form.elements.response.value.trim();
              try {
                parsedRes = JSON.parse(parsedRes);
              } catch {}

              const newRule = {
                id: `rule_${Date.now()}`,
                url_pattern: form.elements.url_pattern.value.trim(),
                method: form.elements.method.value,
                status: parseInt(form.elements.status.value, 10) || 200,
                response: parsedRes,
                enabled: true,
              };

              rules.push(newRule);
              try {
                await LD.call("http_mocks_save", { name: site.name, rules });
                toast("success", "Mock rule saved");
                closeModal();
                renderHttpMocksView();
              } catch (err) {
                toast("error", "Failed to save rule", err.message);
              }
            });
          });
        });

      } catch (err) {
        mainPane.innerHTML = `<div class="card error-pane">${icon("alert")} Failed to load HTTP Mocks: ${esc(err.message)}</div>`;
      }
    }

    // ── 6. INCOMING WEBHOOKS INSPECTOR VIEW (Phase 5) ─────────────────────
    async function renderWebhooksView() {
      mainPane.innerHTML = `<div class="loading-pane sm">${icon("pulse")} Loading incoming webhooks...</div>`;

      try {
        const res = await LD.call("webhooks_list", { name: site.name, limit: 100 });
        const list = res.webhooks || [];
        if (pillCountWebhooks) pillCountWebhooks.textContent = list.length;

        if (!list.length) {
          mainPane.innerHTML = `
            <div class="empty" style="padding:40px 20px">
              <div class="empty-icon">${icon("cloud")}</div>
              <h3>${window.t ? window.t("webhooks_empty", "No webhooks captured yet") : "No webhooks captured yet"}</h3>
              <p class="muted sm" style="max-width:480px;margin:8px auto 16px">${window.t ? window.t("webhooks_empty_desc", "Incoming requests matching webhook patterns are logged here automatically.") : "Incoming requests matching webhook patterns are logged here automatically."}</p>
              <div style="background:rgba(99, 102, 241, 0.08);border:1px solid rgba(99, 102, 241, 0.2);border-radius:8px;padding:12px 16px;max-width:540px;margin:0 auto;text-align:left">
                <span style="font-size:12px;font-weight:600;display:block;margin-bottom:4px">${window.t ? window.t("webhook_patterns", "Monitored Patterns") : "Monitored Patterns"}:</span>
                <code style="font-size:11.5px;color:var(--text)">webhook*, */webhook*, stripe/*, api/payments/*/callback, api/webhooks/*</code>
                <div class="muted sm" style="margin-top:8px">${window.t ? window.t("webhook_tolerance_tip", "Tip: Providers like Stripe enforce a 5-minute timestamp tolerance. When replaying older events, relax tolerance in local configs.") : "Tip: Providers like Stripe enforce a 5-minute timestamp tolerance. When replaying older events, relax tolerance in local configs."}</div>
              </div>
            </div>
          `;
          return;
        }

        mainPane.innerHTML = `
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
            <div>
              <b style="font-size:14px">${window.t ? window.t("webhooks_title", "Incoming Webhooks Inspector") : "Incoming Webhooks Inspector"}</b>
              <div class="muted sm">${list.length} captured webhook payload(s)</div>
            </div>
            <button class="btn sm ghost danger" id="btn-clear-webhooks">${icon("trash")} ${window.t ? window.t("webhook_clear", "Clear All Webhooks") : "Clear All Webhooks"}</button>
          </div>
          <div class="telescope-feed" id="webhooks-feed-list">
            ${list.map(wh => `
              <div class="telescope-entry" data-wh-id="${esc(wh.id)}" style="cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 14px;background:var(--surface);border:1px solid var(--border);border-radius:8px;margin-bottom:8px">
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
                  <span class="perf-status-badge ${wh.status >= 500 ? 's5xx' : (wh.status >= 400 ? 's4xx' : (wh.status >= 300 ? 's3xx' : 's2xx'))}">${esc(wh.status)}</span>
                  <span class="perf-method ${(wh.method || 'post').toLowerCase()}">${esc(wh.method)}</span>
                  <code style="font-family:var(--mono);font-weight:600;font-size:13px">${esc(wh.uri)}</code>
                  <span class="chip sm" style="font-family:var(--mono)">${wh.body_size} B</span>
                </div>
                <div style="display:flex;align-items:center;gap:8px">
                  <span class="muted sm" style="font-size:11.5px">${esc(wh.created_at || "")}</span>
                  <button class="btn sm ghost icon-btn" data-wh-curl="${esc(wh.id)}" title="${window.t ? window.t("webhook_curl", "Copy as cURL") : "Copy as cURL"}">${icon("copy")}</button>
                  <button class="btn sm ghost" data-wh-inspect="${esc(wh.id)}">${icon("eye")}Inspect</button>
                  <button class="btn sm primary ghost" data-wh-replay="${esc(wh.id)}">${icon("refresh")}${window.t ? window.t("webhook_replay", "Replay") : "Replay"}</button>
                </div>
              </div>
            `).join("")}
          </div>
        `;

        $("#btn-clear-webhooks", mainPane)?.addEventListener("click", async () => {
          await LD.call("webhooks_clear", { name: site.name });
          toast("info", "Webhooks cleared");
          renderWebhooksView();
        });

        $$("[data-wh-curl]", mainPane).forEach(btn => {
          btn.addEventListener("click", async (e) => {
            e.stopPropagation();
            const id = btn.dataset.whCurl;
            try {
              const res = await LD.call("webhooks_curl", { name: site.name, id });
              if (res.curl) {
                await navigator.clipboard.writeText(res.curl);
                toast("ok", "cURL command copied to clipboard!");
              }
            } catch (err) {
              toast("error", "Failed to generate cURL", err.message);
            }
          });
        });

        $$("[data-wh-replay]", mainPane).forEach(btn => {
          btn.addEventListener("click", async (e) => {
            e.stopPropagation();
            const id = btn.dataset.whReplay;
            btn.disabled = true;
            try {
              const res = await LD.call("webhooks_replay", { name: site.name, id });
              if (res.status >= 200 && res.status < 400) {
                toast("ok", `Replay Success: HTTP ${res.status} (${res.duration_ms} ms)`);
              } else {
                toast("warn", `Replay Finished: HTTP ${res.status || 'ERR'} (${res.duration_ms} ms)`);
              }
              renderWebhooksView();
            } catch (err) {
              toast("error", "Replay failed", err.message);
            } finally {
              btn.disabled = false;
            }
          });
        });

        $$("[data-wh-inspect], .telescope-entry", mainPane).forEach(el => {
          el.addEventListener("click", async (e) => {
            if (e.target.closest("button")) return;
            const id = el.dataset.whInspect || el.dataset.whId;
            openWebhookModal(id);
          });
        });

      } catch (err) {
        mainPane.innerHTML = `<div class="card error-pane">${icon("alert")} Failed to load webhooks: ${esc(err.message)}</div>`;
      }
    }

    async function openWebhookModal(whId) {
      try {
        const res = await LD.call("webhooks_get", { name: site.name, id: whId });
        const wh = res.webhook;
        if (!wh) return;

        let formattedBody = wh.body || "";
        try {
          formattedBody = JSON.stringify(JSON.parse(wh.body), null, 2);
        } catch {}

        modal({
          title: `Webhook: ${wh.method} ${wh.uri}`,
          html: `
            <div style="display:flex;flex-direction:column;gap:14px;max-height:75vh;overflow-y:auto">
              <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;padding-bottom:10px;border-bottom:1px solid var(--border)">
                <div style="display:flex;align-items:center;gap:8px">
                  <span class="perf-status-badge ${wh.status >= 500 ? 's5xx' : (wh.status >= 400 ? 's4xx' : 's2xx')}">${wh.status}</span>
                  <span class="perf-method ${(wh.method || 'post').toLowerCase()}">${esc(wh.method)}</span>
                  <b style="font-family:var(--mono);font-size:13px">${esc(wh.url || wh.uri)}</b>
                </div>
                <div class="muted sm">${esc(wh.created_at || "")} · ${wh.duration_ms || 0} ms</div>
              </div>

              <div>
                <b style="font-size:12px;margin-bottom:6px;display:block">${window.t ? window.t("webhook_headers", "Headers") : "Headers"}</b>
                <pre style="background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:8px 12px;font-size:11.5px;max-height:140px;overflow-y:auto;font-family:var(--mono)">${esc(Object.entries(wh.headers || {}).map(([k, v]) => `${k}: ${v}`).join("\n"))}</pre>
              </div>

              <div>
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                  <b style="font-size:12px">${window.t ? window.t("webhook_payload", "Payload / Body") : "Payload / Body"}</b>
                  <button type="button" class="btn sm ghost" id="modal-btn-copy-body">${icon("copy")}Copy Payload</button>
                </div>
                <textarea id="modal-webhook-body" style="width:100%;height:180px;font-family:var(--mono);font-size:12px;padding:8px 10px;background:var(--bg);border:1px solid var(--border);border-radius:6px;resize:vertical">${esc(formattedBody)}</textarea>
              </div>

              ${wh.response_preview ? `
                <div>
                  <b style="font-size:12px;margin-bottom:6px;display:block">${window.t ? window.t("webhook_response", "Response") : "Response"} (${wh.status})</b>
                  <pre style="background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:8px 12px;font-size:11.5px;max-height:100px;overflow-y:auto;font-family:var(--mono)">${esc(wh.response_preview)}</pre>
                </div>
              ` : ""}

              <div id="modal-replay-result" style="display:none;padding:10px 12px;border-radius:6px;border:1px solid var(--border)"></div>

              <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding-top:10px;border-top:1px solid var(--border)">
                <button type="button" class="btn sm" id="modal-btn-curl">${icon("copy")}${window.t ? window.t("webhook_curl", "Copy as cURL") : "Copy as cURL"}</button>
                <div class="btn-row">
                  <button type="button" class="btn sm" data-dismiss>Close</button>
                  <button type="button" class="btn sm primary" id="modal-btn-replay">${icon("refresh")}${window.t ? window.t("webhook_replay", "Send Replay") : "Send Replay"}</button>
                </div>
              </div>
            </div>
          `,
          onOpen: (modalEl) => {
            $("#modal-btn-copy-body", modalEl)?.addEventListener("click", () => {
              const ta = $("#modal-webhook-body", modalEl);
              navigator.clipboard.writeText(ta.value);
              toast("ok", "Payload copied");
            });

            $("#modal-btn-curl", modalEl)?.addEventListener("click", async () => {
              const res = await LD.call("webhooks_curl", { name: site.name, id: wh.id });
              if (res.curl) {
                navigator.clipboard.writeText(res.curl);
                toast("ok", "cURL copied to clipboard");
              }
            });

            $("#modal-btn-replay", modalEl)?.addEventListener("click", async () => {
              const replayBtn = $("#modal-btn-replay", modalEl);
              const customBody = $("#modal-webhook-body", modalEl).value;
              const resultBox = $("#modal-replay-result", modalEl);
              replayBtn.disabled = true;
              resultBox.style.display = "block";
              resultBox.className = "loading-pane sm";
              resultBox.innerHTML = `${icon("pulse")} Sending replay...`;

              try {
                const rep = await LD.call("webhooks_replay", { name: site.name, id: wh.id, custom_body: customBody });
                resultBox.className = rep.status >= 200 && rep.status < 400 ? "card ok-pane" : "card warn-pane";
                resultBox.innerHTML = `
                  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                    <b>Result: HTTP ${rep.status} (${rep.duration_ms} ms)</b>
                    ${rep.error ? `<span class="chip sm danger">${esc(rep.error)}</span>` : ""}
                  </div>
                  ${rep.body ? `<pre style="margin:0;font-size:11px;max-height:80px;overflow-y:auto;font-family:var(--mono)">${esc(rep.body)}</pre>` : ""}
                `;
              } catch (err) {
                resultBox.className = "card error-pane";
                resultBox.innerHTML = `Replay error: ${esc(err.message)}`;
              } finally {
                replayBtn.disabled = false;
              }
            });
          }
        });
      } catch (err) {
        toast("error", "Failed to inspect webhook", err.message);
      }
    }

    // ── INSPECT REQUEST DETAIL MODAL (Telescope-Grade Tabbed Inspector) ─────

    // Initial load
    activePerfRefreshFn = loadView;
    await checkProfilerStatus();
    await loadView();

    activePerfPoller = poll(async () => {
      if ($("#site-drawer")?.classList.contains("open") && currentSite?.name === site.name) {
        await loadView();
      }
    }, 1000);
  }

  function onPerfEvent(event) {
    if (!activePerfContainer || !activePerfSite) return;
    const evSite = (event.site || "").toLowerCase();
    const curSite = (activePerfSite.name || "").toLowerCase();
    if (evSite && evSite !== curSite && !evSite.includes(curSite) && !curSite.includes(evSite)) return;
    if (activePerfRefreshFn) {
      activePerfRefreshFn();
    }
  }

  function destroy() {
    activeDumpsContainer = null;
    activeDumpsSite = null;
    activePerfContainer = null;
    activePerfSite = null;
    activePerfRefreshFn = null;
    if (activePerfPoller) {
      activePerfPoller.stop();
      activePerfPoller = null;
    }
    if (activeTinkerSite) {
      LD.call("tinker_stop", { name: activeTinkerSite }).catch(() => {});
      activeTinkerSite = null;
    }
    for (const p of activePollers) {
      p.stop();
    }
    activePollers.clear();
    currentSite = null;
  }

  // ── Models Explorer (Task 7.1) ─────────────────────────────────────────────
  function mountModels(container, site) {
    currentSite = site;
    let models = [];
    let selectedModel = null;
    let query = "";
    let loading = true;

    container.innerHTML = `
      <div class="models-container" style="display:flex;gap:14px;min-height:500px">
        <div class="card models-sidebar" style="width:260px;padding:12px;display:flex;flex-direction:column;gap:10px">
          <div style="display:flex;align-items:center;justify-content:space-between">
            <b style="font-size:13px;display:flex;align-items:center;gap:6px">${icon("database")} Eloquent Models</b>
            <span class="chip sm" id="models-count-chip">0</span>
          </div>
          <div class="search" style="width:100%">
            ${icon("search")}
            <input type="search" id="models-search" placeholder="Filter models…" autocomplete="off" style="width:100%">
          </div>
          <div id="models-list" style="flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:4px">
            <div class="loading-pane sm">${icon("pulse")} Scanning models…</div>
          </div>
        </div>

        <div class="card models-detail" id="models-detail" style="flex:1;padding:16px;overflow-y:auto">
          <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);flex-direction:column;gap:8px">
            <span style="opacity:.4">${icon("database")}</span>
            <span>Select a model from the list to view attributes and relations</span>
          </div>
        </div>
      </div>
    `;

    const listEl = $("#models-list", container);
    const countChip = $("#models-count-chip", container);
    const searchInput = $("#models-search", container);
    const detailEl = $("#models-detail", container);

    async function loadModels() {
      loading = true;
      listEl.innerHTML = `<div class="loading-pane sm">${icon("pulse")} Scanning models…</div>`;
      try {
        const res = await LD.call("models_list", { name: site.name });
        models = res.models || [];
        countChip.textContent = models.length;
        renderList();
        if (models.length > 0 && !selectedModel) {
          selectModel(models[0]);
        }
      } catch (err) {
        listEl.innerHTML = `<div style="padding:12px;color:var(--red);font-size:12px">${esc(err.message)}</div>`;
      } finally {
        loading = false;
      }
    }

    function renderList() {
      const q = query.trim().toLowerCase();
      const filtered = models.filter((m) => !q || m.toLowerCase().includes(q));
      if (!filtered.length) {
        listEl.innerHTML = `<div style="padding:16px;text-align:center;color:var(--muted);font-size:12px">No models found</div>`;
        return;
      }
      listEl.innerHTML = filtered.map((m) => `
        <button class="btn ghost sm model-item-btn ${m === selectedModel ? 'active' : ''}" data-model="${esc(m)}" style="justify-content:flex-start;text-align:left;font-family:var(--mono);font-size:12.5px;padding:7px 10px;width:100%">
          ${icon("file")} ${esc(m)}
        </button>
      `).join("");

      $$("[data-model]", listEl).forEach((btn) => {
        btn.addEventListener("click", () => selectModel(btn.dataset.model));
      });
    }

    async function selectModel(modelName) {
      selectedModel = modelName;
      $$(".model-item-btn", listEl).forEach((b) => b.classList.toggle("active", b.dataset.model === modelName));
      detailEl.innerHTML = `<div class="loading-pane">${icon("pulse")} Introspecting ${esc(modelName)}…</div>`;

      try {
        const res = await LD.call("model_show", { name: site.name, model: modelName });
        if (!res.ok) {
          detailEl.innerHTML = `
            <div style="padding:24px;color:var(--red)">
              <b>${icon("alert")} Could not inspect ${esc(modelName)}</b>
              <p class="muted sm" style="margin-top:6px">${esc(res.error || "artisan model:show failed")}</p>
            </div>
          `;
          return;
        }

        const m = res.model || {};
        const attrs = m.attributes || [];
        const rels = m.relations || [];
        const observers = m.observers || [];

        detailEl.innerHTML = `
          <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--border);flex-wrap:wrap;gap:10px">
            <div>
              <div style="display:flex;align-items:center;gap:8px">
                <h3 style="margin:0;font-size:18px">${esc(modelName)}</h3>
                <span class="chip sm" style="font-family:var(--mono)">${esc(m.class || modelName)}</span>
              </div>
              <div style="margin-top:6px;display:flex;align-items:center;gap:10px;font-size:12px;color:var(--muted)">
                <span>Database: <b>${esc(m.database || "default")}</b></span>
                <span>Table: <b style="font-family:var(--mono)">${esc(m.table || "—")}</b></span>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              ${m.table ? `<button class="btn sm" id="btn-browse-model-table" data-table="${esc(m.table)}">${icon("database")} Browse in Database</button>` : ""}
              <button class="btn sm ghost" id="btn-open-model-file" data-model="${esc(modelName)}">${icon("code")} Open in Editor</button>
            </div>
          </div>

          <div style="margin-bottom:18px">
            <h4 style="font-size:13px;text-transform:uppercase;letter-spacing:0.5px;color:var(--muted);margin-bottom:8px">Attributes (${attrs.length})</h4>
            ${!attrs.length ? `<div class="muted sm">No attributes discovered.</div>` : `
              <div class="routes-table-wrap">
                <table class="routes-table" style="font-size:12px">
                  <thead>
                    <tr>
                      <th>Column</th>
                      <th>Type</th>
                      <th>Cast</th>
                      <th>Flags</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${attrs.map((a) => {
                      const flags = [];
                      if (a.increments) flags.push('<span class="chip xs" style="color:var(--accent)">PK</span>');
                      if (a.nullable) flags.push('<span class="chip xs muted">nullable</span>');
                      if (a.fillable) flags.push('<span class="chip xs" style="color:var(--green)">fillable</span>');
                      if (a.hidden) flags.push('<span class="chip xs text-red">hidden</span>');
                      if (a.unique) flags.push('<span class="chip xs" style="color:var(--blue)">unique</span>');
                      return `
                        <tr>
                          <td><b style="font-family:var(--mono)">${esc(a.name)}</b></td>
                          <td><span class="muted" style="font-family:var(--mono)">${esc(a.type || "—")}</span></td>
                          <td><span style="font-family:var(--mono)">${esc(a.cast || "—")}</span></td>
                          <td>${flags.join(" ") || "—"}</td>
                        </tr>
                      `;
                    }).join("")}
                  </tbody>
                </table>
              </div>
            `}
          </div>

          <div style="margin-bottom:18px">
            <h4 style="font-size:13px;text-transform:uppercase;letter-spacing:0.5px;color:var(--muted);margin-bottom:8px">Relationships (${rels.length})</h4>
            ${!rels.length ? `<div class="muted sm">No relations defined on this model.</div>` : `
              <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(260px, 1fr));gap:10px">
                ${rels.map((r) => `
                  <div class="card" style="padding:10px 12px;background:var(--surface-2)">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
                      <b style="font-family:var(--mono);font-size:13px">${esc(r.name)}</b>
                      <span class="badge sm" style="font-family:var(--mono)">${esc(r.type)}</span>
                    </div>
                    <div style="font-size:11.5px;color:var(--muted)">
                      Related: ${r.related ? `<button class="btn ghost xs link" data-jump-model="${esc(r.related)}" style="padding:0;font-family:var(--mono)">${esc(r.related)}</button>` : "—"}
                    </div>
                  </div>
                `).join("")}
              </div>
            `}
          </div>

          ${observers.length ? `
            <div>
              <h4 style="font-size:13px;text-transform:uppercase;letter-spacing:0.5px;color:var(--muted);margin-bottom:8px">Observers (${observers.length})</h4>
              <div style="display:flex;gap:6px;flex-wrap:wrap">
                ${observers.map((o) => `<span class="chip sm" style="font-family:var(--mono)">${esc(o)}</span>`).join("")}
              </div>
            </div>
          ` : ""}
        `;

        // Handlers
        $("#btn-browse-model-table", detailEl)?.addEventListener("click", (e) => {
          const tbl = e.currentTarget.dataset.table;
          setView("database");
          if (window.DB?.selectTable) window.DB.selectTable(tbl);
        });

        $("#btn-open-model-file", detailEl)?.addEventListener("click", () => {
          const modelRel = modelName.replace(/\\/g, "/") + ".php";
          LD.call("open_file", { path: `app/Models/${modelRel}` }).catch(() => {
            LD.call("open_file", { path: `app/${modelRel}` });
          });
        });

        $$("[data-jump-model]", detailEl).forEach((btn) => {
          btn.addEventListener("click", () => {
            const relFull = btn.dataset.jumpModel;
            const shortName = relFull.replace(/^App\\Models\\/, "").replace(/^App\\/, "");
            if (models.includes(shortName)) {
              selectModel(shortName);
            } else if (models.includes(relFull)) {
              selectModel(relFull);
            } else {
              toast("info", `Model ${shortName} not in active models list`);
            }
          });
        });

      } catch (err) {
        detailEl.innerHTML = `<div style="padding:24px;color:var(--red)">Failed to inspect model: ${esc(err.message)}</div>`;
      }
    }

    searchInput.addEventListener("input", (e) => {
      query = e.target.value;
      renderList();
    });

    loadModels();
  }

  // ── Translation Manager (Task 7.6) ─────────────────────────────────────────
  const RTL_LOCALES = /^(ar|fa|he|ur|ps|ku|yi|dv)([_-]|$)/i;

  function mountTranslations(container, site) {
    currentSite = site;
    let transData = null;
    let query = "";
    let missingOnly = false;

    container.innerHTML = `
      <div class="translations-container card" style="padding:16px;min-height:480px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:10px">
          <div style="display:flex;align-items:center;gap:10px">
            <span style="color:var(--accent)">${icon("globe")}</span>
            <b style="font-size:15px">Translation Manager</b>
            <span class="chip sm" id="trans-count-chip">—</span>
          </div>
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <div class="search" style="width:240px">
              ${icon("search")}
              <input type="search" id="trans-search" placeholder="Search keys or text…" autocomplete="off">
            </div>
            <label class="row" style="margin:0;gap:6px;cursor:pointer;font-size:12px">
              <input type="checkbox" id="trans-missing-toggle">
              <span>Missing only</span>
            </label>
            <button class="btn sm icon-btn" id="trans-refresh-btn" title="Refresh">${icon("refresh")}</button>
          </div>
        </div>

        <div id="trans-content-pane">
          <div class="loading-pane">${icon("pulse")} Scanning translation files in lang/…</div>
        </div>
      </div>
    `;

    const contentPane = $("#trans-content-pane", container);
    const countChip = $("#trans-count-chip", container);
    const searchInput = $("#trans-search", container);
    const missingToggle = $("#trans-missing-toggle", container);
    const refreshBtn = $("#trans-refresh-btn", container);

    async function loadTranslations() {
      contentPane.innerHTML = `<div class="loading-pane">${icon("pulse")} Scanning translation files…</div>`;
      try {
        transData = await LD.call("translations_list", { name: site.name });
        renderTable();
      } catch (err) {
        contentPane.innerHTML = `<div style="padding:24px;color:var(--red)">Failed to load translations: ${esc(err.message)}</div>`;
      }
    }

    function renderTable() {
      if (!transData || !transData.rows) return;
      const locales = transData.locales || [];
      const q = query.trim().toLowerCase();

      const filtered = transData.rows.filter((r) => {
        if (missingOnly && !r.missing) return false;
        if (!q) return true;
        if (r.key.toLowerCase().includes(q)) return true;
        return locales.some((loc) => (r.values[loc] || "").toLowerCase().includes(q));
      });

      countChip.textContent = `${filtered.length} / ${transData.total_keys} keys (${transData.missing_keys_count} missing)`;

      if (!filtered.length) {
        contentPane.innerHTML = `<div style="padding:36px;text-align:center;color:var(--muted)">No translation keys match your filter.</div>`;
        return;
      }

      contentPane.innerHTML = `
        <div class="routes-table-wrap" style="max-height:600px;overflow-y:auto">
          <table class="routes-table" style="font-size:12px">
            <thead>
              <tr>
                <th style="width:260px">Translation Key</th>
                ${locales.map((loc) => `<th>${esc(loc.toUpperCase())}</th>`).join("")}
              </tr>
            </thead>
            <tbody>
              ${filtered.map((r) => `
                <tr>
                  <td>
                    <div style="font-family:var(--mono);font-size:11.5px;font-weight:600;word-break:break-all">
                      ${esc(r.key)}
                      <span class="chip xs" title="${r.source === "php" ? "Defined in a PHP group file" : "Defined in a JSON file"}">${r.source === "php" ? "PHP" : "JSON"}</span>
                      ${r.missing ? '<span class="chip xs text-red" style="margin-left:4px">missing</span>' : ''}
                    </div>
                  </td>
                  ${locales.map((loc) => {
                    const val = r.values[loc] || "";
                    const isRtl = RTL_LOCALES.test(loc);
                    const file = r.source === "php" && r.files ? r.files[loc] : "";
                    // PHP group files can hold comments and nested arrays, so they are edited
                    // in the editor; a missing PHP value is filled through the locale's JSON
                    // file, which __() checks first.
                    if (file) {
                      return `
                        <td>
                          <div style="display:flex;gap:6px;align-items:center">
                            <input type="text" class="input xs" value="${esc(val)}" dir="${isRtl ? 'rtl' : 'ltr'}" readonly title="${esc(file)}" style="flex:1;min-width:0;font-size:12px;opacity:.85">
                            <button class="btn xs icon-btn trans-open-file" data-file="${esc(file)}" title="Open ${esc(file)}" aria-label="Open ${esc(file)}">${icon("code")}</button>
                          </div>
                        </td>`;
                    }
                    return `
                      <td>
                        <input type="text" class="input xs trans-inline-input" data-key="${esc(r.key)}" data-loc="${esc(loc)}" value="${esc(val)}" dir="${isRtl ? 'rtl' : 'ltr'}" placeholder="${isRtl ? 'أدخل الترجمة…' : 'Enter value…'}" title="${r.source === "php" ? `Saved to ${esc(loc)}.json` : ""}" style="width:100%;font-size:12px;${!val ? 'border-color:rgba(239,68,68,0.4);' : ''}">
                      </td>
                    `;
                  }).join("")}
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `;

      $$(".trans-open-file", contentPane).forEach((btn) => {
        btn.addEventListener("click", () => {
          LD.call("open_file", { path: `${site.path}/${transData.lang_dir}/${btn.dataset.file}` })
            .catch((err) => toast("error", "Couldn't open the file", err.message));
        });
      });

      let saveTimers = new Map();
      $$(".trans-inline-input", contentPane).forEach((input) => {
        input.addEventListener("input", () => {
          const key = input.dataset.key;
          const loc = input.dataset.loc;
          const val = input.value;
          const timerKey = `${loc}:${key}`;
          if (saveTimers.has(timerKey)) clearTimeout(saveTimers.get(timerKey));
          saveTimers.set(timerKey, setTimeout(async () => {
            try {
              input.style.opacity = "0.6";
              await LD.call("translation_save", { name: site.name, locale: loc, key, value: val });
              input.style.opacity = "1";
              input.style.borderColor = "var(--green)";
              setTimeout(() => { input.style.borderColor = ""; }, 1500);
            } catch (err) {
              input.style.borderColor = "var(--red)";
              toast("error", "Failed to save translation", err.message);
            }
          }, 400));
        });
      });
    }

    searchInput.addEventListener("input", (e) => {
      query = e.target.value;
      renderTable();
    });

    missingToggle.addEventListener("change", (e) => {
      missingOnly = e.target.checked;
      renderTable();
    });

    refreshBtn.addEventListener("click", () => loadTranslations());
    loadTranslations();
  }

  // ── Project Time Machine & Checkpoints (Feature 2) ─────────────────────────
  async function mountCheckpoints(container, site) {
    currentSite = site;
    let checkpoints = [];

    container.innerHTML = `
      <div class="checkpoints-container">
        <div class="card" style="margin-bottom:14px;padding:14px 18px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
            <div>
              <h3 style="margin:0;display:flex;align-items:center;gap:8px;font-size:15px">
                ${icon("clock")} ${window.t ? window.t("checkpoints", "Project Time Machine & Checkpoints") : "Project Time Machine & Checkpoints"}
              </h3>
              <p class="muted sm" style="margin:4px 0 0">
                Instantly snapshot database, .env, and uploaded storage files before running migrations or major code changes.
              </p>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <button class="btn primary sm" id="btn-create-checkpoint">${icon("save")} ${window.t ? window.t("save_checkpoint", "Save Checkpoint") : "Save Checkpoint"}</button>
              <button class="btn ghost sm icon-btn" id="btn-refresh-checkpoints" title="Refresh">${icon("refresh")}</button>
            </div>
          </div>
        </div>

        <div id="checkpoints-list-pane">
          <div class="loading-pane">${icon("pulse")} Loading checkpoints…</div>
        </div>

        <!-- Create Checkpoint Modal -->
        <div id="checkpoint-modal" class="modal-scrim" hidden>
          <div class="modal card" style="max-width:480px">
            <div class="modal-header">
              <h3>${icon("save")} Create Project Checkpoint</h3>
              <button class="btn ghost icon-btn sm" id="modal-checkpoint-close">${icon("x")}</button>
            </div>
            <div class="modal-body" style="padding:14px 0">
              <label class="label">Checkpoint Note / Description
                <input type="text" class="input" id="checkpoint-note-input" placeholder="e.g. Before running payments migration" autofocus>
              </label>
              <label style="display:flex;align-items:center;gap:8px;margin-top:12px;font-size:13px;cursor:pointer">
                <input type="checkbox" id="checkpoint-storage-chk" checked>
                <span>Include uploaded media files (<code>storage/app/public</code>)</span>
              </label>
            </div>
            <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding-top:10px">
              <button class="btn ghost" id="modal-checkpoint-cancel">Cancel</button>
              <button class="btn primary" id="modal-checkpoint-save">Create Checkpoint</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const listPane = $("#checkpoints-list-pane", container);
    const createBtn = $("#btn-create-checkpoint", container);
    const refreshBtn = $("#btn-refresh-checkpoints", container);
    const modal = $("#checkpoint-modal", container);
    const modalClose = $("#modal-checkpoint-close", container);
    const modalCancel = $("#modal-checkpoint-cancel", container);
    const modalSave = $("#modal-checkpoint-save", container);
    const noteInput = $("#checkpoint-note-input", container);
    const storageChk = $("#checkpoint-storage-chk", container);

    modalClose.addEventListener("click", () => { modal.hidden = true; });
    modalCancel.addEventListener("click", () => { modal.hidden = true; });
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.hidden = true; });

    createBtn.addEventListener("click", () => {
      noteInput.value = "";
      modal.hidden = false;
      noteInput.focus();
    });

    modalSave.addEventListener("click", async () => {
      const note = noteInput.value.trim();
      const includeStorage = storageChk.checked;
      modalSave.disabled = true;
      try {
        const res = await LD.call("checkpoint_create", { name: site.name, note, include_storage: includeStorage });
        if (!res.ok) throw new Error(res.error || "Failed to create checkpoint");
        toast("success", "Project checkpoint saved successfully");
        modal.hidden = true;
        await loadCheckpoints();
      } catch (err) {
        toast("error", "Couldn't create checkpoint", err.message);
      } finally {
        modalSave.disabled = false;
      }
    });

    refreshBtn.addEventListener("click", () => loadCheckpoints());

    async function loadCheckpoints() {
      listPane.innerHTML = `<div class="loading-pane">${icon("pulse")} Loading checkpoints…</div>`;
      try {
        const res = await LD.call("checkpoint_list", { name: site.name });
        checkpoints = res.checkpoints || [];

        if (!checkpoints.length) {
          listPane.innerHTML = `
            <div class="card" style="text-align:center;padding:36px">
              <div style="font-size:32px;margin-bottom:8px;color:var(--muted)">${icon("clock")}</div>
              <h3>No Checkpoints Created Yet</h3>
              <p class="muted sm" style="max-width:440px;margin:6px auto 16px">
                Checkpoints capture your entire database state, .env file, and storage files so you can experiment freely and revert in seconds.
              </p>
              <button class="btn primary sm" id="btn-create-checkpoint-empty">${icon("save")} Save First Checkpoint</button>
            </div>
          `;
          $("#btn-create-checkpoint-empty", listPane)?.addEventListener("click", () => {
            createBtn.click();
          });
          return;
        }

        const cardsHtml = checkpoints.map(cp => {
          const sz = cp.total_size ? `${Math.round(cp.total_size / (1024 * 1024) * 10) / 10} MB` : "";
          return `
            <div class="checkpoint-card" data-cp-id="${esc(cp.id)}">
              <div style="display:flex;align-items:center;gap:12px;min-width:0">
                <span style="font-size:22px;color:var(--accent);opacity:0.85">${icon("clock")}</span>
                <div>
                  <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                    <b style="font-size:14px;color:var(--text)">${esc(cp.note || "Checkpoint")}</b>
                    <span class="chip sm muted" style="font-family:var(--mono);font-size:11px">${esc(cp.created_at)}</span>
                    ${cp.git_branch ? `<span class="chip sm" style="font-family:var(--mono);font-size:11px">${icon("git")}${esc(cp.git_branch)}${cp.git_commit ? ` (${esc(cp.git_commit)})` : ""}</span>` : ""}
                  </div>
                  <div style="display:flex;align-items:center;gap:8px;margin-top:4px;font-size:11.5px;color:var(--muted)">
                    <span>${cp.has_db ? `${icon("database")} DB Snapshot` : ""}</span>
                    <span>${cp.has_env ? `· .env file` : ""}</span>
                    <span>${cp.has_storage ? `· Storage files` : ""}</span>
                    ${sz ? `<span class="chip sm muted" style="font-size:10.5px">${sz}</span>` : ""}
                  </div>
                </div>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <button class="btn sm" data-cp-restore="${esc(cp.id)}">${icon("refresh")} Restore</button>
                <button class="btn sm ghost danger icon-btn" data-cp-delete="${esc(cp.id)}" title="Delete checkpoint">${icon("trash")}</button>
              </div>
            </div>
          `;
        }).join("");

        listPane.innerHTML = `<div class="checkpoint-timeline">${cardsHtml}</div>`;

        $$("[data-cp-restore]", listPane).forEach(btn => {
          btn.addEventListener("click", async () => {
            const id = btn.dataset.cpRestore;
            const ok = await confirmModal({
              title: "Restore Checkpoint?",
              message: "Restoring this checkpoint will overwrite your current database, .env, and storage files with the state from this checkpoint. Proceed?",
              confirm: "Restore Checkpoint",
              danger: true,
            });
            if (!ok) return;

            btn.disabled = true;
            try {
              const res = await LD.call("checkpoint_restore", { name: site.name, id });
              if (!res.ok) throw new Error(res.error || "Failed to restore checkpoint");
              toast("success", res.message || "Checkpoint restored successfully!");
            } catch (err) {
              toast("error", "Restore failed", err.message);
            } finally {
              btn.disabled = false;
            }
          });
        });

        $$("[data-cp-delete]", listPane).forEach(btn => {
          btn.addEventListener("click", async () => {
            const id = btn.dataset.cpDelete;
            const ok = await confirmModal({
              title: "Delete Checkpoint?",
              message: "Permanently delete this project checkpoint from disk?",
              confirm: "Delete",
              danger: true,
            });
            if (!ok) return;

            try {
              await LD.call("checkpoint_delete", { name: site.name, id });
              toast("info", "Checkpoint deleted");
              await loadCheckpoints();
            } catch (err) {
              toast("error", "Delete failed", err.message);
            }
          });
        });

      } catch (err) {
        listPane.innerHTML = `<div class="card error-pane">${icon("alert")} Failed to load checkpoints: ${esc(err.message)}</div>`;
      }
    }

    await loadCheckpoints();
  }

  // ── Live Cache & Redis Explorer (Feature 5) ─────────────────────────
  async function mountCache(container, site) {
    currentSite = site;
    let cacheKeys = [];
    let cacheDriver = "file";

    container.innerHTML = `
      <div class="cache-container">
        <div class="cache-toolbar card">
          <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
            <div>
              <h3 style="margin:0 0 4px 0">${icon("database")} Cache & Redis Explorer</h3>
              <p class="muted" style="margin:0;font-size:12px">Driver: <b id="cache-driver-label" style="text-transform:uppercase;color:var(--accent)">...</b> · <span id="cache-keys-count">0 keys</span></p>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <input type="search" id="cache-search-input" placeholder="Filter keys by prefix..." class="input sm" style="width:220px">
            <button id="btn-cache-refresh" class="btn sm">${icon("refresh")} Refresh</button>
            <button id="btn-cache-flush" class="btn sm danger">${icon("trash")} Flush All</button>
          </div>
        </div>

        <div id="cache-keys-pane" class="card" style="padding:0;overflow:hidden">
          <div class="muted" style="padding:24px;text-align:center">${icon("spinner")} Loading cache keys...</div>
        </div>
      </div>
    `;

    const listPane = $("#cache-keys-pane", container);
    const driverLabel = $("#cache-driver-label", container);
    const countLabel = $("#cache-keys-count", container);
    const searchInput = $("#cache-search-input", container);
    const refreshBtn = $("#btn-cache-refresh", container);
    const flushBtn = $("#btn-cache-flush", container);

    async function loadKeys(query = "") {
      listPane.innerHTML = `<div class="muted" style="padding:24px;text-align:center">${icon("spinner")} Inspecting cache...</div>`;
      try {
        const res = await LD.call("cache_list", { name: site.name, site_path: site.path, query });
        cacheDriver = res.driver || "file";
        cacheKeys = res.keys || [];
        driverLabel.textContent = cacheDriver;
        countLabel.textContent = `${cacheKeys.length} key(s)`;

        if (!cacheKeys.length) {
          listPane.innerHTML = `
            <div style="text-align:center;padding:40px 20px" class="muted">
              ${icon("database")}
              <div style="font-weight:600;margin-top:8px">No cache keys found</div>
              <div style="font-size:12px;margin-top:4px">Cache store (${esc(cacheDriver)}) is currently empty or no keys matched query.</div>
            </div>
          `;
          return;
        }

        const rows = cacheKeys.map(k => {
          let ttlClass = "cache-ttl-badge";
          let ttlText = k.ttl > 0 ? `${k.ttl}s` : (k.ttl === -1 ? "No Expiry" : "Expired");
          if (k.ttl === -1) ttlClass += " no-expiry";
          else if (k.ttl === -2 || k.ttl === 0) ttlClass += " expired";

          const sizeText = k.size > 1024 ? `${(k.size / 1024).toFixed(1)} KB` : `${k.size || 0} B`;

          return `
            <tr data-key="${esc(k.key)}">
              <td style="font-family:var(--mono);font-weight:600;word-break:break-all">${esc(k.key)}</td>
              <td><span class="cache-type-badge">${esc(k.type || "string")}</span></td>
              <td><span class="${ttlClass}">${ttlText}</span></td>
              <td class="muted" style="font-size:12px">${sizeText}</td>
              <td style="font-family:var(--mono);font-size:12px;color:var(--text-muted);max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(k.preview || "")}</td>
              <td style="text-align:right;white-space:nowrap">
                <button class="btn sm" data-cache-inspect="${esc(k.key)}" title="Inspect value">${icon("search")}</button>
                <button class="btn sm danger" data-cache-del="${esc(k.key)}" title="Delete key">${icon("trash")}</button>
              </td>
            </tr>
          `;
        }).join("");

        listPane.innerHTML = `
          <div style="overflow-x:auto">
            <table class="cache-table">
              <thead>
                <tr>
                  <th>Key</th>
                  <th>Type</th>
                  <th>TTL</th>
                  <th>Size</th>
                  <th>Preview</th>
                  <th style="text-align:right">Actions</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>
        `;

        // Bind inspect buttons
        $$("[data-cache-inspect]", listPane).forEach(btn => {
          btn.addEventListener("click", async () => {
            const key = btn.dataset.cacheInspect;
            try {
              const item = await LD.call("cache_get", { name: site.name, site_path: site.path, key });
              let formatted = item.value;
              if (typeof item.value === "object") {
                formatted = JSON.stringify(item.value, null, 2);
              } else if (typeof item.value === "string") {
                try {
                  const parsed = JSON.parse(item.value);
                  formatted = JSON.stringify(parsed, null, 2);
                } catch {
                  formatted = item.value;
                }
              }
              openModal(`
                <div class="modal md">
                  <div class="modal-header">
                    <h2>${icon("database")} Key: ${esc(key)}</h2>
                  </div>
                  <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
                    <div style="display:flex;gap:16px;font-size:12px" class="muted">
                      <span>TTL: <b>${item.ttl ?? "N/A"}</b></span>
                      <span>Raw Length: <b>${item.raw?.length || 0} bytes</b></span>
                    </div>
                    <pre class="cache-modal-pre">${esc(String(formatted))}</pre>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn primary" data-dismiss>Close</button>
                  </div>
                </div>
              `);
            } catch (err) {
              toast("error", "Failed to fetch key value", err.message);
            }
          });
        });

        // Bind delete buttons
        $$("[data-cache-del]", listPane).forEach(btn => {
          btn.addEventListener("click", async () => {
            const key = btn.dataset.cacheDel;
            const ok = await confirmModal({
              title: "Delete Cache Key?",
              message: `Permanently delete cache key <code>${esc(key)}</code>?`,
              confirm: "Delete Key",
              danger: true,
            });
            if (!ok) return;

            try {
              await LD.call("cache_delete", { name: site.name, site_path: site.path, key });
              toast("info", `Key "${key}" deleted`);
              await loadKeys(searchInput.value.trim());
            } catch (err) {
              toast("error", "Delete failed", err.message);
            }
          });
        });

      } catch (err) {
        listPane.innerHTML = `<div class="card error-pane">${icon("alert")} Failed to inspect cache: ${esc(err.message)}</div>`;
      }
    }

    refreshBtn.addEventListener("click", () => loadKeys(searchInput.value.trim()));
    searchInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") loadKeys(searchInput.value.trim());
    });

    flushBtn.addEventListener("click", async () => {
      const ok = await confirmModal({
        title: "Flush Entire Cache?",
        message: `This will clear all cached items in the <b>${esc(cacheDriver)}</b> store for <code>${esc(site.name)}</code>.`,
        confirm: "Flush All",
        danger: true,
      });
      if (!ok) return;

      try {
        await LD.call("cache_flush", { name: site.name, site_path: site.path });
        toast("success", "Cache flushed completely");
        await loadKeys();
      } catch (err) {
        toast("error", "Flush failed", err.message);
      }
    });

    await loadKeys();
  }

  // ── Vite & Asset Watcher Supervisor (Feature 9) ─────────────────────
  async function mountVite(container, site) {
    currentSite = site;
    let pollInterval = null;

    container.innerHTML = `
      <div class="vite-container" style="display:flex;flex-direction:column;gap:14px">
        <div class="card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:12px">
            <div>
              <h3 style="margin:0 0 4px 0">${icon("zap")} Vite &amp; Asset Watcher</h3>
              <div style="font-size:12px" class="muted">
                Status: <span id="vite-status-badge" class="badge muted" style="font-size:11px">Checking...</span>
                <span id="vite-port-badge" class="badge primary" style="font-size:11px;display:none">localhost:5173</span>
                <span id="vite-pid-badge" class="muted" style="margin-left:8px;font-size:11px;display:none">PID: <code id="vite-pid-val"></code></span>
              </div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <button id="btn-vite-start" class="btn sm primary">${icon("play")} Start Watcher</button>
            <button id="btn-vite-stop" class="btn sm danger" style="display:none">${icon("stop")} Stop Watcher</button>
            <button id="btn-vite-restart" class="btn sm" style="display:none">${icon("refresh")} Restart</button>
            <button id="btn-vite-open" class="btn sm ghost" style="display:none">${icon("share")} Open HMR</button>
          </div>
        </div>

        <div class="card" style="padding:0;overflow:hidden">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid var(--border);background:var(--surface-2)">
            <span style="font-weight:600;font-size:12px">${icon("terminal")} HMR &amp; Build Output</span>
            <div style="display:flex;gap:8px">
              <button id="btn-vite-clear-log" class="btn sm ghost">${icon("trash")} Clear</button>
            </div>
          </div>
          <pre id="vite-log-console" style="margin:0;padding:14px;background:var(--code-bg, #1a1b26);color:#a9b1d6;font-family:var(--mono);font-size:12px;line-height:1.5;height:360px;overflow-y:auto;white-space:pre-wrap;word-break:break-all">Connecting to Vite output...</pre>
        </div>
      </div>
    `;

    const statusBadge = $("#vite-status-badge", container);
    const portBadge = $("#vite-port-badge", container);
    const pidBadge = $("#vite-pid-badge", container);
    const pidVal = $("#vite-pid-val", container);
    const startBtn = $("#btn-vite-start", container);
    const stopBtn = $("#btn-vite-stop", container);
    const restartBtn = $("#btn-vite-restart", container);
    const openBtn = $("#btn-vite-open", container);
    const logConsole = $("#vite-log-console", container);
    const clearBtn = $("#btn-vite-clear-log", container);

    let currentPort = 5173;

    async function updateStatus() {
      try {
        const res = await LD.call("vite_status", { name: site.name, site_path: site.path });
        currentPort = res.port || 5173;

        if (res.running) {
          statusBadge.className = "badge success";
          statusBadge.textContent = "RUNNING";
          portBadge.style.display = "inline-block";
          portBadge.textContent = `:${currentPort}`;
          if (res.pid) {
            pidBadge.style.display = "inline";
            pidVal.textContent = res.pid;
          }
          startBtn.style.display = "none";
          stopBtn.style.display = "inline-flex";
          restartBtn.style.display = "inline-flex";
          openBtn.style.display = "inline-flex";
        } else {
          statusBadge.className = "badge muted";
          statusBadge.textContent = "STOPPED";
          portBadge.style.display = "none";
          pidBadge.style.display = "none";
          startBtn.style.display = "inline-flex";
          stopBtn.style.display = "none";
          restartBtn.style.display = "none";
          openBtn.style.display = "none";
        }

        if (res.logs && res.logs.length) {
          logConsole.textContent = res.logs.join("\n");
          logConsole.scrollTop = logConsole.scrollHeight;
        } else if (!res.running) {
          logConsole.textContent = "Vite dev watcher is idle. Click 'Start Watcher' to launch `npm run dev` in the background.";
        }
      } catch (err) {
        statusBadge.className = "badge danger";
        statusBadge.textContent = "ERROR";
      }
    }

    startBtn.addEventListener("click", async () => {
      startBtn.disabled = true;
      try {
        await LD.call("vite_start", { name: site.name, site_path: site.path });
        toast("success", "Frontend watcher started");
        await updateStatus();
      } catch (err) {
        toast("error", "Failed to start Vite", err.message);
      } finally {
        startBtn.disabled = false;
      }
    });

    stopBtn.addEventListener("click", async () => {
      stopBtn.disabled = true;
      try {
        await LD.call("vite_stop", { name: site.name, site_path: site.path });
        toast("info", "Frontend watcher stopped");
        await updateStatus();
      } catch (err) {
        toast("error", "Failed to stop Vite", err.message);
      } finally {
        stopBtn.disabled = false;
      }
    });

    restartBtn.addEventListener("click", async () => {
      restartBtn.disabled = true;
      try {
        await LD.call("vite_stop", { name: site.name, site_path: site.path });
        await new Promise(r => setTimeout(r, 600));
        await LD.call("vite_start", { name: site.name, site_path: site.path });
        toast("success", "Vite watcher restarted");
        await updateStatus();
      } catch (err) {
        toast("error", "Restart failed", err.message);
      } finally {
        restartBtn.disabled = false;
      }
    });

    openBtn.addEventListener("click", () => {
      window.open(`http://localhost:${currentPort}`, "_blank");
    });

    clearBtn.addEventListener("click", () => {
      logConsole.textContent = "";
    });

    await updateStatus();
    pollInterval = setInterval(updateStatus, 3000);

    return () => {
      if (pollInterval) clearInterval(pollInterval);
    };
  }

  // ── Local Media & Storage Gallery (Feature 12) ─────────────────────────
  async function mountMedia(container, site) {
    currentSite = site;
    let allFiles = [];
    let activeFilter = "all";
    let searchQuery = "";
    let hasMore = false;
    let searchTimer = null;
    const PAGE = 120;

    container.innerHTML = `
      <div class="media-container" style="display:flex;flex-direction:column;gap:14px">
        <div id="media-symlink-alert"></div>

        <div class="card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:12px">
            <div>
              <h3 style="margin:0 0 4px 0">${icon("folder")} Storage Gallery</h3>
              <div style="font-size:12px" class="muted">
                Location: <code>storage/app/public</code> · <span id="media-count-label">0 files</span> (<span id="media-size-label">0 B</span>)
              </div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <div class="seg" id="media-filter-seg">
              <button class="active" data-filter="all">All</button>
              <button data-filter="image">Images</button>
              <button data-filter="document">Docs</button>
              <button data-filter="video">Video</button>
            </div>
            <input type="search" id="media-search-input" placeholder="Search media..." class="input sm" style="width:180px">
            <button id="btn-media-refresh" class="btn sm">${icon("refresh")} Refresh</button>
          </div>
        </div>

        <div id="media-grid-pane">
          <div class="muted" style="padding:32px;text-align:center">${icon("spinner")} Scanning storage/app/public...</div>
        </div>
      </div>
    `;

    const alertPane = $("#media-symlink-alert", container);
    const gridPane = $("#media-grid-pane", container);
    const countLabel = $("#media-count-label", container);
    const sizeLabel = $("#media-size-label", container);
    const searchInput = $("#media-search-input", container);
    const refreshBtn = $("#btn-media-refresh", container);
    const filterSeg = $("#media-filter-seg", container);

    // Filtering and paging happen in the backend so a large storage folder
    // doesn't ship every file's metadata to the page at once.
    async function loadMedia({ append = false } = {}) {
      if (!append) gridPane.innerHTML = `<div class="muted" style="padding:32px;text-align:center">${icon("spinner")} Scanning files...</div>`;
      try {
        const res = await LD.call("media_list", {
          name: site.name, query: searchQuery, type: activeFilter,
          offset: append ? allFiles.length : 0, limit: PAGE,
        });
        allFiles = append ? allFiles.concat(res.files || []) : (res.files || []);
        hasMore = !!res.has_more;
        countLabel.textContent = `${res.total_files || 0} file(s)`;
        sizeLabel.textContent = res.total_size_formatted || "0 B";

        if (res.symlink && !res.symlink.linked) {
          alertPane.innerHTML = `
            <div class="card" style="background:rgba(245, 158, 11, 0.1);border:1px solid #f59e0b;padding:12px 16px;display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:6px">
              <div style="display:flex;align-items:center;gap:10px">
                <span style="color:#f59e0b;font-size:20px">${icon("alert")}</span>
                <div>
                  <b style="font-size:13px;color:#f59e0b">Missing public/storage Symlink!</b>
                  <div style="font-size:12px;color:var(--text-muted)">Public web users cannot access files uploaded to <code>storage/app/public</code> without a valid symlink.</div>
                </div>
              </div>
              <button id="btn-fix-symlink" class="btn sm primary">${icon("link")} Repair Symlink (storage:link)</button>
            </div>
          `;
          $("#btn-fix-symlink", alertPane)?.addEventListener("click", async () => {
            try {
              await LD.call("media_fix_symlink", { name: site.name });
              toast("success", "Storage symlink repaired!");
              await loadMedia();
            } catch (err) {
              toast("error", "Symlink repair failed", err.message);
            }
          });
        } else {
          alertPane.innerHTML = "";
        }

        renderGrid();
      } catch (err) {
        gridPane.innerHTML = `<div class="card error-pane">${icon("alert")} Failed to load storage gallery: ${esc(err.message)}</div>`;
      }
    }

    function renderGrid() {
      const filtered = allFiles;

      if (!filtered.length) {
        gridPane.innerHTML = `
          <div class="card" style="text-align:center;padding:48px 20px" class="muted">
            <span style="font-size:32px;opacity:0.4">${icon("folder")}</span>
            <div style="font-weight:600;margin-top:8px">${searchQuery || activeFilter !== "all" ? "No files match this filter" : "No media files yet"}</div>
            <div style="font-size:12px;margin-top:4px" class="muted">Uploaded files in <code>storage/app/public</code> show up here.</div>
          </div>
        `;
        return;
      }

      const cardsHtml = filtered.map(f => {
        let thumbHtml = "";
        if (f.type === "image") {
          const directUrl = site.url ? `${site.url}${f.storage_url}` : f.storage_url;
          thumbHtml = `<img src="${esc(directUrl)}" alt="${esc(f.filename)}" class="media-thumb-img" loading="lazy" decoding="async" onerror="this.onerror=null;this.hidden=true;this.nextElementSibling.hidden=false"><span hidden>${icon("file")}</span>`;
        } else if (f.type === "video") {
          thumbHtml = `<span style="font-size:36px;color:var(--accent)">${icon("play")}</span>`;
        } else {
          thumbHtml = `<span style="font-size:36px;color:var(--text-muted)">${icon("file")}</span>`;
        }

        const dimsText = f.width && f.height ? `${f.width}×${f.height}` : "";

        return `
          <div class="media-card" data-media-path="${esc(f.relative_path)}">
            <div class="media-thumb-wrap">
              ${thumbHtml}
            </div>
            <div class="media-card-body">
              <div class="media-card-name" title="${esc(f.filename)}">${esc(f.filename)}</div>
              <div class="media-card-meta">
                <span>${f.size_formatted}</span>
                <span>${dimsText}</span>
              </div>
            </div>
          </div>
        `;
      }).join("");

      gridPane.innerHTML = `<div class="media-gallery-grid">${cardsHtml}</div>
        ${hasMore ? `<div style="text-align:center;margin-top:14px"><button class="btn sm" id="btn-media-more">Show more (${allFiles.length} shown)</button></div>` : ""}`;
      $("#btn-media-more", gridPane)?.addEventListener("click", (e) => {
        e.currentTarget.disabled = true;
        loadMedia({ append: true });
      });

      $$("[data-media-path]", gridPane).forEach(card => {
        card.addEventListener("click", () => {
          const rel = card.dataset.mediaPath;
          const file = allFiles.find(x => x.relative_path === rel);
          if (!file) return;

          const directUrl = site.url ? `${site.url}${file.storage_url}` : file.storage_url;

          openModal(`
            <div class="modal md">
              <div class="modal-header">
                <h2>${icon("file")} ${esc(file.filename)}</h2>
              </div>
              <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
                ${file.type === "image" ? `
                  <div style="text-align:center;background:var(--surface-2);padding:14px;border-radius:8px">
                    <img src="${esc(directUrl)}" style="max-width:100%;max-height:360px;object-fit:contain;border-radius:4px" onerror="this.style.display='none'">
                  </div>
                ` : ""}
                <table class="cache-table">
                  <tr><th style="width:120px">Path</th><td style="font-family:var(--mono);font-size:12px">${esc(file.relative_path)}</td></tr>
                  <tr><th>Public URL</th><td style="font-family:var(--mono);font-size:12px"><a href="${esc(directUrl)}" target="_blank" class="link">${esc(directUrl)}</a></td></tr>
                  <tr><th>Size</th><td style="font-size:12px">${file.size_formatted} (${file.size} bytes)</td></tr>
                  <tr><th>MIME Type</th><td style="font-size:12px">${esc(file.mime_type)}</td></tr>
                  ${file.width ? `<tr><th>Dimensions</th><td style="font-size:12px">${file.width} × ${file.height} px</td></tr>` : ""}
                </table>
              </div>
              <div class="modal-footer" style="justify-content:space-between">
                <button type="button" class="btn danger" id="btn-modal-delete-media">${icon("trash")} Delete File</button>
                <div style="display:flex;gap:8px">
                  <button type="button" class="btn" id="btn-modal-copy-url">${icon("copy")} Copy URL</button>
                  <button type="button" class="btn primary" data-dismiss>Close</button>
                </div>
              </div>
            </div>
          `, (modalRoot) => {
            $("#btn-modal-copy-url", modalRoot)?.addEventListener("click", () => {
              navigator.clipboard?.writeText(directUrl);
              toast("success", "URL copied to clipboard");
            });

            $("#btn-modal-delete-media", modalRoot)?.addEventListener("click", async () => {
              const ok = await confirmModal({
                title: "Delete File?",
                message: `Permanently delete <code>${esc(file.filename)}</code> from storage?`,
                confirm: "Delete",
                danger: true,
              });
              if (!ok) return;

              try {
                await LD.call("media_delete", { name: site.name, path: file.relative_path });
                toast("info", `File ${file.filename} deleted`);
                closeModal();
                await loadMedia();
              } catch (err) {
                toast("error", "Delete failed", err.message);
              }
            });
          });
        });
      });
    }

    refreshBtn.addEventListener("click", () => loadMedia());
    searchInput.addEventListener("input", (e) => {
      searchQuery = e.target.value.toLowerCase().trim();
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => loadMedia(), 250);
    });

    filterSeg.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-filter]");
      if (btn) {
        activeFilter = btn.dataset.filter;
        $$("button", filterSeg).forEach(b => b.classList.toggle("active", b === btn));
        loadMedia();
      }
    });

    await loadMedia();
  }

  // ── Visual Package Hub (Feature 14) ──────────────────────────────────
  async function mountPackages(container, site) {
    currentSite = site;
    let packagesData = null;
    let outdatedData = null;
    let auditData = null;
    let activeSubtab = "composer"; // "composer" | "npm"
    let currentFilter = "";
    let activeTypeFilter = "all"; // "all" | "direct" | "dev" | "outdated" | "vulnerable"

    container.innerHTML = `
      <div class="packages-container" style="display:flex;flex-direction:column;gap:14px">
        <div class="card" style="padding:14px 16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
          <div>
            <h3 style="margin:0 0 4px 0">${icon("box")} Package Hub</h3>
            <p class="muted" style="margin:0;font-size:12px" id="pkg-summary-label">Inspecting dependencies…</p>
          </div>
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <button id="btn-pkg-audit" class="btn sm">${icon("shield")} Audit Security</button>
            <button id="btn-pkg-outdated" class="btn sm">${icon("refresh")} Check Outdated</button>
            <button id="btn-pkg-install" class="btn sm primary">${icon("plus")} Install Package</button>
            <button id="btn-pkg-update-all" class="btn sm">${icon("zap")} Update All</button>
          </div>
        </div>

        <!-- Security Advisories Banner -->
        <div id="pkg-audit-alert" style="display:none"></div>

        <!-- Subtabs & Controls -->
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
          <div class="segmented" id="pkg-manager-tabs" style="width:300px">
            <button class="segment active" data-pkg-tab="composer">${icon("code")} Composer (PHP)</button>
            <button class="segment" data-pkg-tab="npm">${icon("terminal")} NPM (JS)</button>
          </div>
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <div class="segmented" id="pkg-type-filters" style="font-size:11.5px">
              <button class="segment active" data-pkg-filter="all">All</button>
              <button class="segment" data-pkg-filter="direct">Direct</button>
              <button class="segment" data-pkg-filter="dev">Dev</button>
              <button class="segment" data-pkg-filter="outdated">Outdated</button>
              <button class="segment" data-pkg-filter="vulnerable">Vulnerable</button>
            </div>
            <input type="search" id="pkg-search-input" placeholder="Search packages…" class="input sm" style="width:180px">
          </div>
        </div>

        <!-- Packages Table Card -->
        <div id="pkg-table-pane" class="card" style="padding:0;overflow:hidden">
          <div class="loading-pane">${icon("pulse")} Loading package lists…</div>
        </div>
      </div>
    `;

    const summaryLabel = $("#pkg-summary-label", container);
    const auditAlert = $("#pkg-audit-alert", container);
    const tablePane = $("#pkg-table-pane", container);
    const searchInput = $("#pkg-search-input", container);
    const btnAudit = $("#btn-pkg-audit", container);
    const btnOutdated = $("#btn-pkg-outdated", container);
    const btnInstall = $("#btn-pkg-install", container);
    const btnUpdateAll = $("#btn-pkg-update-all", container);
    const managerTabs = $("#pkg-manager-tabs", container);
    const typeFilters = $("#pkg-type-filters", container);

    async function loadPackages() {
      tablePane.innerHTML = `<div class="loading-pane">${icon("pulse")} Reading package files…</div>`;
      try {
        packagesData = await LD.call("packages_list", { name: site.name });
        if (!packagesData.ok) throw new Error(packagesData.error || "Failed to list packages");

        const cCount = packagesData.composer_count || 0;
        const nCount = packagesData.npm_count || 0;
        summaryLabel.textContent = `${cCount} Composer (PHP) · ${nCount} NPM (JS) dependencies`;

        if (!packagesData.has_composer && packagesData.has_npm) {
          activeSubtab = "npm";
          $$("button", managerTabs).forEach((b) => b.classList.toggle("active", b.dataset.pkgTab === "npm"));
        }

        renderTable();

        // Auto-check outdated in background
        LD.call("packages_outdated", { name: site.name, force: false })
          .then((res) => {
            if (res.ok) {
              outdatedData = res;
              renderTable();
            }
          })
          .catch(() => {});
      } catch (err) {
        tablePane.innerHTML = `<div style="padding:20px;color:var(--red)">${esc(err.message)}</div>`;
      }
    }

    function renderTable() {
      if (!packagesData) return;
      const isComposer = activeSubtab === "composer";
      const rawList = isComposer ? (packagesData.composer_packages || []) : (packagesData.npm_packages || []);
      const outdatedList = isComposer ? (outdatedData?.composer_outdated || []) : (outdatedData?.npm_outdated || []);
      const advisories = isComposer ? (auditData?.composer_advisories || []) : (auditData?.npm_advisories || []);

      const q = currentFilter.toLowerCase().trim();

      const filtered = rawList.filter((pkg) => {
        if (q && !pkg.name.toLowerCase().includes(q) && !(pkg.description || "").toLowerCase().includes(q)) return false;

        const isDirect = Boolean(pkg.direct);
        const isDev = pkg.type === "dev";
        const hasOutdated = isComposer
          ? outdatedList.some((o) => o.name === pkg.name)
          : outdatedList.some((o) => o.name === pkg.name);
        const hasVuln = advisories.some((a) => a.package === pkg.name);

        if (activeTypeFilter === "direct" && !isDirect) return false;
        if (activeTypeFilter === "dev" && !isDev) return false;
        if (activeTypeFilter === "outdated" && !hasOutdated) return false;
        if (activeTypeFilter === "vulnerable" && !hasVuln) return false;

        return true;
      });

      if (!filtered.length) {
        tablePane.innerHTML = `
          <div style="padding:40px 20px;text-align:center" class="muted">
            ${icon("box")}
            <div style="font-weight:600;margin-top:8px">No packages match the filter</div>
            <div style="font-size:12px;margin-top:4px">Try selecting a different filter or clearing search.</div>
          </div>
        `;
        return;
      }

      const rows = filtered.map((pkg) => {
        const outInfo = isComposer
          ? outdatedList.find((o) => o.name === pkg.name)
          : outdatedList.find((o) => o.name === pkg.name);

        const vulnInfo = advisories.filter((a) => a.package === pkg.name);

        let latestHtml = `<span class="muted mono sm">—</span>`;
        if (outInfo) {
          const targetVer = isComposer ? outInfo.latest : (outInfo.latest || outInfo.wanted);
          latestHtml = `
            <span class="chip xs text-amber" title="Newer version available: ${esc(targetVer)}">
              ${icon("arrow-up")} ${esc(targetVer)}
            </span>
          `;
        }

        let statusHtml = `<span class="chip xs muted">Up to date</span>`;
        if (vulnInfo.length > 0) {
          statusHtml = `<span class="chip xs text-red" title="${esc(vulnInfo[0].title || 'Vulnerability')}">⚠️ ${vulnInfo[0].severity || 'CVE'}</span>`;
        } else if (outInfo) {
          statusHtml = `<span class="chip xs text-amber">Update available</span>`;
        }

        const typeBadge = pkg.type === "dev" ? `<span class="chip xs" style="background:var(--surface-3);font-size:10px">dev</span>` : `<span class="chip xs" style="font-size:10px">prod</span>`;
        const directBadge = pkg.direct ? `<span class="chip xs text-blue" style="font-size:10px">direct</span>` : `<span class="chip xs muted" style="font-size:10px">transitive</span>`;

        return `
          <tr data-pkg-name="${esc(pkg.name)}">
            <td>
              <div style="display:flex;align-items:center;gap:6px">
                <a href="${esc(pkg.homepage || '#')}" target="_blank" rel="noopener" style="font-weight:600;font-family:var(--mono);font-size:12.5px;color:var(--text)">
                  ${esc(pkg.name)}
                </a>
                ${pkg.license && pkg.license !== "Unknown" ? `<span class="chip xs muted" style="font-size:10px">${esc(pkg.license)}</span>` : ""}
              </div>
              ${pkg.description ? `<div class="muted xs" style="margin-top:2px;max-width:380px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(pkg.description)}</div>` : ""}
            </td>
            <td>
              <div style="display:flex;gap:4px;align-items:center">
                ${typeBadge}
                ${directBadge}
              </div>
            </td>
            <td><span class="mono sm" style="font-weight:600">${esc(pkg.version || "dev-main")}</span></td>
            <td>${latestHtml}</td>
            <td>${statusHtml}</td>
            <td style="text-align:right;white-space:nowrap">
              ${outInfo ? `<button class="btn sm" data-pkg-action="update" data-pkg-name="${esc(pkg.name)}" title="Update to latest">${icon("refresh")} Update</button>` : ""}
              ${pkg.direct ? `<button class="btn sm danger ghost" data-pkg-action="remove" data-pkg-name="${esc(pkg.name)}" title="Remove package">${icon("trash")}</button>` : ""}
            </td>
          </tr>
        `;
      }).join("");

      tablePane.innerHTML = `
        <div class="routes-table-wrap">
          <table class="routes-table" style="font-size:12px">
            <thead>
              <tr>
                <th>Package</th>
                <th>Type</th>
                <th>Installed</th>
                <th>Latest</th>
                <th>Status</th>
                <th style="text-align:right">Actions</th>
              </tr>
            </thead>
            <tbody>
              ${rows}
            </tbody>
          </table>
        </div>
      `;

      // Wire row actions
      $$("[data-pkg-action]", tablePane).forEach((btn) => {
        btn.addEventListener("click", async (e) => {
          const action = btn.dataset.pkgAction;
          const pkgName = btn.dataset.pkgName;
          if (action === "update") {
            btn.disabled = true;
            btn.innerHTML = `${icon("pulse")} Updating…`;
            try {
              const res = await LD.call("packages_manage", {
                name: site.name,
                action: "update",
                manager: activeSubtab,
                package: pkgName,
              });
              if (!res.ok) throw new Error(res.error || "Update failed");
              toast("success", `Updated ${pkgName} successfully`);
              await loadPackages();
            } catch (err) {
              toast("error", "Update failed", err.message);
            } finally {
              btn.disabled = false;
            }
          } else if (action === "remove") {
            const confirmed = await confirmModal({
              title: `Remove ${pkgName}?`,
              message: `Are you sure you want to uninstall <b>${esc(pkgName)}</b> from your ${activeSubtab} dependencies?`,
              confirm: "Uninstall",
              danger: true,
            });
            if (!confirmed) return;
            btn.disabled = true;
            btn.innerHTML = `${icon("pulse")} Removing…`;
            try {
              const res = await LD.call("packages_manage", {
                name: site.name,
                action: "remove",
                manager: activeSubtab,
                package: pkgName,
              });
              if (!res.ok) throw new Error(res.error || "Removal failed");
              toast("success", `Removed ${pkgName}`);
              await loadPackages();
            } catch (err) {
              toast("error", "Removal failed", err.message);
            } finally {
              btn.disabled = false;
            }
          }
        });
      });
    }

    // Event listeners
    managerTabs.addEventListener("click", (e) => {
      const seg = e.target.closest("[data-pkg-tab]");
      if (seg) {
        activeSubtab = seg.dataset.pkgTab;
        $$("button", managerTabs).forEach((b) => b.classList.toggle("active", b === seg));
        renderTable();
      }
    });

    typeFilters.addEventListener("click", (e) => {
      const seg = e.target.closest("[data-pkg-filter]");
      if (seg) {
        activeTypeFilter = seg.dataset.pkgFilter;
        $$("button", typeFilters).forEach((b) => b.classList.toggle("active", b === seg));
        renderTable();
      }
    });

    searchInput.addEventListener("input", (e) => {
      currentFilter = e.target.value;
      renderTable();
    });

    btnOutdated.addEventListener("click", async () => {
      btnOutdated.disabled = true;
      btnOutdated.innerHTML = `${icon("pulse")} Checking…`;
      try {
        const res = await LD.call("packages_outdated", { name: site.name, force: true });
        if (!res.ok) throw new Error(res.error || "Failed to check outdated packages");
        outdatedData = res;
        const count = activeSubtab === "composer" ? (res.composer_outdated_count || 0) : (res.npm_outdated_count || 0);
        toast("info", `${count} outdated package${count === 1 ? "" : "s"} found`);
        renderTable();
      } catch (err) {
        toast("error", "Check outdated failed", err.message);
      } finally {
        btnOutdated.disabled = false;
        btnOutdated.innerHTML = `${icon("refresh")} Check Outdated`;
      }
    });

    btnAudit.addEventListener("click", async () => {
      btnAudit.disabled = true;
      btnAudit.innerHTML = `${icon("pulse")} Auditing…`;
      try {
        const res = await LD.call("packages_audit", { name: site.name, force: true });
        if (!res.ok) throw new Error(res.error || "Failed to audit packages");
        auditData = res;
        const cVulns = res.composer_advisories_count || 0;
        const nVulns = res.npm_vulnerabilities || 0;
        const total = cVulns + nVulns;

        if (total > 0) {
          auditAlert.style.display = "block";
          auditAlert.innerHTML = `
            <div class="card error-card" style="padding:12px 16px;border-left:4px solid var(--red)">
              <div style="display:flex;align-items:center;justify-content:space-between">
                <b>${icon("alert")} ${total} Security Vulnerabilit${total === 1 ? "y" : "ies"} Detected</b>
                <button class="btn xs ghost" id="btn-dismiss-audit-alert">Dismiss</button>
              </div>
              <p class="muted sm" style="margin:4px 0 8px">Vulnerabilities reported by Composer / NPM audit advisories:</p>
              <div style="display:flex;flex-direction:column;gap:6px">
                ${(res.composer_advisories || []).map((a) => `
                  <div style="font-size:12px;display:flex;gap:8px;align-items:center">
                    <span class="chip xs text-red">${esc(a.severity)}</span>
                    <b>${esc(a.package)}</b>: ${esc(a.title)}
                    ${a.cve ? `<span class="chip xs muted">${esc(a.cve)}</span>` : ""}
                    ${a.link ? `<a href="${esc(a.link)}" target="_blank" rel="noopener" class="xs">View Advisory</a>` : ""}
                  </div>
                `).join("")}
              </div>
            </div>
          `;
          $("#btn-dismiss-audit-alert", auditAlert)?.addEventListener("click", () => {
            auditAlert.style.display = "none";
          });
          toast("error", `${total} vulnerabilities found! Review the security alert above.`);
        } else {
          auditAlert.style.display = "block";
          auditAlert.innerHTML = `
            <div class="card" style="padding:10px 14px;border-left:4px solid var(--green);background:var(--green-soft);display:flex;align-items:center;justify-content:space-between">
              <span style="font-size:12.5px;color:var(--green)">✓ <b>Zero vulnerabilities!</b> All dependencies passed security audits.</span>
              <button class="btn xs ghost" id="btn-dismiss-audit-alert">Dismiss</button>
            </div>
          `;
          $("#btn-dismiss-audit-alert", auditAlert)?.addEventListener("click", () => {
            auditAlert.style.display = "none";
          });
          toast("success", "Audit passed: No known vulnerabilities found");
        }
        renderTable();
      } catch (err) {
        toast("error", "Security audit failed", err.message);
      } finally {
        btnAudit.disabled = false;
        btnAudit.innerHTML = `${icon("shield")} Audit Security`;
      }
    });

    btnUpdateAll.addEventListener("click", async () => {
      const confirmed = await confirmModal({
        title: `Update all ${activeSubtab.toUpperCase()} packages?`,
        message: `This will execute <code>${activeSubtab} update</code> in your project. It may take a minute or two.`,
        confirm: "Update All",
        danger: false,
      });
      if (!confirmed) return;

      btnUpdateAll.disabled = true;
      btnUpdateAll.innerHTML = `${icon("pulse")} Updating…`;
      try {
        const res = await LD.call("packages_manage", {
          name: site.name,
          action: "update",
          manager: activeSubtab,
        });
        if (!res.ok) throw new Error(res.error || "Update all failed");
        toast("success", `All ${activeSubtab} packages updated successfully!`);
        await loadPackages();
      } catch (err) {
        toast("error", "Update all failed", err.message);
      } finally {
        btnUpdateAll.disabled = false;
        btnUpdateAll.innerHTML = `${icon("zap")} Update All`;
      }
    });

    btnInstall.addEventListener("click", () => {
      openModal(`
        <div class="modal" style="max-width:520px">
          <div class="modal-header">
            <h2>${icon("plus")} Install Package</h2>
            <p>Require a new dependency into your project.</p>
          </div>
          <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
            <div>
              <label style="font-size:12px;font-weight:600">Package Manager:</label>
              <select id="modal-install-manager" class="select sm" style="width:100%;margin-top:4px">
                <option value="composer" ${activeSubtab === "composer" ? "selected" : ""}>Composer (PHP)</option>
                <option value="npm" ${activeSubtab === "npm" ? "selected" : ""}>NPM (Node.js)</option>
              </select>
            </div>
            <div>
              <label style="font-size:12px;font-weight:600">Package Name:</label>
              <input type="text" id="modal-install-name" placeholder="e.g. spatie/laravel-permission or axios" class="input sm" style="width:100%;margin-top:4px" autocomplete="off">
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <input type="checkbox" id="modal-install-dev" style="cursor:pointer">
              <label for="modal-install-dev" style="font-size:12px;cursor:pointer">Development dependency (--dev / --save-dev)</label>
            </div>
            <div id="modal-install-log" style="display:none;max-height:160px;overflow-y:auto;background:var(--term-bg);color:var(--term-text);padding:10px;border-radius:6px;font-family:var(--mono);font-size:11px"></div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn sm" data-dismiss>Cancel</button>
            <button type="button" class="btn sm primary" id="btn-modal-install-run">${icon("download")} Install</button>
          </div>
        </div>`, (root) => {
        $("[data-dismiss]", root)?.addEventListener("click", closeModal);
        $("#btn-modal-install-run", root)?.addEventListener("click", async () => {
          const mgr = $("#modal-install-manager", root)?.value || "composer";
          const pkg = $("#modal-install-name", root)?.value.trim();
          const dev = Boolean($("#modal-install-dev", root)?.checked);
          const logBox = $("#modal-install-log", root);
          const runBtn = $("#btn-modal-install-run", root);

          if (!pkg) return toast("error", "Package name is required");

          runBtn.disabled = true;
          runBtn.innerHTML = `${icon("pulse")} Installing…`;
          if (logBox) {
            logBox.style.display = "block";
            logBox.textContent = `Running ${mgr} require ${pkg}…\nPlease wait…\n`;
          }

          try {
            const res = await LD.call("packages_manage", {
              name: site.name,
              action: "install",
              manager: mgr,
              package: pkg,
              dev,
            });
            if (!res.ok) throw new Error(res.error || "Installation failed");
            if (logBox) logBox.textContent += res.output || "Success!\n";
            toast("success", `Installed ${pkg} successfully!`);
            setTimeout(() => {
              closeModal();
              loadPackages();
            }, 600);
          } catch (err) {
            if (logBox) logBox.textContent += `\nError: ${err.message}`;
            toast("error", "Installation failed", err.message);
          } finally {
            runBtn.disabled = false;
            runBtn.innerHTML = `${icon("download")} Install`;
          }
        });
      });
    });

    await loadPackages();
  }

  /* ── Studio Agent Tab (Stage 13) ────────────────────────────────────────── */
  let studioHandler = null;          // set by the mounted Studio tab
  const studioEarly = new Map();     // run_id -> events that arrived before studio_agent_start returned
  function onStudioEvent(event) {
    if (studioHandler && studioHandler(event)) return;
    if (!event.run_id) return;
    const list = studioEarly.get(event.run_id) || [];
    list.push(event);
    studioEarly.set(event.run_id, list.slice(-500));
    if (studioEarly.size > 20) studioEarly.delete(studioEarly.keys().next().value);
  }
  async function mountStudio(container, site) {
    destroy();
    currentSite = site;
    const T = (k, f) => (window.t ? window.t(k, f) : f);
    const SOURCE_LABEL = {
      cli: T("studio_src_cli", "local CLI agent"),
      settings: T("studio_src_settings", "AI from Settings → AI"),
      ollama: T("studio_src_ollama", "local Ollama"),
      none: T("studio_src_none", "no AI available"),
    };

    container.innerHTML = `
      <div class="studio-container" style="display:flex;flex-direction:column;height:100%;gap:12px;padding:4px 0">
        <div class="card" style="padding:10px 14px;display:flex;flex-direction:column;gap:8px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
            <span style="font-weight:600;display:flex;align-items:center;gap:6px;font-size:14px">${icon("sparkles")} ${T("studio_title", "Studio Coding Agent")}</span>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <label class="muted xs" for="studio-conv-select" style="font-weight:500">${T("studio_conversation", "Conversation")}:</label>
              <select id="studio-conv-select" class="input sm" style="max-width:230px;font-size:12px"></select>
              <button class="btn ghost icon-btn sm" id="studio-new-chat" title="${esc(T("studio_new_chat", "New conversation"))}">${icon("plus")}</button>
              <button class="btn ghost icon-btn sm" id="studio-rename-chat" title="${esc(T("studio_rename_chat", "Rename conversation"))}">${icon("edit")}</button>
              <button class="btn ghost icon-btn sm" id="studio-delete-chat" title="${esc(T("studio_delete_chat", "Delete conversation"))}">${icon("trash")}</button>
            </div>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
            <div style="display:flex;align-items:center;gap:8px">
              <label class="muted xs" for="studio-agent-select" style="font-weight:500">${T("studio_agent_label", "Agent")}:</label>
              <select id="studio-agent-select" class="input sm" style="max-width:240px;font-size:12px">
                <option value="auto">${T("studio_auto", "Auto (Settings AI first)")}</option>
              </select>
              <span id="studio-model-wrap" style="display:none;align-items:center;gap:6px">
                <label class="muted xs" for="studio-model-select" style="font-weight:500">${T("studio_model", "Model")}:</label>
                <select id="studio-model-select" class="input sm" style="max-width:230px;font-size:12px"></select>
              </span>
              <span id="studio-effort-wrap" style="display:none;align-items:center;gap:6px" title="${esc(T("studio_effort_hint", "How long the model may think before it answers. Higher is smarter but slower and uses more of your limit."))}">
                <label class="muted xs" for="studio-effort-select" style="font-weight:500">${T("studio_effort", "Effort")}:</label>
                <select id="studio-effort-select" class="input sm" style="font-size:12px">
                  <option value="">${T("studio_effort_default", "Default")}</option>
                  <option value="low">${T("studio_effort_low", "Low")}</option>
                  <option value="medium">${T("studio_effort_medium", "Medium")}</option>
                  <option value="high">${T("studio_effort_high", "High")}</option>
                  <option value="xhigh">${T("studio_effort_xhigh", "Extra high")}</option>
                  <option value="max">${T("studio_effort_max", "Max")}</option>
                </select>
              </span>
              <label class="xs" style="display:flex;align-items:center;gap:4px" title="${esc(T("studio_allow_edits_hint", "Approve file edits without asking. Without it, the agent asks you before each edit. Commands are always asked about, except read-only ones like ls or git status. File changes can be reverted below."))}">
                <input type="checkbox" id="studio-allow-edits"> ${T("studio_allow_edits", "Allow file edits")}
              </label>
              <label class="xs" id="studio-think-wrap" style="display:none;align-items:center;gap:4px" title="${esc(T("studio_think_hint", "Let a thinking model (qwen3, deepseek-r1…) reason before answering and show that reasoning. Slower."))}">
                <input type="checkbox" id="studio-think"> ${T("studio_think", "Show thinking")}
              </label>
            </div>
            <span class="muted xs" id="studio-who"></span>
          </div>
        </div>

        <div class="studio-chips" style="display:flex;gap:6px;flex-wrap:wrap;padding:0 2px">
          <button class="chip sm ghost studio-chip" data-prompt="Explain the architecture, models, and routing of this Laravel project.">✨ Architecture</button>
          <button class="chip sm ghost studio-chip" data-prompt="Analyze recent error logs and propose fixes for any detected exceptions.">🐞 Fix Errors</button>
          <button class="chip sm ghost studio-chip" data-prompt="Generate Pest / PHPUnit tests for the primary models and routes.">🧪 Generate Tests</button>
          <button class="chip sm ghost studio-chip" data-prompt="Review database queries and suggest indexes or eager loading to avoid N+1 issues.">⚡ Optimize Queries</button>
        </div>

        <div id="studio-chat-stream" style="flex:1;min-height:220px;max-height:420px;overflow-y:auto;background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:14px;display:flex;flex-direction:column;gap:12px"></div>

        <div id="studio-diff-container" style="display:none;background:var(--surface);border:1px solid var(--accent);border-radius:8px;padding:12px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;gap:8px;flex-wrap:wrap">
            <span style="font-weight:600;font-size:13px;display:flex;align-items:center;gap:6px">
              ${icon("code")} ${T("studio_changes_made", "Changes made by the agent")}
              <span id="studio-diff-file-tag" class="chip sm"></span>
            </span>
            <div style="display:flex;gap:6px">
              <button class="btn primary sm" id="studio-diff-keep-btn">${icon("check")} ${T("studio_keep", "Keep")}</button>
              <button class="btn ghost sm" id="studio-diff-revert-btn">${icon("x")} ${T("studio_revert", "Revert")}</button>
            </div>
          </div>
          <div id="studio-diff-body" style="max-height:260px;overflow-y:auto"></div>
        </div>

        <div class="studio-input-box" style="position:relative;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:8px">
          <textarea id="studio-prompt-input" class="input" style="width:100%;height:68px;resize:none;border:none;background:transparent;outline:none;font-size:13px;padding:4px" placeholder="${esc(T("studio_placeholder", "Ask the agent about this project (Ctrl+Enter to send)…"))}"></textarea>
          <div style="display:flex;align-items:center;justify-content:space-between;margin-top:6px;padding-top:4px;border-top:1px solid var(--border)">
            <div style="display:flex;align-items:center;gap:8px">
              <button class="btn ghost sm icon-btn" id="studio-voice-btn" title="Voice Dictation (Click to speak)">${icon("mic")}</button>
              <span id="studio-voice-status" class="muted xs" style="display:none">Listening…</span>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <span class="muted xs">Ctrl+Enter</span>
              <button class="btn primary sm" id="studio-send-btn">${icon("play")} ${T("studio_send", "Send")}</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const chatStream = $("#studio-chat-stream", container);
    const promptInput = $("#studio-prompt-input", container);
    const sendBtn = $("#studio-send-btn", container);
    const agentSelect = $("#studio-agent-select", container);
    const convSelect = $("#studio-conv-select", container);
    const whoEl = $("#studio-who", container);
    const allowEdits = $("#studio-allow-edits", container);
    const thinkWrap = $("#studio-think-wrap", container);
    const thinkBox = $("#studio-think", container);
    try { thinkBox.checked = localStorage.getItem("ld.studio.think") === "1"; } catch {}
    thinkBox.addEventListener("change", () => { try { localStorage.setItem("ld.studio.think", thinkBox.checked ? "1" : "0"); } catch {} });
    const modelWrap = $("#studio-model-wrap", container);
    const modelSelect = $("#studio-model-select", container);
    const MODEL_AGENTS = ["antigravity", "claude", "opencode", "ollama", "cloud_llm"];
    const effortWrap = $("#studio-effort-wrap", container);
    const effortSelect = $("#studio-effort-select", container);
    const effortKey = (agentId) => `ld.studio.effort.${agentId}`;
    effortSelect.addEventListener("change", () => { try { localStorage.setItem(effortKey(agentSelect.value), effortSelect.value); } catch {} });
    const showEffort = (agentId, levels) => {
      const on = (levels || []).length > 0;
      effortWrap.style.display = on ? "flex" : "none";
      if (!on) { effortSelect.value = ""; return; }
      let saved = "";
      try { saved = localStorage.getItem(effortKey(agentId)) || ""; } catch {}
      effortSelect.value = levels.includes(saved) ? saved : "";
    };
    const modelKey = (agentId) => `ld.studio.model.${agentId}`;
    const savedModel = (agentId) => { try { return localStorage.getItem(modelKey(agentId)) || ""; } catch { return ""; } };
    let modelLoadSeq = 0;
    const loadModels = async (agentId, preferred) => {
      const seq = ++modelLoadSeq;
      if (!MODEL_AGENTS.includes(agentId)) { modelWrap.style.display = "none"; modelSelect.innerHTML = ""; showEffort(agentId, []); return; }
      modelWrap.style.display = "flex";
      modelSelect.innerHTML = `<option value="">${esc(T("studio_model_loading", "Loading models…"))}</option>`;
      modelSelect.disabled = true;
      let info = { models: [], selectable: false };
      try { info = await LD.call("studio_agent_models", { agent_id: agentId }); } catch (err) { info.error = err.message; }
      if (seq !== modelLoadSeq) return;  // the agent changed meanwhile
      showEffort(agentId, info.efforts);
      if (!info.selectable) {
        if (agentId === "cloud_llm" && !info.error) { modelWrap.style.display = "none"; return; }  // cloud: model from Settings
        modelSelect.innerHTML = `<option value="">${esc(info.error || T("studio_model_default", "Default model"))}</option>`;
        modelSelect.title = info.error || "";
        return;
      }
      const want = preferred ?? savedModel(agentId);
      // Grouped by provider (OpenCode) or Latest / Versions (Claude Code) when the agent reports groups.
      const groups = [];
      info.models.forEach((m) => {
        const g = m.group || "";
        let entry = groups.find((x) => x.name === g);
        if (!entry) groups.push(entry = { name: g, models: [] });
        entry.models.push(m);
      });
      const opt = (m) => `<option value="${esc(m.id)}" title="${esc(m.id)}">${esc(m.label)}</option>`;
      modelSelect.innerHTML = `<option value="">${esc(T("studio_model_default", "Default model"))}${info.default ? ` (${esc(info.default)})` : ""}</option>` +
        groups.map((g) => g.name ? `<optgroup label="${esc(g.name)}">${g.models.map(opt).join("")}</optgroup>` : g.models.map(opt).join("")).join("");
      modelSelect.value = info.models.some((m) => m.id === want) ? want : "";
      modelSelect.disabled = false;
      modelSelect.title = "";
    };
    modelSelect.addEventListener("change", () => {
      try { localStorage.setItem(modelKey(agentSelect.value), modelSelect.value); } catch {}
    });
    const voiceBtn = $("#studio-voice-btn", container);
    const voiceStatus = $("#studio-voice-status", container);
    const diffContainer = $("#studio-diff-container", container);
    const diffBody = $("#studio-diff-body", container);
    const diffFileTag = $("#studio-diff-file-tag", container);

    let agents = [];
    let convId = "";
    let lastResult = null;

    const whoText = (agentName, source, viaMcp) =>
      `${T("studio_answered_by", "Answered by")}: <b>${esc(agentName)}</b> · ${esc(SOURCE_LABEL[source] || source || "")}` +
      (viaMcp ? ` · ${T("studio_with_mcp", "with laravel-dev MCP tools")}` : "");

    const describeSelection = () => {
      const id = agentSelect.value;
      let a = agents.find((x) => x.id === id);
      if (id === "auto") a = ["cloud_llm", "claude", "antigravity", "opencode", "ollama"].map((x) => agents.find((y) => y.id === x && y.installed)).find(Boolean);
      whoEl.innerHTML = a ? `${T("studio_will_answer", "Will answer")}: <b>${esc(a.name)}</b> · ${esc(SOURCE_LABEL[a.source] || "")}${a.mcp ? ` · ${T("studio_with_mcp", "with laravel-dev MCP tools")}` : ""}` : esc(SOURCE_LABEL.none);
      allowEdits.disabled = !(a && a.kind === "cli");
      thinkWrap.style.display = a && a.id === "ollama" ? "flex" : "none";
    };

    /* What the agent does on the way: thinking, tool calls, remarks between them. */
    const fmtDur = (sec) => {
      sec = Math.max(0, Math.round(sec || 0));
      const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), x = String(sec % 60).padStart(2, "0");
      return h ? `${h}:${String(m).padStart(2, "0")}:${x}` : `${m}:${x}`;
    };
    const stepsLabel = (n) => `${n} ${n === 1 ? T("studio_step", "step") : T("studio_steps", "steps")}`;
    const activityPanel = (items, { live = false, duration = 0 } = {}) => {
      const el = document.createElement("details");
      el.className = "studio-activity";
      el.open = live;
      el.innerHTML = `<summary></summary><div class="studio-activity-list"></div>`;
      const list = $(".studio-activity-list", el);
      const summaryEl = $("summary", el);
      const tools = new Map();
      let thinkText = null;
      const api = { el, count: 0 };
      const row = (cls, ico, html) => {
        const r = document.createElement("div");
        r.className = `act-row ${cls}`;
        r.innerHTML = `<span class="act-ico">${ico}</span><div class="act-body">${html}</div>`;
        const stick = list.scrollHeight - list.scrollTop - list.clientHeight < 40;
        list.appendChild(r);
        if (stick) list.scrollTop = list.scrollHeight;
        api.count++;
        return r;
      };
      const paintTool = (r, t) => {
        r.className = `act-row ${t.state === "running" ? "running" : t.state}`;
        $(".act-ico", r).innerHTML = t.state === "running" ? `<span class="spin-dot"></span>` : icon(t.state === "error" ? "x" : "check");
        $(".act-body", r).innerHTML = `<span class="act-name">${esc(t.name || "tool")}</span>${t.detail ? ` <span class="act-detail">${esc(t.detail)}</span>` : ""}` +
          (t.summary ? `<span class="act-summary">${esc(t.summary)}</span>` : "");
      };
      api.summary = (dur) => {
        summaryEl.textContent = live && dur === undefined
          ? `${T("studio_activity", "Activity")} · ${stepsLabel(api.count)}`
          : `${T("studio_worked_for", "Worked for")} ${fmtDur(dur ?? duration)} · ${stepsLabel(api.count)}`;
      };
      api.add = (ev) => {
        if (!ev || ev.kind === "status") return;
        if (ev.kind === "thinking") {
          if (!thinkText) {
            const r = row("act-thinking", icon("sparkles"), `<span class="act-name">${esc(T("studio_thinking_label", "Thinking"))}</span><div class="act-think-text"></div>`);
            thinkText = $(".act-think-text", r);
          }
          const stick = thinkText.scrollHeight - thinkText.scrollTop - thinkText.clientHeight < 30;
          thinkText.append(ev.text || "");
          if (stick) thinkText.scrollTop = thinkText.scrollHeight;
          if (live) list.scrollTop = list.scrollHeight;
        } else {
          thinkText = null;
          if (ev.kind === "thought") {
            row("act-thought", icon("clock"), `<span class="muted">${esc(T("studio_thought_for", "Thought for"))} ${esc(String(ev.seconds ?? ""))}s</span>`);
          } else if (ev.kind === "note") {
            row("act-note", "•", esc(ev.text || ""));
          } else if (ev.kind === "permission") {
            const ok = ev.decision === "allow" || ev.decision === "always";
            const label = ev.decision === "always" ? T("studio_perm_allowed_always", "Allowed for this conversation")
              : ok ? T("studio_perm_allowed", "Allowed") : ev.decision === "cancel" ? T("studio_perm_cancelled", "Stopped") : T("studio_perm_denied", "Denied");
            row(`act-perm ${ok ? "done" : "error"}`, icon("lock"),
              `<span class="act-name">${esc(label)}</span> <span class="muted">${esc(ev.title || "")}</span>` +
              (ev.detail ? ` <span class="act-detail">${esc(ev.detail)}</span>` : ""));
          } else if (ev.kind === "tool") {
            const prev = tools.get(ev.id);
            const t = { ...(prev?.t || {}), ...Object.fromEntries(Object.entries(ev).filter(([, v]) => v !== "" && v != null)) };
            const r = prev?.r || row("", "", "");
            tools.set(ev.id, { r, t });
            paintTool(r, t);
          }
        }
        api.summary();
      };
      (items || []).forEach(api.add);
      api.summary(live ? undefined : duration);
      return api;
    };

    const bubble = (m) => {
      const el = document.createElement("div");
      if (m.role === "user") {
        el.className = "studio-msg-user";
        el.style.cssText = "align-self:flex-end;background:var(--accent);color:#fff;border-radius:8px;padding:8px 12px;font-size:13px;max-width:80%;line-height:1.4;white-space:pre-wrap";
        el.textContent = m.text;
      } else {
        el.className = "studio-msg-agent";
        el.style.cssText = "background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:10px 12px;font-size:13px;line-height:1.5";
        const files = (m.files_changed || []).length ? `<div class="muted xs" style="margin-top:6px">${icon("file")} ${esc(m.files_changed.join(", "))}</div>` : "";
        el.innerHTML = `
          <div style="font-weight:600;margin-bottom:4px;display:flex;align-items:center;gap:6px;color:${m.error ? "var(--red,#ef4444)" : "var(--accent)"}">
            ${icon(m.error ? "alert" : "sparkles")} ${esc(m.agent || "Agent")}
            ${m.source ? `<span class="chip sm muted" style="font-weight:400">${esc(SOURCE_LABEL[m.source] || m.source)}</span>` : ""}
            ${m.model ? `<span class="chip sm muted" style="font-weight:400;font-family:var(--mono)">${esc(m.model)}${m.effort ? ` · ${esc(m.effort)}` : ""}</span>` : ""}
          </div>
          <div style="white-space:pre-wrap">${esc(m.text || "")}</div>${files}`;
        if ((m.activity || []).length) {
          el.children[0].after(activityPanel(m.activity, { duration: m.duration }).el);
        } else if (m.duration) {
          el.children[0].insertAdjacentHTML("afterend", `<div class="muted xs" style="margin-bottom:4px">${icon("clock")} ${esc(T("studio_worked_for", "Worked for"))} ${fmtDur(m.duration)}</div>`);
        }
      }
      return el;
    };

    const renderMessages = (messages) => {
      chatStream.innerHTML = "";
      if (!messages.length) {
        chatStream.innerHTML = `<div class="studio-empty muted sm" style="text-align:center;padding:30px 10px">${esc(T("studio_empty", "Ask anything about this project. Conversations are saved and can be continued later."))}</div>`;
        return;
      }
      messages.forEach((m) => chatStream.appendChild(bubble(m)));
      chatStream.scrollTop = chatStream.scrollHeight;
    };

    const loadConversations = async (selectId) => {
      let list = [];
      try { list = (await LD.call("studio_conversations_list", { name: site.name })).conversations || []; } catch {}
      convSelect.innerHTML = `<option value="">${esc(T("studio_new_chat", "New conversation"))}</option>` +
        list.map((c) => `<option value="${esc(c.id)}">${esc(c.title)} (${c.messages})</option>`).join("");
      convSelect.value = selectId ?? (list[0]?.id || "");
      return list;
    };

    const openConversation = async (id) => {
      convId = id || "";
      diffContainer.style.display = "none";
      lastResult = null;
      if (!convId) return renderMessages([]);
      try {
        const conv = await LD.call("studio_conversation_get", { name: site.name, id: convId });
        if (conv.agent_id && [...agentSelect.options].some((o) => o.value === conv.agent_id && !o.disabled)) {
          agentSelect.value = conv.agent_id;  // continue with the agent that holds the session
          describeSelection();
          loadModels(conv.agent_id, conv.model || undefined);
        }
        renderMessages(conv.messages || []);
      } catch (err) {
        toast("error", T("studio_load_failed", "Could not open the conversation"), err.message);
        renderMessages([]);
      }
    };

    try {
      const ares = await LD.call("studio_agents_list");
      agents = ares?.agents || [];
      agentSelect.innerHTML = `<option value="auto">${T("studio_auto", "Auto (Settings AI first)")}</option>` +
        agents.map((a) => `<option value="${esc(a.id)}" ${a.installed ? "" : "disabled"} title="${esc(a.description || "")}">${esc(a.name)} ${a.installed ? "✔" : `(${T("studio_unavailable", "not available")})`}</option>`).join("");
    } catch {}
    describeSelection();
    loadModels(agentSelect.value);
    agentSelect.addEventListener("change", () => { describeSelection(); loadModels(agentSelect.value); });

    await loadConversations();
    await openConversation(convSelect.value);
    convSelect.addEventListener("change", () => openConversation(convSelect.value));

    $("#studio-new-chat", container)?.addEventListener("click", () => { convSelect.value = ""; openConversation(""); promptInput.focus(); });
    $("#studio-rename-chat", container)?.addEventListener("click", async () => {
      if (!convId) return;
      const current = convSelect.selectedOptions[0]?.textContent.replace(/\s\(\d+\)$/, "") || "";
      const title = window.prompt(T("studio_rename_chat", "Rename conversation"), current);
      if (!title) return;
      try {
        await LD.call("studio_conversation_rename", { name: site.name, id: convId, title });
        await loadConversations(convId);
      } catch (err) { toast("error", T("studio_rename_failed", "Rename failed"), err.message); }
    });
    $("#studio-delete-chat", container)?.addEventListener("click", async () => {
      if (!convId) return;
      if (!(await confirmModal({ title: T("studio_delete_chat", "Delete conversation"), message: T("studio_delete_confirm", "This conversation will be deleted permanently."), confirm: T("delete", "Delete"), danger: true }))) return;
      try {
        await LD.call("studio_conversation_delete", { name: site.name, id: convId });
        await openConversation((await loadConversations())[0]?.id || "");
      } catch (err) { toast("error", T("studio_delete_failed", "Delete failed"), err.message); }
    });

    container.querySelectorAll(".studio-chip").forEach((btn) => {
      btn.addEventListener("click", () => { promptInput.value = btn.dataset.prompt; promptInput.focus(); });
    });

    $("#studio-diff-keep-btn", container)?.addEventListener("click", () => { diffContainer.style.display = "none"; });
    $("#studio-diff-revert-btn", container)?.addEventListener("click", async (e) => {
      if (!lastResult?.file_status || !Object.keys(lastResult.file_status).length) return;
      e.currentTarget.disabled = true;
      try {
        const r = await LD.call("studio_revert", { name: site.name, file_status: lastResult.file_status });
        if (r.ok) toast("success", T("studio_reverted", "Changes reverted"), r.reverted.join(", "));
        else toast("error", T("studio_revert_partial", "Some files could not be reverted"), r.errors.join("\n"));
        diffContainer.style.display = "none";
      } catch (err) {
        toast("error", T("studio_revert_failed", "Revert failed"), err.message);
      } finally { e.currentTarget.disabled = false; }
    });

    let activeRun = null;  // { id, el, textEl } while an answer is streaming
    const setSendMode = (running) => {
      sendBtn.classList.toggle("danger", running);
      sendBtn.classList.toggle("primary", !running);
      sendBtn.innerHTML = running ? `${icon("x")} ${T("studio_stop", "Stop")}` : `${icon("play")} ${T("studio_send", "Send")}`;
      sendBtn.title = running ? T("studio_stop_hint", "Stop the request (the partial answer is kept)") : "";
    };

    const finishRun = async (res) => {
      const run = activeRun;
      activeRun = null;
      if (run) { clearInterval(run.timer); Object.values(run.permCards || {}).forEach((c) => c.remove()); }
      setSendMode(false);
      sendBtn.disabled = false;
      lastResult = res;
      const finalBubble = bubble({ role: "agent", text: res.reply || (res.cancelled ? "" : res.error || ""), agent: res.agent || "Agent",
        source: res.source, model: res.model, effort: res.effort, files_changed: res.files_changed, error: res.error && !res.cancelled,
        activity: res.activity, duration: res.duration ?? (run ? (Date.now() - run.startedAt) / 1000 : 0) });
      if (res.cancelled) {
        finalBubble.insertAdjacentHTML("beforeend", `<div class="muted xs" style="margin-top:6px">${icon("x")} ${esc(T("studio_stopped", "Stopped — partial answer"))}</div>`);
      }
      run?.el.replaceWith(finalBubble);
      if ((res.denied || []).length && !res.error) {
        finalBubble.insertAdjacentHTML("beforeend", `<div class="muted xs" style="margin-top:6px">${icon("lock")} ${esc(T("studio_perm_stopped", "A permission was denied — send a new message to continue."))}</div>`);
      }
      if (res.agent) whoEl.innerHTML = whoText(res.agent, res.source, res.via_mcp);
      if (res.conversation_id) convId = res.conversation_id;
      await loadConversations(convId);
      if (res.diff && res.diff.trim()) {
        diffContainer.style.display = "block";
        diffFileTag.textContent = (res.files_changed || []).join(", ");
        diffBody.innerHTML = window.DiffViewer?.renderDiff
          ? window.DiffViewer.renderDiff(res.diff)
          : `<pre style="font-family:var(--mono);font-size:12px">${esc(res.diff)}</pre>`;
      }
      if (res.error && !res.cancelled) toast("error", T("studio_failed", "Agent task failed"), res.error);
      chatStream.scrollTop = chatStream.scrollHeight;
    };

    const liveStatus = (run, text) => { run.statusEl.textContent = text; };
    const PERM_KIND = {
      execute: T("studio_perm_execute", "run a command"), edit: T("studio_perm_edit", "edit a file"),
      delete: T("studio_perm_delete", "delete a file"), move: T("studio_perm_move", "move a file"),
      read: T("studio_perm_read", "read a file"), search: T("studio_perm_search", "search files"),
      fetch: T("studio_perm_fetch", "use the internet"), mcp: T("studio_perm_mcp", "use a tool"), other: T("studio_perm_other", "use a tool"),
    };
    /* The agent waits until the user answers this card. */
    const permissionCard = (run, req) => {
      const card = document.createElement("div");
      card.className = "studio-perm-card";
      const editable = !!req.editable;
      const always = ["edit", "delete", "move"].includes(req.kind)
        ? T("studio_perm_always_edits", "Allow all edits in this conversation")
        : T("studio_perm_always", "Always allow this in this conversation");
      card.innerHTML = `
        <div class="perm-head">${icon("lock")} <b>${esc(req.agent || "Agent")}</b> ${esc(T("studio_perm_wants", "wants to"))} ${esc(PERM_KIND[req.kind] || PERM_KIND.other)}</div>
        ${req.title && req.title !== req.detail ? `<div class="perm-title">${esc(req.title)}</div>` : ""}
        ${req.detail || editable ? (editable
          ? `<textarea class="perm-detail input" rows="${Math.min(6, (req.detail || "").split("\n").length + 1)}" spellcheck="false">${esc(req.detail || "")}</textarea>
             <div class="muted xs">${esc(T("studio_perm_edit_hint", "You can change the command before allowing it."))}</div>`
          : `<pre class="perm-detail">${esc(req.detail)}</pre>`) : ""}
        <div class="perm-actions">
          <button class="btn primary sm" data-d="allow">${icon("check")} ${esc(T("studio_perm_allow", "Allow"))}</button>
          <button class="btn ghost sm" data-d="always">${esc(always)}</button>
          <button class="btn ghost sm perm-deny" data-d="deny">${icon("x")} ${esc(T("studio_perm_deny", "Deny"))}</button>
        </div>
        <div class="muted xs">${esc(T("studio_perm_paused", "The agent is paused until you answer. If you deny and it cannot do the task without this, it stops and waits for your next message."))}</div>`;
      card.querySelectorAll("[data-d]").forEach((btn) => btn.addEventListener("click", async () => {
        card.querySelectorAll("button").forEach((b) => { b.disabled = true; });
        const edited = editable ? $(".perm-detail", card).value : undefined;
        try {
          const r = await LD.call("studio_permission_reply", { run_id: run.id, request_id: req.id, decision: btn.dataset.d,
            input: editable && edited !== req.detail ? edited : undefined });
          if (!r.ok) { toast("error", T("studio_perm_expired", "That request is no longer waiting"), r.error || ""); card.remove(); }
          else card.classList.add("answered");
        } catch (err) {
          toast("error", T("studio_perm_failed", "Could not send the answer"), err.message);
          card.querySelectorAll("button").forEach((b) => { b.disabled = false; });
        }
      }));
      return card;
    };

    const applyItem = (run, item) => {
      run.lastEventAt = Date.now();
      if (item.permission) {
        const req = item.permission;
        const card = permissionCard(run, req);
        run.permCards[req.id] = card;
        run.waitingPerm = true;
        run.textEl.before(card);
        liveStatus(run, T("studio_perm_waiting", "Waiting for your approval…"));
        card.scrollIntoView({ block: "nearest", behavior: "smooth" });
        $("button[data-d=allow]", card)?.focus({ preventScroll: true });
        if (document.hidden) toast("info", T("studio_perm_needed", "The agent needs your approval"), req.title || req.detail || "");
        return;
      }
      if (item.delta) {
        const nearBottom = chatStream.scrollHeight - chatStream.scrollTop - chatStream.clientHeight < 60;
        run.textEl.append(item.delta);
        liveStatus(run, T("studio_writing", "Writing the answer…"));
        if (nearBottom) chatStream.scrollTop = chatStream.scrollHeight;
        return;
      }
      const a = item.activity;
      if (!a) return;
      if (a.kind === "status") {
        liveStatus(run, a.code === "starting" ? `${T("studio_starting", "Starting")} ${a.agent || ""}…`
          : a.code === "waiting" ? T("studio_waiting", "Waiting for the model…") : T("studio_thinking_now", "Thinking…"));
        return;
      }
      if (a.kind === "thinking" || a.kind === "thought") liveStatus(run, T("studio_thinking_now", "Thinking…"));
      if (a.kind === "tool") {
        const t = { ...(run.tools[a.id] || {}), ...Object.fromEntries(Object.entries(a).filter(([, v]) => v !== "" && v != null)) };
        run.tools[a.id] = t;
        liveStatus(run, t.state === "running"
          ? `${T("studio_running_tool", "Running")} ${t.name || ""}${t.detail ? ` · ${t.detail}` : ""}…`
          : T("studio_working", "Working…"));
      }
      if (a.kind === "note" && a.moved) run.textEl.textContent = "";  // that text was a remark before a tool call: it is in the activity now
      if (a.kind === "permission") {
        run.permCards[a.id]?.remove();  // answered (here, or it timed out / was stopped)
        delete run.permCards[a.id];
        run.waitingPerm = Object.keys(run.permCards).length > 0;
      }
      const nearBottom = chatStream.scrollHeight - chatStream.scrollTop - chatStream.clientHeight < 60;
      run.activity.add(a);
      run.activity.el.style.display = run.activity.count ? "" : "none";
      if (nearBottom) chatStream.scrollTop = chatStream.scrollHeight;
    };
    const onStudioEvent = (ev) => {
      if (!activeRun || ev.run_id !== activeRun.id) return false;
      const run = activeRun;
      if (ev.delta) applyItem(run, { delta: ev.delta });
      (ev.events || []).forEach((item) => applyItem(run, item));
      if (ev.finished) finishRun(ev.result || {});
      return true;
    };
    studioHandler = onStudioEvent;

    const runAgent = async () => {
      if (activeRun) {  // the button is "Stop" while streaming
        sendBtn.disabled = true;
        try { await LD.call("studio_agent_cancel", { run_id: activeRun.id }); } catch {}
        return;
      }
      const text = promptInput.value.trim();
      if (!text || sendBtn.disabled) return;
      promptInput.value = "";
      sendBtn.disabled = true;
      diffContainer.style.display = "none";
      chatStream.querySelector(".studio-empty")?.remove();
      chatStream.appendChild(bubble({ role: "user", text }));
      const pending = document.createElement("div");
      pending.className = "studio-msg-agent";
      pending.style.cssText = "background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:10px 12px;font-size:13px;line-height:1.5";
      pending.innerHTML = `
        <div class="studio-live-head"><span class="spin-dot"></span><span class="studio-live-status shimmer">${esc(T("studio_thinking", "The agent is working…"))}</span><span class="studio-live-timer">0:00</span></div>
        <div class="studio-live-quiet" hidden></div>
        <div class="studio-stream-text" style="white-space:pre-wrap;margin-top:4px"></div>`;
      const live = activityPanel([], { live: true });
      live.el.style.display = "none";
      $(".studio-live-quiet", pending).after(live.el);
      chatStream.appendChild(pending);
      chatStream.scrollTop = chatStream.scrollHeight;

      const startedAt = Date.now();
      try {
        const start = await LD.call("studio_agent_start", {
          name: site.name, prompt: text, agent_id: agentSelect.value,
          conversation_id: convId, allow_edits: allowEdits.checked && !allowEdits.disabled,
          model: modelWrap.style.display !== "none" && !modelSelect.disabled ? modelSelect.value : "",
          think: thinkWrap.style.display !== "none" && thinkBox.checked,
          effort: effortWrap.style.display !== "none" ? effortSelect.value : "",
        });
        convId = start.conversation_id || convId;
        const run = activeRun = { id: start.run_id, el: pending, textEl: $(".studio-stream-text", pending),
          statusEl: $(".studio-live-status", pending), activity: live, tools: {}, permCards: {}, waitingPerm: false,
          startedAt, lastEventAt: Date.now() };
        const timerEl = $(".studio-live-timer", pending), quietEl = $(".studio-live-quiet", pending);
        run.timer = setInterval(() => {
          // A ticking clock and "no output for…" so a long task never looks frozen.
          timerEl.textContent = fmtDur((Date.now() - run.startedAt) / 1000);
          const quiet = Math.round((Date.now() - run.lastEventAt) / 1000);
          quietEl.hidden = quiet < 15 || run.waitingPerm;
          if (quiet >= 15) quietEl.textContent = T("studio_quiet", "No new output for {n}s — the agent is still running. Use Stop to cancel.").replace("{n}", quiet);
        }, 1000);
        setSendMode(true);
        sendBtn.disabled = false;
        // Events that arrived before this call returned.
        (studioEarly.get(start.run_id) || []).forEach(onStudioEvent);
        studioEarly.delete(start.run_id);
      } catch (err) {
        pending.replaceWith(bubble({ role: "agent", text: err.message, agent: "Error", error: true }));
        toast("error", T("studio_failed", "Agent task failed"), err.message);
        sendBtn.disabled = false;
      }
    };

    sendBtn?.addEventListener("click", runAgent);
    promptInput.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); runAgent(); }
    });

    // Voice Dictation (Web Speech API)
    let recognition = null;
    let isListening = false;
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (SpeechRec) {
      recognition = new SpeechRec();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = (window.i18nLanguage === "ar") ? "ar-SA" : "en-US";

      recognition.onstart = () => {
        isListening = true;
        if (voiceStatus) voiceStatus.style.display = "inline";
        if (voiceBtn) voiceBtn.classList.add("danger");
      };

      recognition.onresult = (event) => {
        let transcript = "";
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript) {
          promptInput.value = (promptInput.value ? promptInput.value + " " : "") + transcript;
        }
      };

      recognition.onerror = () => {
        isListening = false;
        if (voiceStatus) voiceStatus.style.display = "none";
        if (voiceBtn) voiceBtn.classList.remove("danger");
      };

      recognition.onend = () => {
        isListening = false;
        if (voiceStatus) voiceStatus.style.display = "none";
        if (voiceBtn) voiceBtn.classList.remove("danger");
      };

      voiceBtn?.addEventListener("click", () => {
        if (!isListening) {
          try { recognition.start(); } catch {}
        } else {
          try { recognition.stop(); } catch {}
        }
      });
    } else {
      voiceBtn?.addEventListener("click", () => {
        toast("info", "Voice Dictation", "Browser Speech API not supported in current environment; use prompt textarea.");
      });
    }
  }

  return {
    onStudioEvent,
    mountTinker,
    mountStudio,
    mountLogs,
    mountMail,
    mountQueue,
    mountDeploy,
    mountRoutes,
    mountModels,
    mountTranslations,
    mountDumps,
    mountTests,
    mountCheckpoints,
    mountCache,
    mountVite,
    mountMedia,
    mountPerf,
    mountPackages,
    onDumpEvent,
    onPerfEvent,
    update,
    destroy,
  };
})();


// Top-level `const` is not a window property: app.js reaches the module through window
// (live dumps, Performance requests and Studio streaming events).
window.LaravelDev = LaravelDev;
