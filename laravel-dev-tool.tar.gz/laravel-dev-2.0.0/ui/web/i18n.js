/* ── Internationalization (i18n) & RTL support ── */
(function () {
  const dict = {
    en: {
      sites: "Sites",
      database: "Database",
      servers: "Servers",
      services: "Services",
      settings: "Settings",
      activity: "Activity",
      add_site: "Add site",
      search_sites: "Search sites",
      refresh: "Refresh",
      not_linked: "Not linked",
      browser: "Browser",
      editor: "Editor",
      folder: "Folder",
      terminal: "Terminal",
      running: "Running",
      stopped: "Stopped",
      overview: "Overview",
      env: "Environment",
      logs: "Logs",
      tinker: "Tinker",
      queue: "Queues & Cron",
      mail: "Mail",
      routes: "Routes",
      dumps: "Dumps",
      tests: "Tests",
      checkpoints: "Time Machine",
      cache: "Cache & Redis",
      domains: "Domains & Subdomains",
      vite: "Vite & Assets",
      media: "Storage Gallery",
      deploy: "Deploy & Backup",
      git: "Git",
      save: "Save",
      cancel: "Cancel",
      delete: "Delete",
      confirm: "Confirm",
      repair: "Repair",
      secure: "Secure",
      unlink: "Unlink",
      diagnose: "Diagnose",
      share: "Share",
      restore: "Restore",
      prune: "Prune",
      start_all: "Start all",
      stop_all: "Stop all",
      close: "Close",
      diff: "Diff",
      commit: "Commit",
      branch: "Branch",
      switch: "Switch",
      new_branch: "New branch",
      stash: "Stash",
      pop: "Pop",
      run: "Run",
      copy: "Copy",
      copied: "Copied!",
      link: "Link",
      site_single: "site",
      site_plural: "sites",
      found_in_not_linked: "Found in",
      not_linked_suffix: "but not linked",
      no_matches: "No matches",
      nothing_matches: "Nothing matches",
      no_sites_yet: "No sites yet",
      new_project: "New project",
      link_folder: "Link folder",
      clone_repo: "Clone repo",
      open_browser: "Open in browser",
      open_editor: "Open in editor",
      open_folder: "Open folder",
      open_terminal: "Open terminal",
      perf: "Requests & Queries",
      back_to_sites: "Back to Projects",
      requests_and_queries: "Requests & Queries",
      live_profiler: "Live SQL & Profiler",
      executed_queries: "Executed Queries",
      query_count: "Queries",
      requests: "Requests",
      queries: "Queries",
      errors: "Errors",
      slow: "Slow (>100ms)",
      response_time: "Response Time",
      live_listening: "Listening for live requests…",
      enable_live_profiler_desc: "Track SQL queries, execution latency, and N+1 bottlenecks in real time while browsing.",
      models: "Models",
      trans: "Translations",
      nginx_traffic: "Nginx Traffic (L1)",
      app_profiler: "App Profiler (L2)",
      enable_profiler: "Enable Profiler",
      disable_profiler: "Disable Profiler",
      n_plus_one_only: "N+1 queries only",
      filter_assets: "Filter static assets",
      explain_query: "Explain Query",
      copy_curl: "Copy cURL",
      language: "Language",
      language_desc: "Interface language and text direction",
      appearance: "Appearance",
      system: "System",
      light: "Light",
      dark: "Dark",
      services_subtitle: "Everything your sites need to run.",
      php_versions: "PHP versions",
      settings_subtitle: "Saved to ~/.config/laravel-dev",
      general: "General",
      www_folder: "www folder",
      default_php: "Default PHP",
      notifications: "Desktop Notifications",
    },
    ar: {
      sites: "المواقع",
      database: "قواعد البيانات",
      servers: "الخوادم",
      services: "الخدمات",
      settings: "الإعدادات",
      activity: "سجل العمليات",
      add_site: "إضافة موقع",
      search_sites: "بحث في المشاريع…",
      refresh: "تحديث",
      not_linked: "غير مربوط",
      browser: "المتصفح",
      editor: "المحرر",
      folder: "المجلد",
      terminal: "الطرفية",
      running: "يعمل",
      stopped: "متوقف",
      overview: "نظرة عامة",
      env: "البيئة والتهيئة",
      logs: "السجلات",
      tinker: "تفاعلي (Tinker)",
      queue: "الطوابير والمهام",
      mail: "البريد",
      routes: "المسارات",
      dumps: "المخرجات",
      tests: "الاختبارات",
      checkpoints: "نقاط الاستعادة (آلة الزمن)",
      cache: "الكاش ومفاتيح Redis",
      domains: "النطاقات والنطاقات الفرعية",
      vite: "أدوات Vite والتجميع",
      media: "معرض وسائط التخزين",
      deploy: "النشر والنسخ الاحتياطي",
      git: "إدارة Git",
      save: "حفظ",
      cancel: "إلغاء",
      delete: "حذف",
      confirm: "تأكيد",
      repair: "إصلاح",
      secure: "تأمين (HTTPS)",
      unlink: "إلغاء الربط",
      diagnose: "تشخيص",
      share: "مشاركة",
      restore: "استعادة",
      prune: "تنظيف القديم",
      start_all: "تشغيل الكل",
      stop_all: "إيقاف الكل",
      close: "إغلاق",
      diff: "الفروقات",
      commit: "اعتماد (Commit)",
      branch: "الفرع",
      switch: "تبديل",
      new_branch: "فرع جديد",
      stash: "حفظ مؤقت (Stash)",
      pop: "استرجاع (Pop)",
      run: "تشغيل",
      copy: "نسخ",
      copied: "تم النسخ!",
      link: "ربط",
      site_single: "موقع",
      site_plural: "مواقع",
      found_in_not_linked: "موجود في",
      not_linked_suffix: "ولكن غير مربوط",
      no_matches: "لا توجد نتائج",
      nothing_matches: "لا يوجد ما يطابق",
      no_sites_yet: "لا توجد مشاريع حتى الآن",
      new_project: "مشروع جديد",
      link_folder: "ربط مجلد",
      clone_repo: "استنساخ مستودع",
      open_browser: "فتح في المتصفح",
      open_editor: "فتح في المحرر",
      open_folder: "فتح المجلد",
      open_terminal: "فتح الطرفية",
      perf: "الطلبات والاستعلامات",
      back_to_sites: "العودة إلى المشاريع",
      requests_and_queries: "الطلبات والاستعلامات",
      live_profiler: "المراقب المباشر والاستعلامات",
      executed_queries: "الاستعلامات المنفذة",
      query_count: "الاستعلامات",
      requests: "الطلبات",
      queries: "الاستعلامات",
      errors: "الأخطاء",
      slow: "البطيء (>100ms)",
      response_time: "سرعة الاستجابة",
      live_listening: "بانتظار الطلبات والاستعلامات المباشرة…",
      enable_live_profiler_desc: "تتبع استعلامات SQL، سرعة الاستجابة، ومشاكل N+1 بشكل فوري أثناء تصفحك للموقع.",
      models: "النماذج والعلاقات",
      trans: "مدير الترجمات",
      nginx_traffic: "حركة Nginx (مستوى 1)",
      app_profiler: "مراقب الأداء (مستوى 2)",
      enable_profiler: "تفعيل المراقب",
      disable_profiler: "تعطيل المراقب",
      n_plus_one_only: "استعلامات N+1 فقط",
      filter_assets: "تجاهل الملفات الثابتة",
      explain_query: "تحليل الاستعلام",
      copy_curl: "نسخ كـ cURL",
      language: "اللغة",
      language_desc: "لغة الواجهة واتجاه النصوص",
      appearance: "المظهر",
      system: "النظام",
      light: "فاتح",
      dark: "داكن",
      services_subtitle: "كل ما تحتاجه مشاريعك لتعمل بكفاءة.",
      php_versions: "إصدارات PHP",
      settings_subtitle: "محفوظة في ~/.config/laravel-dev",
      general: "عام",
      www_folder: "مجلد المشاريع www",
      default_php: "إصدار PHP الافتراضي",
      notifications: "إشعارات سطح المكتب",
    },
  };

  let currentLang = localStorage.getItem("laravel_dev_lang") || "en";

  function getLang() {
    return currentLang;
  }

  function setLang(lang) {
    if (!dict[lang]) lang = "en";
    currentLang = lang;
    try {
      localStorage.setItem("laravel_dev_lang", lang);
    } catch {}
    applyDirection();
    translateDOM();
    window.dispatchEvent(new CustomEvent("langchange", { detail: { lang } }));
  }

  function t(key, fallback) {
    const entry = dict[currentLang]?.[key] || (fallback !== undefined ? fallback : (dict.en[key] || key));
    return entry;
  }

  function applyDirection() {
    const isRtl = currentLang === "ar";
    document.documentElement.lang = currentLang;
    document.documentElement.dir = isRtl ? "rtl" : "ltr";
  }

  function translateDOM(root = document) {
    root.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.dataset.i18n;
      const text = t(key);
      if (text) el.textContent = text;
    });
    root.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      const key = el.dataset.i18nPlaceholder;
      const text = t(key);
      if (text) el.placeholder = text;
    });
  }

  // Initialize on load
  applyDirection();
  document.addEventListener("DOMContentLoaded", () => {
    translateDOM();
  });

  window.I18N = {
    getLang,
    setLang,
    t,
    translateDOM,
    dict,
  };
  window.t = t;
})();

