"use strict";

/* Request & query inspector for the Requests & Queries tab, laid out like the
   Network panel of browser devtools: a side panel with Headers / Payload /
   Response / Cookies / Timing / Queries / Context / cURL for a request, and
   SQL / Executions / Callers / Explain for a query.
   Uses the helpers defined in app.js (icon, esc, LD, toast, copyText). */

const Inspector = (() => {
  let panel = null;   // { el, kind, site, list, index, tab, data, opts }

  // ── small renderers ──────────────────────────────────────────────────────
  const ms = (v) => (v === null || v === undefined || v === "" ? "—" : `${Math.round(Number(v) * 10) / 10} ms`);
  const bytes = (n) => {
    n = Number(n || 0);
    if (!n) return "—";
    if (n < 1024) return `${n} B`;
    if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
    return `${(n / 1048576).toFixed(1)} MB`;
  };
  const statusClass = (s) => `s${String(s || 0)[0]}xx`;

  function kvTable(obj, { empty = "Nothing recorded", copy = true } = {}) {
    const entries = Array.isArray(obj) ? obj : Object.entries(obj || {});
    if (!entries.length) return `<div class="ni-empty">${esc(empty)}</div>`;
    return `<div class="ni-kv">${entries.map(([k, v]) => {
      const val = typeof v === "object" && v !== null ? JSON.stringify(v) : String(v ?? "");
      return `<div class="ni-k">${esc(k)}</div><div class="ni-v" ${copy ? `data-ni-copy="${esc(val)}" title="Click to copy"` : ""}>${esc(val) || '<span class="muted">(empty)</span>'}</div>`;
    }).join("")}</div>`;
  }

  function section(title, body, { open = true, count = null } = {}) {
    return `<details class="ni-section" ${open ? "open" : ""}>
      <summary>${esc(title)}${count !== null ? ` <span class="ni-count">${count}</span>` : ""}</summary>
      <div class="ni-section-body">${body}</div>
    </details>`;
  }

  // Pretty JSON with token colours; anything else is shown as text.
  function jsonHtml(value) {
    const text = JSON.stringify(value, null, 2);
    return esc(text).replace(
      /(&quot;(?:\\.|[^\\&]|&(?!quot;))*?&quot;)(\s*:)?|\b(true|false|null)\b|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g,
      (m, str, colon, lit, num) => {
        if (str) return colon ? `<span class="ni-json-key">${str}</span>${colon}` : `<span class="ni-json-str">${str}</span>`;
        if (lit) return `<span class="ni-json-lit">${lit}</span>`;
        return `<span class="ni-json-num">${num}</span>`;
      });
  }

  function bodyView(body, contentType) {
    if (body === null || body === undefined || body === "") return "";
    if (typeof body === "object") return `<pre class="ni-code">${jsonHtml(body)}</pre>`;
    if (/json/i.test(contentType || "") || /^\s*[[{]/.test(body)) {
      try { return `<pre class="ni-code">${jsonHtml(JSON.parse(body))}</pre>`; } catch { /* not complete JSON: show as text */ }
    }
    return `<pre class="ni-code">${esc(body)}</pre>`;
  }

  function curlFor(req, site) {
    const url = req.request?.url || `${site.url || `http://${site.domain}`}${req.uri || "/"}`;
    const parts = [`curl -X ${req.method || "GET"} '${url.replace(/'/g, "'\\''")}'`];
    for (const [k, v] of Object.entries(req.headers || {})) {
      if (/^(cookie|host|content-length|connection)$/i.test(k) || /hidden\]$/.test(String(v))) continue;
      parts.push(`-H '${k}: ${String(v).replace(/'/g, "'\\''")}'`);
    }
    if (req.payload && !["GET", "HEAD"].includes(req.method)) {
      parts.push(`--data-raw '${JSON.stringify(req.payload).replace(/'/g, "'\\''")}'`);
    }
    return parts.join(" \\\n  ");
  }

  // ── panel shell ──────────────────────────────────────────────────────────
  function ensurePanel() {
    if (panel?.el?.isConnected) return panel.el;
    const el = document.createElement("div");
    el.className = "ni-scrim";
    el.innerHTML = `<aside class="ni-panel" role="dialog" aria-modal="true" aria-label="Inspector"></aside>`;
    document.body.append(el);
    el.addEventListener("click", (e) => {
      if (e.target === el) return close();
      // Delegated once here: the panel's content is re-rendered on every tab switch.
      const c = e.target.closest("[data-ni-copy]");
      if (c) return copyText(c.dataset.niCopy);
      const f = e.target.closest("[data-ni-open]");
      if (f) {
        return LD.call("open_file", { name: panel.site.name, path: f.dataset.niOpen, line: Number(f.dataset.line || 1) })
          .catch((err) => toast("error", "Couldn't open the file", err.message));
      }
      const r = e.target.closest("[data-ni-request]");
      if (r) openRequest(panel.site, r.dataset.niRequest, { formatSql: panel.opts.formatSql });
    });
    document.addEventListener("keydown", onKey);
    panel = { el };
    return el;
  }

  function close() {
    document.removeEventListener("keydown", onKey);
    panel?.el?.remove();
    panel = null;
  }

  function onKey(e) {
    if (!panel) return;
    if (e.key === "Escape") { e.preventDefault(); close(); return; }
    if (e.target.closest?.("input, textarea, select")) return;
    if ((e.key === "ArrowDown" || e.key === "ArrowUp") && panel.list?.length > 1) {
      e.preventDefault();
      step(e.key === "ArrowDown" ? 1 : -1);
    }
  }

  function step(delta) {
    const next = panel.index + delta;
    if (next < 0 || next >= panel.list.length) return;
    panel.index = next;
    if (panel.kind === "request") loadRequest(panel.list[next].id);
    else { panel.data = panel.list[next]; renderQuery(); }
  }

  function header({ badge, title, meta, actions = "" }) {
    const nav = panel.list?.length > 1 ? `
      <div class="ni-nav">
        <button class="btn sm ghost icon-btn" data-ni-step="-1" title="Previous (↑)" ${panel.index <= 0 ? "disabled" : ""}>${icon("up")}</button>
        <span class="muted">${panel.index + 1} / ${panel.list.length}</span>
        <button class="btn sm ghost icon-btn ni-down" data-ni-step="1" title="Next (↓)" ${panel.index >= panel.list.length - 1 ? "disabled" : ""}>${icon("up")}</button>
      </div>` : "";
    return `<header class="ni-head">
      <div class="ni-title">${badge}<span class="ni-url" title="${esc(title)}">${esc(title)}</span></div>
      <div class="ni-head-side">${nav}${actions}<button class="btn sm ghost icon-btn" data-ni-close title="Close (Esc)" aria-label="Close">${icon("x")}</button></div>
      <div class="ni-meta">${meta}</div>
    </header>`;
  }

  function tabsBar(tabs) {
    return `<nav class="ni-tabs" role="tablist">${tabs.map(([id, label, count]) =>
      `<button role="tab" class="ni-tab ${panel.tab === id ? "active" : ""}" aria-selected="${panel.tab === id}" data-ni-tab="${id}">${label}${count ? ` <span class="ni-count">${count}</span>` : ""}</button>`).join("")}</nav>`;
  }

  function wireCommon(root, rerender) {
    root.querySelector("[data-ni-close]")?.addEventListener("click", close);
    root.querySelectorAll("[data-ni-step]").forEach((b) => b.addEventListener("click", () => step(Number(b.dataset.niStep))));
    root.querySelectorAll("[data-ni-tab]").forEach((b) => b.addEventListener("click", () => { panel.tab = b.dataset.niTab; rerender(); }));
  }

  const caller = (file, line) => file
    ? `<button class="ni-link" data-ni-open="${esc(file)}" data-line="${esc(line || 1)}" title="Open ${esc(file)}:${esc(line || 1)} in the editor">${esc(file.split(/[\\/]/).pop())}:${esc(line || 1)}</button>`
    : '<span class="muted">—</span>';

  // ── request inspector ────────────────────────────────────────────────────
  async function openRequest(site, id, opts = {}) {
    ensurePanel();
    const list = opts.list || null;
    Object.assign(panel, { kind: "request", site, list, opts, tab: opts.tab || (panel.kind === "request" ? panel.tab : "headers"),
                           index: list ? Math.max(0, list.findIndex((r) => r.id === id)) : 0 });
    await loadRequest(id);
  }

  async function loadRequest(id) {
    const aside = panel.el.querySelector(".ni-panel");
    aside.innerHTML = `<div class="ni-loading">${icon("pulse")} Loading request…</div>`;
    try {
      const res = await LD.call("perf_detail", { name: panel.site.name, id });
      if (!res.ok || !res.request) throw new Error(res.error || "Request not found");
      panel.data = res.request;
      renderRequest();
    } catch (err) {
      aside.innerHTML = `${header({ badge: "", title: "Request", meta: "" })}<div class="ni-body"><div class="card error-pane">${icon("alert")} ${esc(err.message)}</div></div>`;
      wireCommon(aside, renderRequest);
    }
  }

  function renderRequest() {
    const req = panel.data;
    const site = panel.site;
    const net = req.network || {};
    const resp = req.response || null;
    const profiled = req.source !== "nginx";
    const queries = req.queries || [];
    const url = req.request?.url || `${site.url || `http://${net.host || site.domain}`}${req.uri || "/"}`;
    const size = resp?.size ?? net.bytes ?? req.bytes;

    const tabs = [
      ["headers", "Headers"],
      ["payload", "Payload"],
      ["response", "Response"],
      ["cookies", "Cookies"],
      ["timing", "Timing"],
      ["queries", "Queries", queries.length || ""],
      ["context", "Context"],
      ["curl", "cURL"],
    ];
    if (!tabs.some(([t]) => t === panel.tab)) panel.tab = "headers";

    const note = (what) => `<div class="ni-note">${icon("alert")}<span>Only nginx saw this request, so it has no ${esc(what)}. Turn on <b>Live SQL &amp; Profiler</b> (Laravel) to record headers, payload, response and queries.</span></div>`;

    let body = "";
    switch (panel.tab) {
      case "headers":
        body = section("General", kvTable([
          ["Request URL", url],
          ["Request Method", req.method || "GET"],
          ["Status Code", `${req.status || "—"}`],
          ["Remote Address", req.request?.ip || net.remote_addr || req.ip || ""],
          ...(req.route ? [["Route", req.route]] : []),
          ...(req.action ? [["Action", req.action]] : []),
          ...(req.middleware?.length ? [["Middleware", req.middleware.join(", ")]] : []),
          ...(net.upstream_addr ? [["Upstream", `${net.upstream_addr} (${net.upstream_status || "?"})`]] : []),
          ...(net.referer || req.referer ? [["Referer", net.referer || req.referer]] : []),
        ]))
        + (profiled
          ? section("Response Headers", kvTable(resp?.headers, { empty: "Response headers weren't captured (older profiler version)." }), { count: Object.keys(resp?.headers || {}).length })
            + section("Request Headers", kvTable(req.headers), { count: Object.keys(req.headers || {}).length })
          : section("Request Headers", kvTable(net.user_agent || req.user_agent ? [["User-Agent", net.user_agent || req.user_agent], ["Host", net.host || req.host || ""]] : [])) + note("other headers"));
        break;

      case "payload": {
        if (!profiled) { body = note("payload"); break; }
        const qp = req.query_params || {};
        const files = req.request?.files || [];
        body = section("Query String Parameters", kvTable(qp, { empty: "No query string" }), { count: Object.keys(qp).length })
          + section("Request Body", req.payload && Object.keys(req.payload).length
            ? `<div class="ni-sub muted">${esc(req.request?.content_type || "")}</div>${bodyView(req.payload)}`
            : `<div class="ni-empty">${["GET", "HEAD"].includes(req.method) ? "GET requests have no body" : "Empty body"}</div>`)
          + (files.length ? section("Uploaded Files", kvTable(files.map((f) => [f.field, `${f.name} · ${bytes(f.size)} · ${f.mime}`])), { count: files.length }) : "");
        break;
      }

      case "response":
        if (!profiled) { body = note("response body"); break; }
        if (!resp) { body = `<div class="ni-empty">The response wasn't captured. Update the profiler (reinstall Laravel Dev, then turn the profiler off and on).</div>`; break; }
        body = `<div class="ni-sub">${esc(resp.content_type || "unknown type")} · ${bytes(resp.size)}
            ${resp.body !== null && resp.body !== undefined ? `<button class="btn xs ghost" data-ni-copy="${esc(resp.body)}">${icon("copy")}Copy</button>` : ""}</div>`
          + (resp.streamed ? `<div class="ni-empty">Streamed or file download — the body isn't recorded.</div>`
            : resp.body_dropped ? `<div class="ni-empty">The body was dropped to keep this request under the profiler's size limit.</div>`
            : resp.body === null || resp.body === undefined ? `<div class="ni-empty">Binary content isn't recorded.</div>`
            : bodyView(resp.body, resp.content_type) + (resp.body_truncated ? `<div class="ni-sub muted">Showing the first ${bytes(resp.body.length)} of ${bytes(resp.size)}.</div>` : ""));
        break;

      case "cookies":
        if (!profiled) { body = note("cookies"); break; }
        body = section("Request Cookies", (req.request?.cookies || []).length
            ? `<div class="ni-sub muted">Names only — values are session secrets and are never recorded.</div>${kvTable(req.request.cookies.map((n) => [n, "••••"]), { copy: false })}`
            : `<div class="ni-empty">No cookies sent</div>`, { count: (req.request?.cookies || []).length })
          + section("Response Cookies (Set-Cookie)", (resp?.cookies || []).length ? `
            <table class="ni-table"><thead><tr><th>Name</th><th>Expires</th><th>HttpOnly</th><th>Secure</th><th>SameSite</th></tr></thead>
            <tbody>${resp.cookies.map((c) => `<tr><td class="mono">${esc(c.name)}</td><td>${esc(c.expires)}</td><td>${c.http_only ? "✓" : ""}</td><td>${c.secure ? "✓" : ""}</td><td>${esc(c.same_site || "")}</td></tr>`).join("")}</tbody></table>`
            : `<div class="ni-empty">No cookies set</div>`, { count: (resp?.cookies || []).length });
        break;

      case "timing":
        body = timingView(req);
        break;

      case "queries":
        body = queries.length ? requestQueries(req) : `<div class="ni-empty">${profiled ? "This request ran no SQL queries." : "Queries are recorded by the profiler only."}</div>`;
        break;

      case "context": {
        if (!profiled) { body = note("application context"); break; }
        const c = req.cache || {};
        body = section("Application", kvTable([
          ["Duration", ms(req.duration_ms)], ["Boot", ms(req.boot_ms)], ["Peak memory", `${req.memory_peak_mb || 0} MB`],
          ["Queries", `${req.query_count || queries.length} (${ms(req.query_time_ms)})`], ["Events fired", req.events_count || 0],
        ]))
          + section("Authenticated User", req.user ? kvTable(req.user) : `<div class="ni-empty">Guest</div>`)
          + section("Cache", kvTable([["Hits", c.hits || 0], ["Misses", c.misses || 0], ["Writes", c.writes || 0]], { copy: false }))
          + section("Views", (req.views || []).length ? `<div class="ni-chips">${req.views.map((v) => `<span class="chip sm mono">${esc(v)}</span>`).join("")}</div>` : `<div class="ni-empty">No views rendered</div>`, { count: (req.views || []).length })
          + section("Outgoing HTTP", (req.http_calls || []).length ? `<table class="ni-table"><thead><tr><th>Method</th><th>URL</th><th>Status</th><th>Time</th></tr></thead><tbody>
              ${req.http_calls.map((h) => `<tr><td>${esc(h.method || "")}</td><td class="mono ni-break">${esc(h.url)}${h.mocked ? ' <span class="chip xs">mocked</span>' : ""}</td><td>${esc(h.status)}</td><td>${ms(h.duration_ms)}</td></tr>`).join("")}</tbody></table>`
            : `<div class="ni-empty">No outgoing calls</div>`, { count: (req.http_calls || []).length })
          + section("Jobs", (req.jobs || []).length ? kvTable(req.jobs.map((j) => [j.name, `${j.status} · ${j.queue} · attempt ${j.attempts}`])) : `<div class="ni-empty">No jobs processed</div>`, { count: (req.jobs || []).length });
        break;
      }

      case "curl": {
        const cmd = curlFor(req, site);
        body = `<div class="ni-sub"><button class="btn sm" data-ni-copy="${esc(cmd)}">${icon("copy")}Copy cURL</button>
          <span class="muted">Cookies and hidden headers are left out.</span></div><pre class="ni-code">${esc(cmd)}</pre>`;
        break;
      }
    }

    const aside = panel.el.querySelector(".ni-panel");
    aside.innerHTML = header({
      badge: `<span class="perf-method ${(req.method || "get").toLowerCase()}">${esc(req.method || "GET")}</span>
              <span class="perf-status-badge ${statusClass(req.status)}">${esc(req.status || "—")}</span>`,
      title: req.uri || "/",
      meta: [
        ms(req.duration_ms),
        bytes(size),
        req.time_iso ? esc(req.time_iso.replace("T", " ").replace(/[+Z].*$/, "")) : (req.time ? esc(new Date(req.time * 1000).toLocaleString()) : ""),
        profiled ? `<span class="chip xs">profiler</span>` : `<span class="chip xs muted">nginx only</span>`,
        req.truncated ? `<span class="chip xs warn" title="Large request: some detail was dropped to fit the profiler's size limit">trimmed</span>` : "",
      ].filter(Boolean).join('<span class="ni-dot">·</span>'),
    }) + tabsBar(tabs) + `<div class="ni-body">${body}</div>`;
    wireCommon(aside, renderRequest);
    wireQueryRows(aside);
  }

  function timingView(req) {
    const net = req.network || {};
    const total = Number(req.duration_ms || net.total_ms || 0) || 1;
    const rows = [];
    const bar = (label, start, dur, cls, note = "") => {
      const left = Math.max(0, Math.min(100, (start / total) * 100));
      const width = Math.max(0.6, Math.min(100 - left, (dur / total) * 100));
      rows.push(`<div class="ni-wf-row"><div class="ni-wf-label" title="${esc(label)}">${esc(label)}</div>
        <div class="ni-wf-track"><div class="ni-wf-bar ni-wf-${cls}" style="left:${left}%;width:${width}%"></div></div>
        <div class="ni-wf-time">${ms(dur)}${note}</div></div>`);
    };
    if (net.upstream_connect_ms != null) bar("Connect to PHP-FPM", 0, net.upstream_connect_ms, "connect");
    if (req.boot_ms) bar("Framework boot", 0, req.boot_ms, "boot");
    (req.queries || []).forEach((q, i) => {
      if (q.start_ms != null) bar(`Query #${i + 1} · ${(q.sql || "").slice(0, 40)}`, Number(q.start_ms), Number(q.time_ms || 0), "query");
    });
    if (net.upstream_header_ms != null) bar("Waiting for app (TTFB)", 0, net.upstream_header_ms, "wait");
    if (net.upstream_ms != null) bar("Application total", 0, net.upstream_ms, "app");
    bar("Total", 0, total, "total");

    const qTime = Number(req.query_time_ms || 0);
    const summary = kvTable([
      ["Total", ms(total)],
      ...(net.upstream_ms != null ? [["Application (PHP)", ms(net.upstream_ms)], ["nginx overhead", ms(Math.max(0, (net.total_ms || total) - net.upstream_ms))]] : []),
      ...(req.boot_ms ? [["Framework boot", ms(req.boot_ms)]] : []),
      ...(req.queries?.length ? [["Database", `${ms(qTime)} · ${Math.round((qTime / total) * 100)}% of the request`]] : []),
    ], { copy: false });
    const unplaced = (req.queries || []).some((q) => q.start_ms == null);
    return section("Waterfall", `<div class="ni-wf">${rows.join("")}</div>
      ${unplaced ? `<div class="ni-sub muted">Some queries have no start time (recorded by an older profiler) and aren't drawn.</div>` : ""}`)
      + section("Summary", summary);
  }

  function requestQueries(req) {
    const queries = req.queries || [];
    const n1 = req.insights?.n_plus_one || [];
    const fmt = panel.opts.formatSql || esc;
    return (n1.length ? `<div class="ni-note warn">${icon("alert")}<span>${n1.length} possible N+1 pattern${n1.length > 1 ? "s" : ""}: ${n1.map((a) => `<b>${a.count}×</b> ${esc((a.pattern || "").slice(0, 60))}`).join(" · ")}</span></div>` : "")
      + `<table class="ni-table ni-qtable"><thead><tr><th>#</th><th>Query</th><th>Time</th><th>Caller</th></tr></thead><tbody>
      ${queries.map((q, i) => {
        const sql = q.interpolated_sql || q.sql || "";
        return `<tr class="ni-qrow" data-ni-q="${i}" tabindex="0">
          <td class="muted">${i + 1}</td>
          <td class="mono ni-ellipsis"><span class="query-badge ${(q.query_type || "sql").toLowerCase()}">${esc(q.query_type || "SQL")}</span> ${esc(sql)}</td>
          <td class="mono ${Number(q.time_ms) >= 50 ? "ni-slow" : ""}">${ms(q.time_ms)}</td>
          <td class="mono ni-ellipsis">${caller(q.file, q.line)}</td></tr>
        <tr class="ni-qdetail" data-ni-qd="${i}" hidden><td></td><td colspan="3">
          <pre class="ni-code sql-highlight">${fmt(sql)}</pre>
          ${(q.bindings || []).length ? `<div class="ni-sub muted mono">Bindings: ${esc(JSON.stringify(q.bindings))}</div>` : ""}
          <div class="ni-sub"><button class="btn xs" data-ni-copy="${esc(sql)}">${icon("copy")}Copy SQL</button>
            ${(q.query_type || "").toUpperCase() === "SELECT" ? `<button class="btn xs" data-ni-explain="${esc(sql)}">${icon("search")}Explain</button>` : ""}</div>
          <div class="ni-explain"></div>
        </td></tr>`;
      }).join("")}</tbody></table>`;
  }

  function wireQueryRows(root) {
    root.querySelectorAll("[data-ni-q]").forEach((row) => {
      const toggle = (e) => {
        if (e.target.closest("button")) return;
        const d = root.querySelector(`[data-ni-qd="${row.dataset.niQ}"]`);
        d.hidden = !d.hidden;
        row.classList.toggle("open", !d.hidden);
      };
      row.addEventListener("click", toggle);
      row.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(e); } });
    });
    root.querySelectorAll("[data-ni-explain]").forEach((b) => b.addEventListener("click", () =>
      explain(b.dataset.niExplain, b.closest("td")?.querySelector(".ni-explain") || root.querySelector(".ni-body > .ni-explain"), b)));
  }

  // EXPLAIN never runs the statement itself; only SELECTs are offered anyway.
  async function explain(sql, out, btn) {
    btn.disabled = true;
    out.innerHTML = `<div class="ni-loading sm">${icon("pulse")} Running EXPLAIN…</div>`;
    try {
      const target = await LD.call("db_for_site", { name: panel.site.name });
      const plan = await LD.call("db_explain", { conn: target.conn, database: target.database, sql });
      const st = plan.summary?.status || "";
      out.innerHTML = `<div class="ni-note ${st === "critical" ? "bad" : st === "warning" ? "warn" : "good"}">${icon(st === "optimal" ? "check" : "alert")}
          <span><b>${esc(st || "plan")}</b>${plan.summary?.full_table_scans ? ` · ${plan.summary.full_table_scans} full table scan(s)` : ""}</span></div>
        <table class="ni-table"><thead><tr><th>Step</th><th>Key</th><th>Rows</th><th>Notes</th></tr></thead><tbody>
        ${(plan.steps || []).map((s) => `<tr><td class="mono">${esc(s.operation || s.table || "")}</td><td class="mono">${esc(s.key || "—")}</td><td>${esc(s.rows ?? "")}</td><td>${esc(s.warning || s.extra || "")}</td></tr>`).join("")}
        </tbody></table>
        ${(plan.summary?.recommendations || []).map((r) => `<div class="ni-sub">${esc(r.message || "")}${r.suggested_sql ? ` <code data-ni-copy="${esc(r.suggested_sql)}" title="Click to copy">${esc(r.suggested_sql)}</code>` : ""}</div>`).join("")}`;
    } catch (err) {
      out.innerHTML = `<div class="ni-note bad">${icon("alert")}<span>${esc(err.message)}</span></div>`;
    } finally {
      btn.disabled = false;
    }
  }

  // ── query inspector ──────────────────────────────────────────────────────
  function openQuery(site, query, opts = {}) {
    ensurePanel();
    const list = opts.list || null;
    Object.assign(panel, { kind: "query", site, list, opts, data: query, tab: opts.tab || (panel.kind === "query" ? panel.tab : "sql"),
                           index: list ? Math.max(0, list.indexOf(query)) : 0 });
    renderQuery();
  }

  function renderQuery() {
    const q = panel.data;
    const fmt = panel.opts.formatSql || esc;
    const execs = q.executions || [];
    const tabs = [["sql", "SQL"], ["executions", "Executions", q.count || execs.length], ["callers", "Callers", (q.callers || []).length || ""], ["explain", "Explain"]];
    const isSelect = (q.query_type || "").toUpperCase() === "SELECT";
    const sql = q.interpolated_sql || q.sql || "";
    let body = "";

    switch (panel.tab) {
      case "sql":
        body = section("Statement", `<div class="ni-sub"><button class="btn xs" data-ni-copy="${esc(sql)}">${icon("copy")}Copy with values</button>
            <button class="btn xs ghost" data-ni-copy="${esc(q.sql || "")}">${icon("copy")}Copy with ?</button></div>
            <pre class="ni-code sql-highlight">${fmt(sql)}</pre>`)
          + section("Statistics", kvTable([
            ["Executions", `${q.count} in ${q.request_count || "?"} request(s)`],
            ["Total time", ms(q.total_time_ms)], ["Average", ms(q.avg_time_ms)],
            ["Fastest", ms(q.min_time_ms)], ["Slowest", ms(q.max_time_ms)], ["p95", ms(q.p95_time_ms)],
            ["Connection", q.connection || "default"],
          ], { copy: false }))
          + section("Normalized (all runs share this shape)", `<pre class="ni-code sql-highlight">${fmt(q.normalized || q.sql || "")}</pre>`, { open: false })
          + ((q.bindings || []).length ? section("Bindings (latest run)", kvTable(q.bindings.map((b, i) => [`?${i + 1}`, b === null ? "NULL" : b]))) : "")
          + (q.is_n_plus_one ? `<div class="ni-note warn">${icon("alert")}<span>Ran ${q.count} times — likely an N+1. Eager-load the relation with <code>with()</code> where it's called.</span></div>` : "");
        break;

      case "executions":
        body = execs.length ? `<table class="ni-table"><thead><tr><th>When</th><th>Request</th><th>Time</th><th>Caller</th></tr></thead><tbody>
          ${execs.map((e, i) => `<tr class="ni-qrow" data-ni-q="${i}" tabindex="0">
            <td class="muted">${e.request_time ? esc(new Date(e.request_time * 1000).toLocaleTimeString()) : "—"}</td>
            <td class="mono ni-ellipsis">${e.request_id ? `<button class="ni-link" data-ni-request="${esc(e.request_id)}" title="Open this request">${esc(e.request || "request")}</button>` : esc(e.request || "")}</td>
            <td class="mono ${Number(e.time_ms) >= 50 ? "ni-slow" : ""}">${ms(e.time_ms)}</td>
            <td class="mono ni-ellipsis">${caller(e.file, e.line)}</td></tr>
          <tr class="ni-qdetail" data-ni-qd="${i}" hidden><td></td><td colspan="3"><pre class="ni-code sql-highlight">${fmt(e.interpolated_sql || "")}</pre></td></tr>`).join("")}
          </tbody></table>${q.count > execs.length ? `<div class="ni-sub muted">Showing the latest ${execs.length} of ${q.count}.</div>` : ""}`
          : `<div class="ni-empty">No individual runs recorded</div>`;
        break;

      case "callers":
        body = (q.callers || []).length
          ? `<table class="ni-table"><thead><tr><th>File</th><th>Runs</th></tr></thead><tbody>${q.callers.map((c) => `<tr><td class="mono">${caller(c.file, c.line)}</td><td>${c.count}</td></tr>`).join("")}</tbody></table>`
          : `<div class="ni-empty">The caller wasn't found inside app/ (framework or vendor code ran it).</div>`;
        break;

      case "explain":
        body = isSelect
          ? `<div class="ni-sub">Asks the database how it would run this query, without running it.
              <button class="btn sm primary" data-ni-explain="${esc(sql)}">${icon("search")}Run EXPLAIN</button></div><div class="ni-explain"></div>`
          : `<div class="ni-empty">EXPLAIN is offered for SELECT queries only.</div>`;
        break;
    }

    const aside = panel.el.querySelector(".ni-panel");
    aside.innerHTML = header({
      badge: `<span class="query-badge ${(q.query_type || "sql").toLowerCase()}">${esc(q.query_type || "SQL")}</span>`,
      title: (q.sql || "").replace(/\s+/g, " "),
      meta: [`${q.count}× · avg ${ms(q.avg_time_ms)}`, `total ${ms(q.total_time_ms)}`,
             q.slow ? `<span class="chip xs danger">slow</span>` : "", q.is_n_plus_one ? `<span class="chip xs danger">N+1</span>` : ""]
        .filter(Boolean).join('<span class="ni-dot">·</span>'),
    }) + tabsBar(tabs) + `<div class="ni-body">${body}</div>`;
    wireCommon(aside, renderQuery);
    wireQueryRows(aside);
  }

  return { openRequest, openQuery, close };
})();
window.Inspector = Inspector;
