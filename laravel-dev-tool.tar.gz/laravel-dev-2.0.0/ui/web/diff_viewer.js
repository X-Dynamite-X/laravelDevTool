/**
 * ui/web/diff_viewer.js - Lightweight unified diff viewer component for laravel-dev-tool.
 */

const DiffViewer = {
  renderDiff(diffText) {
    if (!diffText || !diffText.trim()) {
      return '<div class="diff-empty" style="color:var(--muted);padding:12px;text-align:center;">No changes detected</div>';
    }

    const lines = diffText.split('\n');
    let html = '<div class="diff-container" style="font-family:monospace;font-size:12px;background:#18181b;border:1px solid #27272a;border-radius:8px;overflow-x:auto;padding:8px;">';

    for (const line of lines) {
      const escaped = line.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
      if (line.startsWith('+++') || line.startsWith('---')) {
        html += `<div style="color:#71717a;font-weight:bold;padding:2px 4px;">${escaped}</div>`;
      } else if (line.startsWith('@@')) {
        html += `<div style="color:#38bdf8;background:#0c4a6e33;padding:2px 4px;margin:2px 0;">${escaped}</div>`;
      } else if (line.startsWith('+')) {
        html += `<div style="color:#10b981;background:#064e3b33;padding:2px 4px;">${escaped}</div>`;
      } else if (line.startsWith('-')) {
        html += `<div style="color:#ef4444;background:#7f1d1d33;padding:2px 4px;">${escaped}</div>`;
      } else {
        html += `<div style="color:#a1a1aa;padding:2px 4px;">${escaped}</div>`;
      }
    }

    html += '</div>';
    return html;
  }
};

window.DiffViewer = DiffViewer;
