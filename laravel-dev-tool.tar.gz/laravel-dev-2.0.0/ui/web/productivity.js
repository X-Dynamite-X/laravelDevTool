"use strict";

/* ── Productivity, Command Palette & Vault Engine ─────────────────────────────
   Phase 6: Floating Command Palette (Ctrl+K) and Encrypted Vault UI.
   Designed for zero DOM bloat (< 1MB) and instant keyboard interaction.
───────────────────────────────────────────────────────────────────────────── */

const Productivity = (() => {
  function init() {
    setupCommandPaletteTrigger();
  }

  // ── 1. Command Palette (Ctrl+K) ───────────────────────────────────────────

  let paletteOpen = false;
  let activeIndex = 0;
  let filteredCommands = [];
  const siteArtisanCommands = new Map();

  function setupCommandPaletteTrigger() {
    document.addEventListener("keydown", (e) => {
      const ctrl = e.ctrlKey || e.metaKey;
      if (ctrl && e.key.toLowerCase() === "k") {
        e.preventDefault();
        toggleCommandPalette();
      }
    });
  }

  function toggleCommandPalette() {
    if (paletteOpen) {
      closeCommandPalette();
    } else {
      openCommandPalette();
    }
  }

  function getCommandItems() {
    const items = [];

    // Views navigation
    items.push({
      category: "Navigation",
      title: "Go to Sites",
      icon: "globe",
      run: () => setView("sites"),
    });
    items.push({
      category: "Navigation",
      title: "Go to Database",
      icon: "database",
      run: () => setView("database"),
    });
    items.push({
      category: "Navigation",
      title: "Open Hologram Schema Visualizer",
      icon: "grid",
      run: () => {
        setView("database");
        if (window.DB?.openHologram) window.DB.openHologram();
      },
    });
    items.push({
      category: "Navigation",
      title: "Go to Servers",
      icon: "cloud",
      run: () => setView("servers"),
    });
    items.push({
      category: "Navigation",
      title: "Go to Cloudflare",
      icon: "cloud",
      run: () => setView("cloudflare"),
    });
    items.push({
      category: "Navigation",
      title: "Go to GitHub",
      icon: "git",
      run: () => setView("github"),
    });
    items.push({
      category: "Navigation",
      title: "Go to Settings",
      icon: "settings",
      run: () => setView("settings"),
    });

    // Sites
    (state.sites || []).forEach((site) => {
      items.push({
        category: "Projects",
        title: `${site.name} · Open in Browser`,
        detail: site.domain || site.url,
        icon: "browser",
        run: () => openOn("browser", site.name),
      });
      items.push({
        category: "Projects",
        title: `${site.name} · Open Project Drawer`,
        detail: site.path,
        icon: "folder",
        run: () => openDrawer(site.name, "overview"),
      });
      if (site.type === "laravel") {
        items.push({
          category: "Laravel",
          title: `${site.name} · Open Web Tinker`,
          icon: "terminal",
          run: () => openDrawer(site.name, "tinker"),
        });
        items.push({
          category: "Laravel",
          title: `${site.name} · View Live Logs`,
          icon: "pulse",
          run: () => openDrawer(site.name, "logs"),
        });
        items.push({
          category: "Laravel",
          title: `${site.name} · Queues & Cron Dashboard`,
          icon: "layers",
          run: () => openDrawer(site.name, "queue"),
        });
        items.push({
          category: "Laravel",
          title: `${site.name} · Deploy & Snapshots`,
          icon: "rocket",
          run: () => openDrawer(site.name, "deploy"),
        });
        items.push({
          category: "Laravel",
          title: `${site.name} · Open Mailbox`,
          icon: "mail",
          run: () => openDrawer(site.name, "mail"),
        });
        items.push({
          category: "Laravel",
          title: `${site.name} · Artisan Make Generator`,
          icon: "zap",
          run: () => openMakeModal(site.name),
        });
      }
    });

    // Quick Artisan Actions
    if (state.drawer?.name) {
      const activeSite = state.drawer.name;
      const cached = siteArtisanCommands.get(activeSite) || [];
      if (cached.length) {
        cached.forEach((c) => {
          items.push({
            category: "Artisan",
            title: `php artisan ${c.name} (${activeSite})`,
            detail: c.description || "",
            icon: "terminal",
            run: () => runAction("artisan", { name: activeSite, args: c.name }),
          });
        });
      } else {
        items.push({
          category: "Artisan",
          title: `php artisan migrate (${activeSite})`,
          icon: "terminal",
          run: () => runAction("artisan", { name: activeSite, args: "migrate" }),
        });
        items.push({
          category: "Artisan",
          title: `php artisan optimize:clear (${activeSite})`,
          icon: "zap",
          run: () => runAction("artisan", { name: activeSite, args: "optimize:clear" }),
        });
        LD.call("artisan_commands", { name: activeSite }).then((cmds) => {
          if (cmds && cmds.length) siteArtisanCommands.set(activeSite, cmds);
        }).catch(() => {});
      }
    }

    return items;
  }

  function openCommandPalette() {
    paletteOpen = true;
    activeIndex = 0;

    let modal = $("#cmd-palette-root");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "cmd-palette-root";
      modal.className = "cmd-palette-scrim";
      document.body.appendChild(modal);
    }

    modal.hidden = false;
    modal.innerHTML = `
      <div class="cmd-palette-box">
        <div class="cmd-palette-input-wrap">
          <span class="cmd-palette-search-icon">${icon("search")}</span>
          <input type="text" id="cmd-palette-input" class="cmd-palette-input" placeholder="Type a command or search sites, databases, servers…" autocomplete="off" spellcheck="false">
          <kbd class="cmd-palette-kbd">Esc</kbd>
        </div>
        <div class="cmd-palette-results" id="cmd-palette-results"></div>
      </div>`;

    const input = $("#cmd-palette-input", modal);
    input.focus();

    filterAndRenderCommands("");

    input.addEventListener("input", () => {
      activeIndex = 0;
      filterAndRenderCommands(input.value.trim().toLowerCase());
    });

    input.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        if (filteredCommands.length) {
          activeIndex = (activeIndex + 1) % filteredCommands.length;
          renderCommandItems();
        }
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        if (filteredCommands.length) {
          activeIndex = (activeIndex - 1 + filteredCommands.length) % filteredCommands.length;
          renderCommandItems();
        }
      } else if (e.key === "Enter") {
        e.preventDefault();
        const selected = filteredCommands[activeIndex];
        if (selected) {
          closeCommandPalette();
          selected.run();
        }
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeCommandPalette();
      }
    });

    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeCommandPalette();
    });
  }

  function closeCommandPalette() {
    paletteOpen = false;
    const modal = $("#cmd-palette-root");
    if (modal) modal.hidden = true;
  }

  function filterAndRenderCommands(query) {
    const all = getCommandItems();
    if (!query) {
      filteredCommands = all.slice(0, 16);
    } else {
      filteredCommands = all.filter((cmd) => {
        return (
          cmd.title.toLowerCase().includes(query) ||
          (cmd.detail && cmd.detail.toLowerCase().includes(query)) ||
          cmd.category.toLowerCase().includes(query)
        );
      }).slice(0, 20);
    }
    renderCommandItems();
  }

  function renderCommandItems() {
    const listEl = $("#cmd-palette-results");
    if (!listEl) return;

    if (!filteredCommands.length) {
      listEl.innerHTML = `<div style="padding:24px;text-align:center;color:var(--muted)">No matching commands found</div>`;
      return;
    }

    listEl.innerHTML = filteredCommands.map((cmd, idx) => {
      const isSelected = idx === activeIndex;
      return `
        <div class="cmd-item ${isSelected ? "selected" : ""}" data-cmd-idx="${idx}">
          <span class="cmd-item-icon">${icon(cmd.icon || "terminal")}</span>
          <div class="cmd-item-content">
            <div class="cmd-item-title">${esc(cmd.title)}</div>
            ${cmd.detail ? `<div class="cmd-item-detail">${esc(cmd.detail)}</div>` : ""}
          </div>
          <span class="cmd-item-badge">${esc(cmd.category)}</span>
        </div>`;
    }).join("");

    const selectedEl = listEl.querySelector(".cmd-item.selected");
    if (selectedEl) selectedEl.scrollIntoView({ block: "nearest" });

    listEl.querySelectorAll(".cmd-item").forEach((el) => {
      el.addEventListener("click", () => {
        const idx = Number(el.dataset.cmdIdx);
        const target = filteredCommands[idx];
        if (target) {
          closeCommandPalette();
          target.run();
        }
      });
    });
  }

  // ── 2. Encrypted Vault UI ─────────────────────────────────────────────────

  async function openVaultModal(vaultStatus) {
    const isEnabled = vaultStatus?.enabled;
    const isUnlocked = vaultStatus?.unlocked;

    if (!isEnabled) {
      if (vaultStatus?.available === false) {
        toast("error", "Vault Unavailable", vaultStatus.error || "python3-cryptography is required.");
        return;
      }
      // Setup vault modal
      const res = await formModal({
        title: "Enable Encrypted Vault",
        confirm: "Enable & Encrypt",
        fields: [
          { name: "password", label: "Master Password", type: "password", required: true, minlength: 6 },
          { name: "confirm", label: "Confirm Password", type: "password", required: true, minlength: 6 },
        ],
      });
      if (!res) return;
      if (res.password !== res.confirm) {
        toast("error", "Passwords do not match");
        return;
      }
      try {
        await LD.call("vault_set_key", { password: res.password });
        toast("success", "Vault enabled and all credentials encrypted");
        if (state.vault) Object.assign(state.vault, { enabled: true, unlocked: true });
        renderVaultSection();
      } catch (err) {
        toast("error", "Vault error", err.message);
      }
      return;
    }

    if (!isUnlocked) {
      // Unlock modal
      const res = await formModal({
        title: "Unlock Credential Vault",
        confirm: "Unlock",
        fields: [
          { name: "password", label: "Master Password", type: "password", required: true },
        ],
      });
      if (!res) return;
      try {
        await LD.call("vault_unlock", { password: res.password });
        toast("success", "Vault unlocked successfully");
        if (state.vault) state.vault.unlocked = true;
        renderVaultSection();
      } catch (err) {
        toast("error", "Vault error", err.message);
      }
      return;
    }

    // Already enabled and unlocked
    await LD.call("vault_lock");
    toast("success", "Vault locked");
    if (state.vault) state.vault.unlocked = false;
    renderVaultSection();
  }

  function renderVaultSection() {
    const container = $("#vault-settings-card");
    if (!container) return;

    const v = state.vault || { enabled: false, unlocked: true, available: true };
    const isUnavailable = v.available === false;

    container.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <h3 style="margin:0;display:flex;align-items:center;gap:8px">
          ${icon("lock")}Credential Vault
        </h3>
        <span class="chip sm ${v.enabled ? (v.unlocked ? "active" : "danger") : (isUnavailable ? "danger" : "muted")}">
          ${isUnavailable ? "Unavailable" : (v.enabled ? (v.unlocked ? "Unlocked" : "Locked") : "Disabled")}
        </span>
      </div>
      <p class="muted" style="margin:0 0 12px">Protects database passwords, SSH keys, and server secrets with authenticated Fernet AES-128-CBC + PBKDF2 (100k rounds) encryption.</p>
      ${isUnavailable ? `<div class="notice danger sm" style="margin-bottom:12px">${esc(v.error || "python3-cryptography is required.")}</div>` : ""}
      <div class="btn-row">
        ${!v.enabled
          ? `<button type="button" class="btn sm primary" id="btn-vault-action" ${isUnavailable ? "disabled" : ""}>${icon("lock")}Set Master Password</button>`
          : !v.unlocked
            ? `<button type="button" class="btn sm primary" id="btn-vault-action">${icon("key")}Unlock Vault</button>`
            : `<button type="button" class="btn sm" id="btn-vault-action">${icon("lock")}Lock Vault</button>
               <button type="button" class="btn sm" id="btn-vault-change-key">${icon("key")}Change Password</button>
               <button type="button" class="btn sm danger" id="btn-vault-disable">${icon("trash")}Disable Vault</button>`}
      </div>`;

    const actBtn = $("#btn-vault-action", container);
    if (actBtn) {
      actBtn.addEventListener("click", () => openVaultModal(state.vault));
    }

    const changeBtn = $("#btn-vault-change-key", container);
    if (changeBtn) {
      changeBtn.addEventListener("click", async () => {
        const res = await formModal({
          title: "Change Master Password",
          confirm: "Change Password",
          fields: [
            { name: "old_password", label: "Current Master Password", type: "password", required: true },
            { name: "new_password", label: "New Master Password", type: "password", required: true, minlength: 6 },
            { name: "confirm_password", label: "Confirm New Password", type: "password", required: true, minlength: 6 },
          ],
        });
        if (!res) return;
        if (res.new_password !== res.confirm_password) {
          toast("error", "New passwords do not match");
          return;
        }
        try {
          await LD.call("vault_set_key", { old_password: res.old_password, password: res.new_password });
          toast("success", "Master password changed and credentials re-encrypted");
          renderVaultSection();
        } catch (err) {
          toast("error", "Couldn't change password", err.message);
        }
      });
    }

    const disableBtn = $("#btn-vault-disable", container);
    if (disableBtn) {
      disableBtn.addEventListener("click", async () => {
        const res = await formModal({
          title: "Disable Encrypted Vault?",
          message: "Enter master password to decrypt all credentials back to plain text and disable vault.",
          confirm: "Disable Vault",
          danger: true,
          fields: [{ name: "password", label: "Master Password", type: "password", required: true }],
        });
        if (!res) return;
        try {
          await LD.call("vault_disable", { password: res.password });
          toast("success", "Vault disabled and secrets decrypted");
          if (state.vault) Object.assign(state.vault, { enabled: false, unlocked: true });
          renderVaultSection();
        } catch (err) {
          toast("error", "Couldn't disable vault", err.message);
        }
      });
    }
  }

  // ── 3. Artisan Make Generator (Task 7.9) ───────────────────────────────────

  function openMakeModal(siteName) {
    if (!siteName) {
      if (state.sites && state.sites.length) {
        siteName = state.sites[0].name;
      } else {
        toast("info", "No project sites available");
        return;
      }
    }

    openModal(`
      <form class="modal" id="artisan-make-form" style="max-width:540px">
        <div class="modal-header">
          <h2>${icon("zap")} Artisan Make Generator · ${esc(siteName)}</h2>
          <p>Generate Laravel scaffold components with intuitive options and instantly open them in your editor.</p>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <div class="grid-2">
            <label class="field">
              <span>Component Type</span>
              <select id="make-type-select">
                <option value="model">Model</option>
                <option value="controller">Controller</option>
                <option value="migration">Migration</option>
                <option value="request">Form Request</option>
                <option value="job">Queue Job</option>
                <option value="event">Event</option>
                <option value="listener">Listener</option>
                <option value="seeder">Seeder</option>
                <option value="factory">Factory</option>
                <option value="mail">Mailable</option>
                <option value="notification">Notification</option>
                <option value="resource">API Resource</option>
                <option value="rule">Validation Rule</option>
                <option value="command">Console Command</option>
              </select>
            </label>
            <label class="field">
              <span>Name</span>
              <input type="text" id="make-name-input" placeholder="e.g. Post or PostController" required autofocus>
            </label>
          </div>

          <div id="make-options-wrap" style="background:var(--surface-2);padding:10px 12px;border-radius:6px"></div>
          <div id="make-result-wrap" style="display:none;padding:10px;border-radius:6px;background:var(--surface-1)"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>Cancel</button>
          <button type="submit" class="btn primary" id="btn-make-submit">${icon("play")} Generate</button>
        </div>
      </form>
    `, (root) => {
      const typeSelect = $("#make-type-select", root);
      const nameInput = $("#make-name-input", root);
      const optWrap = $("#make-options-wrap", root);
      const form = $("#artisan-make-form", root);
      const resultWrap = $("#make-result-wrap", root);
      const submitBtn = $("#btn-make-submit", root);

      function updateOptions() {
        const type = typeSelect.value;
        if (type === "model") {
          optWrap.style.display = "block";
          optWrap.innerHTML = `
            <span style="font-size:11px;font-weight:600;color:var(--muted);display:block;margin-bottom:6px">Model Options:</span>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px">
              <label class="row" style="margin:0;gap:6px;cursor:pointer"><input type="checkbox" value="-m"> <span>Migration (-m)</span></label>
              <label class="row" style="margin:0;gap:6px;cursor:pointer"><input type="checkbox" value="-c"> <span>Controller (-c)</span></label>
              <label class="row" style="margin:0;gap:6px;cursor:pointer"><input type="checkbox" value="-r"> <span>Resource Controller (-r)</span></label>
              <label class="row" style="margin:0;gap:6px;cursor:pointer"><input type="checkbox" value="-f"> <span>Factory (-f)</span></label>
              <label class="row" style="margin:0;gap:6px;cursor:pointer"><input type="checkbox" value="-s"> <span>Seeder (-s)</span></label>
              <label class="row" style="margin:0;gap:6px;cursor:pointer"><input type="checkbox" value="-a"> <span>All scaffolding (-a)</span></label>
            </div>
          `;
        } else if (type === "controller") {
          optWrap.style.display = "block";
          optWrap.innerHTML = `
            <span style="font-size:11px;font-weight:600;color:var(--muted);display:block;margin-bottom:6px">Controller Options:</span>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px">
              <label class="row" style="margin:0;gap:6px;cursor:pointer"><input type="checkbox" value="--resource"> <span>Resource CRUD</span></label>
              <label class="row" style="margin:0;gap:6px;cursor:pointer"><input type="checkbox" value="--api"> <span>API Resource</span></label>
              <label class="row" style="margin:0;gap:6px;cursor:pointer"><input type="checkbox" value="--invokable"> <span>Invokable (__invoke)</span></label>
            </div>
          `;
        } else if (type === "job") {
          optWrap.style.display = "block";
          optWrap.innerHTML = `
            <label class="row" style="margin:0;gap:6px;cursor:pointer;font-size:12px"><input type="checkbox" value="--sync"> <span>Synchronous (--sync)</span></label>
          `;
        } else {
          optWrap.style.display = "none";
          optWrap.innerHTML = "";
        }
      }

      typeSelect.addEventListener("change", updateOptions);
      updateOptions();

      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const makeType = typeSelect.value;
        const makeName = nameInput.value.trim();
        if (!makeName) return;

        const flags = Array.from(optWrap.querySelectorAll("input:checked")).map((cb) => cb.value);

        submitBtn.disabled = true;
        submitBtn.innerHTML = `${icon("pulse")} Generating…`;
        resultWrap.style.display = "none";

        try {
          const res = await LD.call("artisan_make", {
            name: siteName,
            type: makeType,
            make_name: makeName,
            flags,
          });

          if (!res.ok) throw new Error(res.error || res.output || "Make command failed");

          toast("success", `Generated ${makeType}: ${makeName}`);
          resultWrap.style.display = "block";
          resultWrap.innerHTML = `
            <div style="color:var(--green);font-size:12.5px;font-weight:600;margin-bottom:6px">✓ Generated successfully:</div>
            <pre style="font-family:var(--mono);font-size:11.5px;margin:0 0 8px;white-space:pre-wrap">${esc(res.output)}</pre>
            ${res.created_files && res.created_files.length ? `
              <div style="display:flex;gap:6px;flex-wrap:wrap">
                ${res.created_files.map((f) => `<button type="button" class="btn sm" data-open-created="${esc(f)}">${icon("code")} Open ${esc(f)}</button>`).join("")}
              </div>
            ` : ""}
          `;

          $$("[data-open-created]", resultWrap).forEach((b) => {
            b.addEventListener("click", () => {
              LD.call("open_file", { path: b.dataset.openCreated });
            });
          });
        } catch (err) {
          resultWrap.style.display = "block";
          resultWrap.innerHTML = `<div style="color:var(--red);font-size:12px">${esc(err.message)}</div>`;
        } finally {
          submitBtn.disabled = false;
          submitBtn.innerHTML = `${icon("play")} Generate`;
        }
      });
    });
  }

  return {
    init,
    toggleCommandPalette,
    openCommandPalette,
    closeCommandPalette,
    renderVaultSection,
    openMakeModal,
  };
})();
