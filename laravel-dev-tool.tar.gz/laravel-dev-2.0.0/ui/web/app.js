"use strict";

/* ── icons (lucide-style paths) ─────────────────────────────────────────── */
const ICONS = {
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  server: '<rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><path d="M6 6h.01M6 18h.01"/>',
  settings: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  terminal: '<path d="m4 17 6-6-6-6M12 19h8"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  refresh: '<path d="M21 12a9 9 0 0 1-15.5 6.2L3 16M3 12a9 9 0 0 1 15.5-6.2L21 8M21 3v5h-5M3 21v-5h5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  play: '<path d="m7 4 13 8-13 8z"/>',
  stop: '<rect x="5" y="5" width="14" height="14" rx="2"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  browser: '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  code: '<path d="m16 18 6-6-6-6M8 6l-6 6 6 6"/>',
  folder: '<path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.7-.9l-.8-1.2A2 2 0 0 0 7.9 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z"/>',
  file: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
  branch: '<circle cx="6" cy="5" r="2.5"/><circle cx="6" cy="19" r="2.5"/><circle cx="18" cy="7" r="2.5"/><path d="M6 7.5v9M18 9.5c0 5-6 4-11 7.5"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  trash: '<path d="M3 6h18M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  unlink: '<path d="m18.8 13.4 1.7-1.7a5 5 0 0 0-7.1-7.1l-1.7 1.7M5.2 10.6l-1.7 1.7a5 5 0 0 0 7.1 7.1l1.7-1.7M8 2v3M2 8h3M16 22v-3M22 16h-3"/>',
  wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.8-3.8a6 6 0 0 1-7.9 7.9l-6.9 6.9a2.1 2.1 0 0 1-3-3l6.9-6.9a6 6 0 0 1 7.9-7.9z"/>',
  filter: '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
  pulse: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
  zap: '<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
  cpu: '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
  bug: '<path d="m8 2 1.88 1.88"/><path d="M14.12 3.88 16 2"/><path d="M9 7.13v-1a3 3 0 1 1 6 0v1"/><path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"/><path d="M12 20v-9"/><path d="M6.53 9C4.6 8.8 3 7.1 3 5"/><path d="M6 13H2"/><path d="M3 21c0-2.1 1.7-3.9 3.8-4"/><path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"/><path d="M22 13h-4"/><path d="M17.2 17c2.1.1 3.8 1.9 3.8 4"/>',
  activity: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
  sparkles: '<path d="m12 3 1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2z"/>',
  alert: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
  cloud: '<path d="M17.5 19H9a7 7 0 1 1 6.7-9h1.8a4.5 4.5 0 1 1 0 9z"/>',
  back: '<path d="m15 18-6-6 6-6"/>',
  up: '<path d="m18 15-6-6-6 6"/>',
  home: '<path d="m3 10 9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  rocket: '<path d="M4.5 16.5c-1.5 1.3-2 5-2 5s3.7-.5 5-2c.7-.8.7-2.1-.1-2.9a2.2 2.2 0 0 0-2.9-.1z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.9A12.9 12.9 0 0 1 22 2c0 2.7-.8 7.5-6 11a22.4 22.4 0 0 1-4 2z"/><path d="M9 12H4s.6-3 2-4c1.6-1.1 5 0 5 0M12 15v5s3-.6 4-2c1.1-1.6 0-5 0-5"/>',
  power: '<path d="M18.4 6.6a9 9 0 1 1-12.8 0M12 2v10"/>',
  key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
  rename: '<path d="M17 22h-1a4 4 0 0 1-4-4V6a4 4 0 0 1 4-4h1M7 22h1a4 4 0 0 0 4-4v-1M7 2h1a4 4 0 0 1 4 4v1"/>',
  eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  grid: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/>',
  env: '<path d="M4 7h16M4 12h10M4 17h7"/><circle cx="18" cy="16" r="3"/><path d="m20.2 18.2 1.8 1.8"/>',
  history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5M12 7v5l4 2"/>',
  "rotate-ccw": '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  qrcode: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
  git: '<circle cx="18" cy="18" r="3"/><circle cx="6" cy="6" r="3"/><path d="M6 9v12"/><path d="M18 15a9 9 0 0 0-9-9H6"/>',
};

function icon(name, cls = "") {
  return `<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ""}</svg>`;
}

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

const NEW_NAME_RE = /^[a-z0-9][a-z0-9.-]*$/;

const TYPES = {
  laravel: { label: "Laravel", color: "#f53003" },
  next: { label: "Next.js", color: "#71717a" },
  nuxt: { label: "Nuxt", color: "#00a86b" },
  vite: { label: "Vite", color: "#8b5cf6" },
  node: { label: "Node", color: "#5fa04e" },
  django: { label: "Django", color: "#3776ab" },
};
const isApp = (site) => site && site.type && site.type !== "laravel";
// Runs its own server process (start/stop): every non-Laravel app, and Laravel too on macOS/Windows.
const runsServer = (site) => !!(site && site.process);
const managed = () => state.mode !== "portable";

function typeChip(site) {
  const meta = TYPES[site.type] || TYPES.node;
  return `<span class="chip type" style="--type:${meta.color}">${esc(site.type_label || meta.label)}</span>`;
}
const DOMAIN_RE = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/;

/* ── bridge to ui/app.py ────────────────────────────────────────────────── */
const LD = {
  seq: 0,
  pending: new Map(),
  call(method, params = {}) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      const message = JSON.stringify({ id, method, params });
      if (window.webkit?.messageHandlers?.ld) {
        window.webkit.messageHandlers.ld.postMessage(message);
      } else if (window.pywebview?.api) {
        window.pywebview.api.post(message);
      } else {
        Demo.handle(id, method, params);
      }
    });
  },
  resolve(id, payload) {
    const entry = this.pending.get(id);
    if (!entry) return;
    this.pending.delete(id);
    payload.ok ? entry.resolve(payload.data) : entry.reject(new Error(payload.error || "Unknown error"));
  },
  onEvent(event) {
    if (event.type === "task") onTaskEvent(event.task, event.done);
    if (event.type === "output") onTaskOutput(event.id, event.text);
    if (event.type === "dump") window.LaravelDev?.onDumpEvent(event.dump);
    if (event.type === "perf_request") window.LaravelDev?.onPerfEvent(event);
    window.Servers?.onEvent(event);
    window.Database?.onEvent(event);
  },
};
window.LD = LD;

/* ── state ──────────────────────────────────────────────────────────────── */
const state = {
  view: "sites",
  filter: "",
  sites: [],
  services: [],
  phpVersions: [],
  settings: {},
  prefs: {},
  editors: [],
  tray: false,
  tasks: new Map(),
  output: new Map(),
  activeTask: null,
  drawer: { name: null, tab: "overview", details: null },
  loaded: false,
  mode: "managed",
  platform: "linux",
  tools: null,
};

/* ── helpers ────────────────────────────────────────────────────────────── */
function avatarColor(name) {
  let hash = 0;
  for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  return `hsl(${hash % 360} 62% 52%)`;
}

function avatar(name, size = "") {
  return `<div class="avatar ${size}" style="background:${avatarColor(name)}">${esc(name[0] || "?")}</div>`;
}

function toast(type, title, detail = "") {
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.innerHTML = `${icon(type === "error" ? "alert" : "check")}<div><b>${esc(title)}</b>${detail ? `<small>${esc(detail)}</small>` : ""}</div>`;
  $("#toasts").append(el);
  setTimeout(() => { el.classList.add("leaving"); setTimeout(() => el.remove(), 220); }, type === "error" ? 6000 : 3500);
}

async function api(method, params) {
  try {
    return await LD.call(method, params);
  } catch (err) {
    toast("error", "Something went wrong", err.message);
    throw err;
  }
}

function copyText(text) {
  const area = document.createElement("textarea");
  area.value = text;
  document.body.append(area);
  area.select();
  document.execCommand("copy");
  area.remove();
  toast("success", "Copied to clipboard");
}

function timeAgo(ts) {
  const s = Math.max(0, Math.round(Date.now() / 1000 - ts));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  return `${Math.floor(s / 3600)}h ago`;
}

function phpOptions(selected) {
  return state.phpVersions.map((v) => `<option value="${esc(v)}" ${v === selected ? "selected" : ""}>PHP ${esc(v)}</option>`).join("");
}

function defaultPhp() {
  const pref = state.prefs.default_php;
  return state.phpVersions.includes(pref) ? pref : state.phpVersions[state.phpVersions.length - 1];
}

function slugify(value) {
  return value.toLowerCase().replace(/\.git$/, "").replace(/[^a-z0-9.-]+/g, "-").replace(/^[^a-z0-9]+|-+$/g, "");
}

function applyTheme() {
  const theme = state.prefs.theme || "system";
  if (theme === "system") document.documentElement.removeAttribute("data-theme");
  else document.documentElement.setAttribute("data-theme", theme);
}

/* ── navigation ─────────────────────────────────────────────────────────── */
function setView(view) {
  // The site workspace occupies the main area; leave it when navigating to a
  // global page from the persistent sidebar.
  if (view !== "sites" && state.drawer.name) closeDrawer();
  state.view = view;
  $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  $$(".view").forEach((v) => (v.hidden = v.id !== `view-${view}`));
  if (view === "services") managed() ? refreshServices() : renderTools();
  if (view === "settings") renderSettings();
  if (view === "servers") window.Servers?.show();
  if (view === "cloudflare") window.Cloudflare?.show();
  if (view === "github") window.GitHub?.show();
  if (view === "database") window.Database?.show();
}

/* ── sites ──────────────────────────────────────────────────────────────── */
function renderSites() {
  const body = $("#sites-body");
  const linked = state.sites.filter((s) => s.linked);
  const unlinked = state.sites.filter((s) => !s.linked);
  $("#nav-sites-count").textContent = linked.length || "";
  const dir = (state.settings.LARAVEL_SITES_DIR || "").replace(state.home, "~");
  const countLabel = t(linked.length === 1 ? "site_single" : "site_plural", linked.length === 1 ? "site" : "sites");
  const folderLabel = t("www_folder", "www folder");
  $("#sites-subtitle").innerHTML = `${linked.length} ${countLabel} · ${folderLabel} <bdi>${esc(dir)}</bdi>`;

  if (!state.loaded) {
    body.innerHTML = `<div class="site-list">${'<div class="skeleton"></div>'.repeat(4)}</div>`;
    return;
  }

  if (!state.sites.length) {
    body.innerHTML = `
      <div class="empty">
        <div class="empty-icon">${icon("sparkles")}</div>
        <h2>${t("no_sites_yet", "No sites yet")}</h2>
        <p>Create a fresh Laravel, Next.js, Nuxt or Django app, link a project you already have, or clone one from Git. ${managed() ? "Each gets its own <b>.test</b> domain." : "Each runs on its own localhost port."}</p>
        <div class="actions">
          <button class="btn primary" data-add="new">${icon("plus")}${t("new_project", "New project")}</button>
          <button class="btn" data-add="link">${icon("folder")}${t("link_folder", "Link folder")}</button>
          <button class="btn" data-add="clone">${icon("branch")}${t("clone_repo", "Clone repo")}</button>
        </div>
      </div>`;
    return;
  }

  const q = state.filter.trim().toLowerCase();
  const match = (s) => !q || [s.name, s.domain, s.path].some((v) => v.toLowerCase().includes(q));
  const shownLinked = linked.filter(match);
  const shownUnlinked = unlinked.filter(match);

  let html = "";
  if (shownLinked.length) html += `<div class="site-list">${shownLinked.map(siteRow).join("")}</div>`;
  if (shownUnlinked.length) {
    html += `<div class="group-label" style="margin-top:${shownLinked.length ? 24 : 0}px">${icon("folder")}${t("found_in_not_linked", "Found in")} <bdi>${esc(dir)}</bdi> ${t("not_linked_suffix", "but not linked")}</div>
             <div class="site-list">${shownUnlinked.map(siteRow).join("")}</div>`;
  }
  if (!html) html = `<div class="empty"><h2>${t("no_matches", "No matches")}</h2><p>${t("nothing_matches", "Nothing matches")} “${esc(state.filter)}”.</p></div>`;
  body.innerHTML = html;
}

function siteRow(site) {
  const selected = state.drawer.name === site.name ? "selected" : "";
  const chips = [];
  if (!site.exists) chips.push(`<span class="chip warn">${icon("alert")}Folder missing</span>`);
  if (site.type !== "laravel") chips.push(typeChip(site));
  if (site.linked && site.php) chips.push(`<span class="chip php">PHP ${esc(site.php)}</span>`);
  if (runsServer(site) && site.linked) chips.push(site.running
    ? `<span class="chip ok" title="Running on port ${esc(site.port)}"><span class="dot on"></span>:${esc(site.port)}</span>`
    : `<span class="chip">Stopped</span>`);
  if (site.branch) chips.push(`<span class="chip branch">${icon("branch")}${esc(site.branch)}</span>`);
  if (site.parked) {
    chips.push(`<span class="chip ok" title="Valet-style Parked directory">${icon("sparkles")}${t("parked_badge", "Parked")}</span>`);
  }
  if (site.ssl) {
    chips.push(`<span class="chip ok" title="HTTPS SSL active">${icon("lock")}HTTPS</span>`);
  }
  if (site.worker) {
    chips.push(`<span class="chip ok" title="Queue worker running"><span class="dot on"></span>Queue</span>`);
  } else if (site.worker_configured) {
    chips.push(`<span class="chip muted" title="Queue worker stopped"><span class="dot off"></span>Queue</span>`);
  }
  if (site.cron) {
    chips.push(`<span class="chip ok" title="Cron scheduler active">${icon("clock")}Cron</span>`);
  }
  if (site.log_errors_today && site.log_errors_today > 0) {
    chips.push(`<span class="chip danger" title="${site.log_errors_today} error(s) logged today">${icon("alert")}${site.log_errors_today} err</span>`);
  }
  if (site.reverb?.installed) {
    if (site.reverb.running) {
      chips.push(`<span class="chip ok" title="Reverb WebSocket running on port ${esc(site.reverb.port)}"><span class="dot on"></span>Reverb :${esc(site.reverb.port)}</span>`);
    } else {
      chips.push(`<span class="chip muted" title="Reverb WebSocket stopped"><span class="dot off"></span>Reverb</span>`);
    }
  }

  if (site.tunnel?.active) {
    chips.push(`<span class="chip ok" title="Cloudflare Public Tunnel active: ${esc(site.tunnel.url)}"><span class="dot on"></span>${icon("cloud")}Tunnel</span>`);
  }

  if (site.perf) {
    if (site.perf.errors_5xx > 0) {
      chips.push(`<span class="chip danger" title="${site.perf.errors_5xx} 5xx server errors in recent requests">${icon("alert")}${site.perf.errors_5xx} 5xx</span>`);
    } else if (site.perf.p95 > 0) {
      chips.push(`<span class="chip sm ${site.perf.p95 > 250 ? 'warn' : 'ok'}" title="P95 latency: ${site.perf.p95}ms">${icon("activity")}${site.perf.p95}ms</span>`);
    }
  }

  const power = runsServer(site) && site.linked && site.exists
    ? `<button class="btn ghost icon-btn sm ${site.running ? "" : "accent"}" data-app="${site.running ? "stop" : "start"}" title="${site.running ? "Stop" : "Start"}" aria-label="${site.running ? "Stop" : "Start"}">${icon(site.running ? "stop" : "play")}</button>`
    : "";
  const actions = site.linked
    ? `${power}<button class="btn ghost icon-btn sm" data-open="browser" title="Open in browser" aria-label="Open in browser">${icon("browser")}</button>
       <button class="btn ghost icon-btn sm" data-open="editor" title="Open in editor" aria-label="Open in editor">${icon("code")}</button>
       <button class="btn ghost icon-btn sm" data-open="folder" title="Open folder" aria-label="Open folder">${icon("folder")}</button>
       <button class="btn ghost icon-btn sm" data-open="terminal" title="Open terminal" aria-label="Open terminal">${icon("terminal")}</button>`
    : site.parked
      ? `<button class="btn ghost icon-btn sm" data-open="browser" title="Open in browser" aria-label="Open in browser">${icon("browser")}</button>
         <button class="btn sm" data-link-site>${icon("link")}${t("link", "Link")}</button>`
      : `<button class="btn sm" data-link-site>${icon("link")}${t("link", "Link")}</button>`;

  return `
    <div class="site-row ${selected} ${site.exists ? "" : "missing"}" data-site="${esc(site.name)}">
      ${avatar(site.name)}
      <div class="site-main">
        <div class="site-name">${esc(site.name)}</div>
        <div class="site-meta">
          ${site.linked || site.parked ? `<a class="link" data-open="browser">${esc(site.domain)}</a><span class="sep">·</span>` : ""}
          <span class="path" title="${esc(site.path)}">${esc(site.display_path)}</span>
        </div>
      </div>
      <div class="site-chips">${chips.join("")}</div>
      <div class="site-actions">${actions}</div>
    </div>`;
}

async function refreshSites(forceDrawer = false) {
  state.sites = await api("sites");
  state.loaded = true;
  renderSites();
  if (state.drawer.name) {
    if (state.sites.some((s) => s.name === state.drawer.name)) loadDrawer(forceDrawer);
    else closeDrawer();
  }
}

function siteByName(name) {
  return state.sites.find((s) => s.name === name);
}

function openOn(target, name) {
  api("open", { target, name });
}

/* ── site drawer ────────────────────────────────────────────────────────── */
function openDrawer(name, tab = null) {
  let initialTab = tab;
  if (!initialTab) {
    try {
      initialTab = localStorage.getItem(`ld_site_tab_${name}`);
    } catch {}
  }
  state.drawer = { name, tab: initialTab || "overview", details: null, currentKey: null };
  $("#site-drawer").classList.add("open");
  $("#site-drawer").setAttribute("aria-hidden", "false");
  renderSites();
  renderDrawer(true);
  loadDrawer(false);
}

async function tryCloseDrawer() {
  try {
    if (window.EnvEditor?.dirty()) {
      const ok = await confirmModal({ title: "Discard changes?", message: "You have unsaved environment variables.", confirm: "Discard", danger: true });
      if (!ok) return;
    }
  } catch (err) {
    console.error("Error checking dirty state:", err);
  }
  closeDrawer();
}

function closeDrawer() {
  stopResourceMonitor();
  state.drawer = { name: null, tab: "overview", details: null, currentKey: null };
  try { window.LaravelDev?.destroy(); } catch {}
  try { window.Servers?.closeSite?.(); } catch {}
  const drawer = $("#site-drawer");
  if (drawer) {
    drawer.classList.remove("open", "wide");
    drawer.setAttribute("aria-hidden", "true");
  }
  if (state.view === "sites") renderSites();
}

async function loadDrawer(force = false) {
  const name = state.drawer.name;
  if (!name || !siteByName(name)?.linked) return;
  try {
    const details = await LD.call("site", { name });
    if (state.drawer.name === name) {
      state.drawer.details = details;
      renderDrawer(force);
    }
  } catch { /* site disappeared mid-refresh */ }
}

let _resourceTimer = null;
let _currentRunawayPid = null;

function stopResourceMonitor() {
  if (_resourceTimer) {
    clearInterval(_resourceTimer);
    _resourceTimer = null;
  }
  _currentRunawayPid = null;
}

function startResourceMonitor(siteName) {
  stopResourceMonitor();
  async function poll() {
    if (state.drawer.name !== siteName) {
      stopResourceMonitor();
      return;
    }
    try {
      const res = await call("site_resources", { name: siteName });
      const cpuVal = $("#res-val-cpu");
      const ramVal = $("#res-val-ram");
      const cpuChip = $("#res-chip-cpu");
      const ramChip = $("#res-chip-ram");
      const runawayBanner = $("#runaway-alert-banner");
      const runawayPid = $("#runaway-pid");
      const runawayCpu = $("#runaway-cpu");

      if (cpuVal) cpuVal.textContent = `${res.cpu_percent || 0}%`;
      if (ramVal) ramVal.textContent = `${res.memory_mb || 0} MB`;

      if (cpuChip) {
        cpuChip.classList.toggle("warning", (res.cpu_percent || 0) >= 50 && (res.cpu_percent || 0) < 85);
        cpuChip.classList.toggle("danger", (res.cpu_percent || 0) >= 85);
      }
      if (ramChip) {
        ramChip.classList.toggle("warning", (res.memory_mb || 0) >= 500 && (res.memory_mb || 0) < 1000);
        ramChip.classList.toggle("danger", (res.memory_mb || 0) >= 1000);
      }

      if (runawayBanner) {
        if (res.runaway && res.runaway_process) {
          _currentRunawayPid = res.runaway_process.pid;
          if (runawayPid) runawayPid.textContent = `PID ${_currentRunawayPid}`;
          if (runawayCpu) runawayCpu.textContent = `${res.runaway_process.cpu}%`;
          runawayBanner.style.display = "flex";
        } else {
          runawayBanner.style.display = "none";
          _currentRunawayPid = null;
        }
      }
    } catch {
      // Ignore polling errors
    }
  }

  poll();
  _resourceTimer = setInterval(poll, 4000);

  const killBtn = $("#btn-kill-runaway");
  if (killBtn) {
    killBtn.onclick = async () => {
      if (!_currentRunawayPid) return;
      killBtn.disabled = true;
      try {
        await call("site_kill_process", { name: siteName, pid: _currentRunawayPid });
        toast("info", `Process ${_currentRunawayPid} terminated`);
        poll();
      } catch (err) {
        toast("error", "Failed to terminate process", err.message);
      } finally {
        killBtn.disabled = false;
      }
    };
  }
}

const _overviewCache = new Map();
const _overviewInflight = new Set();

function getOverviewCache(siteName) {
  if (!_overviewCache.has(siteName)) {
    _overviewCache.set(siteName, { artisanHtml: "", doctorHtml: "", auditHtml: "", aboutHtml: "" });
  }
  return _overviewCache.get(siteName);
}

function hydrateOverview(site) {
  if (site) refreshDebugBadge(site.name);
  if (!site || site.type !== "laravel") return;
  populateArtisanDatalist(site.name);
  loadDoctorDiagnostics(site.name);
  loadPackageAudit(site.name);
  loadFrameworkDiagnostics(site.name);
  loadTeamConfig(site.name);
  loadOctaneCard(site);
}

/** Starts a task and resolves with the finished task (runAction resolves at start). */
function runActionAndWait(action, params = {}, opts = {}) {
  return runAction(action, params, opts).then((task) => {
    if (!task) return null;
    const finished = (tk) => tk && (tk.status === "success" || tk.status === "error" || tk.status === "cancelled");
    if (finished(state.tasks.get(task.id))) return state.tasks.get(task.id);
    return new Promise((resolve) => {
      const onDone = (e) => {
        if (e.detail?.id !== task.id) return;
        window.removeEventListener("ld:task-done", onDone);
        resolve(e.detail);
      };
      window.addEventListener("ld:task-done", onDone);
    });
  });
}

/* ───────────────────────── Laravel Octane card ───────────────────────── */

function reloadOctaneCard(siteName) {
  const site = (state.sites || []).find((x) => x.name === siteName) || { name: siteName, type: "laravel" };
  loadOctaneCard(site);
}

async function loadOctaneCard(site) {
  const body = document.getElementById(`octane-body-${site.name}`);
  const chip = document.getElementById(`octane-chip-${site.name}`);
  if (!body) return;
  let st;
  try {
    st = await LD.call("octane_status", { name: site.name });
  } catch (err) {
    body.innerHTML = `<p class="muted sm" style="margin:0">${esc(err.message)}</p>`;
    return;
  }
  const req = st.requirements || {};
  const name = esc(site.name);

  if (chip) {
    chip.className = `chip ${st.enabled ? (st.running ? "ok" : "danger") : ""}`;
    chip.textContent = st.enabled
      ? `${st.running ? "● " : "○ "}Octane · ${st.server}`
      : "PHP-FPM";
  }

  if (st.enabled) {
    body.innerHTML = `
      <div class="status-panel ${st.running ? "ok" : "bad"}">
        <div class="status-panel-main">
          <div class="status-title">
            <span class="dot ${st.running ? "on" : "fail"}"></span>
            ${st.running
              ? t("octane_running", "Running")
              : t("octane_down", "Not responding — the site will return 502 until Octane is back")}
          </div>
          <dl class="kv">
            <dt>${t("octane_server", "Server")}</dt><dd class="mono">${esc(st.server)}</dd>
            <dt>${t("octane_upstream", "Upstream")}</dt><dd class="mono">127.0.0.1:${esc(st.port)}</dd>
            <dt>Workers</dt><dd class="mono">${esc(st.workers)}</dd>
            <dt>${t("octane_watch", "Watch")}</dt><dd>${st.watch ? t("on", "On") : t("off", "Off")}</dd>
          </dl>
          <div class="muted sm">${t("octane_memory_notice", "Notice: Octane persists application state in RAM between requests.")}</div>
        </div>
        <div class="btn-row" style="align-self:flex-start">
          ${st.running
            ? `<button type="button" class="btn sm" data-octane-op="reload" data-site="${name}" title="${esc(t("octane_reload_hint", "Gracefully reload workers after code changes"))}">${icon("refresh")}${t("octane_reload_btn", "Reload Workers")}</button>`
            : `<button type="button" class="btn sm primary" data-octane-op="restart" data-site="${name}">${icon("play")}${t("octane_restart_btn", "Restart")}</button>`}
          <button type="button" class="btn sm ghost" data-octane-log="${name}">${icon("file")}${t("octane_view_log", "Log")}</button>
          <button type="button" class="btn sm danger ghost" data-octane-op="disable" data-site="${name}">${t("octane_disable_btn", "Disable Octane")}</button>
        </div>
      </div>`;
    return;
  }

  const missing = [];
  if (!req.supervisor) missing.push(`<li>${t("octane_need_supervisor", "Supervisor is not installed — run")} <code>sudo apt install supervisor</code></li>`);
  body.innerHTML = `
    ${missing.length ? `<div class="notice warn"><b>${t("octane_requirements", "Requirements")}</b><ul>${missing.join("")}</ul></div>` : ""}
    <form class="octane-form" data-octane-enable-form>
      <input type="hidden" name="name" value="${name}">
      <fieldset class="seg-choice" aria-label="${esc(t("octane_server", "Server"))}">
        <label><input type="radio" name="server" value="frankenphp" checked><span><b>FrankenPHP</b><small>${t("octane_fp_desc", "Recommended · single binary, downloaded automatically")}</small></span></label>
        <label><input type="radio" name="server" value="roadrunner"><span><b>RoadRunner</b><small>${t("octane_rr_desc", "Go-based server, binary downloaded automatically")}</small></span></label>
        <label class="${req.swoole ? "" : "disabled"}"><input type="radio" name="server" value="swoole" ${req.swoole ? "" : "disabled"}><span><b>Swoole</b><small>${req.swoole ? t("octane_sw_desc", "PHP extension, fastest for long-running work") : t("octane_sw_missing", "Needs the swoole PHP extension")}</small></span></label>
      </fieldset>
      <div class="octane-options">
        <label class="field inline">
          <span>Workers</span>
          <select name="workers">
            <option value="auto">${t("octane_workers_auto", "Auto (CPU count)")}</option>
            <option value="1">1</option><option value="2">2</option><option value="4">4</option><option value="8">8</option>
          </select>
        </label>
        <label class="check" title="${esc(t("octane_watch_hint", "Reload workers when files change. Installs the chokidar npm package if needed."))}">
          <input type="checkbox" name="watch" ${req.node ? "" : "disabled"}>
          <span>${t("octane_watch_label", "Reload on file changes")}${req.node ? "" : ` <small class="muted">(${t("octane_needs_node", "needs Node.js")})</small>`}</span>
        </label>
        <button class="btn sm primary" type="submit" ${req.supervisor ? "" : "disabled"}>${icon("rocket")}${t("octane_enable_btn", "Enable Octane")}</button>
      </div>
      <p class="muted sm" style="margin:0">${t("octane_enable_note", "The site keeps running on PHP-FPM until Octane answers; if it fails to start, nothing is switched and the log is shown.")}</p>
    </form>`;
}

async function openOctaneLog(siteName) {
  const render = async (root) => {
    const pre = root.querySelector("#octane-log-pre");
    pre.textContent = t("loading", "Loading…");
    try {
      const res = await LD.call("octane_logs", { name: siteName, lines: 200 });
      pre.textContent = res.log || "(empty)";
      pre.scrollTop = pre.scrollHeight;
    } catch (err) {
      pre.textContent = err.message;
    }
  };
  openModal(`
    <div class="modal" style="max-width:820px;width:100%">
      <div class="modal-header">
        <h2>${icon("file")} Octane log · ${esc(siteName)}</h2>
        <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
      </div>
      <div class="modal-body"><pre id="octane-log-pre" class="log-pre"></pre></div>
      <div class="modal-footer">
        <button type="button" class="btn" id="octane-log-refresh">${icon("refresh")}${t("refresh", "Refresh")}</button>
        <button type="button" class="btn primary" data-dismiss>${t("close", "Close")}</button>
      </div>
    </div>`, (root) => {
    render(root);
    root.querySelector("#octane-log-refresh").addEventListener("click", () => render(root));
  });
}

/* ───────────────────────── Debug session ───────────────────────── */

const DEBUG_LAUNCH_JSON = JSON.stringify({
  version: "0.2.0",
  configurations: [{ name: "Listen for Xdebug (Laravel Dev)", type: "php", request: "launch", port: 9003 }],
}, null, 2);

function fmtRemaining(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}:${String(s).padStart(2, "0")}`;
}

async function refreshDebugBadge(siteName) {
  const btn = document.getElementById(`qa-debug-${siteName}`);
  if (!btn) return;
  try {
    const st = await LD.call("debug_session_status", { name: siteName });
    const label = btn.querySelector("span");
    btn.classList.toggle("armed", !!st.armed);
    if (label) label.textContent = st.armed ? `${t("debugging", "Debugging")} · ${Math.ceil(st.remaining_seconds / 60)}m` : t("debug_session", "Debug");
  } catch (_) { /* badge is best-effort */ }
}

function openDebugSessionModal(siteName) {
  let st = null;
  let timer = null;
  let busy = false;

  const check = (ok, label, hint = "", pending = false) => `
    <li class="check-row ${ok ? "ok" : pending ? "todo" : "bad"}">
      <span class="check-icon">${ok ? icon("check") : pending ? icon("wrench") : icon("x")}</span>
      <span><b>${label}</b>${hint ? `<small>${hint}</small>` : ""}</span>
    </li>`;

  const render = (root) => {
    const body = root.querySelector("#dbg-body");
    const foot = root.querySelector("#dbg-foot");
    if (!st) return;
    const c = st.checks || {};
    if (!st.supported) {
      body.innerHTML = `<div class="notice warn">${t("debug_octane", "This site runs on Laravel Octane (no PHP-FPM). Disable Octane to step-debug its requests, or use “Debug an artisan command” below.")}</div>`;
      foot.innerHTML = `<button type="button" class="btn" data-dismiss>${t("close", "Close")}</button>`;
      return;
    }
    const setupNote = t("debug_auto_setup", "set up automatically when you start (asks for your password once)");
    body.innerHTML = `
      <div class="debug-hero ${st.armed ? "armed" : ""}">
        <div class="debug-hero-icon">${icon("bug")}</div>
        <div>
          <div class="debug-hero-title">${st.armed
            ? `${t("debug_active", "Debug session active")} · <span class="mono" id="dbg-remaining">${fmtRemaining(st.remaining_seconds)}</span>`
            : t("debug_inactive", "Debug session is off")}</div>
          <div class="muted sm">${t("debug_explain", "While on, every PHP request to")} <b class="mono">${esc(st.domain)}</b> ${t("debug_explain2", "(and its subdomains) stops at your breakpoints — page loads, API calls from your frontend on any origin, Postman/curl and webhooks. No cookie or browser extension needed.")}</div>
        </div>
      </div>

      <ul class="check-list">
        ${check(c.xdebug_installed, `${t("debug_chk_xdebug", "Xdebug installed")} · PHP ${esc(st.php || "?")}`, c.xdebug_installed ? esc(st.xdebug_mode || "") : setupNote, !c.xdebug_installed)}
        ${c.xdebug_installed ? check(c.xdebug_debug_mode, t("debug_chk_mode", "Step debugging enabled (xdebug.mode=debug)"), c.xdebug_debug_mode ? "" : setupNote, !c.xdebug_debug_mode) : ""}
        ${check(c.vhost_hook && c.flag_dir, t("debug_chk_hook", "Site hook installed"), c.vhost_hook && c.flag_dir ? "" : setupNote, !(c.vhost_hook && c.flag_dir))}
        ${check(c.ide_listening, `${t("debug_chk_ide", "IDE listening on port")} ${st.ide_port}`,
          c.ide_listening ? "" : t("debug_ide_hint", "VS Code: install “PHP Debug”, then Run → Start Debugging with the config below. PhpStorm: click “Start Listening for PHP Debug Connections”."))}
      </ul>

      ${c.ide_listening ? "" : `
        <details class="mini-details">
          <summary>${t("debug_vscode_cfg", "VS Code launch.json")}</summary>
          <div class="muted sm" style="margin-bottom:8px">${t("debug_launch_where", "VS Code reads launch.json from the folder you have open — it must be in this site's project, then press F5 (Run → Start Debugging).")}</div>
          <div class="inline-row" style="margin:0 0 10px">
            <button type="button" class="btn sm primary" id="dbg-write-launch">${icon("file")}${t("debug_write_launch", "Add to this project's .vscode/launch.json")}</button>
            <button type="button" class="btn sm ghost" data-open="editor" data-site="${esc(siteName)}">${icon("code")}${t("debug_open_editor", "Open project in editor")}</button>
          </div>
          <div id="dbg-launch-result"></div>
          <div style="position:relative">
            <pre class="code-pre">${esc(DEBUG_LAUNCH_JSON)}</pre>
            <button type="button" class="btn xs ghost" style="position:absolute;top:6px;right:6px" data-copy="${esc(DEBUG_LAUNCH_JSON)}">${icon("copy")}${t("copy", "Copy")}</button>
          </div>
        </details>`}

      <details class="mini-details">
        <summary>${t("debug_more", "More ways to debug")}</summary>
        <div class="debug-more">
          <div>
            <b>${t("debug_artisan", "Debug an artisan command")}</b>
            <div class="inline-row">
              <input class="input sm mono" id="dbg-artisan" placeholder="test --filter=UserTest" autocomplete="off">
              <button type="button" class="btn sm" id="dbg-artisan-run" ${c.xdebug_installed ? "" : "disabled"}>${icon("terminal")}${t("run", "Run")}</button>
            </div>
          </div>
          <div>
            <b>${t("debug_one_request", "Debug one browser request only")}</b>
            <div class="muted sm">${t("debug_one_request_hint", "Opens the site with ?XDEBUG_TRIGGER — only that page load is debugged.")}</div>
            <button type="button" class="btn sm ghost" style="margin-top:6px" data-open-url="${esc(`http://${st.domain}/?XDEBUG_TRIGGER=LARAVEL_DEV`)}" ${c.xdebug_debug_mode ? "" : "disabled"}>${icon("browser")}${t("open", "Open")}</button>
          </div>
        </div>
      </details>`;

    foot.innerHTML = st.armed ? `
        <button type="button" class="btn" id="dbg-extend">${icon("clock")}+30 min</button>
        <button type="button" class="btn danger" id="dbg-stop">${icon("stop")}${t("debug_stop", "Stop debugging")}</button>` : `
        <label class="field inline">
          <span>${t("debug_duration", "For")}</span>
          <select id="dbg-minutes">
            <option value="15">15 min</option><option value="30" selected>30 min</option>
            <option value="60">1 h</option><option value="120">2 h</option>
          </select>
        </label>
        <button type="button" class="btn primary" id="dbg-start">${icon("bug")}${st.ready ? t("debug_start", "Start debugging") : t("debug_setup_start", "Set up & start")}</button>`;

    const act = async (params) => {
      if (busy) return;
      busy = true;
      foot.querySelectorAll("button").forEach((b) => { b.disabled = true; });
      const task = await runActionAndWait("debug-session", { name: siteName, ...params }, { show: !st.ready });
      busy = false;
      if (task?.status === "success" && params.op === "on" && !(st.checks || {}).ide_listening) {
        toast("warn", t("debug_no_ide", "Debug session on — start your IDE listener"), `${t("debug_chk_ide", "IDE listening on port")} ${st.ide_port}`);
      }
      await refresh(root);
    };
    foot.querySelector("#dbg-start")?.addEventListener("click", () => act({ op: "on", minutes: root.querySelector("#dbg-minutes").value }));
    foot.querySelector("#dbg-stop")?.addEventListener("click", () => act({ op: "off" }));
    foot.querySelector("#dbg-extend")?.addEventListener("click", () => act({ op: "on", minutes: Math.min(480, Math.ceil(st.remaining_seconds / 60) + 30) }));
    body.querySelector("#dbg-write-launch")?.addEventListener("click", async (e) => {
      const out = body.querySelector("#dbg-launch-result");
      e.currentTarget.disabled = true;
      try {
        const r = await LD.call("debug_write_launch_json", { name: siteName });
        out.innerHTML = `<p class="sm" style="margin:0 0 10px;color:${r.ok ? "var(--green)" : "var(--red)"}">${r.ok ? "✓" : "✗"} ${esc(r.message || r.error || "")} <span class="mono muted">${esc(r.path || "")}</span></p>`;
      } catch (err) {
        out.innerHTML = `<p class="sm" style="margin:0 0 10px;color:var(--red)">${esc(err.message)}</p>`;
      }
      e.currentTarget.disabled = false;
    });
    body.querySelector("#dbg-artisan-run")?.addEventListener("click", () => {
      const args = body.querySelector("#dbg-artisan").value.trim();
      if (args) runAction("debug-artisan", { name: siteName, args });
    });
  };

  const refresh = async (root) => {
    try {
      st = await LD.call("debug_session_status", { name: siteName });
    } catch (err) {
      root.querySelector("#dbg-body").innerHTML = `<p class="muted">${esc(err.message)}</p>`;
      return;
    }
    if (!busy) render(root);
    refreshDebugBadge(siteName);
  };

  openModal(`
    <div class="modal debug-modal" style="max-width:640px;width:100%">
      <div class="modal-header">
        <h2>${icon("bug")} ${t("debug_title", "Debug session")} · ${esc(siteName)}</h2>
        <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
      </div>
      <div class="modal-body" id="dbg-body"><p class="muted">${t("loading", "Loading…")}</p></div>
      <div class="modal-footer" id="dbg-foot"></div>
    </div>`, (root) => {
    refresh(root);
    let ticks = 0;
    timer = setInterval(() => {
      if (!document.body.contains(root)) { clearInterval(timer); return; }
      ticks += 1;
      if (st?.armed) {
        st.remaining_seconds = Math.max(0, st.remaining_seconds - 1);
        const el = root.querySelector("#dbg-remaining");
        if (el) el.textContent = fmtRemaining(st.remaining_seconds);
      }
      // Re-check the IDE listener / expiry every 4 s while the dialog is open.
      if (ticks % 4 === 0 || (st?.armed && st.remaining_seconds === 0)) refresh(root);
    }, 1000);
  });
}

async function loadTeamConfig(siteName) {
  const card = document.getElementById(`team-config-card-${siteName}`);
  const content = document.getElementById(`team-config-content-${siteName}`);
  if (!card || !content) return;
  try {
    const res = await LD.call("team_config_status", { name: siteName });
    if (!res || !res.has_config) {
      card.style.display = "block";
      content.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
          <div>
            <b>${t("team_config", "Team Config (herd.yml)")}</b>
            <div class="muted sm">No herd.yml found. Standardize environment settings for your team.</div>
          </div>
          <button type="button" class="btn sm" data-team-export="${esc(siteName)}">${icon("download")}${t("team_export", "Export herd.yml")}</button>
        </div>
      `;
      content.querySelector("[data-team-export]")?.addEventListener("click", () => {
        runAction("team-export", { name: siteName, filename: "herd.yml" });
      });
      return;
    }

    card.style.display = "block";
    if (res.matches) {
      content.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
          <div style="display:flex;align-items:center;gap:8px">
            <span class="dot on"></span>
            <div>
              <b>${t("team_config", "Team Config")}: <code>${esc(res.file)}</code></b>
              <div class="muted sm" style="color:var(--green)">Environment perfectly matches team requirements (PHP ${esc(res.required?.php || "")}, Node ${esc(res.required?.node || "")})</div>
            </div>
          </div>
          <button type="button" class="btn sm ghost" data-team-export="${esc(siteName)}">${icon("refresh")}${t("team_export", "Re-export")}</button>
        </div>
      `;
      content.querySelector("[data-team-export]")?.addEventListener("click", () => {
        runAction("team-export", { name: siteName, filename: "herd.yml" });
      });
    } else {
      const diffs = res.differences || [];
      const diffItems = diffs.map((d) => `<div style="font-size:12px;margin-top:2px">• <b>${esc(d.component)}:</b> required <code>${esc(d.required)}</code>, currently <code>${esc(d.current)}</code></div>`).join("");
      content.innerHTML = `
        <div style="background:rgba(245, 158, 11, 0.08);border:1px solid rgba(245, 158, 11, 0.25);border-radius:8px;padding:12px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px">
            <div style="display:flex;align-items:center;gap:8px">
              <span class="dot warn" style="background:var(--amber)"></span>
              <b style="color:var(--text)">Team Config Mismatch (<code>${esc(res.file)}</code>)</b>
            </div>
            <button type="button" class="btn sm primary" data-team-apply="${esc(siteName)}">${icon("zap")}${t("team_sync", "Sync Environment")}</button>
          </div>
          <div class="muted sm" style="margin-bottom:6px">Your local environment diverges from project specifications:</div>
          ${diffItems}
        </div>
      `;
      content.querySelector("[data-team-apply]")?.addEventListener("click", () => {
        runAction("team-apply", { name: siteName });
      });
    }
  } catch (err) {
    // Non-blocking
  }
}

function renderDrawer(force = false) {
  const name = state.drawer.name;
  const site = state.drawer.details || siteByName(name);
  const el = $("#site-drawer");
  if (!site) return;

  const key = `${site.name}:${state.drawer.tab}`;
  if (!force && state.drawer.currentKey === key) {
    if (state.drawer.tab === "overview") {
      const pane = $("#drawer-tab", el);
      if (pane) {
        pane.innerHTML = isApp(site) ? appOverviewTab(site) : overviewTab(site);
        hydrateOverview(site);
      }
    } else {
      window.LaravelDev?.update?.(site);
    }
    return;
  }

  state.drawer.currentKey = key;
  window.LaravelDev?.destroy();

  const backLabel = window.t ? window.t("back_to_sites", "Back to Projects") : "Back to Projects";
  const header = `
    <div class="drawer-header site-page-header">
      <button class="back-to-sites-btn" id="drawer-btn-back" data-close-drawer title="${esc(backLabel)} (Esc)">
        ${icon("back")}
        <span>${esc(backLabel)}</span>
      </button>
      <div class="site-header-divider"></div>
      ${avatar(site.name, "md")}
      <div class="site-header-info">
        <div class="site-header-title-row">
          <h2>${esc(site.name)}</h2>
          <span class="chip sm ${site.linked ? 'ok' : 'warn'}">${esc(site.type_label || site.type || 'Laravel')}</span>
          ${site.php ? `<span class="chip sm php">PHP ${esc(site.php)}</span>` : ''}
          ${site.branch ? `<span class="chip sm muted">${icon("git")}${esc(site.branch)}</span>` : ''}
        </div>
        <div class="site-header-sub">
          ${site.linked ? `<a class="link" data-open="browser" title="Open in browser">${esc(site.url)}</a>` : `<span class="muted">Not linked</span>`}
          <span class="site-path-hint" title="${esc(site.path)}">${esc(site.display_path || site.path)}</span>
        </div>
      </div>
      <div class="site-header-actions">
        <div id="site-resource-gauges" class="site-resource-gauges" title="Project Resource Usage">
          <span class="resource-chip cpu" id="res-chip-cpu" title="Total CPU %">
            <span class="res-dot"></span><span id="res-val-cpu">0.0%</span>
          </span>
          <span class="resource-chip ram" id="res-chip-ram" title="Memory RSS">
            <span id="res-val-ram">0.0 MB</span>
          </span>
        </div>
        <button class="btn ghost icon-btn sm close" data-close-drawer title="Close (Esc)" aria-label="Close">${icon("x")}</button>
      </div>
    </div>
    <div id="runaway-alert-banner" class="runaway-alert-banner" style="display:none">
      <div style="display:flex;align-items:center;gap:8px">
        ${icon("alert")}
        <span><b>Runaway Process Alert:</b> Process <code id="runaway-pid" style="font-family:var(--mono)">...</code> is consuming <b id="runaway-cpu">...</b> CPU.</span>
      </div>
      <button id="btn-kill-runaway" class="btn sm danger solid">${icon("trash")} Terminate Process</button>
    </div>`;

  if (!site.linked) {
    el.innerHTML = `${header}
      <div class="drawer-body">
        <div class="card">
          <h3>${icon("link")}Link this project</h3>
          <p class="muted" style="margin-top:0">${managed()
            ? `This project lives in your www folder but isn't served yet. Linking sets up Nginx and a <b>${esc(site.domain)}</b> domain${site.type === "laravel" ? ", a database and the <code>.env</code> file" : ""}.`
            : "This project lives in your www folder but isn't linked yet. Linking gives it its own localhost port and a Start button."}</p>
          <button class="btn primary" data-link-site>${icon("link")}Link ${esc(site.name)}</button>
        </div>
      </div>`;
    return;
  }

  // Site details are now a full workspace page. Keep requests & queries (perf)
  // prominent right after overview for live debugging.
  const primaryTabs = ["overview", "perf", "models", "routes", "logs", "env"];
  if (site.type === "laravel") primaryTabs.push("packages", "tinker", "queue", "cache", "vite", "media", "mail", "dumps", "trans", "tests", "checkpoints", "deploy");
  else primaryTabs.push("packages", "vite", "media");
  if (site.git) primaryTabs.push("git");
  const allTabs = primaryTabs;

  if (!allTabs.includes(state.drawer.tab)) state.drawer.tab = "overview";
  const tabLabels = {
    overview: window.t ? window.t("overview", "Overview") : "Overview",
    perf: window.t ? window.t("requests_and_queries", "Requests & Queries") : "Requests & Queries",
    models: window.t ? window.t("models", "Models") : "Models",
    routes: window.t ? window.t("routes", "Routes") : "Routes",
    env: window.t ? window.t("env", "Environment") : "Environment",
    logs: window.t ? window.t("logs", "Logs") : "Logs",
    packages: window.t ? window.t("packages", "Packages") : "Packages",
    tinker: window.t ? window.t("tinker", "Tinker") : "Tinker",
    queue: window.t ? window.t("queue", "Queues & Cron") : "Queues & Cron",
    cache: window.t ? window.t("cache", "Cache & Redis") : "Cache & Redis",
    vite: window.t ? window.t("vite", "Vite & Assets") : "Vite & Assets",
    media: window.t ? window.t("media", "Storage Gallery") : "Storage Gallery",
    mail: window.t ? window.t("mail", "Mail") : "Mail",
    trans: window.t ? window.t("trans", "Translations") : "Translations",
    dumps: window.t ? window.t("dumps", "Dumps") : "Dumps",
    tests: window.t ? window.t("tests", "Tests") : "Tests",
    checkpoints: window.t ? window.t("checkpoints", "Time Machine") : "Time Machine",
    deploy: window.t ? window.t("deploy", "Deploy") : "Deploy",
    git: window.t ? window.t("git", "Git") : "Git"
  };

  // 18 tabs in one row was too much to scan; they are grouped by what you're doing.
  const groups = [
    { id: "overview", label: "Overview", icon: "home", tabs: ["overview"] },
    { id: "debug", label: "Debug", icon: "pulse", tabs: ["perf", "logs", "dumps", "mail", "tests"] },
    { id: "code", label: "Code", icon: "code", tabs: ["models", "routes", "tinker", "trans", "packages"] },
    { id: "runtime", label: "Runtime", icon: "layers", tabs: ["env", "queue", "cache", "vite", "media"] },
    { id: "ship", label: "Ship", icon: "rocket", tabs: ["git", "checkpoints", "deploy"] },
  ].map((g) => ({ ...g, tabs: g.tabs.filter((t) => allTabs.includes(t)) })).filter((g) => g.tabs.length);
  const activeGroup = groups.find((g) => g.tabs.includes(state.drawer.tab)) || groups[0];
  state.drawer.groupTab = state.drawer.groupTab || {};
  state.drawer.groupTab[activeGroup.id] = state.drawer.tab;

  el.innerHTML = `${header}
    <div class="drawer-body">
      <div class="quick-actions">
        <button class="quick-action" data-open="browser">${icon("browser")}Browser</button>
        <button class="quick-action" data-open="editor">${icon("code")}Editor</button>
        <button class="quick-action" data-open="folder">${icon("folder")}Folder</button>
        <button class="quick-action" data-open="terminal">${icon("terminal")}Terminal</button>
        <button class="quick-action" data-open-db="${esc(site.name)}">${icon("database")}Database</button>
        ${!["django", "nuxt", "next", "node", "vite"].includes(site.type) ? `<button class="quick-action" data-debug-session="${esc(site.name)}" id="qa-debug-${esc(site.name)}" title="${esc(t("debug_session_hint", "Step-debug every request to this site with Xdebug — including API calls from your frontend"))}">${icon("bug")}<span>${t("debug_session", "Debug")}</span></button>` : ""}
      </div>
      <div class="tab-groups" role="tablist" aria-label="Site sections">
        ${groups.map((g) => {
          const active = g === activeGroup;
          // A section button reopens the tab last used in it.
          const target = active ? state.drawer.tab : (state.drawer.groupTab[g.id] || g.tabs[0]);
          return `<button class="tab-group ${active ? "active" : ""}" role="tab" aria-selected="${active}" data-tab="${target}">${icon(g.icon)}<span>${g.label}</span>${g.tabs.length > 1 ? `<span class="tab-group-count">${g.tabs.length}</span>` : ""}</button>`;
        }).join("")}
      </div>
      ${activeGroup.tabs.length > 1 ? `
      <div class="tabs" role="tablist" aria-label="${esc(activeGroup.label)} tabs">
        ${activeGroup.tabs.map((t) => `<button class="tab ${t === state.drawer.tab ? "active" : ""}" role="tab" aria-selected="${t === state.drawer.tab}" data-tab="${t}">${tabLabels[t] || t}</button>`).join("")}
      </div>` : `<div class="tabs-spacer"></div>`}
      <div id="drawer-tab"></div>
    </div>`;

  el.classList.toggle("wide", true);
  const pane = $("#drawer-tab", el);
  if (state.drawer.tab === "overview") {
    pane.innerHTML = isApp(site) ? appOverviewTab(site) : overviewTab(site);
    hydrateOverview(site);
  }
  if (state.drawer.tab === "git") {
    pane.innerHTML = gitTab(site);
    loadGitTabDetails(site.name);
  }
  if (state.drawer.tab === "env") {
    EnvEditor.mount(pane, { name: site.name }, {
      afterSave: (saved) => {
        const actions = [];
        if (site.type === "laravel" && saved.config_cached) actions.push({ label: "Clear config cache", run: () => runAction("artisan", { name: site.name, args: "config:clear" }, { show: false }) });
        if (runsServer(site) && site.running) actions.push({ label: "Restart server", run: () => LD.call("app_restart", { name: site.name }).then(() => toast("success", `${site.name} restarted`)).catch((err) => toast("error", "Couldn't restart", err.message)) });
        if (site.worker) actions.push({ label: "Restart queue worker", run: () => runAction("worker", { name: site.name, op: "restart" }, { show: false }) });
        return actions;
      },
    });
  }
  if (state.drawer.tab === "tinker") {
    LaravelDev.mountTinker(pane, site);
  }
  if (state.drawer.tab === "logs") {
    LaravelDev.mountLogs(pane, site);
  }
  if (state.drawer.tab === "queue") {
    LaravelDev.mountQueue(pane, site);
  }
  if (state.drawer.tab === "deploy") {
    LaravelDev.mountDeploy(pane, site);
  }
  if (state.drawer.tab === "models") {
    LaravelDev.mountModels(pane, site);
  }
  if (state.drawer.tab === "routes") {
    LaravelDev.mountRoutes(pane, site);
  }
  if (state.drawer.tab === "trans") {
    LaravelDev.mountTranslations(pane, site);
  }
  if (state.drawer.tab === "dumps") {
    LaravelDev.mountDumps(pane, site);
  }
  if (state.drawer.tab === "tests") {
    LaravelDev.mountTests(site, pane);
  }
  if (state.drawer.tab === "checkpoints") {
    LaravelDev.mountCheckpoints(pane, site);
  }
  if (state.drawer.tab === "cache") {
    LaravelDev.mountCache(pane, site);
  }
  if (state.drawer.tab === "vite") {
    LaravelDev.mountVite(pane, site);
  }
  if (state.drawer.tab === "media") {
    LaravelDev.mountMedia(pane, site);
  }
  if (state.drawer.tab === "perf") {
    LaravelDev.mountPerf(pane, site);
  }
  if (state.drawer.tab === "packages") {
    LaravelDev.mountPackages(pane, site);
  }
  if (state.drawer.tab === "mail") {
    LaravelDev.mountMail(pane, site);
  }
  startResourceMonitor(site.name);
}

async function populateArtisanDatalist(siteName, force = false) {
  const cache = getOverviewCache(siteName);
  const dl = document.getElementById(`artisan-cmd-list-${siteName}`);
  if (!force && cache.artisanHtml) {
    if (dl && !dl.children.length) dl.innerHTML = cache.artisanHtml;
    return;
  }
  const flightKey = `artisan:${siteName}`;
  if (!force && _overviewInflight.has(flightKey)) return;
  _overviewInflight.add(flightKey);
  try {
    const cmds = await LD.call("artisan_commands", { name: siteName });
    if (cmds && cmds.length) {
      const html = cmds.map((c) => `<option value="${esc(c.name)}">${esc(c.description || "")}</option>`).join("");
      cache.artisanHtml = html;
      const liveDl = document.getElementById(`artisan-cmd-list-${siteName}`);
      if (liveDl) liveDl.innerHTML = html;
    }
  } catch (err) {
    // Non-blocking
  } finally {
    _overviewInflight.delete(flightKey);
  }
}

async function loadDoctorDiagnostics(siteName, force = false) {
  const cache = getOverviewCache(siteName);
  const initialEl = document.getElementById(`doctor-results-${siteName}`);
  if (!force && cache.doctorHtml) {
    if (initialEl) initialEl.innerHTML = cache.doctorHtml;
    return;
  }
  const flightKey = `doctor:${siteName}`;
  if (!force && _overviewInflight.has(flightKey)) return;
  _overviewInflight.add(flightKey);

  if (initialEl && (force || !cache.doctorHtml)) {
    initialEl.innerHTML = `<p class="muted sm" style="margin:0"><span class="dot on"></span> Running diagnostics…</p>`;
  }
  try {
    const checks = await LD.call("site_doctor", { name: siteName });
    let html = "";
    if (!checks || !checks.length) {
      html = `<p class="muted sm">No diagnostics available.</p>`;
    } else {
      const issues = checks.filter((c) => c.status !== "ok");
      const healHeader = issues.length > 0 ? `
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:8px;border-bottom:1px solid var(--border);flex-wrap:wrap;gap:8px">
          <span class="chip sm warn" style="font-weight:600">${issues.length} issue(s) detected</span>
          <button type="button" class="btn sm primary" data-auto-heal="${esc(siteName)}">${icon("zap")} Auto-Heal Project</button>
        </div>
      ` : "";

      html = healHeader + checks.map((c) => {
        const dotCls = c.status === "ok" ? "on" : (c.status === "warn" ? "warn" : "fail");
        const dotStyle = c.status === "warn" ? 'style="background:var(--amber)"' : '';
        const fixBtn = c.fix_label ? `<button type="button" class="btn sm primary" data-doctor-fix="${esc(c.id)}" data-site="${esc(siteName)}" data-fix-action="${esc(c.fix_action || 'artisan')}" data-args="${esc(c.fix_params?.args || '')}" data-cmd="${esc(c.fix_params?.cmd || '')}">${esc(c.fix_label)}</button>` : "";
        const aiBtn = c.status !== "ok" ? `<button type="button" class="btn sm ghost" data-ai-doctor-fix="${esc(siteName)}" data-check-name="${esc(c.name)}" data-check-msg="${esc(c.message)}" title="Ask AI for solution">${icon("sparkles")} ${t("ai_fix", "Ask AI")}</button>` : "";
        return `
          <div class="doctor-row" style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:6px 0;border-top:1px solid var(--border)">
            <div style="display:flex;align-items:center;gap:8px;min-width:0">
              <span class="dot ${dotCls}" ${dotStyle}></span>
              <div>
                <b style="font-size:12.5px">${esc(c.name)}</b>
                <div class="muted sm">${esc(c.message)}</div>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:6px">
              ${fixBtn}
              ${aiBtn}
            </div>
          </div>
        `;
      }).join("");
    }
    cache.doctorHtml = html;
    const liveEl = document.getElementById(`doctor-results-${siteName}`);
    if (liveEl) liveEl.innerHTML = html;
  } catch (err) {
    const errHtml = `<p style="color:var(--red);margin:0">Failed to run health check: ${esc(err.message)}</p>`;
    const liveEl = document.getElementById(`doctor-results-${siteName}`);
    if (liveEl) liveEl.innerHTML = errHtml;
  } finally {
    _overviewInflight.delete(flightKey);
  }
}

async function loadPackageAudit(siteName, force = false) {
  const cache = getOverviewCache(siteName);
  const initialEl = document.getElementById(`package-audit-results-${siteName}`);
  if (!force && cache.auditHtml) {
    if (initialEl) initialEl.innerHTML = cache.auditHtml;
    return;
  }
  const flightKey = `audit:${siteName}`;
  if (!force && _overviewInflight.has(flightKey)) return;
  _overviewInflight.add(flightKey);

  if (initialEl && (force || !cache.auditHtml)) {
    initialEl.innerHTML = `<p class="muted sm" style="margin:0"><span class="dot on"></span> Auditing packages…</p>`;
  }
  try {
    const res = await LD.call("package_audit", { name: siteName, force });
    const totalAdv = (res.composer_advisories?.length || 0) + (res.npm_vulnerabilities || 0);
    const outdated = res.composer_outdated || [];

    let html = "";
    if (totalAdv === 0 && outdated.length === 0) {
      html = `
        <div style="display:flex;align-items:center;gap:8px;color:var(--green)">
          <span class="dot on"></span>
          <span>All packages are secure and up to date.</span>
        </div>
      `;
    } else {
      if (totalAdv > 0) {
        html += `
          <div style="padding:10px 12px;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:6px;margin-bottom:10px">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
              <b style="color:var(--red);font-size:13px">${icon("alert")}${totalAdv} Security Vulnerabilit${totalAdv === 1 ? "y" : "ies"} Found</b>
              ${res.npm_vulnerabilities > 0 ? `<button type="button" class="btn sm" data-run-npm-fix="${esc(siteName)}">npm audit fix</button>` : ""}
            </div>
            <div style="margin-top:6px;display:flex;flex-direction:column;gap:4px">
              ${(res.composer_advisories || []).map((a) => `
                <div style="font-size:12px">
                  <b>${esc(a.package)}</b>: ${esc(a.title)} ${a.cve ? `<span class="chip sm" style="font-size:10px">${esc(a.cve)}</span>` : ""}
                  ${a.link ? `<a href="${esc(a.link)}" target="_blank" rel="noopener" class="link" style="margin-left:4px">View</a>` : ""}
                </div>
              `).join("")}
              ${res.npm_vulnerabilities > 0 ? `
                <div style="font-size:12px;color:var(--muted)">${res.npm_vulnerabilities} npm package vulnerabilit${res.npm_vulnerabilities === 1 ? "y" : "ies"}.</div>
              ` : ""}
            </div>
          </div>
        `;
      }

      if (outdated.length > 0) {
        html += `
          <div style="padding:10px 12px;background:var(--surface-2);border:1px solid var(--border);border-radius:6px">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px">
              <span style="font-size:13px;font-weight:600">${outdated.length} Outdated Package${outdated.length === 1 ? "" : "s"}</span>
              <button type="button" class="btn sm primary" data-composer-update="${esc(siteName)}">${icon("download")}composer update</button>
            </div>
            <div style="display:flex;flex-direction:column;gap:4px;max-height:160px;overflow-y:auto">
              ${outdated.map((o) => `
                <div style="display:flex;align-items:center;justify-content:space-between;font-size:12px;padding:3px 0;border-bottom:1px solid var(--border)">
                  <span><b>${esc(o.name)}</b> <span class="muted">${esc(o.version)}</span></span>
                  <span class="chip sm" style="color:var(--accent);font-family:var(--mono)">→ ${esc(o.latest)}</span>
                </div>
              `).join("")}
            </div>
          </div>
        `;
      }
    }

    cache.auditHtml = html;
    const liveEl = document.getElementById(`package-audit-results-${siteName}`);
    if (liveEl) liveEl.innerHTML = html;
  } catch (err) {
    const liveEl = document.getElementById(`package-audit-results-${siteName}`);
    if (liveEl) liveEl.innerHTML = `<p style="color:var(--red);margin:0">Failed to audit packages: ${esc(err.message)}</p>`;
  } finally {
    _overviewInflight.delete(flightKey);
  }
}

async function loadFrameworkDiagnostics(siteName, force = false) {
  const cache = getOverviewCache(siteName);
  const initialEl = document.getElementById(`laravel-about-content-${siteName}`);
  if (!force && cache.aboutHtml) {
    if (initialEl) initialEl.innerHTML = cache.aboutHtml;
    return;
  }
  const flightKey = `about:${siteName}`;
  if (!force && _overviewInflight.has(flightKey)) return;
  _overviewInflight.add(flightKey);

  try {
    const res = await LD.call("about_info", { name: siteName });
    let html = "";
    if (!res.ok) {
      html = `<p class="muted sm" style="margin:0">Diagnostics unavailable (${esc(res.error || "artisan about failed")})</p>`;
    } else {
      const ab = res.about || {};
      const envSection = ab.environment || ab.Environment || {};
      const drivers = ab.drivers || ab.Drivers || {};

      const lv = envSection["Laravel Version"] || envSection["laravel_version"] || "10+";
      const pv = envSection["PHP Version"] || envSection["php_version"] || "8.x";
      const appEnv = envSection["App Environment"] || envSection["app_env"] || "local";
      const debug = envSection["App Debug"] !== undefined ? envSection["App Debug"] : true;
      const cacheD = drivers["Cache"] || drivers["cache"] || "file";
      const dbD = drivers["Database"] || drivers["database"] || "mysql";
      const queueD = drivers["Queue"] || drivers["queue"] || "sync";

      html = `
        <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(130px, 1fr));gap:8px;font-size:12px">
          <div style="background:var(--surface-2);padding:8px 10px;border-radius:6px">
            <span class="muted xs" style="display:block">Laravel</span>
            <b style="font-family:var(--mono)">v${esc(String(lv))}</b>
          </div>
          <div style="background:var(--surface-2);padding:8px 10px;border-radius:6px">
            <span class="muted xs" style="display:block">PHP</span>
            <b style="font-family:var(--mono)">v${esc(String(pv))}</b>
          </div>
          <div style="background:var(--surface-2);padding:8px 10px;border-radius:6px">
            <span class="muted xs" style="display:block">Environment</span>
            <b>${esc(String(appEnv))} ${debug ? '<span class="chip xs" style="color:var(--amber)">debug</span>' : ''}</b>
          </div>
          <div style="background:var(--surface-2);padding:8px 10px;border-radius:6px">
            <span class="muted xs" style="display:block">Database</span>
            <b>${esc(String(dbD))}</b>
          </div>
          <div style="background:var(--surface-2);padding:8px 10px;border-radius:6px">
            <span class="muted xs" style="display:block">Queue Driver</span>
            <b>${esc(String(queueD))}</b>
          </div>
          <div style="background:var(--surface-2);padding:8px 10px;border-radius:6px">
            <span class="muted xs" style="display:block">Cache</span>
            <b>${esc(String(cacheD))}</b>
          </div>
        </div>
      `;
    }
    cache.aboutHtml = html;
    const liveEl = document.getElementById(`laravel-about-content-${siteName}`);
    if (liveEl) liveEl.innerHTML = html;
  } catch (err) {
    const liveEl = document.getElementById(`laravel-about-content-${siteName}`);
    if (liveEl) liveEl.innerHTML = `<p class="muted sm" style="margin:0">${esc(err.message)}</p>`;
  } finally {
    _overviewInflight.delete(flightKey);
  }
}

async function openEventsModal(siteName) {
  openModal({
    title: "Registered Events & Listeners",
    content: `<div id="events-modal-content" style="min-height:220px"><div class="loading-pane">${icon("pulse")} Loading events…</div></div>`,
    actions: [{ label: "Close", primary: true, run: () => {} }],
  });
  try {
    const res = await LD.call("events_list", { name: siteName });
    const mContent = document.getElementById("events-modal-content");
    if (!mContent) return;
    if (!res.ok) throw new Error(res.error || "Failed to load events");
    const evs = res.events || [];
    let items = [];
    if (Array.isArray(evs)) {
      items = evs;
    } else if (typeof evs === "object") {
      for (const [k, v] of Object.entries(evs)) {
        items.push({ event: k, listeners: Array.isArray(v) ? v : [v] });
      }
    }
    if (!items.length) {
      mContent.innerHTML = `<div class="muted sm" style="padding:20px;text-align:center">No registered application events discovered.</div>`;
      return;
    }
    mContent.innerHTML = `
      <div style="max-height:65vh;overflow-y:auto">
        <table class="routes-table" style="font-size:12px">
          <thead><tr><th>Event</th><th>Listener(s)</th></tr></thead>
          <tbody>
            ${items.map((it) => `
              <tr>
                <td><b style="font-family:var(--mono);font-size:11.5px">${esc(it.event || it.name || "Event")}</b></td>
                <td><span class="muted" style="font-family:var(--mono);font-size:11.5px">${esc(Array.isArray(it.listeners) ? it.listeners.join(", ") : String(it.listeners || "—"))}</span></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    const mContent = document.getElementById("events-modal-content");
    if (mContent) mContent.innerHTML = `<div style="padding:16px;color:var(--red)">${esc(err.message)}</div>`;
  }
}

function openConfigInspectorModal(siteName) {
  openModal({
    title: "Config Inspector",
    content: `
      <div style="display:flex;flex-direction:column;gap:10px">
        <div style="display:flex;gap:8px;align-items:center">
          <select id="config-inspector-select" class="select sm" style="width:180px;font-family:var(--mono)">
            <option value="app">config/app.php</option>
            <option value="database">config/database.php</option>
            <option value="auth">config/auth.php</option>
            <option value="cache">config/cache.php</option>
            <option value="queue">config/queue.php</option>
            <option value="mail">config/mail.php</option>
            <option value="services">config/services.php</option>
            <option value="session">config/session.php</option>
          </select>
          <button type="button" class="btn sm" id="btn-config-inspect-load">${icon("refresh")} Load</button>
        </div>
        <pre id="config-inspector-output" class="terminal" style="max-height:420px;overflow:auto;padding:12px;font-size:12px">Select config file and click Load</pre>
      </div>
    `,
    actions: [{ label: "Close", primary: true, run: () => {} }],
  });

  async function loadCfg() {
    const sel = document.getElementById("config-inspector-select");
    const out = document.getElementById("config-inspector-output");
    if (!sel || !out) return;
    out.textContent = "Loading configuration…";
    try {
      const res = await LD.call("config_show", { name: siteName, config: sel.value });
      if (res.config) {
        out.textContent = JSON.stringify(res.config, null, 2);
      } else if (res.raw) {
        out.textContent = res.raw;
      } else {
        out.textContent = res.error || "No config output.";
      }
    } catch (err) {
      out.textContent = `Error: ${err.message}`;
    }
  }
  document.getElementById("btn-config-inspect-load")?.addEventListener("click", loadCfg);
  document.getElementById("config-inspector-select")?.addEventListener("change", loadCfg);
  loadCfg();
}

async function openUpgradeAssistantModal(siteName) {
  openModal({
    title: "Laravel Upgrade Assistant",
    content: `<div id="upgrade-modal-content" style="min-height:180px"><div class="loading-pane">${icon("pulse")} Analyzing packages for compatibility…</div></div>`,
    actions: [{ label: "Close", primary: true, run: () => {} }],
  });
  try {
    const res = await LD.call("upgrade_check", { name: siteName });
    const mContent = document.getElementById("upgrade-modal-content");
    if (!mContent) return;
    if (!res.ok) throw new Error(res.error || "Upgrade check failed");

    mContent.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:var(--surface-2);border-radius:8px">
          <div>
            <div class="muted sm">Current Version: <b style="color:var(--text)">${esc(res.current_version)}</b></div>
            <div class="muted sm" style="margin-top:2px">Next Major Target: <b style="color:var(--accent)">${esc(res.target_version)}</b></div>
          </div>
          <button type="button" data-open-url="${esc(res.upgrade_guide_url)}" class="btn sm primary">${icon("browser")} Official Upgrade Guide</button>
        </div>

        ${res.blockers && res.blockers.length ? `
          <div>
            <b style="color:var(--red);font-size:13px">${icon("alert")} ${res.blockers.length} Blocking Dependency Conflicts:</b>
            <div class="card" style="margin-top:6px;max-height:220px;overflow-y:auto;background:var(--surface-1);padding:10px">
              ${res.blockers.map((b) => `<div style="font-family:var(--mono);font-size:11.5px;padding:3px 0;color:var(--text)">${esc(b)}</div>`).join("")}
            </div>
          </div>
        ` : `
          <div class="card" style="padding:14px;color:var(--green);display:flex;align-items:center;gap:8px">
            ${icon("check")} No obvious composer blockers detected for ${esc(res.target_version)}. You can prepare for upgrade!
          </div>
        `}
      </div>
    `;
  } catch (err) {
    const mContent = document.getElementById("upgrade-modal-content");
    if (mContent) mContent.innerHTML = `<div style="padding:16px;color:var(--red)">${esc(err.message)}</div>`;
  }
}

function npmCard(site) {
  const d = state.drawer.details || site || {};
  const loading = !state.drawer.details;
  const pm = d.npm_pm || d.package_manager || "npm";
  const hasPkg = Boolean(d.has_package_json || (d.npm_scripts && Object.keys(d.npm_scripts).length));
  const scriptsObj = d.npm_scripts || d.scripts || {};
  const scriptNames = Object.keys(scriptsObj);
  const titleLabel = window.t ? window.t("npm_commands", "NPM & Frontend Assets") : "NPM & Frontend Assets";

  const suggestions = [
    ...scriptNames.map((s) => ({ val: `run ${s}`, desc: scriptsObj[s] || "" })),
    ...(scriptsObj.build ? [] : [{ val: "run build", desc: "Build frontend assets" }]),
    ...(scriptsObj.dev ? [] : [{ val: "run dev", desc: "Start frontend dev watcher" }]),
    { val: "install", desc: "Install dependencies from package.json" },
    { val: "ci", desc: "Clean install from lockfile" },
    { val: "update", desc: "Update packages" },
    { val: "audit fix", desc: "Fix vulnerable dependencies" },
    { val: "outdated", desc: "Check outdated packages" },
  ];

  const statusChip = loading
    ? `<span class="chip sm muted">Checking…</span>`
    : hasPkg
      ? `<span class="chip sm ${d.node_modules_installed ? "ok" : "warn"}">${d.node_modules_installed ? "node_modules ready" : "node_modules missing"}</span>`
      : `<span class="chip sm muted">No package.json</span>`;

  return `
    <div class="card" id="npm-commands-card-${esc(site.name)}">
      <h3>${icon("terminal")}${esc(titleLabel)}
        <span class="right" style="display:flex;align-items:center;gap:6px">
          ${statusChip}
          <span class="chip sm mono">${esc(pm)}</span>
        </span>
      </h3>
      ${!loading && !hasPkg ? `
        <p class="muted sm" style="margin:0 0 10px">No <code>package.json</code> found yet. Initialize Node packages or run custom ${esc(pm)} commands below.</p>
        <div class="btn-row">
          <button type="button" class="btn sm" data-npm="init -y">${esc(pm)} init -y</button>
        </div>
      ` : `
        <div class="btn-row">
          <button type="button" class="btn sm" data-npm="install">${esc(pm)} install</button>
          <button type="button" class="btn sm primary" data-npm="run build" title="${esc(scriptsObj.build || "Build production assets")}">${icon("zap")}${esc(pm)} run build</button>
          ${scriptNames.filter((s) => s !== "build").map((s) => `
            <button type="button" class="btn sm" data-npm="run ${esc(s)}" title="${esc(scriptsObj[s])}">${esc(pm)} run ${esc(s)}</button>
          `).join("")}
          <button type="button" class="btn sm" data-npm="update">${esc(pm)} update</button>
        </div>
      `}
      <form class="artisan-input" data-npm-form>
        <span class="prefix">${esc(pm)}</span>
        <input name="args" list="npm-cmd-list-${esc(site.name)}" aria-label="${esc(pm)} command" placeholder="run build, run dev, install axios, audit fix…" spellcheck="false" autocorrect="off" autocapitalize="off">
        <datalist id="npm-cmd-list-${esc(site.name)}">
          ${suggestions.map((it) => `<option value="${esc(it.val)}">${esc(it.desc)}</option>`).join("")}
        </datalist>
        <button class="btn sm" type="submit">Run</button>
      </form>
      <form class="artisan-input" data-terminal-exec-form style="margin-top:8px">
        <span class="prefix">terminal $</span>
        <input name="command" aria-label="Terminal command" placeholder="Run any bash command: git status, php artisan route:list, npm run build, ls -la…" spellcheck="false" autocorrect="off" autocapitalize="off">
        <button class="btn sm" type="submit">Run</button>
      </form>
    </div>`;
}

function renderTunnelCard(site) {
  const tunnel = site.tunnel || {};
  const active = Boolean(tunnel.active);
  const url = tunnel.url || "";
  const qrSvg = (window.QRCode && url) ? window.QRCode.generateSVG(url, 140) : "";

  if (active) {
    return `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:8px">
        <div style="display:flex;align-items:center;gap:8px">
          <span class="dot on"></span>
          <b>${window.t ? window.t("tunnel_active", "Tunnel Active") : "Tunnel Active"}</b>
          <span class="chip sm" style="font-family:var(--mono)">${esc(tunnel.mode || "quick")}</span>
          ${tunnel.pid ? `<span class="chip sm" style="color:var(--muted)">PID ${esc(tunnel.pid)}</span>` : ""}
        </div>
        <div style="display:flex;gap:6px">
          <button type="button" class="btn sm danger" data-tunnel="stop" data-name="${esc(site.name)}">${icon("stop")}${window.t ? window.t("stop_tunnel", "Stop Tunnel") : "Stop Tunnel"}</button>
          <button type="button" class="btn sm" data-tunnel="restart" data-name="${esc(site.name)}">${icon("refresh")}${window.t ? window.t("restart_tunnel", "Restart") : "Restart"}</button>
          <button type="button" class="btn sm ghost" data-tunnel-log-toggle="${esc(site.name)}">${icon("terminal")}${window.t ? window.t("tunnel_logs", "Logs") : "Logs"}</button>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <input type="text" class="input sm" readonly value="${esc(url)}" style="flex:1;font-family:var(--mono)">
        <button type="button" class="btn sm" data-copy="${esc(url)}">${icon("copy")}Copy</button>
        <button type="button" class="btn sm ghost" data-open-url="${esc(url)}">${icon("browser")}Open</button>
        <button type="button" class="btn sm ghost" data-tunnel-qr-toggle="${esc(site.name)}">${icon("qrcode")}QR</button>
      </div>
      <div id="tunnel-qr-${esc(site.name)}" style="display:none;background:#fff;padding:12px;border-radius:8px;margin-bottom:10px;text-align:center">
        ${qrSvg}
        <div style="font-size:11px;color:#333;margin-top:6px">Scan with your smartphone camera to access this project live over HTTPS</div>
      </div>
      <div id="tunnel-log-box-${esc(site.name)}" style="display:none;margin-top:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
          <small class="muted">Live cloudflared logs</small>
          <button type="button" class="btn xs ghost" data-tunnel-log-refresh="${esc(site.name)}">${icon("refresh")}Refresh</button>
        </div>
        <pre class="terminal" id="tunnel-log-content-${esc(site.name)}" style="max-height:160px;overflow:auto;font-size:11px;padding:8px;margin:0"></pre>
      </div>
    `;
  }

  return `
    <p class="muted sm" style="margin:0 0 10px">Expose this site securely to the internet with Cloudflare Tunnel (HTTPS) for client previews, mobile testing, or webhooks.</p>
    <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:12px">
      <div style="display:flex;gap:16px;font-size:12px;flex-wrap:wrap">
        <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
          <input type="radio" name="tunnel-mode-${esc(site.name)}" value="quick" checked>
          <span><b>Quick Tunnel</b> (Free trycloudflare.com · No account required)</span>
        </label>
        <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
          <input type="radio" name="tunnel-mode-${esc(site.name)}" value="token" ${tunnel.has_token ? "checked" : ""}>
          <span><b>Custom Domain</b> (Cloudflare Zero Trust Token)</span>
        </label>
      </div>
      <div id="tunnel-token-wrap-${esc(site.name)}" style="${tunnel.has_token ? "" : "display:none"}">
        <input type="password" class="input sm" id="tunnel-token-input-${esc(site.name)}" placeholder="Paste Cloudflare Tunnel Token (eyJh...)" value="${esc(tunnel.token || "")}" style="width:100%">
        <small class="muted" style="display:block;margin-top:4px">From Cloudflare Zero Trust Dashboard &gt; Access &gt; Tunnels</small>
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button type="button" class="btn sm primary" data-start-custom-tunnel="${esc(site.name)}">${icon("zap")}${window.t ? window.t("start_tunnel", "Start Cloudflare Tunnel") : "Start Cloudflare Tunnel"}</button>
      <button type="button" class="btn sm ghost" data-tunnel-log-toggle="${esc(site.name)}">${icon("terminal")}${window.t ? window.t("tunnel_logs", "Past Logs") : "Past Logs"}</button>
    </div>
    <div id="tunnel-log-box-${esc(site.name)}" style="display:none;margin-top:10px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <small class="muted">Recent cloudflared logs</small>
        <button type="button" class="btn xs ghost" data-tunnel-log-refresh="${esc(site.name)}">${icon("refresh")}Refresh</button>
      </div>
      <pre class="terminal" id="tunnel-log-content-${esc(site.name)}" style="max-height:160px;overflow:auto;font-size:11px;padding:8px;margin:0"></pre>
    </div>
  `;
}

function overviewTab(site) {
  const loading = !state.drawer.details;
  const ovCache = getOverviewCache(site.name);
  const worker = loading
    ? `<span class="muted">Checking…</span>`
    : !site.worker_configured
      ? `<p class="muted" style="margin:0 0 10px">No queue worker yet. Laravel Dev can keep <code>queue:work</code> running with Supervisor.</p>
         <button type="button" class="btn sm" data-action="worker-setup">${icon("layers")}Set up worker</button>`
      : `<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
           <span class="dot ${site.worker ? "on" : "off"}"></span>${site.worker ? "Running" : "Stopped"}
           ${site.worker_settings?.effective_mode === "horizon" ? `<span class="chip sm">Horizon</span>` : ""}
         </div>
         <div class="btn-row">
           ${site.worker
             ? `<button type="button" class="btn sm" data-worker="restart">${icon("refresh")}Restart</button>
                <button type="button" class="btn sm" data-worker="stop">${icon("stop")}Stop</button>`
             : `<button type="button" class="btn sm" data-worker="start">${icon("play")}Start</button>`}
         </div>`;

  const sch = site.scheduler || {};
  const scheduler = loading
    ? `<span class="muted">Checking…</span>`
    : `<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
         <span class="dot ${sch.enabled && sch.service === "active" ? "on" : "off"}"></span>
         ${sch.enabled ? (sch.service === "active" ? "Runs every minute" : `Enabled, but cron is ${esc(sch.service || "not running")}`) : "Off: scheduled tasks don't run on their own"}
       </div>
       <div class="btn-row">
         ${sch.enabled
           ? `<button type="button" class="btn sm" data-cron="disable">${icon("stop")}Disable</button>`
           : `<button type="button" class="btn sm" data-cron="enable">${icon("play")}Enable cron</button>`}
         <button type="button" class="btn sm ghost" data-tab="queue">Tasks &amp; output</button>
       </div>`;

  const reverb = loading
    ? `<span class="muted">Checking…</span>`
    : !site.reverb?.installed
      ? `<p class="muted" style="margin:0 0 10px">Reverb is not installed in this project.</p>`
      : `<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:6px">
           <div style="display:flex;align-items:center;gap:8px">
             <span class="dot ${site.reverb.running ? "on" : "off"}"></span>
             <b>${site.reverb.running ? "Running" : "Stopped"}</b>
             <span class="chip sm" style="font-family:var(--mono)">${esc(site.reverb.url)}</span>
             ${site.reverb.pid ? `<span class="chip sm" style="color:var(--muted)">PID ${site.reverb.pid}</span>` : ""}
           </div>
         </div>
         <div class="btn-row">
           ${site.reverb.running
             ? `<button type="button" class="btn sm" data-reverb="restart">${icon("refresh")}Restart</button>
                <button type="button" class="btn sm danger" data-reverb="stop">${icon("stop")}Stop</button>`
             : `<button type="button" class="btn sm primary" data-reverb="start">${icon("play")}Start</button>`}
         </div>`;

  return `
    ${runsServer(site) ? serverCard(site) : ""}
    <div class="card">
      <dl class="info">
        <dt>${managed() ? "Domain" : "Local"}</dt><dd style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><a class="link text" data-open="browser">${esc(site.domain)}</a> <button type="button" class="btn sm ghost" data-manage-domains="${esc(site.name)}" style="margin-left:auto">${icon("globe")}Domains</button> <button type="button" class="btn sm ghost" data-share-site="${esc(site.name)}">${icon("share")}Share</button></dd>
        ${site.aliases && site.aliases.length > 0 ? `<dt>Aliases</dt><dd class="text muted" style="font-size:12px;font-family:var(--mono)">${site.aliases.map(a => `<a class="link" data-open="browser" data-custom-url="http://${esc(a)}">${esc(a)}</a>`).join(", ")}</dd>` : ""}
        <dt>Path</dt><dd><span class="text selectable" title="${esc(site.path)}">${esc(site.display_path)}</span>
          <button type="button" class="btn ghost icon-btn sm" data-copy="${esc(site.path)}" title="Copy path">${icon("copy")}</button></dd>
        ${managed() ? `<dt>PHP</dt><dd style="display:flex;align-items:center;gap:8px">
          <form class="inline-form" data-php-form>
            <select name="php" title="${t("php_isolate_tip", "Switch this site's PHP-FPM socket and environment")}">${phpOptions(site.php || defaultPhp())}</select>
            <button class="btn sm" type="submit">${t("save", "Apply")}</button>
          </form>
          ${site.php && site.php !== defaultPhp() ? `<button type="button" class="btn sm ghost" data-php-unisolate="${esc(site.name)}" title="${t("php_reset_default", "Reset to default PHP")}">${icon("refresh")}</button>` : ""}
        </dd>` : `<dt>PHP</dt><dd>${esc(state.phpVersions[0] || "not found on PATH")}</dd>`}
        ${site.node_version ? `<dt>Node.js</dt><dd><span class="chip">v${esc(site.node_version)}</span></dd>` : ""}
        ${site.laravel ? `<dt>Laravel</dt><dd>${esc(site.laravel)}</dd>` : ""}
        ${site.branch ? `<dt>Branch</dt><dd>${icon("branch")}${esc(site.branch)}</dd>` : ""}
      </dl>
    </div>

    ${site.type === "laravel" ? `
    <div class="card" id="team-config-card-${esc(site.name)}" style="display:none">
      <div id="team-config-content-${esc(site.name)}"></div>
    </div>` : ""}

    ${site.type === "laravel" && managed() ? `
    <div class="card octane-card" id="octane-card-${esc(site.name)}">
      <div class="card-head">
        <div>
          <h3 style="margin:0;display:flex;align-items:center;gap:8px">${icon("activity")}${t("octane_title", "Laravel Octane")}</h3>
          <div class="muted sm" style="margin-top:2px">${t("octane_desc", "Supercharge your application performance with FrankenPHP, RoadRunner, or Swoole")}</div>
        </div>
        <span class="chip" id="octane-chip-${esc(site.name)}" style="margin:0">${site.runtime === "octane" ? "Octane" : "PHP-FPM"}</span>
      </div>
      <div id="octane-body-${esc(site.name)}"><p class="muted sm" style="margin:0">${t("loading", "Loading…")}</p></div>
    </div>` : ""}

    <div class="card">
      <h3>${icon("terminal")}Artisan &amp; Composer</h3>
      <div class="btn-row">
        <button type="button" class="btn sm" data-artisan="migrate">migrate</button>
        <button type="button" class="btn sm" data-artisan="migrate:fresh --seed" data-confirm="This drops every table in the database.">migrate:fresh --seed</button>
        <button type="button" class="btn sm" data-artisan="optimize:clear">optimize:clear</button>
        <button type="button" class="btn sm" data-artisan="storage:link">storage:link</button>
        <button type="button" class="btn sm" data-composer="install">composer install</button>
        <button type="button" class="btn sm" data-composer="update">composer update</button>
        <button type="button" class="btn sm" data-composer="dump-autoload">composer dump-autoload</button>
      </div>
      <form class="artisan-input" data-artisan-form>
        <span class="prefix">php artisan</span>
        <input name="args" list="artisan-cmd-list-${esc(site.name)}" aria-label="Artisan command" placeholder="make:model Post -m, route:list…" spellcheck="false" autocorrect="off" autocapitalize="off">
        <datalist id="artisan-cmd-list-${esc(site.name)}">${ovCache.artisanHtml || ""}</datalist>
        <button class="btn sm" type="submit">Run</button>
      </form>
      <form class="artisan-input" data-composer-form style="margin-top:8px">
        <span class="prefix">composer</span>
        <input name="args" list="composer-cmd-list-${esc(site.name)}" aria-label="Composer command" placeholder="update, require spatie/laravel-permission, dump-autoload…" spellcheck="false" autocorrect="off" autocapitalize="off">
        <datalist id="composer-cmd-list-${esc(site.name)}">
          <option value="update">Update dependencies to latest allowed versions</option>
          <option value="install">Install dependencies from composer.lock</option>
          <option value="dump-autoload">Regenerate Composer autoloader files</option>
          <option value="outdated --direct">Show outdated direct dependencies</option>
          <option value="audit">Scan dependencies for security advisories</option>
          <option value="diagnose">Diagnose Composer environment issues</option>
        </datalist>
        <button class="btn sm" type="submit">Run</button>
      </form>
      <form class="artisan-input" data-terminal-exec-form style="margin-top:8px">
        <span class="prefix">terminal $</span>
        <input name="command" aria-label="Terminal command" placeholder="Run any bash command: git status, php artisan route:list, npm run build, ls -la…" spellcheck="false" autocorrect="off" autocapitalize="off">
        <button class="btn sm" type="submit">Run</button>
      </form>
    </div>

    ${npmCard(site)}

    <div class="card" id="doctor-card" data-site="${esc(site.name)}">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <h3 style="margin:0">${icon("pulse")}Health & Diagnostics (Doctor)</h3>
        <button type="button" class="btn sm ghost" data-doctor-refresh="${esc(site.name)}" title="Re-run health check">${icon("refresh")}Check</button>
      </div>
      <div id="doctor-results-${esc(site.name)}" class="doctor-results">
        ${ovCache.doctorHtml || `<p class="muted sm" style="margin:0">Scanning project health…</p>`}
      </div>
    </div>

    <div class="card" id="package-audit-card-${esc(site.name)}">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <h3 style="margin:0">${icon("layers")}Packages &amp; Security</h3>
        <button type="button" class="btn sm ghost" data-audit-refresh="${esc(site.name)}" title="Re-scan package security and updates">${icon("refresh")}Audit</button>
      </div>
      <div id="package-audit-results-${esc(site.name)}" class="package-audit-results">
        ${ovCache.auditHtml || `<p class="muted sm" style="margin:0">Checking package dependencies…</p>`}
      </div>
    </div>

    ${managed() ? `<div class="card">
      <h3>${icon("layers")}Queue worker</h3>
      ${worker}
    </div>

    <div class="card">
      <h3>${icon("pulse")}Scheduler (cron)</h3>
      ${scheduler}
    </div>

    <div class="card">
      <h3>${icon("zap")}Reverb WebSocket</h3>
      ${reverb}
    </div>` : ""}

    <div class="card" id="tunnel-card-${esc(site.name)}">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
        <h3 style="margin:0">${icon("cloud")}${window.t ? window.t("cloudflare_tunnel", "Cloudflare Tunnel (Public URL)") : "Cloudflare Tunnel (Public URL)"}</h3>
        <button type="button" class="btn sm ghost" data-share-site="${esc(site.name)}" title="Share &amp; QR">${icon("share")}Share &amp; QR</button>
      </div>
      ${renderTunnelCard(site)}
    </div>

    ${(site.dev_tools?.horizon || site.dev_tools?.telescope || site.dev_tools?.pulse) ? `
    <div class="card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <h3 style="margin:0">${icon("browser")}Developer Dashboards</h3>
      </div>
      <p class="muted sm" style="margin:0 0 10px">Quick access to web dashboards for installed Laravel packages:</p>
      <div class="btn-row">
        ${site.dev_tools?.horizon ? `<button type="button" class="btn sm" data-open-url="${esc(site.url)}/horizon">${icon("layers")}Horizon</button>` : ""}
        ${site.dev_tools?.telescope ? `<button type="button" class="btn sm" data-open-url="${esc(site.url)}/telescope">${icon("search")}Telescope</button>` : ""}
        ${site.dev_tools?.pulse ? `<button type="button" class="btn sm" data-open-url="${esc(site.url)}/pulse">${icon("pulse")}Pulse</button>` : ""}
      </div>
    </div>` : ""}

    ${site.type === "laravel" ? `
    <div class="card" id="laravel-about-card-${esc(site.name)}">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:8px">
        <h3 style="margin:0">${icon("zap")}Framework Diagnostics &amp; Tools</h3>
        <div style="display:flex;gap:6px">
          <button type="button" class="btn sm ghost" data-open-events-modal="${esc(site.name)}">${icon("pulse")} Events</button>
          <button type="button" class="btn sm ghost" data-open-config-modal="${esc(site.name)}">${icon("file")} Config</button>
          <button type="button" class="btn sm ghost" data-open-upgrade-modal="${esc(site.name)}">${icon("arrow-up")} Upgrade Check</button>
        </div>
      </div>
      <div id="laravel-about-content-${esc(site.name)}">
        ${ovCache.aboutHtml || `<div class="loading-pane sm">${icon("pulse")} Inspecting environment…</div>`}
      </div>
    </div>` : ""}

    <div class="card danger-zone">
      <h3>${icon("wrench")}Maintenance</h3>
      ${managed() ? `<div class="row-item"><div><b>Repair</b><small>Rewrite Nginx config, fix permissions and .env.</small></div>
        <button type="button" class="btn sm" data-action="repair">${icon("wrench")}Repair</button></div>
      <div class="row-item"><div><b>HTTPS</b><small>${site.ssl ? "Trusted local certificate is active. Re-issue it if the browser complains." : "Issue a trusted local certificate and serve on https://."}</small></div>
        <button type="button" class="btn sm" data-action="secure">${icon("lock")}${site.ssl ? "Renew" : "Secure"}</button></div>
      <div class="row-item"><div><b>Diagnose</b><small>Check folder, Nginx, hosts entry and HTTP response.</small></div>
        <button type="button" class="btn sm" data-action="diagnose">${icon("pulse")}Diagnose</button></div>` : ""}
      <div class="row-item"><div><b>Unlink</b><small>Stop serving it. Files and database stay.</small></div>
        <button type="button" class="btn sm danger" data-action="unlink">${icon("unlink")}Unlink</button></div>
      <div class="row-item"><div><b>Delete</b><small>${managed() ? "Removes the folder, database and config." : "Removes the folder."} Cannot be undone.</small></div>
        <button type="button" class="btn sm danger" data-action="delete">${icon("trash")}Delete</button></div>
    </div>`;
}

function serverCard(site) {
  const d = state.drawer.details || {};
  const django = site.type === "django";
  const depsMissing = d.has_deps && !d.deps_installed;
  const placeholders = `<code>{port}</code> = ${esc(site.port)}${django ? ", <code>{py}</code> = project python" : ""}${site.type === "laravel" ? ", <code>{php}</code> = PHP" : ""}`;
  return `
    <div class="card">
      <h3>${icon("play")}Server <span class="right">${site.running
        ? `<span class="chip ok"><span class="dot on"></span>Running on :${esc(site.port)}</span>`
        : `<span class="chip">Stopped</span>`}</span></h3>
      ${depsMissing ? `<div class="notice">${icon("alert")}<span>Dependencies aren't installed yet.</span>
        <button type="button" class="btn sm primary" data-app-run="app-install">${django ? "pip install" : `${esc(d.package_manager || "npm")} install`}</button></div>` : ""}
      <div class="btn-row">
        ${site.running
          ? `<button type="button" class="btn sm" data-app="restart">${icon("refresh")}Restart</button>
             <button type="button" class="btn sm" data-app="stop">${icon("stop")}Stop</button>
             <button type="button" class="btn sm" data-tab="logs">${icon("pulse")}Output</button>`
          : `<button type="button" class="btn sm primary" data-app="start">${icon("play")}Start</button>`}
      </div>
      <form class="app-config" data-app-config>
        ${site.type === "laravel" ? `<input type="hidden" name="mode" value="dev">` : `
        <label class="field"><span>Mode</span>
          <select name="mode">
            <option value="dev" ${site.mode === "dev" ? "selected" : ""}>Development (hot reload)</option>
            <option value="prod" ${site.mode === "prod" ? "selected" : ""}>Production preview</option>
          </select>
        </label>`}
        <label class="field"><span>Command <small>· ${placeholders}</small></span>
          <input name="command" value="${esc(site.command)}" spellcheck="false" class="mono">
        </label>
        <div class="btn-row"><button class="btn sm" type="submit">Save</button>
          ${site.custom_command ? `<button class="btn sm ghost" type="button" data-app-reset>Reset to default</button>` : ""}</div>
      </form>
    </div>`;
}

function appOverviewTab(site) {
  const d = state.drawer.details || {};
  const django = site.type === "django";
  const pm = d.package_manager || d.npm_pm || "npm";
  const scripts = Object.keys(d.scripts || {}).filter((n) => !["dev", "start", "preview"].includes(n));
  return `
    ${serverCard(site)}

    <div class="card">
      <dl class="info">
        ${managed() ? `<dt>Domain</dt><dd style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><a class="link text" data-open="browser">${esc(site.domain)}</a> <button type="button" class="btn sm ghost" data-manage-domains="${esc(site.name)}" style="margin-left:auto">${icon("globe")}Domains</button></dd>` : ""}
        <dt>Local</dt><dd style="display:flex;align-items:center;gap:8px"><a class="link text mono" data-open="browser">localhost:${esc(site.port)}</a> <button type="button" class="btn sm ghost" data-share-site="${esc(site.name)}" style="margin-left:auto">${icon("share")}Share</button></dd>
        <dt>Path</dt><dd><span class="text selectable" title="${esc(site.path)}">${esc(site.display_path)}</span>
          <button type="button" class="btn ghost icon-btn sm" data-copy="${esc(site.path)}" title="Copy path">${icon("copy")}</button></dd>
        <dt>Type</dt><dd>${typeChip(site)}</dd>
        ${django && d.python ? `<dt>Python</dt><dd><span class="text mono" title="${esc(d.python)}">${esc(d.python.replace(state.home, "~"))}</span></dd>` : ""}
        ${site.branch ? `<dt>Branch</dt><dd>${icon("branch")}${esc(site.branch)}</dd>` : ""}
      </dl>
    </div>

    ${site.type === "laravel" ? `
    <div class="card" id="team-config-card-${esc(site.name)}" style="display:none">
      <div id="team-config-content-${esc(site.name)}"></div>
    </div>` : ""}

    <div class="card">
      ${django ? `
        <h3>${icon("terminal")}manage.py</h3>
        <div class="btn-row">
          <button type="button" class="btn sm" data-manage="migrate">migrate</button>
          <button type="button" class="btn sm" data-manage="makemigrations">makemigrations</button>
          <button type="button" class="btn sm" data-manage="collectstatic --noinput">collectstatic</button>
          <button type="button" class="btn sm" data-manage="check">check</button>
          <button type="button" class="btn sm" data-app-run="app-install">pip install -r requirements.txt</button>
        </div>
        <form class="artisan-input" data-manage-form>
          <span class="prefix">python manage.py</span>
          <input name="args" aria-label="Django manage.py command" placeholder="startapp blog" spellcheck="false" autocorrect="off" autocapitalize="off">
          <button class="btn sm" type="submit">Run</button>
        </form>` : `
        <h3>${icon("terminal")}Scripts <span class="right muted">${esc(pm)}</span></h3>
        <div class="btn-row">
          <button type="button" class="btn sm" data-app-run="app-install">${esc(pm)} install</button>
          <button type="button" class="btn sm primary" data-npm="run build">${icon("zap")}${esc(pm)} run build</button>
          ${scripts.filter((n) => n !== "build").map((n) => `<button type="button" class="btn sm" data-script="${esc(n)}" title="${esc((d.scripts || {})[n])}">${esc(n)}</button>`).join("")}
        </div>
        <form class="artisan-input" data-npm-form>
          <span class="prefix">${esc(pm)}</span>
          <input name="args" aria-label="${esc(pm)} command" placeholder="run build, install axios, audit fix…" spellcheck="false" autocorrect="off" autocapitalize="off">
          <button class="btn sm" type="submit">Run</button>
        </form>`}
    </div>

    ${django ? npmCard(site) : ""}

    <div class="card" id="tunnel-card-${esc(site.name)}">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
        <h3 style="margin:0">${icon("cloud")}${window.t ? window.t("cloudflare_tunnel", "Cloudflare Tunnel (Public URL)") : "Cloudflare Tunnel (Public URL)"}</h3>
        <button type="button" class="btn sm ghost" data-share-site="${esc(site.name)}" title="Share &amp; QR">${icon("share")}Share &amp; QR</button>
      </div>
      ${renderTunnelCard(site)}
    </div>

    <div class="card danger-zone">
      <h3>${icon("wrench")}Maintenance</h3>
      ${managed() ? `<div class="row-item"><div><b>Repair</b><small>Rewrite the nginx proxy and the .test domain.</small></div>
        <button type="button" class="btn sm" data-action="repair">${icon("wrench")}Repair</button></div>
      <div class="row-item"><div><b>HTTPS</b><small>${site.ssl ? "Trusted local certificate is active. Re-issue it if the browser complains." : "Issue a trusted local certificate and serve on https://."}</small></div>
        <button type="button" class="btn sm" data-action="secure">${icon("lock")}${site.ssl ? "Renew" : "Secure"}</button></div>` : ""}
      <div class="row-item"><div><b>Unlink</b><small>Stop serving it. Files stay.</small></div>
        <button type="button" class="btn sm danger" data-action="unlink">${icon("unlink")}Unlink</button></div>
      <div class="row-item"><div><b>Delete</b><small>Removes the folder and config. Cannot be undone.</small></div>
        <button type="button" class="btn sm danger" data-action="delete">${icon("trash")}Delete</button></div>
    </div>`;
}

function gitTab(site) {
  const g = site.git || {};
  const sync = !g.upstream
    ? `<span class="chip">No upstream</span>`
    : g.ahead || g.behind
      ? `${g.behind ? `<span class="chip warn">${icon("download")}${g.behind} behind</span>` : ""}${g.ahead ? `<span class="chip php">${icon("upload")}${g.ahead} ahead</span>` : ""}`
      : `<span class="chip ok">${icon("check")}Up to date</span>`;

  return `
    <div id="git-details-${site.name}">
      <div class="card">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:12px">
          <div style="display:flex;align-items:center;gap:8px">
            <span class="muted sm" style="font-weight:600">Branch:</span>
            <select id="git-branch-select-${site.name}" class="input sm" style="max-width:220px;height:28px;padding:2px 8px">
              <option value="${esc(g.branch || "")}">${esc(g.branch || "Loading…")}</option>
            </select>
            <button class="btn sm" id="git-branch-switch-${site.name}">${icon("branch")}Switch</button>
            <button class="btn sm ghost" id="git-branch-new-${site.name}">+ New</button>
          </div>
          <div style="display:flex;align-items:center;gap:6px">
            ${sync}
          </div>
        </div>
        <div class="btn-row">
          <button class="btn sm" data-git="fetch">${icon("refresh")}Fetch</button>
          <button class="btn sm" data-git="pull">${icon("download")}Pull</button>
          <button class="btn sm" data-git="push">${icon("upload")}Push</button>
          <button class="btn sm" data-open="terminal">${icon("terminal")}Terminal</button>
        </div>
      </div>

      <div class="card">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:10px">
          <h3 style="margin:0">${icon("file")}Changes</h3>
          <div style="display:flex;align-items:center;gap:6px">
            <span id="git-stash-count-${site.name}"></span>
            <button class="btn sm ghost" id="git-stash-push-${site.name}" title="Stash uncommitted changes">${icon("folder")}Stash</button>
            <button class="btn sm ghost" id="git-stash-pop-${site.name}" title="Apply and remove latest stash" disabled>Pop</button>
          </div>
        </div>
        <div id="git-files-list-${site.name}" style="display:flex;flex-direction:column;gap:4px">
          <p class="muted sm" style="margin:4px 0"><span class="dot on"></span> Loading git status…</p>
        </div>
      </div>

      <div class="card" id="git-commit-card-${site.name}" style="display:none">
        <h3 style="margin:0 0 10px 0">${icon("check")}Commit Changes</h3>
        <div style="display:flex;gap:8px;align-items:center">
          <input type="text" id="git-commit-msg-${site.name}" class="input sm" placeholder="Commit message (e.g. Update user controller)" style="flex:1">
          <button class="btn primary sm" id="git-commit-btn-${site.name}">${icon("check")}Commit All</button>
        </div>
      </div>

      <div class="card" id="git-diff-viewer-${site.name}" hidden style="margin-top:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <span style="font-weight:600;font-size:13px" id="git-diff-title-${site.name}">Diff</span>
          <button class="btn sm ghost" id="git-diff-close-${site.name}" data-close-diff="${site.name}">${icon("x")}Close</button>
        </div>
        <pre class="terminal diff-view" id="git-diff-content-${site.name}" style="max-height:360px;overflow-y:auto;font-family:monospace;font-size:12px;padding:8px;border-radius:6px;line-height:1.5;white-space:pre-wrap;background:var(--surface-2);color:var(--text)"></pre>
      </div>

      <div class="card" id="git-workspaces-card-${site.name}">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:10px">
          <div>
            <h3 style="margin:0">${icon("branch")}${t("workspaces", "Git Workspaces")}</h3>
            <div class="muted sm">Run multiple Git branches in parallel on dedicated subdomains (branch.domain.test)</div>
          </div>
          <button class="btn sm primary" id="git-workspace-new-${site.name}">+ ${t("workspace_create", "New Workspace")}</button>
        </div>
        <div id="git-workspaces-list-${site.name}" style="display:flex;flex-direction:column;gap:6px">
          <p class="muted sm" style="margin:4px 0"><span class="dot on"></span> Loading workspaces…</p>
        </div>
      </div>
    </div>
  `;
}

function formatGitDiff(raw) {
  if (!raw) return '<span class="muted">(No diff)</span>';
  return raw.split("\n").map((line) => {
    const safe = esc(line);
    if (line.startsWith("+++") || line.startsWith("---")) return `<span style="color:var(--muted);font-weight:600">${safe}</span>`;
    if (line.startsWith("+")) return `<span style="color:var(--green);background:rgba(34,197,94,0.1);display:block">${safe}</span>`;
    if (line.startsWith("-")) return `<span style="color:var(--red);background:rgba(239,68,68,0.1);display:block">${safe}</span>`;
    if (line.startsWith("@@")) return `<span style="color:#a855f7;font-weight:600;display:block">${safe}</span>`;
    return `<span>${safe}</span>`;
  }).join("\n");
}

async function loadGitTabDetails(siteName) {
  const container = document.getElementById(`git-details-${siteName}`);
  if (!container) return;
  try {
    const info = await LD.call("git_info", { name: siteName });
    if (!info.is_git) {
      container.innerHTML = `<div class="card"><p class="muted sm" style="margin:0">Not a Git repository.</p></div>`;
      return;
    }

    const branchSelect = document.getElementById(`git-branch-select-${siteName}`);
    if (branchSelect) {
      const branches = info.branches || [];
      branchSelect.innerHTML = branches.map((b) => `<option value="${esc(b)}" ${b === info.branch ? "selected" : ""}>${esc(b)}${b === info.branch ? " (current)" : ""}</option>`).join("");
    }

    const stashesCount = (info.stashes || []).length;
    const stashCountEl = document.getElementById(`git-stash-count-${siteName}`);
    if (stashCountEl) {
      stashCountEl.innerHTML = stashesCount > 0
        ? `<span class="chip php">${icon("folder")}${stashesCount} stash${stashesCount > 1 ? "es" : ""}</span>`
        : `<span class="muted sm">No stashes</span>`;
    }
    const stashPopBtn = document.getElementById(`git-stash-pop-${siteName}`);
    if (stashPopBtn) stashPopBtn.disabled = stashesCount === 0;

    const filesList = document.getElementById(`git-files-list-${siteName}`);
    const commitCard = document.getElementById(`git-commit-card-${siteName}`);
    const files = info.files || [];

    if (files.length === 0) {
      if (filesList) filesList.innerHTML = `<p class="muted sm" style="margin:4px 0">${icon("check")}Working tree clean. No uncommitted changes.</p>`;
      if (commitCard) commitCard.style.display = "none";
    } else {
      if (commitCard) commitCard.style.display = "block";
      if (filesList) {
        filesList.innerHTML = files.map((f) => {
          let chipClass = "php";
          if (f.status === "M") chipClass = "warn";
          else if (f.status === "A") chipClass = "ok";
          else if (f.status === "D") chipClass = "danger";
          return `
            <div class="row-item" style="padding:6px 0;align-items:center">
              <div style="display:flex;align-items:center;gap:8px;overflow:hidden">
                <span class="chip ${chipClass}" style="min-width:24px;text-align:center;font-weight:700">${esc(f.status)}</span>
                <span class="mono" style="font-size:13px;word-break:break-all">${esc(f.file)}</span>
              </div>
              <button class="btn sm ghost" data-git-diff-file="${esc(f.file)}" style="flex-shrink:0">${icon("code")}Diff</button>
            </div>
          `;
        }).join("");

        filesList.querySelectorAll("[data-git-diff-file]").forEach((btn) => {
          btn.addEventListener("click", () => showGitDiff(siteName, btn.dataset.gitDiffFile));
        });
      }
    }

    const switchBtn = document.getElementById(`git-branch-switch-${siteName}`);
    if (switchBtn) {
      switchBtn.onclick = () => {
        const sel = document.getElementById(`git-branch-select-${siteName}`);
        const targetBranch = sel?.value;
        if (targetBranch && targetBranch !== info.branch) {
          runAction("git-checkout", { name: siteName, branch: targetBranch });
        }
      };
    }

    const newBranchBtn = document.getElementById(`git-branch-new-${siteName}`);
    if (newBranchBtn) {
      newBranchBtn.onclick = async () => {
        const name = await promptModal("New Branch", "Branch name:", "");
        if (name) {
          runAction("git-checkout", { name: siteName, branch: name, new: true });
        }
      };
    }

    const stashPushBtn = document.getElementById(`git-stash-push-${siteName}`);
    if (stashPushBtn) {
      stashPushBtn.onclick = () => runAction("git-stash", { name: siteName, op: "push" });
    }

    const stashPopBtnEl = document.getElementById(`git-stash-pop-${siteName}`);
    if (stashPopBtnEl) {
      stashPopBtnEl.onclick = () => runAction("git-stash", { name: siteName, op: "pop" });
    }

    const commitBtn = document.getElementById(`git-commit-btn-${siteName}`);
    if (commitBtn) {
      commitBtn.onclick = () => {
        const input = document.getElementById(`git-commit-msg-${siteName}`);
        const msg = (input?.value || "").trim();
        if (!msg) {
          toast("error", "Commit message required", "Please enter a message before committing.");
          return;
        }
        runAction("git-commit", { name: siteName, message: msg });
      };
    }

    const diffCloseBtn = document.getElementById(`git-diff-close-${siteName}`);
    if (diffCloseBtn) {
      diffCloseBtn.onclick = () => {
        const viewer = document.getElementById(`git-diff-viewer-${siteName}`);
        if (viewer) viewer.hidden = true;
      };
    }

    // Load branch workspaces
    const wsListEl = document.getElementById(`git-workspaces-list-${siteName}`);
    if (wsListEl) {
      LD.call("workspaces_list", { name: siteName }).then((res) => {
        const list = res.workspaces || [];
        if (!list.length) {
          wsListEl.innerHTML = `<p class="muted sm" style="margin:4px 0">No branch workspaces created yet. Create one to test a branch on its own isolated subdomain.</p>`;
          return;
        }
        wsListEl.innerHTML = list.map((ws) => `
          <div class="row-item" style="padding:8px 10px;border:1px solid var(--border);border-radius:6px;background:var(--bg);align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
            <div>
              <div style="display:flex;align-items:center;gap:6px">
                <span class="dot on"></span>
                <b style="font-size:13px">${esc(ws.branch)}</b>
                <span class="chip sm muted" style="font-family:var(--mono)">${esc(ws.commit || "")}</span>
              </div>
              <div style="margin-top:2px">
                <a class="link text sm" data-open="browser" data-custom-url="${esc(ws.url)}" style="font-weight:600">${esc(ws.url)}</a>
                <span class="muted sm" style="margin-left:6px;font-family:var(--mono);font-size:11px">${esc(ws.path)}</span>
              </div>
            </div>
            <div style="display:flex;gap:6px">
              <button class="btn sm ghost" data-open-workspace-url="${esc(ws.url)}">${icon("browser")}Open</button>
              <button class="btn sm danger ghost" data-workspace-delete="${esc(ws.branch)}">${icon("trash")}${t("workspace_delete", "Delete")}</button>
            </div>
          </div>
        `).join("");

        wsListEl.querySelectorAll("[data-open-workspace-url]").forEach((b) => {
          b.onclick = () => window.open(b.dataset.openWorkspaceUrl, "_blank");
        });
        wsListEl.querySelectorAll("[data-workspace-delete]").forEach((b) => {
          b.onclick = async () => {
            const br = b.dataset.workspaceDelete;
            if (!(await confirmModal({ title: `Delete Workspace?`, message: `Remove worktree and virtual host for branch '${br}'?`, confirm: "Delete", danger: true }))) return;
            runAction("workspace-delete", { name: siteName, branch: br }).then(() => loadGitTabDetails(siteName));
          };
        });
      }).catch((err) => {
        if (wsListEl) wsListEl.innerHTML = `<p class="muted sm" style="color:var(--red)">Failed to load workspaces: ${esc(err.message)}</p>`;
      });
    }

    const newWsBtn = document.getElementById(`git-workspace-new-${siteName}`);
    if (newWsBtn) {
      newWsBtn.onclick = async () => {
        const branchName = await promptModal("New Branch Workspace", "Branch name (e.g. feature/checkout):", "");
        if (branchName) {
          runAction("workspace-create", { name: siteName, branch: branchName }).then(() => loadGitTabDetails(siteName));
        }
      };
    }
  } catch (err) {
    if (container) container.innerHTML = `<p style="color:var(--red);margin:0">Failed to load Git details: ${esc(err.message)}</p>`;
  }
}

async function showGitDiff(siteName, file) {
  const viewer = document.getElementById(`git-diff-viewer-${siteName}`);
  const title = document.getElementById(`git-diff-title-${siteName}`);
  const content = document.getElementById(`git-diff-content-${siteName}`);
  if (!viewer || !content) return;
  viewer.hidden = false;
  title.textContent = file ? `Diff: ${file}` : "Diff";
  content.innerHTML = `<span class="muted">Loading diff…</span>`;
  try {
    const res = await LD.call("git_diff", { name: siteName, file });
    content.innerHTML = formatGitDiff(res.diff);
  } catch (err) {
    content.innerHTML = `<span style="color:var(--red)">Failed to load diff: ${esc(err.message)}</span>`;
  }
}

function logSource(site) {
  if (isApp(site)) return "app";
  return runsServer(site) && state.drawer.logSource === "app" ? "app" : "laravel";
}

/* ── tasks / activity ───────────────────────────────────────────────────── */
async function runAction(action, params = {}, { show = true } = {}) {
  try {
    const task = await LD.call("run", { action, params });
    state.activeTask = task.id;
    if (show) openActivity();
    return task;
  } catch (err) {
    toast("error", "Couldn't start", err.message);
    return null;
  }
}

function onTaskEvent(task, done) {
  state.tasks.set(task.id, task);
  if (!state.output.has(task.id)) state.output.set(task.id, "");
  if (!state.activeTask) state.activeTask = task.id;
  renderTasks();
  if (!done) return;

  if (task.status === "success") {
    toast("success", task.title, "Finished successfully");
  } else if (task.status === "error") {
    state.activeTask = task.id;
    renderTasks();
    renderTaskOutput();
    openActivity();
    toast("error", task.title, "Failed — see Activity output");
  }

  window.Servers?.onTaskDone(task);
  window.dispatchEvent(new CustomEvent("ld:task-done", { detail: task }));
  const titleLower = (task.title || "").toLowerCase();
  const isWorkerOrCron = titleLower.includes("worker") || titleLower.includes("scheduler") || titleLower.includes("cron");
  const isPkgOrDiag = /^(composer|npm|pnpm|yarn|bun)\b/i.test(task.title || "") || titleLower.includes("repair");
  const shouldForce = Boolean(
    task.site &&
    task.site === state.drawer.name &&
    isWorkerOrCron &&
    state.drawer.tab === "queue"
  );
  if (task.site && isPkgOrDiag) {
    const ovCache = _overviewCache.get(task.site);
    if (ovCache) {
      ovCache.doctorHtml = "";
      ovCache.auditHtml = "";
    }
    if (task.site === state.drawer.name && state.drawer.tab === "overview") {
      loadDoctorDiagnostics(task.site, true);
      loadPackageAudit(task.site, true);
    }
  }
  if (task.site) refreshSites(shouldForce);
  if (task.site && task.site === state.drawer.name && state.drawer.tab === "git") {
    setTimeout(() => loadGitTabDetails(task.site), 500);
  }
  refreshServices();
}

function onTaskOutput(id, text) {
  let buffer = (state.output.get(id) || "") + text;
  buffer = buffer.replace(/\r\n/g, "\n").replace(/[^\n]*\r(?=[^\n])/g, "");
  if (buffer.length > 250000) buffer = buffer.slice(-200000);
  state.output.set(id, buffer);
  if (id === state.activeTask) renderTaskOutput();
}

function renderTasks() {
  const list = $("#task-list");
  const tasks = [...state.tasks.values()].sort((a, b) => b.started - a.started);
  const running = tasks.filter((t) => t.status === "running").length;
  const badge = $("#activity-badge");
  badge.hidden = running === 0;
  badge.textContent = running;
  badge.classList.toggle("spin", running > 0);

  list.innerHTML = tasks.length
    ? tasks.map((t) => `
        <li class="task ${t.id === state.activeTask ? "active" : ""}" data-task="${t.id}">
          <span class="status-icon ${t.status}">${t.status === "success" ? icon("check") : t.status === "running" ? "" : icon("x")}</span>
          <div><div class="task-title">${esc(t.title)}</div><div class="task-time">${timeAgo(t.started)}</div></div>
        </li>`).join("")
    : `<li class="empty-tasks">Commands you run show up here with their live output.</li>`;
  renderTaskOutput();
}

function renderTaskOutput() {
  const task = state.tasks.get(state.activeTask);
  const out = $("#task-output");
  const header = $("#task-output-header");
  if (!task) {
    header.innerHTML = "";
    out.textContent = "";
    return;
  }
  const label = { running: "Running…", success: "Completed", error: `Failed (exit ${task.code})`, cancelled: "Cancelled" }[task.status];
  header.innerHTML = `<b>${esc(task.title)}</b><span>· ${label}</span>
    ${task.status === "running" ? `<button class="btn sm" data-cancel="${task.id}">${icon("stop")}Cancel</button>` : ""}`;
  const stick = out.scrollHeight - out.scrollTop - out.clientHeight < 40;
  out.textContent = state.output.get(task.id) || (task.status === "running" ? "Waiting for output…" : "(no output)");
  if (stick) out.scrollTop = out.scrollHeight;
}

function openActivity() {
  $("#activity").classList.add("open");
  $("#activity").setAttribute("aria-hidden", "false");
  renderTasks();
  const out = $("#task-output");
  out.scrollTop = out.scrollHeight;
}

function closeActivity() {
  $("#activity").classList.remove("open");
  $("#activity").setAttribute("aria-hidden", "true");
}

/* ── services ───────────────────────────────────────────────────────────── */
const SERVICE_ICONS = { Nginx: "globe", Database: "database", Redis: "zap", Supervisor: "layers", Mailpit: "mail", Meilisearch: "search", MinIO: "database" };
const SERVICE_URLS = {
  Mailpit: { url: "http://localhost:8025", label: ":8025" },
  Meilisearch: { url: "http://localhost:7700", label: ":7700" },
  MinIO: { url: "http://localhost:9001", label: ":9001" },
};

async function refreshServices() {
  try {
    state.services = await LD.call("services");
  } catch { return; }
  renderServices();
}

function statusDot(status) {
  return `<span class="dot ${status === "active" ? "on" : status === "failed" ? "fail" : status === "not_installed" ? "warn" : "off"}"></span>`;
}

async function renderTools() {
  if (!state.tools) {
    $("#service-grid").innerHTML = `<div class="skeleton" style="height:90px"></div>`;
    try { state.tools = await LD.call("tools"); } catch { state.tools = []; }
  }
  $("#service-grid").innerHTML = state.tools.map((t) => `
    <div class="card service-card">
      <div class="service-top">
        <div class="service-icon">${icon({ php: "code", composer: "layers", node: "zap", npm: "layers", git: "branch", mysql: "database" }[t.bin] || "cpu")}</div>
        <div><div class="service-name">${esc(t.label)}</div><div class="service-desc"><code>${esc(t.bin)}</code></div></div>
      </div>
      <div class="service-status" style="margin-left:0">${t.version ? `<span class="dot on"></span>${esc(t.version)}` : `<span class="dot off"></span>Not found on PATH`}</div>
    </div>`).join("");
  $("#php-list").innerHTML = "";
}

function renderServices() {
  if (!managed()) {
    $("#mini-services").innerHTML = `<div class="mini-service">${{ windows: "Windows", macos: "macOS", linux: "Linux" }[state.platform] || ""} · portable mode</div>`;
    return;
  }
  const core = state.services.filter((s) => s.kind === "core");
  $("#mini-services").innerHTML = core.length
    ? core.map((s) => `<div class="mini-service"><b>${esc(s.label.replace(" FPM", ""))}</b>${statusDot(s.status)}</div>`).join("")
    : `<div class="mini-service">No services detected</div>`;

  $("#service-grid").innerHTML = state.services.map((s) => {
    const active = s.status === "active";
    const notInstalled = s.status === "not_installed" || s.installed === false;
    const web = SERVICE_URLS[s.label];
    const canUseInProject = ["Mailpit", "Redis", "Meilisearch", "MinIO"].includes(s.label);

    let buttonsHtml = "";
    if (notInstalled) {
      buttonsHtml = `<button class="btn sm primary" data-service-install="${esc(s.unit)}">${icon("download")}Install ${esc(s.label)}</button>`;
    } else {
      buttonsHtml = `
        ${active
          ? `<button class="btn sm" data-service="restart" data-unit="${esc(s.unit)}">${icon("refresh")}Restart</button>
             <button class="btn sm" data-service="stop" data-unit="${esc(s.unit)}">${icon("stop")}Stop</button>`
          : `<button class="btn sm primary" data-service="start" data-unit="${esc(s.unit)}">${icon("play")}Start</button>`}
        ${web && active
          ? `<button class="btn sm ghost" data-open-url="${esc(web.url)}" title="Open Web UI">${icon("browser")}Open UI (${esc(web.label)})</button>`
          : ""}
        ${canUseInProject && (active || s.label === "Mailpit" || s.label === "Redis")
          ? `<button class="btn sm ghost" data-service-env="${esc(s.label.toLowerCase())}" title="Configure in project .env" style="margin-left:auto">${icon("plus")}Use in project</button>`
          : ""}
      `;
    }

    return `
      <div class="card service-card">
        <div class="service-top">
          <div class="service-icon">${icon(SERVICE_ICONS[s.label] || "cpu")}</div>
          <div><div class="service-name">${esc(s.label)}</div><div class="service-desc">${esc(s.description)} · <code>${esc(s.unit)}</code></div></div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="service-status" style="margin-left:0">${statusDot(s.status)}${esc(s.status === "not_installed" ? "Not installed" : s.status)}</div>
        </div>
        <div class="btn-row">
          ${buttonsHtml}
        </div>
      </div>`;
  }).join("") || `<p class="muted">No supported services found. Install nginx, MySQL/MariaDB and PHP-FPM, or rerun install.sh.</p>`;

  const fpm = Object.fromEntries(state.services.filter((s) => /^php[0-9.]*-fpm$/.test(s.unit)).map((s) => [s.unit.replace(/^php|-fpm$/g, ""), s.status]));

  if (!document.activeElement || !document.activeElement.closest("#php-list")) {
    state.phpInfo = state.phpInfo || {};

    if (!state.phpInstallableLoading && !state.phpInstallable) {
      state.phpInstallableLoading = true;
      LD.call("php_installable").then((res) => {
        state.phpInstallable = res.versions || [];
        state.phpInstallableLoading = false;
        renderServices();
      }).catch(() => { state.phpInstallableLoading = false; });
    }

    const installable = state.phpInstallable || [];
    const installHtml = installable.length ? `
      <div class="card" style="margin-bottom:16px;padding:14px 16px">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:12px">
          <div>
            <b style="font-size:14px">${t("php_install_title", "Install PHP Versions")}</b>
            <div class="muted sm">${t("php_install_desc", "Install multiple PHP versions side-by-side with required extensions.")}</div>
          </div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          ${installable.map(item => `
            <div style="display:flex;align-items:center;gap:8px;padding:6px 12px;border:1px solid var(--border);border-radius:8px;background:var(--bg)">
              <b style="font-size:13px">PHP ${esc(item.version)}</b>
              ${item.status === "installed" 
                ? `<span class="chip ok" style="margin:0">${t("php_installed", "Installed")}</span>` 
                : `<button type="button" class="btn sm primary" data-php-install="${esc(item.version)}" style="padding:2px 8px;font-size:11px">${t("php_install_btn", "Install")}</button>`}
            </div>
          `).join("")}
        </div>
      </div>
    ` : "";

    const cardsHtml = state.phpVersions.map((v) => {
      const info = state.phpInfo[v];
      if (!info) {
        LD.call("php_info", { version: v }).then((res) => {
          state.phpInfo[v] = res;
          renderServices();
        }).catch(() => {});
        return `
          <div class="card php-card">
            <div class="php-header">
              <b>PHP ${esc(v)}</b>
              <small>${fpm[v] ? `${statusDot(fpm[v])} FPM ${esc(fpm[v])}` : "CLI only"}</small>
              ${v === defaultPhp() ? `<span class="chip php">default</span>` : ""}
            </div>
            <div class="muted sm">Loading PHP settings...</div>
          </div>`;
      }

      const xdebugBtn = `
        <button class="btn sm ${info.xdebug ? "" : "ghost"}" data-php-xdebug="${esc(v)}" data-enable="${info.xdebug ? "0" : "1"}" title="Toggle Xdebug">
          ${icon(info.xdebug ? "check" : "cpu")}
          <span style="${info.xdebug ? "color:var(--green);font-weight:600" : ""}">Xdebug: ${info.xdebug ? "On" : "Off"}</span>
        </button>
      `;

      const extsList = (info.extensions || []).map((e) => `<span class="php-ext-chip">${esc(e)}</span>`).join("");

      return `
        <div class="card php-card">
          <div class="php-header">
            <div style="display:flex;align-items:center;gap:10px">
              <b>PHP ${esc(v)}</b>
              <small>${fpm[v] ? `${statusDot(fpm[v])} FPM ${esc(fpm[v])}` : "CLI only"}</small>
              ${v === defaultPhp() ? `<span class="chip php">default</span>` : ""}
            </div>
            <div style="margin-left:auto;display:flex;align-items:center;gap:8px">
              ${xdebugBtn}
              <button class="btn sm ghost" data-php-jit="${esc(v)}" title="${esc(t("xdebug_jit_hint", "Configure Xdebug to start only on the XDEBUG_TRIGGER=LARAVEL_DEV trigger, so PHP runs at full speed otherwise"))}">${icon("zap")}${t("xdebug_jit", "JIT mode")}</button>
            </div>
          </div>

          <div class="php-ini-group">
            <div class="php-ini-field">
              <label>memory_limit</label>
              <input type="text" class="input sm" style="width:75px" id="ini-${esc(v)}-memory_limit" value="${esc(info.memory_limit || "")}">
            </div>
            <div class="php-ini-field">
              <label>upload_max_filesize</label>
              <input type="text" class="input sm" style="width:75px" id="ini-${esc(v)}-upload_max_filesize" value="${esc(info.upload_max_filesize || "")}">
            </div>
            <div class="php-ini-field">
              <label>max_execution_time</label>
              <input type="text" class="input sm" style="width:65px" id="ini-${esc(v)}-max_execution_time" value="${esc(info.max_execution_time || "")}">
            </div>
            <button class="btn sm" data-php-ini="${esc(v)}" title="Apply php.ini directives and reload PHP-FPM">
              ${icon("check")}Save ini
            </button>
          </div>

          <div class="php-ext-group">
            <div style="display:flex;align-items:center;gap:6px">
              <input type="text" class="input sm" id="php-ext-input-${esc(v)}" placeholder="Install extension (e.g. redis)..." style="width:200px">
              <button class="btn sm" data-php-ext="${esc(v)}">${icon("plus")}Install</button>
            </div>
            <details class="php-ext-details">
              <summary>${(info.extensions || []).length} extensions loaded (click to view)</summary>
              <div class="php-ext-chips">${extsList || '<span class="muted">No extensions detected</span>'}</div>
            </details>
          </div>
        </div>
      `;
    }).join("");
    $("#php-list").innerHTML = installHtml + cardsHtml;
  }
  loadCustomInstances();
}

/* ── settings ───────────────────────────────────────────────────────────── */
function renderSettings() {
  const form = $("#settings-form");
  form.elements.default_php.innerHTML = phpOptions(defaultPhp());
  form.elements.editor.innerHTML = `<option value="">System default</option>` +
    state.editors.map((e) => `<option value="${esc(e.bin)}">${esc(e.label)}</option>`).join("");
  for (const [key, value] of Object.entries(state.settings)) if (form.elements[key]) form.elements[key].value = value;
  form.elements.editor.value = state.prefs.editor || "";
  form.elements.theme.value = state.prefs.theme || "system";
  if (form.elements.language) form.elements.language.value = window.I18N?.getLang() || "en";
  form.elements.close_to_tray.checked = !!state.prefs.close_to_tray;
  form.elements.autostart.checked = !!state.prefs.autostart;
  if (form.elements.notify_failed_jobs) form.elements.notify_failed_jobs.checked = state.prefs.notify_failed_jobs !== false;
  if (form.elements.notify_log_errors) form.elements.notify_log_errors.checked = state.prefs.notify_log_errors !== false;
  if (form.elements.notify_mail) form.elements.notify_mail.checked = state.prefs.notify_mail !== false;
  if (form.elements.notify_task_fail) form.elements.notify_task_fail.checked = state.prefs.notify_task_fail !== false;
  $("#tray-row").hidden = !state.tray;
  window.Productivity?.renderVaultSection();
  loadVersionCheck(false);
  loadShimStatus();
  loadDnsStatus();
  loadParkStatus();
  loadMcpStatus();
  loadAiSettings();
}

async function loadShimStatus() {
  const shimBody = document.getElementById("cli-shim-card-body");
  if (!shimBody) return;
  try {
    const res = await LD.call("shim_status");
    const active = res.status === "enabled";
    shimBody.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
        <div>
          <b style="font-size:14px">${t("cli_shim_title", "PHP CLI Automatic Version Shim")}</b>
          <div class="muted sm" style="margin-top:2px">${t("cli_shim_desc", "Automatically routes the 'php' command in terminal to each site's .php-version")}</div>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <span class="chip ${active ? "ok" : "muted"}" style="margin:0">${active ? t("cli_shim_active", "Active") : t("cli_shim_inactive", "Inactive")}</span>
          <button type="button" class="btn sm ${active ? "ghost" : "primary"}" data-toggle-shim="${active ? "disable" : "enable"}">
            ${active ? t("cli_shim_disable", "Disable CLI Shim") : t("cli_shim_enable", "Enable CLI Shim")}
          </button>
        </div>
      </div>
    `;
  } catch (err) {
    shimBody.innerHTML = `<p class="muted sm" style="margin:0">${esc(err.message)}</p>`;
  }
}

async function loadDnsStatus() {
  const container = document.getElementById("dns-card-body");
  if (!container) return;
  try {
    const res = await LD.call("dns_status");
    const active = !!res.enabled;
    container.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
        <div>
          <b style="font-size:14px">${t("dns_title", "Wildcard DNS (*.test)")}</b>
          <div class="muted sm" style="margin-top:2px">${t("dns_desc", "Resolve all *.test domains to 127.0.0.1 using dnsmasq and systemd-resolved")}</div>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <span class="chip ${active ? "ok" : "muted"}" style="margin:0">${active ? t("dns_active", "Active") : t("dns_inactive", "Inactive")}</span>
          <button type="button" class="btn sm ${active ? "ghost" : "primary"}" data-toggle-dns="${active ? "disable" : "enable"}">
            ${active ? t("dns_disable", "Disable Wildcard DNS") : t("dns_enable", "Enable Wildcard DNS")}
          </button>
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<p class="muted sm" style="margin:0">${esc(err.message)}</p>`;
  }
}

async function loadParkStatus() {
  const container = document.getElementById("park-card-body");
  if (!container) return;
  try {
    const res = await LD.call("park_status");
    const active = !!res.enabled;
    container.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
        <div>
          <b style="font-size:14px">${t("park_title", "Valet-style Parked Directories")}</b>
          <div class="muted sm" style="margin-top:2px">${t("park_desc", "Automatically serve all Laravel sites in ~/Sites as http://<folder>.test without manual setup")}</div>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <span class="chip ${active ? "ok" : "muted"}" style="margin:0">${active ? t("park_active", "Active") : t("park_inactive", "Inactive")}</span>
          <button type="button" class="btn sm ${active ? "ghost" : "primary"}" data-toggle-park="${active ? "disable" : "enable"}">
            ${active ? t("park_disable", "Disable Parked Sites") : t("park_enable", "Enable Parked Sites")}
          </button>
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<p class="muted sm" style="margin:0">${esc(err.message)}</p>`;
  }
}

async function loadAiSettings() {
  const card = document.getElementById("ai-settings-card");
  if (!card) return;
  let cfg;
  try {
    cfg = await LD.call("ai_settings");
  } catch (err) {
    card.innerHTML = `<p class="muted sm" style="margin:0">${esc(err.message)}</p>`;
    return;
  }
  const labels = { ollama: "Ollama (local, free)", gemini: "Google Gemini", openai: "OpenAI", anthropic: "Anthropic Claude" };
  const defaults = cfg.default_models || {};
  card.innerHTML = `
    <div id="ai-settings-form" style="display:flex;flex-direction:column;gap:10px">
      <div>
        <div style="display:flex;align-items:center;gap:8px">
          <b style="font-size:14px">${icon("sparkles")} ${t("ai_assistant", "AI Assistant")}</b>
          ${cfg.has_key ? `<span class="chip ok sm" style="margin:0">${cfg.key_encrypted ? t("ai_key_vault", "Key in Vault") : t("ai_key_saved", "Key saved")}</span>` : ""}
        </div>
        <div class="muted sm" style="margin-top:2px">${t("ai_settings_desc", "Provider used by \"AI Fix\" in Logs and Doctor. API keys are encrypted when the Vault is enabled.")}</div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px">
        <label class="field">
          <span>${t("ai_provider", "Provider")}</span>
          <select name="provider">
            ${(cfg.providers || Object.keys(labels)).map((pv) => `<option value="${esc(pv)}" ${pv === cfg.provider ? "selected" : ""}>${esc(labels[pv] || pv)}</option>`).join("")}
          </select>
        </label>
        <label class="field">
          <span>${t("ai_model", "Model")}</span>
          <input name="model" value="${esc(cfg.model || "")}" placeholder="${esc(defaults[cfg.provider] || "")}" autocomplete="off">
        </label>
        <label class="field" data-ai-only="ollama">
          <span>${t("ai_ollama_url", "Ollama URL")}</span>
          <input name="ollama_url" value="${esc(cfg.ollama_url || "")}" autocomplete="off">
        </label>
        <label class="field" data-ai-only="cloud">
          <span>${t("ai_api_key", "API key")}</span>
          <input name="api_key" type="password" placeholder="${esc(cfg.has_key ? t("ai_key_keep", "•••••• (leave empty to keep)") : "")}" autocomplete="off">
        </label>
      </div>
      <div class="btn-row" style="gap:8px;align-items:center">
        <button type="button" class="btn sm primary" id="btn-ai-save">${icon("check")}${t("save", "Save")}</button>
        <button type="button" class="btn sm" id="btn-ai-test">${icon("pulse")}${t("ai_test", "Test connection")}</button>
        ${cfg.has_key ? `<button type="button" class="btn sm ghost danger" id="btn-ai-clear-key">${icon("trash")}${t("ai_clear_key", "Remove key")}</button>` : ""}
        <span class="muted sm" id="ai-settings-status"></span>
      </div>
    </div>
  `;
  const form = $("#ai-settings-form", card);
  const status = $("#ai-settings-status", card);
  const field = (name) => form.querySelector(`[name="${name}"]`);
  const syncFields = () => {
    const pv = field("provider").value;
    $$("[data-ai-only]", form).forEach((el) => {
      el.style.display = (el.dataset.aiOnly === "ollama") === (pv === "ollama") ? "" : "none";
    });
    field("model").placeholder = defaults[pv] || "";
  };
  field("provider").addEventListener("change", syncFields);
  syncFields();
  const save = async (extra = {}) => {
    await LD.call("ai_settings_save", {
      provider: field("provider").value,
      model: field("model").value.trim(),
      ollama_url: field("ollama_url").value.trim(),
      api_key: field("api_key").value.trim(),
      ...extra,
    });
  };
  // Enter in these inputs must not submit the surrounding settings form.
  form.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      $("#btn-ai-save", card).click();
    }
  });
  $("#btn-ai-save", card).addEventListener("click", async () => {
    try {
      await save();
      toast("success", t("ai_saved", "AI settings saved"));
      loadAiSettings();
    } catch (err) {
      status.textContent = err.message;
    }
  });
  $("#btn-ai-clear-key", card)?.addEventListener("click", async () => {
    try {
      await save({ clear_key: true, api_key: "" });
      loadAiSettings();
    } catch (err) {
      status.textContent = err.message;
    }
  });
  $("#btn-ai-test", card).addEventListener("click", async () => {
    status.textContent = t("ai_testing", "Testing…");
    try {
      await save();
      const res = await LD.call("ai_test");
      status.innerHTML = res.ok
        ? `<span style="color:var(--green)">✓ ${esc(res.provider)}: ${esc(res.reply || "ok")}</span>`
        : `<span style="color:var(--red)">✗ ${esc(res.error || "failed")}</span>`;
    } catch (err) {
      status.innerHTML = `<span style="color:var(--red)">✗ ${esc(err.message)}</span>`;
    }
  });
}

async function loadMcpStatus() {
  const card = document.getElementById("mcp-settings-card");
  if (!card) return;
  try {
    const res = await LD.call("mcp_status");
    const tools = res.tools || [];
    const command = res.command || "laravel-dev mcp";
    const cliPath = res.cli || "laravel-dev";
    const configSnippet = JSON.stringify({
      mcpServers: {
        "laravel-dev": {
          command: cliPath,
          args: ["mcp"]
        }
      }
    }, null, 2);

    card.innerHTML = `
      <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:12px">
        <div>
          <div style="display:flex;align-items:center;gap:8px">
            <b style="font-size:14px">${t("mcp_server", "MCP Server")}</b>
            <span class="chip ok sm" style="margin:0">JSON-RPC 2.0 (stdio)</span>
          </div>
          <div class="muted sm" style="margin-top:2px">${t("mcp_desc", "Connect Cursor, Claude Desktop, and AI agents directly via Model Context Protocol.")}</div>
        </div>
      </div>

      <div style="margin-bottom:12px">
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px">CLI Command:</label>
        <div style="display:flex;align-items:center;gap:8px;background:var(--bg);border:1px solid var(--border);padding:6px 10px;border-radius:6px">
          <code style="font-size:12px;flex:1">${esc(command)}</code>
          <button type="button" class="btn xs ghost" data-copy="${esc(command)}">${icon("copy")} Copy</button>
        </div>
      </div>

      <div style="margin-bottom:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
          <label style="font-size:12px;font-weight:600">Claude Desktop / Cursor Config:</label>
          <button type="button" class="btn xs ghost" data-copy="${esc(configSnippet)}">${icon("copy")} Copy Config</button>
        </div>
        <pre style="background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:8px 10px;font-size:11px;color:var(--text);overflow-x:auto;margin:0">${esc(configSnippet)}</pre>
      </div>

      <div style="margin-bottom:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px">
          <label style="font-size:12px;font-weight:600">${t("mcp_clients", "AI clients")}</label>
          <button type="button" class="btn xs" id="btn-mcp-test">${icon("pulse")}${t("mcp_test", "Test server")}</button>
        </div>
        <div id="mcp-test-result"></div>
        <ul class="check-list">
          ${(res.clients || []).map((c) => {
            const srv = c.servers || [];
            const userScope = srv.some((x) => x.scope === "user");
            const badCmd = srv.some((x) => !x.command_ok);
            const state = !c.configured ? "todo" : badCmd ? "bad" : "ok";
            const scopes = srv.map((x) => x.scope === "user"
              ? t("mcp_scope_user", "all projects")
              : `${t("mcp_scope_project", "only in")} ${esc(x.scope.replace(/^project:/, "").split("/").pop())}`).join(", ");
            return `
              <li class="check-row ${state}">
                <span class="check-icon">${state === "ok" ? icon("check") : state === "bad" ? icon("x") : icon("plus")}</span>
                <span style="flex:1;min-width:0"><b>${esc(c.client)}</b>
                  <small>${c.configured
                    ? `${badCmd ? t("mcp_cmd_missing", "Command not found — reinstall or fix the path") + " · " : ""}${scopes}`
                    : c.exists ? t("mcp_not_configured", "Installed, laravel-dev not configured") : t("mcp_client_absent", "Not detected")}</small>
                  ${c.client === "Claude Code" && !userScope ? `<small>${t("mcp_add_user_hint", "Make it available in every project:")} <code class="mono">${esc(`claude mcp add --scope user laravel-dev -- ${cliPath} mcp`)}</code></small>` : ""}
                </span>
                ${c.client === "Claude Code" && !userScope
                  ? `<button type="button" class="btn xs ghost" data-copy="${esc(`claude mcp add --scope user laravel-dev -- ${cliPath} mcp`)}">${icon("copy")}</button>`
                  : !c.configured && c.exists
                    ? `<button type="button" class="btn xs ghost" data-copy="${esc(configSnippet)}" title="${esc(c.path)}">${icon("copy")}</button>` : ""}
              </li>`;
          }).join("")}
        </ul>
      </div>

      <div>
        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">Exposed Tools (${tools.length}):</label>
        <div style="display:flex;flex-wrap:wrap;gap:6px">
          ${tools.map(tool => `
            <span class="chip sm" style="font-family:var(--mono);font-size:11px" title="${esc(tool.description)}">${esc(tool.name)}</span>
          `).join("")}
        </div>
      </div>
    `;
    card.querySelector("#btn-mcp-test")?.addEventListener("click", async (e) => {
      const btn = e.currentTarget;
      const out = card.querySelector("#mcp-test-result");
      btn.disabled = true;
      out.innerHTML = `<p class="muted sm" style="margin:0 0 8px">${t("mcp_testing", "Starting the server like an AI client would…")}</p>`;
      try {
        const r = await LD.call("mcp_test");
        out.innerHTML = r.ok
          ? `<div class="status-panel ok" style="margin-bottom:8px"><div class="status-title"><span class="dot on"></span>${t("mcp_test_ok", "Server works")} · ${esc(r.tools)} tools · ${esc(r.projects)} ${t("mcp_projects", "projects")} · ${esc(r.elapsed_ms)} ms · MCP ${esc(r.protocol)}</div></div>`
          : `<div class="status-panel bad" style="margin-bottom:8px"><div class="status-panel-main"><div class="status-title"><span class="dot fail"></span>${esc(r.error || "failed")}</div>${r.stderr ? `<pre class="log-pre" style="max-height:160px">${esc(r.stderr)}</pre>` : ""}</div></div>`;
      } catch (err) {
        out.innerHTML = `<p class="muted sm">${esc(err.message)}</p>`;
      }
      btn.disabled = false;
    });
  } catch (err) {
    card.innerHTML = `<p class="muted sm" style="margin:0">${esc(err.message)}</p>`;
  }
}

async function loadCustomInstances() {
  const container = document.getElementById("custom-instances-card");
  if (!container) return;
  try {
    const res = await LD.call("instances_list");
    const instances = res.instances || [];
    container.innerHTML = `
      <div class="card" style="padding:14px 16px">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:12px">
          <div>
            <div style="display:flex;align-items:center;gap:8px">
              <b style="font-size:14px">${t("service_instances", "Custom Service Instances")}</b>
              <span class="chip sm" style="margin:0">${instances.filter(i => i.active).length}/${instances.length} ${t("running", "Running")}</span>
            </div>
            <div class="muted sm" style="margin-top:2px">Run isolated instances of Redis, MySQL, or PostgreSQL on dedicated ports.</div>
          </div>
          <button type="button" class="btn sm primary" id="btn-add-instance">
            ${icon("plus")} ${t("add_instance", "Add Instance")}
          </button>
        </div>

        ${instances.length ? `
          <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(280px, 1fr));gap:10px">
            ${instances.map(inst => `
              <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 12px;border:1px solid var(--border);border-radius:8px;background:var(--bg)">
                <div style="display:flex;align-items:center;gap:10px;min-width:0">
                  <div style="width:32px;height:32px;border-radius:6px;background:var(--surface-2);display:grid;place-items:center">
                    ${icon(inst.type === "redis" ? "zap" : "database")}
                  </div>
                  <div>
                    <div style="font-weight:600;font-size:13px">${esc(inst.type)}: ${esc(inst.name)}</div>
                    <div class="muted sm" style="font-family:var(--mono);font-size:11px">Port: ${esc(inst.port)} · <span class="dot ${inst.active ? 'on' : 'off'}"></span>${inst.active ? 'Running' : 'Stopped'}</div>
                  </div>
                </div>
                <div class="btn-row" style="gap:4px;flex-shrink:0">
                  <button type="button" class="btn xs ghost" data-copy="${esc(instanceConnString(inst))}" title="${esc(t("copy_connection", "Copy connection string"))}">${icon("copy")}</button>
                  <button type="button" class="btn xs ghost" data-instance-toggle="${inst.active ? "stop" : "start"}" data-instance-type="${esc(inst.type)}" data-instance-name="${esc(inst.name)}" title="${esc(inst.active ? t("stop", "Stop") : t("start", "Start"))}">${icon(inst.active ? "stop" : "play")}</button>
                  <button type="button" class="btn xs ghost danger" data-delete-instance-type="${esc(inst.type)}" data-delete-instance-name="${esc(inst.name)}" title="Delete Instance">
                    ${icon("trash")}
                  </button>
                </div>
              </div>
            `).join("")}
          </div>
        ` : `
          <div class="muted sm" style="padding:8px 0">No custom service instances created. Click "Add Instance" to start an isolated service on a custom port.</div>
        `}
      </div>
    `;

    document.getElementById("btn-add-instance")?.addEventListener("click", () => {
      openAddInstanceModal();
    });

    $$("[data-instance-toggle]", container).forEach(btn => {
      btn.addEventListener("click", async () => {
        const act = btn.dataset.instanceToggle;
        await runAction(`service-instance-${act}`, { type: btn.dataset.instanceType, instance_name: btn.dataset.instanceName });
        setTimeout(() => loadCustomInstances(), 1200);
      });
    });

    $$("[data-delete-instance-type]", container).forEach(btn => {
      btn.addEventListener("click", async () => {
        const type = btn.dataset.deleteInstanceType;
        const name = btn.dataset.deleteInstanceName;
        const ok = await confirmModal({
          title: "Delete Service Instance",
          message: `Are you sure you want to stop and remove instance <b>${esc(type)}:${esc(name)}</b>? Its data directory will be removed.`,
          confirm: "Delete",
          danger: true
        });
        if (ok) {
          await runAction("service-instance-delete", { type, instance_name: name });
          setTimeout(() => loadCustomInstances(), 1200);
        }
      });
    });
  } catch (err) {
    container.innerHTML = `<div class="card" style="padding:14px 16px"><p class="muted sm" style="margin:0">${esc(err.message)}</p></div>`;
  }
}

function instanceConnString(inst) {
  const host = inst.host || "127.0.0.1";
  if (inst.type === "mysql") return `mysql://${inst.username || "root"}@${host}:${inst.port}`;
  if (inst.type === "postgresql") return `postgresql://${inst.username || "postgres"}@${host}:${inst.port}/postgres`;
  return `redis://${host}:${inst.port}`;
}

function openAddInstanceModal() {
  openModal(`
    <form class="modal sm" id="add-instance-form">
      <div class="modal-header">
        <h2>${t("add_instance", "Add Service Instance")}</h2>
        <button type="button" class="btn ghost icon-btn close" data-dismiss>${icon("x")}</button>
      </div>
      <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
        <label class="field">
          <span>${t("instance_type", "Service Type")}</span>
          <select name="type" id="instance-type-select">
            <option value="redis">Redis</option>
            <option value="mysql">MySQL</option>
            <option value="postgresql">PostgreSQL</option>
          </select>
        </label>
        <label class="field">
          <span>${t("instance_name", "Instance Name")}</span>
          <input name="name" placeholder="e.g. cache-2 or staging-db" required pattern="[a-z0-9][a-z0-9_\-]{0,31}" title="lowercase letters, digits, - and _" autocomplete="off">
        </label>
        <label class="field">
          <span>${t("instance_port", "Port")}</span>
          <input name="port" type="number" value="6380" required min="1024" max="65535">
        </label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn" data-dismiss>Cancel</button>
        <button type="submit" class="btn primary">Create Instance</button>
      </div>
    </form>
  `, (root) => {
    const form = $("#add-instance-form", root);
    const typeSelect = $("#instance-type-select", form);
    const portInput = form.elements.port;
    typeSelect.addEventListener("change", () => {
      if (typeSelect.value === "redis") portInput.value = "6380";
      else if (typeSelect.value === "mysql") portInput.value = "3307";
      else if (typeSelect.value === "postgresql") portInput.value = "5433";
    });
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const type = typeSelect.value;
      const name = form.elements.name.value.trim();
      const port = form.elements.port.value.trim();
      closeModal();
      await runAction("service-instance-create", { type, instance_name: name, port });
      setTimeout(() => loadCustomInstances(), 1200);
    });
  });
}

async function loadVersionCheck(force = false) {
  const container = document.getElementById("updates-card-body");
  if (!container) return;
  if (force) container.innerHTML = `<p class="muted sm" style="margin:0"><span class="dot on"></span> Checking GitHub for updates…</p>`;

  try {
    const res = await LD.call("version_check", { force });
    if (res.has_update) {
      container.innerHTML = `
        <div style="background:rgba(99, 102, 241, 0.08);border:1px solid rgba(99, 102, 241, 0.25);border-radius:8px;padding:12px;margin-top:4px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
            <div>
              <b style="color:var(--text)">Update Available: v${esc(res.latest_version)}</b>
              <div class="muted sm" style="margin-top:2px">Current version: v${esc(res.current_version)}</div>
            </div>
            <div class="btn-row">
              ${res.release_url ? `<button type="button" class="btn sm ghost" data-open-url="${esc(res.release_url)}">${icon("browser")}Release Notes</button>` : ""}
              <button type="button" class="btn sm primary" id="btn-apply-update">${icon("download")}Update Now</button>
            </div>
          </div>
          ${res.release_notes ? `<pre style="margin-top:8px;padding:8px;background:var(--surface);border-radius:6px;font-size:11.5px;max-height:120px;overflow-y:auto;white-space:pre-wrap;color:var(--muted)">${esc(res.release_notes)}</pre>` : ""}
        </div>
      `;
      document.getElementById("btn-apply-update")?.addEventListener("click", () => {
        runAction("app-update");
      });
    } else {
      container.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;color:var(--green)">
          <span class="dot on"></span>
          <span>You are on the latest version (<b>v${esc(res.current_version)}</b>).</span>
        </div>
      `;
    }
  } catch (err) {
    container.innerHTML = `<p style="color:var(--red);margin:0">Failed to check for updates: ${esc(err.message)}</p>`;
  }
}

async function saveSettings() {
  const form = $("#settings-form");
  const f = form.elements;
  if (!/^(\/|~|[A-Za-z]:[\\/]|\\\\)/.test(f.LARAVEL_SITES_DIR.value.trim())) {
    f.LARAVEL_SITES_DIR.classList.add("invalid");
    toast("error", "The www folder must be an absolute path");
    return;
  }
  f.LARAVEL_SITES_DIR.classList.remove("invalid");
  const settings = {};
  for (const key of ["LARAVEL_SITES_DIR", "DB_TYPE", "DB_HOST", "DB_PORT", "DB_USER", "DB_PASSWORD"]) settings[key] = f[key].value;
  const prefs = {
    default_php: f.default_php.value, editor: f.editor.value, theme: f.theme.value,
    close_to_tray: f.close_to_tray.checked, autostart: f.autostart.checked,
    notify_failed_jobs: f.notify_failed_jobs?.checked ?? true,
    notify_log_errors: f.notify_log_errors?.checked ?? true,
    notify_mail: f.notify_mail?.checked ?? true,
    notify_task_fail: f.notify_task_fail?.checked ?? true,
  };
  const saved = await api("save", { settings, prefs });
  const lang = f.language ? f.language.value : "en";
  if (window.I18N && window.I18N.getLang() !== lang) {
    window.I18N.setLang(lang);
  }
  state.settings = saved.settings;
  state.prefs = saved.prefs;
  applyTheme();
  renderSettings();
  refreshSites();
  toast("success", "Settings saved");
}

/* ── modals ─────────────────────────────────────────────────────────────── */
function openModal(optionsOrHtml, onMount) {
  let html = optionsOrHtml;
  if (typeof optionsOrHtml === "object" && optionsOrHtml !== null && !(optionsOrHtml instanceof Node)) {
    const { title = "", content = "", actions = [] } = optionsOrHtml;
    const actionsHtml = actions.map((act, i) =>
      `<button type="button" class="btn ${act.primary ? "primary" : ""}" data-action-idx="${i}" ${act.dismiss ? "data-dismiss" : ""}>${esc(act.label || "OK")}</button>`
    ).join("");
    html = `
      <div class="modal card" style="max-width:700px">
        <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between">
          <h2>${esc(title)}</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <div class="modal-body" style="padding:16px">${content}</div>
        <div class="modal-footer" style="display:flex;justify-content:flex-end;gap:8px;padding:12px 16px;border-top:1px solid var(--border)">
          ${actionsHtml || '<button type="button" class="btn" data-dismiss>Close</button>'}
        </div>
      </div>
    `;
    const origMount = onMount;
    onMount = (root) => {
      actions.forEach((act, i) => {
        const btn = root.querySelector(`[data-action-idx="${i}"]`);
        if (btn) {
          btn.addEventListener("click", (e) => {
            if (act.run) act.run(e);
            closeModal();
          });
        }
      });
      origMount?.(root);
    };
  }

  const root = $("#modal-root");
  root.innerHTML = html;
  root.hidden = false;
  root.querySelectorAll("[data-dismiss], .modal-close, .dialog-close, [data-close-modal], button.close").forEach(b => {
    b.onclick = (ev) => { ev.preventDefault(); ev.stopPropagation(); closeModal(); };
  });
  onMount?.(root);
  setTimeout(() => $("input:not([type=hidden]), select", root)?.focus(), 30);
}

function closeModal() {
  const root = $("#modal-root");
  if (root) {
    root.hidden = true;
    root.innerHTML = "";
  }
}

$("#modal-root").addEventListener("click", (e) => {
  if (e.target === $("#modal-root")) closeModal();
});

function confirmModal({ title, message, confirm = "Confirm", danger = false, requireText = "" }) {
  return new Promise((resolve) => {
    let resolved = false;
    const finish = (val) => {
      if (!resolved) {
        resolved = true;
        closeModal();
        resolve(val);
      }
    };
    openModal(`
      <form class="modal sm" id="confirm-form">
        <div class="modal-header"><h2>${esc(title)}</h2></div>
        <div class="modal-body">
          <p style="margin:0">${message}</p>
          ${requireText ? `<label class="field"><span>Type <code>${esc(requireText)}</code> to confirm</span><input name="confirm" autocomplete="off" spellcheck="false"></label>` : ""}
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>Cancel</button>
          <button type="submit" class="btn ${danger ? "danger solid" : "primary"}" ${requireText ? "disabled" : ""}>${esc(confirm)}</button>
        </div>
      </form>`, (root) => {
      const form = $("#confirm-form", root);
      const submit = $("button[type=submit]", form);
      if (requireText) form.elements.confirm.addEventListener("input", (e) => (submit.disabled = e.target.value !== requireText));
      if (!requireText) setTimeout(() => submit.focus(), 40);
      form.addEventListener("submit", (e) => { e.preventDefault(); finish(true); });
      $("[data-dismiss]", form).addEventListener("click", () => finish(false));
    });

    const observer = new MutationObserver(() => {
      if ($("#modal-root").hidden && !resolved) {
        resolved = true;
        observer.disconnect();
        resolve(false);
      }
    });
    observer.observe($("#modal-root"), { attributes: true, attributeFilter: ["hidden"] });
  });
}

function promptModal(title, label, value) {
  return new Promise((resolve) => {
    let resolved = false;
    const finish = (val) => {
      if (!resolved) {
        resolved = true;
        closeModal();
        resolve(val);
      }
    };
    openModal(`
      <form class="modal sm" id="prompt-form">
        <div class="modal-header"><h2>${esc(title)}</h2></div>
        <div class="modal-body"><label class="field"><span>${esc(label)}</span><input name="value" value="${esc(value)}" spellcheck="false" autocomplete="off"></label></div>
        <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">OK</button></div>
      </form>`, (root) => {
      const form = $("#prompt-form", root);
      $("[data-dismiss]", form).addEventListener("click", () => finish(""));
      form.addEventListener("submit", (e) => { e.preventDefault(); const v = form.elements.value.value.trim(); finish(v); });
    });

    const observer = new MutationObserver(() => {
      if ($("#modal-root").hidden && !resolved) {
        resolved = true;
        observer.disconnect();
        resolve("");
      }
    });
    observer.observe($("#modal-root"), { attributes: true, attributeFilter: ["hidden"] });
  });
}

async function openAiFixModal(siteName, issue = {}) {
  const issueObj = typeof issue === "string" ? { message: issue } : (issue || {});
  const msg = issueObj.message || issueObj.description || "";
  const file = issueObj.file || "";
  const line = issueObj.line || 1;
  const trace = issueObj.trace || "";
  const prompt = issueObj.prompt || "";

  let currentFixData = null;

  openModal(`
    <div class="modal card" style="max-width:820px;width:95vw">
      <div class="modal-header" style="display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;align-items:center;gap:8px">
          ${icon("sparkles")}
          <h2 style="margin:0">${t("ai_assistant", "AI Assistant")} · ${esc(siteName)}</h2>
        </div>
        <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
      </div>
      <div class="modal-body" id="ai-fix-modal-body" style="padding:16px;max-height:75vh;overflow-y:auto">
        <div class="loading-pane" style="text-align:center;padding:36px;color:var(--muted)">
          <div style="margin-bottom:10px">${icon("pulse")}</div>
          <div>${t("ai_analyzing", "Analyzing issue and preparing fix…")}</div>
          <div class="muted sm" style="margin-top:6px;font-family:var(--mono);font-size:11px">${esc(msg.slice(0, 100))}</div>
        </div>
      </div>
      <div class="modal-footer" id="ai-fix-modal-footer" style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:12px 16px;border-top:1px solid var(--border)">
        <div id="ai-fix-status" style="font-size:12px;color:var(--muted)"></div>
        <div style="display:flex;gap:8px">
          <button type="button" class="btn" data-dismiss>Close</button>
          <button type="button" class="btn danger" id="btn-ai-revert" style="display:none">${t("revert_changes", "Revert Changes")}</button>
          <button type="button" class="btn primary" id="btn-ai-apply" style="display:none">${t("apply_changes", "Apply Changes")}</button>
        </div>
      </div>
    </div>
  `, async (root) => {
    async function runPropose(customQuery = "") {
      const body = $("#ai-fix-modal-body", root);
      const footerStatus = $("#ai-fix-status", root);
      const applyBtn = $("#btn-ai-apply", root);
      const revertBtn = $("#btn-ai-revert", root);

      if (!body) return;

      body.innerHTML = `
        <div class="loading-pane" style="text-align:center;padding:36px;color:var(--muted)">
          <div style="margin-bottom:10px">${icon("pulse")}</div>
          <div>${t("ai_analyzing", "Analyzing issue and preparing fix…")}</div>
        </div>
      `;
      if (applyBtn) applyBtn.style.display = "none";
      if (revertBtn) revertBtn.style.display = "none";

      try {
        const res = await LD.call("ai_propose_fix", {
          name: siteName,
          message: msg,
          file: file,
          line: line,
          trace: trace,
          prompt: customQuery || prompt,
        });

        currentFixData = res;

        if (footerStatus) {
          footerStatus.innerHTML = res.ai_connected
            ? `<span class="chip ok sm">Provider: ${esc(res.provider || "AI")}</span>`
            : `<span class="chip warn sm" title="${esc(res.ai_error || "")}">${t("ai_offline", "AI unavailable")} · ${esc(res.provider || "")}</span>`;
        }

        const diffHtml = DiffViewer.renderDiff(res.diff);

        body.innerHTML = `
          <div style="display:flex;flex-direction:column;gap:12px">
            <div style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <b style="font-size:13px">Problem Analysis & Explanation:</b>
                ${res.file_path ? `<span class="chip sm" style="font-family:var(--mono)">${esc(res.rel_file || res.file_path)}${res.line ? `:${res.line}` : ''}</span>` : ''}
              </div>
              <div style="font-size:12.5px;line-height:1.5;color:var(--text);white-space:pre-wrap">${esc(res.explanation || "No explanation provided.")}</div>
            </div>

            <div>
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <b style="font-size:13px">${t("diff_viewer", "Diff Viewer")}:</b>
              </div>
              ${diffHtml}
            </div>

            <div style="display:flex;gap:8px;margin-top:4px">
              <input type="text" id="ai-refine-prompt" class="field" style="flex:1;padding:6px 10px;font-size:12px" placeholder="Ask AI to refine, adjust, or explain further…">
              <button type="button" class="btn sm" id="btn-ai-refine">${icon("sparkles")} Refine</button>
            </div>
          </div>
        `;

        if (res.diff && res.proposed_content && res.file_path && applyBtn) {
          applyBtn.style.display = "inline-flex";
        }
        if (res.has_backup && revertBtn) {
          revertBtn.style.display = "inline-flex";
        }

        $("#btn-ai-refine", body)?.addEventListener("click", () => {
          const val = $("#ai-refine-prompt", body)?.value.trim();
          if (val) runPropose(val);
        });
        $("#ai-refine-prompt", body)?.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            const val = $("#ai-refine-prompt", body)?.value.trim();
            if (val) runPropose(val);
          }
        });
      } catch (err) {
        body.innerHTML = `<div class="card" style="padding:20px;color:var(--red)">Failed to generate fix: ${esc(err.message)}</div>`;
      }
    }

    $("#btn-ai-apply", root)?.addEventListener("click", async () => {
      if (!currentFixData || !currentFixData.file_path || !currentFixData.proposed_content) return;
      const btn = $("#btn-ai-apply", root);
      btn.disabled = true;
      try {
        const res = await LD.call("ai_apply_changes", {
          name: siteName,
          file_path: currentFixData.file_path,
          new_content: currentFixData.proposed_content,
        });
        if (res.success) {
          toast("success", "Changes applied successfully!", "Backup saved as .ldbak");
          currentFixData.has_backup = true;
          btn.style.display = "none";
          const rev = $("#btn-ai-revert", root);
          if (rev) rev.style.display = "inline-flex";
        } else {
          toast("error", "Failed to apply changes", res.error || "Unknown error");
        }
      } catch (err) {
        toast("error", "Error applying changes", err.message);
      } finally {
        btn.disabled = false;
      }
    });

    $("#btn-ai-revert", root)?.addEventListener("click", async () => {
      if (!currentFixData || !currentFixData.file_path) return;
      const btn = $("#btn-ai-revert", root);
      btn.disabled = true;
      try {
        const res = await LD.call("ai_revert_changes", {
          name: siteName,
          file_path: currentFixData.file_path,
        });
        if (res.success) {
          toast("success", "Reverted changes successfully!");
          btn.style.display = "none";
          const appBtn = $("#btn-ai-apply", root);
          if (appBtn) appBtn.style.display = "inline-flex";
        } else {
          toast("error", "Failed to revert changes", res.error || "Unknown error");
        }
      } catch (err) {
        toast("error", "Error reverting changes", err.message);
      } finally {
        btn.disabled = false;
      }
    });

    await runPropose();
  });
}
window.openAiFixModal = openAiFixModal;

function addSiteModal(mode = "new", prefill = {}) {
  openModal(`
    <form class="modal" id="add-form" novalidate>
      <div class="modal-header">
        <h2>Add a site</h2>
        <p>It will be served at its own local domain.</p>
      </div>
      <div class="modal-body">
        <div class="segmented">
          <button type="button" class="segment" data-mode="new">${icon("sparkles")}New project</button>
          <button type="button" class="segment" data-mode="link">${icon("folder")}Existing folder</button>
          <button type="button" class="segment" data-mode="clone">${icon("branch")}Git repository</button>
        </div>
        <div class="field" data-for="new"><span>Framework</span>
          <div class="framework-picker">
            ${["laravel", "next", "nuxt", "django"].map((t) => `
              <label class="framework" style="--type:${TYPES[t].color}">
                <input type="radio" name="framework" value="${t}" ${t === (prefill.framework || "laravel") ? "checked" : ""}>
                <span class="framework-dot"></span>${TYPES[t].label}
              </label>`).join("")}
          </div>
        </div>
        <label class="field" data-for="link"><span>Project folder</span>
          <span class="input-group" style="width:100%"><input name="path" placeholder="/home/you/code/my-app" spellcheck="false"><button type="button" class="btn" data-browse>Browse</button></span>
        </label>
        <label class="field" data-for="clone"><span>Repository URL</span><input name="repo" placeholder="https://github.com/acme/shop.git" spellcheck="false"></label>
        <label class="field" data-for="link"><span>Project type <small id="detected-type"></small></span>
          <select name="type">${Object.entries(TYPES).map(([t, m]) => `<option value="${t}">${m.label}</option>`).join("")}</select>
        </label>
        <div class="field" data-for="link" id="placement-field"><span>Put it in the www folder <small class="mono" id="www-dir"></small></span>
          <div class="placement">
            ${[["move", "Move", "The folder moves into www"], ["copy", "Copy", "Original stays untouched"],
               ["symlink", "Shortcut", "A link in www points to it"], ["keep", "Leave it", "Serve it from where it is"]].map(([v, label, hint]) => `
              <label class="place-opt"><input type="radio" name="placement" value="${v}" ${v === (prefill.placement || "move") ? "checked" : ""}>
                <span><b>${label}</b><small>${hint}</small></span></label>`).join("")}
          </div>
        </div>
        <label class="field"><span>Site name</span><input name="name" placeholder="my-app" spellcheck="false" maxlength="60"></label>
        <div class="grid-2">
          <label class="field" id="php-field"><span>PHP version <small id="php-hint"></small></span><select name="php">${phpOptions(defaultPhp())}</select></label>
          <label class="field"><span>Domain <small>(optional)</small></span><input name="domain" placeholder="my-app.test" spellcheck="false"></label>
        </div>
        <div class="grid-2" data-for="new">
          <label class="field"><span>${t("starter_kit", "Starter Kit")}</span>
            <select name="starter">
              <option value="none">${t("starter_none", "None (Standard Laravel)")}</option>
              <option value="react">${t("starter_react", "React (Starter Kit / Inertia)")}</option>
              <option value="vue">${t("starter_vue", "Vue (Starter Kit / Inertia)")}</option>
              <option value="livewire">${t("starter_livewire", "Livewire (Starter Kit / Flux)")}</option>
              <option value="api">${t("starter_api", "API only (Sanctum)")}</option>
              <option value="breeze-blade">${t("starter_blade", "Breeze (Blade)")}</option>
            </select>
          </label>
          <label class="field"><span>${t("database", "Database")}</span>
            <select name="db">
              <option value="sqlite">SQLite (Fastest)</option>
              <option value="mysql">MySQL / MariaDB</option>
              <option value="pgsql">PostgreSQL</option>
            </select>
          </label>
        </div>
        <div class="field" data-for="new" style="margin-top:-2px">
          <span style="display:block;font-size:12px;color:var(--text-dim);margin-bottom:6px">${t("addons_title", "Add-on Packages")}</span>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
            <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer">
              <input type="checkbox" name="addon_filament">
              <span>${t("addon_filament", "Filament Admin Panel")}</span>
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer">
              <input type="checkbox" name="addon_horizon">
              <span>${t("addon_horizon", "Laravel Horizon")}</span>
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer">
              <input type="checkbox" name="addon_telescope">
              <span>${t("addon_telescope", "Laravel Telescope")}</span>
            </label>
          </div>
        </div>
        <div class="field" data-for="new" style="margin-top:2px">
          <label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer">
            <input type="checkbox" name="pest" checked>
            <span>Use Pest PHP testing framework</span>
          </label>
        </div>
        <div class="field" id="worker-field" style="margin-top:2px">
          <label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer">
            <input type="checkbox" name="worker">
            <span>Start a queue worker (Supervisor)</span>
          </label>
        </div>
        <label class="field" data-for="clone"><span>Access token <small>(private repos only)</small></span><input name="token" type="password" autocomplete="off"></label>
        <div class="domain-preview" id="domain-preview"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn" data-dismiss>Cancel</button>
        <button type="submit" class="btn primary" id="add-submit">Create</button>
      </div>
    </form>`, (root) => {
    const form = $("#add-form", root);
    const f = form.elements;
    let current = mode;
    let nameTouched = !!prefill.name;
    if (prefill.path) f.path.value = prefill.path;
    if (prefill.name) f.name.value = prefill.name;
    if (prefill.type) f.type.value = prefill.type;

    const selectedType = () => current === "new" ? f.framework.value : current === "link" ? f.type.value : "";

    let detectSeq = 0;
    const detect = async () => {
      const path = f.path.value.trim();
      const seq = ++detectSeq;
      const kind = path ? await LD.call("detect", { path }).catch(() => "") : "";
      if (seq !== detectSeq) return;
      if (kind) f.type.value = kind;
      $("#detected-type").textContent = kind ? `· detected ${TYPES[kind]?.label || kind}` : path ? "· couldn't detect, pick one" : "";
      update();
    };

    const update = () => {
      $$(".segment", form).forEach((b) => b.classList.toggle("active", b.dataset.mode === current));
      $$("[data-for]", form).forEach((el) => (el.hidden = el.dataset.for !== current));
      $("#add-submit").innerHTML = { new: `${icon("sparkles")}Create app`, link: `${icon("link")}Link site`, clone: `${icon("download")}Clone & link` }[current];
      const kind = selectedType();
      const isLaravel = (kind === "" || kind === "laravel");
      $("#php-field").hidden = !isLaravel || !managed();
      $("#worker-field").hidden = !isLaravel || !managed();
      const www = (state.settings.LARAVEL_SITES_DIR || "").replace(/[\\/]+$/, "");
      const path = f.path.value.trim().replace(/[\\/]+$/, "");
      const parent = path.replace(/[\\/][^\\/]*$/, "");
      $("#www-dir").textContent = www.replace(state.home, "~");
      // Already directly inside www: nothing to move.
      if (current === "link") $("#placement-field").hidden = !path || parent === www;
      $("#php-hint").textContent = current === "clone" ? "(used if it's a Laravel app)" : "";
      const name = f.name.value.trim();
      const domain = f.domain.value.trim().toLowerCase() || (name ? `${name}.test` : "");
      f.domain.placeholder = name ? `${name}.test` : "my-app.test";
      f.domain.closest(".field").hidden = !managed();
      $("#domain-preview").innerHTML = !managed() ? (name ? "It gets its own <b>localhost</b> port — press ▶ to start it." : "")
        : domain ? `Will be available at <b>http://${esc(domain)}</b>` : "";
    };

    const autoName = (source) => {
      if (nameTouched || !source) return;
      f.name.value = slugify(source.split(/[\\/]/).filter(Boolean).pop() || "");
      update();
    };

    $$(".segment", form).forEach((b) => b.addEventListener("click", () => { current = b.dataset.mode; update(); }));
    f.name.addEventListener("input", () => { nameTouched = true; f.name.value = f.name.value.toLowerCase().replace(/\s+/g, "-"); update(); });
    f.domain.addEventListener("input", update);
    let detectTimer = null;
    f.path.addEventListener("input", () => { autoName(f.path.value); clearTimeout(detectTimer); detectTimer = setTimeout(detect, 350); });
    f.type.addEventListener("change", update);
    f.path.addEventListener("input", update);
    $$("[name=framework]", form).forEach((r) => r.addEventListener("change", update));
    f.repo.addEventListener("input", () => autoName(f.repo.value));
    $("[data-browse]", form).addEventListener("click", async () => {
      const path = await api("pick_folder", { title: "Choose a project folder", current: f.path.value || state.settings.LARAVEL_SITES_DIR || state.home });
      if (path) { f.path.value = path; autoName(path); detect(); }
    });
    $("[data-dismiss]", form).addEventListener("click", closeModal);

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      $$(".invalid", form).forEach((el) => el.classList.remove("invalid"));
      const addons = [];
      if (f.addon_filament?.checked) addons.push("filament");
      if (f.addon_horizon?.checked) addons.push("horizon");
      if (f.addon_telescope?.checked) addons.push("telescope");

      const params = {
        name: f.name.value.trim(),
        php: f.php.value,
        domain: f.domain.value.trim().toLowerCase(),
        type: selectedType() || "laravel",
        worker: Boolean(f.worker?.checked),
        starter: f.starter?.value || "none",
        db: f.db?.value || "sqlite",
        pest: Boolean(f.pest?.checked),
        addons: addons.join(","),
      };
      const errors = [];
      if (!NEW_NAME_RE.test(params.name)) errors.push([f.name, "Use lowercase letters, numbers, dashes and dots."]);
      if (state.sites.some((s) => s.linked && s.name === params.name)) errors.push([f.name, `A site called “${params.name}” already exists.`]);
      if (params.domain && !DOMAIN_RE.test(params.domain)) errors.push([f.domain, "That doesn't look like a domain (e.g. shop.test)."]);
      if (current === "link") {
        params.path = f.path.value.trim();
        params.placement = $("#placement-field").hidden ? "keep" : (form.querySelector("[name=placement]:checked")?.value || "keep");
        if (!params.path) errors.push([f.path, "Choose the project folder."]);
      }
      if (current === "clone") {
        params.repo = f.repo.value.trim();
        params.token = f.token.value;
        if (!/^(https?:\/\/|ssh:\/\/|git@)\S+$/.test(params.repo)) errors.push([f.repo, "Enter an https:// or git@ repository URL."]);
      }
      if (errors.length) {
        errors.forEach(([el]) => el.classList.add("invalid"));
        errors[0][0].focus();
        toast("error", errors[0][1]);
        return;
      }
      const task = await runAction(current === "new" ? "create" : current, params);
      if (task) closeModal();
    });

    update();
    if (prefill.path) { autoName(prefill.path); detect(); }
  });
}

function openShareModal(siteName) {
  openModal(`
    <div class="modal" id="share-modal" style="max-width:540px">
      <div class="modal-header">
        <h2>${icon("share")}Share &amp; Expose · ${esc(siteName)}</h2>
        <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
      </div>
      <div class="modal-body" id="share-modal-body">
        <div style="text-align:center;padding:24px" class="muted">Loading share information…</div>
      </div>
    </div>
  `, (root) => {
    $("[data-dismiss]", root)?.addEventListener("click", closeModal);
    async function update() {
      const body = $("#share-modal-body", root);
      if (!body) return;
      try {
        const info = await LD.call("share_info", { name: siteName });
        const qrSvg = window.QRCode && info.lan_url ? window.QRCode.generateSVG(info.lan_url, 150) : "";

        body.innerHTML = `
          <div style="display:flex;flex-direction:column;gap:16px">
            <!-- Local URL -->
            <div style="padding:12px 14px;border:1px solid var(--border);border-radius:8px;background:var(--surface-2)">
              <div style="font-size:12px;color:var(--muted);margin-bottom:6px">Local Host URL</div>
              <div style="display:flex;align-items:center;gap:8px">
                <input type="text" class="input sm" readonly value="${esc(info.domain_url)}" style="flex:1">
                <button type="button" class="btn sm" data-copy="${esc(info.domain_url)}">${icon("copy")}Copy</button>
                <button type="button" class="btn sm ghost" data-open-url="${esc(info.domain_url)}">${icon("browser")}Open</button>
              </div>
            </div>

            <!-- LAN / Wi-Fi -->
            <div style="padding:14px;border:1px solid var(--border);border-radius:8px;background:var(--surface-2)">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <b>Local Wi-Fi / LAN Access</b>
                <span class="chip sm" style="font-family:var(--mono)">${esc(info.lan_ip)}</span>
              </div>
              ${info.lan_url ? `<p class="muted sm" style="margin:0 0 10px">Scan this QR code with your phone camera or open the LAN URL on any device connected to the same Wi-Fi.</p>
              <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
                <div style="background:#fff;padding:6px;border-radius:8px;display:inline-block">
                  ${qrSvg}
                </div>
                <div style="flex:1;min-width:180px;display:flex;flex-direction:column;gap:8px">
                  <input type="text" class="input sm" readonly value="${esc(info.lan_url)}">
                  <button type="button" class="btn sm" data-copy="${esc(info.lan_url)}">${icon("copy")}Copy LAN URL</button>
                  <button type="button" class="btn sm ghost" data-open-url="${esc(info.lan_url)}">${icon("browser")}Open LAN URL</button>
                </div>
              </div>` : `<p class="muted sm" style="margin:0">This site has no LAN port yet. Run <b>Repair</b> from the site's Settings tab once to make it reachable from other devices.</p>`}
            </div>

            <!-- Cloudflare Public Tunnel -->
            <div style="padding:14px;border:1px solid var(--border);border-radius:8px;background:var(--surface-2)">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <b>Public Tunnel (Cloudflare)</b>
                <div style="display:flex;align-items:center;gap:6px">
                  <span class="dot ${info.tunnel?.active ? "on" : "off"}"></span>
                  <span style="font-size:12px;color:var(--muted)">${info.tunnel?.active ? "Active" : "Stopped"}</span>
                  ${info.tunnel?.mode ? `<span class="chip sm">${esc(info.tunnel.mode)}</span>` : ""}
                </div>
              </div>
              <p class="muted sm" style="margin:0 0 10px">Encrypted public HTTPS tunnel via Cloudflare for client previews, webhooks, or mobile devices.</p>
              ${info.tunnel?.active ? `
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
                  <input type="text" class="input sm" readonly value="${esc(info.tunnel.url)}" style="flex:1;font-family:var(--mono)">
                  <button type="button" class="btn sm" data-copy="${esc(info.tunnel.url)}">${icon("copy")}Copy</button>
                  <button type="button" class="btn sm ghost" data-open-url="${esc(info.tunnel.url)}">${icon("browser")}Open</button>
                  <button type="button" class="btn sm ghost" id="btn-toggle-share-tunnel-qr">${icon("qrcode")}QR</button>
                </div>
                <div id="share-tunnel-qr-pane" style="display:none;background:#fff;padding:12px;border-radius:8px;margin-bottom:10px;text-align:center">
                  ${window.QRCode && info.tunnel?.url ? window.QRCode.generateSVG(info.tunnel.url, 140) : ""}
                  <div style="font-size:11px;color:#333;margin-top:6px">Scan with your phone to open this tunnel</div>
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap">
                  <button type="button" class="btn sm danger" id="btn-stop-tunnel">${icon("stop")}Stop Tunnel</button>
                  <button type="button" class="btn sm" id="btn-restart-tunnel">${icon("refresh")}Restart</button>
                  <button type="button" class="btn sm ghost" id="btn-view-share-tunnel-logs">${icon("terminal")}Logs</button>
                </div>
              ` : `
                <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:12px">
                  <div style="display:flex;gap:12px;font-size:12px;flex-wrap:wrap">
                    <label style="display:flex;align-items:center;gap:4px;cursor:pointer">
                      <input type="radio" name="modal-tunnel-mode" value="quick" checked> Quick Tunnel (free trycloudflare.com)
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;cursor:pointer">
                      <input type="radio" name="modal-tunnel-mode" value="token" ${info.tunnel?.has_token ? "checked" : ""}> Custom Domain (Token)
                    </label>
                  </div>
                  <div id="modal-tunnel-token-wrap" style="${info.tunnel?.has_token ? "" : "display:none"}">
                    <input type="password" class="input sm" id="modal-tunnel-token-input" placeholder="Cloudflare Zero Trust Token (eyJh...)" value="${esc(info.tunnel?.token || "")}" style="width:100%">
                  </div>
                </div>
                <div style="display:flex;gap:6px">
                  <button type="button" class="btn sm primary" id="btn-start-tunnel">${icon("zap")}Start Cloudflare Tunnel</button>
                  <button type="button" class="btn sm ghost" id="btn-view-share-tunnel-logs">${icon("terminal")}Past Logs</button>
                </div>
              `}
              <div id="share-tunnel-logs-pane" style="display:none;margin-top:10px">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
                  <small class="muted">cloudflared output</small>
                  <button type="button" class="btn xs ghost" id="btn-refresh-share-logs">${icon("refresh")}Refresh</button>
                </div>
                <pre class="terminal" id="share-tunnel-logs-output" style="max-height:160px;overflow:auto;font-size:11px;padding:8px;margin:0"></pre>
              </div>
            </div>
          </div>
        `;

        root.querySelectorAll('input[name="modal-tunnel-mode"]').forEach((r) => {
          r.addEventListener("change", () => {
            const wrap = $("#modal-tunnel-token-wrap", root);
            if (wrap) wrap.style.display = r.value === "token" ? "block" : "none";
          });
        });

        $("#btn-toggle-share-tunnel-qr", root)?.addEventListener("click", () => {
          const p = $("#share-tunnel-qr-pane", root);
          if (p) p.style.display = p.style.display === "none" ? "block" : "none";
        });

        async function loadShareLogs() {
          const out = $("#share-tunnel-logs-output", root);
          if (!out) return;
          out.textContent = "Loading logs…";
          try {
            const res = await LD.call("tunnel_logs", { name: siteName });
            out.textContent = res.logs || "No logs available.";
          } catch (err) {
            out.textContent = `Error: ${err.message}`;
          }
        }

        $("#btn-view-share-tunnel-logs", root)?.addEventListener("click", () => {
          const p = $("#share-tunnel-logs-pane", root);
          if (p) {
            const isHidden = p.style.display === "none";
            p.style.display = isHidden ? "block" : "none";
            if (isHidden) loadShareLogs();
          }
        });

        $("#btn-refresh-share-logs", root)?.addEventListener("click", loadShareLogs);

        $("#btn-start-tunnel", root)?.addEventListener("click", async (e) => {
          const b = e.currentTarget;
          b.disabled = true;
          b.textContent = "Starting tunnel…";
          const modeEl = root.querySelector('input[name="modal-tunnel-mode"]:checked');
          const mode = modeEl ? modeEl.value : "quick";
          const tokenInput = $("#modal-tunnel-token-input", root);
          const token = tokenInput ? tokenInput.value.trim() : "";
          try {
            const res = await LD.call("tunnel_start", { name: siteName, mode, token });
            if (!res.ok) toast("error", "Tunnel failed", res.error || "Could not start tunnel");
            else toast("success", "Public tunnel active", res.url);
          } catch (err) {
            toast("error", "Tunnel failed", err.message);
          }
          update();
          refreshSites();
        });

        $("#btn-stop-tunnel", root)?.addEventListener("click", async (e) => {
          const b = e.currentTarget;
          b.disabled = true;
          b.textContent = "Stopping tunnel…";
          try {
            await LD.call("tunnel_stop", { name: siteName });
            toast("info", "Tunnel stopped");
          } catch (err) {
            toast("error", "Stop failed", err.message);
          }
          update();
          refreshSites();
        });

        $("#btn-restart-tunnel", root)?.addEventListener("click", async (e) => {
          const b = e.currentTarget;
          b.disabled = true;
          b.textContent = "Restarting tunnel…";
          try {
            const res = await LD.call("tunnel_restart", { name: siteName });
            if (!res.ok) toast("error", "Tunnel restart failed", res.error || "Could not restart tunnel");
            else toast("success", "Public tunnel restarted", res.url);
          } catch (err) {
            toast("error", "Restart failed", err.message);
          }
          update();
          refreshSites();
        });

      } catch (err) {
        body.innerHTML = `<p style="color:var(--red);margin:0">Failed to load share information: ${esc(err.message)}</p>`;
      }
    }
    update();
  });
}

async function openDomainManagerModal(siteName) {
  const site = siteByName(siteName);
  if (!site) return;

  openModal(`
    <div class="modal md" id="domain-manager-modal">
      <div class="modal-header">
        <h2>${icon("globe")} ${window.t ? window.t("domains", "Domains & Subdomains") : "Domains & Subdomains"} — ${esc(site.name)}</h2>
        <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
      </div>
      <div class="modal-body" style="display:flex;flex-direction:column;gap:16px">
        <div id="domain-modal-content">
          <div class="muted" style="text-align:center;padding:24px">${icon("spinner")} Loading domain configuration...</div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn" data-dismiss>Cancel</button>
        <button type="button" class="btn primary" id="btn-save-domains">${icon("check")} Save & Apply</button>
      </div>
    </div>
  `, async (root) => {
    const content = $("#domain-modal-content", root);
    const saveBtn = $("#btn-save-domains", root);

    try {
      const data = await call("domains_get", { name: site.name });
      const primaryDomain = data.primary_domain || site.domain || `${site.name}.test`;
      let aliases = data.aliases ? [...data.aliases] : [];
      let wildcard = data.wildcard !== false;

      function render() {
        content.innerHTML = `
          <div class="field">
            <label style="font-weight:600">Primary Domain</label>
            <div style="display:flex;align-items:center;gap:8px;margin-top:4px">
              <input type="text" class="input" value="${esc(primaryDomain)}" disabled style="font-family:var(--mono);flex:1">
              <span class="badge ${data.ssl ? "success" : "muted"}" style="font-size:12px">${data.ssl ? "SSL Enabled" : "HTTP"}</span>
            </div>
          </div>

          <div class="field" style="background:var(--surface-2);padding:12px;border-radius:var(--radius);border:1px solid var(--border)">
            <label style="display:flex;align-items:center;justify-content:space-between;cursor:pointer">
              <div>
                <b style="font-size:13px">${icon("globe")} Wildcard Subdomains (*.${esc(primaryDomain)})</b>
                <div class="muted" style="font-size:12px;margin-top:2px">Direct all subdomains (e.g. <code>api.${esc(primaryDomain)}</code>, <code>tenant.${esc(primaryDomain)}</code>) to this project</div>
              </div>
              <input type="checkbox" id="chk-wildcard" ${wildcard ? "checked" : ""} style="width:18px;height:18px;accent-color:var(--accent)">
            </label>
          </div>

          <div>
            <label style="font-weight:600;display:block;margin-bottom:6px">Custom Domain Aliases & Subdomains</label>
            <div style="display:flex;gap:8px;margin-bottom:10px">
              <input type="text" id="input-new-alias" class="input sm" placeholder="e.g. api.${esc(primaryDomain)} or ${esc(site.name)}.local" style="font-family:var(--mono);flex:1">
              <button type="button" id="btn-add-alias" class="btn sm primary">${icon("plus")} Add Alias</button>
            </div>

            <div id="aliases-list-pane" style="display:flex;flex-direction:column;gap:6px">
              ${aliases.length === 0 ? `<div class="muted" style="font-size:12px;padding:8px">No extra domain aliases configured.</div>` : ""}
              ${aliases.map((a, idx) => `
                <div style="display:flex;align-items:center;justify-content:space-between;padding:6px 10px;background:var(--surface);border:1px solid var(--border);border-radius:6px">
                  <span style="font-family:var(--mono);font-size:13px">${esc(a)}</span>
                  <button type="button" class="btn sm danger icon-btn" data-remove-alias="${idx}" title="Remove alias">${icon("trash")}</button>
                </div>
              `).join("")}
            </div>
          </div>
        `;

        $("#chk-wildcard", content).addEventListener("change", (e) => {
          wildcard = e.target.checked;
        });

        const newAliasInput = $("#input-new-alias", content);
        const addAliasBtn = $("#btn-add-alias", content);

        function addAlias() {
          const val = newAliasInput.value.trim().toLowerCase();
          if (!val) return;
          if (val === primaryDomain || aliases.includes(val)) {
            toast("warn", "Alias already exists");
            return;
          }
          aliases.push(val);
          render();
        }

        addAliasBtn.addEventListener("click", addAlias);
        newAliasInput.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            addAlias();
          }
        });

        $$("[data-remove-alias]", content).forEach(b => {
          b.addEventListener("click", () => {
            const idx = parseInt(b.dataset.removeAlias, 10);
            aliases.splice(idx, 1);
            render();
          });
        });
      }

      render();

      saveBtn.addEventListener("click", async () => {
        saveBtn.disabled = true;
        saveBtn.innerHTML = `${icon("spinner")} Applying...`;
        try {
          const res = await call("domains_update", { name: site.name, aliases, wildcard });
          closeModal();
          if (res && res.needs_repair) {
            // Regenerating the nginx config runs as a task so its output (and any sudo prompt) is visible.
            const task = await runAction("repair", { name: site.name });
            if (task) toast("info", "Domains saved", "Applying the new nginx config…");
          } else {
            toast("success", "Domains saved");
          }
          refreshSites();
        } catch (err) {
          toast("error", "Failed to update domains", err.message);
          saveBtn.disabled = false;
          saveBtn.innerHTML = `${icon("check")} Save & Apply`;
        }
      });

    } catch (err) {
      content.innerHTML = `<div class="card error-pane">${icon("alert")} Failed to load domains: ${esc(err.message)}</div>`;
    }
  });
}

// ── Universal Command Palette (Feature 8) ──────────────────────────────────
let _paletteItems = [];
let _paletteSelectedIndex = 0;

async function openCommandPalette() {
  const currentSite = state.drawer.name || "";

  openModal(`
    <div class="palette-modal" id="command-palette-modal">
      <div class="palette-header">
        ${icon("search")}
        <input type="text" id="palette-search-input" class="palette-input" placeholder="Type a command, project, or artisan action... (↑↓ to navigate, Enter to run)" autocomplete="off" spellcheck="false">
        <button type="button" class="btn ghost icon-btn sm close" data-dismiss aria-label="Close">${icon("x")}</button>
      </div>
      <div class="palette-results" id="palette-results-list">
        <div class="muted" style="text-align:center;padding:24px">${icon("spinner")} Loading commands...</div>
      </div>
      <div class="palette-footer">
        <span><kbd>↑</kbd> <kbd>↓</kbd> Navigate</span>
        <span><kbd>↵</kbd> Select</span>
        <span><kbd>Esc</kbd> Close</span>
      </div>
    </div>
  `, (root) => {
    const input = $("#palette-search-input", root);
    const list = $("#palette-results-list", root);
    _paletteSelectedIndex = 0;

    async function executeItem(item) {
      if (!item) return;
      closeModal();
      if (item.action === "open_site") {
        openDrawer(item.params.name);
      } else if (item.action === "nav") {
        setView(item.params.view);
      } else if (item.action === "open_modal") {
        addSiteModal(item.params.modal);
      } else if (item.action === "artisan_run") {
        const site = siteByName(item.params.name);
        if (site) {
          openDrawer(site.name, "overview");
          toast("info", `Running php artisan ${item.params.command}...`);
          try {
            const ret = await call("artisan_run", { name: site.name, command: item.params.command });
            toast("success", ret.output || `artisan ${item.params.command} finished`);
          } catch (err) {
            toast("error", `Artisan ${item.params.command} failed`, err.message);
          }
        }
      } else if (item.action === "service_action") {
        try {
          await call("service_action", { service: item.params.service, op: item.params.operation });
          toast("success", `Service ${item.params.service} ${item.params.operation}ed`);
        } catch (err) {
          toast("error", `Service action failed`, err.message);
        }
      }
    }

    function renderItems() {
      if (!_paletteItems.length) {
        list.innerHTML = `<div class="muted" style="text-align:center;padding:32px 16px">No commands or projects matched your query.</div>`;
        return;
      }

      let currentCategory = "";
      let html = "";

      _paletteItems.forEach((item, idx) => {
        const cat = item.category || "commands";
        if (cat !== currentCategory) {
          currentCategory = cat;
          const catLabel = cat === "projects" ? "Projects" :
                           cat === "artisan" ? "Artisan Commands" :
                           cat === "navigation" ? "Navigation" : "System Actions";
          html += `<div class="palette-category-label">${catLabel}</div>`;
        }

        const isSelected = idx === _paletteSelectedIndex;
        const badge = item.category === "projects" ? "↵ Open" :
                      item.category === "artisan" ? "↵ Run" : "↵ Select";

        html += `
          <div class="palette-item ${isSelected ? "selected" : ""}" data-palette-index="${idx}">
            <div class="palette-item-left">
              <div class="palette-item-icon">${icon(item.icon || "terminal")}</div>
              <div class="palette-item-text">
                <div class="palette-item-title">${esc(item.title)}</div>
                <div class="palette-item-sub">${esc(item.subtitle || "")}</div>
              </div>
            </div>
            <span class="palette-badge">${badge}</span>
          </div>
        `;
      });

      list.innerHTML = html;

      const selectedEl = $(".palette-item.selected", list);
      if (selectedEl) {
        selectedEl.scrollIntoView({ block: "nearest" });
      }

      $$(".palette-item", list).forEach(el => {
        el.addEventListener("mouseenter", () => {
          _paletteSelectedIndex = parseInt(el.dataset.paletteIndex, 10);
          $$(".palette-item", list).forEach(x => x.classList.remove("selected"));
          el.classList.add("selected");
        });
        el.addEventListener("click", () => {
          const idx = parseInt(el.dataset.paletteIndex, 10);
          executeItem(_paletteItems[idx]);
        });
      });
    }

    async function search(q = "") {
      try {
        const res = await call("palette_search", { query: q, site_name: currentSite });
        _paletteItems = res.items || [];
        _paletteSelectedIndex = 0;
        renderItems();
      } catch (err) {
        list.innerHTML = `<div class="card error-pane">${esc(err.message)}</div>`;
      }
    }

    input.addEventListener("input", () => {
      search(input.value.trim());
    });

    input.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        if (_paletteItems.length > 0) {
          _paletteSelectedIndex = (_paletteSelectedIndex + 1) % _paletteItems.length;
          renderItems();
        }
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        if (_paletteItems.length > 0) {
          _paletteSelectedIndex = (_paletteSelectedIndex - 1 + _paletteItems.length) % _paletteItems.length;
          renderItems();
        }
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (_paletteItems.length > 0) {
          executeItem(_paletteItems[_paletteSelectedIndex]);
        }
      }
    });

    search("");
    setTimeout(() => input.focus(), 40);
  });
}


/* ── events ─────────────────────────────────────────────────────────────── */
function siteFromEvent(target) {
  const row = target.closest("[data-site]");
  return row ? row.dataset.site : state.drawer.name;
}

document.addEventListener("click", async (e) => {
  const t = e.target instanceof Element ? e.target : e.target?.parentElement;
  if (!t || typeof t.closest !== "function") return;

  const dismiss = t.closest("[data-dismiss], .modal-close, .dialog-close, [data-close-modal], #perf-modal-close, #btn-route-tester-close, button.close");
  if (dismiss && $("#modal-root")?.contains(dismiss)) {
    closeModal();
    return;
  }

  if (t.closest("#activity-close")) {
    closeActivity();
    return;
  }

  const closeDiff = t.closest("[data-close-diff]");
  if (closeDiff) {
    const viewer = document.getElementById(`git-diff-viewer-${closeDiff.dataset.closeDiff}`);
    if (viewer) viewer.hidden = true;
    return;
  }

  const nav = t.closest(".nav-item");
  if (nav) return setView(nav.dataset.view);

  const open = t.closest("[data-open]");
  if (open) { e.stopPropagation(); return openOn(open.dataset.open, siteFromEvent(open)); }

  const openUrl = t.closest("[data-open-url]");
  if (openUrl) {
    e.stopPropagation();
    return LD.call("open", { target: "url", url: openUrl.dataset.openUrl });
  }

  const openDb = t.closest("[data-open-db]");
  if (openDb) {
    e.stopPropagation();
    closeDrawer();
    setView("database");
    window.Database?.openSite(openDb.dataset.openDb);
    return;
  }

  const shareBtn = t.closest("[data-share-site]");
  if (shareBtn) return openShareModal(shareBtn.dataset.shareSite);

  const domainsBtn = t.closest("[data-manage-domains]");
  if (domainsBtn) return openDomainManagerModal(domainsBtn.dataset.manageDomains);

  const linkBtn = t.closest("[data-link-site]");
  if (linkBtn) {
    const site = siteByName(siteFromEvent(linkBtn));
    return addSiteModal("link", { path: site.path, name: slugify(site.name), type: site.type });
  }

  const add = t.closest("[data-add]");
  if (add) return addSiteModal(add.dataset.add);

  const row = t.closest(".site-row[data-site]");
  if (row) return state.drawer.name === row.dataset.site ? closeDrawer() : openDrawer(row.dataset.site);

  if (t.closest("[data-close-drawer], .drawer-close, [aria-label='Close drawer'], #btn-close-drawer") || t.id === "drawer-scrim") return tryCloseDrawer();

  const moreBtn = t.closest(".more-btn");
  if (moreBtn) {
    const menu = $("#tabs-more-menu");
    if (menu) menu.hidden = !menu.hidden;
    return;
  }
  const moreMenu = $("#tabs-more-menu");
  if (moreMenu && !moreMenu.hidden && !t.closest(".tabs-more")) {
    moreMenu.hidden = true;
  }

  const tab = t.closest("[data-tab]");
  if (tab) {
    if (state.drawer.tab === "env" && tab.dataset.tab !== "env" && window.EnvEditor?.dirty()
        && !(await confirmModal({ title: "Discard changes?", message: "You have unsaved environment variables.", confirm: "Discard", danger: true }))) return;
    state.drawer.tab = tab.dataset.tab;
    try {
      localStorage.setItem(`ld_site_tab_${state.drawer.name}`, state.drawer.tab);
    } catch {}
    return renderDrawer(true);
  }

  if (t.closest("[data-log-source]")) {
    state.drawer.logSource = state.drawer.logSource === "app" ? "laravel" : "app";
    return renderDrawer(true);
  }

  const copy = t.closest("[data-copy]");
  if (copy) return copyText(copy.dataset.copy);

  const docRef = t.closest("[data-doctor-refresh]");
  if (docRef) return loadDoctorDiagnostics(docRef.dataset.doctorRefresh, true);

  const auditRef = t.closest("[data-audit-refresh]");
  if (auditRef) return loadPackageAudit(auditRef.dataset.auditRefresh, true);

  const compUpd = t.closest("[data-composer-update]");
  if (compUpd) return runAction("composer", { name: compUpd.dataset.composerUpdate || state.drawer.name, args: "update" });

  const npmFix = t.closest("[data-run-npm-fix]");
  if (npmFix) return runAction("npm", { name: npmFix.dataset.runNpmFix || state.drawer.name, args: "audit fix" });

  const docFix = t.closest("[data-doctor-fix]");
  if (docFix) {
    const fixAction = docFix.dataset.fixAction || "artisan";
    const sName = docFix.dataset.site || state.drawer.name;
    const fixArgs = docFix.dataset.args || docFix.dataset.cmd || (fixAction === "composer" ? "install" : "migrate");
    return runAction(fixAction, { name: sName, args: fixArgs });
  }

  const aiDoc = t.closest("[data-ai-doctor-fix]");
  if (aiDoc) {
    const sName = aiDoc.dataset.aiDoctorFix || state.drawer.name;
    const chkName = aiDoc.dataset.checkName || "";
    const chkMsg = aiDoc.dataset.checkMsg || "";
    return openAiFixModal(sName, {
      message: `${chkName}: ${chkMsg}`,
      prompt: `Doctor diagnostic check "${chkName}" reported an issue: "${chkMsg}". How do I resolve this in my Laravel project? Provide code changes if appropriate.`,
    });
  }

  const autoHeal = t.closest("[data-auto-heal]");
  if (autoHeal) {
    const sName = autoHeal.dataset.autoHeal || state.drawer.name;
    autoHeal.disabled = true;
    try {
      const res = await LD.call("site_doctor_heal", { name: sName });
      toast(res.ok ? "success" : "info", "Auto-Heal Complete", `${(res.fixed || []).length} issue(s) resolved`);
      await loadDoctorDiagnostics(sName, true);
    } catch (err) {
      toast("error", "Auto-Heal Failed", err.message);
    } finally {
      autoHeal.disabled = false;
    }
    return;
  }

  const evModal = t.closest("[data-open-events-modal]");
  if (evModal) return openEventsModal(evModal.dataset.openEventsModal || state.drawer.name);

  const cfgModal = t.closest("[data-open-config-modal]");
  if (cfgModal) return openConfigInspectorModal(cfgModal.dataset.openConfigModal || state.drawer.name);

  const upgModal = t.closest("[data-open-upgrade-modal]");
  if (upgModal) return openUpgradeAssistantModal(upgModal.dataset.openUpgradeModal || state.drawer.name);

  const name = state.drawer.name;

  const action = t.closest("[data-action]");
  if (action) {
    const kind = action.dataset.action;
    if (kind === "delete") {
      const ok = await confirmModal({
        title: `Delete ${name}?`, danger: true, confirm: "Delete forever", requireText: name,
        message: `This permanently deletes <b>${esc(siteByName(name)?.display_path)}</b>, its database and its Nginx config.`,
      });
      if (!ok) return;
    }
    if (kind === "unlink") {
      const ok = await confirmModal({ title: `Unlink ${name}?`, confirm: "Unlink", message: "The site stops being served. Your files and database are kept and you can link it again later." });
      if (!ok) return;
    }
    if (kind === "delete" || kind === "unlink") closeDrawer();
    return runAction(kind, { name });
  }

  const appBtn = t.closest("[data-app]");
  if (appBtn) {
    e.stopPropagation();
    const target = siteFromEvent(appBtn);
    const op = appBtn.dataset.app;
    appBtn.disabled = true;
    try {
      await LD.call(`app_${op}`, { name: target });
      toast("success", `${target} ${{ start: "started", stop: "stopped", restart: "restarted" }[op]}`,
        op === "stop" ? "" : `http://${siteByName(target)?.domain}`);
    } catch (err) {
      toast("error", `Couldn't ${op} ${target}`, err.message);
      if (op !== "stop") {  // show the output so the reason is visible
        if (state.drawer.name === target) { state.drawer.tab = "logs"; renderDrawer(); } else openDrawer(target, "logs");
      }
    }
    return refreshSites();
  }

  const appRun = t.closest("[data-app-run]");
  if (appRun) return runAction(appRun.dataset.appRun, { name });

  const script = t.closest("[data-script]");
  if (script) return runAction("app-script", { name, script: script.dataset.script });

  const manage = t.closest("[data-manage]");
  if (manage) return runAction("manage", { name, args: manage.dataset.manage });

  if (t.closest("[data-app-reset]")) {
    await api("app_config", { name, mode: siteByName(name).mode, command: "" });
    toast("success", "Command reset to default");
    return refreshSites();
  }

  const worker = t.closest("[data-worker]");
  if (worker) return runAction("worker", { name, op: worker.dataset.worker }, { show: false });

  const cron = t.closest("[data-cron]");
  if (cron) return runAction("cron", { name, op: cron.dataset.cron }, { show: false });

  const reverb = t.closest("[data-reverb]");
  if (reverb) return runAction("reverb", { name, op: reverb.dataset.reverb }, { show: false });

  const tunnel = t.closest("[data-tunnel]");
  if (tunnel) {
    const op = tunnel.dataset.tunnel;
    const tName = tunnel.dataset.name || name;
    return runAction("tunnel", { name: tName, op }, { show: false });
  }

  const startCustomTunnel = t.closest("[data-start-custom-tunnel]");
  if (startCustomTunnel) {
    const tName = startCustomTunnel.dataset.startCustomTunnel || name;
    const modeEl = $(`input[name="tunnel-mode-${tName}"]:checked`);
    const mode = modeEl ? modeEl.value : "quick";
    const tokenInput = $(`#tunnel-token-input-${tName}`);
    const token = tokenInput ? tokenInput.value.trim() : "";
    return runAction("tunnel", { name: tName, op: "start", mode, token }, { show: false });
  }

  const qrToggle = t.closest("[data-tunnel-qr-toggle]");
  if (qrToggle) {
    const tName = qrToggle.dataset.tunnelQrToggle || name;
    const box = $(`#tunnel-qr-${tName}`);
    if (box) box.style.display = box.style.display === "none" ? "block" : "none";
    return;
  }

  const logToggle = t.closest("[data-tunnel-log-toggle]");
  if (logToggle) {
    const tName = logToggle.dataset.tunnelLogToggle || name;
    const box = $(`#tunnel-log-box-${tName}`);
    if (box) {
      const isHidden = box.style.display === "none";
      box.style.display = isHidden ? "block" : "none";
      if (isHidden) {
        const out = $(`#tunnel-log-content-${tName}`);
        if (out) {
          out.textContent = "Loading logs…";
          LD.call("tunnel_logs", { name: tName }).then((res) => {
            out.textContent = res.logs || "No logs available.";
          }).catch((err) => {
            out.textContent = `Error: ${err.message}`;
          });
        }
      }
    }
    return;
  }

  const logRefresh = t.closest("[data-tunnel-log-refresh]");
  if (logRefresh) {
    const tName = logRefresh.dataset.tunnelLogRefresh || name;
    const out = $(`#tunnel-log-content-${tName}`);
    if (out) {
      out.textContent = "Refreshing logs…";
      LD.call("tunnel_logs", { name: tName }).then((res) => {
        out.textContent = res.logs || "No logs available.";
      }).catch((err) => {
        out.textContent = `Error: ${err.message}`;
      });
    }
    return;
  }

  const git = t.closest("[data-git]");
  if (git) return runAction("git", { name, op: git.dataset.git });

  const artisan = t.closest("[data-artisan]");
  if (artisan) {
    if (artisan.dataset.confirm && !(await confirmModal({ title: `Run ${artisan.dataset.artisan}?`, message: esc(artisan.dataset.confirm), confirm: "Run", danger: true }))) return;
    return runAction("artisan", { name, args: artisan.dataset.artisan });
  }

  const composer = t.closest("[data-composer]");
  if (composer) return runAction("composer", { name, args: composer.dataset.composer });

  const npmBtn = t.closest("[data-npm]");
  if (npmBtn) return runAction("npm", { name, args: npmBtn.dataset.npm });

  const service = t.closest("[data-service]");
  if (service) return runAction("service", { unit: service.dataset.unit, op: service.dataset.service }, { show: false });

  const servInstall = t.closest("[data-service-install]");
  if (servInstall) {
    const unit = servInstall.dataset.serviceInstall;
    servInstall.disabled = true;
    await runAction("service-install", { name: unit });
    return refreshServices();
  }

  const serviceEnv = t.closest("[data-service-env]");
  if (serviceEnv) {
    const sName = serviceEnv.dataset.serviceEnv;
    let target = state.drawer.name;
    if (!target) {
      const siteNames = (state.sites || []).map((s) => s.name);
      if (siteNames.length === 1) target = siteNames[0];
      else if (siteNames.length > 1) {
        target = await promptModal(`Configure ${sName}`, `Select project name (${siteNames.join(', ')}):`, siteNames[0]);
      }
    }
    if (target) {
      await runAction("service-env", { name: target, service: sName });
      toast("success", `Configured ${sName} in ${target} .env`);
    }
    return;
  }

  const services = t.closest("[data-services]");
  if (services) return runAction("services", { op: services.dataset.services });

  const phpJit = t.closest("[data-php-jit]");
  if (phpJit) {
    const version = phpJit.dataset.phpJit;
    if (state.phpInfo) delete state.phpInfo[version];
    await runAction("php-jit", { version });
    return refreshServices();
  }

  const phpXdebug = t.closest("[data-php-xdebug]");
  if (phpXdebug) {
    const version = phpXdebug.dataset.phpXdebug;
    const enable = phpXdebug.dataset.enable === "1";
    if (state.phpInfo) delete state.phpInfo[version];
    await runAction("php-xdebug", { version, enable });
    return refreshServices();
  }

  const phpIni = t.closest("[data-php-ini]");
  if (phpIni) {
    const version = phpIni.dataset.phpIni;
    const mem = $(`#ini-${version}-memory_limit`)?.value.trim();
    const upload = $(`#ini-${version}-upload_max_filesize`)?.value.trim();
    const time = $(`#ini-${version}-max_execution_time`)?.value.trim();
    if (state.phpInfo) delete state.phpInfo[version];
    if (mem) await runAction("php-ini", { version, key: "memory_limit", value: mem });
    if (upload) await runAction("php-ini", { version, key: "upload_max_filesize", value: upload });
    if (time) await runAction("php-ini", { version, key: "max_execution_time", value: time });
    return refreshServices();
  }

  const phpExt = t.closest("[data-php-ext]");
  if (phpExt) {
    const version = phpExt.dataset.phpExt;
    const input = $(`#php-ext-input-${version}`);
    const ext = input ? input.value.trim() : "";
    if (!ext) return;
    if (state.phpInfo) delete state.phpInfo[version];
    await runAction("php-ext", { version, ext });
    if (input) input.value = "";
    return refreshServices();
  }

  const phpInstall = t.closest("[data-php-install]");
  if (phpInstall) {
    const version = phpInstall.dataset.phpInstall;
    confirmModal({
      title: `${window.t("php_install_btn", "Install")} PHP ${version}`,
      message: `Install PHP ${version} with FPM and standard Laravel extensions (MySQL, PgSQL, SQLite, Redis, cURL, mbstring, XML, Zip)?`,
      confirmText: window.t("php_install_btn", "Install"),
      run: async () => {
        await runAction("php-install", { version });
        state.phpInstallable = null;
        refreshServices();
      },
    });
    return;
  }

  const unisolate = t.closest("[data-php-unisolate]");
  if (unisolate) {
    const siteName = unisolate.dataset.phpUnisolate;
    await runAction("unisolate", { name: siteName });
    refreshSites();
    return;
  }

  const toggleShim = t.closest("[data-toggle-shim]");
  if (toggleShim) {
    const op = toggleShim.dataset.toggleShim;
    await runAction("shim", { op });
    loadShimStatus();
    return;
  }

  const toggleDns = t.closest("[data-toggle-dns]");
  if (toggleDns) {
    const op = toggleDns.dataset.toggleDns;
    await runAction("dns", { op });
    loadDnsStatus();
    return;
  }

  const togglePark = t.closest("[data-toggle-park]");
  if (togglePark) {
    const op = togglePark.dataset.togglePark;
    await runAction("park", { op });
    loadParkStatus();
    refreshSites();
    return;
  }

  const octaneOp = t.closest("[data-octane-op]");
  if (octaneOp) {
    const siteName = octaneOp.dataset.site;
    const op = octaneOp.dataset.octaneOp;
    if (op === "disable") {
      const ok = await confirmModal({
        title: window.t("octane_disable_btn", "Disable Octane"),
        message: window.t("octane_disable_confirm", "Stop the Octane server and switch the site back to PHP-FPM?"),
        confirm: window.t("octane_disable_btn", "Disable Octane"),
        danger: true,
      });
      if (!ok) return;
    }
    octaneOp.disabled = true;
    await runActionAndWait("octane", { name: siteName, op });
    refreshSites(true);
    reloadOctaneCard(siteName);
    return;
  }

  const octaneLog = t.closest("[data-octane-log]");
  if (octaneLog) return openOctaneLog(octaneLog.dataset.octaneLog);

  const debugBtn = t.closest("[data-debug-session]");
  if (debugBtn) return openDebugSessionModal(debugBtn.dataset.debugSession);

  const task = t.closest("[data-task]");
  if (task) { state.activeTask = task.dataset.task; renderTasks(); const out = $("#task-output"); out.scrollTop = out.scrollHeight; return; }

  const cancel = t.closest("[data-cancel]");
  if (cancel) return api("cancel", { id: cancel.dataset.cancel });

  const pick = t.closest("[data-pick]");
  if (pick) {
    const input = $("#settings-form").elements[pick.dataset.pick];
    const path = await api("pick_folder", { title: "Choose your www folder", current: input.value });
    if (path) input.value = path;
  }
});

document.addEventListener("submit", (e) => {
  const form = e.target;
  if (form.matches("[data-octane-enable-form]")) {
    e.preventDefault();
    const siteName = form.elements.name.value;
    const server = form.elements.server.value;
    const workers = form.elements.workers.value;
    const watch = form.elements.watch?.checked;
    const submit = form.querySelector("[type=submit]");
    if (submit) {
      submit.disabled = true;
      submit.innerHTML = `${icon("refresh")}${t("octane_starting", "Starting…")}`;
    }
    runActionAndWait("octane", { name: siteName, op: "enable", server, workers, watch }).then(() => {
      refreshSites(true);
      reloadOctaneCard(siteName);
    });
    return;
  }
  if (form.matches("[data-php-form]")) {
    e.preventDefault();
    runAction("isolate", { name: state.drawer.name, version: form.elements.php.value });
  }
  if (form.matches("[data-artisan-form]")) {
    e.preventDefault();
    const raw = form.elements.args.value.trim();
    if (!raw) return;
    if (/^composer\s+/i.test(raw)) {
      runAction("composer", { name: state.drawer.name, args: raw.replace(/^composer\s+/i, "") });
    } else if (/^(npm|pnpm|yarn|bun)\s+/i.test(raw)) {
      runAction("npm", { name: state.drawer.name, args: raw });
    } else {
      const args = raw.replace(/^(php\s+)?artisan\s+/i, "");
      if (!args) return;
      runAction("artisan", { name: state.drawer.name, args });
    }
    form.elements.args.value = "";
  }
  if (form.matches("[data-terminal-exec-form]")) {
    e.preventDefault();
    const cmd = form.elements.command.value.trim();
    if (!cmd) return;
    runAction("terminal", { name: state.drawer.name, command: cmd });
    form.elements.command.value = "";
  }
  if (form.matches("[data-composer-form]")) {
    e.preventDefault();
    const args = form.elements.args.value.trim().replace(/^composer\s+/i, "");
    if (!args) return;
    runAction("composer", { name: state.drawer.name, args });
    form.elements.args.value = "";
  }
  if (form.matches("[data-npm-form]")) {
    e.preventDefault();
    const args = form.elements.args.value.trim().replace(/^(npm|pnpm|yarn|bun)\s+/i, "");
    if (!args) return;
    runAction("npm", { name: state.drawer.name, args });
    form.elements.args.value = "";
  }
  if (form.matches("[data-manage-form]")) {
    e.preventDefault();
    const args = form.elements.args.value.trim().replace(/^(python3?\s+)?manage\.py\s+/, "");
    if (!args) return;
    runAction("manage", { name: state.drawer.name, args });
    form.elements.args.value = "";
  }
  if (form.matches("[data-app-config]")) {
    e.preventDefault();
    const site = siteByName(state.drawer.name);
    const mode = form.elements.mode.value;
    // Switching mode without editing the command picks that mode's default.
    const command = mode !== site.mode && form.elements.command.value === site.command ? "" : form.elements.command.value;
    api("app_config", { name: site.name, mode, command }).then(() => {
      toast("success", "Saved", site.running ? "Restart the app to use the new command." : "");
      refreshSites();
    });
  }
  if (form.id === "settings-form") { e.preventDefault(); saveSettings(); }
});

document.addEventListener("change", (e) => {
  const target = e.target;
  if (target && target.name && target.name.startsWith("tunnel-mode-")) {
    const tName = target.name.replace("tunnel-mode-", "");
    const wrap = $(`#tunnel-token-wrap-${tName}`);
    if (wrap) wrap.style.display = target.value === "token" ? "block" : "none";
    return;
  }
  const select = target;
  if (!select.matches("[data-app-config] [name=mode]")) return;
  const defaults = state.drawer.details?.default_commands || {};
  const input = select.form.elements.command;
  if (!siteByName(state.drawer.name)?.custom_command && defaults[select.value]) input.value = defaults[select.value];
});

$("#site-search").addEventListener("input", (e) => { state.filter = e.target.value; renderSites(); });
$("#btn-trigger-palette")?.addEventListener("click", () => openCommandPalette());
$("#add-site").addEventListener("click", () => addSiteModal("new"));
$("#refresh-sites").addEventListener("click", () => { refreshSites(); refreshServices(); });
$("#activity-toggle").addEventListener("click", () => ($("#activity").classList.contains("open") ? closeActivity() : openActivity()));
$("#activity-close").addEventListener("click", closeActivity);
$("#save-settings").addEventListener("click", saveSettings);
$("#btn-check-updates")?.addEventListener("click", () => loadVersionCheck(true));

$("#btn-settings-export")?.addEventListener("click", async () => {
  try {
    const data = await LD.call("settings_export");
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `laravel-dev-settings-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast("success", "Settings exported successfully");
  } catch (err) {
    toast("error", "Export failed", err.message);
  }
});

const importFile = $("#settings-import-file");
$("#btn-settings-import")?.addEventListener("click", () => {
  importFile?.click();
});
importFile?.addEventListener("change", async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    const res = await LD.call("settings_import", { data: parsed });
    if (res.ok) {
      toast("success", "Settings imported successfully", `Imported ${res.imported_servers || 0} server profiles.`);
      renderSettings();
    } else {
      toast("error", "Import failed", res.error);
    }
  } catch (err) {
    toast("error", "Invalid settings file", err.message);
  } finally {
    importFile.value = "";
  }
});
$("#settings-language")?.addEventListener("change", (e) => {
  window.I18N?.setLang(e.target.value);
});
window.addEventListener("langchange", () => {
  renderSites();
  renderServices();
  renderDrawer(true);
});

document.addEventListener("keydown", (e) => {
  const ctrl = e.ctrlKey || e.metaKey;
  if (ctrl && (e.key.toLowerCase() === "k" || e.code === "KeyK")) {
    e.preventDefault();
    openCommandPalette();
    return;
  }
  if (e.key === "Escape") {
    if (!$("#modal-root").hidden) return closeModal();
    if ($("#activity").classList.contains("open")) return closeActivity();
    if ($("#site-drawer").classList.contains("open")) return tryCloseDrawer();
  }
  if (!$("#modal-root").hidden) return;

  // Arrow navigation between tabs when focused inside [role="tablist"]
  if (e.target && e.target.closest && e.target.closest('[role="tablist"]')) {
    const list = e.target.closest('[role="tablist"]');
    const tabs = Array.from(list.querySelectorAll('[role="tab"]'));
    const idx = tabs.indexOf(e.target);
    if (idx !== -1) {
      if (e.key === "ArrowRight" || e.key === "ArrowDown") {
        e.preventDefault();
        const next = tabs[(idx + 1) % tabs.length];
        next.focus();
        next.click();
        return;
      } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
        e.preventDefault();
        const prev = tabs[(idx - 1 + tabs.length) % tabs.length];
        prev.focus();
        prev.click();
        return;
      } else if (e.key === "Home") {
        e.preventDefault();
        tabs[0].focus();
        tabs[0].click();
        return;
      } else if (e.key === "End") {
        e.preventDefault();
        tabs[tabs.length - 1].focus();
        tabs[tabs.length - 1].click();
        return;
      }
    }
  }

  if (ctrl && e.key.toLowerCase() === "k") { e.preventDefault(); window.Productivity?.toggleCommandPalette(); }
  if (ctrl && e.key.toLowerCase() === "n" && state.view === "sites") { e.preventDefault(); addSiteModal("new"); }
  if (ctrl && e.key.toLowerCase() === "f" && state.view !== "database") { e.preventDefault(); setView("sites"); $("#site-search").focus(); }
  if (ctrl && e.key.toLowerCase() === "r") { e.preventDefault(); refreshSites(); refreshServices(); }
  if (ctrl && e.key === "`") { e.preventDefault(); $("#activity").classList.contains("open") ? closeActivity() : openActivity(); }
  if (ctrl && ["1", "2", "3", "4", "5", "6", "7"].includes(e.key)) { e.preventDefault(); setView(["sites", "database", "servers", "cloudflare", "github", "services", "settings"][+e.key - 1]); }
});

function initA11yObserver() {
  const syncLabels = (root) => {
    $$("button[title]:not([aria-label]), a[title]:not([aria-label])", root).forEach((el) => {
      el.setAttribute("aria-label", el.title);
    });
  };
  syncLabels(document.body);
  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      m.addedNodes.forEach((node) => {
        if (node.nodeType === 1) {
          if (node.matches?.("button[title]:not([aria-label]), a[title]:not([aria-label])")) {
            node.setAttribute("aria-label", node.title);
          }
          syncLabels(node);
        }
      });
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

/* ── boot ───────────────────────────────────────────────────────────────── */
async function boot() {
  $$("[data-icon]").forEach((el) => (el.outerHTML = icon(el.dataset.icon)));
  renderSites();
  if (!window.webkit?.messageHandlers?.ld && !window.pywebview?.api) {
    // pywebview (macOS/Windows) injects its bridge just after the page loads.
    await new Promise((resolve) => { window.addEventListener("pywebviewready", resolve, { once: true }); setTimeout(resolve, 1500); });
  }
  try {
    const init = await LD.call("init");
    Object.assign(state, {
      home: init.home, settings: init.settings, prefs: init.prefs, editors: init.editors, mode: init.mode || "managed",
      platform: init.platform || "linux", phpVersions: init.php_versions, tray: init.tray, sites: init.sites,
      services: init.services, vault: init.vault, loaded: true,
    });
    window.Productivity?.init();
    document.documentElement.dataset.platform = state.platform;
    if (init.config_dir) $("#settings-subtitle").textContent = `Saved to ${init.config_dir}`;
    if (!managed()) {
      $$("[data-services]").forEach((b) => (b.hidden = true));
      $("#view-services h1").textContent = "Tools";
      $("#view-services .subtitle").textContent = "What Laravel Dev uses from your PATH.";
      $("#php-section-title").hidden = true;
      $(".nav-item[data-view=services]").lastChild.textContent = "Tools";
    }
    init.tasks.forEach((t) => onTaskEvent(t, false));
    $("#version").textContent = init.version ? `v${init.version}` : "";
  } catch (err) {
    state.loaded = true;
    toast("error", "Couldn't load", err.message);
  }
  applyTheme();
  initA11yObserver();
  renderSites();
  renderServices();
  renderTasks();

  setInterval(() => { if (document.visibilityState === "visible") refreshServices(); }, 10000);
  setInterval(() => { if (document.visibilityState === "visible" && !$("#activity").classList.contains("open")) renderTasks(); }, 30000);
}

/* ── demo backend: lets you open ui/web/index.html in a browser to work on the design ── */
const Demo = {
  sites: [
    { name: "shop", type: "laravel", path: "/home/you/Sites/shop", display_path: "~/Sites/shop", domain: "shop.test", url: "http://shop.test", linked: true, exists: true, php: "8.4", branch: "main", worker: true, dev_tools: { horizon: true, telescope: true, pulse: false } },
    { name: "blog", type: "laravel", path: "/home/you/Sites/blog", display_path: "~/Sites/blog", domain: "blog.test", url: "http://blog.test", linked: true, exists: true, php: "8.3", branch: "feature/comments", worker: false },
    { name: "crm-api", type: "laravel", path: "/home/you/code/crm/api", display_path: "~/code/crm/api", domain: "api.crm.test", url: "http://api.crm.test", linked: true, exists: true, php: "8.4", branch: "", worker: false },
    { name: "storefront", type: "nuxt", type_label: "Nuxt", path: "/home/you/Sites/storefront", display_path: "~/Sites/storefront", domain: "storefront.test", url: "http://storefront.test", linked: true, exists: true, php: "", branch: "main", worker: false, port: "4102", running: true, mode: "dev", command: "npm run dev -- --port {port}", custom_command: false },
    { name: "admin-panel", type: "django", type_label: "Django", path: "/home/you/code/admin", display_path: "~/code/admin", domain: "admin.test", url: "http://admin.test", linked: true, exists: true, php: "", branch: "", worker: false, port: "4103", running: false, mode: "dev", command: "{py} manage.py runserver 127.0.0.1:{port}", custom_command: false },
    { name: "playground", type: "laravel", path: "/home/you/Sites/playground", display_path: "~/Sites/playground", domain: "playground.test", url: "http://playground.test", linked: false, exists: true, php: "", branch: "", worker: false },
  ],
  services: [
    { unit: "nginx", label: "Nginx", description: "Web server", kind: "core", status: "active", installed: true },
    { unit: "mariadb", label: "Database", description: "MySQL / MariaDB", kind: "core", status: "active", installed: true },
    { unit: "php8.4-fpm", label: "PHP 8.4 FPM", description: "PHP FastCGI", kind: "core", status: "active", installed: true },
    { unit: "redis-server", label: "Redis", description: "Cache & queues (:6379)", kind: "extra", status: "active", installed: true },
    { unit: "supervisor", label: "Supervisor", description: "Queue workers", kind: "extra", status: "active", installed: true },
    { unit: "mailpit", label: "Mailpit", description: "Email testing (SMTP :1025, Web UI :8025)", kind: "extra", status: "active", installed: true },
    { unit: "meilisearch", label: "Meilisearch", description: "Full-text search engine (:7700)", kind: "extra", status: "not_installed", installed: false },
    { unit: "minio", label: "MinIO", description: "Object storage (API :9000, Console :9001)", kind: "extra", status: "not_installed", installed: false },
  ],
  handle(id, method, params) {
    const ok = (data) => setTimeout(() => LD.resolve(id, { ok: true, data }), 120);
    const site = this.sites.find((s) => s.name === params.name);
    switch (method) {
      case "init": return ok({ version: "1.1.0-demo", home: "/home/you", settings: { LARAVEL_SITES_DIR: "/home/you/Sites", DB_TYPE: "mysql", DB_HOST: "127.0.0.1", DB_PORT: "3306", DB_USER: "root", DB_PASSWORD: "" }, prefs: { theme: "system", close_to_tray: true, editor: "code", default_php: "8.4", autostart: false }, php_versions: ["8.3", "8.4"], editors: [{ bin: "code", label: "VS Code" }], tray: true, sites: this.sites, services: this.services, tasks: [] });
      case "sites": return ok(this.sites);
      case "services": return ok(this.services);
      case "site": return ok({ ...site, scripts: site.type === "nuxt" ? { dev: "nuxt dev", build: "nuxt build", generate: "nuxt generate", lint: "eslint ." } : {}, package_manager: site.type === "django" ? "" : "npm", python: site.type === "django" ? "/home/you/code/admin/.venv/bin/python" : "", has_deps: true, deps_installed: site.type !== "django", default_commands: { dev: site.command, prod: "npm run preview" }, laravel: "12.3.0", worker_configured: site.name === "shop", worker_settings: { mode: "", queues: "default", processes: "2", tries: "3", timeout: "90", sleep: "3", has_horizon: false, effective_mode: "queue" }, scheduler: { installed: true, enabled: site.name === "shop", service: "active", unit: "cron" }, has_env: true, git: site.branch ? { branch: site.branch, upstream: true, ahead: 1, behind: 2, changes: 3 } : null, dev_tools: site.dev_tools || { horizon: false, telescope: false, pulse: false } });
      case "queue_status": return ok({ ok: true, worker_running: true, failed_jobs: [], pending_jobs: [], queue_counts: { default: 2 }, dev_tools: { horizon: true, telescope: true, pulse: false }, horizon_status: "running" });
      case "queue_retry": return ok({ ok: true, output: "Job(s) pushed back onto queue" });
      case "queue_forget": return ok({ ok: true, output: "Job(s) deleted" });
      case "queue_delete_pending": return ok({ ok: true, output: "Pending jobs cleared" });
      case "log": return ok({ exists: true, text: "[2026-10-22 10:01:12] local.INFO: Order 1042 created\n[2026-10-22 10:02:40] local.WARNING: Slow query (1.2s)\n[2026-10-22 10:03:05] local.ERROR: Call to undefined method App\\Models\\Order::total()" });
      case "run": {
        const task = { id: String(Date.now()), title: `${params.action} ${params.params.name || params.params.unit || ""}`.trim(), status: "running", started: Date.now() / 1000 };
        ok(task);
        setTimeout(() => LD.onEvent({ type: "task", task }), 150);
        ["Creating project...\n", "Installing dependencies (lock file)\n", "  - Installing laravel/framework (v12.3.0)\n", "Configuring Nginx...\n", "Project Ready\n"].forEach((line, i) =>
          setTimeout(() => LD.onEvent({ type: "output", id: task.id, text: line }), 400 + i * 350));
        setTimeout(() => LD.onEvent({ type: "task", task: { ...task, status: "success", code: 0 }, done: true }), 2400);
        return;
      }
      case "worker_log": return ok({ exists: true, text: "2026-10-22 10:01:12 App\\Jobs\\SendInvoice ........ RUNNING\n2026-10-22 10:01:13 App\\Jobs\\SendInvoice ........ 412ms DONE\n" });
      case "scheduler_log": return ok({ exists: true, text: "2026-10-22 10:05:00 Running ['artisan' inspire] ........ 38ms DONE\n" });
      case "save": return ok({ settings: params.settings, prefs: params.prefs });
      case "php_info": return ok({ version: params.version || "8.4", xdebug: false, memory_limit: "512M", upload_max_filesize: "64M", max_execution_time: "60", extensions: ["curl", "mbstring", "openssl", "pdo_mysql", "xml", "zip"] });
      case "php_installable": return ok({ versions: [
        { version: "7.4", status: "available" },
        { version: "8.0", status: "available" },
        { version: "8.1", status: "available" },
        { version: "8.2", status: "available" },
        { version: "8.3", status: "installed" },
        { version: "8.4", status: "installed" },
        { version: "8.5", status: "available" }
      ] });
      case "node_versions": return ok({ versions: ["18.20.4", "20.18.0", "22.11.0"] });
      case "shim_status": return ok({ status: "enabled" });
      case "dns_status": return ok({ installed: true, enabled: false, resolved_active: true, resolves: false });
      case "park_status": return ok({ enabled: true });
      case "octane_status": return ok({
        project: params.name || "demo-app", enabled: false, running: false, package_installed: false, server: "frankenphp",
        port: 80, workers: "auto", watch: false, url: "",
        requirements: { supervisor: true, swoole: false, node: true, chokidar: false },
      });
      case "debug_write_launch_json": return ok({ ok: true, created: true, path: `/home/you/Sites/${params.name}/.vscode/launch.json`, message: "Created .vscode/launch.json." });
      case "octane_logs": return ok({ log: "INFO  Server running…\n  Local: http://127.0.0.1:4101\n" });
      case "debug_session_status": return ok({
        project: params.name, domain: `${params.name || "shop"}.test`, php: "8.4", runtime: "php-fpm", supported: true,
        armed: false, expires_at: 0, remaining_seconds: 0, ide_port: 9003, xdebug_mode: "",
        checks: { xdebug_installed: false, xdebug_debug_mode: false, trigger_mode: false, vhost_hook: false, flag_dir: false, ide_listening: false },
        ready: false,
      });
      case "webhooks_list": return ok({
        webhooks: [
          {
            id: "whk-demo-001",
            time: Date.now() / 1000 - 120,
            created_at: "2026-11-09 21:15:00",
            method: "POST",
            uri: "/stripe/webhook",
            status: 200,
            duration_ms: 45.2,
            body_size: 1420,
            body_preview: '{"id":"evt_test_123","type":"payment_intent.succeeded"}',
            headers_count: 8
          }
        ]
      });
      case "webhooks_get": return ok({
        webhook: {
          id: "whk-demo-001",
          time: Date.now() / 1000 - 120,
          created_at: "2026-11-09 21:15:00",
          method: "POST",
          uri: "/stripe/webhook",
          url: "http://demo-app.test/stripe/webhook",
          status: 200,
          duration_ms: 45.2,
          headers: {
            "Content-Type": "application/json",
            "Stripe-Signature": "t=1731186900,v1=52576874836e438b855914f6b",
            "User-Agent": "Stripe/1.0 (+https://stripe.com/docs/webhooks)"
          },
          body: JSON.stringify({
            id: "evt_test_123",
            object: "event",
            type: "payment_intent.succeeded",
            data: { object: { amount: 2500, currency: "usd", status: "succeeded" } }
          }),
          response_preview: '{"received":true}'
        }
      });
      case "webhooks_clear": return ok({ ok: true });
      case "webhooks_replay": return ok({ target: "http://demo-app.test/stripe/webhook", method: "POST", status: 200, duration_ms: 38.5, headers: {}, body: '{"received":true}', error: null });
      case "webhooks_curl": return ok({ curl: `curl -X POST "http://demo-app.test/stripe/webhook" -H "Content-Type: application/json" -H "Stripe-Signature: t=1731186900,v1=52576874836e438b855914f6b" --data-raw '{"id":"evt_test_123"}'` });
      case "webhooks_patterns": return ok({ patterns: ["webhook*", "*/webhook*", "stripe/*"] });
      case "webhooks_save_patterns": return ok({ ok: true });
      case "share_info": return ok({ site: params.name, domain_url: `http://${params.name}.test`, lan_ip: "192.168.1.50", lan_port: "8000", lan_url: "http://192.168.1.50:8000", tunnel: { active: false, url: "", started: 0 } });
      case "tunnel_info": return ok({ active: false, url: "", mode: "quick", started: 0 });
      case "tunnel_start": return ok({ ok: true, url: "https://demo-quick-tunnel.trycloudflare.com", mode: params.mode || "quick" });
      case "tunnel_stop": return ok({ ok: true });
      case "tunnel_restart": return ok({ ok: true, url: "https://demo-quick-tunnel.trycloudflare.com", mode: params.mode || "quick" });
      case "tunnel_logs": return ok({ logs: "2026-11-09T17:00:00Z INF Tunnel started\n2026-11-09T17:00:01Z INF Registered tunnel connection\n2026-11-09T17:00:02Z INF Route configured for trycloudflare.com" });
      case "tunnel_token": return ok({ ok: true, token: params.token || "" });
      case "tunnel_list": return ok({ tunnels: [] });
      case "cf_status": return ok({
        configured: true,
        account_id: "demo-account-123456",
        account_name: "Demo Developer Account",
        token_preview: "cf_t...demo",
        token_masked: "cf_t...demo",
        has_token: true,
        total_accounts: 2,
        accounts: [
          { account_id: "demo-account-123456", account_name: "Demo Developer Account", token_preview: "cf_t...demo", is_active: true },
          { account_id: "demo-account-789012", account_name: "Client Production Account", token_preview: "cf_t...prod", is_active: false }
        ]
      });
      case "cf_accounts": return ok({
        ok: true,
        active_id: "demo-account-123456",
        accounts: [
          { account_id: "demo-account-123456", account_name: "Demo Developer Account", token_preview: "cf_t...demo", is_active: true },
          { account_id: "demo-account-789012", account_name: "Client Production Account", token_preview: "cf_t...prod", is_active: false }
        ]
      });
      case "cf_switch_account": return ok({ ok: true, account_id: params.account_id, account_name: "Switched Account" });
      case "cf_remove_account": return ok({ ok: true, removed_id: params.account_id, remaining_count: 1 });
      case "cf_verify_token": return ok({
        valid: true,
        token_id: "demo-token-id",
        status: "active",
        accounts: [{ id: "demo-account-123456", name: "Demo Developer Account" }]
      });
      case "cf_save_credentials": return ok({ ok: true });
      case "cf_disconnect": return ok({ ok: true });
      case "cf_zones": return ok({
        zones: [
          { id: "zone-1", name: "example.com", status: "active", paused: false, name_servers: ["ns1.cloudflare.com", "ns2.cloudflare.com"] },
          { id: "zone-2", name: "myproject.dev", status: "active", paused: false, name_servers: ["ns1.cloudflare.com", "ns2.cloudflare.com"] }
        ]
      });
      case "cf_dns_list": return ok({
        records: [
          { id: "rec-1", type: "A", name: "example.com", content: "192.0.2.1", proxied: true, ttl: 1 },
          { id: "rec-2", type: "CNAME", name: "api.example.com", content: "example.com", proxied: true, ttl: 1 },
          { id: "rec-3", type: "TXT", name: "example.com", content: "v=spf1 include:_spf.google.com ~all", proxied: false, ttl: 3600 }
        ]
      });
      case "cf_dns_save": return ok({ ok: true, record: { id: params.record_id || "rec-new", ...params } });
      case "cf_dns_proxy": return ok({ ok: true, proxied: params.proxied });
      case "cf_dns_delete": return ok({ ok: true });
      case "cf_purge_cache": return ok({ ok: true, purged: params.purge_everything ? "everything" : (params.files || []).length });
      case "cf_dev_mode_get": return ok({ dev_mode: false, time_remaining: 0 });
      case "cf_dev_mode_set": return ok({ ok: true, dev_mode: params.value });
      case "cf_security_level_get": return ok({ level: "medium" });
      case "cf_security_level_set": return ok({ ok: true, level: params.level });
      case "cf_r2_buckets": return ok({
        buckets: [
          { name: "project-uploads", created_at: "2026-01-15T12:00:00Z", jurisdiction: "default" },
          { name: "backups-archive", created_at: "2026-03-01T08:30:00Z", jurisdiction: "default" }
        ],
        account_id: "demo-account-123456"
      });
      case "cf_r2_create_bucket": return ok({ ok: true, name: params.name });
      case "cf_r2_delete_bucket": return ok({ ok: true });
      case "cf_r2_apply_site": return ok({ ok: true, applied_keys: ["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_BUCKET", "AWS_ENDPOINT"] });
      case "cf_tunnels": return ok({
        tunnels: [
          { id: "tun-demo-1", name: "laravel-dev-office", status: "healthy", created_at: "2026-02-10T11:00:00Z", connections: 2 },
          { id: "tun-demo-2", name: "staging-api", status: "inactive", created_at: "2026-02-12T15:20:00Z", connections: 0 }
        ]
      });
      case "cf_tunnel_create": return ok({ ok: true, tunnel: { id: "tun-new-1", name: params.name } });
      case "cf_tunnel_token": return ok({ ok: true, token: "eyJhIjoiZGVtbyIsInQiOiJkZW1vLXRva2VuIn0=" });
      case "cf_tunnel_delete": return ok({ ok: true });
      case "gh_status": return ok({
        configured: true,
        username: "demo-dev",
        account_name: "Demo Developer",
        avatar_url: "https://avatars.githubusercontent.com/u/583231",
        email: "dev@example.com",
        scopes: ["repo", "workflow", "read:org", "admin:public_key"],
        rate_limit_remaining: 4950,
        rate_limit_total: 5000,
        total_accounts: 1
      });
      case "gh_accounts": return ok({
        ok: true,
        active_id: "demo-dev",
        accounts: [{
          account_id: "demo-dev",
          username: "demo-dev",
          account_name: "Demo Developer",
          email: "dev@example.com",
          token_preview: "ghp_****1234",
          is_active: true
        }]
      });
      case "gh_verify_token": return ok({
        valid: true,
        username: "demo-dev",
        name: "Demo Developer",
        avatar_url: "https://avatars.githubusercontent.com/u/583231",
        email: "dev@example.com",
        scopes: ["repo", "workflow", "read:org"]
      });
      case "gh_save_credentials": return ok({ ok: true });
      case "gh_disconnect": return ok({ ok: true });
      case "gh_repos": return ok({
        ok: true,
        repos: [
          {
            id: 101,
            name: "laravel-app",
            full_name: "demo-dev/laravel-app",
            private: false,
            html_url: "https://github.com/demo-dev/laravel-app",
            description: "Modern Laravel web application",
            fork: false,
            default_branch: "main",
            stargazers_count: 14,
            forks_count: 2,
            open_issues_count: 3,
            language: "PHP",
            updated_at: "2026-11-08T14:20:00Z"
          },
          {
            id: 102,
            name: "saas-api",
            full_name: "demo-dev/saas-api",
            private: true,
            html_url: "https://github.com/demo-dev/saas-api",
            description: "Private microservice backend",
            fork: false,
            default_branch: "main",
            stargazers_count: 3,
            forks_count: 0,
            open_issues_count: 1,
            language: "PHP",
            updated_at: "2026-11-09T18:10:00Z"
          }
        ]
      });
      case "gh_create_repo": return ok({ ok: true, name: params.name, full_name: `demo-dev/${params.name}`, html_url: `https://github.com/demo-dev/${params.name}` });
      case "gh_delete_repo": return ok({ ok: true });
      case "gh_clone_repo": return ok({ ok: true, destination: "/home/user/Sites/" + (params.repo_full_name || "repo").split("/").pop() });
      case "gh_pulls": return ok({
        ok: true,
        pulls: [
          {
            id: 201,
            number: 14,
            title: "Add Stripe payment webhooks",
            state: "open",
            user: "demo-dev",
            html_url: "https://github.com/demo-dev/laravel-app/pull/14",
            head: "feature/stripe-webhooks",
            base: "main",
            draft: false,
            created_at: "2026-11-09T10:00:00Z",
            comments: 2
          }
        ]
      });
      case "gh_create_pull": return ok({ ok: true, number: 15, title: params.title });
      case "gh_merge_pull": return ok({ ok: true, merged: true, message: "Pull Request successfully merged" });
      case "gh_close_pull": return ok({ ok: true });
      case "gh_issues": return ok({
        ok: true,
        issues: [
          {
            id: 301,
            number: 8,
            title: "Refactor queue worker supervisor configs",
            state: "open",
            user: "demo-dev",
            html_url: "https://github.com/demo-dev/laravel-app/issues/8",
            labels: ["enhancement"],
            comments: 1,
            created_at: "2026-11-07T12:00:00Z"
          }
        ]
      });
      case "gh_create_issue": return ok({ ok: true, number: 9, title: params.title });
      case "gh_close_issue": return ok({ ok: true });
      case "gh_actions": return ok({
        ok: true,
        runs: [
          {
            id: 401,
            name: "Tests & Code Style",
            head_branch: "main",
            event: "push",
            status: "completed",
            conclusion: "success",
            html_url: "https://github.com/demo-dev/laravel-app/actions/runs/401",
            created_at: "2026-11-09T18:00:00Z"
          }
        ]
      });
      case "gh_trigger_workflow": return ok({ ok: true });
      case "gh_site_git_status": return ok({ ok: true, is_git: true, clean: true, branch: "main", unpushed: 0, remote_url: "https://github.com/demo-dev/laravel-app.git" });
      case "gh_publish_site": return ok({ ok: true, full_name: `demo-dev/${params.repo_name || "project"}`, html_url: `https://github.com/demo-dev/${params.repo_name || "project"}` });
      case "gh_link_site": return ok({ ok: true, remote_url: `https://github.com/${params.repo_full_name}.git` });
      case "tests_run": return ok({
        ok: true,
        total: 3,
        passed: 2,
        failed: 1,
        errors: 0,
        time: 0.24,
        raw_output: "PHPUnit 10.5.45 by Sebastian Bergmann and contributors.\n..F   3 / 3 (100%)\nTime: 0.24s, Memory: 18.00 MB\nThere was 1 failure:\n1) Tests\\Feature\\ExampleTest::test_the_application_returns_a_successful_response\nFailed asserting that 404 is 200.",
        cases: [
          { name: "test_basic_test", class: "Tests\\Unit\\ExampleTest", file: "/home/you/Sites/shop/tests/Unit/ExampleTest.php", line: "15", time: 0.04, status: "passed", message: "" },
          { name: "test_database_connection", class: "Tests\\Unit\\DbTest", file: "/home/you/Sites/shop/tests/Unit/DbTest.php", line: "20", time: 0.08, status: "passed", message: "" },
          { name: "test_the_application_returns_a_successful_response", class: "Tests\\Feature\\ExampleTest", file: "/home/you/Sites/shop/tests/Feature/ExampleTest.php", line: "19", time: 0.12, status: "failed", message: "Failed asserting that 404 is 200." },
        ]
      });
      case "package_audit": return ok({
        ok: true,
        has_composer: true,
        has_npm: true,
        composer_advisories: [
          { package: "guzzlehttp/psr7", title: "Improper header parsing", cve: "CVE-2023-29197", link: "https://github.com/advisories/GHSA-wxmh-65f7-jcvw", affected: "<1.9.1", severity: "high" }
        ],
        composer_outdated: [
          { name: "laravel/framework", version: "v12.2.0", latest: "v12.3.0", status: "semver-safe-update", description: "The Laravel Framework." },
          { name: "monolog/monolog", version: "3.7.0", latest: "3.8.1", status: "semver-safe-update", description: "Sends your logs to files, sockets, etc." }
        ],
        npm_vulnerabilities: 0,
        npm_advisories: []
      });
      case "supervisor_programs": return ok([
        { name: "worker", tag: `laravel-dev-${params.name}`, command: "php artisan queue:work --queue=default", numprocs: 1, status: "running", is_worker: true, log: `laravel-dev-${params.name}.log` },
        { name: "schedule", tag: `laravel-dev-${params.name}-schedule`, command: "php artisan schedule:work", numprocs: 1, status: "running", is_worker: false, log: `laravel-dev-${params.name}-schedule.log` },
      ]);
      case "supervisor_program_log": return ok({ exists: true, text: "2026-10-23 00:05:00 Running ['artisan' inspire] ........ 15ms DONE\n" });
      case "git_info": return ok({
        is_git: true,
        branch: "main",
        branches: ["main", "develop", "feature/auth", "origin/main"],
        files: [
          { status: "M", file: "app/Http/Controllers/UserController.php" },
          { status: "A", file: "routes/api_v2.php" },
          { status: "??", file: ".env.backup" }
        ],
        stashes: ["stash@{0}: WIP on main: 7a8b9c Fix user auth"]
      });
      case "git_diff": return ok({
        diff: "--- a/app/Http/Controllers/UserController.php\n+++ b/app/Http/Controllers/UserController.php\n@@ -15,4 +15,6 @@\n-    return response()->json($user);\n+    $user->updateLastLogin();\n+    return response()->json(['user' => $user, 'token' => $token]);\n"
      });
      case "backup_schedule_get": return ok({
        enabled: true,
        frequency: "daily",
        retention: 5,
        type: "full",
        remote: "",
        last_run: "2026-10-23 02:00",
        last_status: "ok",
        last_log: "Snapshot created: backup_full_20261023_020000.tar.gz (42.5 MB) in 420ms\n"
      });
      case "backup_schedule_set": return ok({ ok: true, message: "Backup schedule updated" });
      case "backup_prune": return ok({ ok: true, kept: params.keep || 5, deleted: 1, deleted_files: ["old_backup.tar.gz"] });
      case "version_check": return ok({ checked_at: Date.now() / 1000, current_version: "1.0.1", latest_version: "1.0.1", has_update: false });
      case "env_read": return ok({
        exists: true,
        content: `APP_NAME=Laravel\nAPP_ENV=local\nAPP_KEY=base64:demoKey1234567890=\nAPP_DEBUG=true\nAPP_URL=http://${params.name || 'shop'}.test\n\nLOG_CHANNEL=stack\n\nDB_CONNECTION=mysql\nDB_HOST=127.0.0.1\nDB_PORT=3306\nDB_DATABASE=shop\nDB_USERNAME=root\nDB_PASSWORD=\n\nCACHE_DRIVER=file\nQUEUE_CONNECTION=database\n`,
        variables: [
          { key: "APP_NAME", value: "Laravel" },
          { key: "APP_ENV", value: "local" },
          { key: "APP_KEY", value: "base64:demoKey1234567890=" },
          { key: "APP_DEBUG", value: "true" },
          { key: "APP_URL", value: `http://${params.name || 'shop'}.test` },
          { key: "DB_CONNECTION", value: "mysql" },
          { key: "DB_DATABASE", value: "shop" }
        ].map((v) => ({ ...v, secret: v.key === "APP_KEY" })),
        file: params.file || ".env",
        files: [".env", ".env.testing"],
        missing: [{ key: "MAIL_MAILER", value: "smtp" }],
        hash: "demo",
        scope: `local:/home/you/Sites/${params.name || "shop"}`,
        type: "laravel",
        config_cached: false,
        running: true,
      });
      case "env_save": return this.handle(id, "env_read", params);
      case "backup_list": {
        const ago = (h) => new Date(Date.now() - h * 3600e3).toISOString().slice(0, 16).replace("T", " ");
        return ok([
          { filename: "shop_20261023_020000_full.tar.gz", size_human: "42.5 MB", type: "full", created_at: ago(12) },
          { filename: "shop_20261022_020000_db.sql.gz", size_human: "3.0 MB", type: "db", created_at: ago(36) },
        ]);
      }
      case "backup_estimate": return ok({ db_human: "3.1 MB", storage_human: "39 MB", total_human: "42 MB" });
      case "site_routes": return ok({ ok: true, routes: [
        { method: "GET|HEAD", uri: "/", name: "home", action: "Closure", middleware: ["web"] },
        { method: "GET|HEAD", uri: "orders", name: "orders.index", action: "App\\Http\\Controllers\\OrderController@index", middleware: ["web", "auth"] },
        { method: "POST", uri: "orders", name: "orders.store", action: "App\\Http\\Controllers\\OrderController@store", middleware: ["web", "auth"] },
        { method: "GET|HEAD", uri: "orders/{order}", name: "orders.show", action: "App\\Http\\Controllers\\OrderController@show", middleware: ["web", "auth"] },
        { method: "DELETE", uri: "orders/{order}", name: "orders.destroy", action: "App\\Http\\Controllers\\OrderController@destroy", middleware: ["web", "auth"] },
        { method: "GET|HEAD", uri: "api/products", name: "", action: "App\\Http\\Controllers\\Api\\ProductController@index", middleware: ["api"] },
      ] });
      case "models_list": return ok({ ok: true, models: ["App\\Models\\Order", "App\\Models\\Product", "App\\Models\\User"] });
      case "translations_list": return ok({
        ok: true, lang_dir: "lang", locales: ["ar", "en"], total_keys: 4, missing_keys_count: 1,
        rows: [
          { key: "orders.title", source: "php", values: { ar: "الطلبات", en: "Orders" }, files: { ar: "ar/orders.php", en: "en/orders.php" }, missing: false },
          { key: "orders.empty", source: "php", values: { ar: null, en: "No orders yet" }, files: { en: "en/orders.php" }, missing: true },
          { key: "Welcome back", source: "json", values: { ar: "مرحباً بعودتك", en: "Welcome back" }, missing: false },
          { key: "Sign out", source: "json", values: { ar: "تسجيل الخروج", en: "Sign out" }, missing: false },
        ],
      });
      case "translation_save": return ok({ ok: true });
      case "servers": return ok([
        { id: "srv-prod-1", name: "Production Web 01", host: "198.51.100.10", user: "deploy", port: 22, auth: "key", php: "8.4" },
        { id: "srv-staging", name: "Staging Server", host: "198.51.100.25", user: "forge", port: 22, auth: "agent", php: "8.3" }
      ]);
      case "backups_list": return ok([
        { filename: "shop_20261023_020000_full.tar.gz", size: 44564480, size_formatted: "42.5 MB", type: "full", created: Date.now() / 1000 - 3600 * 12 },
        { filename: "shop_20261022_020000_db.sql.gz", size: 3145728, size_formatted: "3.0 MB", type: "db", created: Date.now() / 1000 - 3600 * 36 }
      ]);
      case "checkpoint_list": return ok({ ok: true, checkpoints: [
        { id: "cp_demo_1", timestamp: Date.now() / 1000 - 3600, created_at: "2026-10-24 19:30:00", note: "Before auth migration", git_branch: "main", git_commit: "a8f3b21", has_db: true, has_env: true, has_storage: true, total_size: 4194304 },
        { id: "cp_demo_2", timestamp: Date.now() / 1000 - 86400, created_at: "2026-10-23 15:00:00", note: "Initial setup checkpoint", git_branch: "main", git_commit: "91b8f42", has_db: true, has_env: true, has_storage: false, total_size: 2097152 }
      ] });
      case "checkpoint_create": return ok({ ok: true, checkpoint: { id: "cp_new", timestamp: Date.now() / 1000, created_at: "Just now", note: params.note || "Manual Checkpoint", total_size: 3145728, has_db: true, has_env: true } });
      case "checkpoint_restore": return ok({ ok: true, message: "Checkpoint restored successfully" });
      case "checkpoint_delete": return ok({ ok: true });
      case "cache_list": return ok({
        ok: true,
        driver: "redis",
        total: 3,
        keys: [
          { key: "framework:cache:user_982", ttl: 342, type: "string", size: 512, preview: '{"id":982,"name":"Ahmed Al-Ali","role":"admin"}' },
          { key: "settings:general", ttl: -1, type: "hash", size: 1024, preview: '{"site_name":"DevShop","theme":"dark"}' },
          { key: "session:token_expired", ttl: 0, type: "string", size: 64, preview: "expired_token_data" }
        ]
      });
      case "cache_get": return ok({
        ok: true,
        key: params.key || "framework:cache:user_982",
        ttl: 342,
        raw: '{"id":982,"name":"Ahmed Al-Ali","role":"admin","permissions":["superadmin","view_dashboard","manage_users"]}',
        value: { id: 982, name: "Ahmed Al-Ali", role: "admin", permissions: ["superadmin", "view_dashboard", "manage_users"] }
      });
      case "cache_delete": return ok({ ok: true, message: "Cache key deleted" });
      case "cache_flush": return ok({ ok: true, message: "Cache flushed successfully" });
      case "domains_get": return ok({
        ok: true,
        name: params.name || "shop",
        primary_domain: `${params.name || "shop"}.test`,
        aliases: [`api.${params.name || "shop"}.test`, `admin.${params.name || "shop"}.test`],
        wildcard: true,
        ssl: true
      });
      case "domains_update": return ok({ ok: true, message: "Domains and Nginx configuration updated successfully" });
      case "site_resources": return ok({
        ok: true,
        name: params.name || "shop",
        process_count: 2,
        cpu_percent: 1.4,
        memory_mb: 52.8,
        runaway: false,
        runaway_process: null,
        processes: [
          { pid: 4812, cpu: 1.2, memory_mb: 34.0, command: "php artisan queue:work" },
          { pid: 4910, cpu: 0.2, memory_mb: 18.8, command: "npm run dev" }
        ]
      });
      case "site_kill_process": return ok({ ok: true, message: "Process terminated" });
      case "palette_search": return ok({
        ok: true,
        query: params.query || "",
        items: [
          { id: "p1", title: "Open Project: shop", subtitle: "shop.test · Laravel · ~/Sites/shop", category: "projects", icon: "folder", action: "open_site", params: { name: "shop" } },
          { id: "p2", title: "php artisan migrate", subtitle: "Run database migrations (shop)", category: "artisan", icon: "database", action: "artisan_run", params: { name: "shop", command: "migrate" } },
          { id: "p3", title: "php artisan cache:clear", subtitle: "Flush application cache store (shop)", category: "artisan", icon: "trash", action: "artisan_run", params: { name: "shop", command: "cache:clear" } },
          { id: "p4", title: "Open Database Studio", subtitle: "SQL query runner and schema inspector", category: "navigation", icon: "database", action: "nav", params: { view: "database" } },
          { id: "p5", title: "Restart Nginx Web Server", subtitle: "Reload web server configuration", category: "system", icon: "refresh", action: "service_action", params: { service: "nginx", operation: "restart" } },
        ]
      });
      case "vite_status": return ok({
        ok: true,
        has_frontend: true,
        running: false,
        pid: null,
        port: 5173,
        logs: [
          "> dev",
          "> vite",
          "",
          "  VITE v5.4.2  ready in 240 ms",
          "",
          "  ➜  Local:   http://localhost:5173/",
          "  ➜  Network: use --host to expose",
          "  ➜  press h + enter to show help"
        ]
      });
      case "vite_start": return ok({ ok: true, running: true, pid: 6140, port: 5173 });
      case "vite_stop": return ok({ ok: true, message: "Watcher stopped" });
      case "notifications_list": return ok({
        ok: true,
        count: 2,
        notifications: [
          { name: "OrderShippedNotification", channels: ["mail", "sms", "database"], relative_path: "app/Notifications/OrderShippedNotification.php" },
          { name: "ServerAlertNotification", channels: ["slack", "mail", "database"], relative_path: "app/Notifications/ServerAlertNotification.php" }
        ]
      });
      case "notification_preview": return ok({
        ok: true,
        channel: params.channel || "mail",
        name: params.class_name || "OrderShippedNotification",
        subject: "Your order #8291 has been shipped!",
        from: "orders@shop.test",
        to: "customer@example.com",
        sender: "SHOP-AUTH",
        message: "Your order #8291 has shipped via DHL Express. Tracking number: 984210982",
        segments: 1,
        character_count: 75,
        title: ":package: Order Dispatched",
        text: "Order #8291 has been handed to the courier service.",
        html: "<div style='padding:20px;font-family:sans-serif'><h2>Order Shipped!</h2><p>Your order #8291 is on its way.</p></div>",
        id: "d9e84b21-4821-4819-bf91-a8391823901a",
        type: "App\\Notifications\\OrderShippedNotification",
        notifiable_type: "App\\Models\\User",
        notifiable_id: 1,
        created_at: "2 minutes ago",
        data: { order_id: 8291, tracking: "984210982", carrier: "DHL Express" }
      });
      case "http_mocks_list": return ok({
        ok: true,
        count: 1,
        rules: [
          { id: "rule_1", url_pattern: "https://api.openai.com/v1/*", method: "POST", status: 200, response: { choices: [{ message: { content: "Mocked AI Response" } }] }, enabled: true }
        ],
        profiler_installed: true,
      });
      case "http_mocks_save": return ok({ ok: true, count: (params.rules || []).length });
      case "http_mock_test": return ok({ ok: true, matched: true, result: { status: 200 } });
      case "http_outgoing_logs": return ok({
        ok: true,
        count: 2,
        calls: [
          { id: "call_1", method: "POST", url: "https://api.openai.com/v1/chat/completions", status: 200, duration_ms: 42.1, mocked: true, rule_id: "rule_1", from: "POST /chat" },
          { id: "call_2", method: "GET", url: "https://api.stripe.com/v1/charges/ch_test_984", status: 200, duration_ms: 315.6, mocked: false, from: "GET /orders/984" }
        ]
      });
      case "media_list": return ok({
        ok: true,
        total_files: 3,
        total_size: 1485760,
        total_size_formatted: "1.4 MB",
        symlink: { linked: true, status: "ok", target: "storage/app/public" },
        files: [
          { filename: "avatar_1.png", relative_path: "avatars/avatar_1.png", storage_url: "/storage/avatars/avatar_1.png", size: 348160, size_formatted: "340 KB", mime_type: "image/png", type: "image", width: 512, height: 512, modified_at: Date.now() / 1000 - 3600 },
          { filename: "banner_hero.webp", relative_path: "banners/banner_hero.webp", storage_url: "/storage/banners/banner_hero.webp", size: 1048576, size_formatted: "1.0 MB", mime_type: "image/webp", type: "image", width: 1920, height: 1080, modified_at: Date.now() / 1000 - 7200 },
          { filename: "terms_and_conditions.pdf", relative_path: "docs/terms_and_conditions.pdf", storage_url: "/storage/docs/terms_and_conditions.pdf", size: 89024, size_formatted: "87 KB", mime_type: "application/pdf", type: "document", width: null, height: null, modified_at: Date.now() / 1000 - 86400 }
        ]
      });
      case "media_delete": return ok({ ok: true, message: "File deleted" });
      case "media_fix_symlink": return ok({ ok: true, message: "Symlink repaired" });
      case "dumps_status": return ok({ running: true, site_active: true, sites_count: 1, config_cached: false });
      case "dumps_list": return ok([]);
      case "perf_status": return ok({ nginx_available: true, profiler_installed: true, profiler_active: true });
      case "perf_telescope": return ok({
        ok: true,
        site: params.name || "shop",
        category: params.category || "requests",
        framework: "Laravel",
        summary: {
          total_requests: 84,
          avg_duration_ms: 54.3,
          p50_ms: 38.2,
          p95_ms: 184.2,
          p99_ms: 420.0,
          error_count: 2,
          error_rate: 2.4,
          total_queries: 42,
          n_plus_one_count: 1,
          framework: "Laravel"
        },
        requests: [
          {
            id: "req-demo-1",
            time: Date.now() / 1000 - 120,
            method: "GET",
            uri: "/products",
            route: "products.index",
            action: "App\\Http\\Controllers\\ProductController@index",
            status: 200,
            duration_ms: 82.5,
            upstream_time_ms: 68.3,
            memory_peak_mb: 18.4,
            query_count: 18,
            query_time_ms: 42.1,
            n_plus_one_count: 1,
            queries: [
              { sql: "select * from `categories` where `id` = ?", time_ms: 2.1, connection: "mysql", file: "app/Http/Controllers/ProductController.php", line: 42, bindings: [1] },
              { sql: "select * from `products` where `active` = 1 order by `id` desc limit 20", time_ms: 14.2, connection: "mysql", file: "app/Http/Controllers/ProductController.php", line: 36, bindings: [] }
            ],
            timeline: [
              { name: "Framework Boot", type: "boot", start_ms: 0.0, duration_ms: 14.2, percentage: 17.2 },
              { name: "Database (18 queries)", type: "database", start_ms: 14.2, duration_ms: 42.1, percentage: 51.0 },
              { name: "Application", type: "app", start_ms: 56.3, duration_ms: 26.2, percentage: 31.8 }
            ]
          },
          {
            id: "req-demo-2",
            time: Date.now() / 1000 - 240,
            method: "POST",
            uri: "/api/cart/add",
            status: 200,
            duration_ms: 34.2,
            upstream_time_ms: 30.1,
            query_count: 4,
            query_time_ms: 8.5,
            n_plus_one_count: 0,
            queries: []
          },
          {
            id: "req-demo-3",
            time: Date.now() / 1000 - 360,
            method: "GET",
            uri: "/api/v1/faulty",
            status: 500,
            duration_ms: 95.4,
            upstream_time_ms: 92.0,
            query_count: 2,
            query_time_ms: 4.1,
            n_plus_one_count: 0,
            queries: []
          }
        ],
        queries: [
          {
            sql: "select * from `categories` where `id` = ?",
            normalized: "select * from `categories` where `id` = ?",
            bindings: [1],
            count: 12,
            total_time_ms: 24.5,
            avg_time_ms: 2.04,
            slow: false,
            connection: "mysql",
            caller: "app/Http/Controllers/ProductController.php:42",
            file: "app/Http/Controllers/ProductController.php",
            line: 42,
            is_n_plus_one: true,
            recent_requests: ["/products"],
            query_type: "SELECT",
            min_time_ms: 1.8, max_time_ms: 2.2, p95_time_ms: 2.2, request_count: 1,
            callers: [{ file: "app/Http/Controllers/ProductController.php", line: 42, count: 12 }],
            executions: [101, 102, 103, 104, 105].map((id, i) => ({
              time_ms: 1.8 + i / 10, bindings: [id], interpolated_sql: `select * from \`categories\` where \`id\` = ${id}`,
              file: "app/Http/Controllers/ProductController.php", line: 42,
              request_id: "req-demo-1", request: "GET /products", request_time: Date.now() / 1000 - 120, start_ms: 20 + i * 2.5,
            })),
          },
          {
            sql: "select count(*) as aggregate from `orders` where `status` = 'pending'",
            normalized: "select count(*) as aggregate from `orders` where `status` = ?",
            bindings: [],
            count: 3,
            total_time_ms: 112.4,
            avg_time_ms: 37.47,
            slow: true,
            connection: "mysql",
            caller: "app/Http/Controllers/ProductController.php:28",
            file: "app/Http/Controllers/ProductController.php",
            line: 28,
            is_n_plus_one: false,
            recent_requests: ["/products", "/admin/analytics"]
          }
        ]
      });
      case "perf_nginx": return ok({
        ok: true,
        exists: true,
        summary: {
          total: 84,
          p50: 38.2,
          p90: 115.4,
          p95: 184.2,
          p99: 420.0,
          avg: 54.3,
          error_count: 2,
          error_rate: 2.4,
          status_counts: { 200: 78, 302: 4, 404: 1, 500: 1 },
          slowest_paths: [
            { path: "/api/orders/export", count: 3, avg_ms: 380.5, max_ms: 420.0 },
            { path: "/checkout/process", count: 8, avg_ms: 210.2, max_ms: 260.4 },
            { path: "/admin/analytics", count: 5, avg_ms: 185.0, max_ms: 215.1 },
            { path: "/products", count: 28, avg_ms: 45.2, max_ms: 98.4 },
            { path: "/login", count: 12, avg_ms: 32.1, max_ms: 64.0 }
          ]
        },
        requests: [
          { time: "2026-10-23T14:40:12+03:00", method: "GET", uri: "/api/orders/export?format=csv", path: "/api/orders/export", status: 200, bytes: 48920, duration_ms: 420.0, upstream_time: "0.418", ip: "127.0.0.1" },
          { time: "2026-10-23T14:39:55+03:00", method: "POST", uri: "/checkout/process", path: "/checkout/process", status: 200, bytes: 1420, duration_ms: 210.2, upstream_time: "0.208", ip: "127.0.0.1" },
          { time: "2026-10-23T14:38:10+03:00", method: "GET", uri: "/products?category=electronics", path: "/products", status: 200, bytes: 18450, duration_ms: 45.2, upstream_time: "0.043", ip: "127.0.0.1" },
          { time: "2026-10-23T14:37:04+03:00", method: "GET", uri: "/legacy-page", path: "/legacy-page", status: 404, bytes: 340, duration_ms: 12.1, upstream_time: "0.011", ip: "127.0.0.1" },
          { time: "2026-10-23T14:35:22+03:00", method: "GET", uri: "/api/v1/faulty", path: "/api/v1/faulty", status: 500, bytes: 840, duration_ms: 95.4, upstream_time: "0.094", ip: "127.0.0.1" }
        ]
      });
      case "perf_requests": return ok({
        ok: true,
        site: params.name || "shop",
        total: 2,
        avg_duration_ms: 58.4,
        avg_queries: 14,
        avg_memory_mb: 16.5,
        n_plus_one_total: 1,
        requests: [
          {
            id: "req-demo-1",
            time: Date.now() / 1000 - 120,
            method: "GET",
            uri: "/products",
            route: "products.index",
            action: "App\\Http\\Controllers\\ProductController@index",
            status: 200,
            duration_ms: 82.5,
            boot_ms: 14.2,
            memory_peak_mb: 18.4,
            query_count: 18,
            query_time_ms: 42.1,
            n_plus_one_count: 1,
            insights: {
              n_plus_one: [
                {
                  pattern: "select * from `categories` where `id` = ?",
                  count: 12,
                  total_time_ms: 24.5,
                  caller: "app/Http/Controllers/ProductController.php:42",
                  file: "app/Http/Controllers/ProductController.php",
                  line: 42,
                  suggestion: "Possible N+1 query. Consider eager loading relationships with ->with('categories')."
                }
              ],
              duplicates: [],
              slow_queries: [
                {
                  sql: "select count(*) as aggregate from `orders` where `status` = 'pending'",
                  time_ms: 112.4,
                  connection: "mysql",
                  caller: "app/Http/Controllers/ProductController.php:28",
                  file: "app/Http/Controllers/ProductController.php",
                  line: 28
                }
              ]
            },
            timeline: [
              { name: "Framework Boot", type: "boot", start_ms: 0.0, duration_ms: 14.2, percentage: 17.2 },
              { name: "Database (18 queries)", type: "database", start_ms: 14.2, duration_ms: 42.1, percentage: 51.0 },
              { name: "Application (ProductController@index)", type: "app", start_ms: 56.3, duration_ms: 26.2, percentage: 31.8 }
            ]
          },
          {
            id: "req-demo-2",
            time: Date.now() / 1000 - 300,
            method: "POST",
            uri: "/api/cart/add",
            route: "cart.add",
            action: "App\\Http\\Controllers\\CartController@add",
            status: 200,
            duration_ms: 34.2,
            boot_ms: 12.0,
            memory_peak_mb: 14.6,
            query_count: 4,
            query_time_ms: 8.5,
            n_plus_one_count: 0,
            insights: { n_plus_one: [], duplicates: [], slow_queries: [] },
            timeline: [
              { name: "Framework Boot", type: "boot", start_ms: 0.0, duration_ms: 12.0, percentage: 35.1 },
              { name: "Database (4 queries)", type: "database", start_ms: 12.0, duration_ms: 8.5, percentage: 24.9 },
              { name: "Application (CartController@add)", type: "app", start_ms: 20.5, duration_ms: 13.7, percentage: 40.0 }
            ]
          }
        ]
      });
      case "perf_detail": return ok({
        ok: true,
        request: {
          id: params.id || "req-demo-1",
          time: Date.now() / 1000 - 120,
          method: "GET",
          uri: "/products?page=2&sort=price",
          query_params: { page: "2", sort: "price" },
          headers: { Host: "shop.test", Accept: "application/json", "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Firefox/131.0", Cookie: "[hidden]", "X-Requested-With": "XMLHttpRequest" },
          request: { url: "http://shop.test/products?page=2&sort=price", ip: "127.0.0.1", content_type: "", is_json: false, cookies: ["laravel_session", "XSRF-TOKEN"], files: [] },
          response: {
            status: 200, content_type: "application/json", size: 1840, body_truncated: false, streamed: false,
            headers: { "content-type": "application/json", "cache-control": "no-cache, private", "x-ratelimit-limit": "60", "x-ratelimit-remaining": "57" },
            cookies: [{ name: "laravel_session", expires: "2026-10-25 14:00:00", http_only: true, secure: false, same_site: "lax" }],
            body: JSON.stringify({ data: [{ id: 1, name: "Pizza", price: 9.5, active: true }, { id: 2, name: "Burger", price: 7, active: false }], meta: { page: 2, total: 42 }, next: null }),
          },
          network: { total_ms: 84.1, upstream_ms: 82.9, upstream_header_ms: 82.7, upstream_connect_ms: 0.4, upstream_status: "200", upstream_addr: "unix:/run/php/php8.4-fpm.sock", bytes: 1840, remote_addr: "127.0.0.1", host: "shop.test", referer: "http://shop.test/", user_agent: "Mozilla/5.0 (X11; Linux x86_64) Firefox/131.0" },
          route: "products.index",
          action: "App\\Http\\Controllers\\ProductController@index",
          status: 200,
          duration_ms: 82.5,
          boot_ms: 14.2,
          memory_peak_mb: 18.4,
          query_count: 18,
          query_time_ms: 42.1,
          n_plus_one_count: 1,
          cache: { hits: 4, misses: 1, writes: 0 },
          views: ["products.index", "layouts.app"],
          events_count: 6,
          http_calls: [
            { url: "https://api.stripe.com/v1/exchange_rates", status: 200, duration_ms: 85.0 }
          ],
          queries: [
            {
              sql: "select * from `products` where `active` = ? order by `id` desc limit 15",
              bindings: [1],
              time_ms: 3.2,
              start_ms: 16.0,
              connection: "mysql",
              file: "app/Http/Controllers/ProductController.php",
              line: 35
            },
            {
              sql: "select * from `categories` where `id` = ?",
              bindings: [101],
              time_ms: 1.8,
              start_ms: 21.5,
              connection: "mysql",
              file: "app/Http/Controllers/ProductController.php",
              line: 42
            },
            {
              sql: "select * from `categories` where `id` = ?",
              bindings: [102],
              time_ms: 2.1,
              start_ms: 24.0,
              connection: "mysql",
              file: "app/Http/Controllers/ProductController.php",
              line: 42
            },
            {
              sql: "select * from `categories` where `id` = ?",
              bindings: [103],
              time_ms: 1.9,
              start_ms: 26.6,
              connection: "mysql",
              file: "app/Http/Controllers/ProductController.php",
              line: 42
            },
            {
              sql: "select * from `categories` where `id` = ?",
              bindings: [104],
              time_ms: 2.0,
              start_ms: 29.1,
              connection: "mysql",
              file: "app/Http/Controllers/ProductController.php",
              line: 42
            },
            {
              sql: "select * from `categories` where `id` = ?",
              bindings: [105],
              time_ms: 2.2,
              start_ms: 31.8,
              connection: "mysql",
              file: "app/Http/Controllers/ProductController.php",
              line: 42
            }
          ],
          insights: {
            n_plus_one: [
              {
                pattern: "select * from `categories` where `id` = ?",
                count: 12,
                total_time_ms: 24.5,
                caller: "app/Http/Controllers/ProductController.php:42",
                file: "app/Http/Controllers/ProductController.php",
                line: 42,
                suggestion: "Possible N+1 query. Consider eager loading relationships with ->with('categories')."
              }
            ],
            duplicates: [],
            slow_queries: []
          },
          timeline: [
            { name: "Framework Boot", type: "boot", start_ms: 0.0, duration_ms: 14.2, percentage: 17.2 },
            { name: "Database (18 queries)", type: "database", start_ms: 14.2, duration_ms: 42.1, percentage: 51.0 },
            { name: "Application (ProductController@index)", type: "app", start_ms: 56.3, duration_ms: 26.2, percentage: 31.8 }
          ]
        }
      });
      case "perf_clear": return ok({ ok: true });
      case "perf_profiler_toggle": return ok({ ok: true, enabled: params.enable });
      case "pick_folder": return ok("/home/you/code/new-app");
      case "detect": return ok(params.path.includes("nuxt") ? "nuxt" : "laravel");
      case "team_config_status": return ok({
        has_config: true,
        file: "herd.yml",
        path: "/home/you/Sites/" + (params.name || "shop") + "/herd.yml",
        matches: true,
        required: { php: "8.4", node: "22", services: ["mysql", "redis"] },
        differences: []
      });
      case "workspaces_list": return ok({
        workspaces: [
          { branch: "feature/auth", domain: (params.name || "shop") + "-feature-auth.test", path: "/home/you/Sites/" + (params.name || "shop") + "/.worktrees/feature-auth", is_current: false }
        ]
      });
      case "instances_list": return ok({
        instances: [
          { type: "redis", name: "cache", port: 6380, active: true, created_at: "2026-11-01" },
          { type: "mysql", name: "analytics", port: 3307, active: false, created_at: "2026-11-05" }
        ]
      });
      case "mcp_test": return ok({ ok: true, elapsed_ms: 1268, protocol: "2025-06-18", tools: 8, projects: 5, server: { name: "laravel-dev-mcp" } });
      case "mcp_status": return ok({
        ok: true,
        clients: [
          { client: "Claude Code", path: "~/.claude.json", exists: true, configured: true, servers: [{ name: "laravel-dev", scope: "project:/home/you/laravel-dev-tool", command: "/opt/laravel-dev/bin/laravel-dev mcp", command_ok: true }] },
          { client: "Cursor", path: "~/.cursor/mcp.json", exists: true, configured: false, servers: [] },
          { client: "Claude Desktop", path: "", exists: false, configured: false, servers: [] },
        ],
        cli: "/usr/local/bin/laravel-dev",
        command: "laravel-dev mcp",
        tools: [
          { name: "list_projects", description: "List all registered projects with their domains, paths, and PHP versions." },
          { name: "get_project_details", description: "Get comprehensive details for a specific project." },
          { name: "get_routes", description: "Get all registered routes for a Laravel project." },
          { name: "get_models", description: "Inspect Eloquent models and schema attributes." },
          { name: "get_recent_logs", description: "Retrieve recent log entries and exceptions from laravel.log." },
          { name: "run_doctor", description: "Run system and project diagnostic checks." },
          { name: "query_database", description: "Execute read-only SQL queries against project database." },
          { name: "run_artisan", description: "Execute artisan CLI commands." }
        ]
      });
      case "ai_propose_fix": return ok({
        ok: true,
        provider: "demo-ai",
        ai_connected: true,
        file_path: "/home/you/Sites/" + (params.name || "shop") + "/app/Http/Controllers/ProductController.php",
        rel_file: "app/Http/Controllers/ProductController.php",
        line: params.line || 42,
        has_backup: false,
        explanation: "The query in ProductController is suffering from an N+1 relationship query pattern when accessing categories. Using eager loading ->with('categories') solves the issue and improves response latency by ~60%.",
        original_content: "<?php\n\nnamespace App\\Http\\Controllers;\n\nuse App\\Models\\Product;\n\nclass ProductController extends Controller\n{\n    public function index()\n    {\n        $products = Product::all();\n        return view('products.index', compact('products'));\n    }\n}\n",
        proposed_content: "<?php\n\nnamespace App\\Http\\Controllers;\n\nuse App\\Models\\Product;\n\nclass ProductController extends Controller\n{\n    public function index()\n    {\n        $products = Product::with('categories')->get();\n        return view('products.index', compact('products'));\n    }\n}\n",
        diff: "--- app/Http/Controllers/ProductController.php\n+++ app/Http/Controllers/ProductController.php\n@@ -9,3 +9,3 @@\n     public function index()\n     {\n-        $products = Product::all();\n+        $products = Product::with('categories')->get();\n         return view('products.index', compact('products'));\n"
      });
      case "ai_settings": return ok({
        provider: "ollama", model: "", ollama_url: "http://127.0.0.1:11434", has_key: false, key_encrypted: false,
        providers: ["ollama", "gemini", "openai", "anthropic"],
        default_models: { ollama: "llama3", gemini: "gemini-2.5-flash", openai: "gpt-4o-mini", anthropic: "claude-sonnet-5-5" },
      });
      case "ai_settings_save": return ok({ provider: params.provider, model: params.model, has_key: !!params.api_key });
      case "ai_test": return ok({ ok: true, provider: "demo-ai", reply: "pong" });
      case "ai_apply_changes": return ok({ success: true, file: params.file_path, backup: (params.file_path || "file") + ".ldbak" });
      case "ai_revert_changes": return ok({ success: true, file: params.file_path });
      case "ai_generate_diff": return ok({ diff: "--- file\n+++ file\n@@ -1,1 +1,1 @@\n-old\n+new\n" });
      default: return ok(true);
    }
  },
};

boot();
