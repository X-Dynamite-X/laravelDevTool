"use strict";

/* Database manager (Navicat-style): a connection tree on the left, tabs for
   databases, tables and SQL editors on the right, all in one window.
   Grid edits are staged and saved in one transaction.
   Uses the helpers defined in app.js (icon, esc, LD, toast, modals). */

const Database = (() => {
  const DRIVERS = { mysql: "MySQL", mariadb: "MariaDB", pgsql: "PostgreSQL", sqlite: "SQLite" };
  const DRIVER_COLORS = { mysql: "#00758f", mariadb: "#c0765a", pgsql: "#336791", sqlite: "#0f80cc" };
  const PAGE_SIZES = [50, 100, 250, 500];
  const KEEP_DATA_TABS = 4; // inactive tabs beyond this drop their rows to save memory

  const S = {
    loaded: false,
    conns: [],
    tree: {},          // conn id -> {open, loading, error, version, databases, dbs: {name: {open, loading, tables, error}}}
    filter: "",
    showSystem: false,
    tabs: [],
    active: null,
    recent: [],        // tab ids, most recent first
    servers: [],
  };
  let seq = 0;
  let menuEl = null;

  const view = () => $("#view-database");
  const conn = (id) => S.conns.find((c) => c.id === id);
  const tab = () => S.tabs.find((t) => t.id === S.active);
  const inDb = (el) => el.closest("#view-database");
  const q = (driver, name) => driver === "mysql" || driver === "mariadb" ? "`" + name.replace(/`/g, "``") + "`" : `"${name.replace(/"/g, '""')}"`;

  function fmtNum(n) {
    if (n === null || n === undefined) return "";
    return n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1e4 ? `${Math.round(n / 1e3)}k` : String(n);
  }
  function fmtBytes(n) {
    if (!n) return "—";
    const u = ["B", "KB", "MB", "GB"];
    const i = Math.min(Math.floor(Math.log(n) / Math.log(1024)), u.length - 1);
    return `${(n / 1024 ** i).toFixed(i ? 1 : 0)} ${u[i]}`;
  }
  function display(value) {
    if (value === null || value === undefined) return `<span class="null">NULL</span>`;
    const text = String(value);
    return esc(text.length > 300 ? text.slice(0, 300) + "…" : text).replace(/\n/g, "↵");
  }

  /* ── data loading ───────────────────────────────────────── */
  async function loadConns(refresh = false) {
    try {
      S.conns = await LD.call("db_connections", { refresh });
    } catch (err) {
      toast("error", "Couldn't load connections", err.message);
    }
    S.loaded = true;
  }

  async function openConn(id, { quiet = false } = {}) {
    const node = S.tree[id] || (S.tree[id] = { open: false, dbs: {} });
    node.open = true;
    node.loading = true;
    node.error = "";
    renderTree();
    try {
      const data = await LD.call("db_databases", { conn: id });
      Object.assign(node, { databases: data.databases, version: data.version, default: data.default, loading: false });
      const c = conn(id);
      if (c) c.open = true;
      if (data.default && data.databases.some((d) => d.name === data.default)) await openDb(id, data.default);
    } catch (err) {
      Object.assign(node, { loading: false, error: err.message });
      if (!quiet) toast("error", `Couldn't connect to ${conn(id)?.name || "database"}`, err.message);
    }
    renderTree();
  }

  async function openDb(id, db, force = false) {
    const node = S.tree[id];
    const dbn = node.dbs[db] || (node.dbs[db] = {});
    dbn.open = true;
    if (dbn.tables && !force) return renderTree();
    dbn.loading = true;
    renderTree();
    try {
      dbn.tables = await LD.call("db_tables", { conn: id, database: db });
      dbn.error = "";
    } catch (err) {
      dbn.error = err.message;
    }
    dbn.loading = false;
    renderTree();
    S.tabs.filter((t) => t.kind === "db" && t.conn === id && t.db === db).forEach(() => renderMain());
  }

  /* ── layout ─────────────────────────────────────────────── */
  function render() {
    const root = view();
    if (!root) return;
    if (!$(".dbm", root)) {
      root.innerHTML = `
        <div class="dbm">
          <aside class="dbm-side">
            <div class="dbm-side-head">
              <b>Connections</b>
              <span class="spacer"></span>
              <button class="btn ghost icon-btn sm" data-db="open-diff" title="Compare Schemas (Schema Diff)">${icon("layers")}</button>
              <button class="btn ghost icon-btn sm" data-db="refresh-conns" title="Refresh">${icon("refresh")}</button>
              <button class="btn ghost icon-btn sm" data-db="new-conn" title="New connection">${icon("plus")}</button>
            </div>
            <div class="search sm dbm-filter">${icon("search")}<input data-db-filter placeholder="Filter tables" autocomplete="off" spellcheck="false"></div>
            <div class="dbm-tree" id="dbm-tree"></div>
          </aside>
          <section class="dbm-main">
            <div class="dbm-tabs" id="dbm-tabs"></div>
            <div class="dbm-content" id="dbm-content"></div>
          </section>
        </div>`;
    }
    renderTree();
    renderTabs();
    renderMain();
  }

  function renderTree() {
    const el = $("#dbm-tree");
    if (!el) return;
    if (!S.loaded) {
      el.innerHTML = `<div class="skeleton" style="height:28px;margin:8px"></div>`.repeat(4);
      return;
    }
    const filter = S.filter.trim().toLowerCase();
    const groups = [
      ["Projects", S.conns.filter((c) => c.source === "site")],
      ["Connections", S.conns.filter((c) => c.source === "local" || c.source === "saved")],
      ["Servers", S.conns.filter((c) => c.source === "server")],
    ].filter(([, list]) => list.length);
    if (!groups.length) {
      el.innerHTML = `<div class="dbm-hint">No connections yet.<br><button class="btn sm primary" data-db="new-conn">${icon("plus")}New connection</button></div>`;
      return;
    }
    el.innerHTML = groups.map(([label, list]) => `
      <div class="dbm-group">${esc(label)}</div>
      ${list.map((c) => connNode(c, filter)).join("")}`).join("");
  }

  function connNode(c, filter) {
    const node = S.tree[c.id] || {};
    const open = node.open;
    const isSsh = Boolean(c.use_ssh || c.ssh_host || c.server);
    const sub = c.driver === "sqlite"
      ? (c.file || "").split(/[\\/]/).pop()
      : `${isSsh ? "SSH · " : ""}${c.server_name ? `${c.server_name} · ` : ""}${c.database || c.host || ""}`;
    let children = "";
    if (open) {
      if (node.loading) children = `<div class="dbm-node dim" style="--depth:1"><span class="spin-dot"></span>Connecting…</div>`;
      else if (node.error) children = `<div class="dbm-node error" style="--depth:1" title="${esc(node.error)}">${icon("alert")}<span class="label">${esc(node.error)}</span></div>`;
      else {
        // A project's connection shows just the project's database until asked for the rest.
        const focused = c.source !== "saved" && c.source !== "local" && node.default && !node.showAll;
        const dbs = (node.databases || []).filter((d) => focused ? d.name === node.default : S.showSystem || !d.system || d.name === node.default);
        children = dbs.map((d) => dbNode(c, d, filter)).join("") || `<div class="dbm-node dim" style="--depth:1">No databases</div>`;
        const hidden = (node.databases || []).length - dbs.length;
        if (hidden > 0) children += focused
          ? `<div class="dbm-node dim link" style="--depth:1" data-db="show-all" data-conn="${esc(c.id)}">Show ${hidden} other database${hidden > 1 ? "s" : ""} on this server</div>`
          : `<div class="dbm-node dim link" style="--depth:1" data-db="show-system">Show ${hidden} system database${hidden > 1 ? "s" : ""}</div>`;
      }
    }
    const colorStyle = c.color ? `border-left: 3px solid ${c.color}; padding-left: 5px;` : "";
    return `
      <div class="dbm-node conn ${open ? "open" : ""}" style="--depth:0; ${colorStyle}" data-node="conn" data-conn="${esc(c.id)}">
        <span class="chev">${icon("back", "flip-down")}</span>
        <span class="drv" style="--c:${c.color || DRIVER_COLORS[c.driver] || "#888"}" title="${esc(DRIVERS[c.driver] || c.driver)}">${esc((DRIVERS[c.driver] || "?").slice(0, 2))}</span>
        <span class="label"><b>${esc(c.name)}</b><small>${esc(sub)}</small></span>
        ${isSsh ? `<span title="SSH Tunneled Connection" style="color:var(--muted);display:grid;place-items:center;">${icon("cloud")}</span>` : ""}
        <span class="dot ${c.open ? "on" : "off"}" title="${c.open ? "Connected" : "Not connected"}"></span>
        <button class="btn ghost icon-btn xs node-more" data-menu="conn" title="More">⋯</button>
      </div>${children}`;
  }

  function dbNode(c, d, filter) {
    const dbn = S.tree[c.id].dbs[d.name] || {};
    let children = "";
    if (dbn.open) {
      if (dbn.loading) children = `<div class="dbm-node dim" style="--depth:2"><span class="spin-dot"></span>Loading…</div>`;
      else if (dbn.error) children = `<div class="dbm-node error" style="--depth:2" title="${esc(dbn.error)}">${icon("alert")}<span class="label">${esc(dbn.error)}</span></div>`;
      else {
        const tables = (dbn.tables || []).filter((t) => !filter || t.name.toLowerCase().includes(filter));
        children = tables.map((t) => `
          <div class="dbm-node table ${isActiveTable(c.id, d.name, t.name) ? "active" : ""}" style="--depth:2" data-node="table" data-conn="${esc(c.id)}" data-dbname="${esc(d.name)}" data-table="${esc(t.name)}" title="${esc(t.name)}${t.comment ? ` — ${esc(t.comment)}` : ""}">
            ${icon(t.view ? "eye" : "grid")}<span class="label">${esc(t.name)}</span>
            <span class="count">${fmtNum(t.rows)}</span>
          </div>`).join("") || `<div class="dbm-node dim" style="--depth:2">${filter ? "No match" : "No tables"}</div>`;
      }
    }
    return `
      <div class="dbm-node db ${dbn.open ? "open" : ""} ${d.system ? "system" : ""}" style="--depth:1" data-node="db" data-conn="${esc(c.id)}" data-dbname="${esc(d.name)}">
        <span class="chev">${icon("back", "flip-down")}</span>${icon("database")}
        <span class="label">${esc(d.name)}</span>
        <button class="btn ghost icon-btn xs node-more" data-db="open-hologram" data-conn="${esc(c.id)}" data-dbname="${esc(d.name)}" title="Hologram (ERD)">${icon("layers")}</button>
        <button class="btn ghost icon-btn xs node-more" data-db="query-here" title="New query">${icon("terminal")}</button>
        <button class="btn ghost icon-btn xs node-more" data-menu="db" title="More">⋯</button>
      </div>${children}`;
  }

  const isActiveTable = (c, d, t) => { const a = tab(); return a && a.kind === "table" && a.conn === c && a.db === d && a.table === t; };

  function renderTabs() {
    const el = $("#dbm-tabs");
    if (!el) return;
    el.innerHTML = S.tabs.map((t) => {
      const dirty = t.kind === "table" && pendingCount(t);
      const label = t.kind === "query" ? t.title : t.kind === "hologram" ? `Hologram · ${t.db}` : t.kind === "diff" ? `Diff · ${t.srcDb || "Source"} ➔ ${t.tgtDb || "Target"}` : t.kind === "db" ? t.db : t.table;
      const ico = t.kind === "query" ? "terminal" : t.kind === "hologram" ? "layers" : t.kind === "diff" ? "layers" : t.kind === "db" ? "database" : "grid";
      return `<button class="dbm-tab ${t.id === S.active ? "active" : ""}" data-tab-id="${t.id}" title="${esc(conn(t.conn)?.name || "")} · ${esc(t.db)}${t.table ? ` · ${esc(t.table)}` : ""}">
        ${icon(ico)}<span>${esc(label)}</span>${dirty ? `<span class="dirty-dot"></span>` : ""}
        <span class="x" data-close-tab="${t.id}">${icon("x")}</span></button>`;
    }).join("") + (S.tabs.length ? `<button class="dbm-tab add" data-db="new-query" title="New query (Ctrl+T)">${icon("plus")}</button>` : "");
  }

  function renderMain() {
    const el = $("#dbm-content");
    if (!el) return;
    const t = tab();
    if (!t) return (el.innerHTML = welcome());
    // Re-rendering replaces the grid: keep its scroll position when it is the same tab.
    const grid = $(".dbm-grid-wrap", el);
    const key = t.id + (t.sub || "");
    const scroll = grid && el.dataset.tab === key ? [grid.scrollTop, grid.scrollLeft] : null;
    el.dataset.tab = key;
    if (t.kind === "db") el.innerHTML = dbTab(t);
    if (t.kind === "table") el.innerHTML = tableTab(t);
    if (t.kind === "hologram") {
      el.innerHTML = hologramTab(t);
      bindHologramEvents(t, el);
    }
    if (t.kind === "diff") {
      el.innerHTML = diffTab(t);
      bindDiffEvents(t, el);
    }
    if (scroll && t.kind !== "query" && t.kind !== "hologram" && t.kind !== "diff") {
      const next = $(".dbm-grid-wrap", el);
      if (next) [next.scrollTop, next.scrollLeft] = scroll;
    }
    if (t.kind === "query") {
      const editor = $(".sql-editor", el);
      if (editor && editor.dataset.tab === t.id) {
        $("#dbm-query-results").innerHTML = queryResults(t);
        $("#dbm-query-bar").innerHTML = queryBar(t);
        return;
      }
      el.innerHTML = queryTab(t);
      const area = $(".sql-editor", el);
      area.value = t.sql;
      area.focus();
    }
  }

  function welcome() {
    const projects = S.conns.filter((c) => c.source === "site");
    return `
      <div class="dbm-welcome">
        <div class="empty-icon">${icon("database")}</div>
        <h2>Databases</h2>
        <p class="muted">Browse and edit MySQL, MariaDB, PostgreSQL and SQLite — your projects' databases are already here, read from their <code>.env</code>. Server databases open through SSH.</p>
        <div class="btn-row" style="justify-content:center">
          <button class="btn primary" data-db="new-conn">${icon("plus")}New connection</button>
          ${S.conns.length ? `<button class="btn" data-db="new-query">${icon("terminal")}New query</button>` : ""}
          ${S.conns.length ? `<button class="btn" data-db="open-diff">${icon("layers")}Schema Diff</button>` : ""}
        </div>
        ${projects.length ? `<div class="dbm-cards">${projects.map((c) => `
          <button class="dbm-card" data-open-conn="${esc(c.id)}">
            <span class="drv" style="--c:${DRIVER_COLORS[c.driver]}">${esc(DRIVERS[c.driver].slice(0, 2))}</span>
            <span><b>${esc(c.name)}</b><small>${esc(c.database || (c.file || "").split(/[\\/]/).pop())}</small></span>
          </button>`).join("")}</div>` : ""}
      </div>`;
  }

  /* ── tabs ───────────────────────────────────────────────── */
  function activate(id) {
    S.active = id;
    S.recent = [id, ...S.recent.filter((r) => r !== id)];
    // Memory: tabs that haven't been looked at for a while forget their rows.
    S.recent.slice(KEEP_DATA_TABS).forEach((rid) => {
      const old = S.tabs.find((t) => t.id === rid);
      if (old && old.kind === "table" && !pendingCount(old)) old.data = null;
      if (old && old.kind === "query") old.results = old.results?.map((r) => (r.rows ? { ...r, rows: [], dropped: true } : r)) || null;
    });
    const t = tab();
    renderTabs();
    renderMain();
    renderTree();
    if (t && t.kind === "table" && !t.data && !t.loading) loadRows(t);
    if (t && t.kind === "db" && !S.tree[t.conn]?.dbs[t.db]?.tables) openDb(t.conn, t.db);
    if (t && t.kind === "hologram" && !t.data && !t.loading) loadHologram(t);
  }

  function openTab(spec) {
    const existing = S.tabs.find((t) => t.kind === spec.kind && t.conn === spec.conn && t.db === spec.db && (spec.kind !== "table" || t.table === spec.table) && spec.kind !== "query");
    if (existing) {
      if (spec.showFilters !== undefined) existing.showFilters = spec.showFilters;
      return activate(existing.id);
    }
    const t = { id: `t${++seq}`, ...spec };
    if (t.kind === "table") Object.assign(t, {
      sub: spec.sub || "data",
      page: 1,
      limit: 100,
      sort: "",
      dir: "ASC",
      where: spec.where || "",
      search: spec.search || "",
      filters: spec.filters ? [...spec.filters] : [],
      showFilters: Boolean(spec.showFilters || (spec.filters && spec.filters.length)),
      showRawWhere: false,
      data: null,
      edits: new Map(),
      inserts: [],
      deletes: new Set(),
      selected: new Set(),
      structure: null
    });
    if (t.kind === "db") Object.assign(t, { tableSearch: "" });
    if (t.kind === "query") Object.assign(t, { title: `Query ${seq}`, sql: spec.sql || "", results: null, running: false, resultIndex: 0 });
    if (t.kind === "hologram") Object.assign(t, { title: `Hologram · ${spec.db}`, zoom: 1, panX: 60, panY: 60, data: null, loading: false, compact: false, filter: "", positions: {} });
    S.tabs.push(t);
    activate(t.id);
  }

  async function closeTab(id) {
    const t = S.tabs.find((x) => x.id === id);
    if (!t) return;
    if (t.kind === "table" && pendingCount(t) && !(await confirmModal({ title: `Discard changes to ${t.table}?`, message: "You have edits that were not saved.", confirm: "Discard", danger: true }))) return;
    const index = S.tabs.indexOf(t);
    S.tabs.splice(index, 1);
    S.recent = S.recent.filter((r) => r !== id);
    if (S.active === id) S.active = S.recent[0] || S.tabs[Math.max(0, index - 1)]?.id || null;
    if (S.active) activate(S.active);
    else { renderTabs(); renderMain(); renderTree(); }
  }

  /* ── database (objects) tab ─────────────────────────────── */
  function dbTab(t) {
    const c = conn(t.conn);
    const dbn = S.tree[t.conn]?.dbs[t.db] || {};
    const tables = dbn.tables || [];
    const search = (t.tableSearch || "").trim().toLowerCase();
    const filtered = search
      ? tables.filter((tb) => tb.name.toLowerCase().includes(search) || (tb.comment && tb.comment.toLowerCase().includes(search)) || (tb.engine && tb.engine.toLowerCase().includes(search)))
      : tables;
    return `
      <div class="dbm-pane">
        <div class="dbm-bar">
          <div class="crumbs-db">${esc(c?.name || "")}<span class="sep">›</span><b>${esc(t.db)}</b>
            ${S.tree[t.conn]?.version ? `<span class="chip">${esc(S.tree[t.conn].version)}</span>` : ""}</div>
          <span class="spacer"></span>
          <button class="btn sm" data-db="open-hologram" data-conn="${esc(t.conn)}" data-dbname="${esc(t.db)}" title="Open interactive schema diagram">${icon("layers")}Hologram (ERD)</button>
          <button class="btn sm" data-db="query-db">${icon("terminal")}New query</button>
          <button class="btn sm" data-db="import">${icon("upload")}Import .sql</button>
          <button class="btn sm" data-db="export-db">${icon("download")}Export</button>
          <button class="btn sm" data-db="snapshots-db" data-conn="${esc(t.conn)}" data-dbname="${esc(t.db)}" title="Save &amp; restore database snapshots">${icon("camera")}Snapshots</button>
          <button class="btn icon-btn sm" data-db="refresh-db" title="Refresh">${icon("refresh")}</button>
        </div>
        <div class="dbm-toolbar" style="background:var(--surface-2);">
          <div class="search sm dbm-table-search" style="width:240px;">
            ${icon("search")}
            <input data-db-table-search placeholder="Filter tables…" value="${esc(t.tableSearch || "")}" autocomplete="off" spellcheck="false">
            ${t.tableSearch ? `<button type="button" class="btn ghost icon-btn xs" data-db-clear-table-search title="Clear">✕</button>` : ""}
          </div>
          <span class="muted" style="font-size:12px;">${filtered.length} ${filtered.length === 1 ? "table" : "tables"}${search ? ` (filtered from ${tables.length})` : ""}</span>
          <span class="spacer"></span>
          <button class="btn sm" data-db="query-db" title="Open SQL Editor">${icon("terminal")} SQL Editor</button>
        </div>
        <div class="dbm-grid-wrap">
          ${dbn.loading && !tables.length ? `<div class="skeleton" style="height:120px;margin:16px"></div>` : `
          <table class="dbg objects">
            <thead><tr><th>Name</th><th class="num">Rows</th><th class="num">Size</th>${c?.driver === "sqlite" ? "" : "<th>Engine</th>"}<th>Comment</th><th style="text-align:right;">Actions</th></tr></thead>
            <tbody>${filtered.map((tb) => `
              <tr data-node="table" data-conn="${esc(t.conn)}" data-dbname="${esc(t.db)}" data-table="${esc(tb.name)}">
                <td>${icon(tb.view ? "eye" : "grid")} <b>${esc(tb.name)}</b>${tb.view ? ` <span class="chip">view</span>` : ""}</td>
                <td class="num">${tb.rows === null ? "—" : `${tb.rows > 0 && c?.driver !== "sqlite" ? "~" : ""}${Number(tb.rows).toLocaleString()}`}</td>
                <td class="num">${fmtBytes(tb.size)}</td>${c?.driver === "sqlite" ? "" : `<td>${esc(tb.engine)}</td>`}
                <td class="muted">${esc(tb.comment)}</td>
                <td class="row-actions" style="white-space:nowrap;">
                  <button class="btn ghost icon-btn xs" data-db-quick-query="${esc(tb.name)}" title="Query this table (${c?.driver === 'mysql' || c?.driver === 'mariadb' ? '`' + esc(tb.name) + '`' : esc(tb.name)})">${icon("terminal")}</button>
                  <button class="btn ghost icon-btn xs" data-db-open-filtered="${esc(tb.name)}" title="Open with filter builder">${icon("filter")}</button>
                  <button class="btn ghost icon-btn xs" data-node="table" data-conn="${esc(t.conn)}" data-dbname="${esc(t.db)}" data-table="${esc(tb.name)}" title="Browse data">${icon("grid")}</button>
                  <button class="btn ghost icon-btn xs" data-menu="table" title="More options">⋯</button>
                </td>
              </tr>`).join("") || `<tr><td colspan="6" class="dbm-hint">${search ? "No tables match your filter." : "No tables in this database."}</td></tr>`}</tbody>
          </table>`}
        </div>
      </div>`;
  }

  /* ── table tab ──────────────────────────────────────────── */
  const pendingCount = (t) => t.kind === "table" ? t.edits.size + t.inserts.length + t.deletes.size : 0;

  async function loadRows(t, { keepPage = true } = {}) {
    t.loading = true;
    if (!keepPage) t.page = 1;
    if (S.active === t.id) renderMain();
    const started = performance.now();
    try {
      t.data = await LD.call("db_rows", {
        conn: t.conn,
        database: t.db,
        table: t.table,
        page: t.page,
        limit: t.limit,
        sort: t.sort,
        dir: t.dir,
        where: t.where,
        search: t.search,
        filters: t.filters || []
      });
      t.error = "";
      t.ms = Math.round(performance.now() - started);
      t.selected = new Set();
    } catch (err) {
      t.error = err.message;
    }
    t.loading = false;
    if (S.active === t.id) renderMain();
  }

  async function loadStructure(t) {
    try {
      t.structure = await LD.call("db_structure", { conn: t.conn, database: t.db, table: t.table });
    } catch (err) {
      t.structure = { error: err.message };
    }
    if (S.active === t.id) renderMain();
  }

  function tableTab(t) {
    const c = conn(t.conn);
    const sub = `
      <div class="seg sm">
        ${["data", "structure", "ddl"].map((s) => `<button class="${t.sub === s ? "active" : ""}" data-sub="${s}">${{ data: "Data", structure: "Structure", ddl: "DDL" }[s]}</button>`).join("")}
      </div>`;
    const tools = `
      <div class="dbm-quick-tools">
        <button class="dbm-quick-btn" data-db="gen-model" title="Generate Eloquent Model">${icon("code")} Model</button>
        <button class="dbm-quick-btn" data-db="gen-migration" title="Generate Laravel Migration">${icon("file")} Migration</button>
        <button class="dbm-quick-btn" data-db="seed-table" title="Seed Realistic Dummy Data">${icon("zap")} Seed Data</button>
      </div>`;
    const head = `
      <div class="dbm-bar">
        <div class="crumbs-db">${esc(c?.name || "")}<span class="sep">›</span>${esc(t.db)}<span class="sep">›</span><b>${esc(t.table)}</b></div>
        <span class="spacer"></span>
        ${tools}
        ${sub}
      </div>`;
    if (t.sub !== "data") {
      if (!t.structure) { loadStructure(t); return head + `<div class="skeleton" style="height:160px;margin:16px"></div>`; }
      if (t.structure.error) return head + `<div class="card error-card" style="margin:16px">${esc(t.structure.error)}</div>`;
      return head + (t.sub === "structure" ? structureView(t.structure) : `
        <div class="dbm-pane-scroll"><div class="ddl-box"><button class="btn sm" data-db="copy-ddl">${icon("copy")}Copy</button><pre class="mono">${esc(t.structure.ddl || "-- not available")}</pre></div></div>`);
    }
    return head + dataView(t);
  }

  function dataView(t) {
    const d = t.data;
    const pending = pendingCount(t);
    const readOnly = d?.view;
    const cols = d?.columns || [];
    const filterCount = (t.filters || []).length;
    const hasSearch = Boolean((t.search || "").trim());

    const toolbar = `
      <div class="dbm-toolbar">
        <button class="btn icon-btn sm" data-db="reload" title="Refresh (F5)">${icon("refresh")}</button>
        ${readOnly ? `<span class="chip">Read-only view</span>` : `
        <button class="btn sm" data-db="add-row">${icon("plus")}Row</button>
        <button class="btn sm" data-db="delete-rows" ${t.selected.size ? "" : "disabled"}>${icon("trash")}Delete${t.selected.size ? ` (${t.selected.size})` : ""}</button>`}
        
        <button class="btn sm ${t.showFilters || filterCount ? "active" : ""}" data-db="toggle-filters" title="Filter table rows">
          ${icon("filter")} Filter ${filterCount ? `<span class="badge" style="margin-left:4px;">${filterCount}</span>` : ""}
        </button>

        <div class="search sm">
          ${icon("search")}
          <input data-row-search placeholder="Search all columns…" value="${esc(t.search)}" autocomplete="off" spellcheck="false">
          ${hasSearch ? `<button type="button" class="btn ghost icon-btn xs" data-db-clear-row-search title="Clear search">✕</button>` : ""}
        </div>

        <button class="btn sm" data-db="open-as-query" title="Open this table view as SQL query in Query Editor">${icon("terminal")} SQL Editor</button>
        <button class="btn icon-btn sm" data-db="export-table" title="Export">${icon("download")}</button>
      </div>

      ${t.showFilters || filterCount || t.showRawWhere ? `
      <div class="dbm-filter-panel">
        <div class="dbm-filter-row">
          <span class="filter-lbl">${icon("filter")} Filter:</span>
          <select class="sm" data-flt-column>
            ${cols.filter((c) => !c.hidden).map((c) => `<option value="${esc(c.name)}">${esc(c.name)}${c.type ? ` (${esc(c.type.replace(/\(.*\)/, ""))})` : ""}</option>`).join("")}
          </select>
          <select class="sm" data-flt-op>
            <option value="=">= (equals)</option>
            <option value="!=">!= (not equals)</option>
            <option value="CONTAINS">contains</option>
            <option value="STARTS_WITH">starts with</option>
            <option value="ENDS_WITH">ends with</option>
            <option value=">">&gt; (greater than)</option>
            <option value="<">&lt; (less than)</option>
            <option value=">=">&gt;= (greater or equal)</option>
            <option value="<=">&lt;= (less or equal)</option>
            <option value="IS NULL">is NULL</option>
            <option value="IS NOT NULL">is NOT NULL</option>
            <option value="IN">in (comma-separated)</option>
          </select>
          <input class="sm mono" data-flt-value placeholder="Value…" spellcheck="false" autocomplete="off">
          <button class="btn sm primary" data-db="add-filter">${icon("plus")} Add Filter</button>
          <button class="btn ghost sm" data-db="toggle-raw-where" title="Switch to custom SQL WHERE clause">${t.showRawWhere ? "Hide Raw SQL" : "Custom SQL WHERE"}</button>
        </div>

        ${t.showRawWhere ? `
        <form class="dbm-raw-where-form" data-where-form>
          <span class="mono" style="font-size:11px; font-weight:700; color:var(--accent);">WHERE</span>
          <input name="where" class="mono" value="${esc(t.where)}" placeholder="e.g. id > 100 AND status = 'active'" spellcheck="false" autocomplete="off">
          <button class="btn sm" type="submit">Apply SQL</button>
        </form>` : ""}

        ${filterCount ? `
        <div class="dbm-filter-chips">
          <span class="filter-chips-title">Active Filters:</span>
          ${t.filters.map((f, fi) => `
            <span class="filter-chip">
              <b>${esc(f.column)}</b> <i>${esc(f.op)}</i> ${f.op.includes("NULL") ? "" : `<code>${esc(String(f.value ?? ""))}</code>`}
              <button type="button" class="filter-chip-remove" data-remove-filter="${fi}" title="Remove this filter">✕</button>
            </span>
          `).join("")}
          <button class="btn ghost xs" data-db="clear-all-filters" style="color:var(--red);">Clear all</button>
        </div>` : ""}
      </div>` : ""}

      ${pending ? `<div class="dbm-pending"><span><b>${pending}</b> unsaved change${pending > 1 ? "s" : ""}</span><span class="spacer"></span>
        <button class="btn sm" data-db="discard">Discard</button><button class="btn sm primary" data-db="save">${icon("check")}Save (Ctrl+S)</button></div>` : ""}`;
    if (t.error && !d) return toolbar + `<div class="card error-card" style="margin:16px"><h3>${icon("alert")}Couldn't load rows</h3><p class="muted">${esc(t.error)}</p></div>`;
    if (!d) return toolbar + `<div class="skeleton" style="height:220px;margin:16px"></div>`;

    const visible = cols.map((col, i) => ({ ...col, i })).filter((col) => !col.hidden);
    const truncated = new Set(d.truncated.map(([r, ci]) => `${r}:${ci}`));
    const headCells = visible.map((col) => `
      <th data-sort="${esc(col.name)}" class="${t.sort === col.name ? "sorted" : ""}" title="${esc(col.type || "")}${col.nullable ? "" : " · NOT NULL"}${col.comment ? ` — ${esc(col.comment)}` : ""}">
        <span>${col.pk ? `<span class="pk">PK</span>` : ""}${esc(col.name)}</span><small>${esc((col.type || "").replace(/\(.*\)/, ""))}</small>
        ${t.sort === col.name ? `<i>${t.dir === "ASC" ? "▲" : "▼"}</i>` : ""}
      </th>`).join("");

    const insertRows = t.inserts.map((row, ni) => `
      <tr class="new" data-new="${ni}">
        <td class="rn"><button class="btn ghost icon-btn xs" data-db="drop-new" title="Remove">${icon("x")}</button></td>
        ${visible.map((col) => `<td data-new-cell="${esc(col.name)}" class="${row[col.name] !== undefined ? "dirty" : ""}">${row[col.name] !== undefined ? display(row[col.name]) : `<span class="null">${col.auto ? "auto" : col.default !== null && col.default !== undefined ? "default" : "NULL"}</span>`}</td>`).join("")}
      </tr>`).join("");

    const bodyRows = d.rows.map((row, ri) => {
      const edits = t.edits.get(ri) || {};
      const deleted = t.deletes.has(ri);
      return `
        <tr class="${deleted ? "deleted" : ""} ${t.selected.has(ri) ? "selected" : ""}" data-row="${ri}">
          <td class="rn" data-select-row>${(d.page - 1) * d.limit + ri + 1}</td>
          ${visible.map((col) => {
            const has = Object.prototype.hasOwnProperty.call(edits, col.name);
            const value = has ? edits[col.name] : row[col.i];
            const cut = !has && truncated.has(`${ri}:${col.i}`);
            return `<td data-cell="${col.i}" class="${has ? "dirty" : ""} ${col.binary ? "bin" : ""} ${typeof value === "number" ? "num" : ""}">${display(value)}${cut ? `<span class="cut">…</span>` : ""}</td>`;
          }).join("")}
        </tr>`;
    }).join("");

    const from = d.total ? (d.page - 1) * d.limit + 1 : 0;
    return toolbar + `
      <div class="dbm-grid-wrap ${t.loading ? "loading" : ""}" tabindex="0" data-grid>
        <table class="dbg">
          <thead><tr><th class="rn" data-select-all title="Select all">#</th>${headCells}</tr></thead>
          <tbody>${insertRows}${bodyRows || (insertRows ? "" : `<tr><td colspan="${visible.length + 1}" class="dbm-hint">${t.where || t.search ? "No rows match." : "This table is empty."}</td></tr>`)}</tbody>
        </table>
      </div>
      <div class="dbm-foot">
        <span class="muted">${from}–${Math.min(d.page * d.limit, d.total)} of ${d.estimated ? "~" : ""}${Number(d.total).toLocaleString()} rows${t.ms ? ` · ${t.ms} ms` : ""}</span>
        ${!d.identity.length && !d.view ? `<span class="chip warn" title="Edits match the whole row and change one row at a time">No primary key</span>` : ""}
        <span class="spacer"></span>
        <button class="btn icon-btn sm" data-page="first" ${d.page <= 1 ? "disabled" : ""} title="First page">«</button>
        <button class="btn icon-btn sm" data-page="prev" ${d.page <= 1 ? "disabled" : ""}>${icon("back")}</button>
        <span class="page-input">Page <input type="number" min="1" max="${d.pages}" value="${d.page}" data-page-input> of ${d.pages}</span>
        <button class="btn icon-btn sm" data-page="next" ${d.page >= d.pages ? "disabled" : ""}>${icon("back", "flip")}</button>
        <button class="btn icon-btn sm" data-page="last" ${d.page >= d.pages ? "disabled" : ""} title="Last page">»</button>
        <select data-page-size class="sm">${PAGE_SIZES.map((n) => `<option value="${n}" ${n === d.limit ? "selected" : ""}>${n} / page</option>`).join("")}</select>
      </div>`;
  }

  function structureView(s) {
    return `
      <div class="dbm-pane-scroll">
        <h4 class="dbm-h">Columns <span class="muted">${s.columns.length}</span></h4>
        <table class="dbg plain">
          <thead><tr><th>#</th><th>Name</th><th>Type</th><th>Null</th><th>Default</th><th>Key</th><th>Extra</th><th>Comment</th></tr></thead>
          <tbody>${s.columns.map((c, i) => `<tr>
            <td class="muted">${i + 1}</td><td><b>${esc(c.name)}</b></td><td class="mono">${esc(c.type)}</td>
            <td>${c.nullable ? "YES" : `<span class="chip">NOT NULL</span>`}</td>
            <td class="mono">${c.default === null || c.default === undefined ? `<span class="null">NULL</span>` : esc(c.default)}</td>
            <td>${c.pk ? `<span class="pk">PK</span>` : ""}</td><td class="mono muted">${esc(c.extra || (c.auto ? "auto increment" : ""))}</td><td class="muted">${esc(c.comment)}</td>
          </tr>`).join("")}</tbody>
        </table>
        <h4 class="dbm-h">Indexes <span class="muted">${s.indexes.length}</span></h4>
        <table class="dbg plain">
          <thead><tr><th>Name</th><th>Columns</th><th>Kind</th><th>Method</th></tr></thead>
          <tbody>${s.indexes.map((x) => `<tr><td><b>${esc(x.name)}</b></td><td class="mono">${esc(x.columns.join(", "))}</td>
            <td>${x.primary ? `<span class="pk">PRIMARY</span>` : x.unique ? `<span class="chip">UNIQUE</span>` : "INDEX"}</td><td class="muted">${esc(x.type || "")}</td></tr>`).join("") || `<tr><td colspan="4" class="dbm-hint">No indexes</td></tr>`}</tbody>
        </table>
        <h4 class="dbm-h">Foreign keys <span class="muted">${s.foreign_keys.length}</span></h4>
        <table class="dbg plain">
          <thead><tr><th>Name</th><th>Columns</th><th>References</th><th>On update</th><th>On delete</th></tr></thead>
          <tbody>${s.foreign_keys.map((f) => `<tr><td><b>${esc(f.name)}</b></td><td class="mono">${esc(f.columns.join(", "))}</td>
            <td class="mono">${esc(f.ref_table)}(${esc(f.ref_columns.join(", "))})</td><td>${esc(f.on_update || "")}</td><td>${esc(f.on_delete || "")}</td></tr>`).join("") || `<tr><td colspan="5" class="dbm-hint">No foreign keys</td></tr>`}</tbody>
        </table>
      </div>`;
  }

  /* cell editing */
  function startEdit(td) {
    const t = tab();
    if (!t?.data || t.data.view) return;
    const tr = td.closest("tr");
    const isNew = tr.dataset.new !== undefined;
    const colName = isNew ? td.dataset.newCell : t.data.columns[+td.dataset.cell].name;
    const col = t.data.columns.find((c) => c.name === colName);
    if (col.binary) return toast("error", "Binary values can't be edited here", "Use the SQL editor.");
    const ri = isNew ? +tr.dataset.new : +tr.dataset.row;
    if (!isNew && t.deletes.has(ri)) return;
    let value;
    if (isNew) value = t.inserts[ri][colName];
    else {
      const edits = t.edits.get(ri) || {};
      value = Object.prototype.hasOwnProperty.call(edits, colName) ? edits[colName] : t.data.rows[ri][+td.dataset.cell];
    }
    const truncated = !isNew && t.data.truncated.some(([r, c]) => r === ri && c === +td.dataset.cell) && !(t.edits.get(ri) || {})[colName];
    const long = typeof value === "string" && (value.length > 80 || value.includes("\n"));
    td.classList.add("editing");
    td.innerHTML = long || truncated
      ? `<textarea class="cell-input mono" rows="4" spellcheck="false"></textarea>`
      : `<input class="cell-input mono" spellcheck="false" autocomplete="off">`;
    const input = $(".cell-input", td);
    input.value = value === null || value === undefined ? "" : String(value);
    input.placeholder = value === null ? "NULL" : "";
    input.dataset.wasNull = value === null || value === undefined ? "1" : "";
    input.focus();
    input.select();
    if (truncated) {
      input.disabled = true;
      LD.call("db_cell", { conn: t.conn, database: t.db, table: t.table, key: rowKey(t, ri), column: colName })
        .then((res) => { input.value = res.value ?? ""; input.disabled = false; input.focus(); })
        .catch((err) => { toast("error", "Couldn't load the full value", err.message); renderMain(); });
    }
    const finish = (commit, move = 0) => {
      if (!td.classList.contains("editing")) return;
      td.classList.remove("editing");
      if (commit) {
        const raw = input.value;
        const newValue = raw === "" && input.dataset.wasNull ? null : raw;
        setCell(t, isNew, ri, colName, newValue, td);
      }
      renderMain();
      if (move) {
        const cells = $$(`#dbm-content tr[data-${isNew ? "new" : "row"}="${ri}"] td[data-${isNew ? "new-cell" : "cell"}]`);
        const index = cells.findIndex((c) => (isNew ? c.dataset.newCell === colName : t.data.columns[+c.dataset.cell].name === colName));
        const next = cells[index + move];
        if (next) startEdit(next);
      }
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); finish(false); }
      else if (e.key === "Enter" && (input.tagName === "INPUT" || e.ctrlKey)) { e.preventDefault(); finish(true); }
      else if (e.key === "Tab") { e.preventDefault(); finish(true, e.shiftKey ? -1 : 1); }
    });
    input.addEventListener("blur", () => setTimeout(() => finish(true), 0));
  }

  function setCell(t, isNew, ri, colName, value) {
    if (isNew) {
      t.inserts[ri][colName] = value;
      return renderTabs();
    }
    const colIndex = t.data.columns.findIndex((c) => c.name === colName);
    const original = t.data.rows[ri][colIndex];
    const edits = t.edits.get(ri) || {};
    if (value === original || (original !== null && value !== null && String(original) === value)) delete edits[colName];
    else edits[colName] = value;
    Object.keys(edits).length ? t.edits.set(ri, edits) : t.edits.delete(ri);
    renderTabs();
  }

  function rowKey(t, ri) {
    const d = t.data;
    const row = d.rows[ri];
    const key = {};
    if (d.identity.length) {
      for (const name of d.identity) key[name] = row[d.columns.findIndex((c) => c.name === name)];
    } else {
      const cut = new Set(d.truncated.filter(([r]) => r === ri).map(([, c]) => c));
      d.columns.forEach((c, i) => { if (!c.binary && !cut.has(i)) key[c.name] = row[i]; });
    }
    return key;
  }

  async function saveChanges(t) {
    if (!pendingCount(t)) return;
    const matchAll = !t.data.identity.length;
    const changes = {
      deletes: [...t.deletes].map((ri) => ({ key: rowKey(t, ri), match_all: matchAll })),
      updates: [...t.edits].filter(([ri]) => !t.deletes.has(ri)).map(([ri, values]) => ({ key: rowKey(t, ri), values, match_all: matchAll })),
      inserts: t.inserts,
    };
    try {
      const res = await LD.call("db_apply", { conn: t.conn, database: t.db, table: t.table, changes });
      t.edits = new Map(); t.inserts = []; t.deletes = new Set();
      const parts = [res.inserted && `${res.inserted} added`, res.updated && `${res.updated} updated`, res.deleted && `${res.deleted} deleted`].filter(Boolean);
      toast("success", `Saved ${t.table}`, parts.join(", "));
      renderTabs();
      await loadRows(t);
    } catch (err) {
      toast("error", "Nothing was saved", err.message);
    }
  }

  /* ── SQL & query helpers ────────────────────────────────── */
  function buildTableSelectSql(driver, table, filters = [], rawWhere = "", sort = "", dir = "ASC", limit = 100) {
    const tableRef = q(driver, table);
    let sql = `SELECT * FROM ${tableRef}`;
    const clauses = [];
    (filters || []).forEach((f) => {
      const colQ = q(driver, f.column);
      const op = (f.op || "=").toUpperCase().trim();
      const val = f.value;
      if (op === "IS NULL" || op === "IS NOT NULL") {
        clauses.push(`${colQ} ${op}`);
      } else if (op === "CONTAINS") {
        clauses.push(`${colQ} LIKE '%${String(val).replace(/'/g, "''")}%'`);
      } else if (op === "STARTS_WITH") {
        clauses.push(`${colQ} LIKE '${String(val).replace(/'/g, "''")}%'`);
      } else if (op === "ENDS_WITH") {
        clauses.push(`${colQ} LIKE '%${String(val).replace(/'/g, "''")}'`);
      } else if (op === "IN" || op === "NOT IN") {
        const parts = String(val).split(",").map((v) => `'${v.trim().replace(/'/g, "''")}'`);
        clauses.push(`${colQ} ${op} (${parts.join(", ")})`);
      } else {
        const isNum = !isNaN(val) && val !== "" && val !== null;
        clauses.push(`${colQ} ${op} ${isNum ? val : `'${String(val).replace(/'/g, "''")}'`}`);
      }
    });
    if (rawWhere && rawWhere.trim()) clauses.push(`(${rawWhere.trim()})`);
    if (clauses.length) sql += `\nWHERE ${clauses.join(" AND ")}`;
    if (sort) sql += `\nORDER BY ${q(driver, sort)} ${dir === "DESC" ? "DESC" : "ASC"}`;
    sql += `\nLIMIT ${limit || 100};`;
    return sql;
  }

  function formatSql(sql) {
    if (!sql || !sql.trim()) return sql;
    const keywords = [
      "SELECT", "FROM", "WHERE", "AND", "OR", "GROUP BY", "ORDER BY", "HAVING",
      "LIMIT", "OFFSET", "JOIN", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "FULL JOIN",
      "CROSS JOIN", "ON", "INSERT INTO", "VALUES", "UPDATE", "SET", "DELETE FROM",
      "AS", "DESC", "ASC", "IN", "NOT IN", "IS NULL", "IS NOT NULL", "LIKE", "NOT LIKE",
      "DISTINCT", "UNION", "UNION ALL", "CASE", "WHEN", "THEN", "ELSE", "END",
      "EXISTS", "NOT EXISTS", "BETWEEN", "CREATE TABLE", "ALTER TABLE", "DROP TABLE",
      "TRUNCATE TABLE", "PRIMARY KEY", "FOREIGN KEY", "DEFAULT"
    ];
    keywords.sort((a, b) => b.length - a.length);

    let res = sql;
    keywords.forEach((kw) => {
      const rx = new RegExp(`\\b${kw.replace(/ /g, "\\s+")}\\b`, "gi");
      res = res.replace(rx, kw);
    });

    const breakClauses = ["FROM", "WHERE", "GROUP BY", "ORDER BY", "HAVING", "LIMIT", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "JOIN", "SET", "VALUES"];
    breakClauses.forEach((kw) => {
      const rx = new RegExp(`([^\\n;])\\s+(${kw}\\b)`, "g");
      res = res.replace(rx, "$1\n$2");
    });
    return res;
  }

  function saveQueryHistory(sql) {
    if (!sql || !sql.trim()) return;
    try {
      const raw = localStorage.getItem("ld_sql_history");
      let history = raw ? JSON.parse(raw) : [];
      history = [sql.trim(), ...history.filter((s) => s.trim() !== sql.trim())].slice(0, 30);
      localStorage.setItem("ld_sql_history", JSON.stringify(history));
    } catch {}
  }

  function showQueryHistoryMenu(x, y) {
    try {
      const raw = localStorage.getItem("ld_sql_history");
      const history = raw ? JSON.parse(raw) : [];
      if (!history.length) {
        return toast("info", "No query history yet", "Queries you execute will be saved here automatically.");
      }
      const items = history.map((sql) => {
        const singleLine = sql.replace(/\s+/g, " ").trim();
        const label = singleLine.length > 55 ? singleLine.slice(0, 55) + "…" : singleLine;
        return {
          label,
          icon: "terminal",
          run: () => {
            const area = $(".sql-editor");
            if (area) {
              area.value = sql;
              area.focus();
              const current = tab();
              if (current?.kind === "query") current.sql = sql;
            }
          }
        };
      });
      items.push("-");
      items.push({
        label: "Clear History",
        icon: "trash",
        danger: true,
        run: () => {
          localStorage.removeItem("ld_sql_history");
          toast("success", "Query history cleared");
        }
      });
      showMenu(x, y, items);
    } catch (e) {
      toast("error", "Couldn't read history", e.message);
    }
  }

  function insertSqlSnippet(text, replaceAll = false) {
    const area = $(".sql-editor");
    if (!area) return;
    area.focus();
    if (replaceAll || !area.value.trim()) {
      area.value = text;
      area.setSelectionRange(text.length, text.length);
    } else {
      const start = area.selectionStart;
      const end = area.selectionEnd;
      const before = area.value.substring(0, start);
      const after = area.value.substring(end);
      const needSpaceBefore = before.length && !/\s$/.test(before) && !/^\s/.test(text);
      const insert = (needSpaceBefore ? " " : "") + text;
      area.value = before + insert + after;
      const newPos = start + insert.length;
      area.setSelectionRange(newPos, newPos);
    }
    const current = tab();
    if (current?.kind === "query") current.sql = area.value;
  }

  function applyQueryTemplate(templateName) {
    const current = tab();
    const c = conn(current?.conn);
    const dbn = S.tree[current?.conn]?.dbs[current?.db] || {};
    const tables = dbn.tables || [];
    const tblSelect = $("[data-query-table]");
    const selectedTable = tblSelect?.value || (tables[0] ? tables[0].name : "table_name");
    const tRef = q(c?.driver, selectedTable);

    let sql = "";
    switch (templateName) {
      case "select_all":
        sql = `SELECT * FROM ${tRef} LIMIT 100;`;
        break;
      case "select_where":
        sql = `SELECT * FROM ${tRef}\nWHERE status = 'active'\nORDER BY id DESC\nLIMIT 50;`;
        break;
      case "count_group":
        sql = `SELECT status, COUNT(*) AS count\nFROM ${tRef}\nGROUP BY status\nORDER BY count DESC;`;
        break;
      case "join":
        sql = `SELECT t1.*, t2.*\nFROM ${tRef} t1\nINNER JOIN other_table t2 ON t1.id = t2.${selectedTable}_id\nLIMIT 100;`;
        break;
      case "insert":
        sql = `INSERT INTO ${tRef} (column1, column2)\nVALUES ('value1', 'value2');`;
        break;
      case "update":
        sql = `UPDATE ${tRef}\nSET column1 = 'value1'\nWHERE id = 1;`;
        break;
      case "delete":
        sql = `DELETE FROM ${tRef}\nWHERE id = 1;`;
        break;
      default:
        return;
    }
    insertSqlSnippet(sql, true);
  }

  /* ── query tab ──────────────────────────────────────────── */
  function queryTab(t) {
    const c = conn(t.conn);
    const dbs = (S.tree[t.conn]?.databases || []).filter((d) => S.showSystem || !d.system || d.name === t.db);
    const dbn = S.tree[t.conn]?.dbs[t.db] || {};
    const tables = dbn.tables || [];

    return `
      <div class="dbm-query">
        <div class="dbm-bar">
          <select data-query-conn class="sm">${S.conns.map((x) => `<option value="${esc(x.id)}" ${x.id === t.conn ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>
          ${c?.driver === "sqlite" ? "" : `<select data-query-db class="sm"><option value="">(no database)</option>${dbs.map((d) => `<option ${d.name === t.db ? "selected" : ""}>${esc(d.name)}</option>`).join("")}</select>`}
          <span class="spacer"></span>
          <div id="dbm-query-bar">${queryBar(t)}</div>
        </div>

        <div class="dbm-query-tools">
          <div class="dbm-query-tool-group">
            <span class="tool-label">Table:</span>
            <select class="sm" data-query-table title="Select a table">
              <option value="">(choose table)</option>
              ${tables.map((tb) => `<option value="${esc(tb.name)}">${esc(tb.name)}</option>`).join("")}
            </select>
            <button class="btn xs ghost" data-query-action="select-table" title="Generate SELECT * FROM table LIMIT 100">SELECT *</button>
            <button class="btn xs ghost" data-query-action="count-table" title="Generate COUNT(*) FROM table">COUNT(*)</button>
          </div>

          <div class="dbm-query-tool-sep"></div>

          <div class="dbm-query-tool-group">
            <span class="tool-label">Snippets:</span>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="WHERE " title="Add WHERE">WHERE</button>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="ORDER BY id DESC " title="Add ORDER BY">ORDER BY</button>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="GROUP BY " title="Add GROUP BY">GROUP BY</button>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="INNER JOIN  ON " title="Add INNER JOIN">JOIN</button>
            <button class="btn xs ghost query-snippet-btn" data-sql-snippet="LIMIT 50 " title="Add LIMIT">LIMIT</button>
          </div>

          <div class="dbm-query-tool-sep"></div>

          <div class="dbm-query-tool-group">
            <select class="sm" data-query-template title="Load SQL Template">
              <option value="">SQL Templates…</option>
              <option value="select_all">SELECT * FROM ... LIMIT 100</option>
              <option value="select_where">SELECT ... WHERE ...</option>
              <option value="count_group">SELECT col, COUNT(*) GROUP BY col</option>
              <option value="join">SELECT * FROM t1 JOIN t2 ON ...</option>
              <option value="insert">INSERT INTO table (col1, col2) VALUES (...)</option>
              <option value="update">UPDATE table SET col = val WHERE ...</option>
              <option value="delete">DELETE FROM table WHERE ...</option>
            </select>
            <button class="btn xs ghost" data-query-action="format" title="Format SQL keywords and indentation">${icon("code")} Format</button>
            <button class="btn xs ghost" data-query-action="history" title="Recent queries history">${icon("clock")} History</button>
            <button class="btn xs ghost" data-query-action="clear" title="Clear editor">${icon("trash")} Clear</button>
          </div>
        </div>

        <textarea class="sql-editor mono" data-tab="${t.id}" spellcheck="false" placeholder="SELECT * FROM users LIMIT 100;&#10;&#10;Ctrl+Enter runs the selection, or everything."></textarea>
        <div class="dbm-results" id="dbm-query-results">${queryResults(t)}</div>
      </div>`;
  }

  function queryBar(t) {
    return `
      <button class="btn sm" data-db="explain-query" ${t.running ? "disabled" : ""} title="Analyze query execution plan (EXPLAIN)">${icon("pulse")} EXPLAIN</button>
      <button class="btn sm primary" data-db="run-query" ${t.running ? "disabled" : ""}>${icon("play")}${t.running ? "Running…" : "Run"} <kbd>Ctrl ↵</kbd></button>
    `;
  }

  function queryResults(t) {
    if (t.running) return `<div class="dbm-hint"><span class="spin-dot"></span>Running…</div>`;
    if (t.showExplain && t.explain) return renderExplainView(t);
    if (!t.results) return `<div class="dbm-hint">Results show up here.</div>`;
    const results = t.results;
    const index = Math.min(t.resultIndex, results.length - 1);
    const r = results[index];
    const tabs = results.length > 1 ? `<div class="seg sm result-tabs">${results.map((x, i) => `<button class="${i === index ? "active" : ""}" data-result="${i}">${x.error ? "⚠ Error" : x.columns ? `Result ${i + 1}` : `Query ${i + 1}`}</button>`).join("")}</div>` : "";
    let body;
    if (r.error) body = `<div class="query-msg error">${icon("alert")}<div><b>${esc(r.error)}</b><small class="mono">${esc(r.sql)}</small></div></div>`;
    else if (!r.columns) body = `<div class="query-msg ok">${icon("check")}<div><b>${r.affected >= 0 ? `${r.affected} row${r.affected === 1 ? "" : "s"} affected` : "Done"}</b><small class="mono">${esc(r.sql)} · ${r.ms} ms</small></div></div>`;
    else if (r.dropped) body = `<div class="dbm-hint">Rows released to save memory — run the query again.</div>`;
    else body = `
      <div class="dbm-grid-wrap"><table class="dbg">
        <thead><tr><th class="rn">#</th>${r.columns.map((c) => `<th><span>${esc(c)}</span></th>`).join("")}</tr></thead>
        <tbody>${r.rows.map((row, i) => `<tr><td class="rn">${i + 1}</td>${row.map((v) => `<td class="${typeof v === "number" ? "num" : ""}">${display(v)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${r.columns.length + 1}" class="dbm-hint">No rows</td></tr>`}</tbody>
      </table></div>
      <div class="dbm-foot"><span class="muted">${r.rows.length}${r.more ? "+" : ""} row${r.rows.length === 1 ? "" : "s"} · ${r.ms} ms${r.more ? " · showing the first 1000" : ""}</span></div>`;
    return tabs + body;
  }

  async function runQuery(t) {
    const area = $(".sql-editor");
    if (area) t.sql = area.value;
    const selected = area && area.selectionEnd > area.selectionStart ? area.value.slice(area.selectionStart, area.selectionEnd) : t.sql;
    if (!selected.trim()) return toast("error", "Write a query first");
    saveQueryHistory(selected);
    t.running = true;
    t.showExplain = false;
    renderMain();
    try {
      const res = await LD.call("db_query", { conn: t.conn, database: t.db, sql: selected });
      t.results = res.results;
      const firstError = res.results.findIndex((r) => r.error);
      const lastGrid = res.results.map((r, i) => (r.columns ? i : -1)).filter((i) => i >= 0).pop();
      t.resultIndex = firstError >= 0 ? firstError : lastGrid ?? res.results.length - 1;
      if (/\b(create|drop|alter|rename)\b/i.test(selected) && S.tree[t.conn]?.dbs[t.db]) openDb(t.conn, t.db, true);
    } catch (err) {
      t.results = [{ error: err.message, sql: selected.slice(0, 120) }];
      t.resultIndex = 0;
    }
    t.running = false;
    renderMain();
  }

  /* ── connections (Navicat-style with SSH) ──────────────── */
  async function connModal(existing = {}) {
    if (!S.servers.length) {
      try { S.servers = (await LD.call("servers")).servers; } catch { S.servers = []; }
    }
    const driver = existing.driver || "mysql";
    const useSsh = Boolean(existing.use_ssh || existing.ssh_host || existing.server);
    const sshMode = existing.ssh_mode || (existing.server && !existing.ssh_host ? "server" : "custom");
    const sshAuth = existing.ssh_auth || (existing.ssh_key ? "key" : "password");
    const colors = ["", "#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"];

    openModal(`
      <form class="modal" id="conn-form" novalidate style="max-width:540px;">
        <div class="modal-header">
          <h2>${existing.id ? "Edit connection" : "New connection"}</h2>
          <p>Navicat-style connection setup with dedicated SSH tunnel support.</p>
        </div>

        <div class="modal-body" style="padding-bottom: 8px;">
          <!-- Top Nav Tabs (Navicat style) -->
          <div class="conn-nav-tabs">
            <button type="button" class="conn-nav-btn active" data-nav-panel="general">
              ${icon("database")} General
            </button>
            <button type="button" class="conn-nav-btn" data-nav-panel="ssh">
              ${icon("cloud")} SSH Tunnel <span class="badge" data-ssh-badge ${useSsh ? "" : "hidden"}>Active</span>
            </button>
          </div>

          <!-- General Tab Panel -->
          <div class="conn-panel" id="conn-panel-general">
            <div class="segmented" style="margin-bottom: 12px;">
              ${Object.entries(DRIVERS).map(([k, v]) => `
                <button type="button" class="segment ${k === driver ? "active" : ""}" data-driver="${k}">
                  ${v}
                </button>
              `).join("")}
            </div>
            <input type="hidden" name="driver" value="${esc(driver)}">

            <div style="display:flex; gap:10px; align-items:flex-end;">
              <label class="field" style="flex:1;">
                <span>Connection Name</span>
                <input name="name" value="${esc(existing.name || "")}" placeholder="e.g. Production Database">
              </label>
              <div class="field" style="flex:none; padding-bottom: 2px;">
                <span>Color Tag</span>
                <div class="conn-colors">
                  ${colors.map((c) => `
                    <button type="button" class="conn-color-dot ${c === (existing.color || "") ? "active" : ""}"
                      data-color="${c}" style="background:${c || "var(--border-strong)"};"
                      title="${c ? "Tag color" : "Default"}"></button>
                  `).join("")}
                </div>
                <input type="hidden" name="color" value="${esc(existing.color || "")}">
              </div>
            </div>

            <!-- Network DB options -->
            <div data-net ${driver === "sqlite" ? "hidden" : ""}>
              <div class="grid-2">
                <label class="field">
                  <span>Host</span>
                  <input name="host" value="${esc(existing.host || "127.0.0.1")}" spellcheck="false" placeholder="127.0.0.1 or localhost">
                </label>
                <label class="field">
                  <span>Port</span>
                  <input name="port" value="${esc(existing.port || "")}" placeholder="${driver === "pgsql" ? 5432 : 3306}" inputmode="numeric">
                </label>
                <label class="field">
                  <span>Username</span>
                  <input name="user" value="${esc(existing.user || "")}" spellcheck="false" autocomplete="off" placeholder="root">
                </label>
                <label class="field">
                  <span>Password</span>
                  <div class="input-with-eye">
                    <input name="password" type="password" placeholder="${existing.has_password ? "(unchanged)" : "Enter password"}" autocomplete="new-password">
                    <button type="button" class="input-eye-btn" data-toggle-pass title="Show/Hide Password">${icon("eye")}</button>
                  </div>
                </label>
              </div>
              <label class="field">
                <span>Default Database <small>(optional)</small></span>
                <input name="database" value="${esc(existing.database || "")}" spellcheck="false" placeholder="e.g. shopjo_db">
              </label>
            </div>

            <!-- SQLite options -->
            <div data-file ${driver !== "sqlite" ? "hidden" : ""}>
              <label class="field">
                <span>Database File</span>
                <span class="input-group" style="width:100%">
                  <input name="file" value="${esc(existing.file || "")}" spellcheck="false" placeholder="/path/to/database.sqlite">
                  <button type="button" class="btn" data-pick-sqlite>Browse</button>
                </span>
              </label>
            </div>
          </div>

          <!-- SSH Tunnel Tab Panel -->
          <div class="conn-panel" id="conn-panel-ssh" hidden>
            <div class="ssh-notice" style="margin-bottom: 12px;">
              <b>Navicat SSH Tunnel</b>: Connect securely to a database behind a firewall or remote server without exposing database ports.
            </div>

            <label class="place-opt" style="margin-bottom: 12px; cursor: pointer;">
              <input type="checkbox" name="use_ssh" ${useSsh ? "checked" : ""} class="switch">
              <span>
                <b>Use SSH Tunnel</b>
                <small>Route database connection through an encrypted SSH tunnel.</small>
              </span>
            </label>

            <div id="ssh-details" ${useSsh ? "" : "hidden"}>
              <div class="segmented" style="grid-template-columns: 1fr 1fr; margin-bottom: 12px;">
                <button type="button" class="segment ${sshMode === "custom" ? "active" : ""}" data-ssh-mode="custom">
                  ${icon("wrench")} Dedicated SSH Settings
                </button>
                <button type="button" class="segment ${sshMode === "server" ? "active" : ""}" data-ssh-mode="server">
                  ${icon("cloud")} Saved Server
                </button>
              </div>
              <input type="hidden" name="ssh_mode" value="${esc(sshMode)}">

              <!-- Custom SSH settings -->
              <div id="ssh-custom-box" ${sshMode === "custom" ? "" : "hidden"}>
                <div class="grid-2">
                  <label class="field">
                    <span>SSH Host / IP</span>
                    <input name="ssh_host" value="${esc(existing.ssh_host || "")}" placeholder="e.g. 165.245.242.88" spellcheck="false">
                  </label>
                  <label class="field">
                    <span>SSH Port</span>
                    <input name="ssh_port" value="${esc(existing.ssh_port || "22")}" placeholder="22" inputmode="numeric">
                  </label>
                </div>
                <label class="field">
                  <span>SSH User</span>
                  <input name="ssh_user" value="${esc(existing.ssh_user || "")}" placeholder="root or ubuntu" spellcheck="false" autocomplete="off">
                </label>

                <div class="field" style="margin-top: 6px;">
                  <span>Authentication Method</span>
                  <div class="segmented" style="grid-template-columns: 1fr 1fr; margin-top: 4px;">
                    <button type="button" class="segment ${sshAuth === "password" ? "active" : ""}" data-ssh-auth="password">
                      ${icon("lock")} Password
                    </button>
                    <button type="button" class="segment ${sshAuth === "key" ? "active" : ""}" data-ssh-auth="key">
                      ${icon("key")} Private Key
                    </button>
                  </div>
                  <input type="hidden" name="ssh_auth" value="${esc(sshAuth)}">
                </div>

                <!-- Password Auth -->
                <div id="ssh-auth-password" ${sshAuth === "password" ? "" : "hidden"}>
                  <label class="field">
                    <span>SSH Password</span>
                    <div class="input-with-eye">
                      <input name="ssh_password" type="password" placeholder="${existing.has_ssh_password ? "(unchanged)" : "Enter SSH password"}" autocomplete="new-password">
                      <button type="button" class="input-eye-btn" data-toggle-pass title="Show/Hide Password">${icon("eye")}</button>
                    </div>
                  </label>
                </div>

                <!-- Key Auth -->
                <div id="ssh-auth-key" ${sshAuth === "key" ? "" : "hidden"}>
                  <label class="field">
                    <span>Private Key File</span>
                    <span class="input-group" style="width:100%">
                      <input name="ssh_key" value="${esc(existing.ssh_key || "")}" placeholder="~/.ssh/id_rsa or /path/to/key" spellcheck="false">
                      <button type="button" class="btn" data-pick-ssh-key>Browse</button>
                    </span>
                  </label>
                  <label class="field">
                    <span>Passphrase <small>(if key is encrypted)</small></span>
                    <div class="input-with-eye">
                      <input name="ssh_passphrase" type="password" placeholder="${existing.has_ssh_passphrase ? "(unchanged)" : "Optional key passphrase"}" autocomplete="new-password">
                      <button type="button" class="input-eye-btn" data-toggle-pass title="Show/Hide Passphrase">${icon("eye")}</button>
                    </div>
                  </label>
                </div>
              </div>

              <!-- Saved Server option -->
              <div id="ssh-server-box" ${sshMode === "server" ? "" : "hidden"}>
                <label class="field">
                  <span>Select Saved Server</span>
                  <select name="server">
                    <option value="">Choose a server...</option>
                    ${S.servers.map((s) => `
                      <option value="${esc(s.id)}" ${s.id === existing.server ? "selected" : ""}>
                        ${esc(s.name)} (${esc(s.host)})
                      </option>
                    `).join("")}
                  </select>
                </label>
              </div>

              <!-- SSH Test button -->
              <div style="display:flex; align-items:center; gap:8px; margin-top:10px;">
                <button type="button" class="btn sm" data-test-ssh>${icon("pulse")} Test SSH Tunnel</button>
                <div id="ssh-test-inline" style="font-size:12px;"></div>
              </div>
            </div>
          </div>

          <div class="test-result-box" id="conn-test" hidden></div>
        </div>

        <div class="modal-footer">
          ${existing.id ? `<button type="button" class="btn danger" data-remove style="margin-right:auto">${icon("trash")}Remove</button>` : ""}
          <button type="button" class="btn" data-test>${icon("pulse")}Test Connection</button>
          <button type="button" class="btn" data-dismiss>Cancel</button>
          <button type="submit" class="btn primary">${existing.id ? "Save" : `${icon("plus")}Add`}</button>
        </div>
      </form>`, (root) => {
      const form = $("#conn-form", root);
      const f = form.elements;

      const sync = () => {
        const sqlite = f.driver.value === "sqlite";
        $("[data-net]", form).hidden = sqlite;
        $("[data-file]", form).hidden = !sqlite;
        f.port.placeholder = f.driver.value === "pgsql" ? "5432" : "3306";
      };

      // Top Tab Navigation
      $$("[data-nav-panel]", form).forEach((btn) => {
        btn.addEventListener("click", () => {
          $$("[data-nav-panel]", form).forEach((b) => b.classList.toggle("active", b === btn));
          const panelName = btn.dataset.navPanel;
          $("#conn-panel-general", form).hidden = panelName !== "general";
          $("#conn-panel-ssh", form).hidden = panelName !== "ssh";
        });
      });

      // Driver selector
      $$("[data-driver]", form).forEach((b) => b.addEventListener("click", () => {
        $$("[data-driver]", form).forEach((x) => x.classList.toggle("active", x === b));
        f.driver.value = b.dataset.driver;
        sync();
      }));

      // Color picker
      $$("[data-color]", form).forEach((b) => b.addEventListener("click", () => {
        $$("[data-color]", form).forEach((x) => x.classList.toggle("active", x === b));
        f.color.value = b.dataset.color;
      }));

      // Password eye toggling
      $$("[data-toggle-pass]", form).forEach((btn) => {
        btn.addEventListener("click", () => {
          const input = btn.previousElementSibling;
          if (input) {
            input.type = input.type === "password" ? "text" : "password";
            btn.classList.toggle("active", input.type === "text");
          }
        });
      });

      // SSH toggle
      f.use_ssh.addEventListener("change", () => {
        const checked = f.use_ssh.checked;
        $("#ssh-details", form).hidden = !checked;
        $("[data-ssh-badge]", form).hidden = !checked;
      });

      // SSH mode (custom vs server)
      $$("[data-ssh-mode]", form).forEach((b) => b.addEventListener("click", () => {
        $$("[data-ssh-mode]", form).forEach((x) => x.classList.toggle("active", x === b));
        f.ssh_mode.value = b.dataset.sshMode;
        $("#ssh-custom-box", form).hidden = f.ssh_mode.value !== "custom";
        $("#ssh-server-box", form).hidden = f.ssh_mode.value !== "server";
      }));

      // SSH auth (password vs key)
      $$("[data-ssh-auth]", form).forEach((b) => b.addEventListener("click", () => {
        $$("[data-ssh-auth]", form).forEach((x) => x.classList.toggle("active", x === b));
        f.ssh_auth.value = b.dataset.sshAuth;
        $("#ssh-auth-password", form).hidden = f.ssh_auth.value !== "password";
        $("#ssh-auth-key", form).hidden = f.ssh_auth.value !== "key";
      }));

      const payload = () => ({
        id: existing.id,
        name: f.name.value,
        driver: f.driver.value,
        color: f.color.value,
        host: f.host.value,
        port: f.port.value,
        user: f.user.value,
        password: f.password.value === "" && existing.has_password ? null : f.password.value,
        database: f.database.value,
        file: f.file.value,
        use_ssh: f.use_ssh.checked,
        ssh_mode: f.ssh_mode.value,
        server: f.server ? f.server.value : "",
        ssh_host: f.ssh_host ? f.ssh_host.value : "",
        ssh_port: f.ssh_port ? f.ssh_port.value : "22",
        ssh_user: f.ssh_user ? f.ssh_user.value : "",
        ssh_auth: f.ssh_auth ? f.ssh_auth.value : "password",
        ssh_password: f.ssh_password && f.ssh_password.value === "" && existing.has_ssh_password ? null : (f.ssh_password ? f.ssh_password.value : ""),
        ssh_key: f.ssh_key ? f.ssh_key.value : "",
        ssh_passphrase: f.ssh_passphrase && f.ssh_passphrase.value === "" && existing.has_ssh_passphrase ? null : (f.ssh_passphrase ? f.ssh_passphrase.value : ""),
      });

      $("[data-dismiss]", form).addEventListener("click", closeModal);

      $("[data-pick-sqlite]", form).addEventListener("click", async () => {
        const path = await LD.call("db_pick_sqlite", { current: f.file.value }).catch(() => "");
        if (path) {
          f.file.value = path;
          if (!f.name.value) f.name.value = path.split(/[\\/]/).pop();
        }
      });

      $("[data-pick-ssh-key]", form)?.addEventListener("click", async () => {
        const path = await LD.call("pick_file", { title: "Choose SSH Private Key", current: f.ssh_key?.value }).catch(() => "");
        if (path && f.ssh_key) f.ssh_key.value = path;
      });

      // Inline SSH Test
      $("[data-test-ssh]", form)?.addEventListener("click", async () => {
        const out = $("#ssh-test-inline", form);
        out.innerHTML = `<span class="spin-dot"></span> Testing SSH tunnel…`;
        const p = payload();
        try {
          const res = await LD.call("db_test_ssh", {
            ssh_mode: p.ssh_mode,
            server: p.server,
            ssh_host: p.ssh_host,
            ssh_port: p.ssh_port,
            ssh_user: p.ssh_user,
            ssh_auth: p.ssh_auth,
            ssh_key: p.ssh_key,
            ssh_password: p.ssh_password,
            ssh_passphrase: p.ssh_passphrase,
          });
          out.style.color = "var(--green)";
          out.innerHTML = `${icon("check")} SSH connected · ${res.ms} ms`;
        } catch (err) {
          out.style.color = "var(--red)";
          out.innerHTML = `${icon("alert")} ${esc(err.message)}`;
        }
      });

      // Full Connection Test
      $("[data-test]", form).addEventListener("click", async () => {
        const out = $("#conn-test", form);
        out.hidden = false;
        out.className = "test-result-box";
        out.innerHTML = `<div class="test-result-step"><span class="spin-dot"></span> Testing connection…</div>`;
        const p = payload();
        try {
          const res = await LD.call("db_test", { ...p, name: p.name || "test" });
          out.className = "test-result-box ok";
          let html = "";
          if (res.ssh) {
            html += `<div class="test-result-step">${icon("check")} SSH Tunnel connected · ${esc(res.ssh.host)} (${res.ssh.ms} ms)</div>`;
          }
          html += `<div class="test-result-step">${icon("check")} Database connected · ${esc(res.version)} (${res.ms} ms total)</div>`;
          out.innerHTML = html;
        } catch (err) {
          out.className = "test-result-box error";
          out.innerHTML = `<div class="test-result-step">${icon("alert")} ${esc(err.message)}</div>`;
        }
      });

      $("[data-remove]", form)?.addEventListener("click", async () => {
        closeModal();
        if (!(await confirmModal({ title: `Remove ${existing.name}?`, message: "Only the saved connection is removed; the database is not touched.", confirm: "Remove", danger: true }))) return;
        await LD.call("db_remove", { id: existing.id });
        S.tabs.filter((t) => t.conn === existing.id).forEach((t) => closeTab(t.id));
        delete S.tree[existing.id];
        await loadConns();
        render();
      });

      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const saved = await LD.call("db_save", payload());
          closeModal();
          delete S.tree[saved.id];
          await loadConns();
          render();
          openConn(saved.id);
        } catch (err) {
          toast("error", err.message);
        }
      });

      sync();
    });
  }

  /* ── hologram (schema ERD visualizer) ────────────────────── */
  function openHologram(connId, dbName) {
    const existing = S.tabs.find((t) => t.kind === "hologram" && t.conn === connId && t.db === dbName);
    if (existing) return activate(existing.id);
    openTab({ kind: "hologram", conn: connId, db: dbName });
  }

  async function loadHologram(t, force = false) {
    if (t.loading) return;
    t.loading = true;
    t.error = "";
    if (force) t.data = null;
    renderMain();
    try {
      t.data = await LD.call("db_hologram", { conn: t.conn, database: t.db });
      const savedKey = `ld_holo_${t.conn}_${t.db}`;
      const savedPos = localStorage.getItem(savedKey);
      if (savedPos && !force) {
        try { t.positions = JSON.parse(savedPos); } catch { t.positions = {}; }
      } else {
        t.positions = {};
      }
      autoLayout(t, false);
    } catch (err) {
      t.error = err.message;
    }
    t.loading = false;
    renderMain();
  }

  function autoLayout(t, overwrite = true) {
    if (!t.data || !t.data.tables) return;
    const tables = t.data.tables;
    const relations = t.data.relations || [];
    t.positions = t.positions || {};

    const inDegree = {};
    const outDegree = {};
    tables.forEach((tb) => { inDegree[tb.name] = 0; outDegree[tb.name] = 0; });
    relations.forEach((r) => {
      if (inDegree[r.target_table] !== undefined) inDegree[r.target_table]++;
      if (outDegree[r.source_table] !== undefined) outDegree[r.source_table]++;
    });

    const sorted = [...tables].sort((a, b) => {
      const scoreA = inDegree[a.name] * 2 - outDegree[a.name];
      const scoreB = inDegree[b.name] * 2 - outDegree[b.name];
      return scoreB - scoreA;
    });

    const colWidth = 270;
    const colGap = 80;
    const rowGap = 30;
    const colsCount = Math.max(2, Math.min(5, Math.ceil(Math.sqrt(tables.length))));
    const colHeights = new Array(colsCount).fill(60);

    sorted.forEach((tb) => {
      if (!overwrite && t.positions[tb.name]) return;
      let minCol = 0;
      for (let c = 1; c < colsCount; c++) {
        if (colHeights[c] < colHeights[minCol]) minCol = c;
      }
      const x = 60 + minCol * (colWidth + colGap);
      const y = colHeights[minCol];
      t.positions[tb.name] = { x, y };

      const visibleCols = t.compact
        ? tb.columns.filter((col) => col.pk || relations.some((r) => (r.source_table === tb.name && r.source_col === col.name) || (r.target_table === tb.name && r.target_col === col.name)))
        : tb.columns;
      const cardHeight = Math.min(260, 42 + visibleCols.length * 24);
      colHeights[minCol] += cardHeight + rowGap;
    });

    try {
      localStorage.setItem(`ld_holo_${t.conn}_${t.db}`, JSON.stringify(t.positions));
    } catch {}
  }

  function hologramTab(t) {
    const c = conn(t.conn);
    if (t.loading && !t.data) {
      return `
        <div class="hologram-wrap">
          <div class="hologram-bar">
            <div class="hologram-title">${esc(c?.name || "")}<span class="sep">›</span><b>${esc(t.db)}</b><span class="sep">›</span><span>Hologram</span></div>
          </div>
          <div class="hologram-empty">
            <span class="spin-dot" style="width:32px;height:32px;"></span>
            <h3>Analyzing Schema & Relationships…</h3>
            <p>Scanning tables, columns, primary keys, and foreign keys</p>
          </div>
        </div>`;
    }

    if (t.error && !t.data) {
      return `
        <div class="hologram-wrap">
          <div class="hologram-bar">
            <div class="hologram-title">${esc(c?.name || "")}<span class="sep">›</span><b>${esc(t.db)}</b><span class="sep">›</span><span>Hologram</span></div>
          </div>
          <div class="hologram-empty">
            ${icon("alert")}
            <h3>Couldn't load Hologram</h3>
            <p>${esc(t.error)}</p>
            <button class="btn primary sm" data-holo="retry">${icon("refresh")} Retry</button>
          </div>
        </div>`;
    }

    const tables = t.data?.tables || [];
    const relations = t.data?.relations || [];
    const filter = (t.filter || "").toLowerCase().trim();

    return `
      <div class="hologram-wrap" id="hologram-wrap-${t.id}">
        <div class="hologram-bar">
          <div class="hologram-title">
            ${esc(c?.name || "")}<span class="sep">›</span><b>${esc(t.db)}</b><span class="sep">›</span>
            <span>${icon("layers")} Hologram (ERD)</span>
          </div>

          <div class="search sm" style="width:200px; margin-left:12px;">
            ${icon("search")}
            <input type="search" placeholder="Find table…" value="${esc(t.filter || "")}" data-holo-search autocomplete="off">
          </div>

          <button class="btn sm ${t.compact ? "active" : ""}" data-holo="toggle-compact" title="Toggle compact columns">
            ${icon("grid")} ${t.compact ? "Show All Columns" : "Compact (Keys Only)"}
          </button>
          <button class="btn sm" data-holo="autolayout" title="Re-arrange tables neatly">
            ${icon("sparkles")} Auto Layout
          </button>
          <button class="btn sm" data-holo="reload" title="Reload schema">
            ${icon("refresh")}
          </button>

          <span class="spacer"></span>

          <div class="btn-group">
            <button class="btn icon-btn sm" data-holo="zoom-out" title="Zoom Out (-)">${icon("back", "flip-down")}</button>
            <button class="btn sm" data-holo="zoom-reset" title="Reset Zoom">${Math.round((t.zoom || 1) * 100)}%</button>
            <button class="btn icon-btn sm" data-holo="zoom-in" title="Zoom In (+)">${icon("up")}</button>
            <button class="btn sm" data-holo="fit" title="Fit All Tables">Fit</button>
          </div>

          <button class="btn icon-btn sm" data-holo="export-svg" title="Export as SVG">${icon("download")}</button>
        </div>

        <div class="hologram-viewport" id="holo-vp-${t.id}">
          <div class="hologram-canvas" id="holo-canvas-${t.id}" style="transform: translate(${t.panX || 60}px, ${t.panY || 60}px) scale(${t.zoom || 1});">
            <svg class="hologram-svg-layer" id="holo-svg-${t.id}">
              <defs>
                <marker id="holo-arrow" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="var(--accent)" />
                </marker>
                <marker id="holo-arrow-inferred" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#0ea5e9" />
                </marker>
              </defs>
              <g class="hologram-edges-group" id="holo-edges-${t.id}"></g>
            </svg>

            <div class="hologram-nodes-layer" id="holo-nodes-${t.id}">
              ${tables.map((tb) => {
                const pos = (t.positions && t.positions[tb.name]) || { x: 0, y: 0 };
                const isMatch = !filter || tb.name.toLowerCase().includes(filter);
                const cols = t.compact
                  ? tb.columns.filter((col) => col.pk || relations.some((r) => (r.source_table === tb.name && r.source_col === col.name) || (r.target_table === tb.name && r.target_col === col.name)))
                  : tb.columns;

                return `
                  <div class="hologram-card ${isMatch ? "" : "dimmed"}" id="holo-card-${t.id}-${esc(tb.name)}"
                    data-table="${esc(tb.name)}"
                    style="transform: translate3d(${pos.x}px, ${pos.y}px, 0); width: 250px;">
                    <div class="hologram-card-head" data-card-drag="${esc(tb.name)}">
                      ${icon("grid")}
                      <span class="hologram-card-name" title="${esc(tb.name)}">${esc(tb.name)}</span>
                      ${tb.rows !== null ? `<span class="hologram-card-badge">${fmtNum(tb.rows)}</span>` : ""}
                      <div class="hologram-card-actions">
                        <button class="btn ghost icon-btn xs" data-holo-action="model" data-table="${esc(tb.name)}" title="Generate Eloquent Model">${icon("code")}</button>
                        <button class="btn ghost icon-btn xs" data-holo-action="migration" data-table="${esc(tb.name)}" title="Generate Migration">${icon("file")}</button>
                        <button class="btn ghost icon-btn xs" data-holo-action="seed" data-table="${esc(tb.name)}" title="Seed Dummy Data">${icon("zap")}</button>
                        <button class="btn ghost icon-btn xs" data-holo-action="data" data-table="${esc(tb.name)}" title="View Data">${icon("eye")}</button>
                        <button class="btn ghost icon-btn xs" data-holo-action="structure" data-table="${esc(tb.name)}" title="View Structure">${icon("wrench")}</button>
                      </div>
                    </div>
                    <div class="hologram-card-body">
                      ${cols.map((col) => {
                        const isFk = relations.some((r) => r.source_table === tb.name && r.source_col === col.name);
                        return `
                          <div class="hologram-col-row ${col.pk ? "pk" : ""}" data-col="${esc(col.name)}" data-table="${esc(tb.name)}">
                            <span class="hologram-port left" data-port="left" data-table="${esc(tb.name)}" data-col="${esc(col.name)}"></span>
                            ${col.pk ? `<span class="hologram-tag pk">PK</span>` : isFk ? `<span class="hologram-tag fk">FK</span>` : ""}
                            <span class="hologram-col-name" title="${esc(col.name)}">${esc(col.name)}</span>
                            <span class="hologram-col-type" title="${esc(col.type)}">${esc((col.type || "").split("(")[0])}</span>
                            <span class="hologram-port right" data-port="right" data-table="${esc(tb.name)}" data-col="${esc(col.name)}"></span>
                          </div>`;
                      }).join("")}
                    </div>
                  </div>`;
              }).join("")}
            </div>
          </div>

          <div class="hologram-stats-floating">
            <span><b>${tables.length}</b> tables</span>
            <span>·</span>
            <span><b>${relations.length}</b> relationships</span>
            ${relations.some((r) => r.inferred) ? `<span style="color:#0ea5e9;">(${relations.filter((r) => r.inferred).length} inferred)</span>` : ""}
          </div>
        </div>
      </div>`;
  }

  function drawHologramEdges(t, root) {
    const svgGroup = $("#holo-edges-" + t.id, root);
    if (!svgGroup || !t.data || !t.data.relations) return;
    const relations = t.data.relations;
    const filter = (t.filter || "").toLowerCase().trim();

    let pathsHtml = "";
    relations.forEach((rel) => {
      const sp = t.positions[rel.source_table];
      const tp = t.positions[rel.target_table];
      if (!sp || !tp) return;

      const sourceCard = $(`#holo-card-${t.id}-${CSS.escape(rel.source_table)}`, root);
      const targetCard = $(`#holo-card-${t.id}-${CSS.escape(rel.target_table)}`, root);

      let sy = sp.y + 35;
      let ty = tp.y + 35;

      if (sourceCard) {
        const row = $(`[data-col="${CSS.escape(rel.source_col)}"]`, sourceCard);
        if (row) sy = sp.y + row.offsetTop + 11;
      }
      if (targetCard) {
        const row = $(`[data-col="${CSS.escape(rel.target_col)}"]`, targetCard);
        if (row) ty = tp.y + row.offsetTop + 11;
      }

      const isRight = tp.x >= sp.x;
      const sx = isRight ? sp.x + 250 : sp.x;
      const tx = isRight ? tp.x : tp.x + 250;
      const dx = Math.max(50, Math.abs(tx - sx) * 0.45);
      const d = `M ${sx} ${sy} C ${sx + (isRight ? dx : -dx)} ${sy}, ${tx + (isRight ? -dx : dx)} ${ty}, ${tx} ${ty}`;

      const isDimmed = filter && (!rel.source_table.toLowerCase().includes(filter) && !rel.target_table.toLowerCase().includes(filter));
      const isHighlighted = t.hoverTable && (rel.source_table === t.hoverTable || rel.target_table === t.hoverTable);
      const isRelHover = t.hoverRel === rel.id;

      const cls = ["hologram-edge"];
      if (rel.inferred) cls.push("inferred");
      if (isDimmed) cls.push("dimmed");
      if (isHighlighted || isRelHover) cls.push("highlighted");

      const marker = rel.inferred ? "url(#holo-arrow-inferred)" : "url(#holo-arrow)";
      const title = `${esc(rel.source_table)}.${esc(rel.source_col)} ➔ ${esc(rel.target_table)}.${esc(rel.target_col)}${rel.on_delete ? ` (ON DELETE ${esc(rel.on_delete)})` : ""}${rel.inferred ? " [Inferred]" : ""}`;

      pathsHtml += `<path d="${d}" class="${cls.join(" ")}" data-rel="${esc(rel.id)}" data-source="${esc(rel.source_table)}" data-target="${esc(rel.target_table)}" marker-end="${marker}"><title>${title}</title></path>`;
    });

    svgGroup.innerHTML = pathsHtml;
  }

  function updateHologramTransform(t) {
    const canvas = $(`#holo-canvas-${t.id}`);
    if (canvas) {
      canvas.style.transform = `translate(${t.panX || 60}px, ${t.panY || 60}px) scale(${t.zoom || 1})`;
    }
    const zoomBtn = $(`[data-holo="zoom-reset"]`);
    if (zoomBtn) {
      zoomBtn.textContent = `${Math.round((t.zoom || 1) * 100)}%`;
    }
  }

  function fitHologram(t) {
    if (!t.data || !t.data.tables || !t.data.tables.length) return;
    const vp = $(`#holo-vp-${t.id}`);
    if (!vp) return;
    const rect = vp.getBoundingClientRect();
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    t.data.tables.forEach((tb) => {
      const p = t.positions[tb.name] || { x: 0, y: 0 };
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x + 250);
      maxY = Math.max(maxY, p.y + 240);
    });
    const padding = 60;
    const w = (maxX - minX) + padding * 2;
    const h = (maxY - minY) + padding * 2;
    const scaleX = rect.width / w;
    const scaleY = rect.height / h;
    t.zoom = Math.min(1.2, Math.max(0.3, Math.min(scaleX, scaleY)));
    t.panX = (rect.width - (maxX - minX) * t.zoom) / 2 - minX * t.zoom;
    t.panY = (rect.height - (maxY - minY) * t.zoom) / 2 - minY * t.zoom;
    updateHologramTransform(t);
  }

  function bindHologramEvents(t, root) {
    const vp = $(`#holo-vp-${t.id}`, root);
    const canvas = $(`#holo-canvas-${t.id}`, root);
    if (!vp || !canvas) return;

    drawHologramEdges(t, root);

    // Card Dragging
    $$("[data-card-drag]", root).forEach((head) => {
      head.addEventListener("mousedown", (e) => {
        if (e.target.closest("button")) return;
        e.stopPropagation();
        const tableName = head.dataset.cardDrag;
        const card = $(`#holo-card-${t.id}-${CSS.escape(tableName)}`, root);
        if (!card) return;
        const startX = e.clientX, startY = e.clientY;
        const orig = { ...(t.positions[tableName] || { x: 0, y: 0 }) };

        function onMove(ev) {
          const dx = (ev.clientX - startX) / (t.zoom || 1);
          const dy = (ev.clientY - startY) / (t.zoom || 1);
          t.positions[tableName] = {
            x: Math.round(orig.x + dx),
            y: Math.round(orig.y + dy)
          };
          card.style.transform = `translate3d(${t.positions[tableName].x}px, ${t.positions[tableName].y}px, 0)`;
          drawHologramEdges(t, root);
        }

        function onUp() {
          window.removeEventListener("mousemove", onMove);
          window.removeEventListener("mouseup", onUp);
          try {
            localStorage.setItem(`ld_holo_${t.conn}_${t.db}`, JSON.stringify(t.positions));
          } catch {}
        }

        window.addEventListener("mousemove", onMove);
        window.addEventListener("mouseup", onUp);
      });
    });

    // Canvas Panning
    vp.addEventListener("mousedown", (e) => {
      if (e.target.closest(".hologram-card") || e.target.closest("button") || e.target.closest("input")) return;
      vp.classList.add("panning");
      const startX = e.clientX, startY = e.clientY;
      const startPanX = t.panX || 60, startPanY = t.panY || 60;

      function onMove(ev) {
        t.panX = startPanX + (ev.clientX - startX);
        t.panY = startPanY + (ev.clientY - startY);
        updateHologramTransform(t);
      }

      function onUp() {
        vp.classList.remove("panning");
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
      }

      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    });

    // Canvas Zooming with mouse wheel
    vp.addEventListener("wheel", (e) => {
      e.preventDefault();
      const factor = e.deltaY < 0 ? 1.08 : 0.92;
      const newZoom = Math.min(Math.max((t.zoom || 1) * factor, 0.25), 2.5);
      const rect = vp.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;
      t.panX = mouseX - (mouseX - (t.panX || 60)) * (newZoom / (t.zoom || 1));
      t.panY = mouseY - (mouseY - (t.panY || 60)) * (newZoom / (t.zoom || 1));
      t.zoom = newZoom;
      updateHologramTransform(t);
    }, { passive: false });

    // Table Hover Highlighting
    $$(".hologram-card", root).forEach((card) => {
      card.addEventListener("mouseenter", () => {
        t.hoverTable = card.dataset.table;
        card.classList.add("highlighted");
        drawHologramEdges(t, root);
      });
      card.addEventListener("mouseleave", () => {
        t.hoverTable = null;
        card.classList.remove("highlighted");
        drawHologramEdges(t, root);
      });
    });

    // Search filter input
    const searchInput = $("[data-holo-search]", root);
    if (searchInput) {
      searchInput.addEventListener("input", (e) => {
        t.filter = e.target.value;
        const val = t.filter.toLowerCase().trim();
        $$(".hologram-card", root).forEach((c) => {
          c.classList.toggle("dimmed", Boolean(val && !c.dataset.table.toLowerCase().includes(val)));
        });
        drawHologramEdges(t, root);
      });
    }
  }

  function exportHologramSvg(t) {
    if (!t.data || !t.data.tables) return;
    const tables = t.data.tables;
    const relations = t.data.relations || [];
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    tables.forEach((tb) => {
      const p = t.positions[tb.name] || { x: 0, y: 0 };
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x + 260);
      maxY = Math.max(maxY, p.y + 300);
    });
    const padding = 50;
    const width = Math.max(600, (maxX - minX) + padding * 2);
    const height = Math.max(400, (maxY - minY) + padding * 2);
    const offsetX = padding - minX;
    const offsetY = padding - minY;

    let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">\n`;
    svg += `<style>
      .bg { fill: #18181b; }
      .card { fill: #27272a; stroke: #3f3f46; stroke-width: 1; rx: 8; }
      .head { font-family: sans-serif; font-weight: bold; font-size: 13px; fill: #f4f4f5; }
      .col { font-family: sans-serif; font-size: 11px; fill: #a1a1aa; }
      .col-pk { font-weight: bold; fill: #fbbf24; }
      .edge { fill: none; stroke: var(--accent); stroke-width: 2; opacity: 0.8; }
      .edge-inf { fill: none; stroke: #0ea5e9; stroke-width: 2; stroke-dasharray: 4 3; opacity: 0.8; }
    </style>\n`;
    svg += `<rect width="100%" height="100%" class="bg"/>\n`;

    relations.forEach((r) => {
      const sp = t.positions[r.source_table];
      const tp = t.positions[r.target_table];
      if (!sp || !tp) return;
      const x1 = sp.x + offsetX + (tp.x > sp.x ? 250 : 0);
      const y1 = sp.y + offsetY + 60;
      const x2 = tp.x + offsetX + (tp.x > sp.x ? 0 : 250);
      const y2 = tp.y + offsetY + 60;
      const dx = Math.abs(x2 - x1) * 0.5;
      const cls = r.inferred ? "edge-inf" : "edge";
      svg += `<path d="M ${x1} ${y1} C ${x1 + (x2 > x1 ? dx : -dx)} ${y1}, ${x2 + (x2 > x1 ? -dx : dx)} ${y2}, ${x2} ${y2}" class="${cls}"/>\n`;
    });

    tables.forEach((tb) => {
      const p = t.positions[tb.name] || { x: 0, y: 0 };
      const x = p.x + offsetX;
      const y = p.y + offsetY;
      const visibleCols = tb.columns.slice(0, 10);
      const h = 36 + visibleCols.length * 20 + 10;
      svg += `<rect x="${x}" y="${y}" width="250" height="${h}" class="card"/>\n`;
      svg += `<text x="${x + 12}" y="${y + 24}" class="head">${esc(tb.name)}</text>\n`;
      visibleCols.forEach((col, i) => {
        const cy = y + 46 + i * 20;
        const cls = col.pk ? "col col-pk" : "col";
        svg += `<text x="${x + 14}" y="${cy}" class="${cls}">${col.pk ? "🔑 " : ""}${esc(col.name)} (${esc((col.type || "").split("(")[0])})</text>\n`;
      });
    });

    svg += `</svg>`;
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hologram_${t.db}_schema.svg`;
    a.click();
    URL.revokeObjectURL(url);
    toast("success", "Schema Exported", `Saved hologram_${t.db}_schema.svg`);
  }

  async function testConnAction(c) {
    toast("info", `Testing ${c.name}…`);
    try {
      const res = await LD.call("db_test", { id: c.id, existing: true });
      let details = `${res.version} · ${res.ms} ms`;
      if (res.ssh) details = `SSH (${res.ssh.ms}ms) + DB (${res.ms}ms)`;
      toast("success", `Connected to ${c.name}`, details);
    } catch (err) {
      toast("error", `Connection to ${c.name} failed`, err.message);
    }
  }

  /* ── context menu ───────────────────────────────────────── */
  function showMenu(x, y, items) {
    hideMenu();
    menuEl = document.createElement("div");
    menuEl.className = "ctx-menu";
    menuEl.innerHTML = items.map((it, i) => it === "-" ? `<hr>` : `<button data-mi="${i}" class="${it.danger ? "danger" : ""}" ${it.disabled ? "disabled" : ""}>${it.icon ? icon(it.icon) : ""}${esc(it.label)}</button>`).join("");
    document.body.append(menuEl);
    const rect = menuEl.getBoundingClientRect();
    menuEl.style.left = `${Math.min(x, innerWidth - rect.width - 8)}px`;
    menuEl.style.top = `${Math.min(y, innerHeight - rect.height - 8)}px`;
    menuEl.addEventListener("click", (e) => {
      const b = e.target.closest("[data-mi]");
      if (!b) return;
      const item = items[+b.dataset.mi];
      hideMenu();
      item.run();
    });
  }
  function hideMenu() { menuEl?.remove(); menuEl = null; }

  function connMenu(c) {
    const node = S.tree[c.id];
    return [
      { label: node?.open ? "Refresh" : "Connect", icon: "refresh", run: () => openConn(c.id) },
      { label: "Test connection…", icon: "pulse", run: () => testConnAction(c) },
      { label: "New query", icon: "terminal", run: () => openTab({ kind: "query", conn: c.id, db: c.database || node?.default || (c.driver === "sqlite" ? "main" : "") }) },
      ...(c.driver !== "sqlite" ? [{ label: "New database…", icon: "plus", run: () => createDbModal(c) }] : []),
      "-",
      ...(c.source === "saved" ? [{ label: "Edit connection…", icon: "edit", run: () => connModal(c) }] : []),
      ...(c.source === "site" ? [{ label: "Edit project .env", icon: "file", run: () => { setView("sites"); openDrawer(c.site, "env"); } }] : []),
      ...(c.source !== "saved" ? [{ label: "Save as connection…", icon: "plus", run: () => connModal({ ...c, id: undefined, name: `${c.name} copy`, source: "saved" }) }] : []),
      { label: "Disconnect", icon: "power", disabled: !c.open, run: async () => {
        await LD.call("db_close", { id: c.id });
        c.open = false;
        if (S.tree[c.id]) S.tree[c.id].open = false;
        renderTree();
      } },
    ];
  }

  function dbMenu(c, db) {
    return [
      { label: "Open", icon: "database", run: () => openTab({ kind: "db", conn: c.id, db }) },
      { label: "Hologram (ERD)…", icon: "layers", run: () => openHologram(c.id, db) },
      { label: "Compare with… (Schema Diff)", icon: "layers", run: () => openDiffTab({ srcConn: c.id, srcDb: db }) },
      { label: "New query", icon: "terminal", run: () => openTab({ kind: "query", conn: c.id, db }) },
      { label: "Refresh", icon: "refresh", run: () => openDb(c.id, db, true) },
      "-",
      { label: "Export as SQL…", icon: "download", run: () => exportData(c.id, db, [], "sql") },
      { label: "Import .sql file…", icon: "upload", run: () => importSql(c.id, db) },
      ...(c.driver !== "sqlite" ? ["-", { label: "Drop database…", icon: "trash", danger: true, run: () => dropDb(c, db) }] : []),
    ];
  }

  function tableMenu(c, db, table) {
    const meta = S.tree[c.id]?.dbs[db]?.tables?.find((t) => t.name === table) || {};
    return [
      { label: "Open", icon: "grid", run: () => openTab({ kind: "table", conn: c.id, db, table }) },
      { label: "Filter Table…", icon: "filter", run: () => openTab({ kind: "table", conn: c.id, db, table, showFilters: true }) },
      { label: "Structure", icon: "layers", run: () => { openTab({ kind: "table", conn: c.id, db, table }); tab().sub = "structure"; renderMain(); } },
      { label: "Query this table", icon: "terminal", run: () => openTab({ kind: "query", conn: c.id, db, sql: `SELECT * FROM ${q(c.driver, table)} LIMIT 100;` }) },
      "-",
      { label: "Generate Eloquent Model…", icon: "code", run: () => openModelModal(c.id, db, table) },
      { label: "Generate Migration…", icon: "file", run: () => openMigrationModal(c.id, db, table) },
      { label: "Seed Dummy Data…", icon: "zap", run: () => openSeedModal(c.id, db, table) },
      "-",
      { label: "Export as SQL…", icon: "download", run: () => exportData(c.id, db, [table], "sql") },
      { label: "Export as CSV…", icon: "download", run: () => exportData(c.id, db, [table], "csv") },
      { label: "Export as JSON…", icon: "download", run: () => exportData(c.id, db, [table], "json") },
      "-",
      { label: "Rename…", icon: "rename", run: () => renameTable(c, db, table) },
      ...(meta.view ? [] : [{ label: "Empty table…", icon: "x", danger: true, run: () => tableOp(c, db, table, "truncate") }]),
      { label: `Drop ${meta.view ? "view" : "table"}…`, icon: "trash", danger: true, run: () => tableOp(c, db, table, "drop") },
    ];
  }

  function cellMenu(t, ri, colIndex) {
    const d = t.data;
    const col = d.columns[colIndex];
    const row = d.rows[ri];
    const value = (t.edits.get(ri) || {})[col.name] ?? row[colIndex];
    const asObject = Object.fromEntries(d.columns.filter((c) => !c.hidden).map((c) => [c.name, row[d.columns.indexOf(c)]]));
    return [
      { label: "Copy value", icon: "copy", run: () => copyText(value === null ? "NULL" : String(value)) },
      { label: "Copy row as JSON", icon: "copy", run: () => copyText(JSON.stringify(asObject, null, 2)) },
      { label: "Copy row as INSERT", icon: "copy", run: () => {
        const cols = Object.keys(asObject);
        const vals = Object.values(asObject).map((v) => v === null ? "NULL" : typeof v === "number" ? v : `'${String(v).replace(/'/g, "''")}'`);
        copyText(`INSERT INTO ${q(conn(t.conn).driver, t.table)} (${cols.map((c) => q(conn(t.conn).driver, c)).join(", ")}) VALUES (${vals.join(", ")});`);
      } },
      "-",
      { label: `Filter: ${col.name} = this`, icon: "filter", run: () => {
        t.filters = t.filters || [];
        t.filters.push({ column: col.name, op: value === null ? "IS NULL" : "=", value: value === null ? "" : value });
        t.showFilters = true;
        loadRows(t, { keepPage: false });
      } },
      { label: `Filter: ${col.name} != this`, icon: "filter", run: () => {
        t.filters = t.filters || [];
        t.filters.push({ column: col.name, op: value === null ? "IS NOT NULL" : "!=", value: value === null ? "" : value });
        t.showFilters = true;
        loadRows(t, { keepPage: false });
      } },
      ...(d.view ? [] : [
        { label: "Set NULL", icon: "x", disabled: !col.nullable || col.binary, run: () => { setCell(t, false, ri, col.name, null); renderMain(); } },
        { label: t.deletes.has(ri) ? "Restore row" : "Delete row", icon: "trash", danger: !t.deletes.has(ri), run: () => {
          t.deletes.has(ri) ? t.deletes.delete(ri) : t.deletes.add(ri);
          renderTabs(); renderMain();
        } },
      ]),
    ];
  }

  /* ── operations ─────────────────────────────────────────── */
  function exportData(connId, db, tables, format) {
    LD.call("db_export", { conn: connId, database: db, tables, format }).then((started) => {
      if (started) toast("success", "Export started", "You'll get a message when it's done.");
    }).catch((err) => toast("error", "Export failed", err.message));
  }

  async function importSql(connId, db) {
    if (!(await confirmModal({ title: `Import into ${db}?`, message: `Statements in the file run against <b>${esc(db)}</b> on ${esc(conn(connId)?.name)}. Dumps usually drop and recreate their tables.`, confirm: "Choose file…" }))) return;
    LD.call("db_import", { conn: connId, database: db }).then((started) => {
      if (started) toast("success", "Import started");
    }).catch((err) => toast("error", "Import failed", err.message));
  }

  async function openSnapshotsModal(connId, dbName) {
    const c = conn(connId);
    const siteName = c?.site_name || c?.name || dbName;

    openModal(`
      <div class="modal" style="max-width:720px">
        <div class="modal-header">
          <h2>${icon("camera")} Database Snapshots · ${esc(dbName)}</h2>
          <p>Instant database snapshots for rapid testing, migration rollbacks, and schema experimentation.</p>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <div style="display:flex;gap:8px;align-items:center;background:var(--surface-2);padding:10px;border-radius:6px">
            <input type="text" id="snap-new-name" placeholder="Snapshot name (e.g. before-migrate)" class="input sm" style="flex:1">
            <input type="text" id="snap-new-desc" placeholder="Optional description" class="input sm" style="flex:1">
            <button class="btn sm primary" id="btn-create-snap">${icon("camera")} Take Snapshot</button>
          </div>
          <div id="snapshots-list-pane" style="max-height:50vh;overflow-y:auto">
            <div class="loading-pane sm">${icon("pulse")} Loading snapshots…</div>
          </div>
        </div>
        <div class="modal-footer"><button type="button" class="btn" data-dismiss>Close</button></div>
      </div>`, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      async function refreshSnaps() {
        const pane = $("#snapshots-list-pane", root);
        if (!pane) return;
        pane.innerHTML = `<div class="loading-pane sm">${icon("pulse")} Loading snapshots…</div>`;
        try {
          const res = await LD.call("db_snapshots_list", { name: siteName });
          const snaps = res.snapshots || [];
          if (!snaps.length) {
            pane.innerHTML = `<div class="muted sm" style="padding:24px;text-align:center">No snapshots saved for this project yet. Take one above!</div>`;
            return;
          }
          pane.innerHTML = `
            <div class="routes-table-wrap">
              <table class="routes-table" style="font-size:12px">
                <thead><tr><th>Name</th><th>Created</th><th>Tables</th><th>Size</th><th>Actions</th></tr></thead>
                <tbody>
                  ${snaps.map((s) => `
                    <tr>
                      <td>
                        <b style="font-size:12.5px">${esc(s.name)}</b>
                        ${s.description ? `<div class="muted xs">${esc(s.description)}</div>` : ""}
                        ${s.git_commit ? `<span class="chip xs" style="font-family:var(--mono)">git: ${esc(s.git_commit)}</span>` : ""}
                      </td>
                      <td><span class="muted" style="font-size:11px">${new Date(s.created_at).toLocaleString()}</span></td>
                      <td><span class="chip sm">${s.tables_count || "—"}</span></td>
                      <td><span class="mono" style="font-size:11.5px">${fmtBytes(s.size_bytes || 0)}</span></td>
                      <td style="white-space:nowrap">
                        <button class="btn xs primary" data-restore-snap="${esc(s.id)}">${icon("refresh")} Restore</button>
                        <button class="btn xs ghost danger" data-del-snap="${esc(s.id)}">${icon("trash")}</button>
                      </td>
                    </tr>
                  `).join("")}
                </tbody>
              </table>
            </div>
          `;

          $$("[data-restore-snap]", pane).forEach((btn) => {
            btn.addEventListener("click", async () => {
              const sid = btn.dataset.restoreSnap;
              if (!(await confirmModal({ title: "Restore database snapshot?", message: "This will overwrite current database state with this snapshot.", confirm: "Restore", danger: true }))) return;
              btn.disabled = true;
              btn.innerHTML = `${icon("pulse")} Restoring…`;
              try {
                const r = await LD.call("db_snapshot_restore", { name: siteName, snapshot_id: sid });
                if (r.ok) {
                  toast("success", "Database restored from snapshot");
                  closeModal();
                  openDb(connId, dbName, true);
                } else {
                  toast("error", "Restore failed", r.error);
                }
              } catch (err) {
                toast("error", "Restore failed", err.message);
              }
            });
          });

          $$("[data-del-snap]", pane).forEach((btn) => {
            btn.addEventListener("click", async () => {
              const sid = btn.dataset.delSnap;
              await LD.call("db_snapshot_delete", { name: siteName, snapshot_id: sid });
              toast("success", "Snapshot deleted");
              refreshSnaps();
            });
          });
        } catch (err) {
          pane.innerHTML = `<div style="padding:16px;color:var(--red)">Failed to load snapshots: ${esc(err.message)}</div>`;
        }
      }

      $("#btn-create-snap", root)?.addEventListener("click", async () => {
        const nameInput = $("#snap-new-name", root);
        const descInput = $("#snap-new-desc", root);
        const sName = nameInput.value.trim() || "snapshot";
        const btn = $("#btn-create-snap", root);
        btn.disabled = true;
        btn.innerHTML = `${icon("pulse")} Saving…`;
        try {
          const res = await LD.call("db_snapshot_create", { name: siteName, snapshot_name: sName, description: descInput.value.trim() });
          if (res.ok) {
            toast("success", "Snapshot created successfully");
            nameInput.value = "";
            descInput.value = "";
            refreshSnaps();
          } else {
            toast("error", "Failed to create snapshot", res.error);
          }
        } catch (err) {
          toast("error", "Failed to create snapshot", err.message);
        } finally {
          btn.disabled = false;
          btn.innerHTML = `${icon("camera")} Take Snapshot`;
        }
      });

      refreshSnaps();
    });
  }

  function createDbModal(c) {
    openModal(`
      <form class="modal sm" id="newdb-form">
        <div class="modal-header"><h2>New database</h2><p>On ${esc(c.name)}</p></div>
        <div class="modal-body">
          <label class="field"><span>Name</span><input name="name" placeholder="shop" spellcheck="false" autocomplete="off"></label>
          ${c.driver !== "pgsql" ? `<div class="grid-2">
            <label class="field"><span>Charset</span><input name="charset" value="utf8mb4"></label>
            <label class="field"><span>Collation</span><input name="collation" value="utf8mb4_unicode_ci"></label></div>` : ""}
        </div>
        <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">Create</button></div>
      </form>`, (root) => {
      const form = $("#newdb-form", root);
      $("[data-dismiss]", form).addEventListener("click", closeModal);
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const name = form.elements.name.value.trim();
        try {
          await LD.call("db_create_database", { conn: c.id, name, charset: form.elements.charset?.value, collation: form.elements.collation?.value });
          closeModal();
          toast("success", `Database ${name} created`);
          await openConn(c.id);
          openDb(c.id, name);
        } catch (err) {
          toast("error", "Couldn't create the database", err.message);
        }
      });
    });
  }

  async function dropDb(c, db) {
    if (!(await confirmModal({ title: `Drop ${db}?`, danger: true, confirm: "Drop database", requireText: db,
      message: `Permanently deletes <b>${esc(db)}</b> and every table in it on ${esc(c.name)}.` }))) return;
    try {
      await LD.call("db_drop_database", { conn: c.id, name: db });
      S.tabs.filter((t) => t.conn === c.id && t.db === db).forEach((t) => { t.edits = new Map(); t.inserts = []; t.deletes = new Set(); closeTab(t.id); });
      toast("success", `Dropped ${db}`);
      openConn(c.id);
    } catch (err) {
      toast("error", "Couldn't drop it", err.message);
    }
  }

  async function tableOp(c, db, table, op) {
    const verb = op === "drop" ? "Drop" : "Empty";
    if (!(await confirmModal({ title: `${verb} ${table}?`, danger: true, confirm: verb, requireText: op === "drop" ? table : "",
      message: op === "drop" ? `Permanently deletes <b>${esc(table)}</b> and its data.` : `Deletes every row in <b>${esc(table)}</b>. The table stays.` }))) return;
    try {
      await LD.call("db_table_op", { conn: c.id, database: db, table, op });
      toast("success", `${verb === "Drop" ? "Dropped" : "Emptied"} ${table}`);
      if (op === "drop") S.tabs.filter((t) => t.kind === "table" && t.conn === c.id && t.db === db && t.table === table).forEach((t) => { t.edits = new Map(); t.inserts = []; t.deletes = new Set(); closeTab(t.id); });
      else S.tabs.filter((t) => t.kind === "table" && t.table === table && t.conn === c.id).forEach((t) => loadRows(t));
      openDb(c.id, db, true);
    } catch (err) {
      toast("error", `Couldn't ${verb.toLowerCase()} ${table}`, err.message);
    }
  }

  async function renameTable(c, db, table) {
    const target = await promptModal(`Rename ${table}`, "New name", table);
    if (!target || target === table) return;
    try {
      await LD.call("db_table_op", { conn: c.id, database: db, table, op: "rename", target });
      S.tabs.filter((t) => t.kind === "table" && t.conn === c.id && t.db === db && t.table === table).forEach((t) => { t.table = target; t.data = null; });
      openDb(c.id, db, true);
      renderTabs();
      renderMain();
    } catch (err) {
      toast("error", "Couldn't rename", err.message);
    }
  }

  /* ── code generation & seeder modals (Phase 1) ────────── */

  function highlightPhp(code) {
    const re = /(\/\*[\s\S]*?\*\/|\/\/[^\n]*)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|(\$[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)|(\b(?:class|new|extends|implements|public|protected|private|function|return|use|namespace|void|bool|int|string|float|array|true|false|null|if|else|foreach)\b)|(\b[A-Z][a-zA-Z0-9_]*\b)/g;

    let lastIndex = 0;
    let html = "";
    let m;
    while ((m = re.exec(code)) !== null) {
      if (m.index > lastIndex) {
        html += esc(code.slice(lastIndex, m.index));
      }
      const [match, comment, str, variable, keyword, typeName] = m;
      if (comment) html += `<span class="tok-comment">${esc(match)}</span>`;
      else if (str) html += `<span class="tok-str">${esc(match)}</span>`;
      else if (variable) html += `<span class="tok-var">${esc(match)}</span>`;
      else if (keyword) html += `<span class="tok-kw">${esc(match)}</span>`;
      else if (typeName) html += `<span class="tok-type">${esc(match)}</span>`;
      lastIndex = re.lastIndex;
    }
    if (lastIndex < code.length) html += esc(code.slice(lastIndex));
    return html;
  }

  function openCodeModal({ title, type, fileName, code, connId, database, table }) {
    const c = conn(connId);
    const sitesList = (window.state?.sites || []).map((s) => s.name);
    const defaultSite = c?.site || sitesList[0] || "";

    const folderMap = {
      model: "app/Models/",
      migration: "database/migrations/",
      seeder: "database/seeders/"
    };
    const targetFolder = folderMap[type] || "";

    openModal(`
      <div class="modal code-preview-modal" id="code-modal">
        <div class="modal-header" style="padding-bottom: 12px;">
          <h2>${esc(title)}</h2>
          <p>Generated Laravel code for table <b>${esc(table)}</b>.</p>
        </div>

        <div class="modal-body" style="padding-top: 0;">
          <div class="code-preview-bar">
            <div class="code-preview-meta">
              <span class="code-badge">${esc(targetFolder)}</span>
              <input id="code-modal-filename" value="${esc(fileName)}" spellcheck="false" style="font-family:var(--font-mono, monospace); font-size:12px; width:260px; padding:4px 8px; border:1px solid var(--border); border-radius:6px; background:var(--surface); color:var(--text);">
            </div>
            <div class="code-preview-tools">
              ${sitesList.length ? `
                <select id="code-modal-site" style="font-size:12px; padding:4px 8px; border:1px solid var(--border); border-radius:6px; background:var(--surface); color:var(--text);">
                  ${sitesList.map((s) => `<option value="${esc(s)}" ${s === defaultSite ? "selected" : ""}>Project: ${esc(s)}</option>`).join("")}
                </select>
              ` : ""}
              <button type="button" class="btn sm" id="code-modal-copy">${icon("copy")} Copy</button>
              <button type="button" class="btn sm primary" id="code-modal-save">${icon("check")} Save to Project</button>
            </div>
          </div>

          <pre class="code-preview-pre"><code>${highlightPhp(code)}</code></pre>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>Close</button>
        </div>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      $("#code-modal-copy", root)?.addEventListener("click", async function () {
        try {
          await navigator.clipboard.writeText(code);
          const orig = this.innerHTML;
          this.innerHTML = `${icon("check")} Copied!`;
          setTimeout(() => { this.innerHTML = orig; }, 1800);
          toast("success", "Code copied to clipboard");
        } catch {
          copyText(code);
        }
      });

      $("#code-modal-save", root)?.addEventListener("click", async function () {
        const site = $("#code-modal-site", root)?.value || defaultSite;
        if (!site) {
          toast("error", "Choose a project first");
          return;
        }
        const fn = $("#code-modal-filename", root)?.value.trim() || fileName;
        this.disabled = true;
        this.innerHTML = `${icon("refresh")} Saving…`;
        try {
          let res = await LD.call("db_save_code", { site, type, file_name: fn, code, overwrite: false });
          if (res.exists) {
            this.disabled = false;
            this.innerHTML = `${icon("check")} Save to Project`;
            const confirmed = await confirmModal({
              title: `${res.file_name || fn} already exists`,
              message: `${esc(res.message || "A file with this name already exists.")}<br><br>Do you want to overwrite it?`,
              confirm: "Overwrite",
              danger: true,
            });
            if (!confirmed) return;

            this.disabled = true;
            this.innerHTML = `${icon("refresh")} Overwriting…`;
            res = await LD.call("db_save_code", { site, type, file_name: fn, code, overwrite: true });
          }
          if (res.ok) {
            toast("success", `Saved to ${res.path}`);
            closeModal();
          } else {
            throw new Error(res.error || "Failed to save file");
          }
        } catch (err) {
          this.disabled = false;
          this.innerHTML = `${icon("check")} Save to Project`;
          toast("error", "Couldn't save file", err.message);
        }
      });
    });
  }

  async function openModelModal(connId, database, table) {
    try {
      const res = await LD.call("db_generate_model", { conn: connId, database, table });
      openCodeModal({
        title: `Eloquent Model: ${res.model}`,
        type: "model",
        fileName: res.file_name,
        code: res.code,
        connId,
        database,
        table
      });
    } catch (err) {
      toast("error", "Failed to generate model", err.message);
    }
  }

  async function openMigrationModal(connId, database, table) {
    try {
      const res = await LD.call("db_generate_migration", { conn: connId, database, table });
      openCodeModal({
        title: `Laravel Migration: ${table}`,
        type: "migration",
        fileName: res.file_name,
        code: res.code,
        connId,
        database,
        table
      });
    } catch (err) {
      toast("error", "Failed to generate migration", err.message);
    }
  }

  function openSeedModal(connId, database, table) {
    let selectedCount = 25;
    let selectedMode = "insert";

    openModal(`
      <div class="modal seeder-modal" id="seed-modal">
        <div class="modal-header">
          <h2>Seed Dummy Data</h2>
          <p>Generate realistic mock records for <b>${esc(table)}</b>.</p>
        </div>

        <div class="modal-body">
          <label class="field">
            <span>Number of Records</span>
            <div class="seed-count-pills">
              ${[10, 25, 50, 100, 500].map((num) => `
                <button type="button" class="seed-count-pill ${num === selectedCount ? "active" : ""}" data-count="${num}">
                  ${num}
                </button>
              `).join("")}
            </div>
          </label>

          <label class="field" style="margin-top: 8px;">
            <span>Seeding Mode</span>
            <div class="seed-mode-group">
              <label class="seed-mode-card ${selectedMode === "insert" ? "active" : ""}">
                <input type="radio" name="seed-mode" value="insert" ${selectedMode === "insert" ? "checked" : ""}>
                <div>
                  <div class="seed-mode-title">⚡ Direct Insert to Database</div>
                  <div class="seed-mode-desc">Immediately stream realistic records into the live database table with real foreign keys.</div>
                </div>
              </label>

              <label class="seed-mode-card ${selectedMode === "code" ? "active" : ""}">
                <input type="radio" name="seed-mode" value="code" ${selectedMode === "code" ? "checked" : ""}>
                <div>
                  <div class="seed-mode-title">📄 Generate Laravel Seeder File</div>
                  <div class="seed-mode-desc">Create a Database\\Seeders PHP class file that you can save or run via artisan db:seed.</div>
                </div>
              </label>
            </div>
          </label>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss>Cancel</button>
          <button type="button" class="btn primary" id="seed-modal-submit">${icon("zap")} Start Seeding</button>
        </div>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      $$(".seed-count-pill", root).forEach((btn) => {
        btn.addEventListener("click", () => {
          $$(".seed-count-pill", root).forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          selectedCount = Number(btn.dataset.count);
        });
      });

      $$(".seed-mode-card", root).forEach((card) => {
        card.addEventListener("click", () => {
          $$(".seed-mode-card", root).forEach((c) => c.classList.remove("active"));
          card.classList.add("active");
          selectedMode = card.querySelector("input").value;
          const submitBtn = $("#seed-modal-submit", root);
          if (submitBtn) {
            submitBtn.innerHTML = selectedMode === "insert" ? `${icon("zap")} Start Seeding` : `${icon("code")} Generate Seeder`;
          }
        });
      });

      $("#seed-modal-submit", root)?.addEventListener("click", async function () {
        if (selectedMode === "insert") {
          const connObj = S.connections?.find((c) => c.id === connId);
          const isRemote = Boolean(connObj?.use_ssh || connObj?.server || connObj?.source === "server");
          const isProd = /prod/i.test(database) || /prod/i.test(connObj?.name || "");

          if (isRemote || isProd) {
            const confirmed = await confirmModal({
              title: "⚠️ Remote / Production Database Guard",
              message: `You are about to insert ${selectedCount} mock records directly into table "${table}" on ${isProd ? "production " : ""}database "${database}" (${connObj?.name || connId}). Type "${database}" to confirm:`,
              confirm: "Confirm & Insert",
              danger: true,
              requireText: database,
            });
            if (!confirmed) return;
          } else {
            const confirmed = await confirmModal({
              title: "Insert mock records?",
              message: `Insert ${selectedCount} realistic mock records into table "${table}" on database "${database}" (${connObj?.name || connId})?`,
              confirm: "Insert Data",
              danger: false,
            });
            if (!confirmed) return;
          }
        }

        this.disabled = true;
        this.innerHTML = `${icon("refresh", "spin")} Processing…`;
        try {
          if (selectedMode === "insert") {
            const res = await LD.call("db_seed_data", { conn: connId, database, table, count: selectedCount, mode: "insert" });
            toast("success", `Inserted ${res.inserted} mock rows into ${res.table} (${res.ms}ms)`);
            closeModal();
            const current = tab();
            if (current?.kind === "table" && current.table === table && current.conn === connId) {
              loadRows(current, { keepPage: true });
            }
          } else {
            const res = await LD.call("db_seed_data", { conn: connId, database, table, count: selectedCount, mode: "code" });
            closeModal();
            openCodeModal({
              title: `Laravel Seeder: ${res.model}Seeder`,
              type: "seeder",
              fileName: res.file_name,
              code: res.code,
              connId,
              database,
              table
            });
          }
        } catch (err) {
          this.disabled = false;
          this.innerHTML = selectedMode === "insert" ? `${icon("zap")} Start Seeding` : `${icon("code")} Generate Seeder`;
          toast("error", "Seeding failed", err.message);
        }
      });
    });
  }

  /* ── Phase 2: Schema Diff & Visual EXPLAIN ─────────────── */

  async function runExplain(t) {
    const area = $(".sql-editor");
    if (area) t.sql = area.value;
    const selected = area && area.selectionEnd > area.selectionStart ? area.value.slice(area.selectionStart, area.selectionEnd) : t.sql;
    if (!selected.trim()) return toast("error", "Write a query first to explain");
    t.running = true;
    t.showExplain = true;
    renderMain();
    try {
      const res = await LD.call("db_explain", { conn: t.conn, database: t.db, sql: selected });
      t.explain = res;
    } catch (err) {
      t.explain = { error: err.message };
    }
    t.running = false;
    renderMain();
  }

  function renderExplainView(t) {
    const exp = t.explain;
    if (exp?.error) {
      return `
        <div style="padding:16px;">
          <div style="margin-bottom:12px;">
            <button class="btn sm" data-db="close-explain">${icon("back")} Back to Results</button>
          </div>
          <div class="query-msg error">${icon("alert")}<div><b>EXPLAIN Error</b><small class="mono">${esc(exp.error)}</small></div></div>
        </div>`;
    }

    const summary = exp.summary || {};
    const status = summary.status || "optimal";
    const statusTitles = {
      optimal: "Optimal Execution Plan",
      warning: "Optimization Opportunity Detected",
      critical: "Performance Warning: Full Table Scan"
    };
    const statusSubs = {
      optimal: "The database uses indexes efficiently for this query.",
      warning: "Some operations (sorting or temporary tables) may slow down large datasets.",
      critical: `${summary.full_table_scans || 1} table(s) are scanned row-by-row without using an index.`
    };

    return `
      <div class="dbm-explain-wrap">
        <div style="display:flex; align-items:center; justify-content:space-between;">
          <button class="btn sm" data-db="close-explain">${icon("back")} Back to Results</button>
          <span class="muted" style="font-size:12px;">Driver: <b>${esc(exp.driver?.toUpperCase() || "")}</b></span>
        </div>

        <div class="explain-banner ${esc(status)}">
          ${icon(status === "optimal" ? "check" : "alert", "explain-banner-icon")}
          <div>
            <div class="explain-banner-title">${esc(statusTitles[status] || "Analysis Complete")}</div>
            <div class="explain-banner-sub">${esc(statusSubs[status] || "")}</div>
          </div>
        </div>

        ${(summary.recommendations || []).length ? `
          <div style="display:flex; flex-direction:column; gap:8px;">
            <div style="font-size:12px; font-weight:600; color:var(--text); text-transform:uppercase; letter-spacing:0.5px;">Recommended Index Optimizations:</div>
            ${summary.recommendations.map((rec) => `
              <div class="explain-rec-card">
                <div>
                  <div class="explain-rec-text">${esc(rec.message)}</div>
                  ${rec.suggested_sql ? `<code class="explain-rec-sql">${esc(rec.suggested_sql)}</code>` : ""}
                </div>
                ${rec.suggested_sql ? `
                  <button class="btn sm" data-copy-sql="${esc(rec.suggested_sql)}">${icon("copy")} Copy SQL</button>
                ` : ""}
              </div>
            `).join("")}
          </div>
        ` : ""}

        <div style="font-size:12px; font-weight:600; color:var(--text); text-transform:uppercase; letter-spacing:0.5px;">Execution Steps Breakdown:</div>
        <div class="explain-steps-flow">
          ${(exp.steps || []).map((step, idx) => `
            <div class="explain-step-card ${esc(step.severity || "good")}">
              <span class="chip" style="font-family:var(--font-mono, monospace); font-weight:bold;">#${idx + 1}</span>
              <div>
                <div class="explain-step-op">${esc(step.operation || step.type)}</div>
                ${step.warning ? `<div class="explain-step-detail" style="color:var(--red); font-weight:550; margin-top:2px;">⚠ ${esc(step.warning)}</div>` : ""}
                ${step.key ? `<div class="explain-step-detail">Index used: <code class="mono">${esc(step.key)}</code></div>` : ""}
              </div>
              <div class="explain-step-badges">
                ${step.table ? `<span class="explain-pill">${icon("grid")} ${esc(step.table)}</span>` : ""}
                ${step.rows !== undefined && step.rows !== null ? `<span class="explain-pill ${step.severity === "critical" ? "red" : ""}">${Number(step.rows).toLocaleString()} rows est.</span>` : ""}
                ${step.type === "scan" ? `<span class="explain-pill red">Full Scan</span>` : step.type === "index_lookup" ? `<span class="explain-pill green">Indexed</span>` : ""}
              </div>
            </div>
          `).join("")}
        </div>
      </div>`;
  }

  function openDiffTab({ srcConn, srcDb, tgtConn, tgtDb } = {}) {
    const sConn = srcConn || S.conns[0]?.id;
    const sDb = srcDb || conn(sConn)?.database || (conn(sConn)?.driver === "sqlite" ? "main" : "");
    const tConn = tgtConn || (S.conns.length > 1 ? S.conns[1]?.id : sConn);
    const tDb = tgtDb || conn(tConn)?.database || (conn(tConn)?.driver === "sqlite" ? "main" : "");

    const t = {
      id: fId(),
      kind: "diff",
      srcConn: sConn,
      srcDb: sDb,
      tgtConn: tConn,
      tgtDb: tDb,
      data: null,
      loading: false,
      selectedTable: null,
      checkedStatements: new Set(),
      tableFilter: ""
    };
    S.tabs.push(t);
    activate(t.id);
    loadDiff(t);
  }

  async function loadDiff(t) {
    if (!t.srcConn || !t.tgtConn) return;
    t.loading = true;
    renderMain();
    try {
      const res = await LD.call("db_diff", {
        src_conn: t.srcConn,
        src_db: t.srcDb,
        tgt_conn: t.tgtConn,
        tgt_db: t.tgtDb
      });
      t.data = res;
      t.checkedStatements = new Set((res.statements || []).map((s) => s.id));
      t.selectedTable = res.tables?.[0]?.name || null;
    } catch (err) {
      toast("error", "Comparison failed", err.message);
    }
    t.loading = false;
    renderMain();
  }

  function diffTab(t) {
    const sConn = conn(t.srcConn);
    const tConn = conn(t.tgtConn);
    const sDbs = (S.tree[t.srcConn]?.databases || []).filter((d) => S.showSystem || !d.system || d.name === t.srcDb);
    const tDbs = (S.tree[t.tgtConn]?.databases || []).filter((d) => S.showSystem || !d.system || d.name === t.tgtDb);

    const diff = t.data;
    const stats = diff?.stats || {
      missing_tables: 0, extra_tables: 0, altered_tables: 0, identical_tables: 0,
      missing_columns: 0, modified_columns: 0, missing_indexes: 0, total_statements: 0
    };

    const tables = diff?.tables || [];
    const filter = (t.tableFilter || "").toLowerCase().trim();
    const visibleTables = tables.filter((tb) => !filter || tb.name.toLowerCase().includes(filter));
    const selected = t.selectedTable || (visibleTables[0]?.name || null);
    const currentTableData = tables.find((tb) => tb.name === selected);

    const statements = diff?.statements || [];
    const checkedCount = t.checkedStatements ? t.checkedStatements.size : 0;

    return `
      <div class="dbm-diff-container">
        <div class="diff-toolbar">
          <div class="diff-target-group">
            <span class="muted" style="font-size:12px; font-weight:600;">Source:</span>
            <select data-diff-src-conn class="sm">
              ${S.conns.map((c) => `<option value="${esc(c.id)}" ${c.id === t.srcConn ? "selected" : ""}>${esc(c.name)}</option>`).join("")}
            </select>
            ${sConn?.driver === "sqlite" ? "" : `
              <select data-diff-src-db class="sm">
                ${sDbs.map((d) => `<option value="${esc(d.name)}" ${d.name === t.srcDb ? "selected" : ""}>${esc(d.name)}</option>`).join("")}
              </select>
            `}
          </div>

          <span class="diff-arrow">➔</span>

          <div class="diff-target-group">
            <span class="muted" style="font-size:12px; font-weight:600;">Target:</span>
            <select data-diff-tgt-conn class="sm">
              ${S.conns.map((c) => `<option value="${esc(c.id)}" ${c.id === t.tgtConn ? "selected" : ""}>${esc(c.name)}</option>`).join("")}
            </select>
            ${tConn?.driver === "sqlite" ? "" : `
              <select data-diff-tgt-db class="sm">
                ${tDbs.map((d) => `<option value="${esc(d.name)}" ${d.name === t.tgtDb ? "selected" : ""}>${esc(d.name)}</option>`).join("")}
              </select>
            `}
          </div>

          <button class="btn sm primary" data-diff="run-compare" ${t.loading ? "disabled" : ""}>
            ${icon("refresh")}${t.loading ? "Comparing…" : "Compare Schemas"}
          </button>

          <span class="spacer"></span>

          <button class="btn sm" data-diff="copy-all-sql" ${statements.length ? "" : "disabled"} title="Copy generated sync script">
            ${icon("copy")} Copy Sync SQL
          </button>
          <button class="btn sm primary" data-diff="sync-selected" ${checkedCount ? "" : "disabled"} title="Apply selected migration statements to target">
            ${icon("zap")} Sync to Target (${checkedCount})
          </button>
        </div>

        ${diff ? `
          <div class="diff-stats-bar">
            <span class="diff-chip ${stats.missing_tables ? "missing" : "identical"}">
              ${stats.missing_tables} Missing Tables
            </span>
            <span class="diff-chip ${stats.altered_tables ? "altered" : "identical"}">
              ${stats.altered_tables} Altered Tables
            </span>
            <span class="diff-chip ${stats.missing_columns ? "altered" : "identical"}">
              ${stats.missing_columns} Missing Columns
            </span>
            <span class="diff-chip ${stats.missing_indexes ? "altered" : "identical"}">
              ${stats.missing_indexes} Missing Indexes
            </span>
            <span class="diff-chip identical">
              ${stats.identical_tables} Identical Tables
            </span>
          </div>

          <div class="diff-content-grid">
            <div class="diff-table-list">
              <div style="padding: 8px 10px; border-bottom: 1px solid var(--border);">
                <div class="search sm" style="width:100%;">
                  ${icon("search")}
                  <input data-diff-filter placeholder="Filter tables…" value="${esc(t.tableFilter || "")}">
                </div>
              </div>
              <div style="overflow-y:auto; flex:1;">
                ${visibleTables.map((tb) => {
                  const statusColors = {
                    missing_in_target: "background:var(--red-soft); color:var(--red);",
                    altered: "background:var(--amber-soft); color:var(--amber);",
                    extra_in_target: "background:rgba(14,165,233,0.15); color:#0ea5e9;",
                    identical: "background:var(--green-soft); color:var(--green);"
                  };
                  const statusLabels = {
                    missing_in_target: "Missing",
                    altered: "Altered",
                    extra_in_target: "Extra",
                    identical: "Identical"
                  };
                  return `
                    <div class="diff-table-row ${tb.name === selected ? "active" : ""}" data-diff-table="${esc(tb.name)}">
                      <div class="diff-table-name">
                        ${icon("grid")} <span>${esc(tb.name)}</span>
                      </div>
                      <span class="chip" style="${statusColors[tb.status] || ""}">
                        ${statusLabels[tb.status] || tb.status}
                      </span>
                    </div>`;
                }).join("")}
              </div>
            </div>

            <div class="diff-details-panel">
              ${currentTableData ? `
                <div style="background:var(--surface); border:1px solid var(--border); border-radius:8px; padding:12px 16px;">
                  <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:8px;">
                    <h3 style="margin:0; font-size:15px; display:flex; align-items:center; gap:6px;">
                      ${icon("grid")} Table: <b>${esc(currentTableData.name)}</b>
                    </h3>
                  </div>

                  ${currentTableData.missing_columns?.length ? `
                    <div style="margin-top:8px;">
                      <span class="muted" style="font-size:12px; font-weight:600;">Missing Columns in Target:</span>
                      <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:4px;">
                        ${currentTableData.missing_columns.map((c) => `<span class="chip" style="color:var(--red); background:var(--red-soft); font-family:var(--font-mono, monospace);">+ ${esc(c)}</span>`).join("")}
                      </div>
                    </div>
                  ` : ""}

                  ${currentTableData.modified_columns?.length ? `
                    <div style="margin-top:8px;">
                      <span class="muted" style="font-size:12px; font-weight:600;">Modified Columns:</span>
                      <div style="display:flex; flex-direction:column; gap:4px; margin-top:4px;">
                        ${currentTableData.modified_columns.map((m) => `
                          <div style="font-size:12px; font-family:var(--font-mono, monospace); color:var(--text);">
                            ~ <b>${esc(m.column)}</b>: ${esc(m.target_type)} ➔ <span style="color:var(--accent);">${esc(m.source_type)}</span>
                          </div>`).join("")}
                      </div>
                    </div>
                  ` : ""}

                  ${currentTableData.missing_indexes?.length ? `
                    <div style="margin-top:8px;">
                      <span class="muted" style="font-size:12px; font-weight:600;">Missing Indexes:</span>
                      <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:4px;">
                        ${currentTableData.missing_indexes.map((idx) => `<span class="chip" style="color:var(--amber); background:var(--amber-soft); font-family:var(--font-mono, monospace);">+ ${esc(idx)}</span>`).join("")}
                      </div>
                    </div>
                  ` : ""}
                </div>
              ` : ""}

              <div style="display:flex; align-items:center; justify-content:space-between;">
                <span style="font-size:13px; font-weight:600; color:var(--text);">Executable Sync Statements (${statements.length}):</span>
                <button class="btn ghost xs" data-diff="toggle-all-stmts">
                  ${t.checkedStatements.size === statements.length ? "Deselect All" : "Select All"}
                </button>
              </div>

              ${statements.length ? `
                <div style="display:flex; flex-direction:column; gap:8px;">
                  ${statements.map((stmt) => `
                    <div class="diff-stmt-card">
                      <input type="checkbox" data-stmt-id="${stmt.id}" ${t.checkedStatements.has(stmt.id) ? "checked" : ""}>
                      <div class="diff-stmt-content">
                        <div class="diff-stmt-desc">${esc(stmt.description || stmt.type)}</div>
                        <pre class="diff-stmt-sql"><code>${esc(stmt.sql)}</code></pre>
                      </div>
                    </div>
                  `).join("")}
                </div>
              ` : `
                <div class="card" style="padding:24px; text-align:center; color:var(--muted);">
                  ${icon("check")} Target schema is completely in sync with source! No statements required.
                </div>
              `}
            </div>
          </div>
        ` : `
          <div class="dbm-welcome" style="padding:40px 20px;">
            <div class="empty-icon">${icon("layers")}</div>
            <h2>Schema Diff & Safe Sync</h2>
            <p class="muted">Compare two database structures (e.g. Local vs Staging or Production via SSH) to find missing tables, extra columns, modified types, and missing indexes.</p>
            <button class="btn primary" data-diff="run-compare" style="margin-top:12px;">
              ${icon("refresh")} Start Schema Comparison
            </button>
          </div>
        `}
      </div>`;
  }

  function bindDiffEvents(t, root) {
    const srcConnSel = $("[data-diff-src-conn]", root);
    const srcDbSel = $("[data-diff-src-db]", root);
    const tgtConnSel = $("[data-diff-tgt-conn]", root);
    const tgtDbSel = $("[data-diff-tgt-db]", root);

    srcConnSel?.addEventListener("change", async (e) => {
      t.srcConn = e.target.value;
      const c = conn(t.srcConn);
      t.srcDb = c?.database || (c?.driver === "sqlite" ? "main" : "");
      if (!S.tree[t.srcConn]?.databases) await openConn(t.srcConn, { quiet: true });
      renderMain();
    });

    srcDbSel?.addEventListener("change", (e) => {
      t.srcDb = e.target.value;
      renderMain();
    });

    tgtConnSel?.addEventListener("change", async (e) => {
      t.tgtConn = e.target.value;
      const c = conn(t.tgtConn);
      t.tgtDb = c?.database || (c?.driver === "sqlite" ? "main" : "");
      if (!S.tree[t.tgtConn]?.databases) await openConn(t.tgtConn, { quiet: true });
      renderMain();
    });

    tgtDbSel?.addEventListener("change", (e) => {
      t.tgtDb = e.target.value;
      renderMain();
    });

    const searchInput = $("[data-diff-filter]", root);
    searchInput?.addEventListener("input", (e) => {
      t.tableFilter = e.target.value;
      renderMain();
    });

    $$("[data-diff-table]", root).forEach((el) => {
      el.addEventListener("click", () => {
        t.selectedTable = el.dataset.diffTable;
        renderMain();
      });
    });

    $$("[data-stmt-id]", root).forEach((cb) => {
      cb.addEventListener("change", (e) => {
        const id = Number(e.target.dataset.stmtId);
        if (e.target.checked) t.checkedStatements.add(id);
        else t.checkedStatements.delete(id);
        renderMain();
      });
    });
  }

  /* ── events ─────────────────────────────────────────────── */

  document.addEventListener("click", async (e) => {
    if (menuEl && !menuEl.contains(e.target)) hideMenu();
    const t = e.target;
    if (!inDb(t)) return;
    let el;

    if ((el = t.closest("[data-close-tab]"))) { e.stopPropagation(); return closeTab(el.dataset.closeTab); }
    if ((el = t.closest("[data-tab-id]"))) return activate(el.dataset.tabId);
    if ((el = t.closest("[data-open-conn]"))) return openConn(el.dataset.openConn);
    if ((el = t.closest("[data-menu]"))) {
      e.stopPropagation();
      const node = el.closest("[data-conn]");
      const c = conn(node.dataset.conn);
      const r = el.getBoundingClientRect();
      const items = el.dataset.menu === "conn" ? connMenu(c) : el.dataset.menu === "db" ? dbMenu(c, node.dataset.dbname) : tableMenu(c, node.dataset.dbname, node.dataset.table);
      return showMenu(r.left, r.bottom + 4, items);
    }

    const action = t.closest("[data-db]")?.dataset.db;
    const current = tab();
    switch (action) {
      case "new-conn": return connModal();
      case "refresh-conns": await loadConns(true); for (const id of Object.keys(S.tree)) if (S.tree[id].open && conn(id)) openConn(id, { quiet: true }); return render();
      case "show-system": S.showSystem = true; return renderTree();
      case "show-all": S.tree[t.closest("[data-conn]").dataset.conn].showAll = true; return renderTree();
      case "query-here": {
        e.stopPropagation();
        const node = t.closest("[data-conn]");
        return openTab({ kind: "query", conn: node.dataset.conn, db: node.dataset.dbname });
      }
      case "new-query": {
        const base = current || { conn: S.conns[0]?.id, db: S.conns[0]?.database || "" };
        if (!base.conn) return toast("error", "Add a connection first");
        return openTab({ kind: "query", conn: base.conn, db: base.db || "" });
      }
      case "query-db": return openTab({ kind: "query", conn: current.conn, db: current.db });
      case "refresh-db": return openDb(current.conn, current.db, true);
      case "export-db": return exportData(current.conn, current.db, [], "sql");
      case "snapshots-db": return openSnapshotsModal(current.conn, current.db);
      case "import": return importSql(current.conn, current.db);
      case "copy-ddl": return copyText(current.structure?.ddl || "");
      case "gen-model": return openModelModal(current.conn, current.db, current.table);
      case "gen-migration": return openMigrationModal(current.conn, current.db, current.table);
      case "seed-table": return openSeedModal(current.conn, current.db, current.table);
      case "reload":
        if (pendingCount(current) && !(await confirmModal({ title: "Discard changes?", message: "Refreshing drops your unsaved edits.", confirm: "Discard", danger: true }))) return;
        current.edits = new Map(); current.inserts = []; current.deletes = new Set();
        renderTabs();
        return loadRows(current);
      case "add-row": current.inserts.unshift({}); renderTabs(); renderMain(); {
        const first = $("#dbm-content tr.new td[data-new-cell]");
        const visible = current.data.columns.filter((c) => !c.hidden);
        const target = visible.find((c) => !c.auto);
        const cell = target ? $(`#dbm-content tr[data-new="0"] td[data-new-cell="${CSS.escape(target.name)}"]`) : first;
        if (cell) startEdit(cell);
      }
        return;
      case "drop-new": current.inserts.splice(+t.closest("[data-new]").dataset.new, 1); renderTabs(); return renderMain();
      case "delete-rows": current.selected.forEach((ri) => current.deletes.add(ri)); current.selected = new Set(); renderTabs(); return renderMain();
      case "discard": current.edits = new Map(); current.inserts = []; current.deletes = new Set(); renderTabs(); return renderMain();
      case "save": return saveChanges(current);
      case "export-table": return showMenu(e.clientX, e.clientY, ["sql", "csv", "json"].map((f) => ({ label: `Export as ${f.toUpperCase()}…`, icon: "download", run: () => exportData(current.conn, current.db, [current.table], f) })));
      case "run-query": return runQuery(current);
      case "toggle-filters": {
        current.showFilters = !current.showFilters;
        return renderMain();
      }
      case "toggle-raw-where": {
        current.showRawWhere = !current.showRawWhere;
        return renderMain();
      }
      case "add-filter": {
        const colSel = $("[data-flt-column]");
        const opSel = $("[data-flt-op]");
        const valInp = $("[data-flt-value]");
        if (!colSel || !opSel) return;
        const column = colSel.value;
        const op = opSel.value;
        const value = valInp ? valInp.value.trim() : "";
        if (!op.includes("NULL") && !value) {
          return toast("error", "Filter value required", "Please enter a value for the filter condition.");
        }
        current.filters = current.filters || [];
        current.filters.push({ column, op, value });
        current.showFilters = true;
        return loadRows(current, { keepPage: false });
      }
      case "clear-all-filters": {
        current.filters = [];
        current.where = "";
        current.showRawWhere = false;
        return loadRows(current, { keepPage: false });
      }
      case "open-as-query": {
        const c = conn(current.conn);
        const sql = buildTableSelectSql(c?.driver, current.table, current.filters, current.where, current.sort, current.dir, current.limit);
        return openTab({ kind: "query", conn: current.conn, db: current.db, sql });
      }
      case "open-hologram": {
        e.stopPropagation();
        const node = t.closest("[data-conn]") || t.closest("[data-dbname]");
        const c = node?.dataset.conn || current?.conn;
        const d = node?.dataset.dbname || current?.db;
        if (c && d) return openHologram(c, d);
        break;
      }
      case "open-diff": return openDiffTab();
      case "explain-query": return runExplain(current);
      case "close-explain": current.showExplain = false; return renderMain();
    }

    const quickTable = t.closest("[data-db-quick-query]")?.dataset.dbQuickQuery;
    if (quickTable) {
      e.stopPropagation();
      const c = conn(current?.conn);
      return openTab({
        kind: "query",
        conn: current.conn,
        db: current.db,
        sql: `SELECT * FROM ${q(c?.driver, quickTable)} LIMIT 100;`
      });
    }

    const filterTable = t.closest("[data-db-open-filtered]")?.dataset.dbOpenFiltered;
    if (filterTable) {
      e.stopPropagation();
      return openTab({
        kind: "table",
        conn: current.conn,
        db: current.db,
        table: filterTable,
        showFilters: true
      });
    }

    const rmFilter = t.closest("[data-remove-filter]");
    if (rmFilter && current?.kind === "table") {
      const idx = +rmFilter.dataset.removeFilter;
      if (current.filters && current.filters[idx] !== undefined) {
        current.filters.splice(idx, 1);
        return loadRows(current, { keepPage: false });
      }
    }

    if (t.closest("[data-db-clear-row-search]") && current?.kind === "table") {
      current.search = "";
      return loadRows(current, { keepPage: false });
    }

    if (t.closest("[data-db-clear-table-search]") && current?.kind === "db") {
      current.tableSearch = "";
      return renderMain();
    }

    const qAction = t.closest("[data-query-action]")?.dataset.queryAction;
    if (qAction && current?.kind === "query") {
      switch (qAction) {
        case "select-table": {
          const tbl = $("[data-query-table]")?.value;
          if (!tbl) return toast("info", "Select a table first");
          const tRef = q(conn(current.conn)?.driver, tbl);
          return insertSqlSnippet(`SELECT * FROM ${tRef} LIMIT 100;`, true);
        }
        case "count-table": {
          const tbl = $("[data-query-table]")?.value;
          if (!tbl) return toast("info", "Select a table first");
          const tRef = q(conn(current.conn)?.driver, tbl);
          return insertSqlSnippet(`SELECT COUNT(*) AS total_rows FROM ${tRef};`, true);
        }
        case "format": {
          const area = $(".sql-editor");
          if (!area || !area.value.trim()) return toast("info", "No SQL to format");
          const formatted = formatSql(area.value);
          area.value = formatted;
          current.sql = formatted;
          return toast("success", "SQL formatted");
        }
        case "history": {
          const r = t.getBoundingClientRect();
          return showQueryHistoryMenu(r.left, r.bottom + 4);
        }
        case "clear": {
          const area = $(".sql-editor");
          if (area) {
            area.value = "";
            current.sql = "";
            area.focus();
          }
          return;
        }
      }
    }

    const snippetBtn = t.closest("[data-sql-snippet]");
    if (snippetBtn && current?.kind === "query") {
      const snippet = snippetBtn.dataset.sqlSnippet;
      if (snippet) insertSqlSnippet(snippet);
      return;
    }

    const diffAction = t.closest("[data-diff]")?.dataset.diff;
    if (diffAction && current?.kind === "diff") {
      switch (diffAction) {
        case "run-compare": return loadDiff(current);
        case "copy-all-sql": {
          if (!current.data?.sync_sql) return;
          try {
            await navigator.clipboard.writeText(current.data.sync_sql);
            toast("success", "Sync SQL copied to clipboard");
          } catch {
            copyText(current.data.sync_sql);
          }
          return;
        }
        case "toggle-all-stmts": {
          const all = (current.data?.statements || []).map((s) => s.id);
          if (current.checkedStatements.size === all.length) current.checkedStatements.clear();
          else current.checkedStatements = new Set(all);
          return renderMain();
        }
        case "sync-selected": {
          const selected = (current.data?.statements || []).filter((s) => current.checkedStatements.has(s.id));
          if (!selected.length) return toast("error", "Select at least one statement to apply");

          const tgtConnObj = S.connections?.find((c) => c.id === current.tgtConn);
          const isMysql = tgtConnObj?.driver === "mysql" || tgtConnObj?.driver === "mariadb";

          const msgHtml = `
            Apply <b>${selected.length}</b> migration statement(s) to <b>${esc(current.tgtDb)}</b>?
            ${isMysql
              ? `<div class="notice danger sm" style="margin-top:10px">⚠️ MySQL/MariaDB performs implicit commits on DDL statements. Changes cannot be rolled back if an error occurs.</div>`
              : `<div class="notice info sm" style="margin-top:10px">ℹ️ Atomic: In PostgreSQL/SQLite, statements run in a transaction and roll back automatically on error.</div>`
            }
          `;

          const ok = await confirmModal({
            title: "Sync to Target Database?",
            message: msgHtml,
            confirm: "Execute Sync",
            danger: isMysql,
          });
          if (!ok) return;

          try {
            const res = await LD.call("db_sync", {
              tgt_conn: current.tgtConn,
              tgt_db: current.tgtDb,
              statements: selected,
              stop_on_error: true,
            });

            if (res.failed > 0) {
              toast("error", `Sync finished with ${res.failed} error(s)`, `${res.executed} succeeded, ${res.failed} failed`);
              const failedItems = (res.results || []).filter((r) => !r.ok);
              openModal(`
                <div class="modal" style="max-width:640px">
                  <div class="modal-header">
                    <h2 style="color:var(--danger)">${icon("alert")} Schema Sync Failed</h2>
                    <p><b>${res.failed}</b> statement(s) failed during execution.</p>
                  </div>
                  <div class="modal-body">
                    ${failedItems.map((f) => `
                      <div style="margin-bottom:12px;background:var(--surface-2);padding:10px;border-radius:6px;border:1px solid var(--border)">
                        <div style="color:var(--danger);font-weight:600;font-size:12.5px;margin-bottom:6px">${esc(f.error)}</div>
                        <pre style="margin:0;font-family:var(--mono);font-size:11.5px;white-space:pre-wrap;color:var(--muted)">${esc(f.sql)}</pre>
                      </div>
                    `).join("")}
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn primary" data-dismiss>Dismiss</button>
                  </div>
                </div>
              `, (mRoot) => {
                $("[data-dismiss]", mRoot)?.addEventListener("click", closeModal);
              });
            } else {
              toast("success", `Executed all ${res.executed} statement(s) successfully!`);
            }

            await loadDiff(current);
          } catch (err) {
            toast("error", "Sync execution failed", err.message);
          }
          return;
        }
      }
    }

    if (t.closest("[data-copy-sql]")) {
      const sql = t.closest("[data-copy-sql]").dataset.copySql;
      try {
        await navigator.clipboard.writeText(sql);
        toast("success", "Index SQL copied to clipboard");
      } catch {
        copyText(sql);
      }
      return;
    }

    const holo = t.closest("[data-holo]")?.dataset.holo;
    if (holo && current?.kind === "hologram") {
      switch (holo) {
        case "retry":
        case "reload": return loadHologram(current, true);
        case "autolayout": autoLayout(current, true); return renderMain();
        case "toggle-compact": current.compact = !current.compact; return renderMain();
        case "zoom-in": current.zoom = Math.min(2.5, (current.zoom || 1) * 1.2); return updateHologramTransform(current);
        case "zoom-out": current.zoom = Math.max(0.25, (current.zoom || 1) / 1.2); return updateHologramTransform(current);
        case "zoom-reset": current.zoom = 1; current.panX = 60; current.panY = 60; return updateHologramTransform(current);
        case "fit": return fitHologram(current);
        case "export-svg": return exportHologramSvg(current);
      }
    }

    const holoAction = t.closest("[data-holo-action]")?.dataset.holoAction;
    if (holoAction && current?.kind === "hologram") {
      e.stopPropagation();
      const tb = t.closest("[data-holo-action]").dataset.table;
      if (holoAction === "model") return openModelModal(current.conn, current.db, tb);
      if (holoAction === "migration") return openMigrationModal(current.conn, current.db, tb);
      if (holoAction === "seed") return openSeedModal(current.conn, current.db, tb);
      return openTab({ kind: "table", conn: current.conn, db: current.db, table: tb, sub: holoAction });
    }

    if ((el = t.closest("[data-node]")) && !t.closest("button")) {
      const kind = el.dataset.node;
      const id = el.dataset.conn;
      if (kind === "conn") {
        const node = S.tree[id];
        if (node?.open && !node.error) { node.open = false; return renderTree(); }
        return openConn(id);
      }
      if (kind === "db") {
        const dbn = S.tree[id].dbs[el.dataset.dbname];
        if (dbn?.open) { dbn.open = false; return renderTree(); }
        return openDb(id, el.dataset.dbname);
      }
      if (kind === "table") return openTab({ kind: "table", conn: id, db: el.dataset.dbname, table: el.dataset.table });
    }

    if ((el = t.closest("[data-sub]"))) { current.sub = el.dataset.sub; return renderMain(); }
    if ((el = t.closest("[data-result]"))) { current.resultIndex = +el.dataset.result; return renderMain(); }
    if ((el = t.closest("[data-sort]"))) {
      const col = el.dataset.sort;
      current.dir = current.sort === col && current.dir === "ASC" ? "DESC" : "ASC";
      current.sort = col;
      return loadRows(current);
    }
    if ((el = t.closest("[data-page]"))) {
      const d = current.data;
      current.page = { first: 1, prev: d.page - 1, next: d.page + 1, last: d.pages }[el.dataset.page];
      return loadRows(current);
    }
    if (t.closest("[data-select-all]")) {
      const all = current.data.rows.map((_, i) => i);
      current.selected = current.selected.size === all.length ? new Set() : new Set(all);
      return renderMain();
    }
    if ((el = t.closest("[data-select-row]"))) {
      const ri = +el.closest("tr").dataset.row;
      if (e.shiftKey && current.lastSelected !== undefined) {
        const [a, b] = [current.lastSelected, ri].sort((x, y) => x - y);
        for (let i = a; i <= b; i++) current.selected.add(i);
      } else if (e.ctrlKey || e.metaKey) {
        current.selected.has(ri) ? current.selected.delete(ri) : current.selected.add(ri);
      } else {
        current.selected = current.selected.has(ri) && current.selected.size === 1 ? new Set() : new Set([ri]);
      }
      current.lastSelected = ri;
      return renderMain();
    }
  });

  document.addEventListener("dblclick", (e) => {
    const td = e.target.closest("#view-database td[data-cell], #view-database td[data-new-cell]");
    if (td && !td.classList.contains("editing")) startEdit(td);
    const card = e.target.closest("#view-database .hologram-card");
    const current = tab();
    if (card && current?.kind === "hologram") {
      const tb = card.dataset.table;
      if (tb) openTab({ kind: "table", conn: current.conn, db: current.db, table: tb, sub: "data" });
    }
  });

  document.addEventListener("contextmenu", (e) => {
    const t = e.target;
    if (!inDb(t)) return;
    const current = tab();
    const td = t.closest("td[data-cell]");
    if (td && current?.kind === "table") {
      e.preventDefault();
      return showMenu(e.clientX, e.clientY, cellMenu(current, +td.closest("tr").dataset.row, +td.dataset.cell));
    }
    const holoCard = t.closest("#view-database .hologram-card");
    if (holoCard && current?.kind === "hologram") {
      e.preventDefault();
      const tb = holoCard.dataset.table;
      return showMenu(e.clientX, e.clientY, [
        { label: `Table: ${tb}`, icon: "grid", run: () => openTab({ kind: "table", conn: current.conn, db: current.db, table: tb, sub: "data" }) },
        { label: "View Structure", icon: "wrench", run: () => openTab({ kind: "table", conn: current.conn, db: current.db, table: tb, sub: "structure" }) },
        "-",
        { label: "Generate Eloquent Model…", icon: "code", run: () => openModelModal(current.conn, current.db, tb) },
        { label: "Generate Migration…", icon: "file", run: () => openMigrationModal(current.conn, current.db, tb) },
        { label: "Seed Dummy Data…", icon: "zap", run: () => openSeedModal(current.conn, current.db, tb) },
      ]);
    }
    const node = t.closest("[data-node]");
    if (node) {
      e.preventDefault();
      const c = conn(node.dataset.conn);
      const items = node.dataset.node === "conn" ? connMenu(c) : node.dataset.node === "db" ? dbMenu(c, node.dataset.dbname) : tableMenu(c, node.dataset.dbname, node.dataset.table);
      showMenu(e.clientX, e.clientY, items);
    }
  });

  document.addEventListener("submit", (e) => {
    if (!e.target.matches("#view-database [data-where-form]")) return;
    e.preventDefault();
    const t = tab();
    t.where = e.target.elements.where.value.trim();
    loadRows(t, { keepPage: false });
  });

  let searchTimer = null;
  document.addEventListener("input", (e) => {
    const t = e.target;
    if (t.matches("#view-database [data-db-filter]")) {
      S.filter = t.value;
      return renderTree();
    }
    if (t.matches("#view-database [data-db-table-search]")) {
      const current = tab();
      if (current?.kind === "db") {
        current.tableSearch = t.value;
        renderMain();
        const box = $("#view-database [data-db-table-search]");
        if (box) { box.focus(); box.setSelectionRange(box.value.length, box.value.length); }
      }
      return;
    }
    if (t.matches("#view-database [data-row-search]")) {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        const current = tab();
        current.search = t.value;
        loadRows(current, { keepPage: false }).then(() => {
          const box = $("#view-database [data-row-search]");
          if (box) { box.focus(); box.setSelectionRange(box.value.length, box.value.length); }
        });
      }, 350);
    }
    if (t.matches("#view-database .sql-editor")) {
      const current = tab();
      if (current?.kind === "query") current.sql = t.value;
    }
  });

  document.addEventListener("change", async (e) => {
    const t = e.target;
    if (!inDb(t)) return;
    const current = tab();
    if (t.matches("[data-page-size]")) { current.limit = +t.value; return loadRows(current, { keepPage: false }); }
    if (t.matches("[data-page-input]")) {
      current.page = Math.min(Math.max(1, +t.value || 1), current.data.pages);
      return loadRows(current);
    }
    if (t.matches("[data-query-conn]")) {
      current.conn = t.value;
      current.db = conn(t.value)?.database || (conn(t.value)?.driver === "sqlite" ? "main" : "");
      if (!S.tree[t.value]?.databases) await openConn(t.value, { quiet: true });
      $("#dbm-content").innerHTML = queryTab(current);
      $(".sql-editor").value = current.sql;
      return;
    }
    if (t.matches("[data-query-db]")) current.db = t.value;
    if (t.matches("[data-query-template]") && current?.kind === "query") {
      if (t.value) {
        applyQueryTemplate(t.value);
        t.value = "";
      }
      return;
    }
    if (t.matches("[data-flt-op]")) {
      const valInp = $("[data-flt-value]");
      if (valInp) {
        valInp.disabled = t.value.includes("NULL");
        if (t.value.includes("NULL")) valInp.value = "";
      }
      return;
    }
  });

  document.addEventListener("keydown", (e) => {
    if (state.view !== "database" || !$("#modal-root").hidden) return;
    const current = tab();
    const ctrl = e.ctrlKey || e.metaKey;
    if (e.key === "Enter" && e.target.matches("[data-flt-value]")) {
      e.preventDefault();
      $("[data-db='add-filter']")?.click();
      return;
    }
    if (e.target.matches(".sql-editor")) {
      if (ctrl && e.key === "Enter") { e.preventDefault(); return runQuery(current); }
      if (e.key === "Tab") {
        e.preventDefault();
        const a = e.target;
        const s = a.selectionStart;
        a.setRangeText("  ", s, a.selectionEnd, "end");
        current.sql = a.value;
      }
      return;
    }
    if (ctrl && e.key.toLowerCase() === "s" && current?.kind === "table") { e.preventDefault(); return saveChanges(current); }
    if (ctrl && e.key.toLowerCase() === "t") { e.preventDefault(); $("[data-db='new-query']")?.click(); return; }
    if (ctrl && e.key.toLowerCase() === "w" && current) { e.preventDefault(); return closeTab(current.id); }
    if (e.key === "F5" && current?.kind === "table") { e.preventDefault(); return loadRows(current); }
    if (e.key === "Delete" && current?.kind === "table" && current.selected.size && !e.target.matches("input, textarea")) {
      e.preventDefault();
      current.selected.forEach((ri) => current.deletes.add(ri));
      current.selected = new Set();
      renderTabs();
      return renderMain();
    }
    if (e.key === "Escape") hideMenu();
  });

  window.addEventListener("blur", hideMenu);

  /* ── public ─────────────────────────────────────────────── */
  async function ensureLoaded() {
    if (!S.loaded) await loadConns();
  }

  return {
    async show() {
      render();
      await ensureLoaded();
      render();
    },
    dirty: () => S.tabs.some((t) => pendingCount(t)),
    async open(connId, db) {
      await loadConns(true);
      render();
      if (!conn(connId)) return toast("error", "Connection not found");
      await openConn(connId, { quiet: false });
      if (db) {
        await openDb(connId, db);
        openTab({ kind: "db", conn: connId, db });
      }
    },
    async openSite(name) {
      try {
        const target = await LD.call("db_for_site", { name });
        await this.open(target.conn, target.database);
      } catch (err) {
        toast("error", "No database for this project", err.message);
      }
    },
    onEvent(event) {
      if (event.type === "db-progress") {
        const el = $("#db-job");
        const text = `${event.kind === "export" ? "Exporting" : "Importing"}… ${event.count.toLocaleString()} ${event.kind === "export" ? "rows" : "statements"}`;
        if (el) el.textContent = text;
        else { const n = document.createElement("div"); n.id = "db-job"; n.className = "db-job"; n.textContent = text; document.body.append(n); }
      }
      if (event.type === "db-job") {
        $("#db-job")?.remove();
        event.ok ? toast("success", event.label, `${event.count.toLocaleString()} ${event.kind === "export" ? "rows" : "statements"}`)
                 : toast("error", event.kind === "export" ? "Export failed" : "Import failed", event.error);
        if (event.ok && event.kind === "import") {
          for (const [id, node] of Object.entries(S.tree)) for (const [db, dbn] of Object.entries(node.dbs || {})) if (dbn.open) openDb(id, db, true);
        }
      }
    },
  };
})();
window.Database = Database;
