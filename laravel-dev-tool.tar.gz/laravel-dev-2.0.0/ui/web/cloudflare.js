"use strict";

/* ── Cloudflare Hub: Centralized Cloudflare Management for Laravel Dev ──
   Manages API Token, Zones, DNS Records, Cache Purging, Development Mode,
   R2 Object Storage, and Named Tunnels directly from the application UI. */

const Cloudflare = (() => {
  const S = {
    status: { configured: false, token_masked: "", account_id: "", account_name: "" },
    tab: "overview", // overview | dns | cache | r2 | tunnels | security
    zones: [],
    currentZoneId: "",
    dnsRecords: [],
    dnsFilterType: "ALL",
    dnsSearch: "",
    r2Buckets: [],
    r2ErrorObj: null,
    tunnels: [],
    tunnelsErrorObj: null,
    devMode: false,
    devModeTime: 0,
    securityLevel: "medium",
    dnsErrorObj: null,
    cacheErrorObj: null,
    securityErrorObj: null,
    errorObj: null,
    loading: false,
    error: "",
  };

  const view = () => $("#view-cloudflare");
  const currentZone = () => S.zones.find((z) => z.id === S.currentZoneId) || S.zones[0] || null;

  async function init() {
    await refreshStatus();
    if (S.status.configured) {
      await loadZones();
    }
    window.addEventListener("langchange", () => {
      const root = view();
      if (root && !root.hidden) {
        render();
      }
    });
  }

  async function show() {
    if (!S.status.configured) {
      await refreshStatus();
    }
    if (S.status.configured && !S.zones.length) {
      await loadZones();
    }
    render();
  }

  async function refreshStatus() {
    try {
      const res = await LD.call("cf_status");
      S.status = res || { configured: false };
    } catch (err) {
      S.status = { configured: false };
    }
  }

  async function loadZones() {
    S.loading = true;
    S.error = "";
    S.errorObj = null;
    try {
      const res = await LD.call("cf_zones", { page: 1, per_page: 50 });
      if (res.ok) {
        S.zones = res.zones || [];
        S.errorObj = null;
        if (!S.currentZoneId && S.zones.length) {
          S.currentZoneId = S.zones[0].id;
        }
      } else {
        S.errorObj = res;
        S.error = res.error || "Failed to load zones";
      }
    } catch (err) {
      S.error = err.message;
      S.errorObj = { error: err.message, cause_title: "Error loading domains", cause_explanation: err.message };
    } finally {
      S.loading = false;
    }
  }

  async function loadDnsRecords() {
    if (!S.currentZoneId) return;
    S.loading = true;
    try {
      const res = await LD.call("cf_dns_list", {
        zone_id: S.currentZoneId,
        type: S.dnsFilterType === "ALL" ? "" : S.dnsFilterType,
        name: S.dnsSearch,
      });
      if (res.ok) {
        S.dnsRecords = res.records || [];
        S.dnsErrorObj = null;
      } else {
        S.dnsErrorObj = res;
        toast("error", res.cause_title || "DNS Error", res.cause_action || res.error || "Failed to load DNS records");
      }
    } catch (err) {
      S.dnsErrorObj = { error: err.message, cause_title: "DNS Error", cause_explanation: err.message };
      toast("error", "DNS Error", err.message);
    } finally {
      S.loading = false;
      render();
    }
  }

  async function loadCacheAndSecurity() {
    if (!S.currentZoneId) return;
    try {
      const [devRes, secRes] = await Promise.all([
        LD.call("cf_dev_mode_get", { zone_id: S.currentZoneId }),
        LD.call("cf_security_level_get", { zone_id: S.currentZoneId }),
      ]);
      if (devRes.ok) {
        S.devMode = Boolean(devRes.enabled);
        S.devModeTime = devRes.time_remaining || 0;
        S.cacheErrorObj = null;
      } else {
        S.cacheErrorObj = devRes;
      }
      if (secRes.ok) {
        S.securityLevel = secRes.level || "medium";
        S.securityErrorObj = null;
      } else {
        S.securityErrorObj = secRes;
      }
    } catch (err) {
      S.cacheErrorObj = { error: err.message, cause_title: "Settings Error", cause_explanation: err.message };
    }
  }

  async function loadR2Buckets() {
    S.loading = true;
    try {
      const res = await LD.call("cf_r2_buckets");
      if (res.ok) {
        S.r2Buckets = res.buckets || [];
        S.r2ErrorObj = null;
      } else {
        S.r2ErrorObj = res;
        toast("error", res.cause_title || "R2 Storage Error", res.cause_action || res.error || "Failed to list R2 buckets");
      }
    } catch (err) {
      S.r2ErrorObj = { error: err.message, cause_title: "R2 Storage Error", cause_explanation: err.message };
      toast("error", "R2 Storage Error", err.message);
    } finally {
      S.loading = false;
      render();
    }
  }

  async function loadTunnels() {
    S.loading = true;
    try {
      const res = await LD.call("cf_tunnels");
      if (res.ok) {
        S.tunnels = res.tunnels || [];
        S.tunnelsErrorObj = null;
      } else {
        S.tunnelsErrorObj = res;
        toast("error", res.cause_title || "Tunnels Error", res.cause_action || res.error || "Failed to load account tunnels");
      }
    } catch (err) {
      S.tunnelsErrorObj = { error: err.message, cause_title: "Tunnels Error", cause_explanation: err.message };
      toast("error", "Tunnels Error", err.message);
    } finally {
      S.loading = false;
      render();
    }
  }

  // ── Render Views ─────────────────────────────────────────────────────────

  function render() {
    const root = view();
    if (!root) return;

    if (!S.status.configured) {
      root.innerHTML = renderOnboarding();
      attachOnboardingEvents(root);
      return;
    }

    const cz = currentZone();
    const accounts = S.status.accounts || [];
    root.innerHTML = `
      <header class="view-header">
        <div>
          <div style="display:flex;align-items:center;gap:10px">
            <h1 style="margin:0;display:flex;align-items:center;gap:8px">${icon("cloud")}Cloudflare Hub</h1>
            <span class="chip ok sm"><span class="dot on"></span>Connected</span>
            ${accounts.length > 1 ? `<span class="chip sm primary" id="cf-chip-acc-count" style="cursor:pointer" title="Manage Accounts">${accounts.length} Accounts</span>` : ""}
          </div>
          <p class="subtitle" style="margin:4px 0 0">Centralized Cloudflare management for DNS, Cache, R2 Storage, Tunnels &amp; Security.</p>
        </div>
        <div class="header-actions" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <!-- Account Switcher Dropdown -->
          <div style="display:flex;align-items:center;gap:6px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:4px 8px">
            <span style="font-size:11px;color:var(--muted);font-weight:600">${icon("cpu")}Account:</span>
            <select id="cf-account-select" style="background:transparent;border:0;color:var(--text);font-size:12px;font-weight:600;cursor:pointer;outline:none;max-width:180px">
              ${accounts.map((a) => `
                <option value="${esc(a.account_id)}" ${a.is_active ? "selected" : ""}>
                  ${esc(a.account_name || a.account_id)} ${a.is_active ? "✔" : ""}
                </option>
              `).join("")}
            </select>
          </div>
          <button type="button" class="btn sm" id="btn-cf-add-account" title="Add Another Cloudflare Account">${icon("plus")}Add Account</button>
          <button type="button" class="btn sm ghost" id="btn-cf-manage-accounts" title="Manage Accounts">${icon("settings")}</button>
          <button type="button" class="btn sm icon-btn" id="btn-cf-refresh" title="Refresh Cloudflare Data">${icon("refresh")}</button>
          <button type="button" class="btn sm ghost danger icon-btn" id="btn-cf-disconnect" title="Disconnect Account">${icon("unlink")}</button>
        </div>
      </header>

      <div class="view-body" style="padding:0;display:flex;flex-direction:column;gap:0">
        <!-- Cloudflare Sub-navigation Tabs -->
        <div class="drawer-tabs" style="padding:0 24px;border-bottom:1px solid var(--border);background:var(--surface)">
          <button class="drawer-tab ${S.tab === "overview" ? "active" : ""}" data-cf-tab="overview">${icon("home")}Overview</button>
          <button class="drawer-tab ${S.tab === "dns" ? "active" : ""}" data-cf-tab="dns">${icon("globe")}Domains &amp; DNS</button>
          <button class="drawer-tab ${S.tab === "cache" ? "active" : ""}" data-cf-tab="cache">${icon("zap")}Cache &amp; Performance</button>
          <button class="drawer-tab ${S.tab === "r2" ? "active" : ""}" data-cf-tab="r2">${icon("database")}R2 Storage</button>
          <button class="drawer-tab ${S.tab === "tunnels" ? "active" : ""}" data-cf-tab="tunnels">${icon("cloud")}Tunnels</button>
          <button class="drawer-tab ${S.tab === "security" ? "active" : ""}" data-cf-tab="security">${icon("lock")}Security</button>
        </div>

        <div style="padding:24px;max-width:1200px">
          ${S.error ? `<div class="notice" style="margin-bottom:16px">${icon("alert")}<span>${esc(S.error)}</span></div>` : ""}
          ${renderActiveTab()}
        </div>
      </div>
    `;

    attachMainEvents(root);
  }

  function renderOnboarding() {
    return `
      <header class="view-header">
        <div>
          <h1>${icon("cloud")}Cloudflare Hub</h1>
          <p class="subtitle">Connect your Cloudflare account to manage domains, DNS, cache, R2 storage, and tunnels directly inside Laravel Dev.</p>
        </div>
      </header>
      <div class="view-body" style="display:flex;justify-content:center;padding:40px 16px">
        <div class="card" style="max-width:580px;width:100%">
          <div style="text-align:center;margin-bottom:20px">
            <div style="width:64px;height:64px;border-radius:16px;background:var(--accent-soft);color:var(--accent);display:grid;place-items:center;margin:0 auto 12px">
              ${icon("cloud")}
            </div>
            <h2 style="margin:0 0 6px">Connect Cloudflare Account</h2>
            <p class="muted sm" style="margin:0">Create an API Token in your Cloudflare dashboard and paste it here.</p>
          </div>

          <form id="cf-onboarding-form" style="display:flex;flex-direction:column;gap:16px">
            <div>
              <label class="field">
                <span><b>Account Label (optional)</b></span>
                <input type="text" id="cf-account-label-input" placeholder="e.g. Personal Account, Work, Client X" autocomplete="off">
              </label>
              <small class="muted" style="display:block;margin-top:4px">
                A custom label to identify this account when linking multiple Cloudflare accounts.
              </small>
            </div>

            <div>
              <label class="field">
                <span><b>Cloudflare API Token</b> <small style="color:var(--red)">*</small></span>
                <input type="password" id="cf-token-input" placeholder="e.g. 7_Abc123XyZ..." required autocomplete="off" spellcheck="false" style="font-family:var(--mono)">
              </label>
              <small class="muted" style="display:block;margin-top:4px">
                Get this from: <a href="https://dash.cloudflare.com/profile/api-tokens" class="link" data-open-url="https://dash.cloudflare.com/profile/api-tokens">Cloudflare Dashboard &gt; My Profile &gt; API Tokens</a>
              </small>
            </div>

            <div id="cf-verify-result"></div>

            <div class="btn-row" style="justify-content:flex-end">
              <button type="submit" class="btn primary" id="btn-verify-cf">${icon("check")}Verify &amp; Connect</button>
            </div>
          </form>

          <div style="margin-top:24px;padding-top:16px;border-top:1px solid var(--border)">
            <b style="font-size:12px;color:var(--muted)">Recommended Permissions for your API Token:</b>
            <ul class="muted sm" style="margin:6px 0 0;padding-left:18px;line-height:1.6">
              <li><b>Zone &gt; DNS:</b> Edit</li>
              <li><b>Zone &gt; Zone:</b> Read</li>
              <li><b>Zone &gt; Cache Purge:</b> Purge</li>
              <li><b>Account &gt; Workers R2 Storage:</b> Edit (optional, for R2)</li>
              <li><b>Account &gt; Cloudflare Tunnel:</b> Edit (optional, for Tunnels)</li>
            </ul>
          </div>
        </div>
      </div>
    `;
  }

  function renderErrorBanner(err, retryBtnId = "") {
    if (!err || (!err.error && !err.cause_title)) return "";
    const isAr = (window.I18N && window.I18N.getLang && window.I18N.getLang() === "ar");

    const rawTitle = (isAr ? err.cause_title_ar : null) || err.cause_title;
    const title = rawTitle || (err.cause_key ? t(`cf_err_${err.cause_key}_title`, err.cause_title || t("cf_err_notice", "Cloudflare Notice")) : t("cf_err_notice", "Cloudflare Notice"));

    const rawExplanation = (isAr ? err.cause_explanation_ar : null) || err.cause_explanation;
    const explanation = rawExplanation || (err.cause_key ? t(`cf_err_${err.cause_key}_desc`, err.cause_explanation || err.error || t("cf_err_default", "An error occurred while communicating with Cloudflare API.")) : (err.error || t("cf_err_default", "An error occurred while communicating with Cloudflare API.")));

    const rawAction = (isAr ? err.cause_action_ar : null) || err.cause_action;
    const action = rawAction || (err.cause_key ? t(`cf_err_${err.cause_key}_action`, err.cause_action || "") : (err.cause_action || ""));

    const url = err.dashboard_url || "";
    const perm = err.required_perm || "";
    const code = err.error_code || err.status_code || "";

    const lblCause = t("cf_err_cause", "Root Cause:");
    const lblPerm = t("cf_err_required_perm", "Required API Permission:");
    const lblAction = t("cf_err_suggested_action", "Suggested Fix:");
    const lblFixInCf = t("cf_err_fix_in_cf", "Fix in Cloudflare");
    const lblRetry = t("cf_err_retry", "Retry");

    return `
      <div class="card" style="margin:0 0 16px 0;padding:16px 20px;border-inline-start:4px solid var(--red);background:var(--surface);display:flex;flex-direction:column;gap:12px;box-shadow:var(--shadow-sm)">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:10px">
          <div style="display:flex;align-items:center;gap:12px">
            <div style="width:38px;height:38px;border-radius:10px;background:rgba(239, 68, 68, 0.12);color:var(--red);display:grid;place-items:center;flex-shrink:0">
              ${icon("alert")}
            </div>
            <div>
              <b style="font-size:14px;color:var(--red);display:block">${esc(title)}</b>
              <div class="muted sm" style="font-family:var(--mono);font-size:11px;margin-top:2px">
                ${code ? `Code: ${esc(code)} · ` : ""}${esc(err.error || title)}
              </div>
            </div>
          </div>
          <div class="btn-row" style="margin:0;gap:8px">
            ${url ? `
              <button type="button" class="btn sm primary" data-open-url="${esc(url)}">
                ${icon("browser")} ${esc(lblFixInCf)}
              </button>
            ` : ""}
            ${retryBtnId ? `
              <button type="button" class="btn sm ghost" id="${esc(retryBtnId)}">
                ${icon("refresh")} ${esc(lblRetry)}
              </button>
            ` : ""}
          </div>
        </div>

        <div style="font-size:13px;line-height:1.6;color:var(--text);background:var(--surface-2);padding:12px 14px;border-radius:8px;border:1px solid var(--border)">
          <div style="margin-bottom:6px"><b>${esc(lblCause)}</b> ${esc(explanation)}</div>
          ${perm ? `<div style="margin-bottom:6px;color:var(--accent)"><b>${esc(lblPerm)}</b> <code>${esc(perm)}</code></div>` : ""}
          ${action ? `<div style="color:var(--green)"><b>${esc(lblAction)}</b> ${esc(action)}</div>` : ""}
        </div>
      </div>
    `;
  }

  function renderActiveTab() {
    switch (S.tab) {
      case "overview": return renderOverviewTab();
      case "dns": return renderDnsTab();
      case "cache": return renderCacheTab();
      case "r2": return renderR2Tab();
      case "tunnels": return renderTunnelsTab();
      case "security": return renderSecurityTab();
      default: return `<p>Tab not found.</p>`;
    }
  }

  // ── Tab 1: Overview ──────────────────────────────────────────────────────

  function renderOverviewTab() {
    const cz = currentZone();
    return `
      <div style="display:flex;flex-direction:column;gap:20px">
        ${renderErrorBanner(S.errorObj, "btn-cf-refresh")}
        <!-- Quick Stats Cards -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:16px">
          <div class="card" style="margin:0;padding:16px">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
              <span style="color:var(--muted);font-size:12px">Active Account</span>
              ${(S.status.accounts || []).length > 1 ? `<span class="chip sm primary" style="font-size:10px">${(S.status.accounts || []).length} Accounts</span>` : ""}
            </div>
            <div style="font-size:16px;font-weight:600;display:flex;align-items:center;gap:6px">
              ${icon("cloud")} ${esc(S.status.account_name || "Cloudflare User")}
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:6px">
              <span class="muted sm" style="font-family:var(--mono);font-size:11px">${esc(S.status.token_masked)}</span>
              <button type="button" class="btn sm xs ghost" id="btn-quick-manage-accs" style="padding:2px 8px;font-size:11px">${icon("refresh")}Switch</button>
            </div>
          </div>

          <div class="card" style="margin:0;padding:16px">
            <div style="color:var(--muted);font-size:12px;margin-bottom:4px">Managed Domains (Zones)</div>
            <div style="font-size:24px;font-weight:700">${S.zones.length}</div>
            <div class="muted sm" style="margin-top:4px">Active across Cloudflare edge</div>
          </div>

          <div class="card" style="margin:0;padding:16px">
            <div style="color:var(--muted);font-size:12px;margin-bottom:4px">R2 Object Storage</div>
            <div style="font-size:24px;font-weight:700">${S.r2Buckets.length} <small style="font-size:13px;font-weight:normal">bucket(s)</small></div>
            <div class="muted sm" style="margin-top:4px">Zero egress fee storage</div>
          </div>

          <div class="card" style="margin:0;padding:16px">
            <div style="color:var(--muted);font-size:12px;margin-bottom:4px">Account Tunnels</div>
            <div style="font-size:24px;font-weight:700">${S.tunnels.length}</div>
            <div class="muted sm" style="margin-top:4px">Zero Trust connectors</div>
          </div>
        </div>

        <!-- Domains List Card -->
        <div class="card">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
            <h3 style="margin:0">${icon("globe")}Your Domains (Zones)</h3>
            <span class="muted sm">${S.zones.length} total</span>
          </div>
          ${S.zones.length ? `
            <div class="table-wrap">
              <table style="width:100%;font-size:13px">
                <thead>
                  <tr style="text-align:left;border-bottom:1px solid var(--border)">
                    <th style="padding:8px">Domain</th>
                    <th style="padding:8px">Status</th>
                    <th style="padding:8px">Plan</th>
                    <th style="padding:8px">Name Servers</th>
                    <th style="padding:8px;text-align:right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  ${S.zones.map((z) => `
                    <tr style="border-bottom:1px solid var(--border)">
                      <td style="padding:10px 8px;font-weight:600">
                        <a href="javascript:void(0)" class="link" data-open-zone-dns="${esc(z.id)}">${esc(z.name)}</a>
                      </td>
                      <td style="padding:10px 8px">
                        <span class="chip ${z.status === "active" ? "ok" : "warn"} sm">${esc(z.status)}</span>
                      </td>
                      <td style="padding:10px 8px"><span class="chip sm">${esc(z.plan)}</span></td>
                      <td style="padding:10px 8px;font-family:var(--mono);font-size:11px;color:var(--muted)">
                        ${esc((z.name_servers || []).join(", "))}
                      </td>
                      <td style="padding:10px 8px;text-align:right">
                        <button type="button" class="btn xs" data-open-zone-dns="${esc(z.id)}">${icon("globe")}DNS</button>
                        <button type="button" class="btn xs ghost" data-open-zone-cache="${esc(z.id)}">${icon("zap")}Cache</button>
                      </td>
                    </tr>
                  `).join("")}
                </tbody>
              </table>
            </div>
          ` : `<p class="muted sm">No domains found in this Cloudflare account.</p>`}
        </div>
      </div>
    `;
  }

  // ── Tab 2: Domains & DNS ─────────────────────────────────────────────────

  function renderDnsTab() {
    const cz = currentZone();
    const records = S.dnsRecords;
    const filterTypes = ["ALL", "A", "AAAA", "CNAME", "TXT", "MX"];

    return `
      <div style="display:flex;flex-direction:column;gap:16px">
        ${renderErrorBanner(S.dnsErrorObj, "btn-refresh-dns")}
        <!-- Zone Selector & Actions Bar -->
        <div class="card" style="margin:0;padding:14px 16px">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
            <div style="display:flex;align-items:center;gap:12px;flex:1;min-width:260px">
              <label style="font-weight:600;font-size:13px">Active Domain:</label>
              <select id="cf-dns-zone-select" style="max-width:280px">
                ${S.zones.map((z) => `<option value="${esc(z.id)}" ${z.id === S.currentZoneId ? "selected" : ""}>${esc(z.name)} (${esc(z.status)})</option>`).join("")}
              </select>
            </div>
            <div style="display:flex;gap:8px">
              <button type="button" class="btn sm primary" id="btn-add-dns">${icon("plus")}Add Record</button>
              <button type="button" class="btn sm ghost" id="btn-quick-purge-cache">${icon("zap")}Purge Cache</button>
            </div>
          </div>
        </div>

        <!-- Filter & Search Bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
          <div style="display:flex;gap:4px">
            ${filterTypes.map((t) => `
              <button type="button" class="segment ${S.dnsFilterType === t ? "active" : ""}" data-dns-type="${esc(t)}">${esc(t)}</button>
            `).join("")}
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <input type="search" class="input sm" id="cf-dns-search" placeholder="Search records…" value="${esc(S.dnsSearch)}" style="width:200px">
            <button type="button" class="btn sm icon-btn" id="btn-dns-refresh" title="Refresh DNS">${icon("refresh")}</button>
          </div>
        </div>

        <!-- Records Table -->
        <div class="card" style="margin:0;padding:0;overflow:hidden">
          ${S.loading ? `<div style="text-align:center;padding:32px" class="muted">${icon("pulse")} Loading DNS records…</div>` : `
            <div class="table-wrap">
              <table style="width:100%;font-size:12.5px;border-collapse:collapse">
                <thead>
                  <tr style="border-bottom:1px solid var(--border);background:var(--surface-2);text-align:left">
                    <th style="padding:10px 12px;width:70px">Type</th>
                    <th style="padding:10px 12px">Name</th>
                    <th style="padding:10px 12px">Content / Target</th>
                    <th style="padding:10px 12px;width:120px">Proxy status</th>
                    <th style="padding:10px 12px;width:70px">TTL</th>
                    <th style="padding:10px 12px;text-align:right;width:110px">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  ${records.length ? records.map((r) => `
                    <tr style="border-bottom:1px solid var(--border)">
                      <td style="padding:10px 12px">
                        <span class="chip sm ${r.type === 'A' ? 'ok' : r.type === 'CNAME' ? 'accent' : ''}" style="font-weight:700">${esc(r.type)}</span>
                      </td>
                      <td style="padding:10px 12px;font-weight:600;font-family:var(--mono)">${esc(r.name)}</td>
                      <td style="padding:10px 12px;font-family:var(--mono);color:var(--text);word-break:break-all">
                        ${esc(r.content)}
                        ${r.priority !== undefined && r.priority !== null ? `<span class="chip sm" style="margin-left:4px">Pri: ${esc(r.priority)}</span>` : ""}
                      </td>
                      <td style="padding:10px 12px">
                        ${r.proxiable ? `
                          <button type="button" class="btn xs ghost" data-toggle-proxy="${esc(r.id)}" data-current-proxied="${r.proxied ? '1' : '0'}" style="color:${r.proxied ? '#f6821f' : 'var(--muted)'};display:inline-flex;align-items:center;gap:4px">
                            <span class="dot" style="background:${r.proxied ? '#f6821f' : 'var(--muted)'}"></span>
                            ${r.proxied ? '🟠 Proxied' : '⚪ DNS only'}
                          </button>
                        ` : `<span class="muted sm">—</span>`}
                      </td>
                      <td style="padding:10px 12px;color:var(--muted)">${r.ttl === 1 ? 'Auto' : `${r.ttl}s`}</td>
                      <td style="padding:10px 12px;text-align:right">
                        <button type="button" class="btn ghost icon-btn xs" data-edit-dns="${esc(r.id)}" title="Edit">${icon("edit")}</button>
                        <button type="button" class="btn ghost icon-btn xs danger" data-delete-dns="${esc(r.id)}" title="Delete">${icon("trash")}</button>
                      </td>
                    </tr>
                  `).join("") : `
                    <tr><td colspan="6" style="text-align:center;padding:32px;color:var(--muted)">No DNS records match the filter.</td></tr>
                  `}
                </tbody>
              </table>
            </div>
          `}
        </div>
      </div>
    `;
  }

  // ── Tab 3: Cache & Performance ───────────────────────────────────────────

  function renderCacheTab() {
    const cz = currentZone();
    return `
      <div style="display:flex;flex-direction:column;gap:20px;max-width:800px">
        ${renderErrorBanner(S.cacheErrorObj, "btn-refresh-cache")}
        <!-- Zone Selector -->
        <div style="display:flex;align-items:center;gap:12px">
          <label style="font-weight:600;font-size:13px">Domain:</label>
          <select id="cf-cache-zone-select" style="max-width:280px">
            ${S.zones.map((z) => `<option value="${esc(z.id)}" ${z.id === S.currentZoneId ? "selected" : ""}>${esc(z.name)}</option>`).join("")}
          </select>
        </div>

        <!-- Development Mode Card -->
        <div class="card">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
            <div>
              <h3 style="margin:0">${icon("wrench")}Development Mode</h3>
              <p class="muted sm" style="margin:4px 0 0">Temporarily bypass Cloudflare edge cache for 3 hours to see asset changes immediately.</p>
            </div>
            <button type="button" class="btn sm ${S.devMode ? 'danger' : 'primary'}" id="btn-toggle-dev-mode">
              ${S.devMode ? `${icon("stop")} Turn Off` : `${icon("play")} Turn On`}
            </button>
          </div>
          <div style="display:flex;align-items:center;gap:8px;margin-top:10px">
            <span class="dot ${S.devMode ? 'on' : 'off'}"></span>
            <b>${S.devMode ? 'Active (Cache Bypassed)' : 'Off (Cache Enabled)'}</b>
            ${S.devMode && S.devModeTime ? `<span class="chip warn sm">${Math.round(S.devModeTime / 60)} mins remaining</span>` : ""}
          </div>
        </div>

        <!-- Purge Cache Card -->
        <div class="card">
          <h3 style="margin:0 0 8px">${icon("zap")}Purge Edge Cache</h3>
          <p class="muted sm" style="margin:0 0 16px">Clear cached resources so Cloudflare fetches fresh versions from your web server.</p>

          <div style="display:flex;flex-direction:column;gap:16px">
            <!-- Purge Everything -->
            <div style="padding:14px;border:1px solid var(--border);border-radius:8px;background:var(--surface-2);display:flex;align-items:center;justify-content:space-between">
              <div>
                <b>Purge Everything</b>
                <p class="muted sm" style="margin:4px 0 0">Removes all cached assets (CSS, JS, images, pages) from Cloudflare data centers worldwide.</p>
              </div>
              <button type="button" class="btn danger sm" id="btn-purge-all">${icon("trash")}Purge Everything</button>
            </div>

            <!-- Purge Specific URLs -->
            <div style="padding:14px;border:1px solid var(--border);border-radius:8px;background:var(--surface-2)">
              <b style="display:block;margin-bottom:6px">Purge Specific URLs / Files</b>
              <p class="muted sm" style="margin:0 0 10px">Enter one URL per line (e.g. <code>https://${cz ? esc(cz.name) : 'example.com'}/css/app.css</code>).</p>
              <textarea id="cf-purge-urls-input" class="input sm" rows="3" placeholder="https://${cz ? esc(cz.name) : 'example.com'}/assets/app.js" style="font-family:var(--mono);width:100%;margin-bottom:10px"></textarea>
              <button type="button" class="btn sm" id="btn-purge-files">${icon("zap")}Purge Files</button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // ── Tab 4: R2 Storage ────────────────────────────────────────────────────

  function renderR2Tab() {
    return `
      <div style="display:flex;flex-direction:column;gap:20px">
        ${renderErrorBanner(S.r2ErrorObj, "btn-refresh-r2")}
        <div class="card" style="margin:0;padding:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
          <div>
            <h3 style="margin:0">${icon("database")}Cloudflare R2 Object Storage</h3>
            <p class="muted sm" style="margin:4px 0 0">S3-compatible object storage with <b>zero egress fees</b>. Perfect for Laravel file uploads and backups.</p>
            ${S.status.account_id ? `
              <div style="margin-top:8px;font-size:12px;font-family:var(--mono);color:var(--muted)">
                S3 Endpoint: <code>https://${esc(S.status.account_id)}.r2.cloudflaredstorage.com</code>
              </div>
            ` : ""}
          </div>
          <button type="button" class="btn sm primary" id="btn-create-r2-bucket">${icon("plus")}New Bucket</button>
        </div>

        <div class="card" style="margin:0">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
            <h3 style="margin:0">Buckets (${S.r2Buckets.length})</h3>
            <button type="button" class="btn xs icon-btn ghost" id="btn-refresh-r2">${icon("refresh")}</button>
          </div>

          ${S.r2Buckets.length ? `
            <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(320px, 1fr));gap:14px">
              ${S.r2Buckets.map((b) => `
                <div style="padding:14px;border:1px solid var(--border);border-radius:8px;background:var(--surface-2);display:flex;flex-direction:column;justify-content:space-between">
                  <div>
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                      <b style="font-size:15px;font-family:var(--mono)">${esc(b.name)}</b>
                      <span class="chip sm">${esc(b.location || 'auto')}</span>
                    </div>
                    <div class="muted sm" style="font-size:11px">Created: ${esc(b.creation_date ? new Date(b.creation_date).toLocaleDateString() : 'N/A')}</div>
                  </div>
                  <div style="display:flex;align-items:center;justify-content:space-between;margin-top:16px;padding-top:10px;border-top:1px solid var(--border)">
                    <button type="button" class="btn xs" data-r2-apply-site="${esc(b.name)}">${icon("code")}Apply to Laravel .env</button>
                    <button type="button" class="btn xs ghost danger" data-r2-delete-bucket="${esc(b.name)}" title="Delete bucket">${icon("trash")}</button>
                  </div>
                </div>
              `).join("")}
            </div>
          ` : `
            <div style="text-align:center;padding:32px;color:var(--muted)">
              ${S.r2ErrorObj ? esc(t("cf_err_r2_failed", "Could not load R2 buckets due to the error above.")) : 'No R2 buckets found. Click "New Bucket" to create one.'}
            </div>
          `}
        </div>
      </div>
    `;
  }

  // ── Tab 5: Tunnels ───────────────────────────────────────────────────────

  function renderTunnelsTab() {
    return `
      <div style="display:flex;flex-direction:column;gap:20px">
        ${renderErrorBanner(S.tunnelsErrorObj, "btn-refresh-tunnels")}
        <div class="card" style="margin:0;padding:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
          <div>
            <h3 style="margin:0">${icon("cloud")}Cloudflare Central Named Tunnels</h3>
            <p class="muted sm" style="margin:4px 0 0">Tunnels registered under your Cloudflare Zero Trust account.</p>
          </div>
          <button type="button" class="btn sm primary" id="btn-create-named-tunnel">${icon("plus")}Create Named Tunnel</button>
        </div>

        <div class="card" style="margin:0">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
            <h3 style="margin:0">Account Tunnels (${S.tunnels.length})</h3>
            <button type="button" class="btn xs icon-btn ghost" id="btn-refresh-tunnels">${icon("refresh")}</button>
          </div>

          ${S.tunnels.length ? `
            <div class="table-wrap">
              <table style="width:100%;font-size:12.5px;border-collapse:collapse">
                <thead>
                  <tr style="border-bottom:1px solid var(--border);background:var(--surface-2);text-align:left">
                    <th style="padding:10px 12px">Name</th>
                    <th style="padding:10px 12px">Tunnel ID</th>
                    <th style="padding:10px 12px">Status</th>
                    <th style="padding:10px 12px">Connectors</th>
                    <th style="padding:10px 12px;text-align:right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  ${S.tunnels.map((t) => `
                    <tr style="border-bottom:1px solid var(--border)">
                      <td style="padding:10px 12px;font-weight:600">${esc(t.name)}</td>
                      <td style="padding:10px 12px;font-family:var(--mono);color:var(--muted)">${esc(t.id)}</td>
                      <td style="padding:10px 12px">
                        <span class="chip ${t.status === 'healthy' ? 'ok' : 'warn'} sm">${esc(t.status || 'unknown')}</span>
                      </td>
                      <td style="padding:10px 12px">${esc(t.connections_count || 0)}</td>
                      <td style="padding:10px 12px;text-align:right">
                        <button type="button" class="btn xs" data-copy-tunnel-token="${esc(t.id)}">${icon("copy")}Token</button>
                        <button type="button" class="btn xs" data-bind-tunnel-site="${esc(t.id)}" data-tunnel-name="${esc(t.name)}">${icon("link")}Bind to Site</button>
                        <button type="button" class="btn xs ghost danger" data-delete-account-tunnel="${esc(t.id)}">${icon("trash")}</button>
                      </td>
                    </tr>
                  `).join("")}
                </tbody>
              </table>
            </div>
          ` : `
            <div style="text-align:center;padding:32px;color:var(--muted)">
              ${S.tunnelsErrorObj ? esc(t("cf_err_tunnels_failed", "Could not load tunnels due to the error above.")) : "No Named Tunnels registered yet."}
            </div>
          `}
        </div>
      </div>
    `;
  }

  // ── Tab 6: Security ──────────────────────────────────────────────────────

  function renderSecurityTab() {
    const levels = [
      { id: "essentially_off", title: "Essentially Off", desc: "Minimal challenges, only the most egregious threats." },
      { id: "low", title: "Low", desc: "Challenges only the most threatening visitors." },
      { id: "medium", title: "Medium (Default)", desc: "Challenges visitors exhibiting suspicious behavior." },
      { id: "high", title: "High", desc: "Challenges visitors exhibiting threatening behavior within 14 days." },
      { id: "under_attack", title: "I'm Under Attack! 🚨", desc: "Shows an interactive JavaScript verification challenge to every visitor." },
    ];

    return `
      <div style="display:flex;flex-direction:column;gap:20px;max-width:800px">
        ${renderErrorBanner(S.securityErrorObj, "btn-refresh-security")}
        <div style="display:flex;align-items:center;gap:12px">
          <label style="font-weight:600;font-size:13px">Domain:</label>
          <select id="cf-security-zone-select" style="max-width:280px">
            ${S.zones.map((z) => `<option value="${esc(z.id)}" ${z.id === S.currentZoneId ? "selected" : ""}>${esc(z.name)}</option>`).join("")}
          </select>
        </div>

        <div class="card">
          <h3 style="margin:0 0 6px">${icon("lock")}Security Level (DDoS Protection)</h3>
          <p class="muted sm" style="margin:0 0 16px">Control how aggressively Cloudflare challenges suspicious visitors and web scrapers.</p>

          <div style="display:flex;flex-direction:column;gap:10px">
            ${levels.map((lvl) => `
              <label style="display:flex;align-items:flex-start;gap:10px;padding:12px;border:1px solid ${S.securityLevel === lvl.id ? 'var(--accent)' : 'var(--border)'};border-radius:8px;background:${S.securityLevel === lvl.id ? 'var(--accent-soft)' : 'var(--surface-2)'};cursor:pointer">
                <input type="radio" name="cf-sec-level" value="${esc(lvl.id)}" ${S.securityLevel === lvl.id ? 'checked' : ''} style="margin-top:3px">
                <div style="flex:1">
                  <b>${esc(lvl.title)}</b>
                  <p class="muted sm" style="margin:2px 0 0">${esc(lvl.desc)}</p>
                </div>
              </label>
            `).join("")}
          </div>
          <div style="margin-top:16px;display:flex;justify-content:flex-end">
            <button type="button" class="btn sm primary" id="btn-save-security-level">${icon("check")}Apply Security Level</button>
          </div>
        </div>
      </div>
    `;
  }

  // ── Event Handlers ───────────────────────────────────────────────────────

  function attachOnboardingEvents(root) {
    const form = $("#cf-onboarding-form", root);
    if (!form) return;

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const tokenInput = $("#cf-token-input", root);
      const token = tokenInput ? tokenInput.value.trim() : "";
      const resultBox = $("#cf-verify-result", root);
      const btn = $("#btn-verify-cf", root);

      if (!token) return;
      btn.disabled = true;
      btn.textContent = "Verifying token…";
      resultBox.innerHTML = `<span class="spin-dot"></span> Checking permissions on Cloudflare API…`;

      try {
        const res = await LD.call("cf_verify_token", { token });
        if (!res.ok || !res.valid) {
          resultBox.innerHTML = renderErrorBanner(res) || `
            <div class="notice danger" style="margin-top:8px">
              ${icon("alert")}<span>${esc(res.error || "Token verification failed")}</span>
            </div>
          `;
          btn.disabled = false;
          btn.innerHTML = `${icon("check")} Verify &amp; Connect`;
          return;
        }

        const accounts = res.accounts || [];
        const customLabel = ($("#cf-account-label-input", root)?.value || "").trim();
        let accountId = accounts[0] ? accounts[0].id : "";
        let accountName = customLabel || (accounts[0] ? accounts[0].name : "Cloudflare Account");

        // Save credentials
        await LD.call("cf_save_credentials", {
          token,
          account_id: accountId,
          account_name: accountName,
          make_active: true,
        });

        toast("success", "Cloudflare connected", `Welcome! Account ${accountName || accountId} is now active.`);
        await refreshStatus();
        await loadZones();
        render();
      } catch (err) {
        resultBox.innerHTML = `<div class="notice danger" style="margin-top:8px">${icon("alert")}<span>${esc(err.message)}</span></div>`;
        btn.disabled = false;
        btn.innerHTML = `${icon("check")} Verify &amp; Connect`;
      }
    });
  }

  async function switchAccount(accId) {
    if (!accId || accId === S.status.account_id) return;
    S.loading = true;
    try {
      const res = await LD.call("cf_switch_account", { account_id: accId });
      if (res.ok) {
        toast("success", "Account Switched", `Active account is now: ${res.account_name || accId}`);
        await refreshStatus();
        S.zones = [];
        S.currentZoneId = "";
        await loadZones();
        if (S.tab === "dns") await loadDnsRecords();
        else if (S.tab === "cache" || S.tab === "security") await loadCacheAndSecurity();
        else if (S.tab === "r2") await loadR2Buckets();
        else if (S.tab === "tunnels") await loadTunnels();
        render();
      } else {
        toast("error", "Switch Failed", res.error || "Could not switch account");
      }
    } catch (err) {
      toast("error", "Error", err.message);
    } finally {
      S.loading = false;
    }
  }

  function attachMainEvents(root) {
    // Account Switcher Dropdown
    $("#cf-account-select", root)?.addEventListener("change", (e) => {
      switchAccount(e.target.value);
    });

    // Add Account Button
    $("#btn-cf-add-account", root)?.addEventListener("click", () => {
      openAddAccountModal();
    });

    // Manage Accounts Button / Chip
    $("#btn-cf-manage-accounts", root)?.addEventListener("click", () => {
      openManageAccountsModal();
    });
    $("#cf-chip-acc-count", root)?.addEventListener("click", () => {
      openManageAccountsModal();
    });
    $("#btn-quick-manage-accs", root)?.addEventListener("click", () => {
      openManageAccountsModal();
    });

    // Tab switching
    root.querySelectorAll("[data-cf-tab]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        S.tab = btn.dataset.cfTab;
        if (S.tab === "dns") await loadDnsRecords();
        else if (S.tab === "cache" || S.tab === "security") await loadCacheAndSecurity();
        else if (S.tab === "r2") await loadR2Buckets();
        else if (S.tab === "tunnels") await loadTunnels();
        render();
      });
    });

    // Refresh & Disconnect
    $("#btn-cf-refresh", root)?.addEventListener("click", async () => {
      await refreshStatus();
      await loadZones();
      if (S.tab === "dns") await loadDnsRecords();
      else if (S.tab === "r2") await loadR2Buckets();
      else if (S.tab === "tunnels") await loadTunnels();
      toast("info", "Cloudflare data refreshed");
      render();
    });

    $("#btn-cf-disconnect", root)?.addEventListener("click", async () => {
      const accs = S.status.accounts || [];
      const isMulti = accs.length > 1;
      const ok = await confirmModal({
        title: isMulti ? `Remove Account '${S.status.account_name}'?` : "Disconnect Cloudflare Account?",
        message: isMulti
          ? `You have ${accs.length} accounts linked. This will remove '${S.status.account_name}' from this app. Your other accounts will remain configured.`
          : "Your API token will be safely removed from local storage. Your Cloudflare settings will remain intact.",
        confirm: isMulti ? "Remove Account" : "Disconnect",
        danger: true,
      });
      if (!ok) return;
      if (isMulti) {
        await LD.call("cf_remove_account", { account_id: S.status.account_id });
      } else {
        await LD.call("cf_disconnect");
      }
      await refreshStatus();
      S.zones = [];
      S.dnsRecords = [];
      if (S.status.configured) {
        await loadZones();
      }
      toast("info", isMulti ? "Account removed" : "Cloudflare disconnected");
      render();
    });

    // Domain switchers
    const zoneSelectors = ["#cf-dns-zone-select", "#cf-cache-zone-select", "#cf-security-zone-select"];
    zoneSelectors.forEach((selId) => {
      const sel = $(selId, root);
      if (sel) {
        sel.addEventListener("change", async () => {
          S.currentZoneId = sel.value;
          if (S.tab === "dns") await loadDnsRecords();
          else if (S.tab === "cache" || S.tab === "security") await loadCacheAndSecurity();
          render();
        });
      }
    });

    // Open zone directly from overview
    root.querySelectorAll("[data-open-zone-dns]").forEach((el) => {
      el.addEventListener("click", async () => {
        S.currentZoneId = el.dataset.openZoneDns;
        S.tab = "dns";
        await loadDnsRecords();
        render();
      });
    });

    root.querySelectorAll("[data-open-zone-cache]").forEach((el) => {
      el.addEventListener("click", async () => {
        S.currentZoneId = el.dataset.openZoneCache;
        S.tab = "cache";
        await loadCacheAndSecurity();
        render();
      });
    });

    // DNS type filter & search
    root.querySelectorAll("[data-dns-type]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        S.dnsFilterType = btn.dataset.dnsType;
        await loadDnsRecords();
      });
    });

    const searchInput = $("#cf-dns-search", root);
    if (searchInput) {
      searchInput.addEventListener("keydown", async (e) => {
        if (e.key === "Enter") {
          S.dnsSearch = searchInput.value.trim();
          await loadDnsRecords();
        }
      });
    }

    $("#btn-dns-refresh", root)?.addEventListener("click", loadDnsRecords);
    $("#btn-refresh-dns", root)?.addEventListener("click", loadDnsRecords);
    $("#btn-refresh-cache", root)?.addEventListener("click", async () => {
      await loadCacheAndSecurity();
      render();
    });
    $("#btn-refresh-security", root)?.addEventListener("click", async () => {
      await loadCacheAndSecurity();
      render();
    });

    // DNS Proxy toggle
    root.querySelectorAll("[data-toggle-proxy]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.toggleProxy;
        const current = btn.dataset.currentProxied === "1";
        const newProxied = !current;
        btn.disabled = true;
        try {
          const res = await LD.call("cf_dns_proxy", {
            zone_id: S.currentZoneId,
            record_id: id,
            proxied: newProxied,
          });
          if (res.ok) {
            toast("success", "DNS Proxy updated", newProxied ? "Orange cloud (Proxied) enabled" : "Grey cloud (DNS only) enabled");
            await loadDnsRecords();
          } else {
            toast("error", "Proxy toggle failed", res.error);
          }
        } catch (err) {
          toast("error", "Error", err.message);
        } finally {
          btn.disabled = false;
        }
      });
    });

    // Delete DNS Record
    root.querySelectorAll("[data-delete-dns]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.deleteDns;
        const ok = await confirmModal({
          title: "Delete DNS Record?",
          message: "This will remove the record from Cloudflare edge DNS immediately.",
          confirm: "Delete",
          danger: true,
        });
        if (!ok) return;
        try {
          const res = await LD.call("cf_dns_delete", { zone_id: S.currentZoneId, record_id: id });
          if (res.ok) {
            toast("info", "DNS record deleted");
            await loadDnsRecords();
          } else {
            toast("error", "Delete failed", res.error);
          }
        } catch (err) {
          toast("error", "Error", err.message);
        }
      });
    });

    // Add DNS Record Modal
    $("#btn-add-dns", root)?.addEventListener("click", () => openDnsModal());
    root.querySelectorAll("[data-edit-dns]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const rec = S.dnsRecords.find((r) => r.id === btn.dataset.editDns);
        if (rec) openDnsModal(rec);
      });
    });

    // Cache Purge buttons
    const handlePurgeAll = async () => {
      const ok = await confirmModal({
        title: "Purge Everything from Edge Cache?",
        message: "This temporarily increases traffic to your origin web server while the edge cache repopulates.",
        confirm: "Purge Everything",
        danger: true,
      });
      if (!ok) return;
      try {
        const res = await LD.call("cf_purge_cache", { zone_id: S.currentZoneId, purge_everything: true });
        if (res.ok) toast("success", "Cache purged", "All cached resources cleared worldwide.");
        else toast("error", "Purge failed", res.error);
      } catch (err) {
        toast("error", "Purge failed", err.message);
      }
    };

    $("#btn-purge-all", root)?.addEventListener("click", handlePurgeAll);
    $("#btn-quick-purge-cache", root)?.addEventListener("click", handlePurgeAll);

    $("#btn-purge-files", root)?.addEventListener("click", async () => {
      const input = $("#cf-purge-urls-input", root);
      const text = input ? input.value.trim() : "";
      if (!text) {
        toast("error", "No URLs entered", "Please enter at least one URL to purge.");
        return;
      }
      const files = text.split("\n").map((u) => u.trim()).filter(Boolean);
      try {
        const res = await LD.call("cf_purge_cache", { zone_id: S.currentZoneId, purge_everything: false, files });
        if (res.ok) {
          toast("success", "Files purged", `${files.length} URL(s) cleared from cache.`);
          if (input) input.value = "";
        } else {
          toast("error", "Purge failed", res.error);
        }
      } catch (err) {
        toast("error", "Purge failed", err.message);
      }
    });

    // Toggle Dev Mode
    $("#btn-toggle-dev-mode", root)?.addEventListener("click", async () => {
      const nextState = !S.devMode;
      try {
        const res = await LD.call("cf_dev_mode_set", { zone_id: S.currentZoneId, enable: nextState });
        if (res.ok) {
          S.devMode = nextState;
          toast("success", "Development Mode", nextState ? "Enabled for 3 hours (cache bypassed)" : "Disabled (cache active)");
          render();
        } else {
          toast("error", "Dev Mode failed", res.error);
        }
      } catch (err) {
        toast("error", "Error", err.message);
      }
    });

    // Save Security Level
    $("#btn-save-security-level", root)?.addEventListener("click", async () => {
      const checked = root.querySelector('input[name="cf-sec-level"]:checked');
      if (!checked) return;
      const level = checked.value;
      try {
        const res = await LD.call("cf_security_level_set", { zone_id: S.currentZoneId, level });
        if (res.ok) {
          S.securityLevel = level;
          toast("success", "Security Level Updated", `Set to ${level}`);
          render();
        } else {
          toast("error", "Update failed", res.error);
        }
      } catch (err) {
        toast("error", "Error", err.message);
      }
    });

    // R2 Actions
    $("#btn-refresh-r2", root)?.addEventListener("click", loadR2Buckets);
    $("#btn-create-r2-bucket", root)?.addEventListener("click", openCreateR2Modal);

    root.querySelectorAll("[data-r2-delete-bucket]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const name = btn.dataset.r2DeleteBucket;
        const ok = await confirmModal({
          title: `Delete Bucket "${name}"?`,
          message: "The bucket must be empty before it can be deleted.",
          confirm: "Delete Bucket",
          danger: true,
        });
        if (!ok) return;
        try {
          const res = await LD.call("cf_r2_delete_bucket", { name });
          if (res.ok) {
            toast("info", "Bucket deleted");
            await loadR2Buckets();
          } else {
            toast("error", "Delete failed", res.error);
          }
        } catch (err) {
          toast("error", "Error", err.message);
        }
      });
    });

    root.querySelectorAll("[data-r2-apply-site]").forEach((btn) => {
      btn.addEventListener("click", () => openApplyR2Modal(btn.dataset.r2ApplySite));
    });

    // Tunnels Actions
    $("#btn-refresh-tunnels", root)?.addEventListener("click", loadTunnels);
    $("#btn-create-named-tunnel", root)?.addEventListener("click", openCreateTunnelModal);

    root.querySelectorAll("[data-copy-tunnel-token]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.copyTunnelToken;
        try {
          const res = await LD.call("cf_tunnel_token", { tunnel_id: id });
          if (res.ok && res.token) {
            await copyText(res.token);
            toast("success", "Tunnel Token Copied", "Use with cloudflared or in project tunnel settings.");
          } else {
            toast("error", "Could not fetch token", res.error);
          }
        } catch (err) {
          toast("error", "Error", err.message);
        }
      });
    });

    root.querySelectorAll("[data-bind-tunnel-site]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.bindTunnelSite;
        const tName = btn.dataset.tunnelName;
        openBindTunnelModal(id, tName);
      });
    });

    root.querySelectorAll("[data-delete-account-tunnel]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.deleteAccountTunnel;
        const ok = await confirmModal({
          title: "Delete Named Tunnel?",
          message: "This will remove the tunnel configuration from your Cloudflare account.",
          confirm: "Delete Tunnel",
          danger: true,
        });
        if (!ok) return;
        try {
          const res = await LD.call("cf_tunnel_delete", { tunnel_id: id });
          if (res.ok) {
            toast("info", "Tunnel deleted");
            await loadTunnels();
          } else {
            toast("error", "Delete failed", res.error);
          }
        } catch (err) {
          toast("error", "Error", err.message);
        }
      });
    });
  }

  // ── Modals ───────────────────────────────────────────────────────────────

  function openDnsModal(existing = null) {
    const isEdit = Boolean(existing);
    const cz = currentZone();
    const zoneName = cz ? cz.name : "";

    openModal(`
      <div class="modal" style="max-width:500px">
        <div class="modal-header">
          <h2>${icon(isEdit ? "edit" : "plus")}${isEdit ? "Edit DNS Record" : "Add DNS Record"}</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="dns-record-form" class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <div style="display:grid;grid-template-columns:120px 1fr;gap:10px">
            <label class="field">
              <span>Type</span>
              <select name="type" required>
                ${["A", "AAAA", "CNAME", "TXT", "MX", "NS"].map((t) => `<option value="${t}" ${existing?.type === t ? 'selected' : ''}>${t}</option>`).join("")}
              </select>
            </label>
            <label class="field">
              <span>Name (@ for root)</span>
              <input name="name" value="${esc(existing?.name || '@')}" required placeholder="subdomain or @" spellcheck="false">
            </label>
          </div>

          <label class="field">
            <span>Target / Content / IP</span>
            <input name="content" value="${esc(existing?.content || '')}" required placeholder="e.g. 192.0.2.1 or tunnel.trycloudflare.com" spellcheck="false">
          </label>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <label class="field">
              <span>TTL</span>
              <select name="ttl">
                <option value="1">Auto</option>
                <option value="60">1 min</option>
                <option value="300">5 mins</option>
                <option value="1800">30 mins</option>
                <option value="3600">1 hour</option>
              </select>
            </label>
            <label class="field">
              <span>Priority (MX only)</span>
              <input name="priority" type="number" min="0" max="65535" value="${existing?.priority || ''}" placeholder="10">
            </label>
          </div>

          <label class="row" style="background:var(--surface-2);padding:10px;border-radius:8px">
            <span>
              <b>Proxy status (Cloudflare CDN &amp; WAF)</b>
              <small>Routes traffic through Cloudflare (Orange cloud)</small>
            </span>
            <input type="checkbox" class="switch" name="proxied" ${existing?.proxied || (!isEdit) ? 'checked' : ''}>
          </label>

          <div id="dns-modal-error"></div>

          <div class="modal-footer" style="padding:14px 0 0">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="btn-submit-dns-record">${icon("check")}${isEdit ? 'Save Changes' : 'Create Record'}</button>
          </div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#dns-record-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const f = e.target.elements;
        const submitBtn = $("#btn-submit-dns-record", root);
        const errBox = $("#dns-modal-error", root);
        if (errBox) errBox.innerHTML = "";
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh")} Saving…`;
        }

        const payload = {
          zone_id: S.currentZoneId,
          record_id: existing?.id || "",
          type: f.type.value,
          name: f.name.value.trim(),
          content: f.content.value.trim(),
          ttl: parseInt(f.ttl.value, 10) || 1,
          proxied: f.proxied.checked,
          priority: f.priority.value ? parseInt(f.priority.value, 10) : null,
        };

        try {
          const res = await LD.call("cf_dns_save", payload);
          if (res.ok) {
            toast("success", isEdit ? "DNS Record Updated" : "DNS Record Created", `${payload.type} ${payload.name}`);
            closeModal();
            await loadDnsRecords();
          } else {
            if (errBox) errBox.innerHTML = renderErrorBanner(res);
            toast("error", res.cause_title || "DNS Save Failed", res.cause_action || res.error || "Save failed");
          }
        } catch (err) {
          if (errBox) errBox.innerHTML = renderErrorBanner({ error: err.message, cause_title: "Save Error", cause_explanation: err.message });
          toast("error", "Error", err.message);
        } finally {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `${icon("check")}${isEdit ? 'Save Changes' : 'Create Record'}`;
          }
        }
      });
    });
  }

  function openCreateR2Modal() {
    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header">
          <h2>${icon("plus")}New R2 Storage Bucket</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="create-r2-form" class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <label class="field">
            <span>Bucket Name <small style="color:var(--red)">*</small></span>
            <input name="name" required placeholder="my-app-uploads" pattern="[a-z0-9][a-z0-9.-]+" spellcheck="false" autocomplete="off">
            <small class="muted">Lowercase letters, numbers, and dashes.</small>
          </label>
          <label class="field">
            <span>Location Hint (Optional)</span>
            <select name="location">
              <option value="">Automatic (recommended)</option>
              <option value="weur">Western Europe</option>
              <option value="eeur">Eastern Europe</option>
              <option value="wnam">Western North America</option>
              <option value="enam">Eastern North America</option>
              <option value="apac">Asia-Pacific</option>
            </select>
          </label>
          <div id="r2-modal-error"></div>
          <div class="modal-footer" style="padding:14px 0 0">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="btn-submit-create-r2">${icon("check")}Create Bucket</button>
          </div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#create-r2-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const f = e.target.elements;
        const name = f.name.value.trim();
        const location_hint = f.location.value;
        const submitBtn = $("#btn-submit-create-r2", root);
        const errBox = $("#r2-modal-error", root);
        if (errBox) errBox.innerHTML = "";
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh")} Creating…`;
        }

        try {
          const res = await LD.call("cf_r2_create_bucket", { name, location_hint });
          if (res.ok) {
            toast("success", "R2 Bucket Created", name);
            closeModal();
            await loadR2Buckets();
          } else {
            if (errBox) errBox.innerHTML = renderErrorBanner(res);
            toast("error", res.cause_title || "Creation Failed", res.cause_action || res.error || "Creation failed");
          }
        } catch (err) {
          if (errBox) errBox.innerHTML = renderErrorBanner({ error: err.message, cause_title: "Creation Error", cause_explanation: err.message });
          toast("error", "Error", err.message);
        } finally {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `${icon("check")}Create Bucket`;
          }
        }
      });
    });
  }

  function openApplyR2Modal(bucketName) {
    const siteOptions = (state.sites || []).map((s) => `<option value="${esc(s.name)}">${esc(s.name)} (${esc(s.display_path)})</option>`).join("");

    openModal(`
      <div class="modal" style="max-width:480px">
        <div class="modal-header">
          <h2>${icon("code")}Apply R2 to Laravel Project</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="apply-r2-form" class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <p class="muted sm" style="margin:0">
            This will update the <code>.env</code> file of the chosen project with the R2 S3-compatible configuration.
          </p>

          <label class="field">
            <span>Select Project</span>
            <select name="site">${siteOptions}</select>
          </label>

          <label class="field">
            <span>R2 Bucket</span>
            <input name="bucket" value="${esc(bucketName)}" readonly style="font-family:var(--mono)">
          </label>

          <label class="field">
            <span>R2 Access Key ID (Optional)</span>
            <input name="access_key" placeholder="Paste S3 Access Key ID (if generated)" style="font-family:var(--mono)">
          </label>

          <label class="field">
            <span>R2 Secret Access Key (Optional)</span>
            <input name="secret_key" type="password" placeholder="Paste S3 Secret Access Key" style="font-family:var(--mono)">
          </label>

          <div class="modal-footer" style="padding:14px 0 0">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary">${icon("check")}Apply to .env</button>
          </div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#apply-r2-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const f = e.target.elements;
        const site = f.site.value;
        const bucket = f.bucket.value;
        const access_key = f.access_key.value.trim();
        const secret_key = f.secret_key.value.trim();

        try {
          const res = await LD.call("cf_r2_apply_site", { site, bucket, access_key, secret_key });
          if (res.ok) {
            toast("success", "R2 Applied", `Updated .env for ${site}`);
            closeModal();
          } else {
            toast("error", "Failed to apply", res.error);
          }
        } catch (err) {
          toast("error", "Error", err.message);
        }
      });
    });
  }

  function openCreateTunnelModal() {
    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header">
          <h2>${icon("plus")}Create Named Cloudflare Tunnel</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="create-tunnel-form" class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <label class="field">
            <span>Tunnel Name <small style="color:var(--red)">*</small></span>
            <input name="name" required placeholder="my-named-tunnel" spellcheck="false" autocomplete="off">
            <small class="muted">Descriptive identifier for this Zero Trust tunnel.</small>
          </label>
          <div id="tunnel-modal-error"></div>
          <div class="modal-footer" style="padding:14px 0 0">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="btn-submit-create-tunnel">${icon("check")}Create Tunnel</button>
          </div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#create-tunnel-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const name = e.target.elements.name.value.trim();
        const submitBtn = $("#btn-submit-create-tunnel", root);
        const errBox = $("#tunnel-modal-error", root);
        if (errBox) errBox.innerHTML = "";
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = `${icon("refresh")} Creating…`;
        }

        try {
          const res = await LD.call("cf_tunnel_create", { name });
          if (res.ok) {
            toast("success", "Tunnel Created", name);
            closeModal();
            await loadTunnels();
          } else {
            if (errBox) errBox.innerHTML = renderErrorBanner(res);
            toast("error", res.cause_title || "Tunnel Creation Failed", res.cause_action || res.error || "Creation failed");
          }
        } catch (err) {
          if (errBox) errBox.innerHTML = renderErrorBanner({ error: err.message, cause_title: "Creation Error", cause_explanation: err.message });
          toast("error", "Error", err.message);
        } finally {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `${icon("check")}Create Tunnel`;
          }
        }
      });
    });
  }

  function openBindTunnelModal(tunnelId, tunnelName) {
    const siteOptions = (state.sites || []).map((s) => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join("");

    openModal(`
      <div class="modal" style="max-width:440px">
        <div class="modal-header">
          <h2>${icon("link")}Bind Tunnel to Site</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="bind-tunnel-form" class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <p class="muted sm" style="margin:0">
            Fetch the credentials token for <b>${esc(tunnelName)}</b> and save it directly into the selected project's tunnel configuration.
          </p>
          <label class="field">
            <span>Select Local Project</span>
            <select name="site">${siteOptions}</select>
          </label>
          <div class="modal-footer" style="padding:14px 0 0">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary">${icon("check")}Bind Token</button>
          </div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#bind-tunnel-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const site = e.target.elements.site.value;
        try {
          const tokRes = await LD.call("cf_tunnel_token", { tunnel_id: tunnelId });
          if (!tokRes.ok || !tokRes.token) {
            toast("error", "Could not get token", tokRes.error);
            return;
          }
          await LD.call("tunnel_token", { name: site, token: tokRes.token });
          toast("success", "Tunnel Bound", `Tunnel token saved for ${site}`);
          closeModal();
        } catch (err) {
          toast("error", "Error", err.message);
        }
      });
    });
  }

  function openAddAccountModal() {
    openModal(`
      <div class="modal" style="max-width:500px">
        <div class="modal-header">
          <h2>${icon("plus")}Add Cloudflare Account</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <form id="add-account-form" class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <div>
            <label class="field">
              <span>Account Label / Friendly Name (optional)</span>
              <input name="label" placeholder="e.g. Personal, Work, Client X" autocomplete="off">
            </label>
            <small class="muted" style="display:block;margin-top:2px">A descriptive name to distinguish this account from others.</small>
          </div>

          <div>
            <label class="field">
              <span>Cloudflare API Token <small style="color:var(--red)">*</small></span>
              <input type="password" name="token" placeholder="Paste Cloudflare API Token" required autocomplete="off" spellcheck="false" style="font-family:var(--mono)">
            </label>
            <small class="muted" style="display:block;margin-top:2px">
              Create an API token at <a href="https://dash.cloudflare.com/profile/api-tokens" class="link" data-open-url="https://dash.cloudflare.com/profile/api-tokens">Cloudflare API Tokens</a>.
            </small>
          </div>

          <div id="add-acc-status"></div>

          <div class="modal-footer" style="padding:14px 0 0">
            <button type="button" class="btn" data-dismiss>Cancel</button>
            <button type="submit" class="btn primary" id="btn-submit-add-acc">${icon("check")}Verify &amp; Add Account</button>
          </div>
        </form>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#add-account-form", root)?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const statusBox = $("#add-acc-status", root);
        const btn = $("#btn-submit-add-acc", root);
        const fd = new FormData(e.target);
        const token = (fd.get("token") || "").trim();
        const label = (fd.get("label") || "").trim();

        if (!token) return;
        btn.disabled = true;
        btn.innerHTML = `${icon("refresh")} Verifying…`;
        statusBox.innerHTML = "";

        try {
          const verifyRes = await LD.call("cf_verify_token", { token });
          if (!verifyRes.ok || !verifyRes.valid) {
            statusBox.innerHTML = renderErrorBanner(verifyRes) || `<div class="notice danger" style="margin-top:8px">${icon("alert")}<span>${esc(verifyRes.error || "Token verification failed")}</span></div>`;
            btn.disabled = false;
            btn.innerHTML = `${icon("check")} Verify &amp; Add Account`;
            return;
          }

          const accounts = verifyRes.accounts || [];
          const accId = accounts[0] ? accounts[0].id : "";
          const accName = label || (accounts[0] ? accounts[0].name : "Cloudflare Account");

          await LD.call("cf_save_credentials", {
            token,
            account_id: accId,
            account_name: accName,
            make_active: true,
          });

          toast("success", "Account Added", `Account '${accName}' added and activated.`);
          closeModal();
          await refreshStatus();
          S.zones = [];
          S.currentZoneId = "";
          await loadZones();
          render();
        } catch (err) {
          statusBox.innerHTML = renderErrorBanner({ error: err.message, cause_title: "Error", cause_explanation: err.message }) || `<div class="notice danger" style="margin-top:8px">${icon("alert")}<span>${esc(err.message)}</span></div>`;
          btn.disabled = false;
          btn.innerHTML = `${icon("check")} Verify &amp; Add Account`;
        }
      });
    });
  }

  function openManageAccountsModal() {
    const accs = S.status.accounts || [];
    openModal(`
      <div class="modal" style="max-width:600px">
        <div class="modal-header">
          <h2>${icon("settings")}Manage Cloudflare Accounts</h2>
          <button type="button" class="btn ghost icon-btn close" data-dismiss aria-label="Close">${icon("x")}</button>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:16px">
          <p class="muted sm" style="margin:0">
            Switch between linked accounts, connect additional accounts, or remove accounts you no longer need.
          </p>

          <div style="display:flex;flex-direction:column;gap:10px">
            ${accs.map((a) => `
              <div class="card" style="margin:0;padding:12px 16px;display:flex;align-items:center;justify-content:space-between;border:${a.is_active ? '2px solid var(--accent)' : '1px solid var(--border)'};background:${a.is_active ? 'var(--accent-soft)' : 'var(--surface)'}">
                <div style="display:flex;align-items:center;gap:12px">
                  <div style="width:36px;height:36px;border-radius:10px;background:var(--accent-soft);color:var(--accent);display:grid;place-items:center">
                    ${icon("cloud")}
                  </div>
                  <div>
                    <div style="font-weight:600;display:flex;align-items:center;gap:8px">
                      ${esc(a.account_name)}
                      ${a.is_active ? `<span class="chip ok sm"><span class="dot on"></span>Active</span>` : ""}
                    </div>
                    <div class="muted sm" style="font-family:var(--mono);font-size:11px">
                      ID: ${esc(a.account_id)} · Token: ${esc(a.token_preview)}
                    </div>
                  </div>
                </div>
                <div style="display:flex;align-items:center;gap:8px">
                  ${!a.is_active ? `
                    <button type="button" class="btn sm" data-switch-acc="${esc(a.account_id)}">${icon("check")}Switch to this</button>
                  ` : ""}
                  <button type="button" class="btn sm ghost danger icon-btn" data-remove-acc="${esc(a.account_id)}" data-acc-name="${esc(a.account_name)}" title="Remove Account">${icon("trash")}</button>
                </div>
              </div>
            `).join("")}
          </div>

          <div class="modal-footer" style="padding:14px 0 0;justify-content:space-between">
            <button type="button" class="btn primary" id="btn-open-add-from-manage">${icon("plus")}Add Another Account</button>
            <button type="button" class="btn" data-dismiss>Close</button>
          </div>
        </div>
      </div>
    `, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      $("#btn-open-add-from-manage", root)?.addEventListener("click", () => {
        closeModal();
        openAddAccountModal();
      });

      root.querySelectorAll("[data-switch-acc]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.dataset.switchAcc;
          closeModal();
          await switchAccount(id);
        });
      });

      root.querySelectorAll("[data-remove-acc]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.dataset.removeAcc;
          const name = btn.dataset.accName;
          const ok = await confirmModal({
            title: `Remove Account '${name}'?`,
            message: "This will remove the account credentials from this app. Your Cloudflare settings will remain intact.",
            confirm: "Remove",
            danger: true,
          });
          if (!ok) return;

          try {
            const res = await LD.call("cf_remove_account", { account_id: id });
            if (res.ok) {
              toast("info", "Account Removed", `Account '${name}' was removed.`);
              closeModal();
              await refreshStatus();
              S.zones = [];
              S.currentZoneId = "";
              if (S.status.configured) {
                await loadZones();
              }
              render();
            } else {
              toast("error", "Failed to remove account", res.error);
            }
          } catch (err) {
            toast("error", "Error", err.message);
          }
        });
      });
    });
  }

  return {
    init,
    show,
  };
})();

window.Cloudflare = Cloudflare;
