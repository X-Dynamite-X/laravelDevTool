"use strict";

/* Environment variables editor (Cloudflare / Vercel style) for a site's .env,
   local or on a server. Edits are staged and written in one save; comments,
   order and untouched lines of the file are kept.
   Uses the helpers defined in app.js (icon, esc, LD, toast, openModal, confirmModal). */

const EnvEditor = (() => {
  const KEY_RE = /^[A-Za-z_][A-Za-z0-9_.]*$/;
  let ed = null; // the editor currently on screen (one at a time)

  function mount(el, target, options = {}) {
    ed = {
      el, target, options,
      data: null, error: "", loading: true,
      edits: new Map(),     // key -> new value
      deleted: new Set(),
      added: [],            // [{key, value, secret}]
      reveal: new Set(),
      filter: "",
      saved: null,          // payload of the last save, for the "apply" notice
      saving: false,
    };
    render();
    load(target.file || "");
  }

  async function load(file) {
    const current = ed;
    current.loading = true;
    render();
    try {
      const data = await LD.call("env_read", { ...current.target, file });
      if (ed !== current) return;
      Object.assign(current, { data, error: "", loading: false, edits: new Map(), deleted: new Set(), added: [] });
    } catch (err) {
      if (ed !== current) return;
      Object.assign(current, { error: err.message, loading: false });
    }
    render();
  }

  const dirtyCount = () => ed.edits.size + ed.deleted.size + ed.added.filter((a) => a.key.trim()).length;
  const isMounted = () => ed && document.body.contains(ed.el);

  function render() {
    if (!isMounted()) return;
    const { data } = ed;
    if (ed.loading && !data) {
      ed.el.innerHTML = `<div class="env-editor"><div class="skeleton" style="height:180px"></div></div>`;
      return;
    }
    if (ed.error && !data) {
      ed.el.innerHTML = `<div class="card error-card"><h3>${icon("alert")}Couldn't read the environment</h3><p class="muted">${esc(ed.error)}</p>
        <button class="btn sm" data-env="reload">${icon("refresh")}Try again</button></div>`;
      return;
    }
    const q = ed.filter.trim().toLowerCase();
    const rows = data.variables
      .filter((v) => !q || v.key.toLowerCase().includes(q) || (!v.secret && String(v.value).toLowerCase().includes(q)))
      .map(varRow).join("");
    const addedRows = ed.added.map(addedRow).join("");
    const count = dirtyCount();
    const files = data.files.includes(data.file) ? data.files : [data.file, ...data.files];

    ed.el.innerHTML = `
      <div class="env-editor">
        <div class="env-toolbar">
          <label class="env-file" title="Environment file">${icon("file")}
            <select data-env-file>${files.map((f) => `<option ${f === data.file ? "selected" : ""}>${esc(f)}</option>`).join("")}
              <option value="__new">New file…</option></select>
          </label>
          <div class="search sm env-search">${icon("search")}<input data-env-filter placeholder="Filter variables" value="${esc(ed.filter)}" autocomplete="off" spellcheck="false"></div>
          <span class="spacer"></span>
          <button class="btn sm" data-env="import" title="Paste a block of KEY=value lines">${icon("upload")}Import .env</button>
          <button class="btn sm" data-env="copy-all" title="Copy the whole file as KEY=value">${icon("copy")}Copy</button>
          <button class="btn sm" data-env="diff-inspector" title="Compare .env with .env.example or another file">${icon("code")}Diff Inspector</button>
          <button class="btn sm" data-env="vault" title="Laravel Environment Encryption Vault">${icon("lock")}Vault</button>
          <button class="btn sm" data-env="compare-server" title="Compare local .env with remote server">${icon("refresh")}Compare Server</button>
          <button class="btn sm primary" data-env="add">${icon("plus")}Add variable</button>
        </div>
        ${!data.exists ? `<div class="notice">${icon("alert")}<span><b>${esc(data.file)}</b> doesn't exist yet — add variables and save to create it.</span></div>` : ""}
        ${ed.saved ? appliedNotice() : ""}
        <div class="env-table">
          <div class="env-head"><span>Type</span><span>Name</span><span>Value</span><span></span></div>
          ${addedRows}
          ${rows || (addedRows ? "" : `<div class="env-empty">${q ? "No variables match." : "No variables yet."}</div>`)}
        </div>
        ${data.missing.length ? `
          <div class="env-missing">
            <div>${icon("alert")}<b>${data.missing.length}</b> variable${data.missing.length > 1 ? "s are" : " is"} in <code>.env.example</code> but not in ${esc(data.file)}:
              <span class="mono">${data.missing.slice(0, 6).map((m) => esc(m.key)).join(", ")}${data.missing.length > 6 ? "…" : ""}</span></div>
            <button class="btn sm" data-env="add-missing">${icon("plus")}Add with example values</button>
          </div>` : ""}
        <div class="env-savebar ${count ? "show" : ""}">
          <span><b>${count}</b> unsaved change${count === 1 ? "" : "s"}</span>
          <span class="spacer"></span>
          <button class="btn sm" data-env="discard">Discard</button>
          <button class="btn sm primary" data-env="save" ${ed.saving ? "disabled" : ""}>${icon("check")}${ed.saving ? "Saving…" : "Save"}</button>
        </div>
      </div>`;
  }

  function typeSelect(secret, attr) {
    return `<select class="env-type ${secret ? "secret" : ""}" ${attr}>
      <option value="text" ${secret ? "" : "selected"}>Text</option>
      <option value="secret" ${secret ? "selected" : ""}>Secret</option></select>`;
  }

  function varRow(v) {
    const deleted = ed.deleted.has(v.key);
    const edited = ed.edits.has(v.key);
    const value = edited ? ed.edits.get(v.key) : v.value;
    const shown = !v.secret || ed.reveal.has(v.key);
    const multiline = String(value).includes("\n");
    return `
      <div class="env-row ${deleted ? "deleted" : ""} ${edited ? "edited" : ""}" data-env-key="${esc(v.key)}">
        ${typeSelect(v.secret, "data-env-type")}
        <span class="env-key mono" title="${esc(v.key)}">${esc(v.key)}</span>
        <span class="env-value">
          ${multiline
            ? `<textarea class="mono" rows="3" data-env-value spellcheck="false" ${deleted ? "disabled" : ""} ${shown ? "" : "style=\"-webkit-text-security:disc\""}>${esc(value)}</textarea>`
            : `<input class="mono" type="${shown ? "text" : "password"}" value="${esc(value)}" data-env-value spellcheck="false" autocomplete="off" ${deleted ? "disabled" : ""} placeholder="(empty)">`}
        </span>
        <span class="env-actions">
          ${v.secret ? `<button class="btn ghost icon-btn sm" data-env="reveal" title="${shown ? "Hide" : "Show"}">${icon("eye")}</button>` : ""}
          <button class="btn ghost icon-btn sm" data-env="copy" title="Copy value">${icon("copy")}</button>
          ${deleted
            ? `<button class="btn ghost sm" data-env="undo">Undo</button>`
            : `<button class="btn ghost icon-btn sm danger" data-env="delete" title="Delete">${icon("trash")}</button>`}
        </span>
      </div>`;
  }

  function addedRow(a, index) {
    return `
      <div class="env-row added" data-env-new="${index}">
        ${typeSelect(a.secret, "data-env-new-type")}
        <span class="env-key"><input class="mono" value="${esc(a.key)}" placeholder="NEW_VARIABLE" data-env-new-key spellcheck="false" autocomplete="off"></span>
        <span class="env-value"><input class="mono" type="${a.secret && !a.show ? "password" : "text"}" value="${esc(a.value)}" placeholder="value" data-env-new-value spellcheck="false" autocomplete="off"></span>
        <span class="env-actions"><button class="btn ghost icon-btn sm danger" data-env="remove-new" title="Remove">${icon("x")}</button></span>
      </div>`;
  }

  function appliedNotice() {
    const actions = ed.options.afterSave?.(ed.saved) || [];
    return `<div class="notice ok">${icon("check")}<span>Saved ${esc(ed.saved.file)}. ${actions.length ? "Apply the new values:" : "New values are used the next time the app reads its environment."}</span>
      ${actions.map((a, i) => `<button class="btn sm ${i === 0 ? "primary" : ""}" data-env-apply="${i}">${esc(a.label)}</button>`).join("")}
      <button class="btn ghost icon-btn sm" data-env="dismiss" title="Dismiss">${icon("x")}</button></div>`;
  }

  function changes() {
    const out = {};
    for (const key of ed.deleted) out[key] = null;
    for (const [key, value] of ed.edits) if (!ed.deleted.has(key)) out[key] = value;
    for (const a of ed.added) if (a.key.trim()) out[a.key.trim()] = a.value;
    return out;
  }

  function validate() {
    const existing = new Set(ed.data.variables.map((v) => v.key));
    const seen = new Set();
    for (const a of ed.added) {
      const key = a.key.trim();
      if (!key) continue;
      if (!KEY_RE.test(key)) return `“${key}” isn't a valid name — use letters, numbers and _ (not starting with a number).`;
      if ((existing.has(key) && !ed.deleted.has(key)) || seen.has(key)) return `${key} is already defined.`;
      seen.add(key);
    }
    return "";
  }

  async function save() {
    const problem = validate();
    if (problem) return toast("error", problem);
    const typed = ed.added.filter((a) => a.key.trim() && a.secret !== null);
    ed.saving = true;
    render();
    try {
      const data = await LD.call("env_save", { ...ed.target, file: ed.data.file, changes: changes(), hash: ed.data.hash });
      for (const a of typed) {
        // Remember the type picked for new variables when it differs from the guess.
        const guessed = data.variables.find((v) => v.key === a.key.trim())?.secret;
        if (guessed !== undefined && guessed !== a.secret) await setType(data.scope, a.key.trim(), a.secret, data);
      }
      Object.assign(ed, { data, edits: new Map(), deleted: new Set(), added: [], saving: false, saved: data });
      toast("success", `${data.file} saved`);
    } catch (err) {
      ed.saving = false;
      toast("error", "Couldn't save", err.message);
    }
    render();
  }

  async function setType(scope, key, secret, data = ed.data) {
    await LD.call("env_type", { scope, key, secret });
    const variable = data.variables.find((v) => v.key === key);
    if (variable) variable.secret = secret;
  }

  function importModal() {
    openModal(`
      <form class="modal" id="env-import-form">
        <div class="modal-header"><h2>Import variables</h2><p>Paste the contents of an .env file. Existing names are overwritten; nothing is saved until you press Save.</p></div>
        <div class="modal-body">
          <textarea name="text" class="mono env-import" rows="12" spellcheck="false" placeholder="APP_NAME=Shop&#10;DB_HOST=127.0.0.1&#10;STRIPE_SECRET=sk_live_…"></textarea>
        </div>
        <div class="modal-footer"><button type="button" class="btn" data-dismiss>Cancel</button><button type="submit" class="btn primary">${icon("upload")}Import</button></div>
      </form>`, (root) => {
      const form = $("#env-import-form", root);
      setTimeout(() => form.elements.text.focus(), 40);
      $("[data-dismiss]", form).addEventListener("click", closeModal);
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const pairs = await LD.call("env_parse", { text: form.elements.text.value });
          if (!pairs.length) return toast("error", "No KEY=value lines found");
          mergePairs(pairs);
          closeModal();
          toast("success", `${pairs.length} variable${pairs.length > 1 ? "s" : ""} staged`, "Review them, then press Save.");
        } catch (err) {
          toast("error", "Couldn't import", err.message);
        }
      });
    });
  }

  async function compareServerModal() {
    if (!ed.target.name) {
      toast("info", "Only available for local projects");
      return;
    }
    const servers = state.servers || [];
    if (!servers.length) {
      toast("info", "No servers configured", "Add a remote server in the Servers tab first.");
      return;
    }

    openModal(`
      <div class="modal" style="max-width:750px">
        <div class="modal-header">
          <h2>${icon("refresh")} Compare Local .env with Server</h2>
          <p>Compare local environment variables against a remote server. Secrets are masked by default.</p>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <div style="display:flex;gap:8px;align-items:center">
            <label style="font-size:12px;font-weight:600">Remote Server:</label>
            <select id="diff-server-select" class="select sm" style="flex:1">
              ${servers.map((s) => `<option value="${esc(s.id)}">${esc(s.name || s.host)} (${esc(s.host)})</option>`).join("")}
            </select>
            <button class="btn sm primary" id="btn-run-env-diff">${icon("refresh")} Compare</button>
          </div>
          <div id="diff-results-pane" style="max-height:55vh;overflow-y:auto">
            <div class="muted sm" style="padding:20px;text-align:center">Click Compare to fetch remote .env and analyze differences</div>
          </div>
        </div>
        <div class="modal-footer"><button type="button" class="btn primary" data-dismiss>Close</button></div>
      </div>`, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);
      $("#btn-run-env-diff", root)?.addEventListener("click", async () => {
        const sId = $("#diff-server-select", root)?.value;
        const pane = $("#diff-results-pane", root);
        if (!pane) return;
        pane.innerHTML = `<div class="loading-pane">${icon("pulse")} Connecting to server and comparing .env…</div>`;

        try {
          const res = await LD.call("env_diff_server", { name: ed.target.name, server_id: sId });
          if (!res.ok) throw new Error(res.error || "Failed to compare env");

          const keys = res.keys || [];
          pane.innerHTML = `
            <div style="display:flex;gap:8px;margin-bottom:10px;font-size:12px;flex-wrap:wrap">
              <span class="chip sm">${res.identical} Identical</span>
              <span class="chip sm ${res.different > 0 ? 'text-amber' : ''}">${res.different} Differing</span>
              <span class="chip sm ${res.local_only > 0 ? 'text-blue' : ''}">${res.local_only} Local only</span>
              <span class="chip sm ${res.remote_only > 0 ? 'text-red' : ''}">${res.remote_only} Server only</span>
            </div>
            <div class="routes-table-wrap">
              <table class="routes-table" style="font-size:12px">
                <thead><tr><th>Variable</th><th>Status</th><th>Local Value</th><th>Server Value</th></tr></thead>
                <tbody>
                  ${keys.map((k) => {
                    const statusCls = k.status === 'identical' ? 'muted' : (k.status === 'different' ? 'text-amber' : (k.status === 'local_only' ? 'text-blue' : 'text-red'));
                    return `
                      <tr>
                        <td><b style="font-family:var(--mono);font-size:11.5px">${esc(k.key)}</b></td>
                        <td><span class="chip xs ${statusCls}">${esc(k.status)}</span></td>
                        <td><span class="mono" style="font-size:11.5px">${esc(k.local_val ?? '—')}</span></td>
                        <td><span class="mono" style="font-size:11.5px">${esc(k.remote_val ?? '—')}</span></td>
                      </tr>
                    `;
                  }).join("")}
                </tbody>
              </table>
            </div>
          `;
        } catch (err) {
          pane.innerHTML = `<div style="padding:16px;color:var(--red)">${esc(err.message)}</div>`;
        }
      });
    });
  }

  async function diffInspectorModal() {
    if (!ed.target.name) {
      toast("info", "Only available for local projects");
      return;
    }
    const files = ed.data.files || [".env", ".env.example"];
    const fileA = ed.data.file || ".env";
    const fileB = files.includes(".env.example") ? ".env.example" : (files.find((f) => f !== fileA) || ".env.example");

    openModal(`
      <div class="modal" style="max-width:820px">
        <div class="modal-header">
          <h2>${icon("code")} Environment Diff Inspector</h2>
          <p>Compare two environment files side-by-side to find missing keys, drifted values, or uncommitted secrets.</p>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:6px">
              <span style="font-size:12px;font-weight:600">File A (Current):</span>
              <select id="diff-file-a" class="select sm">
                ${files.map((f) => `<option value="${esc(f)}" ${f === fileA ? "selected" : ""}>${esc(f)}</option>`).join("")}
              </select>
            </div>
            <div style="display:flex;align-items:center;gap:6px">
              <span style="font-size:12px;font-weight:600">File B (Comparison):</span>
              <select id="diff-file-b" class="select sm">
                ${files.concat(files.includes(".env.example") ? [] : [".env.example"]).map((f) => `<option value="${esc(f)}" ${f === fileB ? "selected" : ""}>${esc(f)}</option>`).join("")}
              </select>
            </div>
            <button class="btn sm primary" id="btn-run-file-diff">${icon("refresh")} Compare</button>
            <span class="spacer"></span>
            <input type="text" id="diff-filter-input" placeholder="Filter keys..." class="input sm" style="width:160px;display:none" autocomplete="off">
          </div>
          <div id="file-diff-results-pane" style="max-height:55vh;overflow-y:auto">
            <div class="muted sm" style="padding:30px;text-align:center">Click <b>Compare</b> to inspect differences between the selected files.</div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn sm" id="btn-sync-missing" style="display:none">${icon("plus")} Import Missing into Editor</button>
          <span class="spacer"></span>
          <button type="button" class="btn primary sm" data-dismiss>Close</button>
        </div>
      </div>`, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      let lastDiffData = null;

      function renderDiffTable(filterText = "") {
        const pane = $("#file-diff-results-pane", root);
        if (!pane || !lastDiffData) return;
        const q = filterText.toLowerCase().trim();
        const items = (lastDiffData.items || []).filter((item) => !q || item.key.toLowerCase().includes(q));

        pane.innerHTML = `
          <div style="display:flex;gap:8px;margin-bottom:12px;font-size:12px;flex-wrap:wrap">
            <span class="chip sm text-green">${lastDiffData.identical_count || 0} Identical</span>
            <span class="chip sm ${lastDiffData.changed_count > 0 ? "text-amber" : ""}">${lastDiffData.changed_count || 0} Changed</span>
            <span class="chip sm ${lastDiffData.added_count > 0 ? "text-blue" : ""}">${lastDiffData.added_count || 0} Added in File B</span>
            <span class="chip sm ${lastDiffData.removed_count > 0 ? "text-red" : ""}">${lastDiffData.removed_count || 0} Only in File A</span>
          </div>
          <div class="routes-table-wrap">
            <table class="routes-table" style="font-size:12px">
              <thead><tr><th>Variable</th><th>Status</th><th>${esc(lastDiffData.file_a)}</th><th>${esc(lastDiffData.file_b)}</th></tr></thead>
              <tbody>
                ${items.map((it) => {
                  const statusCls = it.status === "same" ? "muted" : (it.status === "changed" ? "text-amber" : (it.status === "added" ? "text-blue" : "text-red"));
                  const badgeLabel = it.status === "same" ? "identical" : (it.status === "added" ? "in B only" : (it.status === "removed" ? "in A only" : "changed"));
                  return `
                    <tr>
                      <td><b style="font-family:var(--mono);font-size:11.5px">${esc(it.key)}</b></td>
                      <td><span class="chip xs ${statusCls}">${badgeLabel}</span></td>
                      <td><span class="mono" style="font-size:11.5px;max-width:220px;overflow:hidden;text-overflow:ellipsis;display:inline-block">${esc(it.val_a ?? "—")}</span></td>
                      <td><span class="mono" style="font-size:11.5px;max-width:220px;overflow:hidden;text-overflow:ellipsis;display:inline-block">${esc(it.val_b ?? "—")}</span></td>
                    </tr>
                  `;
                }).join("")}
              </tbody>
            </table>
          </div>
        `;
      }

      $("#diff-filter-input", root)?.addEventListener("input", (e) => {
        renderDiffTable(e.target.value);
      });

      $("#btn-run-file-diff", root)?.addEventListener("click", async () => {
        const fileA = $("#diff-file-a", root)?.value || ".env";
        const fileB = $("#diff-file-b", root)?.value || ".env.example";
        const pane = $("#file-diff-results-pane", root);
        if (!pane) return;
        pane.innerHTML = `<div class="loading-pane">${icon("pulse")} Comparing ${esc(fileA)} and ${esc(fileB)}…</div>`;

        try {
          const res = await LD.call("env_compare_files", { name: ed.target.name, file_a: fileA, file_b: fileB });
          if (!res.ok) throw new Error(res.error || "Failed to compare environment files");
          lastDiffData = res;
          $("#diff-filter-input", root).style.display = "block";
          if (res.added && res.added.length > 0) {
            const btnSync = $("#btn-sync-missing", root);
            if (btnSync) {
              btnSync.style.display = "inline-flex";
              btnSync.textContent = `Import ${res.added.length} Missing from ${fileB}`;
            }
          }
          renderDiffTable();
        } catch (err) {
          pane.innerHTML = `<div style="padding:16px;color:var(--red)">${esc(err.message)}</div>`;
        }
      });

      $("#btn-sync-missing", root)?.addEventListener("click", () => {
        if (!lastDiffData || !lastDiffData.added || !lastDiffData.added.length) return;
        const pairs = lastDiffData.added.map((it) => ({ key: it.key, value: it.val_b || "" }));
        mergePairs(pairs);
        closeModal();
        toast("success", `Imported ${pairs.length} variables from ${lastDiffData.file_b}`, "Review and save your changes.");
      });
    });
  }

  async function vaultModal() {
    if (!ed.target.name) {
      toast("info", "Only available for local projects");
      return;
    }

    openModal(`
      <div class="modal" style="max-width:680px">
        <div class="modal-header">
          <h2>${icon("lock")} Laravel Environment Vault</h2>
          <p>Encrypt your .env file into source-controllable .env.encrypted or decrypt it back using Laravel's native encryption.</p>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:16px">
          <!-- Encrypt Section -->
          <div class="card" style="padding:14px;display:flex;flex-direction:column;gap:10px">
            <div style="display:flex;align-items:center;justify-content:space-between">
              <div>
                <b style="font-size:13.5px">${icon("lock")} Encrypt Environment</b>
                <p class="muted sm" style="margin:2px 0 0">Generates <code>.env.encrypted</code> and prints your secret decryption key.</p>
              </div>
              <div style="display:flex;align-items:center;gap:6px">
                <select id="vault-cipher" class="select sm">
                  <option value="AES-256-CBC" selected>AES-256-CBC (Default)</option>
                  <option value="AES-128-CBC">AES-128-CBC</option>
                </select>
                <button class="btn sm primary" id="btn-vault-encrypt">${icon("lock")} Encrypt .env</button>
              </div>
            </div>
            <div id="vault-encrypt-result" style="display:none;padding:10px;background:var(--surface-2);border-radius:6px;border:1px solid var(--border)">
              <div style="font-size:12px;font-weight:600;color:var(--green);margin-bottom:6px">✓ Successfully Encrypted!</div>
              <div style="font-size:12px;margin-bottom:6px">Decryption Key:</div>
              <div style="display:flex;gap:6px;align-items:center">
                <input type="text" id="vault-generated-key" class="input sm mono" readonly style="flex:1">
                <button class="btn sm" id="btn-copy-vault-key">${icon("copy")} Copy</button>
              </div>
              <p class="muted xs" style="margin:8px 0 0;color:var(--amber)">⚠️ Store this key safely (e.g., 1Password, Bitwarden, or GitHub Secrets). Without it, your .env cannot be recovered.</p>
            </div>
          </div>

          <!-- Decrypt Section -->
          <div class="card" style="padding:14px;display:flex;flex-direction:column;gap:10px">
            <div>
              <b style="font-size:13.5px">${icon("unlock")} Decrypt Environment</b>
              <p class="muted sm" style="margin:2px 0 0">Restores <code>.env</code> from <code>.env.encrypted</code> using your encryption key.</p>
            </div>
            <div style="display:flex;gap:8px;align-items:center">
              <input type="text" id="vault-decrypt-key" placeholder="Enter base64:... decryption key" class="input sm mono" style="flex:1" autocomplete="off">
              <button class="btn sm" id="btn-vault-decrypt">${icon("unlock")} Decrypt .env</button>
            </div>
            <div id="vault-decrypt-msg" style="display:none;font-size:12px"></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn primary sm" data-dismiss>Close</button>
        </div>
      </div>`, (root) => {
      $("[data-dismiss]", root)?.addEventListener("click", closeModal);

      $("#btn-vault-encrypt", root)?.addEventListener("click", async () => {
        const cipher = $("#vault-cipher", root)?.value || "AES-256-CBC";
        const btn = $("#btn-vault-encrypt", root);
        btn.disabled = true;
        btn.innerHTML = `${icon("pulse")} Encrypting…`;

        try {
          const res = await LD.call("env_encrypt", { name: ed.target.name, cipher });
          if (!res.ok) throw new Error(res.error || "Encryption failed");

          const resBox = $("#vault-encrypt-result", root);
          const keyInput = $("#vault-generated-key", root);
          if (resBox && keyInput) {
            resBox.style.display = "block";
            keyInput.value = res.key || "";
          }
          toast("success", ".env encrypted successfully", "A new .env.encrypted file was created.");
        } catch (err) {
          toast("error", "Encryption failed", err.message);
        } finally {
          btn.disabled = false;
          btn.innerHTML = `${icon("lock")} Encrypt .env`;
        }
      });

      $("#btn-copy-vault-key", root)?.addEventListener("click", () => {
        const k = $("#vault-generated-key", root)?.value;
        if (k) copyText(k);
      });

      $("#btn-vault-decrypt", root)?.addEventListener("click", async () => {
        const key = $("#vault-decrypt-key", root)?.value.trim();
        if (!key) return toast("error", "Please provide the decryption key");

        const btn = $("#btn-vault-decrypt", root);
        const msg = $("#vault-decrypt-msg", root);
        btn.disabled = true;
        btn.innerHTML = `${icon("pulse")} Decrypting…`;

        try {
          const res = await LD.call("env_decrypt", { name: ed.target.name, key });
          if (!res.ok) throw new Error(res.error || "Decryption failed");

          if (msg) {
            msg.style.display = "block";
            msg.style.color = "var(--green)";
            msg.textContent = "✓ .env successfully decrypted and restored!";
          }
          toast("success", "Decrypted successfully", ".env has been restored.");
          load(ed.target.file || "");
        } catch (err) {
          if (msg) {
            msg.style.display = "block";
            msg.style.color = "var(--red)";
            msg.textContent = `✗ ${err.message}`;
          }
          toast("error", "Decryption failed", err.message);
        } finally {
          btn.disabled = false;
          btn.innerHTML = `${icon("unlock")} Decrypt .env`;
        }
      });
    });
  }

  function mergePairs(pairs) {
    const existing = new Map(ed.data.variables.map((v) => [v.key, v]));
    for (const { key, value } of pairs) {
      if (existing.has(key)) {
        ed.deleted.delete(key);
        if (existing.get(key).value !== value) ed.edits.set(key, value);
      } else {
        const added = ed.added.find((a) => a.key === key);
        if (added) added.value = value;
        else ed.added.push({ key, value, secret: guessSecret(key) });
      }
    }
    render();
  }

  function guessSecret(key) {
    if (/^(NEXT_PUBLIC_|NUXT_PUBLIC_|VITE_|PUBLIC_|REACT_APP_)/.test(key)) return false;
    return /(PASS|SECRET|TOKEN|KEY|PRIVATE|CREDENTIAL|AUTH|DSN|SALT)/i.test(key) && !/(_ID|_HOST|_PORT|_URL|_NAME)$/i.test(key);
  }

  /* ── events ── */
  document.addEventListener("click", async (e) => {
    if (!isMounted() || !ed.el.contains(e.target)) return;
    const btn = e.target.closest("[data-env], [data-env-apply]");
    if (!btn) return;
    if (btn.dataset.envApply !== undefined) {
      const actions = ed.options.afterSave?.(ed.saved) || [];
      const action = actions[+btn.dataset.envApply];
      ed.saved = null;
      render();
      return action?.run();
    }
    const row = btn.closest("[data-env-key]");
    const key = row?.dataset.envKey;
    const variable = key ? ed.data.variables.find((v) => v.key === key) : null;
    switch (btn.dataset.env) {
      case "reload": return load(ed.target.file || "");
      case "add":
        ed.added.unshift({ key: "", value: "", secret: false });
        render();
        return $("[data-env-new-key]", ed.el)?.focus();
      case "remove-new": ed.added.splice(+btn.closest("[data-env-new]").dataset.envNew, 1); return render();
      case "delete": ed.deleted.add(key); return render();
      case "undo": ed.deleted.delete(key); return render();
      case "reveal": ed.reveal.has(key) ? ed.reveal.delete(key) : ed.reveal.add(key); return render();
      case "copy": return copyText(ed.edits.has(key) ? ed.edits.get(key) : variable?.value ?? "");
      case "copy-all":
        return copyText(ed.data.variables.map((v) => `${v.key}=${/[\s#"'$]/.test(v.value) ? JSON.stringify(v.value) : v.value}`).join("\n"));
      case "import": return importModal();
      case "diff-inspector": return diffInspectorModal();
      case "vault": return vaultModal();
      case "compare-server": return compareServerModal();
      case "add-missing": mergePairs(ed.data.missing); return;
      case "discard": Object.assign(ed, { edits: new Map(), deleted: new Set(), added: [] }); return render();
      case "save": return save();
      case "dismiss": ed.saved = null; return render();
    }
  });

  document.addEventListener("input", (e) => {
    if (!isMounted() || !ed.el.contains(e.target)) return;
    const t = e.target;
    if (t.matches("[data-env-filter]")) {
      ed.filter = t.value;
      const pos = t.selectionStart;
      render();
      const input = $("[data-env-filter]", ed.el);
      input.focus();
      input.setSelectionRange(pos, pos);
      return;
    }
    if (t.matches("[data-env-value]")) {
      const key = t.closest("[data-env-key]").dataset.envKey;
      const original = ed.data.variables.find((v) => v.key === key)?.value;
      t.value === original ? ed.edits.delete(key) : ed.edits.set(key, t.value);
      t.closest(".env-row").classList.toggle("edited", ed.edits.has(key));
      return updateSavebar();
    }
    const added = t.closest("[data-env-new]");
    if (added) {
      const item = ed.added[+added.dataset.envNew];
      if (t.matches("[data-env-new-key]")) {
        item.key = t.value.replace(/\s+/g, "_");
        if (item.key !== t.value) t.value = item.key;
        if (item.secret === false && guessSecret(item.key)) {
          item.secret = true;
          const select = $("[data-env-new-type]", added);
          select.value = "secret";
          select.classList.add("secret");
          $("[data-env-new-value]", added).type = "password";
        }
      }
      if (t.matches("[data-env-new-value]")) item.value = t.value;
      updateSavebar();
    }
  });

  document.addEventListener("change", async (e) => {
    if (!isMounted() || !ed.el.contains(e.target)) return;
    const t = e.target;
    if (t.matches("[data-env-file]")) {
      if (dirtyCount() && !(await confirmModal({ title: "Discard changes?", message: "You have unsaved changes in this file.", confirm: "Discard", danger: true }))) {
        t.value = ed.data.file;
        return;
      }
      if (t.value === "__new") {
        const name = await promptModal("New environment file", "File name", ".env.production");
        if (!name || !/^\.env(\.[A-Za-z0-9_.-]+)?$/.test(name)) { t.value = ed.data.file; return; }
        ed.target = { ...ed.target, file: name };
        return load(name);
      }
      ed.target = { ...ed.target, file: t.value };
      return load(t.value);
    }
    if (t.matches("[data-env-type]")) {
      const key = t.closest("[data-env-key]").dataset.envKey;
      await setType(ed.data.scope, key, t.value === "secret");
      ed.reveal.delete(key);
      return render();
    }
    if (t.matches("[data-env-new-type]")) {
      const item = ed.added[+t.closest("[data-env-new]").dataset.envNew];
      item.secret = t.value === "secret";
      return render();
    }
  });

  document.addEventListener("keydown", (e) => {
    if (!isMounted() || !ed.el.contains(e.target)) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
      e.preventDefault();
      if (dirtyCount()) save();
    }
  });

  function updateSavebar() {
    const bar = $(".env-savebar", ed.el);
    if (!bar) return;
    const count = dirtyCount();
    bar.classList.toggle("show", count > 0);
    $("b", bar).textContent = count;
    bar.querySelector("span").lastChild.textContent = ` unsaved change${count === 1 ? "" : "s"}`;
  }

  return {
    mount,
    dirty: () => (isMounted() ? dirtyCount() : 0),
  };
})();
window.EnvEditor = EnvEditor;
