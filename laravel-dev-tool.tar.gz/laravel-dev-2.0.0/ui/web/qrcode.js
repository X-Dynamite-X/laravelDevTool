// Minimal zero-dependency QR code SVG generator for URLs and local network sharing
(function() {
  const GF256_EXP = new Uint8Array(512);
  const GF256_LOG = new Uint8Array(256);
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF256_EXP[i] = x;
    GF256_EXP[i + 255] = x;
    GF256_LOG[x] = i;
    x <<= 1;
    if (x & 256) x ^= 0x11d;
  }

  function gfMul(x, y) {
    if (x === 0 || y === 0) return 0;
    return GF256_EXP[GF256_LOG[x] + GF256_LOG[y]];
  }

  function rsPoly(n) {
    let poly = [1];
    for (let i = 0; i < n; i++) {
      const next = new Array(poly.length + 1).fill(0);
      for (let j = 0; j < poly.length; j++) {
        next[j] ^= gfMul(poly[j], GF256_EXP[i]);
        next[j + 1] ^= poly[j];
      }
      poly = next;
    }
    return poly;
  }

  function rsEncode(data, ecLen) {
    const poly = rsPoly(ecLen);
    const res = new Uint8Array(ecLen);
    for (let i = 0; i < data.length; i++) {
      const m = data[i] ^ res[0];
      for (let j = 0; j < ecLen - 1; j++) {
        res[j] = res[j + 1] ^ gfMul(poly[poly.length - 2 - j], m);
      }
      res[ecLen - 1] = gfMul(poly[0], m);
    }
    return res;
  }

  const VERSIONS = [
    null,
    { ver: 1, size: 21, dataCap: 19, ecCount: 7, blocks: 1, align: [] },
    { ver: 2, size: 25, dataCap: 34, ecCount: 10, blocks: 1, align: [6, 18] },
    { ver: 3, size: 29, dataCap: 55, ecCount: 15, blocks: 1, align: [6, 22] },
    { ver: 4, size: 33, dataCap: 80, ecCount: 20, blocks: 1, align: [6, 26] },
    { ver: 5, size: 37, dataCap: 108, ecCount: 26, blocks: 1, align: [6, 30] },
    { ver: 6, size: 41, dataCap: 136, ecCount: 18, blocks: 2, align: [6, 34] },
  ];

  function getVersion(dataLen) {
    const needed = dataLen + 2;
    for (let v = 1; v <= 6; v++) {
      if (needed <= VERSIONS[v].dataCap) return VERSIONS[v];
    }
    return VERSIONS[6];
  }

  function createQR(text) {
    const utf8 = new TextEncoder().encode(text);
    const v = getVersion(utf8.length);
    const totalData = v.dataCap;

    const bits = [];
    function put(val, len) {
      for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1);
    }

    put(0b0100, 4); // Byte mode
    put(utf8.length, 8);
    for (let b of utf8) put(b, 8);
    put(0, Math.min(4, totalData * 8 - bits.length));
    while (bits.length % 8 !== 0) bits.push(0);

    const padBytes = [0xec, 0x11];
    let padIdx = 0;
    while (bits.length < totalData * 8) {
      put(padBytes[padIdx % 2], 8);
      padIdx++;
    }

    const dataBytes = new Uint8Array(totalData);
    for (let i = 0; i < totalData; i++) {
      let b = 0;
      for (let j = 0; j < 8; j++) b = (b << 1) | bits[i * 8 + j];
      dataBytes[i] = b;
    }

    let finalBytes = [];
    if (v.blocks === 1) {
      const ec = rsEncode(dataBytes, v.ecCount);
      finalBytes = [...dataBytes, ...ec];
    } else {
      const b1Len = Math.floor(dataBytes.length / 2);
      const b1Data = dataBytes.slice(0, b1Len);
      const b2Data = dataBytes.slice(b1Len);
      const ec1 = rsEncode(b1Data, v.ecCount);
      const ec2 = rsEncode(b2Data, v.ecCount);
      for (let i = 0; i < b1Len; i++) {
        finalBytes.push(b1Data[i]);
        finalBytes.push(b2Data[i]);
      }
      for (let i = 0; i < v.ecCount; i++) {
        finalBytes.push(ec1[i]);
        finalBytes.push(ec2[i]);
      }
    }

    const S = v.size;
    const mat = Array.from({ length: S }, () => new Int8Array(S).fill(-1));
    const reserved = Array.from({ length: S }, () => new Uint8Array(S));

    function setMod(r, c, val) {
      mat[r][c] = val ? 1 : 0;
      reserved[r][c] = 1;
    }

    function finder(row, col) {
      for (let r = -1; r <= 7; r++) {
        for (let c = -1; c <= 7; c++) {
          const nr = row + r, nc = col + c;
          if (nr < 0 || nr >= S || nc < 0 || nc >= S) continue;
          if (r >= 0 && r <= 6 && c >= 0 && c <= 6) {
            if (r === 0 || r === 6 || c === 0 || c === 6 || (r >= 2 && r <= 4 && c >= 2 && c <= 4)) {
              setMod(nr, nc, 1);
            } else {
              setMod(nr, nc, 0);
            }
          } else {
            setMod(nr, nc, 0);
          }
        }
      }
    }
    finder(0, 0);
    finder(0, S - 7);
    finder(S - 7, 0);

    if (v.align.length) {
      const coords = v.align;
      for (let r of coords) {
        for (let c of coords) {
          if (reserved[r][c]) continue;
          for (let dr = -2; dr <= 2; dr++) {
            for (let dc = -2; dc <= 2; dc++) {
              const dark = dr === -2 || dr === 2 || dc === -2 || dc === 2 || (dr === 0 && dc === 0);
              setMod(r + dr, c + dc, dark ? 1 : 0);
            }
          }
        }
      }
    }

    for (let i = 8; i < S - 8; i++) {
      if (!reserved[6][i]) setMod(6, i, i % 2 === 0 ? 1 : 0);
      if (!reserved[i][6]) setMod(i, 6, i % 2 === 0 ? 1 : 0);
    }

    setMod(4 * v.ver + 9, 8, 1);

    const formatBits = 0b111011111000100;
    for (let i = 0; i < 15; i++) {
      const bit = (formatBits >>> (14 - i)) & 1;
      if (i < 6) setMod(8, i, bit);
      else if (i < 8) setMod(8, i + 1, bit);
      else setMod(14 - i, 8, bit);

      if (i < 8) setMod(S - 1 - i, 8, bit);
      else setMod(8, S - 15 + i, bit);
    }

    let bitIdx = 0;
    const allBits = [];
    for (let b of finalBytes) {
      for (let i = 7; i >= 0; i--) allBits.push((b >>> i) & 1);
    }

    let upwards = true;
    for (let right = S - 1; right > 0; right -= 2) {
      if (right === 6) right--;
      const rows = upwards ? Array.from({ length: S }, (_, i) => S - 1 - i) : Array.from({ length: S }, (_, i) => i);
      for (let row of rows) {
        for (let col of [right, right - 1]) {
          if (!reserved[row][col]) {
            const rawBit = bitIdx < allBits.length ? allBits[bitIdx++] : 0;
            const mask = (row + col) % 2 === 0;
            mat[row][col] = rawBit ^ (mask ? 1 : 0);
          }
        }
      }
      upwards = !upwards;
    }

    return { size: S, matrix: mat };
  }

  function generateSVG(text, size) {
    const s = size || 180;
    const { size: S, matrix } = createQR(text);
    const border = 2;
    const total = S + border * 2;
    let path = "";
    for (let r = 0; r < S; r++) {
      for (let c = 0; c < S; c++) {
        if (matrix[r][c] === 1) {
          path += `M${c + border},${r + border}h1v1h-1z`;
        }
      }
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${total} ${total}" width="${s}" height="${s}" style="border-radius:8px;background:#ffffff;padding:8px;box-shadow:var(--shadow)">
      <path d="${path}" fill="#0f172a"/>
    </svg>`;
  }

  const qr = { createQR, generateSVG };
  if (typeof module !== "undefined") module.exports = qr;
  else if (typeof window !== "undefined") window.QRCode = qr;
})();

