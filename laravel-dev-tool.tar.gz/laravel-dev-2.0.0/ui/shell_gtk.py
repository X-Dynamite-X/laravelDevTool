"""Linux window: GTK + WebKitGTK, with a tray icon when AppIndicator is available.

The interface talks to Backend through a WebKit script-message bridge, so
there is no HTTP server and no open port.
"""

import os
import re
import sys
import threading

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
try:
    gi.require_version("WebKit2", "4.1")
except ValueError:
    gi.require_version("WebKit2", "4.0")
from gi.repository import Gdk, Gio, GLib, Gtk, WebKit2  # noqa: E402

try:
    gi.require_version("AyatanaAppIndicator3", "0.1")
    from gi.repository import AyatanaAppIndicator3 as AppIndicator
except (ImportError, ValueError):
    try:
        gi.require_version("AppIndicator3", "0.1")
        from gi.repository import AppIndicator3 as AppIndicator
    except (ImportError, ValueError):
        AppIndicator = None

import osutil  # noqa: E402
import sites  # noqa: E402
from backend import Backend  # noqa: E402
from sites import BASE_DIR, UI_DIR  # noqa: E402

APP_ID = "dev.laravel.LaravelDev"
DIALOG_ACTIONS = {"folder": Gtk.FileChooserAction.SELECT_FOLDER, "open": Gtk.FileChooserAction.OPEN,
                  "save": Gtk.FileChooserAction.SAVE}


class GtkShell(Gtk.Application):
    def __init__(self, start_hidden=False):
        super().__init__(application_id=APP_ID)
        self.start_hidden = start_hidden
        self.window = None
        self.webview = None
        self.indicator = None
        self.tray_sites_menu = None
        self.dialogs = set()
        self.has_tray = AppIndicator is not None
        self.backend = Backend(self)

    # shell interface used by Backend
    def post(self, fn, *args):
        def _call():
            try:
                fn(*args)
            except Exception as e:
                print("Error in post callback:", e)
            return False
        GLib.idle_add(_call)

    def eval_js(self, script):
        if self.webview is None:
            return
        def _exec():
            if self.webview is None:
                return False
            def on_js_done(view, result, *u):
                try:
                    view.run_javascript_finish(result)
                except Exception as e:
                    print(f"[SHELL_GTK] JS execution error: {e}")
            try:
                self.webview.run_javascript(script, None, on_js_done)
            except Exception as e:
                print(f"[SHELL_GTK] eval_js run_javascript error: {e}")
            return False
        GLib.idle_add(_exec)

    def is_active(self):
        return bool(self.window and self.window.is_active())

    def notify(self, title, body, task_id=""):
        try:
            note = Gio.Notification.new(title)
            note.set_body(body)
            self.send_notification(task_id or "laravel-dev", note)
        except Exception:
            osutil.send_desktop_notification(title, body)

    def choose(self, kind, title, done, start=None, multiple=False, name=None, accept="Select"):
        """Open a native file dialog without blocking; done(paths) gets a list (empty if cancelled)."""
        action = DIALOG_ACTIONS[kind]
        dialog = Gtk.FileChooserNative.new(title, self.window, action, accept, "Cancel")
        dialog.set_modal(True)
        dialog.set_select_multiple(multiple)
        if action == Gtk.FileChooserAction.SAVE:
            dialog.set_do_overwrite_confirmation(True)
            if name:
                dialog.set_current_name(name)
        if start and os.path.isdir(start):
            dialog.set_current_folder(start)
            if os.path.basename(start.rstrip("/")).startswith("."):
                dialog.set_show_hidden(True)

        def on_response(chooser, response):
            paths = list(chooser.get_filenames()) if response == Gtk.ResponseType.ACCEPT else []
            self.dialogs.discard(chooser)
            GLib.idle_add(chooser.destroy)
            done(paths)

        # File dialogs answer later, from their "response" signal: a blocking
        # dialog.run() inside the WebKit message callback loses the chosen path.
        def show():
            self.dialogs.add(dialog)  # keep a reference until it answers
            dialog.connect("response", on_response)
            dialog.show()
            return False

        GLib.idle_add(show)

    # lifecycle
    def do_startup(self):
        Gtk.Application.do_startup(self)
        GLib.set_application_name("Laravel Dev")
        GLib.set_prgname("laravel-dev")
        self.hold()  # keep running in the tray when the window is hidden

    def do_activate(self):
        if self.window is None:
            self.build_window()
            self.build_tray()
            if self.start_hidden and self.indicator:
                return
        self.show_window()

    def show_window(self, *_):
        self.window.show_all()
        self.window.present()

    def quit_app(self, *_):
        self.backend.shutdown()
        self.release()
        self.quit()

    def build_window(self):
        self.window = Gtk.ApplicationWindow(application=self, title="Laravel Dev")
        self.window.set_default_size(1240, 780)
        self.window.set_size_request(860, 560)
        for icon in (BASE_DIR / "assets" / "laravel-dev.png", BASE_DIR / "assets" / "laravel-dev.svg"):
            if icon.is_file():
                try:
                    self.window.set_icon_from_file(str(icon))
                    break
                except GLib.Error:
                    pass
        self.window.connect("delete-event", self.on_close)

        # Memory: a local single-page UI needs no page cache, no disk cache and
        # no back/forward cache; this keeps WebKit's footprint small.
        context = WebKit2.WebContext.get_default()
        context.set_cache_model(WebKit2.CacheModel.DOCUMENT_VIEWER)

        content = WebKit2.UserContentManager()
        content.register_script_message_handler("ld")
        content.connect("script-message-received::ld", self.on_message)
        self.webview = WebKit2.WebView.new_with_user_content_manager(content)
        settings = self.webview.get_settings()
        debug = bool(os.environ.get("LARAVEL_DEV_DEBUG"))
        settings.set_enable_developer_extras(debug)
        settings.set_enable_write_console_messages_to_stdout(debug)
        settings.set_enable_page_cache(False)
        for setter in ("set_enable_webgl", "set_enable_media", "set_enable_webaudio", "set_enable_media_stream"):
            if hasattr(settings, setter):
                getattr(settings, setter)(False)
        self.webview.connect("decide-policy", self.on_decide_policy)
        self.webview.connect("context-menu", lambda *_: not debug)
        bg = Gdk.RGBA()
        bg.parse("#f6f6f7")
        self.webview.set_background_color(bg)
        self.webview.load_uri((UI_DIR / "web" / "index.html").as_uri())
        self.window.add(self.webview)

    def on_close(self, *_):
        if self.indicator and self.backend.prefs.get("close_to_tray", True):
            self.window.hide()
            return True
        self.quit_app()
        return True

    def on_decide_policy(self, _view, decision, kind):
        if kind in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            uri = decision.get_navigation_action().get_request().get_uri() or ""
            if kind == WebKit2.PolicyDecisionType.NAVIGATION_ACTION and (
                uri.startswith("file://")
                or uri in ("about:blank", "about:srcdoc")
                or uri.startswith("data:text/html")
            ):
                return False
            if re.match(r"^(https?://|mailto:)", uri):
                osutil.open_path(uri)
            decision.ignore()
            return True
        return False

    def on_message(self, _manager, result):
        value = result.get_js_value() if hasattr(result, "get_js_value") else result
        self.backend.handle(value.to_string())

    # tray
    def build_tray(self):
        if AppIndicator is None:
            return
        icon = BASE_DIR / "assets" / "laravel-dev.png"
        self.indicator = AppIndicator.Indicator.new(
            "laravel-dev", str(icon) if icon.is_file() else "laravel-dev",
            AppIndicator.IndicatorCategory.APPLICATION_STATUS,
        )
        self.indicator.set_title("Laravel Dev")
        self.indicator.set_status(AppIndicator.IndicatorStatus.ACTIVE)

        menu = Gtk.Menu()

        def item(label, callback):
            entry = Gtk.MenuItem(label=label)
            entry.connect("activate", callback)
            menu.append(entry)
            return entry

        item("Open Laravel Dev", self.show_window)
        menu.append(Gtk.SeparatorMenuItem())
        sites_item = Gtk.MenuItem(label="Sites")
        self.tray_sites_menu = Gtk.Menu()
        sites_item.set_submenu(self.tray_sites_menu)
        menu.append(sites_item)
        if sites.MANAGED:
            menu.append(Gtk.SeparatorMenuItem())
            item("Start services", lambda *_: self.backend.start_action("services", {"op": "start"}))
            item("Stop services", lambda *_: self.backend.start_action("services", {"op": "stop"}))
        menu.append(Gtk.SeparatorMenuItem())
        item("Quit", self.quit_app)
        menu.show_all()
        self.indicator.set_menu(menu)
        self.refresh_tray()

    def refresh_tray(self, site_list=None):
        if self.tray_sites_menu is None:
            return False
        if site_list is None:
            threading.Thread(target=lambda: GLib.idle_add(self.refresh_tray, sites.list_sites()), daemon=True).start()
            return False
        for child in self.tray_sites_menu.get_children():
            self.tray_sites_menu.remove(child)
        linked = [s for s in site_list if s["linked"] and s.get("url")]
        for site in linked:
            entry = Gtk.MenuItem(label=site["domain"])
            entry.connect("activate", lambda _w, url=site["url"]: osutil.open_path(url))
            self.tray_sites_menu.append(entry)
        if not linked:
            empty = Gtk.MenuItem(label="No sites yet")
            empty.set_sensitive(False)
            self.tray_sites_menu.append(empty)
        self.tray_sites_menu.show_all()
        return False


def run(start_hidden=False):
    return GtkShell(start_hidden=start_hidden).run([sys.argv[0]])
