"""Background tasks with live output for the Activity panel.

A task is a list of steps: commands, or Python functions that log as they go
(used where Windows/macOS have no shell script to run). On Linux and macOS
commands run on a pseudo-terminal so sudo can cache its credentials for the
whole command and tools print progress the way they do in a shell.
"""

import inspect
import os
import re
import subprocess
import threading
import time
import uuid

from osutil import IS_WINDOWS, NEW_GROUP, NO_WINDOW, terminate_tree

if not IS_WINDOWS:
    import fcntl
    import pty
    import struct
    import termios

ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(\x07|\x1b\\)|\x1b[()][A-Za-z0-9]|\x1b[=>]")
MAX_TASKS = 60


class TaskError(Exception):
    """Raised by Python steps to fail a task with a readable message."""


class Task:
    def __init__(self, title, site=None):
        self.id = uuid.uuid4().hex[:10]
        self.title = title
        self.site = site
        self.proc = None
        self.status = "running"
        self.code = None
        self.started = time.time()

    def summary(self):
        return {"id": self.id, "title": self.title, "status": self.status, "code": self.code,
                "started": self.started, "site": self.site}


class TaskRunner:
    def __init__(self, emit, post, base_env=None):
        """emit(event) talks to the UI; post(fn, *args) runs fn on the UI thread."""
        self.emit = emit
        self.post = post
        self.base_env = base_env or {}
        self.tasks = {}

    def start(self, title, argv, cwd=None, site=None, env_extra=None, stdin_data=None):
        return self.start_steps(title, [("run", argv, cwd, env_extra, stdin_data)], site)

    def start_steps(self, title, steps, site=None):
        """steps: ("run", argv, cwd, env, stdin) tuples or ("py", fn) where fn(log) may raise TaskError."""
        task = Task(title, site)
        self.tasks[task.id] = task
        self._prune()
        self.emit({"type": "task", "task": task.summary()})
        threading.Thread(target=self._work, args=(task, steps), daemon=True).start()
        return task

    def _prune(self):
        done = [t for t in self.tasks.values() if t.status != "running"]
        for task in sorted(done, key=lambda t: t.started)[:max(0, len(self.tasks) - MAX_TASKS)]:
            self.tasks.pop(task.id, None)

    def _out(self, task, text):
        text = ANSI_RE.sub("", text)
        if text:
            self.post(self.emit, {"type": "output", "id": task.id, "text": text})

    def _work(self, task, steps):
        code = 0
        for step in steps:
            if task.status != "running":
                break
            try:
                if step[0] == "py":
                    try:
                        sig = inspect.signature(step[1])
                        has_cancel = len(sig.parameters) >= 2
                    except Exception:
                        has_cancel = False
                    if has_cancel:
                        step[1](lambda text: self._out(task, text), lambda: task.status == "cancelled")
                    else:
                        step[1](lambda text: self._out(task, text))
                    code = 0
                else:
                    _, argv, cwd, env_extra, stdin_data = (*step, None, None, None, None)[:5]
                    code = self._run(task, argv, cwd, env_extra, stdin_data)
            except TaskError as exc:
                self._out(task, f"\n{exc}\n")
                code = 1
            except OSError as exc:
                self._out(task, f"\nCould not start {step[1][0] if step[0] == 'run' else 'step'}: {exc}\n")
                code = 1
            except Exception as exc:  # noqa: BLE001 — shown in Activity instead of dying silently
                self._out(task, f"\nError: {exc}\n")
                code = 1
            if code != 0:
                break
        task.code = code
        if task.status == "running":
            task.status = "success" if code == 0 else "error"
        if getattr(task, "on_done", None):
            try:
                task.on_done(task)
            except Exception:
                pass
        self.post(self.emit, {"type": "task", "task": task.summary(), "done": True})

    def _env(self, env_extra):
        env = dict(env_extra or os.environ)
        env.update(self.base_env)
        env.update({"GIT_TERMINAL_PROMPT": "0", "COMPOSER_NO_INTERACTION": "1", "NO_COLOR": "1", "TERM": "dumb"})
        return env

    def _run(self, task, argv, cwd, env_extra, stdin_data):
        env = self._env(env_extra)
        if IS_WINDOWS:
            task.proc = subprocess.Popen(
                argv, cwd=cwd, env=env, stdin=subprocess.PIPE if stdin_data else subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=NO_WINDOW | NEW_GROUP,
            )
            if stdin_data:
                task.proc.stdin.write(stdin_data)
                task.proc.stdin.close()
            for chunk in iter(lambda: task.proc.stdout.read1(8192), b""):
                self._out(task, chunk.decode("utf-8", errors="replace").replace("\r\n", "\n"))
            return task.proc.wait()

        master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 50, 140, 0, 0))
        if stdin_data:
            # Secrets (e.g. a sudo password) are typed into the terminal; never echo them.
            attrs = termios.tcgetattr(slave)
            attrs[3] &= ~termios.ECHO
            termios.tcsetattr(slave, termios.TCSANOW, attrs)

        def make_controlling_tty():
            os.setsid()
            fcntl.ioctl(0, termios.TIOCSCTTY, 0)

        try:
            task.proc = subprocess.Popen(argv, stdin=slave, stdout=slave, stderr=slave, cwd=cwd, env=env,
                                         preexec_fn=make_controlling_tty, close_fds=True)
        finally:
            os.close(slave)
        if stdin_data:
            os.write(master, stdin_data)
        while True:
            try:
                chunk = os.read(master, 8192)
            except OSError:
                break
            if not chunk:
                break
            self._out(task, chunk.decode("utf-8", errors="replace"))
        os.close(master)
        return task.proc.wait()

    def cancel(self, task_id):
        task = self.tasks.get(task_id)
        if task and task.status == "running":
            task.status = "cancelled"
            if task.proc and task.proc.poll() is None:
                terminate_tree(task.proc.pid)

    def running(self):
        return [t for t in self.tasks.values() if t.status == "running"]
