"""Interactive Notification & Email Studio Engine for Laravel Dev.

Scans `app/Notifications` and `app/Mail`, extracting supported delivery channels
(mail, database, slack, sms, webhook) and rendering interactive multi-channel previews.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any


def list_notifications(site_path: str) -> list[dict[str, Any]]:
    """Scan app/Notifications for all notification classes and their channels."""
    p = Path(site_path).resolve()
    notifs_dir = p / "app" / "Notifications"
    if not notifs_dir.is_dir():
        return []

    notifications = []
    for file in sorted(notifs_dir.rglob("*.php")):
        try:
            content = file.read_text(encoding="utf-8", errors="replace")
            # Extract class name
            m_class = re.search(r"class\s+([A-Za-z0-9_]+)", content)
            if not m_class:
                continue
            class_name = m_class.group(1)

            # Extract via channels: e.g. return ['mail', 'database', 'slack'];
            channels = []
            m_via = re.search(r"function\s+via\s*\([^)]*\)\s*(?::\s*array)?\s*\{([^}]+)\}", content, re.DOTALL)
            if m_via:
                via_body = m_via.group(1)
                found = re.findall(r"['\"]([a-zA-Z0-9_-]+)['\"]", via_body)
                for c in found:
                    c_clean = c.lower()
                    if c_clean in ("mail", "database", "broadcast", "slack", "sms", "vonage", "twilio", "webhook"):
                        if c_clean not in channels:
                            channels.append(c_clean)

            if not channels:
                channels = ["mail", "database"]

            rel_path = str(file.relative_to(p))
            notifications.append({
                "name": class_name,
                "relative_path": rel_path,
                "channels": channels,
                "has_mail": "mail" in channels or "toMail" in content,
                "has_database": "database" in channels or "toArray" in content or "toDatabase" in content,
                "has_slack": "slack" in channels or "toSlack" in content,
                "has_sms": any(x in channels for x in ("sms", "vonage", "twilio")) or "toSms" in content or "toVonage" in content,
            })
        except Exception:
            continue

    return notifications


def get_notification_preview(site_path: str, notif_name: str, channel: str = "mail") -> dict[str, Any]:
    """Generate mock preview payload for the specified notification channel."""
    p = Path(site_path).resolve()
    notif_file = p / "app" / "Notifications" / f"{notif_name}.php"
    content = ""
    if notif_file.is_file():
        content = notif_file.read_text(encoding="utf-8", errors="replace")

    title = re.sub(r"([A-Z])", r" \1", notif_name).strip()

    if channel == "sms":
        # Extract SMS body or fallback
        m_sms = re.search(r"->content\(\s*['\"]([^'\"]+)['\"]\s*\)", content) or re.search(r"->line\(\s*['\"]([^'\"]+)['\"]\s*\)", content)
        sms_text = m_sms.group(1) if m_sms else f"Security Alert: Your {notif_name} verification code is 482910. Valid for 10 minutes."
        return {
            "ok": True,
            "channel": "sms",
            "name": notif_name,
            "to": "+1 (555) 234-5678",
            "sender": "DEV-AUTH",
            "message": sms_text,
            "segments": 1,
            "character_count": len(sms_text),
        }

    if channel == "slack" or channel == "webhook":
        return {
            "ok": True,
            "channel": "slack",
            "name": notif_name,
            "webhook_url": "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX",
            "bot_name": "Laravel Dev Notifier",
            "bot_icon": "https://laravel.com/img/favicon/favicon-32x32.png",
            "color": "#3b82f6",
            "title": f":bell: Notification: {title}",
            "text": f"Event trigger `{notif_name}` executed for user #482",
            "fields": [
                {"title": "Environment", "value": "local (development)", "short": True},
                {"title": "Triggered At", "value": "2026-10-24 20:30:15 UTC", "short": True},
                {"title": "Notifiable Entity", "value": "App\\Models\\User (ID: 482)", "short": True},
                {"title": "Status", "value": "Dispatched", "short": True},
            ],
            "actions": [
                {"type": "button", "text": "View in Dashboard", "style": "primary"},
                {"type": "button", "text": "Acknowledge", "style": "default"},
            ],
        }

    if channel == "database":
        return {
            "ok": True,
            "channel": "database",
            "name": notif_name,
            "table": "notifications",
            "id": "e4b5f891-9872-4a11-8761-9c32b5f7e102",
            "type": f"App\\Notifications\\{notif_name}",
            "notifiable_type": "App\\Models\\User",
            "notifiable_id": 482,
            "data": {
                "message": f"{title} has been generated.",
                "action_url": f"http://localhost/notifications/view",
                "importance": "high",
                "timestamp": "2026-10-24T20:30:15Z",
            },
            "read_at": None,
            "created_at": "Just now",
        }

    # Default: mail channel
    subject = f"Notification: {title}"
    m_subj = re.search(r"->subject\(\s*['\"]([^'\"]+)['\"]\s*\)", content)
    if m_subj:
        subject = m_subj.group(1)

    html_preview = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #334155; margin: 0; padding: 24px; }}
    .email-wrapper {{ max-width: 580px; margin: 0 auto; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; }}
    .email-header {{ background: #0f172a; color: #ffffff; padding: 20px 24px; text-align: center; }}
    .email-header h1 {{ margin: 0; font-size: 18px; font-weight: 700; }}
    .email-body {{ padding: 28px 24px; line-height: 1.6; font-size: 15px; }}
    .btn-action {{ display: inline-block; background: #3b82f6; color: #ffffff; text-decoration: none; padding: 10px 22px; border-radius: 6px; font-weight: 600; margin: 20px 0; }}
    .email-footer {{ padding: 16px 24px; background: #f1f5f9; font-size: 12px; color: #64748b; text-align: center; }}
  </style>
</head>
<body>
  <div class="email-wrapper">
    <div class="email-header">
      <h1>Laravel Notification</h1>
    </div>
    <div class="email-body">
      <h2>Hello Ahmed,</h2>
      <p>This is a live preview of the <b>{notif_name}</b> notification.</p>
      <p>Your action is requested regarding the pending updates to your application environment.</p>
      <div style="text-align: center;">
        <a href="#" class="btn-action">Review Details</a>
      </div>
      <p>Thank you for using our application!<br>Regards,<br><b>Laravel Dev Team</b></p>
    </div>
    <div class="email-footer">
      If you're having trouble clicking the "Review Details" button, copy and paste the URL into your web browser.
    </div>
  </div>
</body>
</html>"""

    return {
        "ok": True,
        "channel": "mail",
        "name": notif_name,
        "subject": subject,
        "from": "notifications@laravel-dev.test",
        "to": "ahmed@example.com",
        "html": html_preview,
    }

