"""Saved Studio agent conversations, one JSON file per conversation.

<config>/studio/<site>/<conversation id>.json:
  {"id", "site", "title", "created_at", "updated_at", "agent_id", "agent",
   "session_id": Claude Code session to resume (or ""),
   "messages": [{"role": "user"|"agent", "text", "ts", "agent", "source", "files_changed"}]}
"""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from osutil import config_dir, private_dir, private_file
except ImportError:  # imported as ui.studio_history
    from ui.osutil import config_dir, private_dir, private_file

SITE_RE = re.compile(r"^[A-Za-z0-9._-]{1,128}$")
ID_RE = re.compile(r"^[a-f0-9]{12}$")
MAX_MESSAGES = 400        # oldest messages are dropped beyond this
MAX_TEXT = 200_000        # characters kept per message
CONTEXT_MESSAGES = 12     # previous messages replayed to agents that cannot resume a session
CONTEXT_CHARS = 12_000


def _root() -> Path:
    return Path(os.environ.get("LARAVEL_DEV_STUDIO_DIR") or (config_dir() / "studio"))


def _site_dir(site: str) -> Path:
    if not SITE_RE.fullmatch(site or "") or site in (".", ".."):
        raise ValueError("Invalid site name")
    return _root() / site


def _file(site: str, conv_id: str) -> Path:
    if not ID_RE.fullmatch(conv_id or ""):
        raise ValueError("Invalid conversation id")
    return _site_dir(site) / f"{conv_id}.json"


def _write(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    private_dir(path.parent)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    private_file(tmp)
    tmp.replace(path)  # atomic: a crash never leaves half a conversation


def _title_from(text: str) -> str:
    line = " ".join((text or "").split())
    return (line[:60] + "…") if len(line) > 60 else (line or "New conversation")


def create(site: str, agent_id: str = "auto", title: str = "") -> Dict[str, Any]:
    now = time.time()
    conv = {"id": uuid.uuid4().hex[:12], "site": site, "title": title or "New conversation",
            "created_at": now, "updated_at": now, "agent_id": agent_id, "agent": "", "session_id": "",
            "messages": []}
    _write(_file(site, conv["id"]), conv)
    return conv


def get(site: str, conv_id: str) -> Dict[str, Any]:
    path = _file(site, conv_id)
    if not path.is_file():
        raise ValueError("Conversation not found")
    return json.loads(path.read_text(encoding="utf-8"))


def list_conversations(site: str) -> List[Dict[str, Any]]:
    d = _site_dir(site)
    out = []
    if d.is_dir():
        for f in d.glob("*.json"):
            try:
                c = json.loads(f.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            msgs = c.get("messages") or []
            out.append({"id": c.get("id"), "title": c.get("title") or "Conversation", "agent": c.get("agent") or "",
                        "created_at": c.get("created_at"), "updated_at": c.get("updated_at"),
                        "messages": len(msgs)})
    return sorted(out, key=lambda c: c.get("updated_at") or 0, reverse=True)


def append(site: str, conv_id: str, messages: List[Dict[str, Any]], **meta: Any) -> Dict[str, Any]:
    conv = get(site, conv_id)
    now = time.time()
    for m in messages:
        entry = {"role": m.get("role", "user"), "text": str(m.get("text") or "")[:MAX_TEXT], "ts": now}
        for k in ("agent", "source", "model", "effort", "files_changed", "error", "activity", "duration"):
            if m.get(k):
                entry[k] = m[k]
        conv["messages"].append(entry)
    conv["messages"] = conv["messages"][-MAX_MESSAGES:]
    if conv.get("title") in ("", "New conversation"):
        first_user = next((m["text"] for m in conv["messages"] if m["role"] == "user"), "")
        conv["title"] = _title_from(first_user)
    for k, v in meta.items():
        if v is not None:
            conv[k] = v
    conv["updated_at"] = now
    _write(_file(site, conv_id), conv)
    return conv


def rename(site: str, conv_id: str, title: str) -> Dict[str, Any]:
    conv = get(site, conv_id)
    conv["title"] = " ".join((title or "").split())[:120] or conv["title"]
    _write(_file(site, conv_id), conv)
    return conv


def delete(site: str, conv_id: str) -> bool:
    path = _file(site, conv_id)
    if path.is_file():
        path.unlink()
        return True
    return False


def context_prompt(conv: Dict[str, Any], prompt: str) -> str:
    """The new prompt preceded by the recent conversation, for agents without session resume."""
    history = [m for m in conv.get("messages") or [] if m.get("role") in ("user", "agent") and not m.get("error")]
    history = history[-CONTEXT_MESSAGES:]
    if not history:
        return prompt
    lines, size = [], 0
    for m in reversed(history):
        text = m["text"] if len(m["text"]) < 3000 else m["text"][:3000] + " …"
        # Name the agent that answered: otherwise a model reads "I'm Claude…" from an earlier
        # Claude Code turn as its own words and repeats it.
        who = "User" if m["role"] == "user" else f"Assistant ({m.get('agent') or 'another AI'})"
        line = f"{who}: {text}"
        size += len(line)
        if size > CONTEXT_CHARS:
            break
        lines.append(line)
    lines.reverse()
    return ("Previous conversation (for context; earlier answers may come from other assistants — "
            "answer as yourself):\n" + "\n\n".join(lines) +
            f"\n\nNew request from the user:\n{prompt}")
