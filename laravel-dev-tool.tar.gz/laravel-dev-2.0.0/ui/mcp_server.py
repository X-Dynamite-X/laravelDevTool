#!/usr/bin/env python3
"""
ui/mcp_server.py - Model Context Protocol (MCP) server for laravel-dev-tool.
Exposes project context, routes, logs, models, database queries, and doctor checks via JSON-RPC 2.0 stdio.
Compatible with Claude Code, Cursor, Windsurf, and Antigravity.
"""

import sys
import os
import re
import json
import shlex
import base64
import shutil
import subprocess
import time
from pathlib import Path

UI_DIR = os.path.dirname(os.path.abspath(__file__))
if UI_DIR not in sys.path:
    sys.path.insert(0, UI_DIR)

from sites import list_sites, site_details, php_binary
from laravel_dev import (
    check_site_health,
    parse_laravel_logs,
    get_routes,
    list_models,
    show_model,
    run_php_json,
)


MCP_TOOLS = [
    {
        "name": "list_projects",
        "description": "Lists all Laravel and web projects managed by laravel-dev-tool with their domains, PHP versions, and paths.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "get_project_details",
        "description": "Returns detailed environment info, git branch, and services status for a specific project.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"}
            },
            "required": ["project"]
        }
    },
    {
        "name": "get_routes",
        "description": "Returns all registered HTTP routes (method, URI, name, action, middleware) for a Laravel project.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"}
            },
            "required": ["project"]
        }
    },
    {
        "name": "get_models",
        "description": "Returns Eloquent models and optionally inspects a specific model's columns, casts, and relations.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"},
                "model": {"type": "string", "description": "Optional specific model name to inspect (e.g. 'User')"}
            },
            "required": ["project"]
        }
    },
    {
        "name": "get_recent_logs",
        "description": "Returns recent application log entries, error messages, and stack traces from laravel.log.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"},
                "limit": {"type": "integer", "description": "Max log entries to return", "default": 20}
            },
            "required": ["project"]
        }
    },
    {
        "name": "run_doctor",
        "description": "Runs health diagnostics on a Laravel project (missing .env keys, storage permissions, migrations, vendor status).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"}
            },
            "required": ["project"]
        }
    },
    {
        "name": "query_database",
        "description": "Executes a read-only SQL SELECT/SHOW/DESCRIBE/EXPLAIN query on the project's default database connection (inside a rolled-back transaction, max 200 rows).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"},
                "sql": {"type": "string", "description": "Read-only SQL query (SELECT, SHOW, DESCRIBE, EXPLAIN)"}
            },
            "required": ["project", "sql"]
        }
    },
    {
        "name": "run_artisan",
        "description": "Executes an inspection-only artisan command (about, route:list, migrate:status, model:show, db:show, db:table, config:show, event:list, schedule:list, queue:failed, ...) and returns output.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"},
                "command": {"type": "string", "description": "The artisan command to run, e.g. 'migrate:status' or 'about'"}
            },
            "required": ["project", "command"]
        }
    }
]


MAX_QUERY_ROWS = 200

READONLY_SQL_RE = re.compile(r"^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN|PRAGMA)\b", re.IGNORECASE)
# Read-only prefixes that can still write files, take locks or change settings.
FORBIDDEN_SQL_RE = re.compile(
    r"\bINTO\s+(OUTFILE|DUMPFILE)\b|\bLOAD_FILE\s*\(|\bFOR\s+(UPDATE|SHARE)\b|\bLOCK\s+IN\b"
    r"|\bpg_(read_file|read_binary_file|ls_dir|sleep|terminate_backend|cancel_backend)\b|\bSLEEP\s*\(|\bBENCHMARK\s*\(",
    re.IGNORECASE,
)

# Artisan commands an AI agent may run: inspection only, nothing that writes data,
# changes the schema, executes arbitrary code (tinker) or takes the app down.
ALLOWED_ARTISAN = {
    "about", "list", "help", "env", "inspire",
    "route:list", "migrate:status", "model:show", "db:show", "db:table", "db:monitor",
    "config:show", "event:list", "schedule:list", "queue:failed", "queue:monitor",
    "channel:list",
}


def validate_readonly_sql(sql: str) -> str:
    sql = (sql or "").strip().rstrip(";").strip()
    if not READONLY_SQL_RE.match(sql):
        raise ValueError("Only read-only queries (SELECT, SHOW, DESCRIBE, EXPLAIN, PRAGMA) are permitted via MCP.")
    if ";" in sql:
        raise ValueError("Multiple SQL statements are not allowed.")
    if FORBIDDEN_SQL_RE.search(sql):
        raise ValueError("This query uses a construct that is not allowed via MCP (file access, locks or sleeps).")
    if re.match(r"^PRAGMA\b", sql, re.IGNORECASE) and "=" in sql:
        raise ValueError("PRAGMA assignments change the database and are not allowed via MCP.")
    return sql


def validate_artisan_command(cmd: str) -> list:
    cmd = (cmd or "").strip()
    if not cmd:
        raise ValueError("An artisan command is required.")
    if any(c in cmd for c in "\n\r\0"):
        raise ValueError("Invalid characters in artisan command.")
    try:
        argv = shlex.split(cmd)
    except ValueError as exc:
        raise ValueError(f"Could not parse artisan command: {exc}") from exc
    if argv and argv[0] == "artisan":
        argv = argv[1:]
    if not argv or argv[0] not in ALLOWED_ARTISAN:
        allowed = ", ".join(sorted(ALLOWED_ARTISAN))
        raise ValueError(f"Artisan command '{argv[0] if argv else ''}' is not allowed via MCP. Allowed: {allowed}")
    if argv[0] == "help" and len(argv) > 1 and argv[1] not in ALLOWED_ARTISAN:
        raise ValueError("help is only available for allowed commands.")
    return argv


SUPPORTED_PROTOCOLS = ("2024-11-05", "2025-03-26", "2025-06-18")


def client_configs(home: str = "") -> list:
    """Which AI clients have a laravel-dev MCP server configured, and where."""
    home_p = Path(home or os.path.expanduser("~"))
    candidates = [
        ("Claude Code", home_p / ".claude.json"),
        ("Cursor", home_p / ".cursor" / "mcp.json"),
        ("Claude Desktop", home_p / ".config" / "Claude" / "claude_desktop_config.json"),
        ("Windsurf", home_p / ".codeium" / "windsurf" / "mcp_config.json"),
        ("Gemini CLI", home_p / ".gemini" / "settings.json"),
        ("Antigravity", home_p / ".gemini" / "antigravity" / "mcp_config.json"),
    ]
    out = []
    for client, path in candidates:
        entry = {"client": client, "path": str(path), "exists": path.is_file(), "servers": []}
        if path.is_file():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception as exc:
                entry["error"] = f"Could not read: {exc}"
                data = {}
            scopes = [("user", data.get("mcpServers") or {})]
            if client == "Claude Code":
                for proj, cfg in (data.get("projects") or {}).items():
                    if isinstance(cfg, dict) and cfg.get("mcpServers"):
                        scopes.append((f"project:{proj}", cfg["mcpServers"]))
            for scope, servers in scopes:
                if not isinstance(servers, dict):
                    continue
                for name, cfg in servers.items():
                    if not isinstance(cfg, dict):
                        continue
                    cmd = str(cfg.get("command") or "")
                    args = [str(a) for a in (cfg.get("args") or [])]
                    if "laravel-dev" not in cmd or "mcp" not in args:
                        continue
                    resolved = shutil.which(cmd) or (cmd if os.access(cmd, os.X_OK) else "")
                    entry["servers"].append({
                        "name": name, "scope": scope, "command": " ".join([cmd, *args]),
                        "command_ok": bool(resolved),
                    })
        entry["configured"] = bool(entry["servers"])
        out.append(entry)
    return out


def self_test(cli: str, timeout: float = 20.0) -> dict:
    """Launches `<cli> mcp` exactly like an AI client would and runs a handshake."""
    msgs = [
        {"jsonrpc": "2.0", "id": 1, "method": "initialize",
         "params": {"protocolVersion": SUPPORTED_PROTOCOLS[-1], "capabilities": {}, "clientInfo": {"name": "laravel-dev-selftest", "version": "1"}}},
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "list_projects", "arguments": {}}},
    ]
    payload = "".join(json.dumps(m) + "\n" for m in msgs)
    started = time.monotonic()
    try:
        proc = subprocess.run([cli, "mcp"], input=payload, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError:
        return {"ok": False, "error": f"Command not found: {cli}"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"No answer within {int(timeout)} s"}
    elapsed = round((time.monotonic() - started) * 1000)
    replies = {}
    for line in proc.stdout.splitlines():
        try:
            obj = json.loads(line)
            replies[obj.get("id")] = obj
        except ValueError:
            continue
    init, tools, call = replies.get(1), replies.get(2), replies.get(3)
    if not init or "result" not in init:
        return {"ok": False, "elapsed_ms": elapsed, "error": "No valid initialize response", "stderr": proc.stderr[-800:]}
    projects = None
    if call and "result" in call and not call["result"].get("isError"):
        try:
            projects = len(json.loads(call["result"]["content"][0]["text"]))
        except Exception:
            projects = None
    return {
        "ok": bool(tools and "result" in tools) and projects is not None,
        "elapsed_ms": elapsed,
        "protocol": init["result"].get("protocolVersion"),
        "server": init["result"].get("serverInfo", {}),
        "tools": len((tools or {}).get("result", {}).get("tools", [])),
        "projects": projects,
        "error": "" if projects is not None else "list_projects failed",
        "stderr": proc.stderr[-800:] if proc.returncode else "",
    }


def _find_project(project_name: str) -> dict:
    for s in list_sites():
        if s.get("name") == project_name:
            return s
    raise ValueError(f"Project '{project_name}' not found.")


def handle_tool_call(name: str, args: dict):
    if name == "list_projects":
        sites = list_sites()
        clean = []
        for s in sites:
            clean.append({
                "name": s.get("name"),
                "domain": s.get("domain"),
                "url": s.get("url") or f"http://{s.get('domain')}",
                "php": s.get("php"),
                "path": s.get("path"),
                "type": s.get("type", "laravel"),
                "secured": bool(s.get("ssl") or s.get("secured", False))
            })
        return clean

    elif name == "get_project_details":
        project = args.get("project", "")
        return site_details(project)

    elif name == "get_routes":
        project = args.get("project", "")
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        return get_routes(site["path"], php_bin=php_bin)

    elif name == "get_models":
        project = args.get("project", "")
        model = (args.get("model") or "").strip()
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        models = list_models(site["path"])
        if model:
            return show_model(site["path"], model, php_bin=php_bin)
        return {"models": models}

    elif name == "get_recent_logs":
        project = args.get("project", "")
        limit = int(args.get("limit") or 20)
        site = _find_project(project)
        res = parse_laravel_logs(
            site_path=site["path"],
            file_name="laravel.log",
            max_entries=limit,
            tail_bytes=256 * 1024,
        )
        entries = res.get("entries", [])
        return {"total": len(entries), "entries": entries[:limit], "stats": res.get("stats", {})}

    elif name == "run_doctor":
        project = args.get("project", "")
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        return check_site_health(site["path"], php_bin=php_bin)

    elif name == "query_database":
        project = args.get("project", "")
        sql = validate_readonly_sql(args.get("sql") or "")
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        # base64 keeps the SQL out of PHP string parsing entirely (no "$var" / "{${...}}"
        # interpolation, no mangled non-ASCII text).
        b64_sql = base64.b64encode(sql.encode("utf-8")).decode("ascii")
        script = f"""
        $sql = base64_decode('{b64_sql}');
        $db = \\Illuminate\\Support\\Facades\\DB::connection();
        // Run inside a transaction that is always rolled back, so statements that slip
        // past the prefix check (EXPLAIN ANALYZE <write>, writable CTEs...) leave no trace.
        $db->beginTransaction();
        try {{
            $rows = $db->select($sql);
        }} finally {{
            $db->rollBack();
        }}
        return ['count' => count($rows), 'rows' => array_slice($rows, 0, {MAX_QUERY_ROWS})];
        """
        res = run_php_json(site["path"], php_bin, script, timeout=15)
        if not res.get("ok"):
            raise ValueError(res.get("error") or "Query failed.")
        return res.get("data")

    elif name == "run_artisan":
        project = args.get("project", "")
        argv = validate_artisan_command(args.get("command") or "")
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        proc = subprocess.run(
            [php_bin, "artisan", *argv, "--no-interaction"],
            cwd=site["path"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30,
        )
        return {
            "exit_code": proc.returncode,
            "stdout": proc.stdout[-20000:],
            "stderr": proc.stderr[-5000:],
        }

    raise ValueError(f"Unknown tool: {name}")


def process_message(req: dict):
    method = req.get("method")
    params = req.get("params") or {}
    if "id" not in req:
        # JSON-RPC notifications (notifications/initialized, notifications/cancelled...) get no reply.
        return None
    msg_id = req.get("id")

    if method == "initialize":
        requested = str(params.get("protocolVersion") or "")
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {
                # Echo the client's version when we support it (we only use tools, which
                # are unchanged across these revisions), otherwise offer our latest.
                "protocolVersion": requested if requested in SUPPORTED_PROTOCOLS else SUPPORTED_PROTOCOLS[-1],
                "capabilities": {
                    "tools": {}
                },
                "serverInfo": {
                    "name": "laravel-dev-mcp",
                    "version": "2.1.0"
                }
            }
        }

    elif method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {
                "tools": MCP_TOOLS
            }
        }

    elif method == "tools/call":
        tool_name = params.get("name")
        tool_args = params.get("arguments") or {}
        try:
            res = handle_tool_call(tool_name, tool_args)
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(res, indent=2, ensure_ascii=False)
                        }
                    ],
                    "isError": False
                }
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": f"Error: {str(e)}"
                        }
                    ],
                    "isError": True
                }
            }

    elif method == "ping":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {}}

    else:
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "error": {
                "code": -32601,
                "message": f"Method not found: {method}"
            }
        }


def run_stdio_server():
    """Runs standard stdio JSON-RPC loop (handles newline-delimited or Content-Length header)."""
    while True:
        try:
            line = sys.stdin.readline()
            if not line:
                break

            line = line.strip()
            if not line:
                continue

            if line.lower().startswith("content-length:"):
                length = int(line.split(":", 1)[1].strip())
                sys.stdin.readline()
                content = sys.stdin.read(length)
                req = json.loads(content)
            else:
                req = json.loads(line)

            resp = process_message(req)
            if resp is not None:
                out_str = json.dumps(resp) + "\n"
                sys.stdout.write(out_str)
                sys.stdout.flush()
        except KeyboardInterrupt:
            break
        except Exception as e:
            err_resp = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": f"Parse error: {str(e)}"}
            }
            sys.stdout.write(json.dumps(err_resp) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    run_stdio_server()
