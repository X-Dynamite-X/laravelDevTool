#!/usr/bin/env python3
"""
ui/mcp_server.py - Model Context Protocol (MCP) server for laravel-dev-tool.
Exposes project context, routes, logs, models, database queries, and doctor checks via JSON-RPC 2.0 stdio.
Compatible with Claude Code, Cursor, Windsurf, and Antigravity.
"""

import sys
import os
import re
import json
import shlex
import base64
import shutil
import subprocess
import time
from pathlib import Path

UI_DIR = os.path.dirname(os.path.abspath(__file__))
if UI_DIR not in sys.path:
    sys.path.insert(0, UI_DIR)

from sites import list_sites, site_details, php_binary
from laravel_dev import (
    check_site_health,
    parse_laravel_logs,
    get_routes,
    list_models,
    show_model,
    run_php_json,
)


MCP_TOOLS = [
    {
        "name": "list_projects",
        "description": "Lists all Laravel and web projects managed by laravel-dev-tool with their domains, PHP versions, and paths.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "get_project_details",
        "description": "Returns detailed environment info, git branch, and services status for a specific project.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"}
            },
            "required": ["project"]
        }
    },
    {
        "name": "get_routes",
        "description": "Returns all registered HTTP routes (method, URI, name, action, middleware) for a Laravel project.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"}
            },
            "required": ["project"]
        }
    },
    {
        "name": "get_models",
        "description": "Returns Eloquent models and optionally inspects a specific model's columns, casts, and relations.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"},
                "model": {"type": "string", "description": "Optional specific model name to inspect (e.g. 'User')"}
            },
            "required": ["project"]
        }
    },
    {
        "name": "get_recent_logs",
        "description": "Returns recent application log entries, error messages, and stack traces from laravel.log.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"},
                "limit": {"type": "integer", "description": "Max log entries to return", "default": 20}
            },
            "required": ["project"]
        }
    },
    {
        "name": "run_doctor",
        "description": "Runs health diagnostics on a Laravel project (missing .env keys, storage permissions, migrations, vendor status).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"}
            },
            "required": ["project"]
        }
    },
    {
        "name": "query_database",
        "description": "Executes a read-only SQL SELECT/SHOW/DESCRIBE/EXPLAIN query on the project's default database connection (inside a rolled-back transaction, max 200 rows).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"},
                "sql": {"type": "string", "description": "Read-only SQL query (SELECT, SHOW, DESCRIBE, EXPLAIN)"}
            },
            "required": ["project", "sql"]
        }
    },
    {
        "name": "run_artisan",
        "description": "Executes an inspection-only artisan command (about, route:list, migrate:status, model:show, db:show, db:table, config:show, event:list, schedule:list, queue:failed, ...) and returns output.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "The name of the project"},
                "command": {"type": "string", "description": "The artisan command to run, e.g. 'migrate:status' or 'about'"}
            },
            "required": ["project", "command"]
        }
    }
]


_P = {"project": {"type": "string", "description": "The name of the project (see list_projects)"}}
_MAIL_FILTERS = {
    "to": {"type": "string", "description": "Part of a recipient address"},
    "from": {"type": "string", "description": "Part of the sender"},
    "subject": {"type": "string", "description": "Part of the subject"},
}

MCP_TOOLS += [
    {"name": "get_status",
     "description": "Health check of the local environment: nginx, PHP-FPM versions, databases, Redis, Mailpit, DNS for *.test.",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "site_info",
     "description": "URL, path, PHP/Node versions, HTTPS, runtime (php-fpm/Octane) of a site, which services its .env points at "
                    "(database, queue, cache, mail, broadcasting) and capabilities (composer run dev, Vite, Reverb, Horizon, Boost).",
     "inputSchema": {"type": "object", "properties": dict(_P), "required": ["project"]}},
    {"name": "list_php_versions",
     "description": "Installed PHP versions and the PHP version each site uses.",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "site_env_get",
     "description": "Read values from a site's .env file. Without keys, returns the variable names only (values may be secrets).",
     "inputSchema": {"type": "object", "properties": {**_P, "keys": {"type": "array", "items": {"type": "string"},
                     "description": "Variable names to read"}}, "required": ["project"]}},
    {"name": "site_env_set",
     "description": "Set or remove variables in a site's .env file, keeping comments and order. Use null to remove a key.",
     "inputSchema": {"type": "object", "properties": {**_P, "values": {"type": "object",
                     "description": "{KEY: \"value\" or null}"}}, "required": ["project", "values"]}},
    {"name": "db_connection",
     "description": "Database connection of a site from its .env: driver, host, port, database, user and a connection URL.",
     "inputSchema": {"type": "object", "properties": dict(_P), "required": ["project"]}},
    {"name": "list_mail",
     "description": "Mails captured by the local Mailpit server, newest first. Use after the app sends a mail (sign-up, password reset).",
     "inputSchema": {"type": "object", "properties": {**_MAIL_FILTERS, "limit": {"type": "integer", "default": 20}}, "required": []}},
    {"name": "read_mail",
     "description": "Full mail by ID: headers, text and HTML body, attachments and every link (e.g. the verification URL).",
     "inputSchema": {"type": "object", "properties": {"id": {"type": "string"}}, "required": ["id"]}},
    {"name": "wait_for_mail",
     "description": "Wait until a NEW mail matching the filters arrives (older mails never count) and return it with its links. "
                    "Start it, then trigger the action that sends the mail.",
     "inputSchema": {"type": "object", "properties": {**_MAIL_FILTERS, "timeout": {"type": "integer", "default": 30,
                     "description": "Seconds, max 120"}}, "required": []}},
    {"name": "insights_list",
     "description": "Recent requests captured by the profiler for a site (route, status, duration, query count) or their SQL queries.",
     "inputSchema": {"type": "object", "properties": {**_P, "type": {"type": "string", "enum": ["request", "query"], "default": "request"},
                     "limit": {"type": "integer", "default": 20}}, "required": ["project"]}},
    {"name": "insights_analyze",
     "description": "Find N+1 queries, duplicate queries, slow queries (>=100 ms), HTTP 5xx errors and slow requests (>=1 s) with file and line. "
                    "Returns a cursor: after fixing, reload the page and call again with after=cursor to check only new requests.",
     "inputSchema": {"type": "object", "properties": {**_P, "after": {"type": "string", "description": "Cursor from a previous call"},
                     "limit": {"type": "integer", "default": 50}}, "required": ["project"]}},
    {"name": "site_services_get",
     "description": "Get current configured service drivers for a site (database, queue, cache, broadcasting, mail) and supported options.",
     "inputSchema": {"type": "object", "properties": dict(_P), "required": ["project"]}},
    {"name": "site_services_set",
     "description": "Switch a service category (database, queue, cache, broadcasting, mail) to an option (e.g. redis, sqlite, mysql, mailpit) or unmanaged.",
     "inputSchema": {"type": "object", "properties": {**_P, "category": {"type": "string"}, "option": {"type": "string"}, "database_name": {"type": "string"}}, "required": ["project", "category", "option"]}},
]

MCP_PROMPTS = [
    {"name": "debug_site",
     "description": "Debug a site using its runtime context: recent requests and queries, problems found by the profiler, logs and mails.",
     "arguments": [{"name": "project", "description": "The name of the project", "required": True},
                   {"name": "problem", "description": "What is wrong (optional)", "required": False}]},
]

MAX_QUERY_ROWS = 200

READONLY_SQL_RE = re.compile(r"^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN|PRAGMA)\b", re.IGNORECASE)
# Read-only prefixes that can still write files, take locks or change settings.
FORBIDDEN_SQL_RE = re.compile(
    r"\bINTO\s+(OUTFILE|DUMPFILE)\b|\bLOAD_FILE\s*\(|\bFOR\s+(UPDATE|SHARE)\b|\bLOCK\s+IN\b"
    r"|\bpg_(read_file|read_binary_file|ls_dir|sleep|terminate_backend|cancel_backend)\b|\bSLEEP\s*\(|\bBENCHMARK\s*\(",
    re.IGNORECASE,
)

# Artisan commands an AI agent may run: inspection only, nothing that writes data,
# changes the schema, executes arbitrary code (tinker) or takes the app down.
ALLOWED_ARTISAN = {
    "about", "list", "help", "env", "inspire",
    "route:list", "migrate:status", "model:show", "db:show", "db:table", "db:monitor",
    "config:show", "event:list", "schedule:list", "queue:failed", "queue:monitor",
    "channel:list",
}


def validate_readonly_sql(sql: str) -> str:
    sql = (sql or "").strip().rstrip(";").strip()
    if not READONLY_SQL_RE.match(sql):
        raise ValueError("Only read-only queries (SELECT, SHOW, DESCRIBE, EXPLAIN, PRAGMA) are permitted via MCP.")
    if ";" in sql:
        raise ValueError("Multiple SQL statements are not allowed.")
    if FORBIDDEN_SQL_RE.search(sql):
        raise ValueError("This query uses a construct that is not allowed via MCP (file access, locks or sleeps).")
    if re.match(r"^PRAGMA\b", sql, re.IGNORECASE) and "=" in sql:
        raise ValueError("PRAGMA assignments change the database and are not allowed via MCP.")
    return sql


def validate_artisan_command(cmd: str) -> list:
    cmd = (cmd or "").strip()
    if not cmd:
        raise ValueError("An artisan command is required.")
    if any(c in cmd for c in "\n\r\0"):
        raise ValueError("Invalid characters in artisan command.")
    try:
        argv = shlex.split(cmd)
    except ValueError as exc:
        raise ValueError(f"Could not parse artisan command: {exc}") from exc
    if argv and argv[0] == "artisan":
        argv = argv[1:]
    if not argv or argv[0] not in ALLOWED_ARTISAN:
        allowed = ", ".join(sorted(ALLOWED_ARTISAN))
        raise ValueError(f"Artisan command '{argv[0] if argv else ''}' is not allowed via MCP. Allowed: {allowed}")
    if argv[0] == "help" and len(argv) > 1 and argv[1] not in ALLOWED_ARTISAN:
        raise ValueError("help is only available for allowed commands.")
    return argv


SUPPORTED_PROTOCOLS = ("2024-11-05", "2025-03-26", "2025-06-18")


def client_configs(home: str = "") -> list:
    """Which AI clients have a laravel-dev MCP server configured, and where."""
    home_p = Path(home or os.path.expanduser("~"))
    candidates = [
        ("Claude Code", home_p / ".claude.json"),
        ("Cursor", home_p / ".cursor" / "mcp.json"),
        ("Claude Desktop", home_p / ".config" / "Claude" / "claude_desktop_config.json"),
        ("Windsurf", home_p / ".codeium" / "windsurf" / "mcp_config.json"),
        ("Gemini CLI", home_p / ".gemini" / "settings.json"),
        ("Antigravity", home_p / ".gemini" / "antigravity" / "mcp_config.json"),
    ]
    out = []
    for client, path in candidates:
        entry = {"client": client, "path": str(path), "exists": path.is_file(), "servers": []}
        if path.is_file():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception as exc:
                entry["error"] = f"Could not read: {exc}"
                data = {}
            scopes = [("user", data.get("mcpServers") or {})]
            if client == "Claude Code":
                for proj, cfg in (data.get("projects") or {}).items():
                    if isinstance(cfg, dict) and cfg.get("mcpServers"):
                        scopes.append((f"project:{proj}", cfg["mcpServers"]))
            for scope, servers in scopes:
                if not isinstance(servers, dict):
                    continue
                for name, cfg in servers.items():
                    if not isinstance(cfg, dict):
                        continue
                    cmd = str(cfg.get("command") or "")
                    args = [str(a) for a in (cfg.get("args") or [])]
                    if "laravel-dev" not in cmd or "mcp" not in args:
                        continue
                    resolved = shutil.which(cmd) or (cmd if os.access(cmd, os.X_OK) else "")
                    entry["servers"].append({
                        "name": name, "scope": scope, "command": " ".join([cmd, *args]),
                        "command_ok": bool(resolved),
                    })
        entry["configured"] = bool(entry["servers"])
        out.append(entry)
    return out


def self_test(cli: str, timeout: float = 20.0) -> dict:
    """Launches `<cli> mcp` exactly like an AI client would and runs a handshake."""
    msgs = [
        {"jsonrpc": "2.0", "id": 1, "method": "initialize",
         "params": {"protocolVersion": SUPPORTED_PROTOCOLS[-1], "capabilities": {}, "clientInfo": {"name": "laravel-dev-selftest", "version": "1"}}},
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "list_projects", "arguments": {}}},
    ]
    payload = "".join(json.dumps(m) + "\n" for m in msgs)
    started = time.monotonic()
    try:
        proc = subprocess.run([cli, "mcp"], input=payload, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError:
        return {"ok": False, "error": f"Command not found: {cli}"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"No answer within {int(timeout)} s"}
    elapsed = round((time.monotonic() - started) * 1000)
    replies = {}
    for line in proc.stdout.splitlines():
        try:
            obj = json.loads(line)
            replies[obj.get("id")] = obj
        except ValueError:
            continue
    init, tools, call = replies.get(1), replies.get(2), replies.get(3)
    if not init or "result" not in init:
        return {"ok": False, "elapsed_ms": elapsed, "error": "No valid initialize response", "stderr": proc.stderr[-800:]}
    projects = None
    if call and "result" in call and not call["result"].get("isError"):
        try:
            projects = len(json.loads(call["result"]["content"][0]["text"]))
        except Exception:
            projects = None
    return {
        "ok": bool(tools and "result" in tools) and projects is not None,
        "elapsed_ms": elapsed,
        "protocol": init["result"].get("protocolVersion"),
        "server": init["result"].get("serverInfo", {}),
        "tools": len((tools or {}).get("result", {}).get("tools", [])),
        "projects": projects,
        "error": "" if projects is not None else "list_projects failed",
        "stderr": proc.stderr[-800:] if proc.returncode else "",
    }


def _find_project(project_name: str) -> dict:
    for s in list_sites():
        if s.get("name") == project_name:
            return s
    raise ValueError(f"Project '{project_name}' not found.")


def handle_tool_call(name: str, args: dict):
    if name == "list_projects":
        sites = list_sites()
        clean = []
        for s in sites:
            clean.append({
                "name": s.get("name"),
                "domain": s.get("domain"),
                "url": s.get("url") or f"http://{s.get('domain')}",
                "php": s.get("php"),
                "path": s.get("path"),
                "type": s.get("type", "laravel"),
                "secured": bool(s.get("ssl") or s.get("secured", False))
            })
        return clean

    elif name == "get_project_details":
        project = args.get("project", "")
        return site_details(project)

    elif name == "get_routes":
        project = args.get("project", "")
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        return get_routes(site["path"], php_bin=php_bin)

    elif name == "get_models":
        project = args.get("project", "")
        model = (args.get("model") or "").strip()
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        models = list_models(site["path"])
        if model:
            return show_model(site["path"], model, php_bin=php_bin)
        return {"models": models}

    elif name == "get_recent_logs":
        project = args.get("project", "")
        limit = int(args.get("limit") or 20)
        site = _find_project(project)
        res = parse_laravel_logs(
            site_path=site["path"],
            file_name="laravel.log",
            max_entries=limit,
            tail_bytes=256 * 1024,
        )
        entries = res.get("entries", [])
        return {"total": len(entries), "entries": entries[:limit], "stats": res.get("stats", {})}

    elif name == "run_doctor":
        project = args.get("project", "")
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        return check_site_health(site["path"], php_bin=php_bin)

    elif name == "query_database":
        project = args.get("project", "")
        sql = validate_readonly_sql(args.get("sql") or "")
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        # base64 keeps the SQL out of PHP string parsing entirely (no "$var" / "{${...}}"
        # interpolation, no mangled non-ASCII text).
        b64_sql = base64.b64encode(sql.encode("utf-8")).decode("ascii")
        script = f"""
        $sql = base64_decode('{b64_sql}');
        $db = \\Illuminate\\Support\\Facades\\DB::connection();
        // Run inside a transaction that is always rolled back, so statements that slip
        // past the prefix check (EXPLAIN ANALYZE <write>, writable CTEs...) leave no trace.
        $db->beginTransaction();
        try {{
            $rows = $db->select($sql);
        }} finally {{
            $db->rollBack();
        }}
        return ['count' => count($rows), 'rows' => array_slice($rows, 0, {MAX_QUERY_ROWS})];
        """
        res = run_php_json(site["path"], php_bin, script, timeout=15)
        if not res.get("ok"):
            raise ValueError(res.get("error") or "Query failed.")
        return res.get("data")

    elif name == "run_artisan":
        project = args.get("project", "")
        argv = validate_artisan_command(args.get("command") or "")
        site = _find_project(project)
        php_bin = php_binary(site.get("php"))
        proc = subprocess.run(
            [php_bin, "artisan", *argv, "--no-interaction"],
            cwd=site["path"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30,
        )
        return {
            "exit_code": proc.returncode,
            "stdout": proc.stdout[-20000:],
            "stderr": proc.stderr[-5000:],
        }

    import agent_cli
    if name == "get_status":
        return agent_cli.status_data()
    if name == "site_info":
        return agent_cli.site_info(_find_project(args.get("project", "")))
    if name == "list_php_versions":
        from sites import php_versions
        return {"installed": php_versions(),
                "sites": [{"name": s.get("name"), "php": s.get("php")} for s in list_sites()]}
    if name == "site_env_get":
        site = _find_project(args.get("project", ""))
        _, text = agent_cli.read_env(site)
        values = agent_cli.envfile.to_dict(text)
        keys = args.get("keys") or []
        if not isinstance(keys, list):
            raise ValueError("keys must be a list of variable names")
        if not keys:
            return {"keys": list(values)}
        return {k: values.get(k) for k in keys}
    if name == "site_env_set":
        site = _find_project(args.get("project", ""))
        changes = args.get("values")
        if not isinstance(changes, dict) or not changes:
            raise ValueError("values must be an object like {\"APP_NAME\": \"Shop\"}")
        path, _ = agent_cli.read_env(site)
        agent_cli.write_env(path, changes)
        return {"ok": True, "file": str(path), "changed": list(changes)}
    if name == "db_connection":
        spec = agent_cli.site_db_spec(_find_project(args.get("project", "")))
        out = {k: spec.get(k, "") for k in ("driver", "host", "port", "database", "user", "file") if spec.get(k)}
        out["url"] = agent_cli.connection_url(spec)
        return out
    if name in ("list_mail", "read_mail", "wait_for_mail"):
        filters = {k: str(args[k]) for k in ("to", "from", "subject") if args.get(k)}
        if name == "list_mail":
            return agent_cli.fetch_mails(filters)[: max(1, min(int(args.get("limit") or 20), 200))]
        if name == "read_mail":
            return agent_cli.mail_detail(str(args.get("id") or ""))
        timeout = max(1, min(int(args.get("timeout") or 30), 120))
        mail = agent_cli.wait_for_mail(filters, timeout)
        return mail if mail is not None else {"found": False, "message": f"No matching mail arrived within {timeout} seconds."}
    if name == "insights_list":
        site = _find_project(args.get("project", ""))
        reqs = agent_cli._perf_rows(site, limit=max(1, min(int(args.get("limit") or 20), 200)))
        if args.get("type") == "query":
            return [{"request": r.get("id"), "uri": r.get("uri"), **{k: q.get(k) for k in ("time_ms", "sql", "bindings", "file", "line")}}
                    for r in reqs for q in r.get("queries") or []]
        return [agent_cli._request_summary(r) for r in reqs]
    if name == "insights_analyze":
        site = _find_project(args.get("project", ""))
        after = float(args.get("after") or 0)
        reqs = agent_cli._perf_rows(site, after=after, limit=max(1, min(int(args.get("limit") or 50), 200)))
        cursor = max((r["_created_at"] for r in reqs), default=after) or time.time()
        return {"requests_analyzed": len(reqs), "issues": agent_cli.analyze_requests(reqs), "cursor": f"{cursor:.6f}"}
    if name == "site_services_get":
        site = _find_project(args.get("project", ""))
        import site_services
        return site_services.get_site_services(site["path"])
    if name == "site_services_set":
        site = _find_project(args.get("project", ""))
        import site_services
        return site_services.set_site_service(
            site["path"],
            category=args.get("category", ""),
            option=args.get("option", ""),
            database_name=args.get("database_name"),
        )

    raise ValueError(f"Unknown tool: {name}")


def list_resources() -> list:
    return [{"uri": f"laravel-dev://site/{s.get('name')}", "name": f"{s.get('name')} site information",
             "description": f"URL, PHP/Node versions, services and capabilities of {s.get('domain')}",
             "mimeType": "application/json"} for s in list_sites()]


def read_resource(uri: str) -> dict:
    prefix = "laravel-dev://site/"
    if not uri.startswith(prefix):
        raise ValueError(f"Unknown resource: {uri}")
    import agent_cli
    data = agent_cli.site_info(_find_project(uri[len(prefix):]))
    return {"contents": [{"uri": uri, "mimeType": "application/json", "text": json.dumps(data, indent=2, ensure_ascii=False)}]}


def get_prompt(name: str, args: dict) -> dict:
    if name != "debug_site":
        raise ValueError(f"Unknown prompt: {name}")
    project = str(args.get("project") or "").strip()
    _find_project(project)
    problem = str(args.get("problem") or "").strip()
    text = (
        f"Debug the local site '{project}'." + (f" The problem: {problem}" if problem else "") + "\n\n"
        "Use the laravel-dev tools instead of guessing:\n"
        f"1. site_info(project='{project}') for the URL, PHP version and services.\n"
        f"2. insights_analyze(project='{project}') for N+1/slow queries and 5xx errors with file and line; "
        "insights_list for the latest requests and their queries.\n"
        f"3. get_recent_logs(project='{project}') for exceptions and stack traces.\n"
        "4. list_mail / wait_for_mail if the flow sends mail.\n"
        f"5. query_database / run_artisan (read-only) to confirm data and configuration.\n"
        "Find the root cause, fix it in the code, then call insights_analyze again with the returned cursor "
        "after the page is reloaded to verify the fix."
    )
    return {"description": "Debug a site with its runtime context",
            "messages": [{"role": "user", "content": {"type": "text", "text": text}}]}


def process_message(req: dict):
    method = req.get("method")
    params = req.get("params") or {}
    if "id" not in req:
        # JSON-RPC notifications (notifications/initialized, notifications/cancelled...) get no reply.
        return None
    msg_id = req.get("id")

    if method == "initialize":
        requested = str(params.get("protocolVersion") or "")
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {
                # Echo the client's version when we support it (we only use tools, which
                # are unchanged across these revisions), otherwise offer our latest.
                "protocolVersion": requested if requested in SUPPORTED_PROTOCOLS else SUPPORTED_PROTOCOLS[-1],
                "capabilities": {
                    "tools": {},
                    "resources": {},
                    "prompts": {}
                },
                "serverInfo": {
                    "name": "laravel-dev-mcp",
                    "version": "2.2.0"
                }
            }
        }

    elif method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {
                "tools": MCP_TOOLS
            }
        }

    elif method == "tools/call":
        tool_name = params.get("name")
        tool_args = params.get("arguments") or {}
        try:
            res = handle_tool_call(tool_name, tool_args)
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(res, indent=2, ensure_ascii=False)
                        }
                    ],
                    "isError": False
                }
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": f"Error: {str(e)}"
                        }
                    ],
                    "isError": True
                }
            }

    elif method in ("resources/list", "resources/read", "prompts/list", "prompts/get"):
        try:
            if method == "resources/list":
                result = {"resources": list_resources()}
            elif method == "resources/read":
                result = read_resource(str(params.get("uri") or ""))
            elif method == "prompts/list":
                result = {"prompts": MCP_PROMPTS}
            else:
                result = get_prompt(str(params.get("name") or ""), params.get("arguments") or {})
            return {"jsonrpc": "2.0", "id": msg_id, "result": result}
        except Exception as e:
            return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32602, "message": str(e)}}

    elif method == "ping":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {}}

    else:
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "error": {
                "code": -32601,
                "message": f"Method not found: {method}"
            }
        }


def run_stdio_server():
    """Runs standard stdio JSON-RPC loop (handles newline-delimited or Content-Length header)."""
    while True:
        try:
            line = sys.stdin.readline()
            if not line:
                break

            line = line.strip()
            if not line:
                continue

            if line.lower().startswith("content-length:"):
                length = int(line.split(":", 1)[1].strip())
                sys.stdin.readline()
                content = sys.stdin.read(length)
                req = json.loads(content)
            else:
                req = json.loads(line)

            resp = process_message(req)
            if resp is not None:
                out_str = json.dumps(resp) + "\n"
                sys.stdout.write(out_str)
                sys.stdout.flush()
        except KeyboardInterrupt:
            break
        except Exception as e:
            err_resp = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": f"Parse error: {str(e)}"}
            }
            sys.stdout.write(json.dumps(err_resp) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    run_stdio_server()
