"""Live Cache & Redis Explorer Engine for Laravel Dev.

Inspects live cache keys, TTL, and values across Redis, File, and Database drivers,
supporting selective key deletion and complete cache flushing.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any


def get_cache_config(site_path: Path) -> dict[str, str]:
    env_file = site_path / ".env"
    cfg = {
        "driver": "file",
        "prefix": "",
        "redis_host": "127.0.0.1",
        "redis_port": "6379",
        "redis_password": "",
    }
    if not env_file.is_file():
        return cfg

    try:
        import envfile

        env_data = envfile.to_dict(env_file.read_text(encoding="utf-8", errors="replace"))
        cfg["driver"] = env_data.get("CACHE_STORE") or env_data.get("CACHE_DRIVER") or "file"
        cfg["prefix"] = env_data.get("CACHE_PREFIX") or ""
        cfg["redis_host"] = env_data.get("REDIS_HOST") or "127.0.0.1"
        cfg["redis_port"] = env_data.get("REDIS_PORT") or "6379"
        cfg["redis_password"] = env_data.get("REDIS_PASSWORD") or ""
    except Exception:
        pass
    return cfg


def list_cache_keys(site_path: str, query: str = "", limit: int = 100) -> dict[str, Any]:
    path = Path(site_path).resolve()
    cfg = get_cache_config(path)
    driver = cfg["driver"].lower()
    keys: list[dict[str, Any]] = []

    # 1. Redis Cache Driver
    if driver == "redis" and shutil.which("redis-cli"):
        cli = ["redis-cli", "-h", cfg["redis_host"], "-p", cfg["redis_port"]]
        if cfg["redis_password"]:
            cli.extend(["-a", cfg["redis_password"]])
        try:
            pattern = f"*{query}*" if query else "*"
            proc = subprocess.run(
                cli + ["--scan", "--pattern", pattern],
                capture_output=True,
                text=True,
                timeout=5,
            )
            raw_keys = [k.strip() for k in proc.stdout.splitlines() if k.strip()][:limit]
            for rk in raw_keys:
                ttl_proc = subprocess.run(cli + ["ttl", rk], capture_output=True, text=True, timeout=2)
                type_proc = subprocess.run(cli + ["type", rk], capture_output=True, text=True, timeout=2)
                val_proc = subprocess.run(cli + ["get", rk], capture_output=True, text=True, timeout=2)
                ttl_val = int(ttl_proc.stdout.strip()) if ttl_proc.stdout.strip().lstrip("-").isdigit() else -1
                k_type = type_proc.stdout.strip() or "string"
                val_preview = val_proc.stdout.strip()[:160]

                keys.append({
                    "key": rk,
                    "type": k_type,
                    "ttl": ttl_val,
                    "ttl_human": f"{ttl_val}s" if ttl_val > 0 else ("Persistent" if ttl_val == -1 else "Expired"),
                    "preview": val_preview,
                    "driver": "redis",
                })
        except Exception:
            pass

    # 2. File Cache Driver
    cache_dir = path / "storage" / "framework" / "cache" / "data"
    if driver == "file" or not keys:
        if cache_dir.is_dir():
            now = int(time.time())
            count = 0
            for root, _, files in os.walk(cache_dir):
                for f in files:
                    if count >= limit:
                        break
                    if f.startswith("."):  # .gitignore, not a cache entry
                        continue
                    fpath = Path(root) / f
                    try:
                        with open(fpath, "rb") as fp:
                            raw_exp = fp.read(10)
                            content = fp.read(512).decode("utf-8", errors="replace")

                        exp_time = int(raw_exp) if raw_exp.isdigit() else 0
                        ttl_sec = exp_time - now if exp_time > now else -1

                        if query and query.lower() not in f.lower() and query.lower() not in content.lower():
                            continue

                        keys.append({
                            "key": f,
                            "type": "file",
                            "ttl": ttl_sec,
                            "ttl_human": f"{ttl_sec}s" if ttl_sec > 0 else "Expired",
                            "preview": content.strip().replace("\n", " ")[:140],
                            "driver": "file",
                            "path": str(fpath.relative_to(path)),
                        })
                        count += 1
                    except Exception:
                        pass

    return {
        "ok": True,
        "driver": driver,
        "count": len(keys),
        "keys": keys,
    }


def get_cache_value(site_path: str, key: str, php_bin: str = "php") -> dict[str, Any]:
    path = Path(site_path).resolve()
    resolved_php = shutil.which(php_bin) or php_bin

    script = f"""
        $k = {json.dumps(key)};
        $val = \\Illuminate\\Support\\Facades\\Cache::get($k);
        return [
            'key' => $k,
            'exists' => \\Illuminate\\Support\\Facades\\Cache::has($k),
            'value' => $val,
            'type' => gettype($val),
        ];
    """
    try:
        import laravel_dev

        res = laravel_dev.run_php_json(path, php_bin=resolved_php, script=script, timeout=8)
        if res.get("ok"):
            return {"ok": True, "data": res.get("data", {})}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": False, "error": "Failed to inspect cache key"}


def delete_cache_key(site_path: str, key: str, php_bin: str = "php") -> dict[str, Any]:
    path = Path(site_path).resolve()
    resolved_php = shutil.which(php_bin) or php_bin

    script = f"""
        $k = {json.dumps(key)};
        $forgot = \\Illuminate\\Support\\Facades\\Cache::forget($k);
        return ['forgot' => $forgot];
    """
    try:
        import laravel_dev

        res = laravel_dev.run_php_json(path, php_bin=resolved_php, script=script, timeout=8)
        if not res.get("ok"):
            return {"ok": False, "error": res.get("error") or "Could not delete the cache key"}
        if not (res.get("data") or {}).get("forgot"):
            return {"ok": False, "error": f"Cache key '{key}' was not found"}
        return {"ok": True, "message": f"Cache key '{key}' deleted"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def flush_all_cache(site_path: str, php_bin: str = "php") -> dict[str, Any]:
    path = Path(site_path).resolve()
    resolved_php = shutil.which(php_bin) or php_bin

    try:
        proc = subprocess.run(
            [resolved_php, "artisan", "cache:clear"],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=15,
        )
        return {
            "ok": proc.returncode == 0,
            "output": proc.stdout.strip(),
            "error": proc.stderr.strip(),
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

