"""Read and edit .env files without disturbing comments, order or quoting
of the lines that were not changed."""

import hashlib
import re

LINE_RE = re.compile(r"^(?P<indent>\s*)(?P<export>export\s+)?(?P<key>[A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(?P<rest>.*)$")
KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*$")
SECRET_RE = re.compile(r"(PASS|SECRET|TOKEN|KEY|PRIVATE|CREDENTIAL|AUTH|DSN|SALT|SIGNATURE|WEBHOOK)", re.I)
NOT_SECRET_RE = re.compile(r"(_ID|_HOST|_PORT|_DRIVER|_REGION|_BUCKET|_URL|_NAME|_VERSION|_PATH|PUBLIC)$", re.I)
ENV_FILES = (".env", ".env.local", ".env.development", ".env.development.local", ".env.production",
             ".env.production.local", ".env.staging", ".env.testing")


def digest(text):
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


PUBLIC_RE = re.compile(r"^(NEXT_PUBLIC_|NUXT_PUBLIC_|VITE_|PUBLIC_|REACT_APP_)")


def looks_secret(key):
    if key in ("APP_KEY", "DATABASE_URL", "REDIS_URL"):
        return True
    if PUBLIC_RE.match(key):  # bundled into the browser build, so never a secret
        return False
    return bool(SECRET_RE.search(key)) and not NOT_SECRET_RE.search(key)


def _unquote(rest):
    rest = rest.rstrip("\r")
    if rest[:1] in ('"', "'"):
        quote = rest[0]
        i, out = 1, []
        while i < len(rest):
            ch = rest[i]
            if quote == '"' and ch == "\\" and i + 1 < len(rest):
                nxt = rest[i + 1]
                out.append({"n": "\n", "r": "\r", "t": "\t"}.get(nxt, nxt))
                i += 2
                continue
            if ch == quote:
                return "".join(out), quote, True
            out.append(ch)
            i += 1
        return rest[1:], quote, False  # unterminated: multi-line value
    value = re.split(r"\s+#", rest, maxsplit=1)[0]
    return value.strip(), "", True


def parse(text):
    """Returns a list of {"key", "value", "line"} for every variable (last one wins on duplicates)."""
    out = {}
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        match = LINE_RE.match(lines[i])
        start = i
        i += 1
        if not match or lines[start].lstrip().startswith("#"):
            continue
        value, quote, closed = _unquote(match.group("rest"))
        if not closed:  # "-quoted value spanning lines (private keys, certificates)
            parts = [match.group("rest")[1:]]
            while i < len(lines):
                line = lines[i]
                i += 1
                if line.rstrip().endswith(quote):
                    parts.append(line.rstrip()[:-1])
                    break
                parts.append(line)
            value = "\n".join(parts)
        out[match.group("key")] = {"key": match.group("key"), "value": value, "line": start + 1}
    return list(out.values())


def to_dict(text):
    return {item["key"]: item["value"] for item in parse(text)}


def quote(value):
    value = "" if value is None else str(value)
    if value == "":
        return ""
    if re.fullmatch(r"[A-Za-z0-9_./:@,+\-]+", value) and not value.startswith("#"):
        return value
    # Real line breaks inside double quotes: phpdotenv, dotenv (node) and
    # python-dotenv all read those, while "\n" escapes are not universal.
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _block_end(lines, start):
    """Index after the last line of the variable starting at `start` (multi-line values)."""
    match = LINE_RE.match(lines[start])
    rest = match.group("rest") if match else ""
    if rest[:1] == '"' and not _unquote(rest)[2]:
        i = start + 1
        while i < len(lines):
            if lines[i].rstrip().endswith('"'):
                return i + 1
            i += 1
        return len(lines)
    return start + 1


def apply(text, changes):
    """changes: {key: new value, or None to delete}. New keys go after the last
    key sharing their prefix (DB_*, MAIL_*), otherwise at the end."""
    lines = text.splitlines()
    pending = {k: v for k, v in changes.items()}
    out = []
    i = 0
    while i < len(lines):
        match = LINE_RE.match(lines[i])
        end = _block_end(lines, i) if match and not lines[i].lstrip().startswith("#") else i + 1
        key = match.group("key") if match and not lines[i].lstrip().startswith("#") else None
        if key in pending:
            value = pending.pop(key)
            if value is not None:
                prefix = (match.group("indent") or "") + (match.group("export") or "")
                out.append(f"{prefix}{key}={quote(value)}")
        else:
            out.extend(lines[i:end])
        i = end

    separated = False
    for key, value in pending.items():
        if value is None:
            continue
        group = key.split("_", 1)[0] + "_" if "_" in key else None
        position = None
        if group:
            for index, line in enumerate(out):
                m = LINE_RE.match(line)
                if m and m.group("key").startswith(group):
                    position = index + 1
        entry = f"{key}={quote(value)}"
        if position is None:
            if out and out[-1].strip() and not separated:
                out.append("")
            separated = True
            out.append(entry)
        else:
            out.insert(position, entry)
    return "\n".join(out).rstrip("\n") + "\n"


def validate_changes(changes):
    if not isinstance(changes, dict):
        raise ValueError("Invalid changes")
    clean = {}
    for key, value in changes.items():
        key = str(key).strip()
        if not KEY_RE.fullmatch(key):
            raise ValueError(f"Invalid variable name: {key or '(empty)'}")
        if value is not None and not isinstance(value, (str, int, float, bool)):
            raise ValueError(f"Invalid value for {key}")
        clean[key] = None if value is None else str(value)
    return clean
