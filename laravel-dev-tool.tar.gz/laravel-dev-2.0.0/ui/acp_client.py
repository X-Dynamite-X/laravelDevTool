"""A small Agent Client Protocol (ACP) client: JSON-RPC 2.0 over the stdio of `agy acp` / `opencode acp`.

Studio uses it so an agent can ask for permission while it works: the agent sends
session/request_permission and waits; the answer comes from the user in the app. Without ACP the
agents run headless, where such a request is denied and the turn ends.

Protocol summary (https://agentclientprotocol.com):
  → initialize {protocolVersion, clientCapabilities}
  → session/new {cwd, mcpServers}  |  session/load {sessionId, cwd, mcpServers} (replays the history)
  → session/prompt {sessionId, prompt: [{type: "text", text}]}  … returns {stopReason}
  ← session/update {sessionId, update: {sessionUpdate: agent_message_chunk | agent_thought_chunk |
                                        tool_call | tool_call_update | plan | …}}
  ← session/request_permission {sessionId, toolCall, options: [{optionId, name, kind}]} (a request:
     answered with {outcome: {outcome: "selected", optionId}} or {outcome: {outcome: "cancelled"}})
  → session/cancel {sessionId} (a notification)
"""
from __future__ import annotations

import json
import os
import subprocess
import threading
from typing import Any, Callable, Dict, List, Optional

PROTOCOL_VERSION = 1


class AcpError(Exception):
    """The agent answered a request with an error, or went away."""


class AcpConnection:
    """One agent process. on_update(update) gets every session/update while a prompt runs;
    on_permission(params) -> optionId | None answers session/request_permission (None = cancelled)."""

    def __init__(self, cmd: List[str], cwd: str, env: Optional[Dict[str, str]] = None):
        self.proc = subprocess.Popen(cmd, cwd=cwd, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True, bufsize=1, start_new_session=True)
        self._next_id = 0
        self._pending: Dict[int, Dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._write_lock = threading.Lock()
        self.on_update: Optional[Callable[[Dict[str, Any]], None]] = None
        self.on_permission: Optional[Callable[[Dict[str, Any]], Optional[str]]] = None
        self.closed = threading.Event()
        self.stderr_tail: List[str] = []
        threading.Thread(target=self._read, daemon=True, name="acp-read").start()
        threading.Thread(target=self._read_stderr, daemon=True, name="acp-stderr").start()

    # ---- transport ----
    def _send(self, obj: Dict[str, Any]) -> None:
        data = json.dumps(obj) + "\n"
        with self._write_lock:
            try:
                self.proc.stdin.write(data)
                self.proc.stdin.flush()
            except (BrokenPipeError, ValueError, OSError) as exc:
                raise AcpError(f"The agent stopped: {self.stderr_text() or exc}") from exc

    def stderr_text(self) -> str:
        return "".join(self.stderr_tail).strip()[-1500:]

    def _read_stderr(self) -> None:
        for line in self.proc.stderr:
            self.stderr_tail.append(line)
            del self.stderr_tail[:-40]

    def _read(self) -> None:
        try:
            for line in self.proc.stdout:
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                if not isinstance(msg, dict):
                    continue
                if "method" in msg:
                    self._incoming(msg)
                elif "id" in msg:
                    with self._lock:
                        waiter = self._pending.pop(msg["id"], None)
                    if waiter:
                        waiter["msg"] = msg
                        waiter["event"].set()
        finally:
            self.closed.set()
            with self._lock:
                for waiter in self._pending.values():
                    waiter["event"].set()  # wakes request() with no answer: the agent went away
                self._pending.clear()

    def _incoming(self, msg: Dict[str, Any]) -> None:
        method, params = msg.get("method"), msg.get("params") or {}
        if method == "session/update":
            if self.on_update:
                try:
                    self.on_update(params.get("update") or {})
                except Exception:  # noqa: BLE001 — a display problem must not stop the agent
                    pass
            return
        if "id" not in msg:
            return  # another notification
        if method == "session/request_permission":
            # Answered from its own thread: the user may take a while, and the reader must keep going.
            threading.Thread(target=self._answer_permission, args=(msg["id"], params), daemon=True).start()
            return
        # fs/*, terminal/*: not offered in our capabilities.
        self._send({"jsonrpc": "2.0", "id": msg["id"], "error": {"code": -32601, "message": f"{method} is not supported"}})

    def _answer_permission(self, req_id: Any, params: Dict[str, Any]) -> None:
        option = None
        try:
            option = self.on_permission(params) if self.on_permission else None
        except Exception:  # noqa: BLE001
            option = None
        outcome = {"outcome": "selected", "optionId": option} if option else {"outcome": "cancelled"}
        try:
            self._send({"jsonrpc": "2.0", "id": req_id, "result": {"outcome": outcome}})
        except AcpError:
            pass

    def request(self, method: str, params: Dict[str, Any], timeout: Optional[float] = None) -> Dict[str, Any]:
        with self._lock:
            self._next_id += 1
            req_id = self._next_id
            waiter = {"event": threading.Event(), "msg": None}
            self._pending[req_id] = waiter
        self._send({"jsonrpc": "2.0", "id": req_id, "method": method, "params": params})
        if not waiter["event"].wait(timeout):
            with self._lock:
                self._pending.pop(req_id, None)
            raise AcpError(f"{method}: no answer from the agent")
        msg = waiter["msg"]
        if msg is None:
            raise AcpError(f"The agent stopped: {self.stderr_text() or 'no output'}")
        if "error" in msg:
            err = msg["error"] or {}
            raise AcpError(str(err.get("message") or err))
        return msg.get("result") or {}

    def notify(self, method: str, params: Dict[str, Any]) -> None:
        self._send({"jsonrpc": "2.0", "method": method, "params": params})

    # ---- session helpers ----
    def initialize(self) -> Dict[str, Any]:
        return self.request("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "clientCapabilities": {"fs": {"readTextFile": False, "writeTextFile": False}, "terminal": False},
            "clientInfo": {"name": "laravel-dev-studio", "version": "1"},
        }, timeout=60)

    def close(self) -> None:
        try:
            self.proc.stdin.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            self.proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(self.proc.pid, 15)
                self.proc.wait(timeout=3)
            except Exception:  # noqa: BLE001
                try:
                    os.killpg(self.proc.pid, 9)
                except Exception:  # noqa: BLE001
                    pass


def content_text(content: Any) -> str:
    """Text of an ACP content block, or of a list of tool-call content entries."""
    if isinstance(content, dict):
        if content.get("type") == "text":
            return str(content.get("text") or "")
        if content.get("type") == "content":
            return content_text(content.get("content"))
        if content.get("type") == "diff":
            return f"edit {content.get('path', '')}"
        return ""
    if isinstance(content, list):
        return "\n".join(t for t in (content_text(c) for c in content) if t)
    return ""
