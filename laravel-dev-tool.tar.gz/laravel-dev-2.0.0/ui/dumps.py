"""Interactive Dumps Viewer Server.
Listens on TCP 127.0.0.1:9912 for Symfony VarDumper / Laravel dump() outputs.
Decodes serialized payloads and streams real-time formatted HTML dumps to the UI.
"""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import select
import shutil
import socket
import subprocess
import threading
import time
import uuid

DUMPS_PORT = 9912
MAX_SAVED_DUMPS = 50


class DumpsServer:
    def __init__(self, emit_fn=None):
        self.emit_fn = emit_fn
        self.server_sock: socket.socket | None = None
        self.thread: threading.Thread | None = None
        self.running = False
        self._stop_event = threading.Event()
        self.dumps: list[dict] = []
        self._lock = threading.Lock()

    def start(self, port: int = DUMPS_PORT) -> bool:
        if self.running:
            return True
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("127.0.0.1", port))
            sock.listen(10)
            sock.settimeout(0.5)
            self.server_sock = sock
            self.running = True
            self._stop_event.clear()
            self.thread = threading.Thread(target=self._listen_loop, daemon=True, name="ld-dumps-server")
            self.thread.start()
            return True
        except Exception:
            self.running = False
            return False

    def stop(self) -> None:
        self.running = False
        self._stop_event.set()
        if self.server_sock:
            try:
                self.server_sock.close()
            except Exception:
                pass
            self.server_sock = None
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.0)
            self.thread = None

    def clear(self) -> None:
        with self._lock:
            self.dumps.clear()

    def list_dumps(self, site_name: str = "") -> list[dict]:
        with self._lock:
            if not site_name:
                return list(self.dumps)
            return [d for d in self.dumps if d.get("site") == site_name or not d.get("site")]

    def _listen_loop(self) -> None:
        while not self._stop_event.is_set() and self.running:
            try:
                conn, addr = self.server_sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle_client, args=(conn,), daemon=True).start()

    def _handle_client(self, conn: socket.socket) -> None:
        # VarDumper keeps one connection per PHP process and writes one base64 line per dump.
        conn.settimeout(300)
        buffer = b""
        try:
            while not self._stop_event.is_set():
                chunk = conn.recv(65536)
                if not chunk:
                    break
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if line.strip():
                        self._process_payload(line.strip())
        except Exception:
            pass
        finally:
            try:
                conn.close()
            except Exception:
                pass
        if buffer.strip():
            self._process_payload(buffer.strip())

    def _get_sites_cache(self) -> list[dict]:
        now = time.time()
        if not hasattr(self, "_sites_cache") or now - getattr(self, "_sites_cache_time", 0) > 30:
            import sites
            try:
                self._sites_cache = sites.list_sites()
            except Exception:
                self._sites_cache = []
            self._sites_cache_time = now
        return self._sites_cache

    def _process_payload(self, raw_bytes: bytes) -> None:
        import sites

        all_sites = self._get_sites_cache()
        default_autoload = ""
        for s in all_sites:
            p = Path(s.get("path", "")) / "vendor" / "autoload.php"
            if p.is_file():
                default_autoload = str(p)
                break

        decode_script = """
error_reporting(0);
$autoload = $argv[1] ?? '';
if ($autoload && file_exists($autoload)) {
    require_once $autoload;
}
$raw = file_get_contents('php://stdin');
if (!$raw) exit(0);

$decoded = base64_decode(trim($raw));
if (!$decoded) exit(0);

// Only VarDumper's own classes, like Symfony's dump-server: anything that can reach the
// port could otherwise send a gadget chain from the project's autoloaded vendor code.
$allowed = class_exists('\\Symfony\\Component\\VarDumper\\Cloner\\Data')
    ? [\\Symfony\\Component\\VarDumper\\Cloner\\Data::class, \\Symfony\\Component\\VarDumper\\Cloner\\Stub::class]
    : false;
$unserialized = @unserialize($decoded, ['allowed_classes' => $allowed]);
if (!$unserialized || !is_array($unserialized)) exit(0);

[$data, $context] = $unserialized;
$source = $context['source'] ?? [];
$file = $source['file'] ?? ($source['name'] ?? '');
$line = $source['line'] ?? null;
$project_dir = $source['project_dir'] ?? '';
$rel_file = $source['file_relative'] ?? $file;

if (!$autoload && $project_dir && file_exists($project_dir . '/vendor/autoload.php')) {
    require_once $project_dir . '/vendor/autoload.php';
}

$html = '';
if (class_exists('\\Symfony\\Component\\VarDumper\\Dumper\\HtmlDumper')) {
    $dumper = new \\Symfony\\Component\\VarDumper\\Dumper\\HtmlDumper();
    $dumper->setTheme('dark');
    $html = $dumper->dump($data, true);
} else {
    ob_start();
    var_dump($data);
    $html = '<pre style="margin:0;color:var(--text);font-family:var(--mono)">' . htmlspecialchars(ob_get_clean()) . '</pre>';
}

echo json_encode([
    'file' => $file,
    'rel_file' => $rel_file,
    'line' => $line,
    'project_dir' => $project_dir,
    'html' => $html,
    'timestamp' => date('H:i:s'),
]);
"""
        php_bin = shutil.which("php") or "php"
        proc = subprocess.Popen(
            [php_bin, "-r", decode_script, default_autoload],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            stdout, _ = proc.communicate(input=raw_bytes.decode("utf-8", errors="replace"), timeout=4)
        except Exception:
            proc.kill()
            return

        if not stdout or not stdout.strip():
            return

        try:
            item = json.loads(stdout)
        except Exception:
            return

        item["id"] = uuid.uuid4().hex[:10]

        # Match site by project_dir or file path
        matched_site = ""
        file_path = item.get("file") or item.get("project_dir") or ""
        for s in all_sites:
            s_path = s.get("path", "")
            if s_path and file_path.startswith(s_path):
                matched_site = s.get("name", "")
                break

        item["site"] = matched_site

        with self._lock:
            self.dumps.insert(0, item)
            if len(self.dumps) > MAX_SAVED_DUMPS:
                self.dumps = self.dumps[:MAX_SAVED_DUMPS]

        if self.emit_fn:
            try:
                self.emit_fn({"type": "dump", "dump": item})
            except Exception:
                pass


_GLOBAL_DUMPS_SERVER: DumpsServer | None = None


def get_dumps_server(emit_fn=None) -> DumpsServer:
    global _GLOBAL_DUMPS_SERVER
    if _GLOBAL_DUMPS_SERVER is None:
        _GLOBAL_DUMPS_SERVER = DumpsServer(emit_fn=emit_fn)
    elif emit_fn and not _GLOBAL_DUMPS_SERVER.emit_fn:
        _GLOBAL_DUMPS_SERVER.emit_fn = emit_fn
    return _GLOBAL_DUMPS_SERVER

