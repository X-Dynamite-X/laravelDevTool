"""Per-Site Resource Monitor (CPU & RAM) Engine for Laravel Dev.

Monitors CPU% and RSS Memory (MB) consumption of processes associated with each
site (Vite watchers, artisan queues, background jobs, php dev servers, and node processes),
detecting runaway loops and providing safe process termination.
"""
from __future__ import annotations

import os
import signal
import subprocess
import time
from pathlib import Path
from typing import Any


def get_site_processes(site_name: str, site_path: str) -> list[dict[str, Any]]:
    """Scan running processes for those belonging to the given site."""
    norm_path = os.path.realpath(site_path)
    procs: list[dict[str, Any]] = []

    try:
        res = subprocess.run(
            ["ps", "-eo", "pid,%cpu,rss,args"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if res.returncode != 0:
            return procs

        lines = res.stdout.splitlines()[1:]  # skip header
        for line in lines:
            parts = line.strip().split(None, 3)
            if len(parts) < 4:
                continue
            pid_str, cpu_str, rss_str, cmd = parts
            try:
                pid = int(pid_str)
                cpu = float(cpu_str)
                rss_kb = int(rss_str)
            except ValueError:
                continue

            # Don't match our own inspection processes or laravel-dev UI itself
            if "laravel-dev" in cmd and "ui/app.py" in cmd:
                continue
            if "ps -eo" in cmd or "grep" in cmd:
                continue

            # Match criteria: process command contains site path, or site name in artisan/vite context
            matched = False
            if norm_path in cmd or site_path in cmd:
                matched = True
            elif f"artisan" in cmd and site_name in cmd:
                matched = True
            elif f"--site={site_name}" in cmd or f"laravel-dev-{site_name}" in cmd:
                matched = True

            if matched:
                mem_mb = round(rss_kb / 1024.0, 1)
                procs.append({
                    "pid": pid,
                    "cpu": cpu,
                    "memory_mb": mem_mb,
                    "command": cmd[:180],
                })
    except Exception:
        pass

    return procs


def get_site_metrics(site_name: str, site_path: str) -> dict[str, Any]:
    """Calculate aggregate CPU%, RAM MB, and runaway process status for a site."""
    procs = get_site_processes(site_name, site_path)
    total_cpu = round(sum(p["cpu"] for p in procs), 1)
    total_mem = round(sum(p["memory_mb"] for p in procs), 1)

    runaway_proc = None
    for p in procs:
        if p["cpu"] >= 85.0:  # sustained CPU spike
            runaway_proc = p
            break

    return {
        "ok": True,
        "name": site_name,
        "process_count": len(procs),
        "cpu_percent": total_cpu,
        "memory_mb": total_mem,
        "runaway": runaway_proc is not None,
        "runaway_process": runaway_proc,
        "processes": procs,
    }


def kill_site_process(site_name: str, site_path: str, pid: int) -> dict[str, Any]:
    """Safely terminate a runaway process belonging to the site."""
    # Security check: verify this PID actually belongs to the site
    procs = get_site_processes(site_name, site_path)
    allowed_pids = {p["pid"] for p in procs}

    if pid not in allowed_pids:
        return {"ok": False, "error": f"PID {pid} does not belong to site {site_name}"}

    try:
        os.kill(pid, signal.SIGTERM)
        time.sleep(0.5)
        # Check if still running, then SIGKILL
        try:
            os.kill(pid, 0)
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
        return {"ok": True, "message": f"Process {pid} terminated successfully"}
    except ProcessLookupError:
        return {"ok": True, "message": f"Process {pid} already stopped"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

