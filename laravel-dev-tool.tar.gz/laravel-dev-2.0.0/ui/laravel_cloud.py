"""Laravel Cloud CLI Integration for laravel-dev-tool.

Provides:
  - CLI discovery (cloud / laravel-cloud) and version inspection
  - Authentication verification and account detection
  - Project linking status (.cloud directory / config)
  - 3-Stage Deployment Pipeline: Prepare -> Build -> Release
  - Live deployment URL resolution
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


def find_cloud_cli() -> Optional[str]:
    """Finds the Laravel Cloud CLI binary ('cloud' or 'laravel-cloud')."""
    # 1. Standard PATH
    cli = shutil.which("cloud") or shutil.which("laravel-cloud")
    if cli and os.access(cli, os.X_OK):
        return cli

    # 2. Composer global bin directories
    home = Path.home()
    candidates = [
        home / ".config" / "composer" / "vendor" / "bin" / "cloud",
        home / ".composer" / "vendor" / "bin" / "cloud",
        home / ".local" / "bin" / "cloud",
        home / ".config" / "composer" / "vendor" / "bin" / "laravel-cloud",
        home / ".composer" / "vendor" / "bin" / "laravel-cloud",
    ]
    for cand in candidates:
        if cand.is_file() and os.access(cand, os.X_OK):
            return str(cand)

    return None


def get_cloud_cli_status() -> Dict[str, Any]:
    """Checks whether the Cloud CLI is installed, its version, and auth status."""
    cli_path = find_cloud_cli()
    if not cli_path:
        return {
            "installed": False,
            "cli_path": None,
            "version": None,
            "authenticated": False,
            "user": None,
            "team": None,
        }

    # Version check
    version = None
    try:
        proc = subprocess.run([cli_path, "--version"], capture_output=True, text=True, timeout=5)
        if proc.returncode == 0:
            version_out = (proc.stdout or proc.stderr).strip()
            # Extract e.g. "Laravel Cloud CLI 1.2.0"
            m = re.search(r"(\d+\.\d+\.\d+)", version_out)
            version = m.group(1) if m else version_out.splitlines()[0]
    except Exception:
        version = "unknown"

    # Authentication check
    authenticated = False
    user_email = None
    team_name = None

    # First check config directory: ~/.config/laravel-cloud/ or ~/.laravel-cloud/
    home = Path.home()
    config_paths = [
        home / ".config" / "laravel-cloud" / "auth.json",
        home / ".laravel-cloud" / "auth.json",
        home / ".config" / "laravel-cloud" / "config.json",
    ]
    for cfg in config_paths:
        if cfg.is_file():
            try:
                data = json.loads(cfg.read_text(encoding="utf-8"))
                if data.get("token") or data.get("api_token") or data.get("user"):
                    authenticated = True
                    user_email = data.get("user", {}).get("email") or data.get("email")
                    team_name = data.get("team", {}).get("name") or data.get("team")
                    break
            except Exception:
                pass

    # If not determined from file, probe CLI whoami
    if not authenticated:
        try:
            proc = subprocess.run([cli_path, "whoami"], capture_output=True, text=True, timeout=5)
            if proc.returncode == 0 and "not logged in" not in proc.stdout.lower():
                authenticated = True
                out = proc.stdout.strip()
                m_email = re.search(r"[\w\.-]+@[\w\.-]+", out)
                if m_email:
                    user_email = m_email.group(0)
                else:
                    user_email = out.splitlines()[0] if out else "Authenticated"
        except Exception:
            pass

    return {
        "installed": True,
        "cli_path": cli_path,
        "version": version or "installed",
        "authenticated": authenticated,
        "user": user_email,
        "team": team_name,
    }


def get_project_cloud_status(project_path: str) -> Dict[str, Any]:
    """Inspects project-level Laravel Cloud association and configuration."""
    root = Path(project_path).resolve()
    cloud_dir = root / ".cloud"
    cloud_yaml = root / ".cloud.yaml"
    cloud_json = cloud_dir / "config.json"

    linked = False
    app_id = None
    app_name = None
    environment = "production"
    live_url = None
    last_deployment: Optional[Dict[str, Any]] = None

    if cloud_json.is_file():
        try:
            data = json.loads(cloud_json.read_text(encoding="utf-8"))
            linked = True
            app_id = data.get("app_id") or data.get("id")
            app_name = data.get("app_name") or data.get("name")
            environment = data.get("environment") or "production"
            live_url = data.get("url") or (f"https://{app_name}.laravel.cloud" if app_name else None)
            last_deployment = data.get("last_deployment")
        except Exception:
            pass
    elif cloud_dir.is_dir() or cloud_yaml.is_file():
        linked = True
        app_name = root.name
        live_url = f"https://{root.name}.laravel.cloud"

    # Also check .env for LARAVEL_CLOUD_* variables
    env_file = root / ".env"
    if env_file.is_file():
        try:
            for line in env_file.read_text(encoding="utf-8", errors="replace").splitlines():
                line = line.strip()
                if line.startswith("LARAVEL_CLOUD_APP="):
                    app_name = line.split("=", 1)[1].strip().strip('"\'')
                    linked = True
                elif line.startswith("LARAVEL_CLOUD_URL="):
                    live_url = line.split("=", 1)[1].strip().strip('"\'')
                    linked = True
        except Exception:
            pass

    return {
        "linked": linked,
        "app_id": app_id,
        "app_name": app_name or (root.name if linked else None),
        "environment": environment,
        "url": live_url,
        "last_deployment": last_deployment,
    }


def link_project_cloud(project_path: str, app_name: str, environment: str = "production") -> Dict[str, Any]:
    """Links project directory to a Laravel Cloud application."""
    root = Path(project_path).resolve()
    cloud_dir = root / ".cloud"
    cloud_dir.mkdir(parents=True, exist_ok=True)
    cfg_file = cloud_dir / "config.json"

    clean_name = re.sub(r"[^a-zA-Z0-9_-]", "-", app_name.lower().strip())
    url = f"https://{clean_name}.laravel.cloud"

    data = {
        "app_name": clean_name,
        "environment": environment,
        "url": url,
        "linked_at": int(time.time()),
    }
    cfg_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return {"ok": True, "app_name": clean_name, "environment": environment, "url": url}


def deploy_project_cloud(
    project_path: str,
    environment: str = "production",
    branch: Optional[str] = None,
) -> Dict[str, Any]:
    """Executes the 3-Stage deployment pipeline: Prepare -> Build -> Release.

    Returns structured status for each stage, live URL, and execution logs.
    """
    root = Path(project_path).resolve()
    if not root.is_dir():
        return {"ok": False, "error": f"Project directory '{project_path}' does not exist."}

    stages: List[Dict[str, Any]] = []
    logs: List[str] = []
    cli_path = find_cloud_cli()

    app_name = root.name
    proj_status = get_project_cloud_status(str(root))
    if proj_status.get("app_name"):
        app_name = proj_status["app_name"]
    public_url = proj_status.get("url") or f"https://{app_name}.laravel.cloud"

    # --- STAGE 1: PREPARE ---
    t_start = time.time()
    logs.append(f"[{time.strftime('%H:%M:%S')}] [STAGE 1: PREPARE] Starting preflight checks for '{app_name}' ({environment})...")

    # Verify composer.json
    composer_file = root / "composer.json"
    if not composer_file.is_file():
        err = "composer.json not found in project root."
        logs.append(f"ERROR: {err}")
        stages.append({"name": "prepare", "status": "failed", "error": err, "duration_ms": int((time.time() - t_start) * 1000)})
        return {"ok": False, "stages": stages, "logs": logs, "error": err}

    # Verify git status
    git_dir = root / ".git"
    git_clean = True
    if git_dir.is_dir():
        try:
            p = subprocess.run(["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, timeout=5)
            if p.stdout.strip():
                git_clean = False
                logs.append("Notice: Local uncommitted changes detected; proceeding with current state.")
        except Exception:
            pass

    logs.append(f"Preflight checks passed (composer valid, git ready). Target environment: {environment}.")
    stages.append({
        "name": "prepare",
        "status": "completed",
        "duration_ms": int((time.time() - t_start) * 1000),
    })

    # --- STAGE 2: BUILD ---
    t_build = time.time()
    logs.append(f"[{time.strftime('%H:%M:%S')}] [STAGE 2: BUILD] Bundling project & triggering build...")

    build_success = True
    build_err = None

    cli_output = ""
    if not cli_path:
        # Never report a deployment that did not happen.
        build_success = False
        build_err = ("Laravel Cloud CLI is not installed. Install it (composer global require laravel/cloud-cli), "
                     "run `cloud auth`, then deploy again.")
        logs.append(f"ERROR: {build_err}")
    else:
        try:
            cmd = [cli_path, "deploy", f"--environment={environment}"]
            proc = subprocess.run(cmd, cwd=root, capture_output=True, text=True, timeout=900)
            cli_output = proc.stdout.strip()
            if cli_output:
                logs.append(cli_output)
            if proc.returncode != 0:
                build_success = False
                build_err = proc.stderr.strip() or cli_output[-500:] or f"cloud deploy exited with code {proc.returncode}."
                logs.append(f"Build error: {build_err}")
            else:
                m_url = re.search(r"https://[a-zA-Z0-9.-]+\.laravel\.cloud", proc.stdout)
                if m_url:
                    public_url = m_url.group(0)
        except Exception as e:
            build_success = False
            build_err = f"Could not run the Laravel Cloud CLI: {e}"
            logs.append(f"ERROR: {build_err}")

    if not build_success:
        stages.append({"name": "build", "status": "failed", "error": build_err, "duration_ms": int((time.time() - t_build) * 1000)})
        return {"ok": False, "stages": stages, "logs": logs, "error": build_err}

    stages.append({
        "name": "build",
        "status": "completed",
        "duration_ms": int((time.time() - t_build) * 1000),
    })

    # --- STAGE 3: RELEASE ---
    t_release = time.time()
    # Laravel Cloud runs the release (migrations, caches) itself; its CLI output above is the record.
    logs.append(f"[{time.strftime('%H:%M:%S')}] [STAGE 3: RELEASE] Laravel Cloud accepted the deployment.")
    if public_url:
        logs.append(f"Application URL: {public_url}")

    stages.append({
        "name": "release",
        "status": "completed",
        "duration_ms": int((time.time() - t_release) * 1000),
    })

    # Save last deployment metadata in .cloud/config.json
    try:
        cloud_dir = root / ".cloud"
        cloud_dir.mkdir(parents=True, exist_ok=True)
        cfg_file = cloud_dir / "config.json"
        existing = {}
        if cfg_file.is_file():
            try:
                existing = json.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception:
                pass
        existing.update({
            "app_name": app_name,
            "environment": environment,
            "url": public_url,
            "last_deployment": {
                "timestamp": int(time.time()),
                "status": "completed",
                "stages": stages,
                "url": public_url,
            },
        })
        cfg_file.write_text(json.dumps(existing, indent=2), encoding="utf-8")
    except Exception:
        pass

    return {
        "ok": True,
        "app_name": app_name,
        "environment": environment,
        "url": public_url,
        "stages": stages,
        "logs": logs,
    }
