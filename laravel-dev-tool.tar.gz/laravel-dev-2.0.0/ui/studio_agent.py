"""Studio Agent Engine for laravel-dev-tool.

Provides:
  - Local coding agent discovery (Claude Code, OpenCode, Antigravity CLI, Ollama, Cloud LLM)
  - Interactive Agent Chat runner in project context
  - Unified Diff generation and review before applying changes
  - Desktop notifications on task completion
  - Local voice dictation hooks (whisper.cpp / Web Speech API)
"""
from __future__ import annotations

import json
import os
import re
import shutil
import socket
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import ai_assistant
    import acp_client
    import studio_permissions
except ImportError:
    from ui import ai_assistant, acp_client, studio_permissions

# Read-only laravel-dev MCP tools the agents may call without asking (no .env / service writes).
READONLY_MCP_TOOLS = studio_permissions.READONLY_MCP_TOOLS


def _settings(ai_settings=None):
    """The app passes its own AISettings (it holds the vault that decrypts the API key)."""
    return ai_settings or ai_assistant.AISettings(Path.home() / ".config" / "laravel-dev")


def detect_installed_agents(ai_settings=None) -> List[Dict[str, Any]]:
    """Detects available local and cloud coding agents."""
    agents: List[Dict[str, Any]] = []

    claude_bin = shutil.which("claude")
    agents.append({
        "id": "claude", "name": "Claude Code", "kind": "cli", "installed": bool(claude_bin), "path": claude_bin,
        "source": "cli", "mcp": True,
        "description": "Claude Code CLI on this machine (your Claude plan or API key), with the laravel-dev MCP tools",
    })

    agy_bin = shutil.which("agy") or shutil.which("antigravity")
    agents.append({
        "id": "antigravity", "name": "Antigravity", "kind": "cli", "installed": bool(agy_bin), "path": agy_bin,
        "source": "cli", "mcp": False,
        "description": "Google Antigravity CLI (agy) with your Antigravity account and the MCP servers configured in agy",
    })

    opencode_bin = shutil.which("opencode")
    agents.append({
        "id": "opencode", "name": "OpenCode", "kind": "cli", "installed": bool(opencode_bin), "path": opencode_bin,
        "source": "cli", "mcp": False, "description": "OpenCode CLI with the providers configured in opencode",
    })

    ollama_running = False
    try:
        with socket.create_connection(("127.0.0.1", 11434), timeout=0.2):
            ollama_running = True
    except OSError:
        pass
    agents.append({
        "id": "ollama", "name": "Ollama (Local LLM)", "kind": "local_llm", "installed": ollama_running,
        "path": "http://127.0.0.1:11434", "source": "ollama", "mcp": False,
        "description": "Local offline model served by Ollama",
    })

    pub = _settings(ai_settings).public()
    provider = (pub.get("provider") or "ollama").lower()
    ready = ollama_running if provider == "ollama" else bool(pub.get("ready", pub.get("has_key")))
    label = ai_assistant.provider_label(provider)
    agents.append({
        "id": "cloud_llm", "name": f"{label} (AI settings)", "kind": "cloud_llm", "installed": ready,
        "path": provider, "source": "settings", "mcp": False, "model": pub.get("model") or "",
        "description": f"The provider chosen in Settings → AI ({label}{' · ' + pub['model'] if pub.get('model') else ''})",
    })
    return agents


def notify_agent_completion(site_name: str, message: str, title: str = "Studio Agent") -> None:
    """Dispatches a desktop notification via notify-send if available."""
    if shutil.which("notify-send"):
        try:
            subprocess.run(
                ["notify-send", "-a", "Laravel Dev", "-i", "utilities-terminal", title, f"[{site_name}] {message}"],
                check=False,
                timeout=3,
            )
        except Exception:
            pass


def transcribe_audio_whisper(audio_path: str) -> Dict[str, Any]:
    """Transcribes an audio recording using local whisper.cpp if available."""
    whisper_bin = shutil.which("whisper-cpp") or shutil.which("whisper") or shutil.which("main")
    if not whisper_bin:
        return {
            "ok": False,
            "error": "whisper.cpp binary not found in PATH. You can install whisper.cpp or use browser voice input.",
        }

    p = Path(audio_path).resolve()
    if not p.is_file():
        return {"ok": False, "error": f"Audio file '{audio_path}' does not exist."}

    try:
        proc = subprocess.run([whisper_bin, "-f", str(p), "--no-timestamps"], capture_output=True, text=True, timeout=60)
        if proc.returncode != 0:
            return {"ok": False, "error": proc.stderr.strip() or "Whisper transcription failed."}
        text = proc.stdout.strip()
        return {"ok": True, "text": text}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _git_status(root: Path) -> Dict[str, str]:
    try:
        g = subprocess.run(["git", "status", "--porcelain", "--untracked-files=all"], cwd=root,
                           capture_output=True, text=True, timeout=5)
    except Exception:
        return {}
    out = {}
    for line in g.stdout.splitlines():
        if len(line) > 3:
            out[line[3:].strip().strip('"')] = line[:2]
    return out


MODEL_RE = re.compile(r"^[A-Za-z0-9._:/@+-]{1,120}$")
_MODEL_CACHE: Dict[str, Any] = {}
MODEL_CACHE_SECONDS = 300

# Claude Code accepts these aliases (and full model ids) for --model.
CLAUDE_MODELS = [("opus", "Opus (latest)"), ("sonnet", "Sonnet (latest)"), ("haiku", "Haiku (latest)"),
                 ("opusplan", "Opus Plan (Opus plans, Sonnet writes)")]
# --effort of Claude Code: how long the model may think before it answers.
CLAUDE_EFFORTS = ["low", "medium", "high", "xhigh", "max"]
_CLAUDE_ID_RE = re.compile(rb"claude-(opus|sonnet|haiku|fable)-(\d+)-(\d)(?![\w-])")


def _claude_known_models(cli_bin: str) -> List[Dict[str, str]]:
    """The full model ids this Claude Code build knows (it has no `models` command), newest first:
    claude-opus-4-7 → "Opus 4.7". Read from the CLI's own executable, so it follows its updates."""
    import mmap
    try:
        with open(os.path.realpath(cli_bin), "rb") as fh, mmap.mmap(fh.fileno(), 0, access=mmap.ACCESS_READ) as mem:
            found = {(m.group(1).decode(), int(m.group(2)), int(m.group(3))) for m in _CLAUDE_ID_RE.finditer(mem)}
    except (OSError, ValueError):
        return []
    found = {f for f in found if f[1] >= 4}  # older generations are retired
    order = {"fable": 0, "opus": 1, "sonnet": 2, "haiku": 3}
    return [{"id": f"claude-{fam}-{major}-{minor}", "label": f"{fam.capitalize()} {major}.{minor}"}
            for fam, major, minor in sorted(found, key=lambda f: (order[f[0]], -f[1], -f[2]))]


def _opencode_models(cli_bin: str):
    """`opencode models` prints one provider/model per line. Returns (models, error)."""
    try:
        res = subprocess.run([cli_bin, "models"], capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return [], f"Could not list OpenCode models: {exc}"
    models = []
    for line in res.stdout.splitlines():
        mid = line.strip()
        if "/" in mid and MODEL_RE.fullmatch(mid):
            provider, _, name = mid.partition("/")
            models.append({"id": mid, "label": name, "group": provider})
    return models, ("" if models else (res.stderr.strip() or "opencode models returned nothing")[-300:])


def list_agent_models(agent_id: str, ai_settings=None, refresh: bool = False) -> Dict[str, Any]:
    """Models an agent can run with: {"models": [{"id", "label"}], "default": id, "selectable": bool}.
    "" as a model id means "the agent's own default"."""
    now = time.time()
    cached = _MODEL_CACHE.get(agent_id)
    if cached and not refresh and now - cached[0] < MODEL_CACHE_SECONDS:
        return cached[1]
    models: List[Dict[str, str]] = []
    default, error = "", ""
    if agent_id == "antigravity":
        agy = shutil.which("agy") or shutil.which("antigravity")
        if agy:
            try:
                res = subprocess.run([agy, "models"], capture_output=True, text=True, timeout=45)
                for line in res.stdout.splitlines():
                    mid, _, label = line.partition("\t")
                    mid = mid.strip()
                    if mid and MODEL_RE.fullmatch(mid) and not mid.lower().startswith("fetching"):
                        models.append({"id": mid, "label": label.strip() or mid})
                if not models:
                    error = (res.stderr.strip() or res.stdout.strip() or "agy models returned nothing")[-300:]
            except (OSError, subprocess.TimeoutExpired) as exc:
                error = f"Could not list Antigravity models: {exc}"
    elif agent_id == "claude":
        models = [{"id": mid, "label": label, "group": "Latest"} for mid, label in CLAUDE_MODELS]
        claude_bin = shutil.which("claude")
        if claude_bin:
            models += [{**m, "group": "Versions"} for m in _claude_known_models(claude_bin)]
    elif agent_id == "opencode":
        opencode_bin = shutil.which("opencode")
        models, error = _opencode_models(opencode_bin) if opencode_bin else ([], "OpenCode is not installed.")
    elif agent_id in ("ollama", "cloud_llm"):
        pub = _settings(ai_settings).public()
        if agent_id == "cloud_llm" and (pub.get("provider") or "ollama") != "ollama":
            # Cloud providers use the model chosen in Settings → AI.
            result = {"models": [], "default": pub.get("model") or "", "selectable": False, "error": ""}
            _MODEL_CACHE[agent_id] = (now, result)
            return result
        try:
            url = (pub.get("ollama_url") or "http://127.0.0.1:11434").rstrip("/") + "/api/tags"
            import urllib.request
            with urllib.request.urlopen(url, timeout=3) as resp:
                tags = json.loads(resp.read().decode("utf-8")).get("models") or []
            models = [{"id": m["name"], "label": m["name"]} for m in tags if MODEL_RE.fullmatch(m.get("name") or "")]
        except Exception as exc:
            error = f"Ollama is not reachable: {exc}"
        default = pub.get("model") or ""
    result = {"models": models, "default": default, "selectable": bool(models), "error": error,
              "efforts": CLAUDE_EFFORTS if agent_id == "claude" else []}
    if models:
        _MODEL_CACHE[agent_id] = (now, result)
    return result


# CLI agents that keep their own conversation and can resume it by id.
RESUMABLE_AGENTS = ("claude", "antigravity", "opencode")
AGY_DENIED = "Antigravity stopped without an answer:"
AGY_DENIED_RETRIES = 2
AGY_CONTINUE_PROMPT = ("That action is not allowed here, so it was denied. Do not try it again. Continue with the "
                       "original request using what is allowed (reading and listing files inside the project, "
                       "searching, the commands that worked), then give your answer.")
EFFORT_RE = re.compile(r"^(low|medium|high|xhigh|max)$")

# Antigravity cannot ask for permission in headless mode: a tool that needs it is denied and the turn
# ends without an answer. These rules (`command(<binary and subcommand>)`, matched word by word, and
# `mcp(<server>/<tool>)`) let it look around the project; "Allow file edits" adds project commands.
AGY_READONLY_COMMANDS = studio_permissions.READONLY_COMMANDS
AGY_EDIT_COMMANDS = ("php", "composer", "npm", "npx", "node", "git add", "git checkout", "git restore", "git stash",
                     "mkdir", "touch", "cp", "mv", "vendor/bin/pest", "vendor/bin/phpunit", "./vendor/bin/pest",
                     "./vendor/bin/phpunit", "vendor/bin/pint", "./vendor/bin/pint")


def _antigravity_permissions(allow_edits: bool) -> str:
    allow = [f"command({c})" for c in AGY_READONLY_COMMANDS + (AGY_EDIT_COMMANDS if allow_edits else ())]
    allow += [f"mcp(laravel-dev/{t})" for t in READONLY_MCP_TOOLS]
    return json.dumps({"permissions": {"allow": allow}})


def _antigravity_command(cli_bin: str, prompt: str, conversation_id: str, allow_edits: bool, model: str = "") -> List[str]:
    cmd = [cli_bin, "-p", prompt, "--output-format", "stream-json", "--print-timeout", "290s",
           "--settings", _antigravity_permissions(allow_edits)]
    if model:
        cmd += ["--model", model]
    if conversation_id:
        cmd += ["--conversation", conversation_id]
    if allow_edits:
        cmd += ["--mode", "accept-edits"]
    return cmd


def _opencode_command(cli_bin: str, prompt: str, session_id: str, allow_edits: bool, model: str = "") -> List[str]:
    """`opencode run --format json`: one JSON event per line. Without "Allow file edits" it runs as the
    read-only `plan` agent; with it as `build`, approving its tool calls (the changes can be reverted)."""
    cmd = [cli_bin, "run", "--format", "json", "--thinking"]
    if model:
        cmd += ["--model", model]
    if session_id:
        cmd += ["--session", session_id]
    cmd += ["--agent", "build", "--auto"] if allow_edits else ["--agent", "plan"]
    # Not "--": OpenCode then sends the message twice. A leading space keeps "-x…" from reading as a flag.
    return cmd + [(" " + prompt) if prompt.startswith("-") else prompt]


def _claude_command(cli_bin: str, prompt: str, session_id: str, allow_edits: bool, mcp_cli: str, model: str = "",
                    effort: str = "", interactive: bool = False) -> List[str]:
    """stream-json + partial messages: one JSON event per line, text arrives as it is written.
    interactive: the prompt goes to stdin as a stream-json message, and every permission request
    comes back as a `can_use_tool` control request that the app answers (--permission-prompt-tool stdio)."""
    if interactive:
        cmd = [cli_bin, "-p", "--input-format", "stream-json", "--permission-prompt-tool", "stdio",
               "--output-format", "stream-json", "--verbose", "--include-partial-messages"]
    else:
        cmd = [cli_bin, "-p", prompt, "--output-format", "stream-json", "--verbose", "--include-partial-messages"]
    if session_id:
        cmd += ["--resume", session_id]
    if model:
        cmd += ["--model", model]
    if effort:
        cmd += ["--effort", effort]
    allowed = []
    if mcp_cli:
        cmd += ["--mcp-config", json.dumps({"mcpServers": {"laravel-dev": {"command": mcp_cli, "args": ["mcp"]}}})]
        allowed += [f"mcp__laravel-dev__{t}" for t in READONLY_MCP_TOOLS]
    if allow_edits:
        cmd += ["--permission-mode", "acceptEdits"]
    if allowed:
        cmd += ["--allowedTools", ",".join(allowed)]
    return cmd


CLI_TIMEOUT = 300  # seconds of work; time spent waiting for the user's approval does not count
CLAUDE_DENY_MESSAGE = ("The user denied this in Laravel Dev Studio. Do not try it again another way. If the task "
                       "cannot be completed without it, stop now and say briefly what you would need.")


def _claude_permission(tool: str, inp: Dict[str, Any], root: Path):
    """(kind, title, detail, editable) of a Claude Code tool call."""
    tool = tool or "tool"
    if tool == "Bash":
        cmd = str(inp.get("command") or "")
        return "execute", str(inp.get("description") or "Run a command"), cmd, True
    if tool in ("Edit", "Write", "MultiEdit", "NotebookEdit"):
        path = str(inp.get("file_path") or inp.get("notebook_path") or "")
        return "edit", f"{'Create' if tool == 'Write' else 'Edit'} {_tool_detail({'path': path}, root)}", path, False
    if tool == "Read":
        return "read", "Read a file", str(inp.get("file_path") or ""), False
    if tool in ("Glob", "Grep", "LS"):
        return "search", f"{tool} files", str(inp.get("path") or ""), False
    if tool in ("WebFetch", "WebSearch"):
        return "fetch", "Use the web", str(inp.get("url") or inp.get("query") or ""), False
    if tool.startswith("mcp__"):
        return "mcp", f"Use {_tool_name(tool)}", _tool_detail(inp, root), False
    return "other", f"Use {tool}", _tool_detail(inp, root), False


def _acp_tool(data: Dict[str, Any], root: Path):
    """(name, detail) of an ACP tool call: agy sends name/args/rawInput, OpenCode name/rawInput/title."""
    raw = data.get("rawInput") if isinstance(data.get("rawInput"), dict) else data.get("args")
    raw = raw if isinstance(raw, dict) else {}
    name = str(data.get("name") or data.get("kind") or "tool")
    if raw.get("ServerName") and raw.get("ToolName"):  # Antigravity's call_mcp_tool
        return f"mcp__{raw['ServerName']}__{raw['ToolName']}", _tool_detail(raw.get("Arguments"), root)
    params = {k: v for k, v in raw.items() if k not in ("cwd", "toolSummary", "WaitMsBeforeAsync", "IsDaemon")}
    detail = _tool_detail(params, root)
    if not detail:
        locations = data.get("locations") or []
        path = locations[0].get("path") if locations and isinstance(locations[0], dict) else ""
        detail = _tool_detail({"path": path}, root) if path and Path(path) != root else str(data.get("title") or "")
    return name, detail


def _acp_permission_kind(tool_call: Dict[str, Any], root: Path):
    """(kind, tool, title, detail) of an ACP permission request."""
    name, detail = _acp_tool(tool_call, root)
    raw = tool_call.get("rawInput") if isinstance(tool_call.get("rawInput"), dict) else {}
    kind = str(tool_call.get("kind") or "other")
    if name.startswith("mcp__"):
        kind = "mcp"
    elif kind == "execute":
        detail = str(raw.get("command") or raw.get("CommandLine") or tool_call.get("title") or detail)
    elif kind in ("read", "edit", "delete", "move", "search"):
        path = next((raw.get(k) for k in ("filePath", "file_path", "path", "Path", "AbsolutePath", "TargetFile")
                     if isinstance(raw.get(k), str) and raw.get(k)), "")
        if not path:
            locations = tool_call.get("locations") or []
            path = locations[0].get("path", "") if locations and isinstance(locations[0], dict) else ""
        detail = path or detail
    args = raw.get("args") if isinstance(raw.get("args"), dict) else {}
    title = str(raw.get("toolSummary") or args.get("toolSummary") or tool_call.get("title") or _tool_name(name))
    return kind, name, title, detail


def _parse_antigravity_event(obj: Dict[str, Any]):
    """One line of `agy -p --output-format stream-json`. Returns (text, final_reply, conversation_id, error).

      {"event": "init", "conversation_id": …}
      {"event": "step_update", "step_update": {"step_type": "agent_response", "text_delta": "OK", …}}
      {"event": "result", "result": {"conversation_id", "status": "SUCCESS"|"ERROR", "response", "error"}}
    The plain `--output-format json` summary ({"conversation_id", "status", "response", "error"}) is
    accepted too."""
    event = obj.get("event")
    if event == "init":
        return "", None, obj.get("conversation_id") or "", ""
    if event == "step_update":
        su = obj.get("step_update") or {}
        text = su.get("text_delta") if su.get("step_type") == "agent_response" else ""
        error = su.get("error") if su.get("state") == "ERROR" else ""
        return (text if isinstance(text, str) else ""), None, su.get("conversation_id") or "", str(error or "")
    summary = obj.get("result") if event == "result" else (obj if "conversation_id" in obj and "status" in obj else None)
    if isinstance(summary, dict):
        status = str(summary.get("status") or "").upper()
        error = summary.get("error") or ("Antigravity reported an error." if status == "ERROR" else "")
        denied = [str(d.get("display_name") or d.get("action") or "") for d in summary.get("denied_actions") or []
                  if isinstance(d, dict)]
        if denied and not str(summary.get("response") or "").strip() and not error:
            error = (f"{AGY_DENIED} it needed permission for {', '.join(sorted(set(denied)))}, "
                     "which it cannot ask for when run from the app. Tick \"Allow file edits\" to let it run project "
                     "commands, or add an allow rule to ~/.gemini/antigravity-cli/settings.json "
                     "(permissions.allow, e.g. \"command(php artisan test)\").")
        return "", str(summary.get("response") or ""), summary.get("conversation_id") or "", str(error or "")
    if event == "error":
        return "", None, "", str(obj.get("error") or obj.get("message") or "Antigravity reported an error.")
    return "", None, "", ""


_DETAIL_KEYS = ("file_path", "path", "Path", "AbsolutePath", "TargetFile", "notebook_path", "command", "CommandLine",
                "pattern", "Pattern", "Query", "query", "url", "Url", "sql", "name", "description", "prompt")


def _short(text: str, limit: int = 160) -> str:
    text = " ".join(str(text or "").split())
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _tool_name(name: str) -> str:
    """mcp__laravel-dev__get_routes → laravel-dev: get_routes"""
    name = str(name or "tool")
    if name.startswith("mcp__"):
        server, _, tool = name[5:].partition("__")
        return f"{server}: {tool}" if tool else server
    return name


def _tool_detail(params: Any, root: Path) -> str:
    """The most telling argument of a tool call (the file, command, pattern…), paths relative to the site."""
    if not isinstance(params, dict):
        return ""
    value = next((params[k] for k in _DETAIL_KEYS if isinstance(params.get(k), str) and params[k].strip()), None)
    if value is None:
        value = next((v for v in params.values() if isinstance(v, str) and v.strip()), "")
    value = str(value).replace("file://", "")
    prefix = str(root) + os.sep
    return _short(value.replace(prefix, ""))


# Antigravity's run_command output starts with timestamps before the command output.
_SUMMARY_SKIP = re.compile(r"^(Created At:|Completed At:|Command output:|Command exited with code 0\.?$)")


def _tool_summary(content: Any) -> str:
    """First meaningful line of a tool result."""
    if isinstance(content, list):
        content = "\n".join(c.get("text", "") for c in content if isinstance(c, dict) and c.get("type") == "text")
    for line in str(content or "").splitlines():
        line = re.sub(r"^\s*\d+\t", "", line).strip()  # Read output is numbered: "12\tcode"
        if _SUMMARY_SKIP.match(line):
            continue
        if line and not line.startswith("<"):
            return _short(line, 140)
    return ""


class _ActivityStream:
    """Turns the event stream of an agent CLI into Studio activity events:

      {"kind": "status", "code": "starting" | "waiting" | "thinking"}  what the agent does right now
      {"kind": "thinking", "text": delta}                               its reasoning, streamed
      {"kind": "thought", "seconds": n}                                 it reasoned without showing the text
      {"kind": "tool", "id", "name", "detail", "state": "running" | "done" | "error", "summary"}
      {"kind": "note", "text"}                                          text it wrote between two tool calls

    `segment` collects the answer text since the last tool call: once the agent calls another
    tool, that text was a remark on its way, not the answer, and moves to the activity as a note."""

    def __init__(self, root: Path, on_delta, on_activity):
        self.root = root
        self.on_delta = on_delta
        self.on_activity = on_activity
        self.streamed: List[str] = []
        self.segment: List[str] = []
        self.steps: Dict[str, Dict[str, Any]] = {}  # Antigravity step_index -> what it showed

    def text(self, text: str):
        if text:
            self.streamed.append(text)
            self.segment.append(text)
            if self.on_delta:
                self.on_delta(text)

    def activity(self, **event):
        if self.on_activity:
            self.on_activity(event)

    def tool(self, tool_id: str, name: str, state: str, detail: str = "", summary: str = ""):
        note = "".join(self.segment).strip()
        if note:
            self.segment.clear()
            self.activity(kind="note", text=note, moved=True)
        self.activity(kind="tool", id=str(tool_id), name=_tool_name(name), detail=detail, state=state, summary=summary)

    # Claude Code: claude -p --output-format stream-json --verbose --include-partial-messages
    def claude(self, obj: Dict[str, Any]):
        kind = obj.get("type")
        if kind == "stream_event":
            ev = obj.get("event") or {}
            etype = ev.get("type")
            if etype == "content_block_delta":
                delta = ev.get("delta") or {}
                if delta.get("type") == "text_delta":
                    self.text(delta.get("text", ""))
                elif delta.get("type") == "thinking_delta" and delta.get("thinking"):
                    self.activity(kind="thinking", text=delta["thinking"])
            elif etype == "content_block_start":
                block = ev.get("content_block") or {}
                if block.get("type") == "tool_use":
                    self.tool(block.get("id"), block.get("name"), "running")
                elif block.get("type") in ("thinking", "redacted_thinking"):
                    self.activity(kind="status", code="thinking")
        elif kind == "assistant":
            for block in (obj.get("message") or {}).get("content") or []:
                if not isinstance(block, dict):
                    continue
                if block.get("type") == "tool_use":  # the complete arguments
                    self.tool(block.get("id"), block.get("name"), "running", _tool_detail(block.get("input"), self.root))
                elif block.get("type") == "text" and not self.streamed:  # no partial messages: the whole text at once
                    self.text(block.get("text", ""))
        elif kind == "user":
            for block in (obj.get("message") or {}).get("content") or []:
                if isinstance(block, dict) and block.get("type") == "tool_result":
                    self.activity(kind="tool", id=str(block.get("tool_use_id")), state="error" if block.get("is_error") else "done",
                                  summary=_tool_summary(block.get("content")))
        elif kind == "system" and obj.get("subtype") == "status" and obj.get("status") == "requesting":
            self.activity(kind="status", code="waiting")

    # Antigravity: agy -p --output-format stream-json
    def antigravity(self, obj: Dict[str, Any]):
        if obj.get("event") != "step_update":
            return
        su = obj.get("step_update") or {}
        step_type, state = su.get("step_type"), su.get("state")
        index = str(su.get("step_index", ""))
        seen = self.steps.setdefault(index, {})
        if step_type == "user_input":
            return
        if step_type == "agent_response":
            if su.get("text_delta"):
                seen["text"] = True
            elif state == "ACTIVE" and not seen.get("status"):
                seen["status"] = True
                self.activity(kind="status", code="thinking")
            if state == "DONE" and not seen.get("text"):
                thinking = (su.get("usage") or {}).get("thinking_tokens") or 0
                if thinking:
                    self.activity(kind="thought", seconds=round(float(su.get("duration_seconds") or 0), 1))
            return
        info = su.get("tool_info") or {}
        name = su.get("tool_name") or info.get("name") or str(step_type or "step")
        params = info.get("parameters")
        if isinstance(params, dict) and params.get("ServerName") and params.get("ToolName"):  # call_mcp_tool
            name = f"mcp__{params['ServerName']}__{params['ToolName']}"
            params = params.get("Arguments")
        tool_state = {"DONE": "done", "ERROR": "error"}.get(state, "running")
        summary = _tool_summary(su.get("error") or info.get("output") or "") if tool_state != "running" else ""
        self.tool(f"agy-{index}", name, tool_state, _tool_detail(params, self.root), summary)

    def antigravity_denied(self, obj: Dict[str, Any]):
        result = obj.get("result") if obj.get("event") == "result" else None
        for n, d in enumerate((result or {}).get("denied_actions") or []):
            if isinstance(d, dict):
                self.tool(f"agy-denied-{n}", str(d.get("display_name") or d.get("action") or "tool"), "error",
                          summary="Permission denied: it cannot be asked for in the app")

    # ACP (agy acp / opencode acp): the `update` of a session/update notification
    def acp(self, update: Dict[str, Any]):
        kind = update.get("sessionUpdate")
        if kind == "agent_message_chunk":
            self.text(acp_client.content_text(update.get("content")))
        elif kind == "agent_thought_chunk":
            text = acp_client.content_text(update.get("content"))
            if text:
                self.activity(kind="thinking", text=text)
        elif kind in ("tool_call", "tool_call_update"):
            tool_id = str(update.get("toolCallId") or "tool")
            seen = self.steps.setdefault(f"acp-{tool_id}", {})
            for k in ("name", "kind", "title", "rawInput", "args", "locations", "status"):
                if update.get(k):
                    seen[k] = update[k]
            name, detail = _acp_tool(seen, self.root)
            state = {"completed": "done", "failed": "error"}.get(seen.get("status"), "running")
            summary = ""
            if state != "running":
                out = update.get("rawOutput")
                if isinstance(out, dict):
                    out = out.get("output") or out.get("error") or ""
                summary = _tool_summary(acp_client.content_text(update.get("content")) or out or "")
            self.tool(tool_id, name, state, detail, summary)
        elif kind == "plan":
            entries = [e for e in update.get("entries") or [] if isinstance(e, dict)]
            text = "\n".join(f"{'☑' if e.get('status') == 'completed' else '☐'} {e.get('content', '')}" for e in entries)
            if text and text != self.steps.get("plan"):
                self.steps["plan"] = text
                self.activity(kind="note", text=text)

    # OpenCode: opencode run --format json
    def opencode(self, obj: Dict[str, Any]) -> str:
        """Returns an error message when the event is an error."""
        kind, part = obj.get("type"), obj.get("part") or {}
        if kind == "step_start":
            self.activity(kind="status", code="thinking")
        elif kind == "text":
            self.text(part.get("text") or "")
        elif kind == "reasoning" and part.get("text"):
            self.activity(kind="thinking", text=part["text"])
        elif kind == "tool_use":
            st = part.get("state") or {}
            state = {"completed": "done", "error": "error"}.get(st.get("status"), "running")
            summary = _tool_summary(st.get("error") or st.get("output") or "") if state != "running" else ""
            self.tool(part.get("callID") or part.get("id") or part.get("partID") or "tool", part.get("tool"), state,
                      _tool_detail(st.get("input"), self.root), summary)
        elif kind == "error":
            err = obj.get("error") or {}
            if isinstance(err, dict):
                data = err.get("data") if isinstance(err.get("data"), dict) else {}
                return str(data.get("message") or err.get("message") or err.get("name") or "OpenCode reported an error.")
            return str(err or "OpenCode reported an error.")
        return ""


def _run_cli_streaming(agent: Dict[str, Any], cmd: List[str], root: Path, session_id: str, on_delta, cancel,
                       on_activity=None, gate=None, stdin_prompt: Optional[str] = None):
    """Runs a CLI agent, forwards its text and activity as they arrive, and honours `cancel`
    (threading.Event). Returns (reply, session_id, error).

    stdin_prompt (Claude Code, interactive): the prompt is sent on stdin and `can_use_tool` control
    requests are answered through `gate` (studio_permissions.PermissionGate) while the agent waits."""
    import threading

    interactive = stdin_prompt is not None
    # stdin closed otherwise: OpenCode appends whatever it can read from stdin to the message.
    # PWD too: OpenCode takes its project directory from $PWD, not from the working directory.
    proc = subprocess.Popen(cmd, cwd=root, env={**os.environ, "PWD": str(root)},
                            stdin=subprocess.PIPE if interactive else subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1,
                            start_new_session=True)  # own process group: stopping kills its children too
    stopped = {"why": ""}

    def send(obj):
        try:
            proc.stdin.write(json.dumps(obj) + "\n")
            proc.stdin.flush()
        except (BrokenPipeError, ValueError, OSError):
            pass

    if interactive:
        send({"type": "control_request", "request_id": "init", "request": {"subtype": "initialize"}})
        send({"type": "user", "message": {"role": "user", "content": stdin_prompt}})

    def watchdog():
        started = time.monotonic()
        while proc.poll() is None:
            waiting = gate is not None and gate.waiting.is_set()
            worked = time.monotonic() - started - (gate.waited if gate is not None else 0)
            if cancel is not None and cancel.is_set():
                stopped["why"] = "cancel"
            elif not waiting and worked > CLI_TIMEOUT:
                stopped["why"] = "timeout"
            if stopped["why"]:
                try:
                    os.killpg(proc.pid, 15)
                    time.sleep(1.5)
                    if proc.poll() is None:
                        os.killpg(proc.pid, 9)
                except (ProcessLookupError, PermissionError):
                    pass
                return
            time.sleep(0.2)

    threading.Thread(target=watchdog, daemon=True).start()
    stream = _ActivityStream(root, on_delta, on_activity)
    final_text, error, raw_lines = None, "", []

    for line in proc.stdout:
        raw_lines.append(line)
        stripped = line.strip()
        if agent["id"] in ("claude", "antigravity", "opencode"):
            try:
                obj = json.loads(stripped)
            except ValueError:
                continue
            if not isinstance(obj, dict):
                continue
            if agent["id"] == "claude":
                if obj.get("type") == "control_request" and interactive:
                    send(_claude_control_response(obj, gate, root, cancel))
                    continue
                stream.claude(obj)
                if obj.get("type") == "result" and interactive:
                    try:
                        proc.stdin.close()  # one turn per run: closing stdin lets Claude Code exit
                    except OSError:
                        pass
                if obj.get("type") == "result":
                    final_text = str(obj.get("result") or "")
                    session_id = obj.get("session_id") or session_id
                    if obj.get("is_error"):
                        error = final_text or "Claude Code reported an error."
            elif agent["id"] == "opencode":
                oc_error = stream.opencode(obj)
                if oc_error:
                    error = oc_error
                session_id = obj.get("sessionID") or session_id
            else:
                stream.antigravity(obj)
                stream.antigravity_denied(obj)
                ag_text, ag_final, ag_session, ag_error = _parse_antigravity_event(obj)
                stream.text(ag_text)
                if ag_session:
                    session_id = ag_session
                if ag_final is not None:
                    final_text = ag_final
                if ag_error:
                    error = ag_error
        else:
            stream.text(line)
    proc.wait()
    stderr = proc.stderr.read() if proc.stderr else ""

    streamed = stream.streamed
    reply = (final_text if final_text is not None else "".join(streamed)).strip()
    if not reply and not streamed and agent["id"] not in ("claude", "antigravity", "opencode"):
        reply = "".join(raw_lines).strip()
    if stopped["why"] == "cancel":
        return reply, session_id, ai_assistant.CANCELLED
    if stopped["why"] == "timeout":
        return reply, session_id, f"{agent['name']} did not finish within {CLI_TIMEOUT // 60} minutes."
    if proc.returncode != 0 and not error:
        error = (stderr.strip() or reply or f"{agent['name']} exited with code {proc.returncode}")[-2000:]
    return reply, session_id, error


def _claude_control_response(obj: Dict[str, Any], gate, root: Path, cancel) -> Dict[str, Any]:
    req = obj.get("request") or {}
    req_id = obj.get("request_id")
    if req.get("subtype") != "can_use_tool" or gate is None:
        return {"type": "control_response", "response": {"subtype": "error", "request_id": req_id,
                                                         "error": f"{req.get('subtype')} is not supported"}}
    tool, inp = str(req.get("tool_name") or "tool"), req.get("input") if isinstance(req.get("input"), dict) else {}
    kind, title, detail, editable = _claude_permission(tool, inp, root)
    answer = gate.decide(kind, tool, title, detail, editable)
    if answer["decision"] in ("allow", "always"):
        updated = dict(inp)
        if answer.get("input") and tool == "Bash":
            updated["command"] = answer["input"]  # the user changed the command before approving it
        result = {"behavior": "allow", "updatedInput": updated}
    elif answer["decision"] == "cancel":
        result = {"behavior": "deny", "message": "Stopped by the user.", "interrupt": True}
    else:
        result = {"behavior": "deny", "message": CLAUDE_DENY_MESSAGE}
    return {"type": "control_response", "response": {"subtype": "success", "request_id": req_id, "response": result}}


# ---------- ACP agents (agy acp, opencode acp) ----------
USE_ACP = True
ACP_LOAD_TIMEOUT = 45
QUOTA_RE = re.compile(r"quota (reached|exceeded)|rate.?limit", re.I)


class AcpUnavailable(Exception):
    """The agent has no working ACP server: Studio falls back to its headless mode."""


def _acp_env(agent_id: str, root: Path, allow_edits: bool) -> Dict[str, str]:
    env = {**os.environ, "PWD": str(root)}
    if agent_id == "opencode":
        # OpenCode allows commands by default; make it ask (Studio approves harmless ones by itself).
        env["OPENCODE_CONFIG_CONTENT"] = json.dumps({"permission": {
            "edit": "allow" if allow_edits else "ask", "bash": "ask", "webfetch": "ask", "external_directory": "ask"}})
    return env


def _acp_answer(params: Dict[str, Any], gate, root: Path) -> Optional[str]:
    """optionId for a session/request_permission, None = cancelled."""
    tool_call = params.get("toolCall") if isinstance(params.get("toolCall"), dict) else {}
    options = [o for o in params.get("options") or [] if isinstance(o, dict) and o.get("optionId")]
    kind, tool, title, detail = _acp_permission_kind(tool_call, root)
    answer = gate.decide(kind, tool, title, detail) if gate is not None else {"decision": "deny"}

    def pick(*kinds):
        return next((o["optionId"] for k in kinds for o in options if o.get("kind") == k), None)

    if answer["decision"] == "always":
        return pick("allow_always", "allow_once")
    if answer["decision"] == "allow":
        return pick("allow_once", "allow_always")
    if answer["decision"] == "deny":
        return pick("reject_once", "reject_always")
    return None


def _run_acp(agent: Dict[str, Any], root: Path, prompt: str, fresh_prompt: str, session_id: str, model: str,
             allow_edits: bool, on_delta, cancel, activity, gate):
    """One turn with an ACP agent. Returns (reply, session_id, error). fresh_prompt (the prompt with the
    recent messages) is sent when the earlier session cannot be reopened."""
    import threading

    try:
        conn = acp_client.AcpConnection([agent["path"], "acp"], str(root), env=_acp_env(agent["id"], root, allow_edits))
    except OSError as exc:
        raise AcpUnavailable(str(exc)) from exc
    try:
        try:
            conn.initialize()
        except acp_client.AcpError as exc:
            raise AcpUnavailable(str(exc)) from exc
        stream = _ActivityStream(root, on_delta, activity)
        sid, text = "", prompt
        if session_id:
            try:  # replays the history as updates: not shown (on_update is not set yet)
                conn.request("session/load", {"sessionId": session_id, "cwd": str(root), "mcpServers": []},
                             timeout=ACP_LOAD_TIMEOUT)
                sid = session_id
            except acp_client.AcpError:
                activity({"kind": "note", "text": "The earlier session could not be reopened; a new one was started with the recent messages."})
        if not sid:
            sid = str(conn.request("session/new", {"cwd": str(root), "mcpServers": []}, timeout=60).get("sessionId") or "")
            text = fresh_prompt
        if model:
            if agent["id"] == "opencode":
                conn.request("session/set_config_option", {"sessionId": sid, "configId": "model", "value": model}, timeout=30)
            else:
                conn.request("session/set_model", {"sessionId": sid, "modelId": model}, timeout=30)
        if allow_edits and agent["id"] == "antigravity":
            try:
                conn.request("session/set_mode", {"sessionId": sid, "modeId": "accept-edits"}, timeout=30)
            except acp_client.AcpError:
                pass
        conn.on_update = stream.acp
        conn.on_permission = lambda params: _acp_answer(params, gate, root)

        outcome: Dict[str, Any] = {}

        def prompt_turn():
            try:
                outcome["result"] = conn.request("session/prompt", {"sessionId": sid, "prompt": [{"type": "text", "text": text}]})
            except acp_client.AcpError as exc:
                outcome["error"] = str(exc)

        worker = threading.Thread(target=prompt_turn, daemon=True)
        worker.start()
        started, stop_sent, why = time.monotonic(), 0.0, ""
        while worker.is_alive():
            worker.join(0.2)
            now = time.monotonic()
            if not why and cancel is not None and cancel.is_set():
                why = "cancel"
            elif not why and gate is not None and not gate.waiting.is_set() and now - started - gate.waited > CLI_TIMEOUT:
                why = "timeout"
            if why and not stop_sent:
                stop_sent = now
                try:
                    conn.notify("session/cancel", {"sessionId": sid})
                except acp_client.AcpError:
                    break
            if stop_sent and now - stop_sent > 8:
                break  # it did not stop: closing the connection kills it
        segment = "".join(stream.segment).strip()
        # After a denied permission the earlier text was only a remark on the way to it.
        reply = segment if gate is not None and gate.denied else (segment or "".join(stream.streamed).strip())
        if why == "cancel":
            return reply, sid, ai_assistant.CANCELLED
        if why == "timeout":
            return reply, sid, f"{agent['name']} did not finish within {CLI_TIMEOUT // 60} minutes."
        if "error" in outcome:
            return reply, sid, outcome["error"]
        stop = str((outcome.get("result") or {}).get("stopReason") or "")
        if reply and QUOTA_RE.search(reply) and len(reply) < 400:
            return "", sid, reply.strip(" ⚠\n")
        if stop == "cancelled" and gate is not None and gate.denied:
            return reply, sid, ""  # it stopped because the user said no: not an error
        if stop == "refusal":
            return reply, sid, f"{agent['name']} refused to continue."
        if stop in ("max_tokens", "max_turn_requests"):
            return reply, sid, f"{agent['name']} stopped: it reached its limit ({stop})."
        return reply, sid, ""
    finally:
        conn.close()


MAX_ACTIVITY = 200
MAX_THINKING = 8000


def _record_activity(log: List[Dict[str, Any]], event: Dict[str, Any]) -> None:
    """Keeps a compact copy of a turn's activity, saved with the answer in the conversation."""
    kind = event.get("kind")
    if kind == "status":
        return
    if kind == "thinking":
        if log and log[-1].get("kind") == "thinking":
            if len(log[-1]["text"]) < MAX_THINKING:
                log[-1]["text"] = (log[-1]["text"] + event.get("text", ""))[:MAX_THINKING]
            return
        event = {"kind": "thinking", "text": str(event.get("text", ""))[:MAX_THINKING]}
    elif kind == "tool":
        for item in reversed(log):
            if item.get("kind") == "tool" and item.get("id") == event.get("id"):
                item.update({k: v for k, v in event.items() if v})
                return
        event = dict(event)
    elif kind == "note":
        event = {"kind": "note", "text": _short(event.get("text", ""), 600)}
    else:
        event = dict(event)
    if len(log) < MAX_ACTIVITY:
        log.append(event)


def run_studio_agent_task(
    project_path: str,
    prompt: str,
    agent_id: str = "auto",
    context_type: str = "general",
    conversation: Optional[Dict[str, Any]] = None,
    ai_settings=None,
    allow_edits: bool = False,
    mcp_cli: str = "",
    on_delta=None,
    cancel=None,
    model: str = "",
    on_activity=None,
    think: bool = False,
    effort: str = "",
    ask_permission=None,
    always_allowed=None,
) -> Dict[str, Any]:
    """Runs one turn of a Studio conversation in the site's directory.

    Who answers is reported in `agent`, `source` ("cli" | "settings" | "ollama" | "none") and `via_mcp`.
    `conversation` gives the earlier turns: Claude Code resumes its own session, other agents get
    the recent messages prepended to the prompt.

    `on_activity(event)` receives what the agent does on the way (thinking, tool calls; see
    _ActivityStream); the same steps come back, compacted, in `activity`. `think` lets an
    Ollama thinking model reason first (slower) and shows that reasoning.

    `ask_permission(request) -> answer` is called when the agent wants to do something that needs the
    user's approval (see studio_permissions); it blocks until the user answers and the agent waits.
    Without it such requests are denied. `always_allowed` is the set of requests the user approved for
    the whole conversation."""
    started = time.monotonic()
    activity_log: List[Dict[str, Any]] = []

    def activity(event: Dict[str, Any]) -> None:
        _record_activity(activity_log, event)
        if on_activity:
            on_activity(event)

    root = Path(project_path).resolve()
    if not root.is_dir():
        return {"ok": False, "error": f"Project directory '{project_path}' does not exist."}

    site_name = root.name
    agents = detect_installed_agents(ai_settings)
    by_id = {a["id"]: a for a in agents}

    selected = by_id.get(agent_id) if agent_id and agent_id != "auto" else None
    if selected is not None and not selected["installed"]:
        return {"ok": False, "error": f"{selected['name']} is not available on this machine."}
    if selected is None:
        # Auto: the AI chosen in Settings first (that is what the user configured), then local agents.
        for preferred in ("cloud_llm", "claude", "antigravity", "opencode", "ollama"):
            if by_id.get(preferred, {}).get("installed"):
                selected = by_id[preferred]
                break
    if selected is None:
        return {"ok": True, "site": site_name, "agent": "None", "agent_id": "none", "source": "none", "via_mcp": False,
                "prompt": prompt, "diff": "", "files_changed": [], "file_status": {}, "session_id": "",
                "reply": ("No AI is available. Choose a provider in Settings → AI, install Claude Code "
                          "(npm i -g @anthropic-ai/claude-code) or OpenCode, or run Ollama.")}

    model = (model or "").strip()
    if model and not MODEL_RE.fullmatch(model):
        return {"ok": False, "error": f"Invalid model name: {model}"}
    effort = (effort or "").strip().lower()
    if effort and not EFFORT_RE.fullmatch(effort):
        return {"ok": False, "error": f"Invalid effort level: {effort}"}
    conversation = conversation or {}
    # A Claude Code session can only be resumed by the agent that created it.
    session_id = (conversation.get("session_id") or "") if conversation.get("agent_id") == selected["id"] else ""
    reply, diff_text, error = "", "", ""
    files_changed: List[str] = []
    file_status: Dict[str, str] = {}
    via_mcp = False

    activity({"kind": "status", "code": "starting", "agent": selected["name"]})
    gate = studio_permissions.PermissionGate(root, selected["name"], ask_permission, cancel, always_allowed, activity)
    acp_done = False
    if selected["kind"] == "cli":
        cli_bin = selected["path"]
        before = _git_status(root)
        try:
            if selected["id"] in ("antigravity", "opencode") and USE_ACP:
                # ACP: the agent can ask for permission and wait for the answer (headless it cannot).
                try:
                    reply, session_id, error = _run_acp(selected, root, prompt, _history_prompt(conversation, prompt),
                                                        session_id, model, allow_edits, on_delta, cancel, activity, gate)
                    acp_done = True
                except AcpUnavailable:
                    activity({"kind": "note", "text": f"{selected['name']} has no ACP server here; it runs without asking for permissions."})
            if acp_done:
                pass
            elif selected["id"] == "claude":
                interactive = gate.interactive
                cmd = _claude_command(cli_bin, prompt, session_id, allow_edits, mcp_cli, model, effort, interactive)
                via_mcp = bool(mcp_cli)
            elif selected["id"] == "antigravity":
                cmd = _antigravity_command(cli_bin, prompt, session_id, allow_edits, model)
            else:
                # A resumed OpenCode session already holds the earlier turns.
                cmd = _opencode_command(cli_bin, prompt if session_id else _history_prompt(conversation, prompt),
                                        session_id, allow_edits, model)
            if not acp_done:
                reply, session_id, error = _run_cli_streaming(
                    selected, cmd, root, session_id, on_delta, cancel, activity, gate,
                    stdin_prompt=prompt if selected["id"] == "claude" and gate.interactive else None)
            # Antigravity ends the turn when a command is denied (it cannot ask in headless mode):
            # continue the same conversation, telling it to do without that command.
            retries = 0
            while (not acp_done and selected["id"] == "antigravity" and error.startswith(AGY_DENIED) and session_id
                   and retries < AGY_DENIED_RETRIES and not (cancel is not None and cancel.is_set())):
                retries += 1
                activity({"kind": "note", "text": "That action is not allowed from the app — Antigravity was asked to continue without it."})
                cmd = _antigravity_command(cli_bin, AGY_CONTINUE_PROMPT, session_id, allow_edits, model)
                reply, session_id, error = _run_cli_streaming(selected, cmd, root, session_id, on_delta, cancel, activity)
        except Exception as e:
            error = f"Error executing {selected['name']}: {e}"

        after = _git_status(root)
        for path, status in after.items():
            if before.get(path) != status:
                files_changed.append(path)
                file_status[path] = status
        if files_changed:
            tracked = [f for f in files_changed if file_status[f] != "??"]
            if tracked:
                try:
                    d = subprocess.run(["git", "diff", "--", *tracked], cwd=root, capture_output=True, text=True, timeout=5)
                    diff_text = d.stdout.strip()
                except Exception:
                    pass
            new_files = [f for f in files_changed if file_status[f] == "??"]
            if new_files:
                diff_text += ("\n" if diff_text else "") + "\n".join(f"new file: {f}" for f in new_files)
    else:
        cfg_obj = _settings(ai_settings)
        try:
            call_cfg = cfg_obj.call_config()
        except Exception as exc:
            # Never switch to another provider silently (it used to fall back to Ollama).
            call_cfg = None
            error = str(exc)
        if call_cfg is not None:
            if selected["id"] == "ollama":
                call_cfg = {**call_cfg, "provider": "ollama", "model": call_cfg.get("model") if call_cfg.get("provider") == "ollama" else ""}
            if model and call_cfg.get("provider") == "ollama":
                call_cfg = {**call_cfg, "model": model}
            if think and call_cfg.get("provider") == "ollama":
                call_cfg = {**call_cfg, "think": True}
            enhanced = (
                f"You are a coding assistant inside Laravel Dev Studio working on the Laravel project '{site_name}'.\n"
                "Answer the request. When you propose code, say which file it belongs to and give the complete code "
                "in a fenced block.\n\n" + _history_prompt(conversation, prompt)
            )
            activity({"kind": "status", "code": "waiting"})
            llm_reply, err = ai_assistant.ask_llm(enhanced, call_cfg, on_delta=on_delta, cancel=cancel,
                                                  on_thinking=lambda text: activity({"kind": "thinking", "text": text}))
            reply = (llm_reply or "").strip()
            if err:
                error = err
            elif not reply:
                error = "The AI provider returned no answer."

    cancelled = error == ai_assistant.CANCELLED
    if error and not reply:
        reply = error
    if gate.denied and not error and not reply.strip():
        reply = (f"Stopped: the task needs {', '.join(gate.denied)}, which you did not allow. "
                 "Send another message to continue (and allow it when asked).")
    notify_agent_completion(site_name, (f"Completed: {prompt[:60]}…" if len(prompt) > 60 else f"Completed: {prompt}")
                            if not error else f"Failed: {error[:80]}")

    return {
        "ok": not error,
        "error": error,
        "cancelled": cancelled,
        "site": site_name,
        "agent": selected["name"],
        "agent_id": selected["id"],
        "model": model,
        "effort": effort if selected["id"] == "claude" else "",
        "source": selected["source"],
        "via_mcp": via_mcp,
        "prompt": prompt,
        "reply": reply,
        "diff": diff_text,
        "files_changed": files_changed,
        "file_status": file_status,
        "session_id": session_id if selected["id"] in RESUMABLE_AGENTS else "",
        "activity": activity_log,
        "denied": gate.denied,
        "duration": round(time.monotonic() - started, 1),
    }


def _history_prompt(conversation: Dict[str, Any], prompt: str) -> str:
    try:
        import studio_history
    except ImportError:
        from ui import studio_history
    return studio_history.context_prompt(conversation or {}, prompt)


def revert_agent_changes(project_path: str, file_status: Dict[str, str]) -> Dict[str, Any]:
    """Undoes the files a Studio agent run changed: tracked files are restored from git,
    files it created are deleted. Only paths inside the project are touched."""
    root = Path(project_path).resolve()
    reverted, errors = [], []
    for rel, status in (file_status or {}).items():
        target = (root / rel).resolve()
        if target != root and root not in target.parents:
            errors.append(f"{rel}: outside the project")
            continue
        try:
            if status == "??":
                if target.is_file():
                    target.unlink()
            else:
                subprocess.run(["git", "checkout", "--", rel], cwd=root, check=True, capture_output=True, text=True, timeout=10)
            reverted.append(rel)
        except subprocess.CalledProcessError as exc:
            errors.append(f"{rel}: {exc.stderr.strip()}")
        except OSError as exc:
            errors.append(f"{rel}: {exc}")
    return {"ok": not errors, "reverted": reverted, "errors": errors}
