"""Visual Package Hub Engine for Laravel Dev (Composer & NPM).

Provides package inspection, outdated package checking, vulnerability auditing,
and package management (update, install, remove) for both PHP (Composer) and Node.js (NPM).
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

OUTDATED_CACHE: dict[str, dict[str, Any]] = {}
AUDIT_CACHE: dict[str, dict[str, Any]] = {}


def _find_bin(name: str) -> str:
    found = shutil.which(name)
    if found:
        return found
    home = Path.home()
    candidates = [
        Path("/usr/local/bin") / name,
        Path("/usr/bin") / name,
        home / ".local" / "bin" / name,
        home / ".config" / "herd-lite" / "bin" / name,
        home / ".volta" / "bin" / name,
        home / ".local" / "share" / "pnpm" / name,
        home / ".bun" / "bin" / name,
    ]
    for cand in candidates:
        if cand.is_file() and os.access(str(cand), os.X_OK):
            return str(cand)
    return name


def _is_php_script(path: str) -> bool:
    if path.lower().endswith(".phar"):
        return True
    try:
        with open(path, "rb") as handle:
            head = handle.read(160)
        return b"php" in head.splitlines()[0].lower() if head else False
    except OSError:
        return False


def _composer_base_cmd(php_bin: str, composer_bin: str) -> list[str]:
    if sys.platform.startswith("win") or not _is_php_script(composer_bin):
        return [composer_bin]
    resolved_php = shutil.which(php_bin) or _find_bin("php") if php_bin == "php" else (shutil.which(php_bin) or php_bin)
    return [resolved_php, "-d", "memory_limit=-1", composer_bin]


def list_packages(site_path: str, php_bin: str = "php") -> dict[str, Any]:
    sp = Path(site_path).resolve()
    has_composer = (sp / "composer.json").is_file()
    has_npm = (sp / "package.json").is_file()

    composer_packages = []
    npm_packages = []

    # 1. Composer
    if has_composer:
        direct_req = {}
        direct_dev = {}
        try:
            cj = json.loads((sp / "composer.json").read_text(encoding="utf-8", errors="replace"))
            direct_req = cj.get("require", {})
            direct_dev = cj.get("require-dev", {})
        except Exception:
            pass

        lock_pkgs = {}
        lock_file = sp / "composer.lock"
        if lock_file.is_file():
            try:
                c_lock = json.loads(lock_file.read_text(encoding="utf-8", errors="replace"))
                for p in c_lock.get("packages", []):
                    pkg_name = p.get("name", "")
                    if not pkg_name:
                        continue
                    lock_pkgs[pkg_name] = {
                        "name": pkg_name,
                        "version": p.get("version", "").lstrip("v"),
                        "description": p.get("description", ""),
                        "license": p.get("license", ["Unknown"])[0] if isinstance(p.get("license"), list) and p.get("license") else (p.get("license") or "Unknown"),
                        "type": "prod",
                        "direct": pkg_name in direct_req,
                        "constraint": direct_req.get(pkg_name, ""),
                        "homepage": p.get("homepage") or (p.get("source", {}).get("url") if isinstance(p.get("source"), dict) else f"https://packagist.org/packages/{pkg_name}"),
                    }
                for p in c_lock.get("packages-dev", []):
                    pkg_name = p.get("name", "")
                    if not pkg_name:
                        continue
                    lock_pkgs[pkg_name] = {
                        "name": pkg_name,
                        "version": p.get("version", "").lstrip("v"),
                        "description": p.get("description", ""),
                        "license": p.get("license", ["Unknown"])[0] if isinstance(p.get("license"), list) and p.get("license") else (p.get("license") or "Unknown"),
                        "type": "dev",
                        "direct": pkg_name in direct_dev,
                        "constraint": direct_dev.get(pkg_name, ""),
                        "homepage": p.get("homepage") or (p.get("source", {}).get("url") if isinstance(p.get("source"), dict) else f"https://packagist.org/packages/{pkg_name}"),
                    }
            except Exception:
                pass

        if lock_pkgs:
            composer_packages = sorted(lock_pkgs.values(), key=lambda x: (not x["direct"], x["name"].lower()))
        else:
            for k, v in direct_req.items():
                if k.lower() == "php" or k.startswith("ext-"):
                    continue
                composer_packages.append({
                    "name": k,
                    "version": v.lstrip("^~"),
                    "description": "",
                    "license": "Unknown",
                    "type": "prod",
                    "direct": True,
                    "constraint": v,
                    "homepage": f"https://packagist.org/packages/{k}",
                })
            for k, v in direct_dev.items():
                composer_packages.append({
                    "name": k,
                    "version": v.lstrip("^~"),
                    "description": "",
                    "license": "Unknown",
                    "type": "dev",
                    "direct": True,
                    "constraint": v,
                    "homepage": f"https://packagist.org/packages/{k}",
                })

    # 2. NPM
    if has_npm:
        direct_npm_req = {}
        direct_npm_dev = {}
        try:
            pj = json.loads((sp / "package.json").read_text(encoding="utf-8", errors="replace"))
            direct_npm_req = pj.get("dependencies", {})
            direct_npm_dev = pj.get("devDependencies", {})
        except Exception:
            pass

        npm_lock_file = sp / "package-lock.json"
        npm_lock_pkgs = {}
        if npm_lock_file.is_file():
            try:
                n_lock = json.loads(npm_lock_file.read_text(encoding="utf-8", errors="replace"))
                packages_v3 = n_lock.get("packages", {})
                if packages_v3:
                    for pkg_path, pdata in packages_v3.items():
                        if not pkg_path:
                            continue
                        pkg_name = pkg_path.split("node_modules/")[-1] if "node_modules/" in pkg_path else pkg_path
                        if not pkg_name:
                            continue
                        is_dev = bool(pdata.get("dev", False)) or pkg_name in direct_npm_dev
                        npm_lock_pkgs[pkg_name] = {
                            "name": pkg_name,
                            "version": pdata.get("version", "").lstrip("^~"),
                            "description": "",
                            "license": pdata.get("license", "Unknown"),
                            "type": "dev" if is_dev else "prod",
                            "direct": (pkg_name in direct_npm_req or pkg_name in direct_npm_dev),
                            "constraint": direct_npm_req.get(pkg_name) or direct_npm_dev.get(pkg_name) or "",
                            "homepage": f"https://www.npmjs.com/package/{pkg_name}",
                        }
                else:
                    dependencies_v1 = n_lock.get("dependencies", {})
                    for pkg_name, pdata in dependencies_v1.items():
                        is_dev = bool(pdata.get("dev", False)) or pkg_name in direct_npm_dev
                        npm_lock_pkgs[pkg_name] = {
                            "name": pkg_name,
                            "version": pdata.get("version", "").lstrip("^~"),
                            "description": "",
                            "license": "Unknown",
                            "type": "dev" if is_dev else "prod",
                            "direct": (pkg_name in direct_npm_req or pkg_name in direct_npm_dev),
                            "constraint": direct_npm_req.get(pkg_name) or direct_npm_dev.get(pkg_name) or "",
                            "homepage": f"https://www.npmjs.com/package/{pkg_name}",
                        }
            except Exception:
                pass

        if npm_lock_pkgs:
            npm_packages = sorted(npm_lock_pkgs.values(), key=lambda x: (not x["direct"], x["name"].lower()))
        else:
            for k, v in direct_npm_req.items():
                npm_packages.append({
                    "name": k,
                    "version": v.lstrip("^~"),
                    "description": "",
                    "license": "Unknown",
                    "type": "prod",
                    "direct": True,
                    "constraint": v,
                    "homepage": f"https://www.npmjs.com/package/{k}",
                })
            for k, v in direct_npm_dev.items():
                npm_packages.append({
                    "name": k,
                    "version": v.lstrip("^~"),
                    "description": "",
                    "license": "Unknown",
                    "type": "dev",
                    "direct": True,
                    "constraint": v,
                    "homepage": f"https://www.npmjs.com/package/{k}",
                })

    return {
        "ok": True,
        "has_composer": has_composer,
        "has_npm": has_npm,
        "composer_packages": composer_packages,
        "npm_packages": npm_packages,
        "composer_count": len(composer_packages),
        "npm_count": len(npm_packages),
    }


def check_outdated(site_path: str, php_bin: str = "php", force: bool = False) -> dict[str, Any]:
    sp = Path(site_path).resolve()
    cache_key = str(sp)
    now = time.time()
    if not force and cache_key in OUTDATED_CACHE:
        entry = OUTDATED_CACHE[cache_key]
        if now - entry["time"] < 120:
            return entry["data"]

    composer_bin = _find_bin("composer")
    npm_bin = _find_bin("npm")
    is_win = sys.platform.startswith("win")

    composer_outdated = []
    npm_outdated = []

    # Composer outdated
    if (sp / "composer.json").is_file():
        try:
            cmd = _composer_base_cmd(php_bin, composer_bin) + ["outdated", "--direct", "--format=json", "--no-interaction"]
            proc = subprocess.run(cmd, cwd=str(sp), stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=40)
            raw = proc.stdout.strip()
            if raw:
                data = json.loads(raw)
                for item in data.get("installed", []):
                    composer_outdated.append({
                        "name": item.get("name"),
                        "version": item.get("version"),
                        "latest": item.get("latest"),
                        "status": item.get("latest-status", "update-possible"),
                        "description": item.get("description", ""),
                    })
        except Exception:
            pass

    # NPM outdated
    if (sp / "package.json").is_file():
        try:
            proc = subprocess.run([npm_bin, "outdated", "--json"], cwd=str(sp), capture_output=True, text=True, timeout=40)
            raw = proc.stdout.strip()
            if raw:
                data = json.loads(raw)
                for pkg_name, pinfo in data.items():
                    npm_outdated.append({
                        "name": pkg_name,
                        "current": pinfo.get("current", ""),
                        "wanted": pinfo.get("wanted", ""),
                        "latest": pinfo.get("latest", ""),
                        "type": pinfo.get("type", "dependencies"),
                    })
        except Exception:
            pass

    res = {
        "ok": True,
        "composer_outdated": composer_outdated,
        "npm_outdated": npm_outdated,
        "composer_outdated_count": len(composer_outdated),
        "npm_outdated_count": len(npm_outdated),
    }
    OUTDATED_CACHE[cache_key] = {"time": now, "data": res}
    return res


def audit_packages(site_path: str, php_bin: str = "php", force: bool = False) -> dict[str, Any]:
    sp = Path(site_path).resolve()
    cache_key = str(sp)
    now = time.time()
    if not force and cache_key in AUDIT_CACHE:
        entry = AUDIT_CACHE[cache_key]
        if now - entry["time"] < 300:
            return entry["data"]

    composer_bin = _find_bin("composer")
    npm_bin = _find_bin("npm")
    is_win = sys.platform.startswith("win")

    has_composer = (sp / "composer.json").is_file()
    has_npm = (sp / "package.json").is_file()

    advisories = []
    npm_advisories = []
    npm_vulnerabilities = 0

    if has_composer:
        try:
            cmd = _composer_base_cmd(php_bin, composer_bin) + ["audit", "--format=json", "--no-interaction"]
            proc = subprocess.run(cmd, cwd=str(sp), stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=40)
            raw = proc.stdout.strip()
            if raw:
                try:
                    data = json.loads(raw)
                    adv_map = data.get("advisories", {})
                    for pkg, adv_list in adv_map.items():
                        for adv in adv_list:
                            advisories.append({
                                "package": pkg,
                                "title": adv.get("title") or "Security vulnerability",
                                "cve": adv.get("cve") or "",
                                "link": adv.get("link") or "",
                                "affected": adv.get("affectedVersions") or "",
                                "severity": adv.get("severity") or "warning",
                            })
                except Exception:
                    pass
        except Exception:
            pass

    if has_npm and (sp / "package-lock.json").is_file():
        try:
            proc = subprocess.run([npm_bin, "audit", "--json"], cwd=str(sp), capture_output=True, text=True, timeout=40)
            raw = proc.stdout.strip()
            if raw:
                try:
                    data = json.loads(raw)
                    metadata = data.get("metadata", {}).get("vulnerabilities", {})
                    npm_vulnerabilities = metadata.get("total", 0)
                    vulns = data.get("vulnerabilities", {})
                    for name, v in vulns.items():
                        npm_advisories.append({
                            "package": name,
                            "severity": v.get("severity", "moderate"),
                            "isDirect": v.get("isDirect", False),
                            "range": v.get("range", ""),
                        })
                except Exception:
                    pass
        except Exception:
            pass

    res = {
        "ok": True,
        "has_composer": has_composer,
        "has_npm": has_npm,
        "composer_advisories": advisories,
        "npm_advisories": npm_advisories,
        "composer_advisories_count": len(advisories),
        "npm_vulnerabilities": npm_vulnerabilities,
    }
    AUDIT_CACHE[cache_key] = {"time": now, "data": res}
    return res


def manage_package(
    site_path: str,
    action: str,
    manager: str,
    package_name: str = "",
    dev: bool = False,
    php_bin: str = "php",
) -> dict[str, Any]:
    sp = Path(site_path).resolve()
    composer_bin = _find_bin("composer")
    npm_bin = _find_bin("npm")
    is_win = sys.platform.startswith("win")

    manager = manager.lower().strip()
    action = action.lower().strip()
    pkg = package_name.strip()

    if manager not in ("composer", "npm"):
        return {"ok": False, "error": f"Unsupported package manager: {manager}"}

    cmd = []
    if manager == "composer":
        base_cmd = _composer_base_cmd(php_bin, composer_bin)
        if action == "update":
            if pkg:
                cmd = base_cmd + ["update", pkg, "--with-all-dependencies", "--no-interaction"]
            else:
                cmd = base_cmd + ["update", "--no-interaction"]
        elif action == "install":
            if not pkg:
                return {"ok": False, "error": "Package name is required for install"}
            cmd = base_cmd + ["require", pkg, "--no-interaction"]
            if dev:
                cmd.append("--dev")
        elif action == "remove":
            if not pkg:
                return {"ok": False, "error": "Package name is required for remove"}
            cmd = base_cmd + ["remove", pkg, "--no-interaction"]
        else:
            return {"ok": False, "error": f"Unknown action: {action}"}
    elif manager == "npm":
        if action == "update":
            if pkg:
                cmd = [npm_bin, "update", pkg]
            else:
                cmd = [npm_bin, "update"]
        elif action == "install":
            if not pkg:
                return {"ok": False, "error": "Package name is required for install"}
            cmd = [npm_bin, "install", pkg]
            if dev:
                cmd.append("--save-dev")
        elif action == "remove":
            if not pkg:
                return {"ok": False, "error": "Package name is required for remove"}
            cmd = [npm_bin, "uninstall", pkg]
        else:
            return {"ok": False, "error": f"Unknown action: {action}"}

    env = dict(os.environ)
    env.update({
        "COMPOSER_NO_INTERACTION": "1",
        "COMPOSER_MEMORY_LIMIT": "-1",
        "GIT_TERMINAL_PROMPT": "0",
    })
    for extra_dir in ("/usr/local/bin", str(Path.home() / ".local" / "bin"), str(Path.home() / ".config" / "herd-lite" / "bin")):
        if os.path.isdir(extra_dir) and extra_dir not in env.get("PATH", ""):
            env["PATH"] = f"{extra_dir}{os.pathsep}{env.get('PATH', '')}"

    try:
        proc = subprocess.run(cmd, cwd=str(sp), env=env, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=300)
        # Invalidate caches
        cache_key = str(sp)
        OUTDATED_CACHE.pop(cache_key, None)
        AUDIT_CACHE.pop(cache_key, None)

        output = (proc.stdout + "\n" + proc.stderr).strip()
        if proc.returncode == 0:
            return {"ok": True, "action": action, "manager": manager, "package": pkg, "output": output}
        return {"ok": False, "action": action, "manager": manager, "package": pkg, "error": output or f"Process exited with code {proc.returncode}"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "Command timed out after 3 minutes"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

