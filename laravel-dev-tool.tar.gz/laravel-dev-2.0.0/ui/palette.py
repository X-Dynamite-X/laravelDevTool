"""Universal Command Palette Indexer & Search Engine for Laravel Dev.

Provides instant fuzzy search and execution for projects, views, artisan commands,
and system services via the Ctrl+K command palette.
"""
from __future__ import annotations

import re
from typing import Any
import sites


SYSTEM_ACTIONS = [
    {
        "id": "view_sites",
        "title": "Go to Projects List",
        "subtitle": "View and manage all local projects",
        "category": "navigation",
        "icon": "folder",
        "action": "nav",
        "params": {"view": "sites"},
    },
    {
        "id": "view_database",
        "title": "Open Database Studio",
        "subtitle": "SQL query runner, tables and schema inspector",
        "category": "navigation",
        "icon": "database",
        "action": "nav",
        "params": {"view": "database"},
    },
    {
        "id": "view_servers",
        "title": "Open Remote Servers Manager",
        "subtitle": "Manage SSH deployment servers and backups",
        "category": "navigation",
        "icon": "server",
        "action": "nav",
        "params": {"view": "servers"},
    },
    {
        "id": "view_settings",
        "title": "Open System Settings",
        "subtitle": "Configure PHP, directories, editor, and preferences",
        "category": "navigation",
        "icon": "settings",
        "action": "nav",
        "params": {"view": "settings"},
    },
    {
        "id": "action_add_site",
        "title": "Create / Add New Project",
        "subtitle": "New Laravel, WordPress, or Node project",
        "category": "actions",
        "icon": "plus",
        "action": "open_modal",
        "params": {"modal": "add_site"},
    },
    {
        "id": "sys_restart_nginx",
        "title": "Restart Nginx Web Server",
        "subtitle": "Reload web server configuration",
        "category": "system",
        "icon": "refresh",
        "action": "service_action",
        "params": {"service": "nginx", "operation": "restart"},
    },
    {
        "id": "sys_restart_mysql",
        "title": "Restart MySQL / MariaDB Database",
        "subtitle": "Restart local database daemon",
        "category": "system",
        "icon": "refresh",
        "action": "service_action",
        "params": {"service": "mysql", "operation": "restart"},
    },
    {
        "id": "sys_restart_redis",
        "title": "Restart Redis Cache Service",
        "subtitle": "Restart local Redis daemon",
        "category": "system",
        "icon": "refresh",
        "action": "service_action",
        "params": {"service": "redis", "operation": "restart"},
    },
]

COMMON_ARTISAN = [
    ("migrate", "Run database migrations", "database"),
    ("migrate:status", "Show status of each migration", "database"),
    ("optimize", "Cache framework bootstrap, config and routes", "zap"),
    ("optimize:clear", "Remove all cached bootstrap, config, routes and views", "trash"),
    ("cache:clear", "Flush the application cache store", "trash"),
    ("config:clear", "Remove configuration cache file", "trash"),
    ("route:clear", "Remove route cache file", "trash"),
    ("view:clear", "Clear all compiled Blade view files", "trash"),
    ("queue:restart", "Signal queue workers to restart after current job", "refresh"),
    ("storage:link", "Create symbolic links for public storage", "link"),
    ("tinker", "Open interactive Tinker REPL workspace", "terminal"),
]


def match_score(query: str, text: str) -> int:
    """Calculate match score for fuzzy matching: 0 = no match, >0 = score."""
    q = query.lower()
    t = text.lower()
    if q == t:
        return 100
    if t.startswith(q):
        return 80
    if q in t:
        return 50
    # Check acronyms (e.g. 'c:c' -> 'cache:clear')
    q_parts = q.split(":")
    t_parts = t.split(":")
    if len(q_parts) == 2 and len(t_parts) == 2:
        if t_parts[0].startswith(q_parts[0]) and t_parts[1].startswith(q_parts[1]):
            return 70
    return 0


def search_palette(query: str, current_site_name: str = "") -> list[dict[str, Any]]:
    """Search items across all indexed categories."""
    q = str(query or "").strip().lower()
    results: list[dict[str, Any]] = []

    # 1. System actions & navigation
    for item in SYSTEM_ACTIONS:
        score = match_score(q, item["title"]) or match_score(q, item["subtitle"]) if q else 10
        if score > 0:
            results.append({**item, "score": score})

    # 2. Registered Sites
    try:
        all_sites = sites.list_sites()
        for s in all_sites:
            name = s.get("name", "")
            dom = s.get("domain", "")
            score = 0
            if q:
                score = max(match_score(q, name), match_score(q, dom))
            else:
                score = 30  # Show projects when opening palette with empty input

            if score > 0:
                results.append({
                    "id": f"site_{name}",
                    "title": f"Open Project: {name}",
                    "subtitle": f"{dom} · {s.get('type_label') or s.get('type', 'Laravel')} · {s.get('display_path', '')}",
                    "category": "projects",
                    "icon": "folder",
                    "action": "open_site",
                    "params": {"name": name},
                    "score": score + 20,  # Prioritize project jumps
                })
    except Exception:
        pass

    # 3. Artisan commands (for current or specified site)
    target_site = current_site_name
    if not target_site:
        try:
            sites_list = sites.list_sites()
            if sites_list:
                target_site = sites_list[0]["name"]
        except Exception:
            pass

    if target_site:
        for cmd, desc, icon_name in COMMON_ARTISAN:
            score = 0
            if q:
                score = max(match_score(q, cmd), match_score(q, f"artisan {cmd}"), match_score(q, desc))
            elif target_site:
                score = 15

            if score > 0:
                results.append({
                    "id": f"artisan_{cmd}",
                    "title": f"php artisan {cmd}",
                    "subtitle": f"{desc} ({target_site})",
                    "category": "artisan",
                    "icon": icon_name,
                    "action": "artisan_run",
                    "params": {"name": target_site, "command": cmd},
                    "score": score,
                })

    # Sort results by score descending, then title
    results.sort(key=lambda x: (-x.get("score", 0), x["title"]))
    return results[:30]

