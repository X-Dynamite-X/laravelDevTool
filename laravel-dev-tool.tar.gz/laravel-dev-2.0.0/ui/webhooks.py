#!/usr/bin/env python3
"""
ui/webhooks.py - Incoming Webhook Inspector, Replayer, and cURL Exporter
Standard library only.
"""

from __future__ import annotations

import json
import os
import shlex
import time
import urllib.error
import urllib.request
from pathlib import Path

DEFAULT_PATTERNS = [
    "webhook*",
    "*/webhook*",
    "stripe/*",
    "api/payments/*/callback",
    "api/webhooks/*",
]


def _cache_dir(site_path: str | Path) -> Path:
    return Path(site_path) / "storage" / "framework" / "cache"


def _webhooks_dir(site_path: str | Path) -> Path:
    return _cache_dir(site_path) / "laravel-dev-webhooks"


def list_webhooks(site_path: str | Path, limit: int = 100) -> list[dict]:
    wh_dir = _webhooks_dir(site_path)
    if not wh_dir.is_dir():
        return []

    items = []
    try:
        files = sorted(wh_dir.glob("*.json"), reverse=True)
        for f in files[:limit]:
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                # Truncate body preview for list
                body_raw = data.get("body") or ""
                items.append({
                    "id": data.get("id") or f.stem,
                    "time": data.get("time") or f.stat().st_mtime,
                    "created_at": data.get("created_at") or "",
                    "method": data.get("method") or "POST",
                    "uri": data.get("uri") or "",
                    "status": data.get("status") or 200,
                    "duration_ms": data.get("duration_ms") or 0,
                    "body_size": len(body_raw),
                    "body_preview": body_raw[:200],
                    "headers_count": len(data.get("headers") or {}),
                    "file": f.name,
                })
            except Exception:
                continue
    except OSError:
        pass

    return items


def get_webhook(site_path: str | Path, webhook_id: str) -> dict | None:
    wh_dir = _webhooks_dir(site_path)
    if not wh_dir.is_dir():
        return None

    # Try direct match or search by id inside json
    for f in wh_dir.glob("*.json"):
        if webhook_id in f.name:
            try:
                return json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                pass
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            if data.get("id") == webhook_id:
                return data
        except Exception:
            continue

    return None


def clear_webhooks(site_path: str | Path) -> bool:
    wh_dir = _webhooks_dir(site_path)
    if not wh_dir.is_dir():
        return True
    try:
        for f in wh_dir.glob("*.json"):
            try:
                f.unlink()
            except OSError:
                pass
        return True
    except OSError:
        return False


def get_patterns(site_path: str | Path) -> list[str]:
    cfg = _cache_dir(site_path) / "laravel-dev-webhooks.json"
    if cfg.is_file():
        try:
            vals = json.loads(cfg.read_text(encoding="utf-8"))
            if isinstance(vals, list) and vals:
                return [str(v) for v in vals]
        except Exception:
            pass
    return list(DEFAULT_PATTERNS)


def save_patterns(site_path: str | Path, patterns: list[str]) -> bool:
    cache = _cache_dir(site_path)
    cache.mkdir(parents=True, exist_ok=True)
    cfg = cache / "laravel-dev-webhooks.json"
    clean = [str(p).strip() for p in patterns if str(p).strip()]
    try:
        cfg.write_text(json.dumps(clean, indent=2), encoding="utf-8")
        return True
    except OSError:
        return False


def export_curl(webhook_data: dict, site_url: str = "") -> str:
    method = (webhook_data.get("method") or "POST").upper()
    uri = webhook_data.get("uri") or "/"
    base_url = (site_url or "http://localhost").rstrip("/")
    target = f"{base_url}{uri}"

    parts = ["curl", "-X", method, shlex.quote(target)]

    headers = webhook_data.get("headers") or {}
    for k, v in headers.items():
        if k.lower() in ("host", "content-length", "connection", "transfer-encoding"):
            continue
        parts.extend(["-H", shlex.quote(f"{k}: {v}")])

    body = webhook_data.get("body")
    if body is not None and method not in ("GET", "HEAD"):
        parts.extend(["--data-raw", shlex.quote(body)])

    return " ".join(parts)


def replay_webhook(site_url: str, webhook_data: dict, custom_body: str | None = None) -> dict:
    method = (webhook_data.get("method") or "POST").upper()
    uri = webhook_data.get("uri") or "/"
    base_url = site_url.rstrip("/")
    target = f"{base_url}{uri}"

    body_str = custom_body if custom_body is not None else (webhook_data.get("body") or "")
    body_bytes = body_str.encode("utf-8") if isinstance(body_str, str) else bytes(body_str)

    req_headers = {}
    for k, v in (webhook_data.get("headers") or {}).items():
        if k.lower() in ("host", "content-length", "connection", "transfer-encoding"):
            continue
        req_headers[k] = v

    # Add custom replay header
    req_headers["X-Laravel-Dev-Replay"] = "true"

    t0 = time.time()
    req = urllib.request.Request(
        url=target,
        data=body_bytes if method not in ("GET", "HEAD") else None,
        headers=req_headers,
        method=method,
    )

    result = {
        "target": target,
        "method": method,
        "status": 0,
        "duration_ms": 0.0,
        "headers": {},
        "body": "",
        "error": None,
    }

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            t1 = time.time()
            result["status"] = resp.status
            result["duration_ms"] = round((t1 - t0) * 1000, 2)
            result["headers"] = dict(resp.headers)
            result["body"] = resp.read().decode("utf-8", errors="replace")[:16384]
    except urllib.error.HTTPError as he:
        t1 = time.time()
        result["status"] = he.code
        result["duration_ms"] = round((t1 - t0) * 1000, 2)
        result["headers"] = dict(he.headers)
        result["body"] = he.read().decode("utf-8", errors="replace")[:16384]
        result["error"] = f"HTTP {he.code}: {he.reason}"
    except Exception as exc:
        t1 = time.time()
        result["duration_ms"] = round((t1 - t0) * 1000, 2)
        result["error"] = str(exc)

    return result
