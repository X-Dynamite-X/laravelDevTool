"""macOS / Windows window: the system web view through pywebview (WKWebView on
macOS, Edge WebView2 on Windows, WebKitGTK or Qt on Linux), so no browser
engine is bundled and memory stays low."""

import os
import threading

import webview

import osutil

from backend import Backend
from sites import UI_DIR


def _dialog_types():
    kinds = getattr(webview, "FileDialog", None)
    if kinds is not None:  # pywebview >= 5
        return {"folder": kinds.FOLDER, "open": kinds.OPEN, "save": kinds.SAVE}
    return {"folder": webview.FOLDER_DIALOG, "open": webview.OPEN_DIALOG, "save": webview.SAVE_DIALOG}


class Bridge:
    """Exposed to JavaScript as window.pywebview.api."""

    def __init__(self, shell):
        self._shell = shell

    def post(self, message):
        self._shell.backend.handle(message)


class WebviewShell:
    has_tray = False

    def __init__(self, start_hidden=False):
        self.start_hidden = start_hidden
        self.window = None
        self.ready = threading.Event()
        self.backend = Backend(self)

    # shell interface used by Backend
    def post(self, fn, *args):
        fn(*args)  # pywebview calls are thread-safe

    def eval_js(self, script):
        if self.window is not None and self.ready.is_set():
            try:
                self.window.evaluate_js(script)
            except Exception:  # noqa: BLE001 — window closing
                pass

    def is_active(self):
        return True

    def notify(self, title, body, task_id=""):
        osutil.send_desktop_notification(title, body)

    def refresh_tray(self, *_):
        return False

    def choose(self, kind, title, done, start=None, multiple=False, name=None, accept="Select"):
        def ask():
            try:
                result = self.window.create_file_dialog(
                    _dialog_types()[kind], directory=start if start and os.path.isdir(start) else "",
                    allow_multiple=multiple, save_filename=name or "")
            except Exception:  # noqa: BLE001
                result = None
            if isinstance(result, str):
                result = [result]
            done(list(result or []))
        threading.Thread(target=ask, daemon=True).start()

    def run(self):
        self.window = webview.create_window(
            "Laravel Dev", url=(UI_DIR / "web" / "index.html").as_uri(), js_api=Bridge(self),
            # No tray icon here, so a hidden window could never be shown again: ignore --hidden.
            width=1240, height=780, min_size=(860, 560), background_color="#f6f6f7",
        )
        self.window.events.loaded += self.ready.set
        self.window.events.closed += self.backend.shutdown
        webview.start(debug=bool(os.environ.get("LARAVEL_DEV_DEBUG")))
        return 0


def run(start_hidden=False):
    return WebviewShell(start_hidden=start_hidden).run()
