"""Environment Vault & Diff Inspector Engine for Laravel Dev.

Provides key-by-key and line-by-line comparison between .env files (.env vs .env.example,
.env vs .env.backup, etc.) and integrates with Laravel's native env:encrypt and env:decrypt.
"""
from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import Any
import envfile


def parse_env_content(text: str) -> dict[str, str]:
    try:
        return envfile.to_dict(text)
    except Exception:
        out = {}
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip().strip('"').strip("'")
        return out


def compare_env_files(site_path: str, file_a_name: str = ".env", file_b_name: str = ".env.example") -> dict[str, Any]:
    p = Path(site_path).resolve()
    path_a = p / file_a_name
    path_b = p / file_b_name

    text_a = path_a.read_text(encoding="utf-8", errors="replace") if path_a.is_file() else ""
    text_b = path_b.read_text(encoding="utf-8", errors="replace") if path_b.is_file() else ""

    dict_a = parse_env_content(text_a)
    dict_b = parse_env_content(text_b)

    all_keys = sorted(set(dict_a.keys()) | set(dict_b.keys()))

    diff_items = []
    added = []
    removed = []
    changed = []
    same = []

    for k in all_keys:
        in_a = k in dict_a
        in_b = k in dict_b
        val_a = dict_a.get(k, "")
        val_b = dict_b.get(k, "")

        if in_a and not in_b:
            item = {"key": k, "status": "removed", "val_a": val_a, "val_b": None}
            removed.append(item)
            diff_items.append(item)
        elif not in_a and in_b:
            item = {"key": k, "status": "added", "val_a": None, "val_b": val_b}
            added.append(item)
            diff_items.append(item)
        elif val_a != val_b:
            item = {"key": k, "status": "changed", "val_a": val_a, "val_b": val_b}
            changed.append(item)
            diff_items.append(item)
        else:
            item = {"key": k, "status": "same", "val_a": val_a, "val_b": val_b}
            same.append(item)
            diff_items.append(item)

    return {
        "ok": True,
        "file_a": file_a_name,
        "file_b": file_b_name,
        "has_file_a": path_a.is_file(),
        "has_file_b": path_b.is_file(),
        "total_keys": len(all_keys),
        "total_diff": len(added) + len(removed) + len(changed),
        "added": added,
        "removed": removed,
        "changed": changed,
        "same": same,
        "items": diff_items,
    }


def encrypt_env(site_path: str, cipher: str = "AES-256-CBC", php_bin: str = "php") -> dict[str, Any]:
    p = Path(site_path).resolve()
    artisan = p / "artisan"
    if not artisan.is_file():
        return {"ok": False, "error": "Not a Laravel project: artisan not found"}

    try:
        proc = subprocess.run(
            [php_bin, str(artisan), "env:encrypt", f"--cipher={cipher}"],
            cwd=str(p),
            capture_output=True,
            text=True,
            timeout=10,
        )
        out = proc.stdout + proc.stderr
        if proc.returncode != 0:
            return {"ok": False, "error": out.strip()}

        # Extract generated key
        key = ""
        m = re.search(r"--key=([a-zA-Z0-9+/=:]+)", out) or re.search(r"key:\s*([a-zA-Z0-9+/=:]+)", out)
        if m:
            key = m.group(1).strip()

        return {
            "ok": True,
            "message": "Environment encrypted successfully",
            "key": key,
            "cipher": cipher,
            "encrypted_file": ".env.encrypted",
            "output": out.strip(),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def decrypt_env(site_path: str, key: str, php_bin: str = "php") -> dict[str, Any]:
    p = Path(site_path).resolve()
    artisan = p / "artisan"
    if not artisan.is_file():
        return {"ok": False, "error": "Not a Laravel project: artisan not found"}

    try:
        proc = subprocess.run(
            [php_bin, str(artisan), "env:decrypt", f"--key={key}", "--force"],
            cwd=str(p),
            capture_output=True,
            text=True,
            timeout=10,
        )
        out = proc.stdout + proc.stderr
        if proc.returncode != 0:
            return {"ok": False, "error": out.strip()}

        return {
            "ok": True,
            "message": "Environment decrypted successfully into .env",
            "output": out.strip(),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}

