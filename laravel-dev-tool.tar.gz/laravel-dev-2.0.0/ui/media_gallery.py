"""Local Media & Storage Gallery Engine for Laravel Dev.

Scans `storage/app/public`, parses file metadata and image dimensions without external packages,
and manages `public/storage` symlinks and file actions.
"""
from __future__ import annotations

import mimetypes
import os
import shutil
import struct
import subprocess
from pathlib import Path
from typing import Any


def get_image_dimensions(file_path: Path) -> tuple[int, int] | None:
    """Extract width and height for PNG, JPEG, GIF, and WebP using standard library."""
    try:
        with file_path.open("rb") as f:
            head = f.read(64)
            # PNG: bytes 12-16 'IHDR', 16-20 width, 20-24 height
            if head.startswith(b"\x89PNG\r\n\x1a\n") and len(head) >= 24:
                w, h = struct.unpack(">II", head[16:24])
                return int(w), int(h)

            # GIF: GIF87a or GIF89a, width at bytes 6-8, height at bytes 8-10 (little-endian)
            if head.startswith((b"GIF87a", b"GIF89a")) and len(head) >= 10:
                w, h = struct.unpack("<HH", head[6:10])
                return int(w), int(h)

            # JPEG: iterate chunks to find SOF marker (0xFF, 0xC0 to 0xC3)
            if head.startswith(b"\xff\xd8"):
                f.seek(2)
                while True:
                    marker_bytes = f.read(2)
                    if len(marker_bytes) < 2:
                        break
                    marker, = struct.unpack(">H", marker_bytes)
                    if 0xFFC0 <= marker <= 0xFFC3:
                        f.read(3)  # skip length & precision
                        h, w = struct.unpack(">HH", f.read(4))
                        return int(w), int(h)
                    else:
                        length_bytes = f.read(2)
                        if len(length_bytes) < 2:
                            break
                        length, = struct.unpack(">H", length_bytes)
                        f.seek(length - 2, os.SEEK_CUR)
    except Exception:
        pass
    return None


def format_size(bytes_num: int) -> str:
    if bytes_num < 1024:
        return f"{bytes_num} B"
    if bytes_num < 1024 * 1024:
        return f"{bytes_num / 1024:.1f} KB"
    return f"{bytes_num / (1024 * 1024):.1f} MB"


def check_storage_symlink(site_path: str) -> dict[str, Any]:
    p = Path(site_path).resolve()
    pub_storage = p / "public" / "storage"
    app_public = p / "storage" / "app" / "public"

    if not pub_storage.exists() and not pub_storage.is_symlink():
        return {"linked": False, "status": "missing", "target": str(app_public)}

    if pub_storage.is_symlink():
        try:
            target = os.readlink(pub_storage)
            resolved_target = (pub_storage.parent / target).resolve()
            is_valid = resolved_target == app_public.resolve()
            return {"linked": is_valid, "status": "ok" if is_valid else "broken", "target": str(target)}
        except Exception:
            return {"linked": False, "status": "broken", "target": ""}

    return {"linked": True, "status": "directory", "target": str(pub_storage)}


def fix_storage_symlink(site_path: str, php_bin: str = "php") -> dict[str, Any]:
    p = Path(site_path).resolve()
    pub_storage = p / "public" / "storage"
    app_public = p / "storage" / "app" / "public"
    app_public.mkdir(parents=True, exist_ok=True)

    if pub_storage.is_dir() and not pub_storage.is_symlink():
        # A real folder may hold files that exist nowhere else; never delete it.
        return {"ok": False, "error": "public/storage is a real folder, not a link. Move its files into "
                                      "storage/app/public, delete the folder, then repair again."}
    if pub_storage.is_symlink() or pub_storage.is_file():
        try:
            pub_storage.unlink()
        except Exception as exc:
            return {"ok": False, "error": f"Could not remove the broken link: {exc}"}

    # Try artisan storage:link first
    artisan = p / "artisan"
    if artisan.is_file():
        try:
            subprocess.run([php_bin, str(artisan), "storage:link"], cwd=str(p), capture_output=True, timeout=5)
        except Exception:
            pass

    # Ensure symlink directly if artisan didn't create it
    if not pub_storage.exists() and not pub_storage.is_symlink():
        try:
            os.symlink("../../storage/app/public", pub_storage)
        except Exception:
            try:
                os.symlink(str(app_public), pub_storage)
            except Exception as e:
                return {"ok": False, "error": f"Failed to create symlink: {e}"}

    return {"ok": True, "message": "Storage symlink repaired successfully"}


def _file_type(mime: str) -> str:
    if mime.startswith("image/"):
        return "image"
    if mime.startswith("video/"):
        return "video"
    if mime == "application/pdf" or mime.startswith("text/"):
        return "document"
    return "other"


def list_media_files(site_path: str, folder: str = "", query: str = "", file_type: str = "all",
                     offset: int = 0, limit: int = 120) -> dict[str, Any]:
    """One page of files (newest first). Totals cover every match so the UI can
    say how many there are without receiving them all."""
    p = Path(site_path).resolve()
    storage_dir = (p / "storage" / "app" / "public").resolve()

    symlink_info = check_storage_symlink(site_path)
    q = query.lower().strip()

    target_dir = (storage_dir / folder).resolve() if folder else storage_dir
    if target_dir != storage_dir and storage_dir not in target_dir.parents:
        return {"ok": False, "error": "Folder is outside storage/app/public"}

    matches = []
    total_size = 0
    counts = {"all": 0, "image": 0, "video": 0, "document": 0, "other": 0}
    if target_dir.is_dir():
        for item in target_dir.rglob("*"):
            if item.name.startswith(".") or not item.is_file():
                continue
            rel = str(item.relative_to(storage_dir))
            if q and q not in rel.lower():
                continue
            mime = mimetypes.guess_type(item.name)[0] or "application/octet-stream"
            kind = _file_type(mime)
            counts["all"] += 1
            counts[kind] += 1
            if file_type not in ("", "all") and kind != file_type:
                continue
            st = item.stat()
            total_size += st.st_size
            matches.append((st.st_mtime, item, rel, mime, kind, st.st_size))

    matches.sort(key=lambda m: m[0], reverse=True)
    files = []
    for mtime, item, rel, mime, kind, size in matches[offset:offset + limit]:
        dims = get_image_dimensions(item) if kind == "image" else None
        files.append({
            "filename": item.name,
            "relative_path": rel,
            "storage_url": f"/storage/{rel}",
            "size": size,
            "size_formatted": format_size(size),
            "mime_type": mime,
            "type": kind,
            "width": dims[0] if dims else None,
            "height": dims[1] if dims else None,
            "modified_at": int(mtime),
        })

    return {
        "ok": True,
        "files": files,
        "offset": offset,
        "has_more": offset + len(files) < len(matches),
        "total_files": len(matches),
        "counts": counts,
        "total_size": total_size,
        "total_size_formatted": format_size(total_size),
        "symlink": symlink_info,
    }


def delete_media_file(site_path: str, relative_path: str) -> dict[str, Any]:
    p = Path(site_path).resolve()
    storage_dir = (p / "storage" / "app" / "public").resolve()
    target_file = (storage_dir / relative_path).resolve()

    # Security check: ensure target is inside storage/app/public
    if storage_dir not in target_file.parents:
        return {"ok": False, "error": "Access denied: Path traversal detected"}

    if not target_file.is_file():
        return {"ok": False, "error": "File not found"}

    try:
        target_file.unlink()
        return {"ok": True, "message": f"File '{target_file.name}' deleted"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

