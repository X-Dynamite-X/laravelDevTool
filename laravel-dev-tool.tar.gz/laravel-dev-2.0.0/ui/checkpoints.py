"""Project Time Machine & Checkpoints Engine for Laravel Dev.

Captures and restores full project checkpoints:
- Database snapshot (MySQL, PostgreSQL, SQLite)
- Environment configuration (.env)
- Storage files (storage/app/public)
- Git branch & commit state
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import tarfile
import time
from pathlib import Path
from typing import Any

import osutil


def get_checkpoints_root() -> Path:
    base = osutil.config_dir() / "checkpoints"
    base.mkdir(parents=True, exist_ok=True)
    return base


def get_site_checkpoints_dir(site_name: str) -> Path:
    d = get_checkpoints_root() / site_name
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_git_info(site_path: Path) -> tuple[str, str]:
    branch = ""
    commit = ""
    if (site_path / ".git").is_dir():
        try:
            r = subprocess.run(
                ["git", "branch", "--show-current"],
                cwd=str(site_path),
                capture_output=True,
                text=True,
                timeout=3,
            )
            branch = r.stdout.strip()
        except Exception:
            pass
        try:
            r = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                cwd=str(site_path),
                capture_output=True,
                text=True,
                timeout=3,
            )
            commit = r.stdout.strip()
        except Exception:
            pass
    return branch, commit


def list_checkpoints(site_name: str) -> list[dict[str, Any]]:
    sdir = get_site_checkpoints_dir(site_name)
    manifest_file = sdir / "checkpoints.json"
    if not manifest_file.is_file():
        return []
    try:
        data = json.loads(manifest_file.read_text(encoding="utf-8"))
        if isinstance(data, list):
            data.sort(key=lambda x: x.get("timestamp", 0), reverse=True)
            return data
    except Exception:
        pass
    return []


def create_checkpoint(
    site_name: str, site_path: str, note: str = "", include_storage: bool = True
) -> dict[str, Any]:
    path = Path(site_path).resolve()
    if not path.is_dir():
        return {"ok": False, "error": f"Project directory not found: {site_path}"}

    sdir = get_site_checkpoints_dir(site_name)
    cp_id = f"cp_{int(time.time())}_{os.urandom(3).hex()}"
    cp_dir = sdir / cp_id
    cp_dir.mkdir(parents=True, exist_ok=True)

    branch, commit = get_git_info(path)

    # 1. Save .env
    has_env = False
    env_file = path / ".env"
    if env_file.is_file():
        shutil.copy2(str(env_file), str(cp_dir / ".env"))
        has_env = True

    # 2. Save Database Snapshot
    has_db = False
    db_size = 0
    try:
        import laravel_dev

        db_snap = laravel_dev.create_db_backup(str(path))
        if db_snap.get("ok"):
            snap_filename = db_snap.get("filename") or ""
            bdir = laravel_dev.get_backups_dir(str(path))
            src_db = bdir / snap_filename
            if src_db.is_file():
                dst_db = cp_dir / "db_snapshot.sql.gz"
                shutil.copy2(str(src_db), str(dst_db))
                has_db = True
                db_size = dst_db.stat().st_size
    except Exception as exc:
        pass

    # 3. Archive storage/app/public if requested
    has_storage = False
    storage_size = 0
    storage_public = path / "storage" / "app" / "public"
    if include_storage and storage_public.is_dir():
        tar_dst = cp_dir / "storage.tar.gz"
        try:
            with tarfile.open(tar_dst, "w:gz") as tar:
                tar.add(str(storage_public), arcname="public")
            has_storage = True
            storage_size = tar_dst.stat().st_size
        except Exception:
            tar_dst.unlink(missing_ok=True)

    manifest_item = {
        "id": cp_id,
        "site": site_name,
        "timestamp": int(time.time()),
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "note": note.strip() or "Manual Checkpoint",
        "git_branch": branch,
        "git_commit": commit,
        "has_env": has_env,
        "has_db": has_db,
        "has_storage": has_storage,
        "db_size": db_size,
        "storage_size": storage_size,
        "total_size": db_size + storage_size + (env_file.stat().st_size if has_env else 0),
    }

    # Update index
    checkpoints = list_checkpoints(site_name)
    checkpoints.insert(0, manifest_item)
    (sdir / "checkpoints.json").write_text(
        json.dumps(checkpoints, indent=2), encoding="utf-8"
    )

    return {"ok": True, "checkpoint": manifest_item}


def restore_checkpoint(site_name: str, site_path: str, checkpoint_id: str) -> dict[str, Any]:
    path = Path(site_path).resolve()
    if not path.is_dir():
        return {"ok": False, "error": f"Project directory not found: {site_path}"}

    sdir = get_site_checkpoints_dir(site_name)
    cp_dir = sdir / checkpoint_id
    if not cp_dir.is_dir():
        return {"ok": False, "error": f"Checkpoint {checkpoint_id} not found"}

    # Restoring overwrites .env, the database and storage; keep a way back.
    safety = create_checkpoint(site_name, site_path, note=f"Auto-saved before restoring {checkpoint_id}")
    if not safety.get("ok"):
        return {"ok": False, "error": f"Could not save the current state first: {safety.get('error')}"}
    safety_id = safety["checkpoint"]["id"]

    restored_items = []

    # 1. Restore .env
    cp_env = cp_dir / ".env"
    if cp_env.is_file():
        shutil.copy2(str(cp_env), str(path / ".env"))
        restored_items.append(".env")

    # 2. Restore Database
    cp_db = cp_dir / "db_snapshot.sql.gz"
    if cp_db.is_file():
        try:
            import laravel_dev

            bdir = laravel_dev.get_backups_dir(str(path), create=True)
            tmp_db = bdir / f"restore_{checkpoint_id}.sql.gz"
            shutil.copy2(str(cp_db), str(tmp_db))
            try:
                res = laravel_dev.restore_backup(str(path), tmp_db.name)
                if not res.get("ok"):
                    done = f" (.env was already restored)" if restored_items else ""
                    return {"ok": False, "restored": restored_items, "safety_checkpoint": safety_id,
                            "error": f"Database restore failed{done}: {res.get('error') or 'unknown error'}"}
                restored_items.append("database")
            finally:
                tmp_db.unlink(missing_ok=True)
        except Exception as exc:
            return {"ok": False, "safety_checkpoint": safety_id, "error": f"Database restore failed: {exc}"}

    # 3. Restore Storage
    cp_storage = cp_dir / "storage.tar.gz"
    if cp_storage.is_file():
        storage_app = path / "storage" / "app"
        storage_app.mkdir(parents=True, exist_ok=True)
        staging = storage_app / f".restore-{checkpoint_id}"
        try:
            shutil.rmtree(staging, ignore_errors=True)
            staging.mkdir()
            with tarfile.open(cp_storage, "r:gz") as tar:
                # "data" refuses absolute paths, ../ and device files from the archive.
                if hasattr(tarfile, "data_filter"):
                    tar.extractall(path=str(staging), filter="data")
                else:
                    tar.extractall(path=str(staging))
            # Swap instead of extracting on top, so files added after the
            # checkpoint don't survive the restore.
            public = storage_app / "public"
            old = storage_app / f".old-public-{checkpoint_id}"
            if public.exists():
                public.rename(old)
            (staging / "public").rename(public)
            shutil.rmtree(old, ignore_errors=True)
            restored_items.append("storage")
        except Exception as exc:
            return {"ok": False, "restored": restored_items, "safety_checkpoint": safety_id,
                    "error": f"Storage restore failed: {exc}"}
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    # 4. Clear config & route caches
    try:
        import sites

        php_bin = sites.php_binary(sites.find_site(site_name).get("php"))
        if (path / "artisan").is_file():
            subprocess.run(
                [php_bin, "artisan", "optimize:clear"],
                cwd=str(path),
                capture_output=True,
                timeout=10,
            )
    except Exception:
        pass

    return {
        "ok": True,
        "restored": restored_items,
        "safety_checkpoint": safety_id,
        "message": f"Checkpoint restored ({', '.join(restored_items) or 'nothing to restore'}). "
                   f"The previous state was saved as a new checkpoint.",
    }


def delete_checkpoint(site_name: str, checkpoint_id: str) -> dict[str, Any]:
    sdir = get_site_checkpoints_dir(site_name)
    cp_dir = sdir / checkpoint_id
    if cp_dir.is_dir():
        shutil.rmtree(cp_dir, ignore_errors=True)

    checkpoints = [cp for cp in list_checkpoints(site_name) if cp.get("id") != checkpoint_id]
    (sdir / "checkpoints.json").write_text(
        json.dumps(checkpoints, indent=2), encoding="utf-8"
    )
    return {"ok": True}

