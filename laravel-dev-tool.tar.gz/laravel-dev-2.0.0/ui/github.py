#!/usr/bin/env python3
"""GitHub Hub Manager for Laravel Dev.

Manages GitHub authentication, multi-account storage, repositories, pull requests,
issues, GitHub Actions workflows, and local Laravel site publishing via GitHub REST API v3.
"""

from __future__ import annotations

import json
import os
import re
import ssl
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

try:
    from osutil import private_file
except ImportError:
    try:
        from ui.osutil import private_file
    except ImportError:
        def private_file(p: Path) -> Path:
            p.parent.mkdir(parents=True, exist_ok=True)
            if not p.exists():
                p.touch()
            try:
                os.chmod(p, 0o600)
            except OSError:
                pass
            return p

GH_API_BASE = "https://api.github.com"


def _config_dirs() -> tuple[Path, Path]:
    uid = os.getuid() if hasattr(os, "getuid") else 1000
    candidates = [
        Path.home() / ".config" / "laravel-dev",
        Path(f"/tmp/laravel-dev-{uid}"),
    ]
    writable_dir = candidates[-1]
    for d in candidates:
        try:
            d.mkdir(parents=True, exist_ok=True)
            test_file = d / ".gh_write_test"
            test_file.touch()
            test_file.unlink(missing_ok=True)
            writable_dir = d
            break
        except OSError:
            continue

    writable_file = writable_dir / "github.json"

    # If fallback dir, sync from primary if exists
    if writable_dir != candidates[0]:
        primary_file = candidates[0] / "github.json"
        if primary_file.is_file() and not writable_file.is_file():
            try:
                writable_file.write_text(primary_file.read_text(encoding="utf-8"), encoding="utf-8")
                try:
                    os.chmod(writable_file, 0o600)
                except OSError:
                    pass
            except OSError:
                pass

    return writable_dir, writable_file


def analyze_gh_error(
    error_message: str,
    error_code: int = 0,
    status_code: int = 0,
    endpoint: str = "",
    username: str = "",
) -> dict[str, str]:
    """Analyze GitHub API errors and return bilingual root cause, fix, and direct dashboard URL."""
    msg = error_message.lower().strip()
    gh_base = f"https://github.com/{username}" if username else "https://github.com"

    # 1. Bad Credentials / Unauthorized
    if (
        status_code == 401
        or "bad credentials" in msg
        or "requires authentication" in msg
        or "token expired" in msg
    ):
        return {
            "category": "bad_credentials",
            "key": "bad_credentials",
            "title": "Invalid or Expired GitHub Personal Access Token",
            "explanation": "GitHub rejected this Personal Access Token. It may have expired, been revoked, or mistyped.",
            "action": "Generate a new Personal Access Token (Classic or Fine-grained) in your GitHub settings and reconnect.",
            "title_ar": "رمز الوصول الشخصي (PAT) غير صالح أو منتهي الصلاحية",
            "explanation_ar": "رفضت منصة GitHub رمز الـ API الحالي. قد يكون الرمز منتهي الصلاحية أو تم إبطاله أو نسخه بشكل غير صحيح.",
            "action_ar": "قم بإنشاء رمز وصول شخصي (Personal Access Token) جديد من إعدادات GitHub وانسخه للتطبيق.",
            "url": "https://github.com/settings/tokens/new?scopes=repo,workflow,read:org,user:email",
            "required_perm": "repo, workflow, read:org, user:email",
        }

    # 2. Rate Limit Exceeded
    if (
        status_code in (403, 429)
        and ("rate limit" in msg or "api rate limit exceeded" in msg)
    ):
        return {
            "category": "rate_limited",
            "key": "rate_limit_exceeded",
            "title": "GitHub API Rate Limit Exceeded (5,000 req/hr)",
            "explanation": "You have reached GitHub's rate limit. Authenticated requests allow up to 5,000 requests per hour.",
            "action": "Please wait a few minutes for your rate limit quota to refresh automatically.",
            "title_ar": "تم تجاوز حد طلبات GitHub API المؤقت",
            "explanation_ar": "تم تجاوز الحد الأقصى المسموح به للطلبات (5000 طلب/ساعة للرموز الموثقة).",
            "action_ar": "يرجى الانتظار بضع دقائق حتى يتم تجديد رصيد الطلبات تلقائياً.",
            "url": "https://docs.github.com/rest/overview/resources-in-the-rest-api#rate-limiting",
            "required_perm": "",
        }

    # 3. Missing Scopes / Permissions
    if (
        status_code == 403
        or "resource not accessible" in msg
        or "must have admin rights" in msg
        or "scope" in msg
        or "permission" in msg
    ):
        if "workflow" in endpoint or "actions" in endpoint or "workflow" in msg:
            perm = "workflow"
            perm_desc = "GitHub Actions Workflows"
        elif "keys" in endpoint or "ssh" in msg:
            perm = "admin:public_key, repo"
            perm_desc = "SSH and Deploy Keys"
        elif "org" in endpoint or "orgs" in endpoint:
            perm = "read:org, admin:org"
            perm_desc = "Organization Access"
        else:
            perm = "repo"
            perm_desc = "Full Control of Repositories"

        return {
            "category": "missing_scope",
            "key": "missing_scope",
            "title": f"Missing Required Token Scope ({perm})",
            "explanation": f"Your GitHub token does not have permission for {perm_desc}. GitHub rejected the request because the [{perm}] scope is not granted.",
            "action": f"Edit your token at GitHub Settings > Developer settings > Personal access tokens, enable the [{perm}] checkbox, and save.",
            "title_ar": f"نقص في صلاحية الرمز المطلوبة ({perm})",
            "explanation_ar": f"رمز GitHub الحالي يفتقر لصلاحية [{perm}] الضرورية للقيام بهذه العملية.",
            "action_ar": f"انتقل إلى إعدادات الرموز في GitHub وقم بتفعيل خيار [{perm}] ثم احفظ التعديل.",
            "url": "https://github.com/settings/tokens",
            "required_perm": perm,
        }

    # 4. Repository Name Conflict / Already Exists
    if (
        status_code == 422
        and ("already exists" in msg or "name already exists" in msg)
    ):
        return {
            "category": "repo_conflict",
            "key": "repo_already_exists",
            "title": "Repository Already Exists",
            "explanation": "A repository with this name already exists under your account or organization.",
            "action": "Choose a different repository name, or link the existing repository instead.",
            "title_ar": "اسم المستودع موجود مسبقاً (Repository Already Exists)",
            "explanation_ar": "يوجد مستودع سابق بنفس هذا الاسم مسجل تحت حسابك أو منظمتك على GitHub.",
            "action_ar": "اختر اسماً آخر للمستودع، أو قم بربط المستودع الموجود مسبقاً.",
            "url": f"https://github.com/{username}?tab=repositories" if username else "https://github.com",
            "required_perm": "",
        }

    # 5. Not Found (404) - often indicates missing repo scope for private repos
    if status_code == 404:
        return {
            "category": "not_found",
            "key": "not_found",
            "title": "Resource Not Found or Access Denied",
            "explanation": "The repository or resource was not found. If this is a private repository, ensure your API token has the 'repo' scope granted.",
            "action": "Check the repository owner and name, and verify your token has 'repo' scope for private repositories.",
            "title_ar": "المستودع غير موجود أو لا تملك صلاحية الوصول إليه",
            "explanation_ar": "تعذر العثور على المستودع. إن كان المستودع خاصاً (Private)، تأكد من أن رمز الـ API يملك صلاحية 'repo'.",
            "action_ar": "تحقق من صحة اسم المستودع، ومن تفعيل صلاحية 'repo' للوصول للمستودعات الخاصة.",
            "url": "https://github.com/settings/tokens",
            "required_perm": "repo",
        }

    # 6. Merge Conflict (409 / 405)
    if status_code in (405, 409) or "conflict" in msg or "not mergeable" in msg:
        return {
            "category": "merge_conflict",
            "key": "merge_conflict",
            "title": "Pull Request Has Merge Conflicts",
            "explanation": "This pull request cannot be merged automatically because there are conflicting changes between the base and head branches.",
            "action": "Pull the latest base branch locally, resolve conflicts, and push to the feature branch before merging.",
            "title_ar": "تعارض في الدمج (Merge Conflict)",
            "explanation_ar": "لا يمكن دمج طلب السحب تلقائياً لوجود تعارض في الملفات بين الفرعين.",
            "action_ar": "قم بحل التعارضات محلياً ثم ارفع التعديلات للفرع لإتمام الدمج.",
            "url": gh_base,
            "required_perm": "",
        }

    # 7. Generic Fallback
    return {
        "category": "api_error",
        "key": "generic_api_error",
        "title": "GitHub API Error",
        "explanation": error_message,
        "action": "Check GitHub Status or verify your repository settings.",
        "title_ar": "خطأ من منصة GitHub",
        "explanation_ar": error_message,
        "action_ar": "راجع إعدادات المستودع أو حالة منصة GitHub.",
        "url": gh_base,
        "required_perm": "",
    }


class GitHubClient:
    """Manages GitHub authentication, multi-account storage, and REST API v3 operations."""

    def __init__(self, config_dir: Path | None = None):
        if config_dir:
            self.config_dir = Path(config_dir).resolve()
            self.config_file = self.config_dir / "github.json"
        else:
            self.config_dir, self.config_file = _config_dirs()
        self._cached_creds: dict[str, Any] | None = None

    # ── Multi-Account Storage ────────────────────────────────────────────────

    def _load_raw_config(self) -> dict[str, Any]:
        if not self.config_file.is_file():
            primary_file = Path.home() / ".config" / "laravel-dev" / "github.json"
            if primary_file.is_file():
                try:
                    return json.loads(primary_file.read_text(encoding="utf-8"))
                except Exception:
                    pass
            return {"active_account_id": "", "accounts": []}

        try:
            return json.loads(self.config_file.read_text(encoding="utf-8"))
        except Exception:
            return {"active_account_id": "", "accounts": []}

    def _save_raw_config(self, data: dict[str, Any]) -> bool:
        try:
            private_file(self.config_file)
            self.config_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
            self._cached_creds = None
            return True
        except OSError:
            # Fallback path
            uid = os.getuid() if hasattr(os, "getuid") else 1000
            fallback_dir = Path(f"/tmp/laravel-dev-{uid}")
            fallback_dir.mkdir(parents=True, exist_ok=True)
            self.config_dir = fallback_dir
            self.config_file = fallback_dir / "github.json"
            try:
                self.config_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
                self._cached_creds = None
                return True
            except OSError:
                return False

    def load_credentials(self) -> dict[str, Any]:
        """Return credentials for the currently active GitHub account."""
        if self._cached_creds is not None:
            return self._cached_creds

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        active_id = cfg.get("active_account_id", "")

        active_acc: dict[str, Any] | None = None
        for a in accounts:
            if a.get("account_id") == active_id:
                active_acc = a
                break
        if not active_acc and accounts:
            active_acc = accounts[0]
            active_id = active_acc.get("account_id", "")

        if active_acc:
            self._cached_creds = {
                "token": active_acc.get("token", ""),
                "account_id": active_acc.get("account_id", ""),
                "account_name": active_acc.get("account_name", ""),
                "username": active_acc.get("username", ""),
                "avatar_url": active_acc.get("avatar_url", ""),
                "email": active_acc.get("email", ""),
                "scopes": active_acc.get("scopes", []),
                "is_active": True,
            }
        else:
            self._cached_creds = {
                "token": "",
                "account_id": "",
                "account_name": "",
                "username": "",
                "avatar_url": "",
                "email": "",
                "scopes": [],
                "is_active": False,
            }
        return self._cached_creds

    def get_active_account_id(self) -> str:
        """Return the active GitHub account ID."""
        creds = self.load_credentials()
        return creds.get("account_id", "")

    def list_stored_accounts(self) -> list[dict[str, Any]]:
        """Return list of all saved GitHub accounts."""
        cfg = self._load_raw_config()
        active_id = cfg.get("active_account_id", "")
        accounts = []
        for a in cfg.get("accounts", []):
            tok = a.get("token", "")
            preview = f"{tok[:4]}...{tok[-4:]}" if len(tok) >= 12 else ("****" if tok else "")
            accounts.append({
                "account_id": a.get("account_id", ""),
                "account_name": a.get("account_name", ""),
                "username": a.get("username", ""),
                "name": a.get("name", ""),
                "avatar_url": a.get("avatar_url", ""),
                "email": a.get("email", ""),
                "scopes": a.get("scopes", []),
                "token_preview": preview,
                "is_active": a.get("account_id") == active_id,
            })
        return accounts

    def save_credentials(
        self,
        token: str,
        username: str = "",
        account_name: str = "",
        avatar_url: str = "",
        email: str = "",
        scopes: list[str] | None = None,
        make_active: bool = True,
    ) -> bool:
        """Save a new GitHub account or update an existing one."""
        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        account_id = username.strip().lower() or f"gh_{len(accounts) + 1}"

        existing_idx = -1
        for idx, acc in enumerate(accounts):
            if acc.get("account_id") == account_id or acc.get("username", "").lower() == username.lower():
                existing_idx = idx
                break

        entry = {
            "account_id": account_id,
            "account_name": account_name.strip() or username or "GitHub Account",
            "username": username.strip(),
            "avatar_url": avatar_url.strip(),
            "email": email.strip(),
            "token": token.strip(),
            "scopes": scopes or [],
        }

        if existing_idx >= 0:
            accounts[existing_idx] = entry
        else:
            accounts.append(entry)

        cfg["accounts"] = accounts
        if make_active or not cfg.get("active_account_id") or len(accounts) == 1:
            cfg["active_account_id"] = account_id

        self._cached_creds = None
        return self._save_raw_config(cfg)

    def switch_account(self, identifier: str) -> dict[str, Any]:
        """Switch active GitHub account by account_id, username, or account_name."""
        target = identifier.strip().lower()
        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])

        matched = None
        for a in accounts:
            if (
                a.get("account_id", "").lower() == target
                or a.get("username", "").lower() == target
                or a.get("account_name", "").lower() == target
            ):
                matched = a
                break

        if not matched:
            return {"ok": False, "error": f"Account '{identifier}' not found in stored GitHub accounts."}

        cfg["active_account_id"] = matched["account_id"]
        self._cached_creds = None
        self._save_raw_config(cfg)
        return {
            "ok": True,
            "account_id": matched["account_id"],
            "account_name": matched.get("account_name", ""),
            "username": matched.get("username", ""),
        }

    def remove_account(self, identifier: str) -> dict[str, Any]:
        """Remove a stored GitHub account."""
        target = identifier.strip().lower()
        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])

        remaining = []
        removed = None
        for a in accounts:
            if (
                a.get("account_id", "").lower() == target
                or a.get("username", "").lower() == target
                or a.get("account_name", "").lower() == target
            ):
                removed = a
            else:
                remaining.append(a)

        if not removed:
            return {"ok": False, "error": f"Account '{identifier}' not found."}

        cfg["accounts"] = remaining
        if cfg.get("active_account_id") == removed.get("account_id"):
            cfg["active_account_id"] = remaining[0]["account_id"] if remaining else ""

        self._cached_creds = None
        self._save_raw_config(cfg)
        return {
            "ok": True,
            "removed_id": removed["account_id"],
            "removed_name": removed.get("account_name", ""),
            "remaining_count": len(remaining),
            "new_active_id": cfg.get("active_account_id", ""),
        }

    def clear_credentials(self) -> bool:
        """Clear all stored GitHub accounts."""
        self._cached_creds = None
        try:
            self.config_file.unlink(missing_ok=True)
            return True
        except OSError:
            return False

    # ── HTTP Request Helper ──────────────────────────────────────────────────

    def _request(
        self,
        endpoint: str,
        method: str = "GET",
        data: dict[str, Any] | None = None,
        override_token: str | None = None,
        timeout: int = 15,
    ) -> dict[str, Any]:
        """Perform an HTTP request to GitHub REST API v3 with enriched diagnostics."""
        token = override_token if override_token is not None else self.load_credentials().get("token", "")
        if not token:
            return {
                "ok": False,
                "error": "GitHub Personal Access Token not configured",
                "cause_category": "missing_token",
                "cause_key": "missing_token",
                "cause_title": "GitHub API Token Not Configured",
                "cause_explanation": "A GitHub Personal Access Token is required to communicate with the GitHub API.",
                "cause_action": "Run 'laravel-dev gh auth' or connect your token via the GitHub section in the application UI.",
                "cause_title_ar": "لم يتم إدخال رمز GitHub API Token",
                "cause_explanation_ar": "التطبيق يحتاج إلى Personal Access Token للاتصال بحسابك في GitHub.",
                "cause_action_ar": "استخدم 'laravel-dev gh auth' أو اربط التوكن من خلال قسم GitHub بالواجهة.",
                "dashboard_url": "https://github.com/settings/tokens",
            }

        url = f"{GH_API_BASE}{endpoint}" if endpoint.startswith("/") else f"{GH_API_BASE}/{endpoint}"
        headers = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "Laravel-Dev-Tool/1.0",
        }

        body_bytes = json.dumps(data).encode("utf-8") if data is not None else None
        req = urllib.request.Request(url, data=body_bytes, headers=headers, method=method)

        ctx = ssl.create_default_context()
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                payload = json.loads(raw) if raw.strip() else {}
                scopes_header = resp.headers.get("X-OAuth-Scopes", "")
                scopes = [s.strip() for s in scopes_header.split(",") if s.strip()]
                rate_limit = {
                    "limit": resp.headers.get("X-RateLimit-Limit", "5000"),
                    "remaining": resp.headers.get("X-RateLimit-Remaining", "5000"),
                    "reset": resp.headers.get("X-RateLimit-Reset", "0"),
                }
                return {
                    "ok": True,
                    "data": payload,
                    "scopes": scopes,
                    "rate_limit": rate_limit,
                }
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", errors="replace")
            err_msg = f"HTTP {e.code}"
            err_code = 0
            try:
                parsed = json.loads(raw)
                err_msg = parsed.get("message") or err_msg
            except Exception:
                err_msg = f"{err_msg}: {raw[:200]}"

            username = self.load_credentials().get("username", "")
            diag = analyze_gh_error(
                error_message=err_msg,
                error_code=err_code,
                status_code=e.code,
                endpoint=endpoint,
                username=username,
            )

            return {
                "ok": False,
                "error": err_msg,
                "status_code": e.code,
                "cause_category": diag["category"],
                "cause_key": diag.get("key", "api_error"),
                "cause_title": diag["title"],
                "cause_explanation": diag["explanation"],
                "cause_action": diag["action"],
                "cause_title_ar": diag.get("title_ar", diag["title"]),
                "cause_explanation_ar": diag.get("explanation_ar", diag["explanation"]),
                "cause_action_ar": diag.get("action_ar", diag["action"]),
                "dashboard_url": diag["url"],
                "required_perm": diag.get("required_perm", ""),
            }
        except urllib.error.URLError as e:
            return {
                "ok": False,
                "error": f"Network connection failed: {e.reason}",
                "status_code": 0,
                "cause_category": "network_error",
                "cause_key": "network_error",
                "cause_title": "Unable to Connect to GitHub (Network Error)",
                "cause_explanation": "Could not connect to the Internet or reach api.github.com.",
                "cause_action": "Check your network connection and verify firewall allows connections to api.github.com.",
                "cause_title_ar": "تعذر الاتصال بخوادم GitHub (Network Error)",
                "cause_explanation_ar": "فشل الاتصال بالإنترنت أو تعذر الوصول إلى خوادم GitHub API.",
                "cause_action_ar": "تأكد من اتصال جهازك بالإنترنت وأن جدار الحماية لا يحظر الاتصال بـ api.github.com.",
                "dashboard_url": "https://www.githubstatus.com",
            }
        except Exception as e:
            return {
                "ok": False,
                "error": str(e),
                "cause_category": "unexpected_error",
                "cause_key": "unexpected_error",
                "cause_title": "Unexpected Error",
                "cause_explanation": str(e),
                "cause_action": "Retry the operation or inspect application logs.",
                "cause_title_ar": "خطأ غير متوقع",
                "cause_explanation_ar": str(e),
                "cause_action_ar": "أعد المحاولة أو تحقق من سجلات النظام.",
            }

    # ── Token Verification & User Discovery ──────────────────────────────────

    def verify_token(self, token: str) -> dict[str, Any]:
        """Verify Personal Access Token against /user and return profile and scopes."""
        res = self._request("/user", method="GET", override_token=token)
        if not res.get("ok"):
            return {
                "ok": False,
                "valid": False,
                "error": res.get("error", "Token verification failed."),
                "status_code": res.get("status_code", 0),
                "cause_category": res.get("cause_category", "invalid_token"),
                "cause_key": res.get("cause_key", "invalid_token"),
                "cause_title": res.get("cause_title", "Invalid or Unauthorized GitHub API Token"),
                "cause_explanation": res.get("cause_explanation", "GitHub rejected this token."),
                "cause_action": res.get("cause_action", "Check your token permissions and generate a new token if needed."),
                "cause_title_ar": res.get("cause_title_ar", "رمز الـ API غير صالح"),
                "cause_explanation_ar": res.get("cause_explanation_ar", "رفضت GitHub هذا الرمز."),
                "cause_action_ar": res.get("cause_action_ar", "تأكد من صلاحيات الرمز وانسخه بشكل صحيح."),
                "dashboard_url": res.get("dashboard_url", "https://github.com/settings/tokens"),
                "required_perm": "repo, workflow, read:org",
            }

        data = res.get("data", {})
        scopes = res.get("scopes", [])
        return {
            "ok": True,
            "valid": True,
            "username": data.get("login", ""),
            "name": data.get("name", "") or data.get("login", ""),
            "avatar_url": data.get("avatar_url", ""),
            "email": data.get("email", ""),
            "bio": data.get("bio", ""),
            "public_repos": data.get("public_repos", 0),
            "total_private_repos": data.get("total_private_repos", 0),
            "followers": data.get("followers", 0),
            "following": data.get("following", 0),
            "plan": (data.get("plan") or {}).get("name", "free"),
            "scopes": scopes,
            "rate_limit": res.get("rate_limit", {}),
        }

    def get_status(self) -> dict[str, Any]:
        """Return the current authentication status and active account info."""
        creds = self.load_credentials()
        has_token = bool(creds.get("token"))
        stored = self.list_stored_accounts()
        if not has_token:
            return {
                "configured": False,
                "accounts": stored,
                "total_accounts": len(stored),
            }

        tok = creds.get("token", "")
        masked = f"{tok[:4]}...{tok[-4:]}" if len(tok) >= 12 else "****"

        return {
            "configured": True,
            "account_id": creds.get("account_id", ""),
            "account_name": creds.get("account_name", ""),
            "username": creds.get("username", ""),
            "avatar_url": creds.get("avatar_url", ""),
            "email": creds.get("email", ""),
            "scopes": creds.get("scopes", []),
            "token_masked": masked,
            "accounts": stored,
            "total_accounts": len(stored),
        }

    # ── Repositories Management ──────────────────────────────────────────────

    def list_repos(
        self,
        visibility: str = "all",
        affiliation: str = "owner,collaborator,organization_member",
        sort: str = "updated",
        direction: str = "desc",
        page: int = 1,
        per_page: int = 50,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List repositories accessible to the active user (including org repos)."""
        qp: dict[str, Any] = {
            "visibility": visibility,
            "affiliation": affiliation,
            "sort": sort,
            "direction": direction,
            "page": page,
            "per_page": per_page,
        }
        params = urllib.parse.urlencode({k: v for k, v in qp.items() if v})
        res = self._request(f"/user/repos?{params}", method="GET")
        if not res.get("ok"):
            return res

        repos = []
        for r in (res.get("data") or []):
            if isinstance(r, dict):
                repos.append({
                    "id": r.get("id"),
                    "name": r.get("name"),
                    "full_name": r.get("full_name"),
                    "owner": (r.get("owner") or {}).get("login"),
                    "owner_avatar": (r.get("owner") or {}).get("avatar_url"),
                    "private": r.get("private", False),
                    "html_url": r.get("html_url"),
                    "clone_url": r.get("clone_url"),
                    "ssh_url": r.get("ssh_url"),
                    "description": r.get("description") or "",
                    "language": r.get("language") or "",
                    "default_branch": r.get("default_branch") or "main",
                    "stargazers_count": r.get("stargazers_count", 0),
                    "forks_count": r.get("forks_count", 0),
                    "open_issues_count": r.get("open_issues_count", 0),
                    "updated_at": r.get("updated_at"),
                    "created_at": r.get("created_at"),
                })
        return {"ok": True, "repos": repos, "page": page}

    def create_repo(
        self,
        name: str,
        description: str = "",
        private: bool = True,
        auto_init: bool = False,
        gitignore_template: str = "",
        license_template: str = "",
    ) -> dict[str, Any]:
        """Create a new GitHub repository."""
        data: dict[str, Any] = {
            "name": name.strip(),
            "description": description.strip(),
            "private": bool(private),
            "auto_init": bool(auto_init),
        }
        if gitignore_template:
            data["gitignore_template"] = gitignore_template
        if license_template:
            data["license_template"] = license_template

        res = self._request("/user/repos", method="POST", data=data)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {
            "ok": True,
            "name": d.get("name"),
            "full_name": d.get("full_name"),
            "html_url": d.get("html_url"),
            "clone_url": d.get("clone_url"),
            "ssh_url": d.get("ssh_url"),
            "default_branch": d.get("default_branch", "main"),
        }

    def delete_repo(self, owner_or_full_name: str, repo_name: str = "") -> dict[str, Any]:
        """Delete a GitHub repository."""
        if "/" in owner_or_full_name and not repo_name:
            owner, name = owner_or_full_name.split("/", 1)
        else:
            owner = owner_or_full_name
            name = repo_name

        return self._request(f"/repos/{owner.strip()}/{name.strip()}", method="DELETE")

    def get_repo(self, owner: str, repo: str) -> dict[str, Any]:
        """Get repository details."""
        return self._request(f"/repos/{owner.strip()}/{repo.strip()}", method="GET")

    def list_branches(self, owner: str, repo: str) -> dict[str, Any]:
        """List branches of a repository."""
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/branches?per_page=50", method="GET")
        if not res.get("ok"):
            return res
        branches = [b.get("name") for b in (res.get("data") or []) if isinstance(b, dict)]
        return {"ok": True, "branches": branches}

    # ── Pull Requests Management ─────────────────────────────────────────────

    def list_pulls(
        self,
        owner: str,
        repo: str,
        state: str = "open",
        page: int = 1,
        per_page: int = 30,
    ) -> dict[str, Any]:
        """List pull requests for a repository."""
        params = urllib.parse.urlencode({"state": state, "page": page, "per_page": per_page})
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/pulls?{params}", method="GET")
        if not res.get("ok"):
            return res

        pulls = []
        for p in (res.get("data") or []):
            if isinstance(p, dict):
                pulls.append({
                    "id": p.get("id"),
                    "number": p.get("number"),
                    "title": p.get("title"),
                    "state": p.get("state"),
                    "user": (p.get("user") or {}).get("login"),
                    "user_avatar": (p.get("user") or {}).get("avatar_url"),
                    "html_url": p.get("html_url"),
                    "head": (p.get("head") or {}).get("ref"),
                    "base": (p.get("base") or {}).get("ref"),
                    "created_at": p.get("created_at"),
                    "updated_at": p.get("updated_at"),
                    "draft": p.get("draft", False),
                })
        return {"ok": True, "pulls": pulls, "page": page}

    def create_pull(
        self,
        owner: str,
        repo: str,
        title: str,
        head: str,
        base: str = "main",
        body: str = "",
    ) -> dict[str, Any]:
        """Create a new pull request."""
        data = {
            "title": title.strip(),
            "head": head.strip(),
            "base": base.strip(),
            "body": body.strip(),
        }
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/pulls", method="POST", data=data)
        if not res.get("ok"):
            return res
        p = res.get("data") or {}
        return {
            "ok": True,
            "number": p.get("number"),
            "title": p.get("title"),
            "html_url": p.get("html_url"),
        }

    def merge_pull(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        merge_method: str = "merge",
        commit_title: str = "",
        commit_message: str = "",
    ) -> dict[str, Any]:
        """Merge a pull request ('merge', 'squash', or 'rebase')."""
        data: dict[str, Any] = {"merge_method": merge_method}
        if commit_title:
            data["commit_title"] = commit_title
        if commit_message:
            data["commit_message"] = commit_message

        res = self._request(
            f"/repos/{owner.strip()}/{repo.strip()}/pulls/{pull_number}/merge",
            method="PUT",
            data=data,
        )
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {
            "ok": True,
            "sha": d.get("sha"),
            "merged": d.get("merged", True),
            "message": d.get("message", "Pull request merged"),
        }

    def close_pull(self, owner: str, repo: str, pull_number: int) -> dict[str, Any]:
        """Close a pull request."""
        return self._request(
            f"/repos/{owner.strip()}/{repo.strip()}/pulls/{pull_number}",
            method="PATCH",
            data={"state": "closed"},
        )

    # ── Issues Management ────────────────────────────────────────────────────

    def list_issues(
        self,
        owner: str,
        repo: str,
        state: str = "open",
        page: int = 1,
        per_page: int = 30,
    ) -> dict[str, Any]:
        """List issues for a repository."""
        params = urllib.parse.urlencode({"state": state, "page": page, "per_page": per_page})
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/issues?{params}", method="GET")
        if not res.get("ok"):
            return res

        issues = []
        for i in (res.get("data") or []):
            if isinstance(i, dict) and "pull_request" not in i:  # Filter out PRs
                labels = [l.get("name") for l in i.get("labels", []) if isinstance(l, dict)]
                issues.append({
                    "id": i.get("id"),
                    "number": i.get("number"),
                    "title": i.get("title"),
                    "state": i.get("state"),
                    "user": (i.get("user") or {}).get("login"),
                    "user_avatar": (i.get("user") or {}).get("avatar_url"),
                    "html_url": i.get("html_url"),
                    "labels": labels,
                    "comments": i.get("comments", 0),
                    "created_at": i.get("created_at"),
                    "updated_at": i.get("updated_at"),
                })
        return {"ok": True, "issues": issues, "page": page}

    def create_issue(
        self,
        owner: str,
        repo: str,
        title: str,
        body: str = "",
        labels: list[str] | None = None,
        assignees: list[str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a new issue."""
        data: dict[str, Any] = {
            "title": title.strip(),
            "body": body.strip(),
        }
        if labels:
            data["labels"] = labels
        if assignees:
            data["assignees"] = assignees

        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/issues", method="POST", data=data)
        if not res.get("ok"):
            return res
        d = res.get("data") or {}
        return {
            "ok": True,
            "number": d.get("number"),
            "title": d.get("title"),
            "html_url": d.get("html_url"),
        }

    def close_issue(
        self,
        owner: str,
        repo: str,
        issue_number: int,
        state_reason: str = "completed",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Close an issue."""
        data: dict[str, Any] = {"state": "closed"}
        if state_reason:
            data["state_reason"] = state_reason
        return self._request(
            f"/repos/{owner.strip()}/{repo.strip()}/issues/{issue_number}",
            method="PATCH",
            data=data,
        )

    # ── GitHub Actions & CI/CD ───────────────────────────────────────────────

    def list_workflow_runs(
        self,
        owner: str,
        repo: str,
        branch: str = "",
        event: str = "",
        status: str = "",
        page: int = 1,
        per_page: int = 30,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List GitHub Actions workflow runs for a repository."""
        qp: dict[str, Any] = {"page": page, "per_page": per_page}
        if branch:
            qp["branch"] = branch
        if event:
            qp["event"] = event
        if status:
            qp["status"] = status
        params = urllib.parse.urlencode(qp)
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/actions/runs?{params}", method="GET")
        if not res.get("ok"):
            return res

        data = res.get("data") or {}
        runs = []
        for r in data.get("workflow_runs", []):
            if isinstance(r, dict):
                runs.append({
                    "id": r.get("id"),
                    "name": r.get("name"),
                    "head_branch": r.get("head_branch"),
                    "event": r.get("event"),
                    "status": r.get("status"),
                    "conclusion": r.get("conclusion"),
                    "html_url": r.get("html_url"),
                    "actor": (r.get("actor") or {}).get("login"),
                    "actor_avatar": (r.get("actor") or {}).get("avatar_url"),
                    "created_at": r.get("created_at"),
                    "updated_at": r.get("updated_at"),
                })
        return {"ok": True, "runs": runs, "total_count": data.get("total_count", len(runs))}

    def trigger_workflow(
        self,
        owner: str,
        repo: str,
        workflow_id: str = "",
        workflow_id_or_file: str = "",
        ref: str = "main",
        inputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Trigger a GitHub Actions workflow dispatch."""
        target_wf = (workflow_id or workflow_id_or_file).strip()
        data = {
            "ref": ref.strip(),
            "inputs": inputs or {},
        }
        res = self._request(
            f"/repos/{owner.strip()}/{repo.strip()}/actions/workflows/{target_wf}/dispatches",
            method="POST",
            data=data,
        )
        if not res.get("ok"):
            return res
        return {"ok": True, "message": f"Workflow {target_wf} triggered on branch '{ref}'."}

    # ── SSH & Deploy Keys ────────────────────────────────────────────────────

    def list_ssh_keys(self) -> dict[str, Any]:
        """List public SSH keys linked to the GitHub account."""
        res = self._request("/user/keys", method="GET")
        if not res.get("ok"):
            return res
        keys = []
        for k in (res.get("data") or []):
            if isinstance(k, dict):
                keys.append({
                    "id": k.get("id"),
                    "title": k.get("title"),
                    "key": k.get("key"),
                    "created_at": k.get("created_at"),
                })
        return {"ok": True, "keys": keys}

    def add_deploy_key(
        self,
        owner: str,
        repo: str,
        title: str,
        key: str,
        read_only: bool = True,
    ) -> dict[str, Any]:
        """Add an SSH Deploy Key to a repository."""
        data = {
            "title": title.strip(),
            "key": key.strip(),
            "read_only": bool(read_only),
        }
        res = self._request(f"/repos/{owner.strip()}/{repo.strip()}/keys", method="POST", data=data)
        if not res.get("ok"):
            return res
        return {"ok": True, "id": (res.get("data") or {}).get("id"), "title": title}

    # ── Local Laravel Sites & Git Integration ────────────────────────────────

    def resolve_site_dir(self, site_name_or_path: str) -> Path | None:
        """Resolve site name or path to a directory."""
        target = Path(site_name_or_path).resolve()
        if target.is_dir():
            return target

        sites_dir = Path.home() / "Sites"
        cand = sites_dir / site_name_or_path
        if cand.is_dir():
            return cand

        # Try /var/www
        cand_var = Path("/var/www") / site_name_or_path
        if cand_var.is_dir():
            return cand_var

        return None

    def get_site_git_status(self, site_name_or_path: str) -> dict[str, Any]:
        """Inspect git status for a local site directory."""
        sdir = self.resolve_site_dir(site_name_or_path)
        if not sdir:
            return {"ok": False, "error": f"Site directory '{site_name_or_path}' not found."}

        git_dir = sdir / ".git"
        if not git_dir.is_dir():
            return {
                "ok": True,
                "is_git": False,
                "path": str(sdir),
                "remote_url": "",
                "branch": "",
                "clean": True,
                "unpushed": 0,
            }

        def run_git(args: list[str]) -> str:
            try:
                res = subprocess.run(["git", "-C", str(sdir)] + args, capture_output=True, text=True, check=False)
                return res.stdout.strip()
            except Exception:
                return ""

        remote_url = run_git(["config", "--get", "remote.origin.url"])
        branch = run_git(["rev-parse", "--abbrev-ref", "HEAD"]) or "main"
        status_porcelain = run_git(["status", "--porcelain"])
        unpushed_str = run_git(["rev-list", f"@{'{u}'}..HEAD", "--count"])
        unpushed = int(unpushed_str) if unpushed_str.isdigit() else 0

        # Parse owner and repo name from remote url
        repo_owner = ""
        repo_name = ""
        if remote_url:
            m = re.search(r"github\.com[:/]([^/]+)/([^/\.]+)(?:\.git)?", remote_url)
            if m:
                repo_owner = m.group(1)
                repo_name = m.group(2)

        return {
            "ok": True,
            "is_git": True,
            "path": str(sdir),
            "remote_url": remote_url,
            "repo_owner": repo_owner,
            "repo_name": repo_name,
            "repo_full_name": f"{repo_owner}/{repo_name}" if repo_owner and repo_name else "",
            "branch": branch,
            "clean": not bool(status_porcelain),
            "unpushed": unpushed,
        }

    def publish_site(
        self,
        site_name_or_path: str,
        repo_name: str = "",
        private: bool = True,
        description: str = "",
    ) -> dict[str, Any]:
        """Publish a local site to a new GitHub repository (init, create, remote, push)."""
        sdir = self.resolve_site_dir(site_name_or_path)
        if not sdir:
            return {"ok": False, "error": f"Site directory '{site_name_or_path}' not found."}

        rname = repo_name.strip() or sdir.name
        creds = self.load_credentials()
        token = creds.get("token")
        if not token:
            return {"ok": False, "error": "GitHub Personal Access Token not configured."}

        # 1. Create repo on GitHub
        create_res = self.create_repo(
            name=rname,
            description=description or f"Laravel application {rname}",
            private=private,
            auto_init=False,
        )
        if not create_res.get("ok"):
            return create_res

        clone_url = create_res.get("clone_url", "")
        html_url = create_res.get("html_url", "")
        owner = creds.get("username", "")

        # 2. Local git orchestration
        def run_cmd(args: list[str]) -> subprocess.CompletedProcess[str]:
            return subprocess.run(args, cwd=str(sdir), capture_output=True, text=True, check=False)

        if not (sdir / ".git").is_dir():
            run_cmd(["git", "init", "-b", "main"])

        # Check default gitignore
        gitignore = sdir / ".gitignore"
        if not gitignore.exists():
            default_gi = "/node_modules\n/public/build\n/public/hot\n/public/storage\n/storage/*.key\n/vendor\n.env\n.env.backup\n.phpunit.result.cache\nHomestead.json\nHomestead.yaml\npm2.json\nauth.json\n"
            try:
                gitignore.write_text(default_gi, encoding="utf-8")
            except OSError:
                pass

        # Commit initial changes if no commits
        head_check = run_cmd(["git", "rev-parse", "HEAD"])
        if head_check.returncode != 0:
            run_cmd(["git", "add", "."])
            run_cmd(["git", "commit", "-m", "Initial commit from Laravel Dev Tool"])

        # Set authenticated remote URL
        auth_url = f"https://oauth2:{token}@github.com/{owner}/{rname}.git"
        run_cmd(["git", "remote", "remove", "origin"])
        add_remote = run_cmd(["git", "remote", "add", "origin", auth_url])
        if add_remote.returncode != 0:
            run_cmd(["git", "remote", "set-url", "origin", auth_url])

        # Push to main
        push_res = run_cmd(["git", "push", "-u", "origin", "main"])
        if push_res.returncode != 0:
            # Fallback to master if branch was master
            push_res = run_cmd(["git", "push", "-u", "origin", "master"])

        # Clean token from remote origin url so plain credentials aren't saved in git config
        clean_remote = f"https://github.com/{owner}/{rname}.git"
        run_cmd(["git", "remote", "set-url", "origin", clean_remote])

        return {
            "ok": True,
            "name": rname,
            "owner": owner,
            "full_name": f"{owner}/{rname}",
            "html_url": html_url,
            "clone_url": clone_url,
            "push_success": push_res.returncode == 0,
            "push_output": push_res.stdout or push_res.stderr,
        }

    def link_site(self, site_name_or_path: str, repo_full_name: str) -> dict[str, Any]:
        """Bind an existing local site to an existing GitHub repository."""
        sdir = self.resolve_site_dir(site_name_or_path)
        if not sdir:
            return {"ok": False, "error": f"Site directory '{site_name_or_path}' not found."}

        target_repo = repo_full_name.strip()
        if "/" not in target_repo:
            return {"ok": False, "error": "Repo full name must be in format 'owner/repo'."}

        def run_cmd(args: list[str]) -> subprocess.CompletedProcess[str]:
            return subprocess.run(args, cwd=str(sdir), capture_output=True, text=True, check=False)

        if not (sdir / ".git").is_dir():
            run_cmd(["git", "init", "-b", "main"])

        remote_url = f"https://github.com/{target_repo}.git"
        run_cmd(["git", "remote", "remove", "origin"])
        res = run_cmd(["git", "remote", "add", "origin", remote_url])

        return {
            "ok": res.returncode == 0,
            "remote_url": remote_url,
            "repo_full_name": target_repo,
        }

    def clone_repo(self, repo_full_name: str, target_dir_or_name: str = "") -> dict[str, Any]:
        """Clone a GitHub repository into local Laravel Sites directory."""
        creds = self.load_credentials()
        token = creds.get("token")
        if not token:
            return {"ok": False, "error": "GitHub Personal Access Token not configured."}

        repo_part = repo_full_name.strip()
        if "/" not in repo_part:
            owner = creds.get("username", "")
            if not owner:
                return {"ok": False, "error": "Repo full name must be in format 'owner/repo'."}
            repo_part = f"{owner}/{repo_part}"

        repo_name = repo_part.split("/")[-1]
        sites_dir = Path.home() / "Sites"
        sites_dir.mkdir(parents=True, exist_ok=True)

        if target_dir_or_name:
            t = Path(target_dir_or_name).expanduser()
            dest = t if t.is_absolute() else (sites_dir / target_dir_or_name)
        else:
            dest = sites_dir / repo_name
        if dest.exists() and any(dest.iterdir()):
            return {"ok": False, "error": f"Destination directory '{dest}' already exists and is not empty."}

        auth_url = f"https://oauth2:{token}@github.com/{repo_part}.git"
        clean_url = f"https://github.com/{repo_part}.git"

        res = subprocess.run(["git", "clone", auth_url, str(dest)], capture_output=True, text=True, check=False)
        if res.returncode != 0:
            return {"ok": False, "error": f"Clone failed: {res.stderr or res.stdout}"}

        # Reset remote to clean URL
        subprocess.run(["git", "-C", str(dest), "remote", "set-url", "origin", clean_url], capture_output=True, check=False)

        return {
            "ok": True,
            "destination": str(dest),
            "site_name": dest.name,
            "repo_full_name": repo_part,
        }


# ── Terminal Output Helpers ──────────────────────────────────────────────────

def _colorize(text: str, color_code: str, is_tty: bool = True) -> str:
    if not is_tty or not color_code:
        return text
    return f"\033[{color_code}m{text}\033[0m"


def _print_table(headers: list[str], rows: list[list[str]], is_tty: bool = True) -> None:
    if not headers or not rows:
        return
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, val in enumerate(row):
            if i < len(col_widths):
                col_widths[i] = max(col_widths[i], len(str(val)))
    header_str = "  ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
    sep_str = "  ".join("-" * col_widths[i] for i in range(len(headers)))
    print(_colorize(header_str, "1;36", is_tty))
    print(_colorize(sep_str, "90", is_tty))
    for row in rows:
        line = "  ".join(str(row[i]).ljust(col_widths[i]) if i < len(row) else "".ljust(col_widths[i]) for i in range(len(headers)))
        print(line)


def _print_error_card(res: dict[str, Any], is_tty: bool = True) -> None:
    raw_err = res.get("error", "Unknown error")
    title = res.get("cause_title", "")
    expl = res.get("cause_explanation", "")
    act = res.get("cause_action", "")
    url = res.get("dashboard_url", "")
    perm = res.get("required_perm", "")

    title_ar = res.get("cause_title_ar", "")
    expl_ar = res.get("cause_explanation_ar", "")
    act_ar = res.get("cause_action_ar", "")

    print(_colorize(f"\n✖ Error: {raw_err}", "1;31", is_tty), file=sys.stderr)
    if title:
        print(_colorize(f"  [Root Cause] {title}", "1;33", is_tty), file=sys.stderr)
    if expl:
        print(f"  {expl}", file=sys.stderr)
    if perm:
        print(_colorize(f"  Required Token Scope: {perm}", "1;36", is_tty), file=sys.stderr)
    if act:
        print(_colorize(f"  [Suggested Fix] {act}", "1;32", is_tty), file=sys.stderr)
    if url:
        print(_colorize(f"  Dashboard Link: {url}", "4;34", is_tty), file=sys.stderr)

    if title_ar and title_ar != title:
        print(_colorize(f"  (عربي) {title_ar}: {act_ar or expl_ar}", "90", is_tty), file=sys.stderr)

    print(file=sys.stderr)


# ── Main CLI Dispatch ────────────────────────────────────────────────────────

def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    is_json = "--json" in argv
    clean_argv = [a for a in argv if a != "--json"]
    cmd = clean_argv[0] if clean_argv else "status"
    is_tty = sys.stdout.isatty() and not is_json

    gh = GitHubClient()

    try:
        if cmd == "status":
            st = gh.get_status()
            if is_json:
                print(json.dumps(st, indent=2))
                return 0
            print(_colorize("GitHub Account Status", "1;34", is_tty))
            print("=" * 35)
            if st.get("configured"):
                print(f"  Active User:    {_colorize(st.get('username', 'N/A'), '1;32', is_tty)} ({st.get('account_name', '')})")
                print(f"  Email:          {st.get('email') or 'N/A'}")
                print(f"  Token:          {st.get('token_masked')}")
                scopes = ", ".join(st.get("scopes", [])) or "No explicit scopes"
                print(f"  Scopes:         {_colorize(scopes, '1;36', is_tty)}")
                print(f"  Status:         {_colorize('Connected', '1;32', is_tty)}")
                tot = st.get("total_accounts", 1)
                if tot > 1:
                    print(f"  Total Accounts: {tot} linked (use 'laravel-dev gh accounts' or 'laravel-dev gh switch')")
            else:
                print(f"  Status:         {_colorize('Not Configured', '1;33', is_tty)}")
                print("  Run 'laravel-dev gh auth' to connect your Personal Access Token.")
            return 0

        elif cmd in ("accounts", "account-list"):
            accs = gh.list_stored_accounts()
            if is_json:
                print(json.dumps({"ok": True, "accounts": accs}, indent=2))
                return 0
            if not accs:
                print(_colorize("No GitHub accounts linked.", "1;33", is_tty))
                print("Run 'laravel-dev gh auth' to connect an account.")
                return 0
            print(_colorize(f"Linked GitHub Accounts ({len(accs)} total):", "1;34", is_tty))
            rows = [
                [
                    "✔ Active" if a.get("is_active") else "",
                    a.get("username", ""),
                    a.get("account_name", ""),
                    a.get("email", ""),
                    a.get("token_preview", ""),
                ]
                for a in accs
            ]
            _print_table(["Status", "Username", "Label", "Email", "Token"], rows, is_tty)
            return 0

        elif cmd in ("switch", "use"):
            target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target:
                print(_colorize("Usage: laravel-dev gh switch <username_or_label>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = gh.switch_account(target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Switched active GitHub account to: {res.get('username')} ({res.get('account_name')})", "1;32", is_tty))
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd in ("remove", "rm"):
            target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target:
                print(_colorize("Usage: laravel-dev gh remove <username_or_label>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = gh.remove_account(target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Removed account: {res.get('removed_name')} ({res.get('removed_id')})", "1;32", is_tty))
                if res.get("remaining_count"):
                    print(f"  Active account is now: {res.get('new_active_id')}")
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd == "auth":
            token = clean_argv[1] if len(clean_argv) > 1 and not clean_argv[1].startswith("--") else ""
            custom_name = ""
            for i, a in enumerate(clean_argv):
                if a == "--name" and i + 1 < len(clean_argv):
                    custom_name = clean_argv[i + 1]

            if not token:
                if is_tty:
                    import getpass
                    token = getpass.getpass("Enter GitHub Personal Access Token (PAT): ").strip()
                else:
                    token = sys.stdin.read().strip()
            if not token:
                print(_colorize("Error: API token cannot be empty.", "1;31", is_tty), file=sys.stderr)
                return 1

            verify = gh.verify_token(token)
            if not verify.get("valid"):
                if is_json:
                    print(json.dumps(verify, indent=2))
                else:
                    _print_error_card(verify, is_tty)
                return 1

            username = verify.get("username", "")
            name = custom_name or verify.get("name", "") or username
            gh.save_credentials(
                token=token,
                username=username,
                account_name=name,
                avatar_url=verify.get("avatar_url", ""),
                email=verify.get("email", ""),
                scopes=verify.get("scopes", []),
                make_active=True,
            )

            if is_json:
                print(json.dumps({"ok": True, "username": username, "account_name": name}))
            else:
                print(_colorize(f"✔ GitHub account connected successfully: {username} ({name})!", "1;32", is_tty))
                scopes_str = ", ".join(verify.get("scopes", [])) or "none"
                print(f"  Scopes granted: {_colorize(scopes_str, '1;36', is_tty)}")
            return 0

        elif cmd in ("logout", "disconnect"):
            gh.clear_credentials()
            if is_json:
                print(json.dumps({"ok": True}))
            else:
                print(_colorize("✔ GitHub credentials removed.", "1;32", is_tty))
            return 0

        elif cmd in ("repos", "repo-list"):
            vis = "all"
            for a in clean_argv:
                if a in ("public", "private", "forks"):
                    vis = a
            res = gh.list_repos(visibility=vis)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if not res.get("ok"):
                _print_error_card(res, is_tty)
                return 1
            repos = res.get("repos", [])
            print(_colorize(f"GitHub Repositories ({len(repos)} total):", "1;34", is_tty))
            rows = [
                [
                    r.get("full_name", ""),
                    "Private" if r.get("private") else "Public",
                    r.get("language") or "-",
                    f"⭐ {r.get('stargazers_count', 0)}",
                    r.get("default_branch", "main"),
                    (r.get("updated_at") or "")[:10],
                ]
                for r in repos
            ]
            _print_table(["Repository", "Visibility", "Lang", "Stars", "Branch", "Updated"], rows, is_tty)
            return 0

        elif cmd in ("repo", "repository"):
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "create":
                name = clean_argv[2] if len(clean_argv) > 2 else ""
                if not name:
                    print(_colorize("Usage: laravel-dev gh repo create <name> [--public] [--desc '...']", "1;33", is_tty), file=sys.stderr)
                    return 1
                is_public = "--public" in argv
                desc = ""
                for i, a in enumerate(clean_argv):
                    if a == "--desc" and i + 1 < len(clean_argv):
                        desc = clean_argv[i + 1]

                res = gh.create_repo(name=name, description=desc, private=not is_public)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Repository '{res.get('full_name')}' created successfully!", "1;32", is_tty))
                    print(f"  URL: {res.get('html_url')}")
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "delete":
                target = clean_argv[2] if len(clean_argv) > 2 else ""
                if not target:
                    print(_colorize("Usage: laravel-dev gh repo delete <owner/repo>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = gh.delete_repo(target)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Repository '{target}' deleted.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "clone":
                target = clean_argv[2] if len(clean_argv) > 2 else ""
                dest = clean_argv[3] if len(clean_argv) > 3 else ""
                if not target:
                    print(_colorize("Usage: laravel-dev gh repo clone <owner/repo> [target_dir]", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = gh.clone_repo(target, dest)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Cloned '{target}' successfully to: {res.get('destination')}", "1;32", is_tty))
                    print(f"  Registered as site '{res.get('site_name')}'")
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd in ("pr", "pulls", "pull-request"):
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "list":
                repo_target = clean_argv[2] if len(clean_argv) > 2 and "/" in clean_argv[2] else ""
                if not repo_target:
                    print(_colorize("Usage: laravel-dev gh pr list <owner/repo> [--state open|closed|all]", "1;33", is_tty), file=sys.stderr)
                    return 1
                owner, repo = repo_target.split("/", 1)
                st_filter = "open"
                for a in clean_argv:
                    if a in ("closed", "all"):
                        st_filter = a
                res = gh.list_pulls(owner, repo, state=st_filter)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                prs = res.get("pulls", [])
                print(_colorize(f"Pull Requests for {repo_target} ({len(prs)} total):", "1;34", is_tty))
                rows = [
                    [f"#{p.get('number')}", p.get("title", ""), p.get("user", ""), f"{p.get('head')} -> {p.get('base')}", p.get("state", "")]
                    for p in prs
                ]
                _print_table(["#", "Title", "Author", "Branches", "State"], rows, is_tty)
                return 0

            elif sub == "merge":
                repo_target = clean_argv[2] if len(clean_argv) > 2 else ""
                num_str = clean_argv[3] if len(clean_argv) > 3 else ""
                if not repo_target or not num_str.isdigit():
                    print(_colorize("Usage: laravel-dev gh pr merge <owner/repo> <pr_number> [--squash|--rebase]", "1;33", is_tty), file=sys.stderr)
                    return 1
                method = "squash" if "--squash" in argv else ("rebase" if "--rebase" in argv else "merge")
                owner, repo = repo_target.split("/", 1)
                res = gh.merge_pull(owner, repo, int(num_str), merge_method=method)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Pull request #{num_str} merged successfully ({method})!", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd in ("issues", "issue"):
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "list":
                repo_target = clean_argv[2] if len(clean_argv) > 2 and "/" in clean_argv[2] else ""
                if not repo_target:
                    print(_colorize("Usage: laravel-dev gh issues list <owner/repo> [--state open|closed]", "1;33", is_tty), file=sys.stderr)
                    return 1
                owner, repo = repo_target.split("/", 1)
                st_filter = "closed" if "--closed" in argv else "open"
                res = gh.list_issues(owner, repo, state=st_filter)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                issues = res.get("issues", [])
                print(_colorize(f"Issues for {repo_target} ({len(issues)} total):", "1;34", is_tty))
                rows = [
                    [f"#{i.get('number')}", i.get("title", ""), i.get("user", ""), ",".join(i.get("labels", [])), i.get("state", "")]
                    for i in issues
                ]
                _print_table(["#", "Title", "Author", "Labels", "State"], rows, is_tty)
                return 0

        elif cmd in ("actions", "runs"):
            repo_target = clean_argv[1] if len(clean_argv) > 1 and "/" in clean_argv[1] else ""
            if not repo_target:
                print(_colorize("Usage: laravel-dev gh actions <owner/repo>", "1;33", is_tty), file=sys.stderr)
                return 1
            owner, repo = repo_target.split("/", 1)
            res = gh.list_workflow_runs(owner, repo)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if not res.get("ok"):
                _print_error_card(res, is_tty)
                return 1
            runs = res.get("runs", [])
            print(_colorize(f"GitHub Actions runs for {repo_target} ({len(runs)} total):", "1;34", is_tty))
            rows = [
                [
                    str(r.get("id")),
                    r.get("name", ""),
                    r.get("head_branch", ""),
                    r.get("conclusion") or r.get("status", ""),
                    (r.get("created_at") or "")[:19].replace("T", " "),
                ]
                for r in runs
            ]
            _print_table(["Run ID", "Workflow", "Branch", "Status", "Started"], rows, is_tty)
            return 0

        elif cmd == "publish":
            site_target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not site_target:
                print(_colorize("Usage: laravel-dev gh publish <site_name_or_path> [--public] [--name 'repo_name']", "1;33", is_tty), file=sys.stderr)
                return 1
            is_public = "--public" in argv
            custom_repo = ""
            for i, a in enumerate(clean_argv):
                if a == "--name" and i + 1 < len(clean_argv):
                    custom_repo = clean_argv[i + 1]

            res = gh.publish_site(site_target, repo_name=custom_repo, private=not is_public)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Site '{site_target}' published to GitHub successfully!", "1;32", is_tty))
                print(f"  Repository: {res.get('full_name')}")
                print(f"  URL:        {res.get('html_url')}")
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd == "link":
            site_target = clean_argv[1] if len(clean_argv) > 1 else ""
            repo_target = clean_argv[2] if len(clean_argv) > 2 else ""
            if not site_target or not repo_target:
                print(_colorize("Usage: laravel-dev gh link <site_name_or_path> <owner/repo>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = gh.link_site(site_target, repo_target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Site '{site_target}' linked to GitHub repository '{repo_target}'!", "1;32", is_tty))
                return 0
            _print_error_card(res, is_tty)
            return 1

        else:
            print(_colorize(f"Unknown command '{cmd}'.", "1;31", is_tty), file=sys.stderr)
            print("Available commands: status, auth, logout, accounts, switch, remove, repos, repo, pr, issues, actions, publish, link", file=sys.stderr)
            return 1

    except KeyboardInterrupt:
        print("\nAborted.")
        return 130
    except Exception as exc:
        if is_json:
            print(json.dumps({"ok": False, "error": str(exc)}))
        else:
            print(_colorize(f"Fatal error: {exc}", "1;31", is_tty), file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
