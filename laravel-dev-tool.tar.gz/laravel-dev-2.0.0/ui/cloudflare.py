"""Cloudflare API Integration Client for Laravel Dev Tool.
Provides lightweight, dependency-free interactions with Cloudflare REST API v4:
Token verification, Zones, DNS records, Cache purging, Development mode,
Cloudflare R2 Object Storage, and Named Tunnels.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import ssl
import time
import urllib.error
import urllib.request
from typing import Any

try:
    from osutil import private_file
except ImportError:
    from ui.osutil import private_file

CF_API_BASE = "https://api.cloudflare.com/client/v4"


def _config_dirs() -> tuple[Path, Path]:
    uid = os.getuid() if hasattr(os, "getuid") else 1000
    candidates = [
        Path.home() / ".config" / "laravel-dev",
        Path(f"/tmp/laravel-dev-{uid}"),
    ]
    writable_dir = candidates[-1]
    for d in candidates:
        try:
            d.mkdir(parents=True, exist_ok=True)
            test_file = d / ".cf_write_test"
            test_file.touch()
            test_file.unlink(missing_ok=True)
            writable_dir = d
            break
        except OSError:
            continue

    writable_file = writable_dir / "cloudflare.json"

    # If writable_dir is fallback, copy existing primary config if present
    if writable_dir != candidates[0]:
        primary_file = candidates[0] / "cloudflare.json"
        if primary_file.is_file() and not writable_file.is_file():
            try:
                writable_file.write_text(primary_file.read_text(encoding="utf-8"), encoding="utf-8")
                try:
                    os.chmod(writable_file, 0o600)
                except OSError:
                    pass
            except OSError:
                pass

    return writable_dir, writable_file


def analyze_cf_error(
    error_message: str,
    error_code: int = 0,
    status_code: int = 0,
    endpoint: str = "",
    account_id: str = "",
) -> dict[str, str]:
    """Analyze Cloudflare error and return user-friendly cause, guidance, and direct dashboard URL."""
    msg = error_message.lower().strip()
    dash_base = f"https://dash.cloudflare.com/{account_id}" if account_id else "https://dash.cloudflare.com"

    # 1. R2 Not Enabled on Account
    if (
        error_code in (10042, 10043)
        or "enable r2" in msg
        or ("r2" in endpoint and status_code in (400, 403) and ("enable" in msg or "dashboard" in msg))
    ):
        return {
            "category": "service_inactive",
            "key": "r2_activation_required",
            "title": "Cloudflare R2 Activation Required in Dashboard",
            "explanation": "Cloudflare R2 is not yet enabled on your account. Your API token is valid, but Cloudflare requires you to enable R2 and accept terms once via the Cloudflare Dashboard before API access is permitted.",
            "action": "Click the button below to visit Cloudflare Dashboard and enable R2 (includes 10 GB/month free storage with zero egress fees).",
            "title_ar": "تفعيل خدمة R2 مطلوب عبر لوحة التحكم",
            "explanation_ar": "خدمة Cloudflare R2 غير مفعّلة بعد في حسابك. رمز الـ API سليم، لكن منصة Cloudflare تفرض تفعيل الخدمة لمرة واحدة أولاً وقبول الشروط قبل السماح لأي اتصال API باستعراض أو إنشاء الـ Buckets.",
            "action_ar": "ادخل إلى لوحة Cloudflare واضغط على 'Enable R2' للموافقة على الشروط (خدمة R2 مجانية وتتضمن 10GB شهرياً بدون أي رسوم نقل بيانات).",
            "url": f"https://dash.cloudflare.com/{account_id}/r2/overview" if account_id else "https://dash.cloudflare.com",
            "required_perm": "Workers R2 Storage: Edit",
        }

    # 2. Missing Permissions / Unauthorized
    if (
        status_code in (401, 403)
        or error_code in (10000, 9109, 9106, 9107, 6003)
        or "unauthorized" in msg
        or "permission" in msg
        or "actor does not have permission" in msg
    ):
        if "/dns_records" in endpoint:
            perm = "Zone > DNS > Edit"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/purge_cache" in endpoint:
            perm = "Zone > Cache Purge > Purge"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/settings" in endpoint:
            perm = "Zone > Zone Settings > Edit"
            scope_hint = "All Zones or specific domain"
            scope_hint_ar = "All Zones أو النطاق المحدد"
        elif "/zones" in endpoint:
            perm = "Zone > Zone > Read"
            scope_hint = "All Zones"
            scope_hint_ar = "All Zones"
        elif "/r2" in endpoint:
            perm = "Account > Workers R2 Storage > Edit"
            scope_hint = "All Accounts"
            scope_hint_ar = "All Accounts"
        elif "/cfd_tunnel" in endpoint:
            perm = "Account > Cloudflare Tunnel > Edit"
            scope_hint = "All Accounts"
            scope_hint_ar = "All Accounts"
        else:
            perm = "Required service permissions"
            scope_hint = "All Accounts or All Zones"
            scope_hint_ar = "All Accounts أو All Zones"

        return {
            "category": "missing_permission",
            "key": "missing_permission",
            "title": f"Missing API Token Permission ({perm})",
            "explanation": f"The active API token does not have sufficient permissions to perform this operation. Cloudflare rejected the request because [{perm}] permission is missing for [{scope_hint}].",
            "action": f"Go to Cloudflare Dashboard > My Profile > API Tokens, click 'Edit' next to your active token, add the [{perm}] permission, and save.",
            "title_ar": f"نقص في صلاحيات رمز الـ API ({perm})",
            "explanation_ar": f"رمز الـ API الحالي لا يملك صلاحية كافية لتنفيذ هذه العملية. ترفض Cloudflare هذا الطلب لنقص الصلاحية: [{perm}] ضمن النطاق [{scope_hint_ar}].",
            "action_ar": f"انتقل إلى Cloudflare Dashboard > My Profile > API Tokens، واضغط 'Edit' بجانب التوكن الحالي وقم بإضافة صلاحية [{perm}] ثم احفظ التعديل.",
            "url": "https://dash.cloudflare.com/profile/api-tokens",
            "required_perm": perm,
        }

    # 3. DNS Record Conflict
    if (
        error_code in (1001, 81044, 81057, 81058, 81053)
        or "already exists" in msg
        or "conflict" in msg
    ):
        return {
            "category": "dns_conflict",
            "key": "dns_record_conflict",
            "title": "DNS Record Conflict (Already Exists)",
            "explanation": "A DNS record with the same name or a conflicting type already exists (for example, creating a CNAME record when an A record already exists for the same hostname).",
            "action": "Delete or edit the existing record first in the 'Domains & DNS' tab, or use a different subdomain name.",
            "title_ar": "تعارض في سجلات الـ DNS (Record Conflict)",
            "explanation_ar": "يوجد سجل DNS سابق بنفس الاسم أو بنوع يتعارض معه (مثل محاولة إنشاء سجل CNAME بينما يوجد سجل A مسبق لنفس الاسم).",
            "action_ar": "احذف أو عدّل السجل القديم أولاً من تبويب 'Domains & DNS'، أو استخدم اسماً فرعياً (Subdomain) مختلفاً.",
            "url": dash_base,
            "required_perm": "",
        }

    # 4. DNS Validation Error
    if (
        error_code in (1004, 9003, 81040)
        or "invalid ipv4" in msg
        or "invalid ip" in msg
        or "content for" in msg
    ):
        return {
            "category": "validation_error",
            "key": "dns_invalid_content",
            "title": "Invalid DNS Record Content or Format",
            "explanation": "The value entered in the content field does not match the chosen record type (e.g. an A record requires a valid IPv4 address like 192.0.2.1).",
            "action": "Ensure the record type is correct and enter a valid IP address or target without extra spaces.",
            "title_ar": "صيغة بيانات السجل غير صحيحة (Invalid DNS Content)",
            "explanation_ar": "القيمة المدخلة في حقل المحتوى لا تطابق نوع السجل المختار (سجل A يتطلب عنوان IPv4 صالح مثل 192.0.2.1).",
            "action_ar": "تأكد من اختيار نوع السجل الصحيح وكتابة عنوان IP صالح بدون مسافات إضافية.",
            "url": dash_base,
            "required_perm": "",
        }

    # 5. Pending Nameservers
    if (
        error_code in (10001, 10002)
        or "pending" in msg
        or "not active" in msg
    ):
        return {
            "category": "zone_pending",
            "key": "zone_nameservers_pending",
            "title": "Domain Nameservers Pending Activation",
            "explanation": "The domain is not active on Cloudflare yet because the authoritative nameservers have not been updated or propagated at your domain registrar.",
            "action": "Ensure your domain registrar's nameservers are set to Cloudflare's assigned nameservers. DNS propagation may take up to 24-48 hours.",
            "title_ar": "النطاق قيد انتظار خوادم الأسماء (Nameservers Pending)",
            "explanation_ar": "النطاق لم يصبح نشطاً بالكامل على شبكة Cloudflare بعد، ولا تزال خوادم الأسماء (Nameservers) بحاجة للتحديث لدى الشركة المسجلة للنطاق.",
            "action_ar": "تأكد من تغيير خوادم الأسماء (Nameservers) عند مسجل النطاق لتطابق خوادم Cloudflare، وقد يستغرق انتشار الـ DNS بضع ساعات.",
            "url": "https://dash.cloudflare.com",
            "required_perm": "",
        }

    # 6. Zero Trust Central Tunnels Setup
    if "/cfd_tunnel" in endpoint and (status_code in (400, 403, 404) or "team" in msg or "tunnel" in msg):
        return {
            "category": "zero_trust_setup",
            "key": "zero_trust_setup",
            "title": "Zero Trust Team Setup Required",
            "explanation": "Named Cloudflare Tunnels require an initial one-time Cloudflare Zero Trust team setup on your account (free for up to 50 users).",
            "action": "Open the Zero Trust dashboard and complete the initial team name onboarding step.",
            "title_ar": "خدمة Zero Trust تتطلب الإعداد الأولي لمرة واحدة",
            "explanation_ar": "أنفاق Zero Trust المسمّاة تتطلب أن تكون خدمة Cloudflare Zero Trust مهيأة لحسابك (الخدمة مجانية حتى 50 مستخدم).",
            "action_ar": "ادخل إلى لوحة تحكم Zero Trust وأكمل خطوة إعداد اسم الفريق (Team Name) لمرة واحدة.",
            "url": "https://one.dash.cloudflare.com/",
            "required_perm": "Account > Cloudflare Tunnel: Edit",
        }

    # 7. Rate Limiting
    if status_code == 429 or "rate limit" in msg or error_code == 10013:
        return {
            "category": "rate_limited",
            "key": "rate_limit_exceeded",
            "title": "Cloudflare API Rate Limit Exceeded",
            "explanation": "Too many requests were sent to the Cloudflare API in a short period of time.",
            "action": "Please wait 30-60 seconds before retrying.",
            "title_ar": "تم تجاوز حد الطلبات المؤقت (Rate Limit Exceeded)",
            "explanation_ar": "تم إرسال عدد كبير من الطلبات خلال فترة وجيزة إلى خوادم Cloudflare API.",
            "action_ar": "يرجى الانتظار لمدة 30-60 ثانية قبل إعادة المحاولة.",
            "url": dash_base,
            "required_perm": "",
        }

    # 8. R2 Bucket Name Validation
    if "bucket" in msg and ("name" in msg or "invalid" in msg or "character" in msg):
        return {
            "category": "validation_error",
            "key": "r2_invalid_bucket_name",
            "title": "Invalid R2 Bucket Name",
            "explanation": "Cloudflare R2 bucket names must consist of lowercase letters, numbers, and hyphens only, with length between 3 and 63 characters.",
            "action": "Choose a bucket name with only lowercase letters and numbers (e.g., my-app-uploads).",
            "title_ar": "اسم الـ Bucket غير متوافق مع معايير R2",
            "explanation_ar": "تشترط Cloudflare R2 أن يتكون اسم الـ Bucket من أحرف إنجليزية صغيرة (lowercase) وأرقام وشرطات فقط، وبطول بين 3 و 63 حرفاً.",
            "action_ar": "اختر اسماً يحتوي فقط على أحرف صغيرة وأرقام (مثال: my-app-uploads).",
            "url": f"https://dash.cloudflare.com/{account_id}/r2/overview" if account_id else "https://dash.cloudflare.com",
            "required_perm": "",
        }

    # 9. Generic Fallback
    return {
        "category": "api_error",
        "key": "generic_api_error",
        "title": "Cloudflare API Server Error",
        "explanation": error_message,
        "action": "Check your Cloudflare Dashboard to verify your account status and resources.",
        "title_ar": "خطأ من خادم Cloudflare",
        "explanation_ar": error_message,
        "action_ar": "راجع لوحة تحكم Cloudflare للتحقق من حالة الحساب والموارد.",
        "url": dash_base,
        "required_perm": "",
    }


class CloudflareClient:
    """Manages authentication, storage, and API requests to Cloudflare v4."""

    def __init__(self, config_dir: Path | None = None):
        if config_dir:
            self.config_dir = Path(config_dir).resolve()
            self.config_file = self.config_dir / "cloudflare.json"
        else:
            self.config_dir, self.config_file = _config_dirs()
        self._cached_creds: dict[str, Any] | None = None

    # ── Credentials & Multi-Account Local Storage ────────────────────────────

    def _load_raw_config(self) -> dict[str, Any]:
        """Load raw json from config file with auto-migration from legacy format."""
        if not self.config_file.is_file():
            return {"active_account_id": "", "accounts": []}

        try:
            data = json.loads(self.config_file.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return {"active_account_id": "", "accounts": []}

            # Migration: if old single-account format (has 'token' but no 'accounts')
            if "accounts" not in data or not isinstance(data.get("accounts"), list):
                legacy_tok = data.get("token", "")
                accounts = []
                if legacy_tok:
                    acc_id = data.get("account_id") or "default"
                    acc_name = data.get("account_name") or "Default Account"
                    accounts.append({
                        "account_id": acc_id,
                        "account_name": acc_name,
                        "token": legacy_tok,
                        "email": data.get("email", ""),
                        "updated_at": data.get("updated_at", int(time.time())),
                    })
                data["accounts"] = accounts
                data["active_account_id"] = accounts[0]["account_id"] if accounts else ""

            return data
        except Exception:
            return {"active_account_id": "", "accounts": []}

    def _save_raw_config(self, data: dict[str, Any]) -> bool:
        """Write config securely to file and update active credentials cache."""
        self.config_dir.mkdir(parents=True, exist_ok=True)
        active_id = data.get("active_account_id", "")
        accounts = data.get("accounts", [])

        # Sync active account
        active_acc = None
        for a in accounts:
            if a.get("account_id") == active_id:
                active_acc = a
                break
        if not active_acc and accounts:
            active_acc = accounts[0]
            data["active_account_id"] = active_acc.get("account_id", "")

        if active_acc:
            data["token"] = active_acc.get("token", "")
            data["account_id"] = active_acc.get("account_id", "")
            data["account_name"] = active_acc.get("account_name", "")
            data["email"] = active_acc.get("email", "")
            self._cached_creds = {
                "token": active_acc.get("token", ""),
                "account_id": active_acc.get("account_id", ""),
                "account_name": active_acc.get("account_name", ""),
                "email": active_acc.get("email", ""),
            }
        else:
            data["token"] = ""
            data["account_id"] = ""
            data["account_name"] = ""
            data["email"] = ""
            self._cached_creds = {"token": "", "account_id": "", "account_name": "", "email": ""}

        try:
            self.config_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
            try:
                os.chmod(self.config_file, 0o600)
            except OSError:
                pass
            return True
        except OSError:
            return False

    def load_credentials(self) -> dict[str, Any]:
        """Load credentials for the currently active Cloudflare account."""
        if self._cached_creds is not None and self._cached_creds.get("token"):
            return self._cached_creds

        cfg = self._load_raw_config()
        active_id = cfg.get("active_account_id", "")
        accounts = cfg.get("accounts", [])

        active_acc = None
        for a in accounts:
            if a.get("account_id") == active_id:
                active_acc = a
                break
        if not active_acc and accounts:
            active_acc = accounts[0]

        if active_acc:
            self._cached_creds = {
                "token": active_acc.get("token", ""),
                "account_id": active_acc.get("account_id", ""),
                "account_name": active_acc.get("account_name", ""),
                "email": active_acc.get("email", ""),
            }
            return self._cached_creds

        self._cached_creds = {"token": "", "account_id": "", "account_name": "", "email": ""}
        return self._cached_creds

    def get_active_account_id(self) -> str:
        """Return the active account ID."""
        creds = self.load_credentials()
        return creds.get("account_id", "")

    def list_stored_accounts(self) -> list[dict[str, Any]]:
        """List all locally configured Cloudflare accounts."""
        cfg = self._load_raw_config()
        active_id = cfg.get("active_account_id", "")
        result = []
        for a in cfg.get("accounts", []):
            acc_id = a.get("account_id", "")
            tok = a.get("token", "")
            masked = f"{tok[:4]}...{tok[-4:]}" if len(tok) >= 8 else "***"
            result.append({
                "account_id": acc_id,
                "account_name": a.get("account_name") or "Unnamed Account",
                "email": a.get("email", ""),
                "token_preview": masked,
                "is_active": (acc_id == active_id or (not active_id and len(result) == 0)),
                "updated_at": a.get("updated_at", 0),
            })
        return result

    def save_credentials(
        self,
        token: str,
        account_id: str = "",
        account_name: str = "",
        email: str = "",
        make_active: bool = True,
    ) -> bool:
        """Save or add an account to local config."""
        token = token.strip()
        account_id = account_id.strip()
        account_name = account_name.strip()
        email = email.strip()

        if not token:
            return False

        if not account_id:
            account_id = f"acc_{int(time.time())}"

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])

        # Check if account already exists
        found = False
        for a in accounts:
            if a.get("account_id") == account_id:
                a["token"] = token
                if account_name:
                    a["account_name"] = account_name
                if email:
                    a["email"] = email
                a["updated_at"] = int(time.time())
                found = True
                break

        if not found:
            accounts.append({
                "account_id": account_id,
                "account_name": account_name or "Cloudflare Account",
                "token": token,
                "email": email,
                "updated_at": int(time.time()),
            })

        cfg["accounts"] = accounts
        if make_active or not cfg.get("active_account_id"):
            cfg["active_account_id"] = account_id

        self._cached_creds = None
        return self._save_raw_config(cfg)

    def switch_account(self, account_identifier: str) -> dict[str, Any]:
        """Switch active account by ID or account name."""
        target = account_identifier.strip().lower()
        if not target:
            return {"ok": False, "error": "Account identifier is required."}

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        matched = None

        # Try exact ID match first
        for a in accounts:
            if a.get("account_id", "").lower() == target:
                matched = a
                break
        # Try name match
        if not matched:
            for a in accounts:
                if a.get("account_name", "").lower() == target:
                    matched = a
                    break

        if not matched:
            return {"ok": False, "error": f"Account '{account_identifier}' not found."}

        cfg["active_account_id"] = matched["account_id"]
        self._cached_creds = None
        self._save_raw_config(cfg)
        return {
            "ok": True,
            "account_id": matched["account_id"],
            "account_name": matched.get("account_name", ""),
        }

    def remove_account(self, account_identifier: str) -> dict[str, Any]:
        """Remove a stored account by ID or name."""
        target = account_identifier.strip().lower()
        if not target:
            return {"ok": False, "error": "Account identifier is required."}

        cfg = self._load_raw_config()
        accounts = cfg.get("accounts", [])
        remaining = []
        removed = None

        for a in accounts:
            if a.get("account_id", "").lower() == target or a.get("account_name", "").lower() == target:
                removed = a
            else:
                remaining.append(a)

        if not removed:
            return {"ok": False, "error": f"Account '{account_identifier}' not found."}

        cfg["accounts"] = remaining
        if cfg.get("active_account_id") == removed.get("account_id"):
            cfg["active_account_id"] = remaining[0]["account_id"] if remaining else ""

        self._cached_creds = None
        self._save_raw_config(cfg)
        return {
            "ok": True,
            "removed_id": removed["account_id"],
            "removed_name": removed.get("account_name", ""),
            "remaining_count": len(remaining),
            "new_active_id": cfg.get("active_account_id", ""),
        }

    def clear_credentials(self) -> bool:
        """Clear all saved Cloudflare accounts."""
        self._cached_creds = {"token": "", "account_id": "", "account_name": "", "email": ""}
        try:
            self.config_file.unlink(missing_ok=True)
            return True
        except OSError:
            return False

    # ── HTTP Request Helper ──────────────────────────────────────────────────

    def _request(
        self,
        endpoint: str,
        method: str = "GET",
        data: dict[str, Any] | None = None,
        override_token: str | None = None,
        timeout: int = 15,
    ) -> dict[str, Any]:
        """Perform an HTTP request to Cloudflare API v4 with enriched error diagnostics."""
        token = override_token if override_token is not None else self.load_credentials().get("token", "")
        if not token:
            return {
                "ok": False,
                "error": "Cloudflare API token not configured",
                "cause_category": "missing_token",
                "cause_key": "missing_token",
                "cause_title": "Cloudflare API Token Not Configured",
                "cause_explanation": "An API Token is required to communicate with your Cloudflare account.",
                "cause_action": "Use 'laravel-dev cf auth' or connect your token via the Cloudflare section in the application UI.",
                "cause_title_ar": "لم يتم إدخال رمز Cloudflare API Token",
                "cause_explanation_ar": "التطبيق يحتاج إلى API Token للاتصال بحسابك في Cloudflare.",
                "cause_action_ar": "استخدم 'laravel-dev cf auth' أو اربط التوكن من خلال واجهة التطبيق.",
                "dashboard_url": "https://dash.cloudflare.com/profile/api-tokens",
            }

        url = f"{CF_API_BASE}{endpoint}" if endpoint.startswith("/") else f"{CF_API_BASE}/{endpoint}"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": "Laravel-Dev-Tool/1.0",
        }

        body_bytes = json.dumps(data).encode("utf-8") if data is not None else None
        req = urllib.request.Request(url, data=body_bytes, headers=headers, method=method)

        ctx = ssl.create_default_context()
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                payload = json.loads(raw)
                success = payload.get("success", False)
                return {
                    "ok": success,
                    "result": payload.get("result"),
                    "errors": payload.get("errors", []),
                    "messages": payload.get("messages", []),
                    "result_info": payload.get("result_info", {}),
                }
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", errors="replace")
            err_msg = f"HTTP {e.code}"
            err_code = 0
            errors_list = []
            try:
                parsed = json.loads(raw)
                errors_list = parsed.get("errors", [])
                if errors_list and isinstance(errors_list, list):
                    first_err = errors_list[0]
                    err_msg = first_err.get("message") or err_msg
                    err_code = first_err.get("code") or 0
            except Exception:
                err_msg = f"{err_msg}: {raw[:200]}"

            acc_id = self.load_credentials().get("account_id", "")
            diag = analyze_cf_error(
                error_message=err_msg,
                error_code=err_code,
                status_code=e.code,
                endpoint=endpoint,
                account_id=acc_id,
            )

            return {
                "ok": False,
                "error": err_msg,
                "error_code": err_code,
                "status_code": e.code,
                "errors": errors_list,
                "cause_category": diag["category"],
                "cause_key": diag.get("key", "api_error"),
                "cause_title": diag["title"],
                "cause_explanation": diag["explanation"],
                "cause_action": diag["action"],
                "cause_title_ar": diag.get("title_ar", diag["title"]),
                "cause_explanation_ar": diag.get("explanation_ar", diag["explanation"]),
                "cause_action_ar": diag.get("action_ar", diag["action"]),
                "dashboard_url": diag["url"],
                "required_perm": diag.get("required_perm", ""),
            }
        except urllib.error.URLError as e:
            return {
                "ok": False,
                "error": f"Network connection failed: {e.reason}",
                "status_code": 0,
                "cause_category": "network_error",
                "cause_key": "network_error",
                "cause_title": "Unable to Connect to Cloudflare (Network Error)",
                "cause_explanation": "Could not connect to the Internet or reach api.cloudflare.com.",
                "cause_action": "Check your network connection and verify firewall allows connections to api.cloudflare.com.",
                "cause_title_ar": "تعذر الاتصال بخوادم Cloudflare (Network Error)",
                "cause_explanation_ar": "فشل الاتصال بالإنترنت أو تعذر الوصول إلى خوادم Cloudflare API.",
                "cause_action_ar": "تأكد من اتصال جهازك بالإنترنت وأن جدار الحماية لا يحظر الاتصال بـ api.cloudflare.com.",
                "dashboard_url": "https://www.cloudflarestatus.com",
            }
        except Exception as e:
            return {
                "ok": False,
                "error": str(e),
                "cause_category": "unexpected_error",
                "cause_key": "unexpected_error",
                "cause_title": "Unexpected Error",
                "cause_explanation": str(e),
                "cause_action": "Retry the operation or inspect application logs.",
                "cause_title_ar": "خطأ غير متوقع",
                "cause_explanation_ar": str(e),
                "cause_action_ar": "أعد المحاولة أو تحقق من سجلات النظام.",
            }

    # ── Token Verification & Accounts ────────────────────────────────────────

    def verify_token(self, token: str) -> dict[str, Any]:
        """Verify validity and status of an API Token."""
        res = self._request("/user/tokens/verify", method="GET", override_token=token)
        if not res.get("ok"):
            return {
                "ok": False,
                "valid": False,
                "error": res.get("error", "Token verification failed. Please check the token permissions."),
                "error_code": res.get("error_code", 0),
                "status_code": res.get("status_code", 0),
                "cause_category": "invalid_token",
                "cause_key": "invalid_token",
                "cause_title": res.get("cause_title", "Invalid or Unauthorized API Token"),
                "cause_explanation": res.get("cause_explanation", "Cloudflare API rejected this token. It may be mistyped, revoked, or expired."),
                "cause_action": res.get("cause_action", "Ensure you copied the entire token without extra spaces, and check its permissions on Cloudflare."),
                "cause_title_ar": res.get("cause_title_ar", "رمز الـ API غير صالح أو تنقصه الصلاحية"),
                "cause_explanation_ar": res.get("cause_explanation_ar", "فشل التحقق من صلاحية رمز Cloudflare API."),
                "cause_action_ar": res.get("cause_action_ar", "تأكد من نسخ الرمز بالكامل وبدون مسافات، ومن صلاحيات الـ API Token."),
                "dashboard_url": res.get("dashboard_url", "https://dash.cloudflare.com/profile/api-tokens"),
                "required_perm": res.get("required_perm", "User > API Tokens > Read"),
            }

        result = res.get("result", {})
        status = result.get("status", "")
        is_active = status.lower() == "active"

        if not is_active:
            return {
                "ok": False,
                "valid": False,
                "status": status,
                "error": f"Token status is '{status}'. It must be 'active'.",
                "cause_category": "inactive_token",
                "cause_key": "inactive_token",
                "cause_title": f"API Token Inactive (Status: {status})",
                "cause_explanation": f"The current token status is '{status}'. The token must be active to perform API requests.",
                "cause_action": "Activate the token or create a new active token in Cloudflare Dashboard.",
                "cause_title_ar": "رمز الـ API غير نشط (Inactive Token)",
                "cause_explanation_ar": f"حالة الرمز الحالية هي '{status}' وليست نشطة (Active). قد يكون الرمز معطلاً أو منتهي الصلاحية.",
                "cause_action_ar": "تأكد من تفعيل التوكن أو قم بإنشاء توكن جديد من لوحة تحكم Cloudflare.",
                "dashboard_url": "https://dash.cloudflare.com/profile/api-tokens",
                "required_perm": "",
            }

        # Try to discover accessible accounts
        acc_res = self._request("/accounts?page=1&per_page=20", method="GET", override_token=token)
        accounts = acc_res.get("result", []) if acc_res.get("ok") else []

        return {
            "ok": True,
            "valid": True,
            "status": status,
            "token_id": result.get("id", ""),
            "accounts": [
                {"id": a.get("id"), "name": a.get("name"), "type": a.get("type", "standard")}
                for a in accounts if isinstance(a, dict)
            ],
        }

    def get_status(self) -> dict[str, Any]:
        """Return the current authentication status, active account, and stored accounts count."""
        creds = self.load_credentials()
        has_token = bool(creds.get("token"))
        stored = self.list_stored_accounts()
        if not has_token:
            return {
                "configured": False,
                "token_masked": "",
                "account_id": "",
                "account_name": "",
                "accounts": stored,
                "total_accounts": len(stored),
            }

        tok = creds["token"]
        masked = f"{tok[:4]}...{tok[-4:]}" if len(tok) >= 8 else "***"
        return {
            "configured": True,
            "token_masked": masked,
            "account_id": creds.get("account_id", ""),
            "account_name": creds.get("account_name", ""),
            "accounts": stored,
            "total_accounts": len(stored),
        }

    def list_accounts(self) -> dict[str, Any]:
        """List accessible Cloudflare accounts."""
        res = self._request("/accounts?page=1&per_page=50", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "accounts": res.get("result", [])}

    # ── Zones & Domains ──────────────────────────────────────────────────────

    def list_zones(self, page: int = 1, per_page: int = 50) -> dict[str, Any]:
        """List domains/zones under the account."""
        creds = self.load_credentials()
        acc_id = creds.get("account_id")
        endpoint = f"/zones?page={page}&per_page={per_page}"
        if acc_id:
            endpoint += f"&account.id={acc_id}"

        res = self._request(endpoint, method="GET")
        if not res.get("ok"):
            # Fallback without account filter if permission scope is zone-level
            res = self._request(f"/zones?page={page}&per_page={per_page}", method="GET")
            if not res.get("ok"):
                return res

        zones = []
        for z in (res.get("result") or []):
            if isinstance(z, dict):
                zones.append({
                    "id": z.get("id"),
                    "name": z.get("name"),
                    "status": z.get("status"),
                    "paused": z.get("paused", False),
                    "type": z.get("type", "full"),
                    "plan": (z.get("plan") or {}).get("name", "Free"),
                    "name_servers": z.get("name_servers", []),
                })
        return {"ok": True, "zones": zones, "result_info": res.get("result_info", {})}

    # ── DNS Records Management ───────────────────────────────────────────────

    def list_dns_records(self, zone_id: str, record_type: str = "", name: str = "", page: int = 1) -> dict[str, Any]:
        """List DNS records for a zone."""
        endpoint = f"/zones/{zone_id}/dns_records?page={page}&per_page=100"
        if record_type:
            endpoint += f"&type={record_type.upper()}"
        if name:
            endpoint += f"&name={name}"

        res = self._request(endpoint, method="GET")
        if not res.get("ok"):
            return res

        records = []
        for r in (res.get("result") or []):
            if isinstance(r, dict):
                records.append({
                    "id": r.get("id"),
                    "zone_id": r.get("zone_id"),
                    "type": r.get("type"),
                    "name": r.get("name"),
                    "content": r.get("content"),
                    "proxiable": r.get("proxiable", False),
                    "proxied": r.get("proxied", False),
                    "ttl": r.get("ttl", 1),
                    "priority": r.get("priority"),
                    "comment": r.get("comment", ""),
                })
        return {"ok": True, "records": records, "result_info": res.get("result_info", {})}

    def create_dns_record(
        self,
        zone_id: str,
        record_type: str,
        name: str,
        content: str,
        proxied: bool = False,
        ttl: int = 1,
        priority: int | None = None,
        comment: str = "",
    ) -> dict[str, Any]:
        """Create a new DNS record."""
        data: dict[str, Any] = {
            "type": record_type.upper().strip(),
            "name": name.strip(),
            "content": content.strip(),
            "ttl": ttl if ttl > 1 else 1,
            "proxied": bool(proxied),
        }
        if comment:
            data["comment"] = comment
        if priority is not None and data["type"] in ("MX", "SRV"):
            data["priority"] = priority

        return self._request(f"/zones/{zone_id}/dns_records", method="POST", data=data)

    def update_dns_record(
        self,
        zone_id: str,
        record_id: str,
        record_type: str,
        name: str,
        content: str,
        proxied: bool = False,
        ttl: int = 1,
        priority: int | None = None,
        comment: str = "",
    ) -> dict[str, Any]:
        """Update an existing DNS record."""
        data: dict[str, Any] = {
            "type": record_type.upper().strip(),
            "name": name.strip(),
            "content": content.strip(),
            "ttl": ttl if ttl > 1 else 1,
            "proxied": bool(proxied),
        }
        if comment:
            data["comment"] = comment
        if priority is not None and data["type"] in ("MX", "SRV"):
            data["priority"] = priority

        return self._request(f"/zones/{zone_id}/dns_records/{record_id}", method="PUT", data=data)

    def toggle_dns_proxy(self, zone_id: str, record_id: str, proxied: bool) -> dict[str, Any]:
        """Toggle proxy status for a DNS record."""
        return self._request(f"/zones/{zone_id}/dns_records/{record_id}", method="PATCH", data={"proxied": proxied})

    def delete_dns_record(self, zone_id: str, record_id: str) -> dict[str, Any]:
        """Delete a DNS record."""
        return self._request(f"/zones/{zone_id}/dns_records/{record_id}", method="DELETE")

    # ── Cache & Edge Controls ────────────────────────────────────────────────

    def purge_cache(self, zone_id: str, purge_everything: bool = True, files: list[str] | None = None) -> dict[str, Any]:
        """Purge CDN cache for a zone."""
        data: dict[str, Any] = {}
        if purge_everything:
            data["purge_everything"] = True
        elif files:
            data["files"] = files
        else:
            data["purge_everything"] = True

        res = self._request(f"/zones/{zone_id}/purge_cache", method="POST", data=data)
        if res.get("ok"):
            return {"ok": True, "message": "Cache successfully purged."}
        return res

    def get_dev_mode(self, zone_id: str) -> dict[str, Any]:
        """Get Development Mode status for a zone."""
        res = self._request(f"/zones/{zone_id}/settings/development_mode", method="GET")
        if not res.get("ok"):
            return res
        result = res.get("result", {})
        val = result.get("value", "off")
        time_remaining = result.get("time_remaining", 0)
        return {"ok": True, "value": val, "enabled": val == "on", "time_remaining": time_remaining}

    def set_dev_mode(self, zone_id: str, enable: bool) -> dict[str, Any]:
        """Toggle Development Mode on or off for a zone."""
        value = "on" if enable else "off"
        res = self._request(f"/zones/{zone_id}/settings/development_mode", method="PATCH", data={"value": value})
        if not res.get("ok"):
            return res
        return {"ok": True, "enabled": enable, "value": value}

    def get_security_level(self, zone_id: str) -> dict[str, Any]:
        """Get current security level for a zone."""
        res = self._request(f"/zones/{zone_id}/settings/security_level", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "level": (res.get("result") or {}).get("value", "medium")}

    def set_security_level(self, zone_id: str, level: str) -> dict[str, Any]:
        """Set security level ('essentially_off', 'low', 'medium', 'high', 'under_attack')."""
        valid_levels = ("essentially_off", "low", "medium", "high", "under_attack")
        if level not in valid_levels:
            return {"ok": False, "error": f"Invalid level. Choose from: {', '.join(valid_levels)}"}

        res = self._request(f"/zones/{zone_id}/settings/security_level", method="PATCH", data={"value": level})
        if not res.get("ok"):
            return res
        return {"ok": True, "level": level}

    def _missing_account_id_res(self) -> dict[str, Any]:
        return {
            "ok": False,
            "error": "Account ID is required for Cloudflare R2 and Named Tunnels operations.",
            "cause_category": "missing_account_id",
            "cause_key": "missing_account_id",
            "cause_title": "Cloudflare Account ID Required",
            "cause_explanation": "Cloudflare R2 and Named Tunnels operations require a 32-character Account ID.",
            "cause_action": "Select the correct account from the switcher or link your account again to auto-discover your Account ID.",
            "cause_title_ar": "معرّف الحساب (Account ID) غير متوفر",
            "cause_explanation_ar": "عمليات R2 وأنفاق Zero Trust تتطلب ربط معرّف الحساب (Account ID) المكون من 32 خانة.",
            "cause_action_ar": "تأكد من اختيار الحساب الصحيح، أو أعد ربط الحساب عبر 'Add Account' لإعادة جلب معرّف الحساب تلقائياً.",
            "dashboard_url": "https://dash.cloudflare.com",
            "required_perm": "Account > Workers R2 Storage / Cloudflare Tunnel",
        }

    # ── Cloudflare R2 Object Storage ─────────────────────────────────────────

    def list_r2_buckets(self) -> dict[str, Any]:
        """List R2 buckets under the active account."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        res = self._request(f"/accounts/{acc_id}/r2/buckets", method="GET")
        if not res.get("ok"):
            return res

        buckets = []
        for b in ((res.get("result") or {}).get("buckets", [])):
            if isinstance(b, dict):
                buckets.append({
                    "name": b.get("name"),
                    "creation_date": b.get("creation_date"),
                    "location": b.get("location", "auto"),
                })
        return {
            "ok": True,
            "buckets": buckets,
            "account_id": acc_id,
            "endpoint": f"https://{acc_id}.r2.cloudflaredstorage.com",
        }

    def create_r2_bucket(self, name: str, location_hint: str = "") -> dict[str, Any]:
        """Create a new R2 bucket."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        data: dict[str, Any] = {"name": name.strip()}
        if location_hint:
            data["locationHint"] = location_hint

        res = self._request(f"/accounts/{acc_id}/r2/buckets", method="POST", data=data)
        if res.get("ok"):
            return {
                "ok": True,
                "name": name,
                "endpoint": f"https://{acc_id}.r2.cloudflaredstorage.com",
            }
        return res

    def delete_r2_bucket(self, name: str) -> dict[str, Any]:
        """Delete an R2 bucket."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        return self._request(f"/accounts/{acc_id}/r2/buckets/{name.strip()}", method="DELETE")

    # ── Cloudflare Central Tunnels (Zero Trust) ──────────────────────────────

    def list_account_tunnels(self) -> dict[str, Any]:
        """List Named Tunnels created under the active account."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        res = self._request(f"/accounts/{acc_id}/cfd_tunnel?is_deleted=false", method="GET")
        if not res.get("ok"):
            return res

        tunnels = []
        for t in (res.get("result") or []):
            if isinstance(t, dict):
                conns = t.get("connections", [])
                tunnels.append({
                    "id": t.get("id"),
                    "name": t.get("name"),
                    "status": t.get("status"),
                    "created_at": t.get("created_at"),
                    "connections_count": len(conns),
                    "remote_config": t.get("remote_config", False),
                })
        return {"ok": True, "tunnels": tunnels}

    def create_account_tunnel(self, name: str) -> dict[str, Any]:
        """Create a new Named Tunnel in Cloudflare account."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        # Cloudflare requires a 32+ character tunnel secret
        import secrets
        secret = secrets.token_urlsafe(32)

        data = {
            "name": name.strip(),
            "tunnel_secret": secret,
            "config_src": "cloudflare",
        }
        res = self._request(f"/accounts/{acc_id}/cfd_tunnel", method="POST", data=data)
        if not res.get("ok"):
            return res

        tunnel_id = (res.get("result") or {}).get("id")
        # Fetch tunnel token
        tok_res = self.get_tunnel_token(tunnel_id) if tunnel_id else {"ok": False}
        token = tok_res.get("token", "") if tok_res.get("ok") else ""

        return {
            "ok": True,
            "id": tunnel_id,
            "name": name,
            "token": token,
        }

    def get_tunnel_token(self, tunnel_id: str) -> dict[str, Any]:
        """Fetch the credentials token for a Named Tunnel."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        res = self._request(f"/accounts/{acc_id}/cfd_tunnel/{tunnel_id}/token", method="GET")
        if not res.get("ok"):
            return res
        return {"ok": True, "token": res.get("result", "")}

    def resolve_zone_id(self, zone_name_or_id: str) -> str | None:
        """Resolve a domain name or zone ID to a verified 32-char zone ID."""
        target = zone_name_or_id.strip()
        if not target:
            return None
        if len(target) == 32 and all(c in "0123456789abcdefABCDEF" for c in target):
            return target
        res = self.list_zones()
        if res.get("ok"):
            for z in res.get("zones", []):
                if z.get("name", "").lower() == target.lower() or z.get("id", "").lower() == target.lower():
                    return z.get("id")
        return None

    def delete_account_tunnel(self, tunnel_id: str) -> dict[str, Any]:
        """Delete a Named Tunnel from Cloudflare account."""
        acc_id = self.load_credentials().get("account_id")
        if not acc_id:
            return self._missing_account_id_res()

        return self._request(f"/accounts/{acc_id}/cfd_tunnel/{tunnel_id}", method="DELETE")


# ── Command Line Interface ───────────────────────────────────────────────────

def _colorize(text: str, color_code: str, is_tty: bool = True) -> str:
    if not is_tty:
        return text
    return f"\033[{color_code}m{text}\033[0m"


def _print_table(headers: list[str], rows: list[list[str]], is_tty: bool = True) -> None:
    if not rows:
        print("  (None)")
        return
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, val in enumerate(row):
            if i < len(col_widths):
                col_widths[i] = max(col_widths[i], len(str(val)))
    header_str = "  ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
    sep_str = "  ".join("-" * col_widths[i] for i in range(len(headers)))
    print(_colorize(header_str, "1;36", is_tty))
    print(_colorize(sep_str, "90", is_tty))
    for row in rows:
        line = "  ".join(str(row[i]).ljust(col_widths[i]) if i < len(row) else "".ljust(col_widths[i]) for i in range(len(headers)))
        print(line)


def _print_error_card(res: dict[str, Any], is_tty: bool = True) -> None:
    import sys
    raw_err = res.get("error", "Unknown error")
    title = res.get("cause_title", "")
    expl = res.get("cause_explanation", "")
    act = res.get("cause_action", "")
    url = res.get("dashboard_url", "")
    perm = res.get("required_perm", "")

    title_ar = res.get("cause_title_ar", "")
    expl_ar = res.get("cause_explanation_ar", "")
    act_ar = res.get("cause_action_ar", "")

    print(_colorize(f"\n✖ Error: {raw_err}", "1;31", is_tty), file=sys.stderr)
    if title:
        print(_colorize(f"  [Root Cause] {title}", "1;33", is_tty), file=sys.stderr)
    if expl:
        print(f"  {expl}", file=sys.stderr)
    if perm:
        print(_colorize(f"  Required API Permission: {perm}", "1;36", is_tty), file=sys.stderr)
    if act:
        print(_colorize(f"  [Suggested Fix] {act}", "1;32", is_tty), file=sys.stderr)
    if url:
        print(_colorize(f"  Dashboard Link: {url}", "4;34", is_tty), file=sys.stderr)

    if title_ar and title_ar != title:
        print(_colorize(f"  (عربي) {title_ar}: {act_ar or expl_ar}", "90", is_tty), file=sys.stderr)

    print(file=sys.stderr)


def main(argv: list[str] | None = None) -> int:
    import sys

    if argv is None:
        argv = sys.argv[1:]

    is_json = "--json" in argv
    clean_argv = [a for a in argv if a != "--json"]
    cmd = clean_argv[0] if clean_argv else "status"
    is_tty = sys.stdout.isatty() and not is_json

    cf = CloudflareClient()

    def respond(data: dict[str, Any]) -> int:
        if is_json:
            print(json.dumps(data, indent=2))
            return 0 if data.get("ok", True) else 1
        return 0 if data.get("ok", True) else 1

    try:
        if cmd == "status":
            st = cf.get_status()
            if is_json:
                print(json.dumps(st, indent=2))
                return 0
            print(_colorize("Cloudflare Account Status", "1;34", is_tty))
            print("=" * 35)
            if st.get("configured"):
                print(f"  Active Account: {_colorize(st.get('account_name', 'N/A'), '1;32', is_tty)} ({st.get('account_id', 'N/A')})")
                print(f"  Token:          {st.get('token_masked') or st.get('token_preview', 'N/A')}")
                print(f"  Status:         {_colorize('Connected', '1;32', is_tty)}")
                tot = st.get("total_accounts", 1)
                if tot > 1:
                    print(f"  Total Accounts: {tot} linked (use 'laravel-dev cf accounts' or 'laravel-dev cf switch')")
            else:
                print(f"  Status:         {_colorize('Not Configured', '1;33', is_tty)}")
                print("  Run 'laravel-dev cloudflare auth' to connect your API token.")
            return 0

        elif cmd in ("accounts", "account-list"):
            accs = cf.list_stored_accounts()
            if is_json:
                print(json.dumps({"ok": True, "accounts": accs}, indent=2))
                return 0
            if not accs:
                print(_colorize("No Cloudflare accounts linked.", "1;33", is_tty))
                print("Run 'laravel-dev cf auth' to add an account.")
                return 0
            print(_colorize(f"Linked Cloudflare Accounts ({len(accs)} total):", "1;34", is_tty))
            rows = [
                [
                    "✔ Active" if a.get("is_active") else "",
                    a.get("account_name", ""),
                    a.get("account_id", ""),
                    a.get("token_preview", ""),
                ]
                for a in accs
            ]
            _print_table(["Status", "Account Name", "Account ID", "Token"], rows, is_tty)
            return 0

        elif cmd in ("switch", "use"):
            target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target:
                print(_colorize("Usage: laravel-dev cloudflare switch <account_id_or_name>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = cf.switch_account(target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Switched active Cloudflare account to: {res.get('account_name')} ({res.get('account_id')})", "1;32", is_tty))
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd in ("remove", "rm"):
            target = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target:
                print(_colorize("Usage: laravel-dev cloudflare remove <account_id_or_name>", "1;33", is_tty), file=sys.stderr)
                return 1
            res = cf.remove_account(target)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                print(_colorize(f"✔ Removed account: {res.get('removed_name')} ({res.get('removed_id')})", "1;32", is_tty))
                if res.get("remaining_count"):
                    print(f"  Active account is now: {res.get('new_active_id')}")
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd == "auth":
            token = clean_argv[1] if len(clean_argv) > 1 and not clean_argv[1].startswith("--") else ""
            custom_name = ""
            for i, a in enumerate(clean_argv):
                if a == "--name" and i + 1 < len(clean_argv):
                    custom_name = clean_argv[i + 1]

            if not token:
                if is_tty:
                    import getpass
                    token = getpass.getpass("Enter Cloudflare API Token: ").strip()
                else:
                    token = sys.stdin.read().strip()
            if not token:
                msg = "API token cannot be empty."
                if is_json:
                    print(json.dumps({"ok": False, "error": msg}))
                else:
                    print(_colorize(f"Error: {msg}", "1;31", is_tty), file=sys.stderr)
                return 1

            verify = cf.verify_token(token)
            if not verify.get("valid"):
                if is_json:
                    print(json.dumps(verify, indent=2))
                else:
                    _print_error_card(verify, is_tty)
                return 1

            accounts = verify.get("accounts", [])
            acc_id = accounts[0]["id"] if accounts else ""
            acc_name = custom_name or (accounts[0]["name"] if accounts else "Cloudflare Account")
            cf.save_credentials(token, account_id=acc_id, account_name=acc_name, make_active=True)

            if is_json:
                print(json.dumps({"ok": True, "account_id": acc_id, "account_name": acc_name}))
            else:
                print(_colorize("✔ Cloudflare API token verified and saved successfully!", "1;32", is_tty))
                if acc_name:
                    print(f"  Active Account: {acc_name} ({acc_id})")
                print("  You can add more accounts at any time with 'laravel-dev cf auth' and switch between them with 'laravel-dev cf switch'.")
            return 0

        elif cmd in ("logout", "disconnect"):
            cf.clear_credentials()
            if is_json:
                print(json.dumps({"ok": True}))
            else:
                print(_colorize("✔ Cloudflare credentials removed.", "1;32", is_tty))
            return 0

        elif cmd in ("zones", "domains"):
            res = cf.list_zones()
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if not res.get("ok"):
                _print_error_card(res, is_tty)
                return 1
            zones = res.get("zones", [])
            print(_colorize(f"Found {len(zones)} zone(s):", "1;34", is_tty))
            rows = [
                [z.get("name", ""), z.get("status", ""), z.get("plan", ""), z.get("id", ""), ",".join(z.get("name_servers", [])[:2])]
                for z in zones
            ]
            _print_table(["Domain", "Status", "Plan", "Zone ID", "Nameservers"], rows, is_tty)
            return 0

        elif cmd == "dns":
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            target_zone = clean_argv[2] if len(clean_argv) > 2 else ""

            if not target_zone:
                print(_colorize("Usage: laravel-dev cloudflare dns <list|add|delete|proxy> <zone> ...", "1;33", is_tty), file=sys.stderr)
                return 1

            zone_id = cf.resolve_zone_id(target_zone)
            if not zone_id:
                print(_colorize(f"Error: Could not resolve zone '{target_zone}'.", "1;31", is_tty), file=sys.stderr)
                return 1

            if sub == "list":
                res = cf.list_dns_records(zone_id)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                recs = res.get("records", [])
                print(_colorize(f"DNS records for {target_zone} ({len(recs)} total):", "1;34", is_tty))
                rows = [
                    [r.get("type", ""), r.get("name", ""), r.get("content", ""), "✔ Proxied" if r.get("proxied") else "DNS only", str(r.get("ttl", "")), r.get("id", "")]
                    for r in recs
                ]
                _print_table(["Type", "Name", "Content", "Proxy", "TTL", "Record ID"], rows, is_tty)
                return 0

            elif sub == "add":
                # args: dns add <zone> <type> <name> <content> [--proxied] [--ttl N]
                rtype = clean_argv[3] if len(clean_argv) > 3 else "A"
                rname = clean_argv[4] if len(clean_argv) > 4 else ""
                rcontent = clean_argv[5] if len(clean_argv) > 5 else ""
                proxied = "--proxied" in argv
                ttl = 1
                for i, a in enumerate(clean_argv):
                    if a == "--ttl" and i + 1 < len(clean_argv):
                        try:
                            ttl = int(clean_argv[i + 1])
                        except ValueError:
                            pass
                if not rname or not rcontent:
                    print(_colorize("Usage: laravel-dev cloudflare dns add <zone> <type> <name> <content> [--proxied] [--ttl N]", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.create_dns_record(zone_id, rtype, rname, rcontent, ttl=ttl, proxied=proxied)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ DNS record created: {rtype} {rname} -> {rcontent}", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "delete":
                rec_id = clean_argv[3] if len(clean_argv) > 3 else ""
                if not rec_id:
                    print(_colorize("Usage: laravel-dev cloudflare dns delete <zone> <record_id>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.delete_dns_record(zone_id, rec_id)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ DNS record {rec_id} deleted.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "proxy":
                rec_id = clean_argv[3] if len(clean_argv) > 3 else ""
                val = clean_argv[4].lower() if len(clean_argv) > 4 else "on"
                proxied = val in ("on", "true", "1", "yes")
                if not rec_id:
                    print(_colorize("Usage: laravel-dev cloudflare dns proxy <zone> <record_id> <on|off>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.toggle_dns_proxy(zone_id, rec_id, proxied)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ DNS record {rec_id} proxy set to: {'Proxied' if proxied else 'DNS only'}", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd == "purge":
            # args: purge <zone> [--all] [file1 file2 ...]
            target_zone = clean_argv[1] if len(clean_argv) > 1 else ""
            if not target_zone:
                print(_colorize("Usage: laravel-dev cloudflare purge <zone> [--all | files...]", "1;33", is_tty), file=sys.stderr)
                return 1
            zone_id = cf.resolve_zone_id(target_zone)
            if not zone_id:
                print(_colorize(f"Error: Could not resolve zone '{target_zone}'.", "1;31", is_tty), file=sys.stderr)
                return 1
            purge_everything = "--all" in argv or len(clean_argv) <= 2
            files = [f for f in clean_argv[2:] if not f.startswith("--")] if not purge_everything else None
            res = cf.purge_cache(zone_id, purge_everything=purge_everything, files=files)
            if is_json:
                print(json.dumps(res, indent=2))
                return 0 if res.get("ok") else 1
            if res.get("ok"):
                mode = "entire cache" if purge_everything else f"{len(files or [])} files"
                print(_colorize(f"✔ Cloudflare cache purged successfully ({mode}) for {target_zone}!", "1;32", is_tty))
                return 0
            _print_error_card(res, is_tty)
            return 1

        elif cmd in ("dev-mode", "devmode"):
            target_zone = clean_argv[1] if len(clean_argv) > 1 else ""
            val = clean_argv[2].lower() if len(clean_argv) > 2 else ""
            if not target_zone:
                print(_colorize("Usage: laravel-dev cloudflare dev-mode <zone> [on|off|status]", "1;33", is_tty), file=sys.stderr)
                return 1
            zone_id = cf.resolve_zone_id(target_zone)
            if not zone_id:
                print(_colorize(f"Error: Could not resolve zone '{target_zone}'.", "1;31", is_tty), file=sys.stderr)
                return 1

            if val in ("on", "enable", "true", "1"):
                res = cf.set_dev_mode(zone_id, True)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Development Mode turned ON for {target_zone} (cache bypassed for 3 hours).", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1
            elif val in ("off", "disable", "false", "0"):
                res = cf.set_dev_mode(zone_id, False)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Development Mode turned OFF for {target_zone}.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1
            else:
                res = cf.get_dev_mode(zone_id)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    dm = res.get("dev_mode")
                    rem = res.get("time_remaining", 0)
                    state_str = _colorize("ON", "1;32", is_tty) if dm else _colorize("OFF", "1;33", is_tty)
                    extra = f" ({rem // 60}m remaining)" if dm and rem else ""
                    print(f"Development Mode for {target_zone}: {state_str}{extra}")
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd == "security":
            target_zone = clean_argv[1] if len(clean_argv) > 1 else ""
            level = clean_argv[2].lower() if len(clean_argv) > 2 else ""
            if not target_zone:
                print(_colorize("Usage: laravel-dev cloudflare security <zone> [essentially_off|low|medium|high|under_attack]", "1;33", is_tty), file=sys.stderr)
                return 1
            zone_id = cf.resolve_zone_id(target_zone)
            if not zone_id:
                print(_colorize(f"Error: Could not resolve zone '{target_zone}'.", "1;31", is_tty), file=sys.stderr)
                return 1
            if level:
                res = cf.set_security_level(zone_id, level)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Security level for {target_zone} set to: {level}", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1
            else:
                res = cf.get_security_level(zone_id)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(f"Security level for {target_zone}: {_colorize(res.get('level', 'N/A'), '1;32', is_tty)}")
                    return 0
                _print_error_card(res, is_tty)
                return 1

        elif cmd == "r2":
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "list":
                res = cf.list_r2_buckets()
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                b = res.get("buckets", [])
                print(_colorize(f"Cloudflare R2 Buckets ({len(b)} total):", "1;34", is_tty))
                rows = [[item.get("name", ""), item.get("jurisdiction", "default"), item.get("created_at", "")] for item in b]
                _print_table(["Bucket Name", "Jurisdiction", "Created At"], rows, is_tty)
                return 0

            elif sub == "create":
                name = clean_argv[2] if len(clean_argv) > 2 else ""
                loc = clean_argv[3] if len(clean_argv) > 3 else ""
                if not name:
                    print(_colorize("Usage: laravel-dev cloudflare r2 create <bucket_name> [location_hint]", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.create_r2_bucket(name, location_hint=loc)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ R2 Bucket '{name}' created successfully!", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "delete":
                name = clean_argv[2] if len(clean_argv) > 2 else ""
                if not name:
                    print(_colorize("Usage: laravel-dev cloudflare r2 delete <bucket_name>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.delete_r2_bucket(name)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ R2 Bucket '{name}' deleted.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "env":
                # args: r2 env <project> <bucket> [access_key] [secret_key]
                proj = clean_argv[2] if len(clean_argv) > 2 else ""
                bucket = clean_argv[3] if len(clean_argv) > 3 else ""
                access_key = clean_argv[4] if len(clean_argv) > 4 else ""
                secret_key = clean_argv[5] if len(clean_argv) > 5 else ""
                if not proj or not bucket:
                    print(_colorize("Usage: laravel-dev cloudflare r2 env <project_path_or_name> <bucket> [access_key] [secret_key]", "1;33", is_tty), file=sys.stderr)
                    return 1
                env_file = Path(proj) / ".env" if Path(proj).is_dir() else Path.home() / "Sites" / proj / ".env"
                if not env_file.is_file():
                    # Check current dir
                    if (Path.cwd() / ".env").is_file():
                        env_file = Path.cwd() / ".env"
                    else:
                        print(_colorize(f"Error: Could not locate .env for '{proj}'.", "1;31", is_tty), file=sys.stderr)
                        return 1
                acc_id = cf.load_credentials().get("account_id", "")
                endpoint = f"https://{acc_id}.r2.cloudflaredstorage.com" if acc_id else ""
                updates = {
                    "FILESYSTEM_DISK": "r2",
                    "R2_BUCKET": bucket,
                }
                if endpoint:
                    updates["R2_ENDPOINT"] = endpoint
                if access_key:
                    updates["R2_ACCESS_KEY_ID"] = access_key
                if secret_key:
                    updates["R2_SECRET_ACCESS_KEY"] = secret_key

                import re
                lines = env_file.read_text(encoding="utf-8").splitlines()
                existing_keys = set()
                new_lines = []
                for line in lines:
                    m = re.match(r"^([A-Za-z0-9_]+)=", line)
                    if m and m.group(1) in updates:
                        k = m.group(1)
                        existing_keys.add(k)
                        new_lines.append(f"{k}={updates[k]}")
                    else:
                        new_lines.append(line)
                for k, v in updates.items():
                    if k not in existing_keys:
                        new_lines.append(f"{k}={v}")
                env_file.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
                print(_colorize(f"✔ R2 configuration written to {env_file}:", "1;32", is_tty))
                for k in updates:
                    print(f"  {k}={updates[k]}")
                return 0

        elif cmd in ("tunnels", "tunnel"):
            sub = clean_argv[1] if len(clean_argv) > 1 else "list"
            if sub == "list":
                res = cf.list_account_tunnels()
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if not res.get("ok"):
                    _print_error_card(res, is_tty)
                    return 1
                tuns = res.get("tunnels", [])
                print(_colorize(f"Cloudflare Named Tunnels ({len(tuns)} total):", "1;34", is_tty))
                rows = [[t.get("name", ""), t.get("status", ""), str(t.get("connections", 0)), t.get("id", ""), t.get("created_at", "")] for t in tuns]
                _print_table(["Name", "Status", "Connections", "Tunnel ID", "Created At"], rows, is_tty)
                return 0

            elif sub == "create":
                name = clean_argv[2] if len(clean_argv) > 2 else ""
                if not name:
                    print(_colorize("Usage: laravel-dev cloudflare tunnel create <name>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.create_account_tunnel(name)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Named Tunnel '{name}' created!", "1;32", is_tty))
                    print(f"  Tunnel ID: {res.get('id')}")
                    if res.get("token"):
                        print(f"  Token:     {res.get('token')}")
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "token":
                tid = clean_argv[2] if len(clean_argv) > 2 else ""
                if not tid:
                    print(_colorize("Usage: laravel-dev cloudflare tunnel token <tunnel_id>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.get_tunnel_token(tid)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(res.get("token", ""))
                    return 0
                _print_error_card(res, is_tty)
                return 1

            elif sub == "delete":
                tid = clean_argv[2] if len(clean_argv) > 2 else ""
                if not tid:
                    print(_colorize("Usage: laravel-dev cloudflare tunnel delete <tunnel_id>", "1;33", is_tty), file=sys.stderr)
                    return 1
                res = cf.delete_account_tunnel(tid)
                if is_json:
                    print(json.dumps(res, indent=2))
                    return 0 if res.get("ok") else 1
                if res.get("ok"):
                    print(_colorize(f"✔ Tunnel {tid} deleted.", "1;32", is_tty))
                    return 0
                _print_error_card(res, is_tty)
                return 1

        else:
            print(_colorize(f"Unknown command '{cmd}'.", "1;31", is_tty), file=sys.stderr)
            print("Available commands: status, auth, logout, zones, dns, purge, dev-mode, security, r2, tunnels", file=sys.stderr)
            return 1

    except KeyboardInterrupt:
        print("\nAborted.")
        return 130
    except Exception as exc:
        if is_json:
            print(json.dumps({"ok": False, "error": str(exc)}))
        else:
            print(_colorize(f"Fatal error: {exc}", "1;31", is_tty), file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
