"""ui/site_services.py - Manages category-based per-site service configuration.

Categories:
  - database: sqlite, mysql, mariadb, pgsql/postgresql, unmanaged
  - queue: sync, database, redis, unmanaged
  - cache: file, database, redis, array, unmanaged
  - broadcasting: log, null, reverb, unmanaged
  - mail: log, mailpit, unmanaged

Original environment variables are preserved in `.env.laravel-dev-services.bak`
before the first mutation in any category so `unmanaged` can cleanly restore them.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import envfile

BACKUP_FILE = ".env.laravel-dev-services.bak"

CATEGORIES = ("database", "queue", "cache", "broadcasting", "mail")

CATEGORY_KEYS: Dict[str, List[str]] = {
    "database": ["DB_CONNECTION", "DB_HOST", "DB_PORT", "DB_DATABASE", "DB_USERNAME", "DB_PASSWORD", "MONGODB_URI"],
    "queue": ["QUEUE_CONNECTION", "QUEUE_DRIVER", "REDIS_HOST", "REDIS_PORT"],
    "cache": ["CACHE_STORE", "CACHE_DRIVER", "REDIS_HOST", "REDIS_PORT"],
    "broadcasting": [
        "BROADCAST_CONNECTION",
        "BROADCAST_DRIVER",
        "REVERB_APP_ID",
        "REVERB_APP_KEY",
        "REVERB_APP_SECRET",
        "REVERB_HOST",
        "REVERB_PORT",
        "REVERB_SCHEME",
    ],
    "mail": [
        "MAIL_MAILER",
        "MAIL_DRIVER",
        "MAIL_HOST",
        "MAIL_PORT",
        "MAIL_USERNAME",
        "MAIL_PASSWORD",
        "MAIL_ENCRYPTION",
    ],
}

CATEGORY_OPTIONS: Dict[str, Dict[str, Dict[str, Any]]] = {
    "database": {
        "sqlite": {
            "label": "SQLite",
            "description": "Embedded file database (database/database.sqlite)",
            "env": {
                "DB_CONNECTION": "sqlite",
                "DB_DATABASE": "database/database.sqlite",
                "DB_HOST": "",
                "DB_PORT": "",
                "DB_USERNAME": "",
                "DB_PASSWORD": "",
            },
        },
        "mysql": {
            "label": "MySQL",
            "description": "Local MySQL 8 server on 127.0.0.1:3306",
            "env": {
                "DB_CONNECTION": "mysql",
                "DB_HOST": "127.0.0.1",
                "DB_PORT": "3306",
                "DB_USERNAME": "root",
                "DB_PASSWORD": "",
            },
        },
        "mariadb": {
            "label": "MariaDB",
            "description": "Local MariaDB server on 127.0.0.1:3306",
            "env": {
                "DB_CONNECTION": "mariadb",
                "DB_HOST": "127.0.0.1",
                "DB_PORT": "3306",
                "DB_USERNAME": "root",
                "DB_PASSWORD": "",
            },
        },
        "pgsql": {
            "label": "PostgreSQL",
            "description": "Local PostgreSQL server on 127.0.0.1:5432",
            "env": {
                "DB_CONNECTION": "pgsql",
                "DB_HOST": "127.0.0.1",
                "DB_PORT": "5432",
                "DB_USERNAME": "postgres",
                "DB_PASSWORD": "",
            },
        },
        "mongodb": {
            "label": "MongoDB",
            "description": "Local MongoDB server on 127.0.0.1:27017",
            "env": {
                "DB_CONNECTION": "mongodb",
                "MONGODB_URI": "mongodb://127.0.0.1:27017",
                "DB_HOST": "127.0.0.1",
                "DB_PORT": "27017",
                "DB_USERNAME": "",
                "DB_PASSWORD": "",
            },
        },
    },
    "queue": {
        "sync": {
            "label": "Sync (In-process)",
            "description": "Executes queued jobs synchronously during request",
            "env": {
                "QUEUE_CONNECTION": "sync",
                "QUEUE_DRIVER": "sync",
            },
        },
        "database": {
            "label": "Database Queue",
            "description": "Stores jobs in application jobs table",
            "env": {
                "QUEUE_CONNECTION": "database",
                "QUEUE_DRIVER": "database",
            },
        },
        "redis": {
            "label": "Redis Queue",
            "description": "High-throughput asynchronous queue with Redis",
            "env": {
                "QUEUE_CONNECTION": "redis",
                "QUEUE_DRIVER": "redis",
                "REDIS_HOST": "127.0.0.1",
                "REDIS_PORT": "6379",
            },
        },
    },
    "cache": {
        "file": {
            "label": "File Cache",
            "description": "Standard Laravel file-based cache storage",
            "env": {
                "CACHE_STORE": "file",
                "CACHE_DRIVER": "file",
            },
        },
        "database": {
            "label": "Database Cache",
            "description": "Stores cache keys in the database cache table",
            "env": {
                "CACHE_STORE": "database",
                "CACHE_DRIVER": "database",
            },
        },
        "redis": {
            "label": "Redis Cache",
            "description": "In-memory fast caching with Redis",
            "env": {
                "CACHE_STORE": "redis",
                "CACHE_DRIVER": "redis",
                "REDIS_HOST": "127.0.0.1",
                "REDIS_PORT": "6379",
            },
        },
        "array": {
            "label": "Array (Ephemeral)",
            "description": "Memory cache surviving for current request only",
            "env": {
                "CACHE_STORE": "array",
                "CACHE_DRIVER": "array",
            },
        },
    },
    "broadcasting": {
        "log": {
            "label": "Log",
            "description": "Writes broadcast events directly to laravel.log",
            "env": {
                "BROADCAST_CONNECTION": "log",
                "BROADCAST_DRIVER": "log",
            },
        },
        "null": {
            "label": "Null (Disabled)",
            "description": "Discards broadcast events silently",
            "env": {
                "BROADCAST_CONNECTION": "null",
                "BROADCAST_DRIVER": "null",
            },
        },
        "reverb": {
            "label": "Laravel Reverb",
            "description": "Real-time WebSocket server on 127.0.0.1:8080",
            "env": {
                "BROADCAST_CONNECTION": "reverb",
                "BROADCAST_DRIVER": "reverb",
                "REVERB_APP_ID": "local-app",
                "REVERB_APP_KEY": "local-key",
                "REVERB_APP_SECRET": "local-secret",
                "REVERB_HOST": "127.0.0.1",
                "REVERB_PORT": "8080",
                "REVERB_SCHEME": "http",
            },
        },
    },
    "mail": {
        "log": {
            "label": "Log",
            "description": "Appends sent emails to laravel.log",
            "env": {
                "MAIL_MAILER": "log",
                "MAIL_DRIVER": "log",
            },
        },
        "mailpit": {
            "label": "Mailpit (SMTP)",
            "description": "Catches local outgoing mail on 127.0.0.1:1025",
            "env": {
                "MAIL_MAILER": "smtp",
                "MAIL_DRIVER": "smtp",
                "MAIL_HOST": "127.0.0.1",
                "MAIL_PORT": "1025",
                "MAIL_USERNAME": "null",
                "MAIL_PASSWORD": "null",
                "MAIL_ENCRYPTION": "null",
            },
        },
    },
}


DB_FAMILY = {"mysql": "mysql", "mariadb": "mysql", "pgsql": "pgsql", "postgres": "pgsql", "postgresql": "pgsql"}
DB_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def _server_credentials(option: str, env_dict: Dict[str, str]) -> Dict[str, str]:
    """Username/password for a database server switch. Never invent credentials:
    keep the site's own ones when it already talks to the same kind of server, else use the
    server configured in Laravel Dev's settings, else leave DB_USERNAME/DB_PASSWORD untouched."""
    current = DB_FAMILY.get((env_dict.get("DB_CONNECTION") or "").lower())
    if current == DB_FAMILY.get(option):
        return {}
    try:
        import sites
        settings = sites.load_settings()
    except Exception:
        return {}
    if DB_FAMILY.get((settings.get("DB_TYPE") or "").lower()) != DB_FAMILY.get(option):
        return {}
    creds = {"DB_USERNAME": settings.get("DB_USER") or "", "DB_PASSWORD": settings.get("DB_PASSWORD") or ""}
    if settings.get("DB_PORT"):
        creds["DB_PORT"] = str(settings["DB_PORT"])
    if settings.get("DB_HOST"):
        creds["DB_HOST"] = settings["DB_HOST"]
    return creds


def _get_backup_path(project_path: Path) -> Path:
    return project_path / BACKUP_FILE


def _load_backups(project_path: Path) -> Dict[str, Dict[str, str]]:
    bpath = _get_backup_path(project_path)
    if not bpath.is_file():
        return {}
    try:
        data = json.loads(bpath.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_backups(project_path: Path, data: Dict[str, Dict[str, str]]) -> None:
    bpath = _get_backup_path(project_path)
    if not data:
        if bpath.exists():
            bpath.unlink()
        return
    bpath.write_text(json.dumps(data, indent=2), encoding="utf-8")


def detect_category_option(category: str, env_dict: Dict[str, str]) -> str:
    """Infers the active option for a category based on current .env variables."""
    if category == "database":
        conn = (env_dict.get("DB_CONNECTION") or env_dict.get("DB_DRIVER") or "").lower().strip()
        if "sqlite" in conn:
            return "sqlite"
        if "mysql" in conn:
            return "mysql"
        if "mariadb" in conn:
            return "mariadb"
        if "pgsql" in conn or "postgres" in conn:
            return "pgsql"
        return conn or "custom"

    if category == "queue":
        conn = (env_dict.get("QUEUE_CONNECTION") or env_dict.get("QUEUE_DRIVER") or "").lower().strip()
        if conn in ("sync", "database", "redis"):
            return conn
        return conn or "sync"

    if category == "cache":
        store = (env_dict.get("CACHE_STORE") or env_dict.get("CACHE_DRIVER") or "").lower().strip()
        if store in ("file", "database", "redis", "array"):
            return store
        return store or "file"

    if category == "broadcasting":
        bconn = (env_dict.get("BROADCAST_CONNECTION") or env_dict.get("BROADCAST_DRIVER") or "").lower().strip()
        if bconn in ("log", "null", "reverb"):
            return bconn
        return bconn or "log"

    if category == "mail":
        mailer = (env_dict.get("MAIL_MAILER") or env_dict.get("MAIL_DRIVER") or "").lower().strip()
        if mailer == "log":
            return "log"
        port = str(env_dict.get("MAIL_PORT") or "").strip()
        host = str(env_dict.get("MAIL_HOST") or "").strip()
        if port == "1025" or "mailpit" in host:
            return "mailpit"
        return mailer or "custom"

    return "custom"


def get_site_services(project_path: str) -> Dict[str, Any]:
    """Returns configuration and detection status for all 5 service categories."""
    root = Path(project_path).resolve()
    env_file = root / ".env"
    env_text = env_file.read_text(encoding="utf-8", errors="replace") if env_file.is_file() else ""
    env_dict = envfile.to_dict(env_text)
    backups = _load_backups(root)

    res: Dict[str, Any] = {}
    for cat in CATEGORIES:
        active_opt = detect_category_option(cat, env_dict)
        cat_back = backups.get(cat)
        options_list = []
        for opt_name, opt_meta in CATEGORY_OPTIONS.get(cat, {}).items():
            options_list.append({
                "id": opt_name,
                "label": opt_meta["label"],
                "description": opt_meta["description"],
            })
        options_list.append({
            "id": "unmanaged",
            "label": "Unmanaged (Custom)",
            "description": "Restore original unmanaged variables or configure manually in .env",
        })

        details: Dict[str, str] = {}
        for k in CATEGORY_KEYS.get(cat, []):
            if k in env_dict:
                details[k] = env_dict[k]

        res[cat] = {
            "category": cat,
            "current": active_opt,
            "is_managed": cat in backups,
            "has_backup": bool(cat_back),
            "details": details,
            "options": options_list,
        }

    return res


def set_site_service(
    project_path: str,
    category: str,
    option: str,
    database_name: Optional[str] = None,
) -> Dict[str, Any]:
    """Applies a category-based service configuration to the site's .env file."""
    root = Path(project_path).resolve()
    env_file = root / ".env"
    if not env_file.is_file():
        raise ValueError(f"Site does not contain a .env file at {root}")

    category = category.lower().strip()
    if category not in CATEGORIES:
        raise ValueError(f"Unknown service category: {category}. Valid: {', '.join(CATEGORIES)}")

    option = option.lower().strip()
    if option == "postgresql":
        option = "pgsql"

    env_text = env_file.read_text(encoding="utf-8", errors="replace")
    env_dict = envfile.to_dict(env_text)
    backups = _load_backups(root)

    cat_keys = CATEGORY_KEYS[category]

    if option == "unmanaged":
        if category not in backups:
            return {"ok": True, "category": category, "option": "unmanaged", "message": "Already unmanaged."}
        restore_map = backups.pop(category)
        _save_backups(root, backups)
        new_text = envfile.apply(env_text, restore_map)
        env_file.write_text(new_text, encoding="utf-8")
        return {
            "ok": True,
            "category": category,
            "option": "unmanaged",
            "message": f"Restored original {category} configuration from backup.",
            "restored_keys": list(restore_map.keys()),
        }

    valid_opts = CATEGORY_OPTIONS.get(category, {})
    if option not in valid_opts:
        raise ValueError(f"Unknown option '{option}' for category '{category}'. Valid: {', '.join(valid_opts.keys())}")

    if category == "database" and database_name and option != "sqlite" and not DB_NAME_RE.fullmatch(str(database_name)):
        raise ValueError("Database names may only use letters, numbers, - and _ (max 64).")

    # Back up original keys if this category is not yet backed up
    if category not in backups:
        cat_backup = {}
        for k in cat_keys:
            cat_backup[k] = env_dict.get(k)
        backups[category] = cat_backup
        _save_backups(root, backups)

    changes = dict(valid_opts[option]["env"])

    if category == "database":
        if option in DB_FAMILY:
            changes.pop("DB_USERNAME", None)
            changes.pop("DB_PASSWORD", None)
            changes.update(_server_credentials(option, env_dict))
        if option == "sqlite":
            db_dir = root / "database"
            db_dir.mkdir(parents=True, exist_ok=True)
            sqlite_file = db_dir / "database.sqlite"
            if not sqlite_file.exists():
                sqlite_file.touch()
        elif database_name:
            changes["DB_DATABASE"] = database_name

    new_text = envfile.apply(env_text, changes)
    env_file.write_text(new_text, encoding="utf-8")

    return {
        "ok": True,
        "category": category,
        "option": option,
        "label": valid_opts[option]["label"],
        "applied_keys": changes,
    }
