#!/usr/bin/env bash
# SSH_ASKPASS helper for the desktop app. ssh passes the prompt as $1: a
# password / key passphrase request, or a host-key confirmation ("yes/no").

PROMPT="${1:-Password:}"
TITLE="Laravel Dev - SSH"

# If password or passphrase was provided by the application environment, return it immediately:
if [[ -n "$SSH_PASSPHRASE" && ("$PROMPT" == *"passphrase"* || "$PROMPT" == *"Passphrase"*) ]]; then
  echo "$SSH_PASSPHRASE"
  exit 0
fi

if [[ -n "$SSH_PASSWORD" ]]; then
  echo "$SSH_PASSWORD"
  exit 0
fi

if [[ -n "$SSH_PASSPHRASE" ]]; then
  echo "$SSH_PASSPHRASE"
  exit 0
fi

# macOS: native dialogs through AppleScript.
if [[ "$(uname)" == "Darwin" ]]; then
  ESCAPED="${PROMPT//\\/\\\\}"
  ESCAPED="${ESCAPED//\"/\\\"}"
  if [[ "$PROMPT" == *"(yes/no"* ]]; then
    osascript -e "button returned of (display dialog \"$ESCAPED\" with title \"$TITLE\" buttons {\"Cancel\", \"Trust and connect\"} default button 2)" >/dev/null 2>&1 && echo yes || echo no
    exit 0
  fi
  exec osascript -e "text returned of (display dialog \"$ESCAPED\" with title \"$TITLE\" default answer \"\" with hidden answer)"
fi

if [[ "$PROMPT" == *"(yes/no"* ]]; then
  if command -v zenity >/dev/null 2>&1; then
    zenity --question --title="$TITLE" --width=520 --ok-label="Trust and connect" --cancel-label="Cancel" \
      --text="$PROMPT" >/dev/null 2>&1 && echo yes || echo no
  elif command -v kdialog >/dev/null 2>&1; then
    kdialog --title "$TITLE" --yesno "$PROMPT" >/dev/null 2>&1 && echo yes || echo no
  else
    echo no
  fi
  exit 0
fi

if command -v zenity >/dev/null 2>&1; then
  exec zenity --entry --hide-text --title="$TITLE" --width=420 --text="$PROMPT"
fi
if command -v kdialog >/dev/null 2>&1; then
  exec kdialog --title "$TITLE" --password "$PROMPT"
fi
if command -v ssh-askpass >/dev/null 2>&1; then
  exec ssh-askpass "$PROMPT"
fi

echo "No GUI prompt available (install zenity)." >&2
exit 1
