"""Remote servers over SSH — nothing is installed on the server.

Everything goes through the system `ssh` binary, so ~/.ssh/config aliases,
keys, the agent and known_hosts all work as they do in a terminal. On Linux
and macOS one multiplexed master connection per server (ControlMaster) means a
password or passphrase is asked once and later commands start instantly.
Prompts — including "trust this host key?" — are shown through
ui/ssh-askpass.sh. Windows' OpenSSH has no ControlMaster, so there every
command opens its own connection and logins must use a key or ssh-agent.
"""

import json
import os
import re
import shlex
import socket
import subprocess
import tempfile
import threading
import time
import uuid
from pathlib import Path

from osutil import IS_WINDOWS, NO_WINDOW, private_dir, private_file

HOST_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]*$")
USER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.-]*$")
UNIT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9@._-]*$")
MAX_EDIT_BYTES = 10 * 1024 * 1024

INFO_SCRIPT = r"""
echo "hostname=$(hostname 2>/dev/null)"
[ -r /etc/os-release ] && . /etc/os-release && echo "os=$PRETTY_NAME"
echo "kernel=$(uname -r)"
echo "uptime=$(cut -d. -f1 /proc/uptime 2>/dev/null)"
echo "load=$(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null)"
echo "cpus=$(nproc 2>/dev/null)"
free -b 2>/dev/null | awk '/^Mem:/{print "mem_total="$2; print "mem_used="$3}'
df -B1 -P / 2>/dev/null | awk 'NR==2{print "disk_total="$2; print "disk_used="$3}'
echo "user=$(id -un)"
echo "home=$HOME"
if [ "$(id -u)" = 0 ]; then echo sudo=root
elif sudo -n true 2>/dev/null; then echo sudo=nopasswd
else echo sudo=password; fi
seen=" "
for u in nginx apache2 httpd mysql mariadb postgresql redis-server redis supervisor docker \
         $(systemctl list-unit-files --no-legend 'php*-fpm.service' 2>/dev/null | awk '{print $1}'); do
  u="${u%.service}"
  systemctl list-unit-files "$u.service" --no-legend 2>/dev/null | grep -q . || continue
  # mysql/mariadb and redis/redis-server are often aliases of one unit: list it once.
  id=$(systemctl show -p Id --value "$u.service" 2>/dev/null); id="${id%.service}"; id="${id:-$u}"
  case "$seen" in *" $id "*) continue ;; esac
  seen="$seen$id "
  echo "unit=$id:$(systemctl is-active "$id" 2>/dev/null)"
done
command -v php >/dev/null 2>&1 && echo "php=$(php -r 'echo PHP_VERSION;' 2>/dev/null)"
command -v composer >/dev/null 2>&1 && echo composer=yes
command -v git >/dev/null 2>&1 && echo git=yes
"""

NODE_PRELUDE = r"""
export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"; [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh" >/dev/null 2>&1
for p in "$HOME/.volta/bin" "$HOME/.bun/bin" "$HOME/.local/bin" /usr/local/bin; do [ -d "$p" ] && PATH="$p:$PATH"; done
"""

DETECT_TYPE = r"""
detect_type() {
  if [ -f "$1/artisan" ]; then echo laravel
  elif [ -f "$1/manage.py" ]; then echo django
  elif [ -f "$1/package.json" ]; then
    if grep -qE '"next"[[:space:]]*:' "$1/package.json"; then echo next
    elif grep -qE '"nuxt"[[:space:]]*:' "$1/package.json"; then echo nuxt
    elif grep -qE '"vite"[[:space:]]*:' "$1/package.json"; then echo vite
    else echo node; fi
  fi
}
"""

SITES_SCRIPT = NODE_PRELUDE + DETECT_TYPE + r"""
for f in /etc/nginx/sites-enabled/* /etc/nginx/conf.d/*.conf; do
  [ -f "$f" ] || continue
  sn=$(grep -m1 -E '^[[:space:]]*server_name' "$f" | sed -E 's/^[[:space:]]*server_name[[:space:]]+//; s/;.*//')
  rt=$(grep -m1 -E '^[[:space:]]*root' "$f" | sed -E 's/^[[:space:]]*root[[:space:]]+//; s/;.*//; s/"//g')
  ph=$(grep -m1 -oE 'php[0-9]+\.[0-9]+-fpm' "$f" | sed -E 's/php//; s/-fpm//')
  ssl=no; grep -qE 'listen[^;]*443' "$f" && ssl=yes
  pp=$(grep -m1 -oE 'proxy_pass[[:space:]]+https?://[^;]+' "$f" | grep -oE ':[0-9]+' | head -n1 | tr -d :)
  printf 'nginx\t%s\t%s\t%s\t%s\t%s\t%s\n' "$f" "$sn" "$rt" "$ph" "$ssl" "$pp"
done
for d in /var/www/* /var/www/*/* /srv/* /srv/*/* "$HOME"/* "$HOME"/*/* /home/*/* /home/*/*/*; do
  [ -d "$d" ] || continue
  t=$(detect_type "$d")
  # Plain node/vite folders are too common to list unless pm2 runs them.
  case "$t" in laravel|django|next|nuxt) printf 'dir\t%s\t%s\n' "$d" "$t" ;; esac
done 2>/dev/null
if command -v pm2 >/dev/null 2>&1; then printf 'pm2\t'; pm2 jlist 2>/dev/null | tr -d '\n'; echo; fi
"""

SITE_META_SCRIPT = DETECT_TYPE + r"""
for d in "$@"; do
  b=$(git -C "$d" rev-parse --abbrev-ref HEAD 2>/dev/null)
  m=no; [ -f "$d/storage/framework/down" ] && m=yes
  u=$(grep -lsxF -e "WorkingDirectory=$d" -e "WorkingDirectory=$d/" /etc/systemd/system/*.service 2>/dev/null | head -n1)
  st=""; if [ -n "$u" ]; then u=$(basename "$u" .service); st=$(systemctl is-active "$u" 2>/dev/null); fi
  printf 'meta\t%s\t%s\t%s\t%s\t%s\t%s\n' "$d" "$b" "$m" "$(detect_type "$d")" "$u" "$st"
done
"""

LIST_BODY = r"""
pwd
find . -mindepth 1 -maxdepth 1 -printf '%y\t%s\t%T@\t%m\t%u\t%f\n' 2>/dev/null
"""
LIST_SCRIPT = 'cd -- "$1" 2>/dev/null || { echo "Cannot open $1" >&2; exit 3; }' + LIST_BODY
LIST_HOME_SCRIPT = "cd || exit 3" + LIST_BODY


def fmt_err(code, err):
    err = (err or "").strip()
    if code == 255:
        return err.splitlines()[-1] if err else "Could not connect over SSH."
    return err or f"Command failed (exit {code})."


class RemoteError(Exception):
    pass


class Remote:
    def __init__(self, config_dir, ui_dir, emit):
        self.file = Path(config_dir) / "servers.json"
        self.cache_dir = Path(config_dir) / "runtime" / "remote"
        runtime = os.environ.get("XDG_RUNTIME_DIR")
        # Unix sockets have a short path limit (104 bytes on macOS): keep it short there.
        self.control_dir = (Path(runtime) / "laravel-dev-ssh" if runtime
                            else Path("/tmp") / f"laravel-dev-ssh-{os.getuid()}" if hasattr(os, "getuid")
                            else Path(config_dir) / "runtime" / "ssh")
        self.mux = not IS_WINDOWS
        self.askpass = str(Path(ui_dir) / "ssh-askpass.sh")
        self.emit = emit
        self.adhoc_servers = {}  # server id -> server dict (e.g. dedicated database ssh tunnels)
        self.sudo_passwords = {}  # server id -> password, memory only
        self.connected = {}  # server id -> time of the last good connection (no-mux mode)
        self.forwards = {}  # (server id, host, port) -> local port of an SSH tunnel
        self.tunnels = {}  # same key -> ssh process (no-mux mode)
        self.watched = {}  # local path -> {server, remote, mtime}
        self.lock = threading.Lock()
        self.watcher = None

    # ── storage ─────────────────────────────────────────────
    def servers(self):
        try:
            data = json.loads(self.file.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (OSError, ValueError):
            return []

    def _save(self, servers):
        self.file.parent.mkdir(parents=True, exist_ok=True)
        self.file.write_text(json.dumps(servers, indent=2), encoding="utf-8")
        private_file(self.file)

    def register_adhoc(self, server):
        with self.lock:
            self.adhoc_servers[server["id"]] = server

    def get(self, server_id):
        with self.lock:
            if server_id in self.adhoc_servers:
                return self.adhoc_servers[server_id]
        for server in self.servers():
            if server["id"] == server_id:
                return server
        raise RemoteError("Unknown server")

    def upsert(self, p):
        name = (p.get("name") or "").strip()
        host = (p.get("host") or "").strip()
        user = (p.get("user") or "").strip()
        port = str(p.get("port") or "").strip()
        key = os.path.expanduser((p.get("key") or "").strip())
        if not name or len(name) > 60:
            raise RemoteError("Give the server a name")
        if not HOST_RE.fullmatch(host):
            raise RemoteError("Enter a valid host, IP or ~/.ssh/config alias")
        if user and not USER_RE.fullmatch(user):
            raise RemoteError("Invalid SSH username")
        if port and not (port.isdigit() and 0 < int(port) < 65536):
            raise RemoteError("Port must be between 1 and 65535")
        if key and not Path(key).is_file():
            raise RemoteError("Identity file not found")
        servers = self.servers()
        entry = {"id": p.get("id") or uuid.uuid4().hex[:10], "name": name, "host": host,
                 "user": user, "port": port, "key": key}
        servers = [s for s in servers if s["id"] != entry["id"]] + [entry]
        servers.sort(key=lambda s: s["name"].lower())
        self._save(servers)
        return entry

    def remove(self, server_id):
        server = self.get(server_id)
        self.disconnect(server_id)
        self._save([s for s in self.servers() if s["id"] != server["id"]])
        return True

    def ssh_config_hosts(self):
        hosts = []
        try:
            for line in (Path.home() / ".ssh" / "config").read_text().splitlines():
                parts = line.strip().split()
                if len(parts) >= 2 and parts[0].lower() == "host":
                    hosts += [h for h in parts[1:] if not any(c in h for c in "*?!")]
        except OSError:
            pass
        known = {s["host"] for s in self.servers()}
        return [h for h in hosts if h not in known]

    # ── ssh plumbing ────────────────────────────────────────
    def env(self, extra=None):
        env = dict(os.environ)
        if not IS_WINDOWS:
            env.update({"SSH_ASKPASS": self.askpass, "SSH_ASKPASS_REQUIRE": "force"})
        if extra:
            env.update(extra)
        return env

    def ssh_argv(self, server, tty=False, master=False):
        argv = ["ssh", "-o", "ServerAliveInterval=30", "-o", "ConnectTimeout=15"]
        if not self.mux:
            # No GUI prompts on Windows: fail fast instead of hanging on a password
            # prompt, and trust a server's key the first time it is seen.
            argv += ["-o", "StrictHostKeyChecking=accept-new", *([] if tty else ["-o", "BatchMode=yes"])]
            argv += ["-t" if tty else "-T"]
        else:
            # Only connect() creates the shared master. Clients never become one:
            # a backgrounded master would inherit our output pipes and hang reads.
            private_dir(self.control_dir)
            argv += ["-o", f"ControlPath={self.control_dir}/%C"]
            if master:
                argv += ["-o", "ControlMaster=yes", "-o", "ControlPersist=15m", "-f", "-N"]
            else:
                argv += ["-o", "ControlMaster=no", "-t" if tty else "-T"]
        if server.get("port"):
            argv += ["-p", server["port"]]
        if server.get("user"):
            argv += ["-l", server["user"]]
        if server.get("key"):
            argv += ["-i", server["key"], "-o", "IdentitiesOnly=yes"]
        return argv + ["--", server["host"]]

    def command(self, server, script, *args, login=False):
        remote = "bash -lc " if login else "bash -c "
        remote += shlex.quote(script) + " ld " + " ".join(shlex.quote(str(a)) for a in args)
        return self.ssh_argv(server) + [remote]

    def connect(self, server_id):
        """Open the shared connection; ssh-askpass shows any password or host-key prompt."""
        server = self.get(server_id)
        if self.check(server_id):
            return True
        extra = {}
        if server.get("password"):
            extra["SSH_PASSWORD"] = server["password"]
        if server.get("passphrase"):
            extra["SSH_PASSPHRASE"] = server["passphrase"]
        argv = self.ssh_argv(server, master=True) if self.mux else self.ssh_argv(server) + ["true"]
        with open(os.devnull, "wb") as devnull, tempfile.TemporaryFile() as err:
            try:
                res = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=devnull, stderr=err,
                                     timeout=30, env=self.env(extra), creationflags=NO_WINDOW)
            except subprocess.TimeoutExpired as exc:
                raise RemoteError("Timed out while connecting.") from exc
            err.seek(0)
            message = err.read().decode("utf-8", "replace")
        if res.returncode != 0:
            if not self.mux and "Permission denied" in message:
                message += "\nOn Windows, log in with an SSH key (ssh-agent or the key file in the server settings)."
            raise RemoteError(fmt_err(255, message))
        self.connected[server_id] = time.time()
        return True

    def run(self, server, script, *args, data=None, timeout=60, binary=False):
        self.connect(server["id"])
        try:
            res = subprocess.run(
                self.command(server, script, *args), input=data,
                stdin=None if data is not None else subprocess.DEVNULL,
                capture_output=True, timeout=timeout, env=self.env(), creationflags=NO_WINDOW,
            )
        except subprocess.TimeoutExpired as exc:
            raise RemoteError("The server took too long to answer.") from exc
        out = res.stdout if binary else res.stdout.decode("utf-8", errors="replace")
        return res.returncode, out, res.stderr.decode("utf-8", errors="replace")

    def _control(self, server, op, *extra):
        argv = self.ssh_argv(server)
        argv[-2:-2] = ["-O", op, *extra]
        return subprocess.run(argv, capture_output=True, env=self.env(), timeout=20)

    def check(self, server_id):
        server = self.get(server_id)
        if not self.mux:
            return time.time() - self.connected.get(server_id, 0) < 900
        return self._control(server, "check").returncode == 0

    def disconnect(self, server_id):
        server = self.get(server_id)
        with self.lock:
            keys = [k for k in self.forwards if k[0] == server_id]
            for key in keys:
                self.forwards.pop(key, None)
                proc = self.tunnels.pop(key, None)
                if proc and proc.poll() is None:
                    proc.terminate()
        if self.mux:
            self._control(server, "exit")
        self.connected.pop(server_id, None)
        self.sudo_passwords.pop(server_id, None)
        return True

    def disconnect_all(self):
        for server in self.servers():
            if self.check(server["id"]) or any(k[0] == server["id"] for k in self.forwards):
                try:
                    self.disconnect(server["id"])
                except (RemoteError, OSError, subprocess.SubprocessError):
                    pass

    # ── tunnels (databases on the server) ───────────────────
    @staticmethod
    def _port_open(port):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except OSError:
            return False

    def forward(self, server_id, host, port):
        """Forward a free local port to host:port as seen from the server; returns the local port."""
        if not HOST_RE.fullmatch(host or "") or not 0 < int(port) < 65536:
            raise RemoteError("Invalid tunnel target")
        key = (server_id, host, int(port))
        with self.lock:
            local = self.forwards.get(key)
            proc = self.tunnels.get(key)
        if local and (proc is None or proc.poll() is None) and self.check(server_id):
            return local
        server = self.get(server_id)
        self.connect(server_id)
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            local = sock.getsockname()[1]
        spec = f"127.0.0.1:{local}:{host}:{port}"
        if self.mux:
            res = self._control(server, "forward", "-L", spec)
            if res.returncode != 0:
                raise RemoteError(fmt_err(res.returncode, res.stderr.decode("utf-8", "replace")))
        else:
            argv = self.ssh_argv(server)
            argv[-2:-2] = ["-N", "-L", spec, "-o", "ExitOnForwardFailure=yes"]
            extra = {}
            if server.get("password"):
                extra["SSH_PASSWORD"] = server["password"]
            if server.get("passphrase"):
                extra["SSH_PASSPHRASE"] = server["passphrase"]
            proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, env=self.env(extra), creationflags=NO_WINDOW)
            with self.lock:
                self.tunnels[key] = proc
        deadline = time.time() + 15
        while not self._port_open(local):
            if time.time() > deadline:
                raise RemoteError("The SSH tunnel to the database did not come up.")
            time.sleep(0.15)
        with self.lock:
            self.forwards[key] = local
        return local

    def test_connection(self, server):
        """Test SSH connection and authentication. Returns latency in ms or raises RemoteError."""
        server_obj = server if isinstance(server, dict) else self.get(server)
        started = time.time()
        extra = {}
        if server_obj.get("password"):
            extra["SSH_PASSWORD"] = server_obj["password"]
        if server_obj.get("passphrase"):
            extra["SSH_PASSPHRASE"] = server_obj["passphrase"]
        argv = ["ssh", "-o", "ConnectTimeout=12", "-o", "StrictHostKeyChecking=accept-new",
                "-o", "ServerAliveInterval=15", "-o", "BatchMode=no"]
        if server_obj.get("port"):
            argv += ["-p", str(server_obj["port"])]
        if server_obj.get("user"):
            argv += ["-l", server_obj["user"]]
        if server_obj.get("key"):
            argv += ["-i", server_obj["key"], "-o", "IdentitiesOnly=yes"]
        argv += ["--", server_obj["host"], "echo", "__SSH_TEST_OK__"]
        with tempfile.TemporaryFile() as err:
            try:
                res = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=err,
                                     timeout=15, env=self.env(extra), creationflags=NO_WINDOW)
            except subprocess.TimeoutExpired as exc:
                raise RemoteError(f"Connection to SSH host '{server_obj['host']}' timed out.") from exc
            err.seek(0)
            message = err.read().decode("utf-8", "replace").strip()
        if res.returncode != 0:
            clean_msg = message.split("\n")[-1] if message else "Authentication failed"
            raise RemoteError(f"SSH authentication failed: {clean_msg}")
        return {"ok": True, "ms": round((time.time() - started) * 1000)}

    # ── queries ─────────────────────────────────────────────
    def list(self):
        rows = []
        for server in self.servers():
            row = dict(server)
            row["connected"] = self.check(server["id"])
            rows.append(row)
        return rows

    def info(self, server_id):
        server = self.get(server_id)
        code, out, err = self.run(server, INFO_SCRIPT, timeout=90)
        if code != 0:
            raise RemoteError(fmt_err(code, err))
        info = {"units": []}
        for line in out.splitlines():
            key, _, value = line.partition("=")
            if key == "unit":
                unit, _, status = value.rpartition(":")
                info["units"].append({"unit": unit, "status": status or "unknown"})
            elif key:
                info[key] = value
        info["sudo_cached"] = server_id in self.sudo_passwords
        return info

    def sites(self, server_id):
        server = self.get(server_id)
        code, out, err = self.run(server, SITES_SCRIPT, timeout=90)
        if code not in (0, 1):
            raise RemoteError(fmt_err(code, err))
        sites, proxies = {}, []

        def entry(path):
            return sites.setdefault(path, {"path": path, "domains": [], "php": "", "ssl": False, "nginx": [],
                                           "type": "", "pm2": None, "port": ""})

        for line in out.splitlines():
            parts = line.split("\t")
            if parts[0] == "nginx" and len(parts) == 7:
                _, conf, names, root, php, ssl, proxy_port = parts
                domains = [n for n in names.split() if n not in ("_", "localhost") and "*" not in n]
                root = root.rstrip("/")
                if proxy_port:
                    proxies.append({"domains": domains, "port": proxy_port, "ssl": ssl == "yes", "conf": conf})
                if not root.startswith("/") or proxy_port:
                    continue
                site = entry(root[:-len("/public")] if root.endswith("/public") else root)
                site["domains"] += [d for d in domains if d not in site["domains"]]
                site["php"] = site["php"] or php
                site["ssl"] = site["ssl"] or ssl == "yes"
                site["nginx"].append(conf)
            elif parts[0] == "dir" and len(parts) == 3:
                entry(parts[1])["type"] = parts[2]
            elif parts[0] == "pm2" and len(parts) == 2:
                try:
                    processes = json.loads(parts[1] or "[]")
                except ValueError:
                    processes = []
                for proc in processes:  # only keep what we show: pm2 env holds secrets
                    env = proc.get("pm2_env") or {}
                    cwd = (env.get("pm_cwd") or "").rstrip("/")
                    if not cwd.startswith("/"):
                        continue
                    site = entry(cwd)
                    site["pm2"] = {"id": proc.get("pm_id"), "name": proc.get("name"), "status": env.get("status")}
                    site["port"] = str((env.get("env") or {}).get("PORT") or env.get("PORT") or "")

        for site in sites.values():  # nginx reverse proxy -> domain, matched by port
            for proxy in proxies:
                if site["port"] and proxy["port"] == site["port"]:
                    site["domains"] += [d for d in proxy["domains"] if d not in site["domains"]]
                    site["ssl"] = site["ssl"] or proxy["ssl"]
                    site["nginx"].append(proxy["conf"])

        if sites:
            code, out, _ = self.run(server, SITE_META_SCRIPT, *sites.keys(), timeout=60)
            for line in out.splitlines():
                parts = line.split("\t")
                if parts[0] == "meta" and len(parts) == 7 and parts[1] in sites:
                    site = sites[parts[1]]
                    site.update({"branch": parts[2], "down": parts[3] == "yes", "unit": parts[5], "unit_status": parts[6]})
                    site["type"] = site["type"] or parts[4]
        result = []
        for site in sites.values():
            if not site["type"]:
                continue
            site["name"] = os.path.basename(site["path"]) or site["path"]
            domain = site["domains"][0] if site["domains"] else ""
            site["url"] = f"{'https' if site['ssl'] else 'http'}://{domain}" if domain else ""
            for key, default in (("branch", ""), ("down", False), ("unit", ""), ("unit_status", "")):
                site.setdefault(key, default)
            result.append(site)
        result.sort(key=lambda s: (not s["domains"], s["name"].lower()))
        return result

    def list_dir(self, server_id, path, hidden=False):
        server = self.get(server_id)
        if path in ("", "~"):
            code, out, err = self.run(server, LIST_HOME_SCRIPT, timeout=30)
        else:
            code, out, err = self.run(server, LIST_SCRIPT, path, timeout=30)
        if code != 0:
            raise RemoteError(fmt_err(code, err))
        lines = out.splitlines()
        cwd, entries = lines[0] if lines else path, []
        for line in lines[1:]:
            parts = line.split("\t", 5)
            if len(parts) != 6:
                continue
            kind, size, mtime, mode, owner, name = parts
            if not hidden and name.startswith("."):
                continue
            entries.append({
                "name": name, "dir": kind == "d", "link": kind == "l", "size": int(size or 0),
                "mtime": float(mtime or 0), "mode": mode, "owner": owner,
            })
        entries.sort(key=lambda e: (not e["dir"], e["name"].lower()))
        return {"path": cwd, "entries": entries}

    def tail_log(self, server_id, path, kind="laravel", pm2_id="", unit=""):
        server = self.get(server_id)
        if kind == "laravel":
            script, args = 'f="$1/storage/logs/laravel.log"; [ -f "$f" ] || exit 4; tail -n 300 -- "$f"', [path]
        elif str(pm2_id).isdigit():
            script, args = NODE_PRELUDE + 'pm2 logs "$1" --lines 300 --nostream --raw 2>&1', [str(pm2_id)]
        elif unit and UNIT_RE.fullmatch(unit):
            script, args = 'journalctl -u "$1" -n 300 --no-pager 2>&1', [unit]
        else:
            return {"exists": False, "text": "", "hint": "No pm2 process or systemd unit runs this app, so there is no log to show."}
        code, out, err = self.run(server, script, *args)
        if code == 4:
            return {"exists": False, "text": ""}
        if code != 0 and not out:
            raise RemoteError(fmt_err(code, err))
        return {"exists": True, "text": out}

    # ── file operations ─────────────────────────────────────
    def file_op(self, server_id, op, path, target=""):
        server = self.get(server_id)
        scripts = {
            "mkdir": 'mkdir -- "$1"',
            "touch": '[ -e "$1" ] && { echo "Already exists" >&2; exit 1; }; : > "$1"',
            "rename": '[ -e "$2" ] && { echo "Already exists" >&2; exit 1; }; mv -- "$1" "$2"',
            "delete": 'rm -rf -- "$1"',
        }
        if op not in scripts:
            raise RemoteError("Unknown file operation")
        if not path.startswith("/") or path.rstrip("/") in ("", "/", "/root", "/home", "/etc", "/var", "/usr"):
            raise RemoteError("Refusing to touch that path")
        code, _, err = self.run(server, scripts[op], path, target)
        if code != 0:
            raise RemoteError(fmt_err(code, err))
        return True

    def local_copy(self, server_id, remote_path):
        return self.cache_dir / server_id / remote_path.lstrip("/")

    def fetch_for_edit(self, server_id, remote_path):
        server = self.get(server_id)
        code, size, err = self.run(server, 'stat -c %s -- "$1"', remote_path)
        if code != 0:
            raise RemoteError(fmt_err(code, err))
        if int(size.strip() or 0) > MAX_EDIT_BYTES:
            raise RemoteError("File is larger than 10 MB — download it instead.")
        code, data, err = self.run(server, 'cat -- "$1"', remote_path, binary=True)
        if code != 0:
            raise RemoteError(fmt_err(code, err))
        local = self.local_copy(server_id, remote_path)
        local.parent.mkdir(parents=True, exist_ok=True)
        private_dir(self.cache_dir)
        local.write_bytes(data)
        with self.lock:
            self.watched[str(local)] = {"server": server_id, "remote": remote_path, "mtime": local.stat().st_mtime}
            if self.watcher is None:  # only poll for saves once something was opened
                self.watcher = threading.Thread(target=self._watch_loop, daemon=True)
                self.watcher.start()
        return str(local)

    # ── small text files (.env editor) ──────────────────────
    ENV_SCRIPT = r"""
cd -- "$1" 2>/dev/null || { echo "Cannot open $1" >&2; exit 3; }
for f in .env .env.* ; do
  case "$f" in .env.example|.env.sample|.env.dist|*.bak|*~) continue ;; esac
  [ -f "$f" ] && printf 'file\t%s\n' "$f"
done
for f in .env.example .env.sample .env.dist; do [ -f "$f" ] && { printf 'example\t%s\n' "$f"; break; }; done
if [ -n "$2" ] && [ -f "$2" ]; then printf 'content\n'; cat -- "$2"; fi
"""

    def read_env(self, server_id, project, name):
        """Returns (env file names, text or None when missing, example text or None)."""
        server = self.get(server_id)
        code, out, err = self.run(server, self.ENV_SCRIPT, project, name, timeout=30)
        if code != 0:
            raise RemoteError(fmt_err(code, err))
        head, _, content = out.partition("content\n")
        files, example = [], None
        for line in head.splitlines():
            kind, _, value = line.partition("\t")
            if kind == "file":
                files.append(value)
            elif kind == "example":
                _, ex, _ = self.run(server, 'cat -- "$1/$2"', project, value, timeout=30)
                example = ex
        return files, (content if "content\n" in out else None), example

    def write_env(self, server_id, path, text):
        # New .env files must not be world-readable; existing ones keep their mode and owner.
        server = self.get(server_id)
        code, _, err = self.run(server, 'umask 027; cat > "$1"', path, data=text.encode("utf-8"), timeout=60)
        if code != 0:
            raise RemoteError(fmt_err(code, err))

    def upload_bytes(self, server_id, remote_path, data, overwrite=True):
        server = self.get(server_id)
        guard = "" if overwrite else '[ -e "$1" ] && { echo "Already exists on the server" >&2; exit 17; }; '
        code, _, err = self.run(server, guard + 'cat > "$1"', remote_path, data=data, timeout=600)
        if code != 0:
            raise RemoteError(fmt_err(code, err))

    def download(self, server_id, remote_path, is_dir, local_path):
        server = self.get(server_id)
        if is_dir:
            parent, name = os.path.dirname(remote_path.rstrip("/")) or "/", os.path.basename(remote_path.rstrip("/"))
            argv = self.command(server, 'tar czf - -C "$1" -- "$2"', parent, name)
        else:
            argv = self.command(server, 'cat -- "$1"', remote_path)
        self.connect(server_id)
        with open(local_path, "wb") as handle:
            res = subprocess.run(argv, stdout=handle, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, env=self.env(),
                                 creationflags=NO_WINDOW)
        if res.returncode != 0:
            os.unlink(local_path)
            raise RemoteError(fmt_err(res.returncode, res.stderr.decode("utf-8", "replace")))

    def _watch_loop(self):
        while True:
            time.sleep(1)
            with self.lock:
                items = list(self.watched.items())
            for local, meta in items:
                try:
                    mtime = os.stat(local).st_mtime
                except OSError:
                    continue
                if mtime == meta["mtime"]:
                    continue
                meta["mtime"] = mtime
                try:
                    self.upload_bytes(meta["server"], meta["remote"], Path(local).read_bytes())
                    self.emit({"type": "remote-file", "ok": True, "path": meta["remote"]})
                except (RemoteError, OSError) as exc:
                    self.emit({"type": "remote-file", "ok": False, "path": meta["remote"], "error": str(exc)})

    # ── sudo ────────────────────────────────────────────────
    def sudo_prefix(self, server_id, mode):
        """Returns (prefix, stdin_data). `mode` is the info()['sudo'] value."""
        if mode == "root":
            return "", None
        if mode == "nopasswd":
            return "sudo -n ", None
        password = self.sudo_passwords.get(server_id)
        if password is None:
            raise RemoteError("SUDO_PASSWORD_REQUIRED")
        return "sudo -S -p '' ", (password + "\n").encode()

    def verify_sudo(self, server_id, password):
        server = self.get(server_id)
        code, _, _ = self.run(server, "sudo -S -p '' -v", data=(password + "\n").encode(), timeout=30)
        if code != 0:
            raise RemoteError("Wrong sudo password.")
        self.sudo_passwords[server_id] = password
        return True

    # ── long-running tasks (streamed through the TaskRunner) ─
    def build_task(self, action, p):
        """Returns (title, argv, env, stdin_data)."""
        if action.startswith("forge-"):
            import forge
            return forge.build_forge_task(self, action, p)
        server = self.get(p.get("server", ""))
        label = server["name"]
        path = (p.get("path") or "").strip()
        if action in ("remote-deploy", "remote-rollback", "remote-git", "remote-composer", "remote-artisan", "remote-maintenance"):
            if not path.startswith("/"):
                raise RemoteError("Invalid project path")
        php = (p.get("php") or "").strip()
        if php and not re.fullmatch(r"\d+\.\d+", php):
            raise RemoteError("Invalid PHP version")
        prelude = (
            'set -e; export COMPOSER_NO_INTERACTION=1 COMPOSER_ALLOW_SUPERUSER=1; cd -- "$1"; '
            'PHP=$(command -v "php$2" || command -v php); COMPOSER=$(command -v composer || true); '
            'run() { printf "\\n$ %s\\n" "$*"; "$@"; }; '
        )
        name = os.path.basename(path)

        kind = p.get("type") or "laravel"
        if action in ("remote-deploy", "remote-restart", "remote-app", "remote-manage") and kind != "laravel":
            return self._app_task(server, action, kind, path, p)

        if action == "remote-deploy":
            down = bool(p.get("down"))
            maint_enter = 'trap \'run "$PHP" artisan up || true\' EXIT ERR; run "$PHP" artisan down --retry=60; ' if down else ""
            maint_exit = 'run "$PHP" artisan up; trap - EXIT ERR; ' if down else ""
            script = prelude + maint_enter + (
                'if [ -d .git ]; then '
                '  git rev-parse HEAD > .ld-last-deploy 2>/dev/null || true; '
                '  run git pull --ff-only; '
                'fi; '
                '[ -n "$COMPOSER" ] && run "$PHP" "$COMPOSER" install --no-dev --optimize-autoloader; '
                'run "$PHP" artisan migrate --force; '
                'run "$PHP" artisan optimize; '
                'run "$PHP" artisan queue:restart; '
            ) + maint_exit + 'echo; echo "Deployed successfully."'
            return f"Deploy {name} · {label}", self.command(server, script, path, php, login=True), self.env(), None

        if action == "remote-rollback":
            down = bool(p.get("down"))
            rollback_mig = bool(p.get("rollback_migration"))
            maint_enter = 'trap \'run "$PHP" artisan up || true\' EXIT ERR; run "$PHP" artisan down --retry=60; ' if down else ""
            maint_exit = 'run "$PHP" artisan up; trap - EXIT ERR; ' if down else ""
            mig_cmd = 'run "$PHP" artisan migrate:rollback --force || true; ' if rollback_mig else ""
            script = prelude + (
                'if [ ! -f .ld-last-deploy ]; then echo "No previous deployment found (.ld-last-deploy missing)"; exit 1; fi; '
                'OLD_COMMIT=$(cat .ld-last-deploy | tr -d "\\r\\n"); '
                'if [ -z "$OLD_COMMIT" ]; then echo "Empty commit hash in .ld-last-deploy"; exit 1; fi; '
                'CURRENT_HEAD=$(git rev-parse HEAD 2>/dev/null || true); '
                'echo "Rolling back to previous commit: $OLD_COMMIT"; '
            ) + maint_enter + mig_cmd + (
                'run git reset --hard "$OLD_COMMIT"; '
                '[ -n "$CURRENT_HEAD" ] && echo "$CURRENT_HEAD" > .ld-last-deploy; '
                '[ -n "$COMPOSER" ] && run "$PHP" "$COMPOSER" install --no-dev --optimize-autoloader; '
                'run "$PHP" artisan optimize; '
                'run "$PHP" artisan queue:restart; '
            ) + maint_exit + 'echo; echo "Rollback complete."'
            return f"Rollback {name} · {label}", self.command(server, script, path, php, login=True), self.env(), None

        if action == "remote-git":
            op = p.get("op")
            args = {"pull": ["pull", "--ff-only"], "fetch": ["fetch", "--all", "--prune"], "status": ["status"]}.get(op)
            if not args:
                raise RemoteError("Unknown git action")
            script = prelude + 'shift 2; run git "$@"'
            return f"Git {op} {name} · {label}", self.command(server, script, path, php, *args, login=True), self.env(), None

        if action == "remote-composer":
            script = prelude + 'shift 2; [ -n "$COMPOSER" ] || { echo "composer is not installed on the server"; exit 1; }; run "$PHP" "$COMPOSER" "$@"'
            args = shlex.split(p.get("args") or "install --no-dev --optimize-autoloader")
            return f"composer {args[0]} {name} · {label}", self.command(server, script, path, php, *args, login=True), self.env(), None

        if action == "remote-artisan":
            args = shlex.split(p.get("args") or "")
            if not args:
                raise RemoteError("Type an artisan command")
            script = prelude + 'shift 2; run "$PHP" artisan "$@"'
            return f"artisan {args[0]} {name} · {label}", self.command(server, script, path, php, *args, login=True), self.env(), None

        if action == "remote-maintenance":
            op = "down" if p.get("op") == "down" else "up"
            script = prelude + f'run "$PHP" artisan {op}'
            return f"Maintenance {op} {name} · {label}", self.command(server, script, path, php, login=True), self.env(), None

        if action == "remote-service":
            unit = (p.get("unit") or "").strip()
            op = p.get("op")
            if not UNIT_RE.fullmatch(unit) or op not in ("start", "stop", "restart", "reload"):
                raise RemoteError("Invalid service action")
            prefix, data = self.sudo_prefix(server["id"], p.get("sudo", "password"))
            script = f'{prefix}systemctl {op} -- "$1" && echo "$1: $(systemctl is-active -- "$1")"'
            return f"{op.capitalize()} {unit} · {label}", self.command(server, script, unit), self.env(), data

        raise RemoteError(f"Unknown action: {action}")

    def _app_task(self, server, action, kind, path, p):
        if not path.startswith("/"):
            raise RemoteError("Invalid project path")
        label, name = server["name"], os.path.basename(path)
        pm2_id = str(p.get("pm2") if p.get("pm2") is not None else "")
        unit = (p.get("unit") or "").strip()
        if pm2_id and not pm2_id.isdigit():
            raise RemoteError("Invalid pm2 process")
        if unit and not UNIT_RE.fullmatch(unit):
            raise RemoteError("Invalid systemd unit")

        # Restarting a systemd unit needs sudo: validate it first, while the
        # password is still the next line on stdin.
        sudo, data = "", None
        restarts = action in ("remote-deploy", "remote-restart")
        if restarts and unit and not pm2_id:
            prefix, data = self.sudo_prefix(server["id"], p.get("sudo", "password"))
            sudo = "sudo -n " if prefix else ""  # root needs no prefix
        head = ("sudo -S -p '' -v || exit 1; " if data else "") + NODE_PRELUDE + (
            'set -e; cd -- "$1"; run() { printf "\\n$ %s\\n" "$*"; "$@"; }; '
            'PY=python3; for v in .venv venv env ../.venv ../venv ../env ../..; do '
            '[ -x "$v/bin/python" ] && [ -f "$v/pyvenv.cfg" ] && PY="$v/bin/python" && break; done; '
            'PM=npm; [ -f pnpm-lock.yaml ] && PM=pnpm; [ -f yarn.lock ] && PM=yarn; { [ -f bun.lockb ] || [ -f bun.lock ]; } && PM=bun; '
        )
        restart = (
            f'run pm2 reload {pm2_id} --update-env; ' if pm2_id else
            f'run {sudo}systemctl restart {unit}; run systemctl is-active {unit}; ' if unit else
            'echo; echo "No pm2 process or systemd unit found for this app — restart it yourself."; '
        )
        if kind == "django":
            install = '[ -f requirements.txt ] && run "$PY" -m pip install -r requirements.txt; '
            build = ('run "$PY" manage.py migrate --noinput; '
                     'run "$PY" manage.py collectstatic --noinput || echo "(collectstatic skipped)"; ')
        else:
            install = ('if [ "$PM" = npm ] && [ -f package-lock.json ]; then run npm ci; '
                       'elif [ "$PM" = npm ]; then run npm install; else run "$PM" install; fi; ')
            build = 'if grep -q \'"build"[[:space:]]*:\' package.json; then run "$PM" run build; fi; '

        if action == "remote-deploy":
            script = head + '[ -d .git ] && run git pull --ff-only; ' + install + build + restart + 'echo; echo Deployed.'
            return f"Deploy {name} · {label}", self.command(server, script, path, login=True), self.env(), data
        if action == "remote-restart":
            return f"Restart {name} · {label}", self.command(server, head + restart, path, login=True), self.env(), data
        if action == "remote-app":
            op = p.get("op")
            if op == "install":
                script = head + install
            elif op == "build":
                script = head + build
            else:
                raise RemoteError("Unknown action")
            return f"{op.capitalize()} {name} · {label}", self.command(server, script, path, login=True), self.env(), None
        if action == "remote-manage":
            if kind != "django":
                raise RemoteError("manage.py is only for Django")
            args = shlex.split(p.get("args") or "")
            if not args:
                raise RemoteError("Type a manage.py command")
            script = head + 'shift; run "$PY" manage.py "$@"'
            return f"manage.py {args[0]} {name} · {label}", self.command(server, script, path, *args, login=True), self.env(), None
        raise RemoteError("Unknown action")

    def terminal_argv(self, server_id, path=""):
        server = self.get(server_id)
        self.connect(server_id)
        argv = self.ssh_argv(server, tty=True)
        if path:
            argv.append(f"cd {shlex.quote(path)} && exec \"${{SHELL:-bash}}\" -l")
        return argv
