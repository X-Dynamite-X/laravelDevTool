"""
ui/team_config.py - Herd and Team configuration manager for laravel-dev-tool.
Supports inspecting, applying, and exporting herd.yml / laravel-dev.yml.
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, Any, Optional

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False


import textwrap

def _parse_yaml_fallback(content: str) -> Dict[str, Any]:
    """Lightweight regex-based YAML parser for simple key-value and nested dicts."""
    data: Dict[str, Any] = {}
    current_section: Optional[str] = None
    dedented = textwrap.dedent(content)

    for line in dedented.splitlines():
        # Strip comments and trailing spaces
        line_clean = re.sub(r'#.*$', '', line).rstrip()
        if not line_clean.strip():
            continue

        indent = len(line_clean) - len(line_clean.lstrip())
        trimmed = line_clean.strip()

        if ":" not in trimmed:
            continue

        key, val = trimmed.split(":", 1)
        key = key.strip().strip("'\"")
        val = val.strip().strip("'\"")

        if indent == 0:
            if not val:
                current_section = key
                data[current_section] = {}
            else:
                current_section = None
                if val.lower() == "true":
                    data[key] = True
                elif val.lower() == "false":
                    data[key] = False
                elif val.isdigit():
                    data[key] = int(val)
                else:
                    data[key] = val
        elif indent > 0 and current_section:
            if val.lower() == "true":
                data[current_section][key] = True
            elif val.lower() == "false":
                data[current_section][key] = False
            elif val.isdigit():
                data[current_section][key] = int(val)
            else:
                data[current_section][key] = val

    return data


def load_team_config(project_path: str) -> Optional[Dict[str, Any]]:
    """Finds and loads herd.yml or laravel-dev.yml from the project root."""
    path = Path(project_path)
    candidates = [
        path / "herd.yml",
        path / "herd.yaml",
        path / "laravel-dev.yml",
        path / "laravel-dev.yaml",
        path / "herd.json",
        path / "laravel-dev.json",
    ]

    for cand in candidates:
        if cand.is_file():
            try:
                content = cand.read_text(encoding="utf-8")
                if cand.suffix == ".json":
                    parsed = json.loads(content)
                elif HAS_YAML:
                    parsed = yaml.safe_load(content) or {}
                else:
                    parsed = _parse_yaml_fallback(content)

                if isinstance(parsed, dict):
                    parsed["_file"] = cand.name
                    parsed["_path"] = str(cand)
                    return parsed
            except Exception:
                continue

    return None


def inspect_team_config(project_path: str, current_env: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Compares project's herd.yml configuration with current environment state.
    """
    config = load_team_config(project_path)
    if not config:
        return {
            "has_config": False,
            "file": None,
            "matches": True,
            "differences": [],
            "required": {}
        }

    differences = []
    current = current_env or {}

    req_php = str(config.get("php", "")).strip()
    curr_php = str(current.get("php", "")).strip()
    if req_php and curr_php and req_php != curr_php:
        differences.append({
            "component": "php",
            "required": req_php,
            "current": curr_php,
            "action": f"isolate {req_php}"
        })

    req_node = str(config.get("node", "")).strip()
    curr_node = str(current.get("node", "")).strip()
    if req_node and curr_node and not curr_node.startswith(req_node) and req_node != curr_node:
        differences.append({
            "component": "node",
            "required": req_node,
            "current": curr_node,
            "action": f"node-use {req_node}"
        })

    req_services = config.get("services", {})
    if isinstance(req_services, dict):
        curr_services = current.get("services", {})
        for srv, needed in req_services.items():
            if needed:
                is_running = curr_services.get(srv, False)
                if not is_running:
                    differences.append({
                        "component": "service",
                        "service": srv,
                        "required": str(needed),
                        "current": "stopped" if not is_running else "running",
                        "action": f"service start {srv}"
                    })

    return {
        "has_config": True,
        "file": config.get("_file"),
        "matches": len(differences) == 0,
        "differences": differences,
        "required": {
            "php": req_php,
            "node": req_node,
            "services": req_services
        }
    }


def detect_services_from_env(project_path: Path) -> Dict[str, Any]:
    """Inspects .env, composer.json and package.json to detect needed services and runtimes."""
    env_file = project_path / ".env"
    example_file = project_path / ".env.example"

    # Auto-copy .env.example if .env does not exist
    if not env_file.is_file() and example_file.is_file():
        try:
            import shutil
            shutil.copy2(example_file, env_file)
        except Exception:
            pass

    env_vars: Dict[str, str] = {}
    if env_file.is_file():
        try:
            for line in env_file.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    k, v = line.split("=", 1)
                    env_vars[k.strip()] = v.strip().strip("'\"")
        except Exception:
            pass

    detected: Dict[str, Any] = {
        "php": "8.3",
        "node": "20",
        "secured": True,
        "aliases": [],
        "services": {},
        "integrations": {"forge": None}
    }

    # Detect PHP from composer.json
    composer = project_path / "composer.json"
    if composer.is_file():
        try:
            cdata = json.loads(composer.read_text(encoding="utf-8"))
            req_php = cdata.get("require", {}).get("php", "")
            match = re.search(r"8\.[0-9]+", req_php)
            if match:
                detected["php"] = match.group(0)
        except Exception:
            pass

    # Detect Node from package.json
    pkg = project_path / "package.json"
    if pkg.is_file():
        try:
            pdata = json.loads(pkg.read_text(encoding="utf-8"))
            req_node = pdata.get("engines", {}).get("node", "")
            match = re.search(r"[0-9]+", req_node)
            if match:
                detected["node"] = match.group(0)
        except Exception:
            pass

    # Detect database
    db_conn = env_vars.get("DB_CONNECTION", "").lower()
    db_port = env_vars.get("DB_PORT", "")
    if db_conn in ("mysql", "mariadb"):
        port_val = f"'${{DB_PORT}}'" if db_port == "${DB_PORT}" else (db_port or "3306")
        detected["services"]["mysql"] = {"version": "8.0", "port": port_val}
    elif db_conn in ("pgsql", "postgresql"):
        port_val = f"'${{DB_PORT}}'" if db_port == "${DB_PORT}" else (db_port or "5432")
        detected["services"]["postgresql"] = {"version": "16", "port": port_val}
    elif db_conn == "mongodb":
        detected["services"]["mongodb"] = {"version": "latest", "port": db_port or "27017"}

    # Detect redis (cache / queue / session)
    cache_store = env_vars.get("CACHE_STORE", env_vars.get("CACHE_DRIVER", "")).lower()
    queue_conn = env_vars.get("QUEUE_CONNECTION", "").lower()
    session_driver = env_vars.get("SESSION_DRIVER", "").lower()
    redis_port = env_vars.get("REDIS_PORT", "6379")
    if "redis" in (cache_store, queue_conn, session_driver) or env_vars.get("REDIS_HOST"):
        detected["services"]["redis"] = {"port": redis_port}

    # Detect mailpit
    mail_mailer = env_vars.get("MAIL_MAILER", "").lower()
    mail_host = env_vars.get("MAIL_HOST", "").lower()
    if mail_mailer == "mailpit" or "mailpit" in mail_host or env_vars.get("MAIL_PORT") == "1025":
        detected["services"]["mailpit"] = True

    # Detect meilisearch
    scout_driver = env_vars.get("SCOUT_DRIVER", "").lower()
    if scout_driver == "meilisearch":
        detected["services"]["meilisearch"] = True

    # Detect minio
    fs_disk = env_vars.get("FILESYSTEM_DISK", "").lower()
    if fs_disk in ("s3", "minio") or "minio" in env_vars.get("AWS_ENDPOINT", "").lower():
        detected["services"]["minio"] = True

    # Detect reverb
    bcast_driver = env_vars.get("BROADCAST_CONNECTION", env_vars.get("BROADCAST_DRIVER", "")).lower()
    if bcast_driver == "reverb" or env_vars.get("REVERB_APP_KEY"):
        detected["services"]["reverb"] = True

    return detected


def generate_laravel_dev_yml(project_path: Path, fresh: bool = False, overrides: Optional[Dict[str, Any]] = None) -> Path:
    """Generates or updates laravel-dev.yml with detected or specified configuration."""
    yml_file = project_path / "laravel-dev.yml"
    if yml_file.is_file() and not fresh:
        return yml_file

    config = detect_services_from_env(project_path)
    if overrides:
        config.update(overrides)

    lines = [
        "# Laravel Dev project configuration (laravel-dev.yml)",
        "version: 1",
        f"php: \"{config['php']}\"",
        f"node: \"{config['node']}\"",
        f"secured: {'true' if config.get('secured', True) else 'false'}",
    ]

    aliases = config.get("aliases", [])
    if aliases:
        lines.append("aliases:")
        for a in aliases:
            lines.append(f"  - \"{a}\"")
    else:
        lines.append("aliases: []")

    srvs = config.get("services", {})
    if srvs:
        lines.append("services:")
        for srv, srv_conf in srvs.items():
            if isinstance(srv_conf, dict):
                lines.append(f"  {srv}:")
                for sk, sv in srv_conf.items():
                    lines.append(f"    {sk}: {sv}")
            elif isinstance(srv_conf, bool):
                lines.append(f"  {srv}: {'true' if srv_conf else 'false'}")
            else:
                lines.append(f"  {srv}: \"{srv_conf}\"")

    integrations = config.get("integrations", {})
    if integrations:
        lines.append("integrations:")
        forge = integrations.get("forge")
        if forge and isinstance(forge, dict):
            lines.append("  forge:")
            for fk, fv in forge.items():
                lines.append(f"    {fk}: {fv}")
        else:
            lines.append("  forge: null")

    yml_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return yml_file


def export_team_config(project_path: str, settings: Dict[str, Any], filename: str = "herd.yml") -> str:
    """Exports current project environment settings to herd.yml or laravel-dev.yml."""
    path = Path(project_path) / filename
    
    config_dict = {
        "version": 1,
        "php": str(settings.get("php", "8.3")),
    }
    
    if settings.get("node"):
        config_dict["node"] = str(settings.get("node"))
        
    services = settings.get("services", {})
    if services:
        config_dict["services"] = services

    lines = [
        "# Generated by laravel-dev-tool (Herd compatible)",
        "version: 1",
        f"php: \"{config_dict['php']}\"",
    ]
    if "node" in config_dict:
        lines.append(f"node: \"{config_dict['node']}\"")
        
    if "services" in config_dict and isinstance(config_dict["services"], dict):
        lines.append("services:")
        for k, v in config_dict["services"].items():
            if isinstance(v, bool):
                lines.append(f"  {k}: {'true' if v else 'false'}")
            else:
                lines.append(f"  {k}: \"{v}\"")

    yaml_text = "\n".join(lines) + "\n"
    path.write_text(yaml_text, encoding="utf-8")
    return str(path)
