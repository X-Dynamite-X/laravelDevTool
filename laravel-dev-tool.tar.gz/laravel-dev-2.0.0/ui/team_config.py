"""
ui/team_config.py - Herd and Team configuration manager for laravel-dev-tool.
Supports inspecting, applying, and exporting herd.yml / laravel-dev.yml.
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, Any, Optional

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False


import textwrap

def _parse_yaml_fallback(content: str) -> Dict[str, Any]:
    """Lightweight regex-based YAML parser for simple key-value and nested dicts."""
    data: Dict[str, Any] = {}
    current_section: Optional[str] = None
    dedented = textwrap.dedent(content)

    for line in dedented.splitlines():
        # Strip comments and trailing spaces
        line_clean = re.sub(r'#.*$', '', line).rstrip()
        if not line_clean.strip():
            continue

        indent = len(line_clean) - len(line_clean.lstrip())
        trimmed = line_clean.strip()

        if ":" not in trimmed:
            continue

        key, val = trimmed.split(":", 1)
        key = key.strip().strip("'\"")
        val = val.strip().strip("'\"")

        if indent == 0:
            if not val:
                current_section = key
                data[current_section] = {}
            else:
                current_section = None
                if val.lower() == "true":
                    data[key] = True
                elif val.lower() == "false":
                    data[key] = False
                elif val.isdigit():
                    data[key] = int(val)
                else:
                    data[key] = val
        elif indent > 0 and current_section:
            if val.lower() == "true":
                data[current_section][key] = True
            elif val.lower() == "false":
                data[current_section][key] = False
            elif val.isdigit():
                data[current_section][key] = int(val)
            else:
                data[current_section][key] = val

    return data


def load_team_config(project_path: str) -> Optional[Dict[str, Any]]:
    """Finds and loads herd.yml or laravel-dev.yml from the project root."""
    path = Path(project_path)
    candidates = [
        path / "herd.yml",
        path / "herd.yaml",
        path / "laravel-dev.yml",
        path / "laravel-dev.yaml",
        path / "herd.json",
        path / "laravel-dev.json",
    ]

    for cand in candidates:
        if cand.is_file():
            try:
                content = cand.read_text(encoding="utf-8")
                if cand.suffix == ".json":
                    parsed = json.loads(content)
                elif HAS_YAML:
                    parsed = yaml.safe_load(content) or {}
                else:
                    parsed = _parse_yaml_fallback(content)

                if isinstance(parsed, dict):
                    parsed["_file"] = cand.name
                    parsed["_path"] = str(cand)
                    return parsed
            except Exception:
                continue

    return None


def inspect_team_config(project_path: str, current_env: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Compares project's herd.yml configuration with current environment state.
    """
    config = load_team_config(project_path)
    if not config:
        return {
            "has_config": False,
            "file": None,
            "matches": True,
            "differences": [],
            "required": {}
        }

    differences = []
    current = current_env or {}

    req_php = str(config.get("php", "")).strip()
    curr_php = str(current.get("php", "")).strip()
    if req_php and curr_php and req_php != curr_php:
        differences.append({
            "component": "php",
            "required": req_php,
            "current": curr_php,
            "action": f"isolate {req_php}"
        })

    req_node = str(config.get("node", "")).strip()
    curr_node = str(current.get("node", "")).strip()
    if req_node and curr_node and not curr_node.startswith(req_node) and req_node != curr_node:
        differences.append({
            "component": "node",
            "required": req_node,
            "current": curr_node,
            "action": f"node-use {req_node}"
        })

    req_services = config.get("services", {})
    if isinstance(req_services, dict):
        curr_services = current.get("services", {})
        for srv, needed in req_services.items():
            if needed:
                is_running = curr_services.get(srv, False)
                if not is_running:
                    differences.append({
                        "component": "service",
                        "service": srv,
                        "required": str(needed),
                        "current": "stopped" if not is_running else "running",
                        "action": f"service start {srv}"
                    })

    return {
        "has_config": True,
        "file": config.get("_file"),
        "matches": len(differences) == 0,
        "differences": differences,
        "required": {
            "php": req_php,
            "node": req_node,
            "services": req_services
        }
    }


def export_team_config(project_path: str, settings: Dict[str, Any], filename: str = "herd.yml") -> str:
    """Exports current project environment settings to herd.yml or laravel-dev.yml."""
    path = Path(project_path) / filename
    
    config_dict = {
        "version": 1,
        "php": str(settings.get("php", "8.3")),
    }
    
    if settings.get("node"):
        config_dict["node"] = str(settings.get("node"))
        
    services = settings.get("services", {})
    if services:
        config_dict["services"] = services

    lines = [
        "# Generated by laravel-dev-tool (Herd compatible)",
        "version: 1",
        f"php: \"{config_dict['php']}\"",
    ]
    if "node" in config_dict:
        lines.append(f"node: \"{config_dict['node']}\"")
        
    if "services" in config_dict and isinstance(config_dict["services"], dict):
        lines.append("services:")
        for k, v in config_dict["services"].items():
            if isinstance(v, bool):
                lines.append(f"  {k}: {'true' if v else 'false'}")
            else:
                lines.append(f"  {k}: \"{v}\"")

    yaml_text = "\n".join(lines) + "\n"
    path.write_text(yaml_text, encoding="utf-8")
    return str(path)
