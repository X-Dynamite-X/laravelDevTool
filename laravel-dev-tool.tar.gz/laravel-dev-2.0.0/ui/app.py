#!/usr/bin/env python3
"""Laravel Dev desktop app.

A window hosting a local HTML interface (ui/web). On Linux it is GTK +
WebKitGTK (shell_gtk.py); on macOS and Windows the system web view through
pywebview (shell_webview.py). All logic lives in backend.py and sites.py.
Set LARAVEL_DEV_SHELL=webview to try the pywebview window on Linux.
"""

import os
import signal
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from osutil import IS_LINUX  # noqa: E402


def missing(lines):
    print("Missing GUI dependencies for the Laravel Dev app.")
    for line in lines:
        print("  " + line)
    return 1


def main():
    start_hidden = "--hidden" in sys.argv
    if hasattr(signal, "SIGINT"):
        signal.signal(signal.SIGINT, signal.SIG_DFL)
    choice = os.environ.get("LARAVEL_DEV_SHELL") or ("gtk" if IS_LINUX else "webview")
    if choice == "gtk":
        try:
            import shell_gtk
        except (ImportError, ValueError):
            try:
                import shell_webview
            except ImportError:
                return missing(["sudo apt install python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1",
                                "sudo pacman -S python-gobject gtk3 webkit2gtk-4.1",
                                "sudo dnf install python3-gobject gtk3 webkit2gtk4.1"])
            return shell_webview.run(start_hidden)
        return shell_gtk.run(start_hidden)
    try:
        import shell_webview
    except ImportError:
        return missing(["python -m pip install pywebview pymysql \"psycopg[binary]\""])
    return shell_webview.run(start_hidden)


if __name__ == "__main__":
    sys.exit(main())
