"""Vite & Asset Watcher Supervisor Engine for Laravel Dev.

Supervises `npm run dev` / Vite processes in the background per site,
capturing Hot Module Replacement (HMR) build logs, port detection, and start/stop controls.
"""
from __future__ import annotations

import collections
import json
import os
import re
import signal
import subprocess
import threading
import time
from pathlib import Path
from typing import Any


class ViteSiteWatcher:
    def __init__(self, site_path: str):
        self.site_path = os.path.realpath(site_path)
        self.process: subprocess.Popen[str] | None = None
        self.pid: int | None = None
        self.port: int = 5173
        self.logs: collections.deque[str] = collections.deque(maxlen=300)
        self.thread: threading.Thread | None = None
        self.running: bool = False
        self.lock = threading.Lock()

    def has_frontend(self) -> bool:
        p = Path(self.site_path)
        pkg = p / "package.json"
        if not pkg.is_file():
            return False
        try:
            data = json.loads(pkg.read_text(encoding="utf-8", errors="replace"))
            scripts = data.get("scripts", {})
            return "dev" in scripts or "watch" in scripts or "build" in scripts
        except Exception:
            return False

    def is_alive(self) -> bool:
        with self.lock:
            if self.process and self.process.poll() is None:
                self.running = True
                return True
            self.running = False
            return False

    def start(self) -> dict[str, Any]:
        with self.lock:
            if self.is_alive():
                return {"ok": True, "running": True, "pid": self.pid, "port": self.port}

            # Choose command: prefer npm run dev
            cmd = ["npm", "run", "dev"]

            try:
                self.logs.clear()
                self.logs.append(f"[{time.strftime('%H:%M:%S')}] Starting frontend watcher: {' '.join(cmd)}")

                self.process = subprocess.Popen(
                    cmd,
                    cwd=self.site_path,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    preexec_fn=os.setsid if hasattr(os, "setsid") else None,
                )
                self.pid = self.process.pid
                self.running = True

                def _reader():
                    assert self.process and self.process.stdout
                    for line in iter(self.process.stdout.readline, ""):
                        stripped = line.rstrip()
                        if stripped:
                            with self.lock:
                                self.logs.append(stripped)
                                # Detect port e.g. "http://localhost:5173"
                                m = re.search(r"http://localhost:(\d+)", stripped)
                                if m:
                                    self.port = int(m.group(1))
                    with self.lock:
                        self.running = False
                        self.logs.append(f"[{time.strftime('%H:%M:%S')}] Process exited.")

                self.thread = threading.Thread(target=_reader, daemon=True, name=f"vite-{Path(self.site_path).name}")
                self.thread.start()

                # Give it a brief moment to initialize
                time.sleep(0.3)
                return {"ok": True, "running": True, "pid": self.pid, "port": self.port}
            except Exception as e:
                self.running = False
                self.logs.append(f"Error starting watcher: {e}")
                return {"ok": False, "error": str(e)}

    def stop(self) -> dict[str, Any]:
        with self.lock:
            if not self.process:
                return {"ok": True, "message": "Not running"}

            try:
                if hasattr(os, "killpg") and self.pid:
                    os.killpg(os.getpgid(self.pid), signal.SIGTERM)
                else:
                    self.process.terminate()

                time.sleep(0.4)
                if self.process.poll() is None:
                    if hasattr(os, "killpg") and self.pid:
                        os.killpg(os.getpgid(self.pid), signal.SIGKILL)
                    else:
                        self.process.kill()

                self.running = False
                self.logs.append(f"[{time.strftime('%H:%M:%S')}] Watcher stopped by user.")
                return {"ok": True, "message": "Watcher stopped"}
            except Exception as e:
                return {"ok": False, "error": str(e)}

    def get_status(self) -> dict[str, Any]:
        alive = self.is_alive()
        # If not alive internally, scan if an external npm run dev / vite is running in this dir
        if not alive:
            try:
                res = subprocess.run(["ps", "-eo", "pid,args"], capture_output=True, text=True, timeout=2)
                for line in res.stdout.splitlines():
                    if ("vite" in line or "npm run dev" in line) and self.site_path in line:
                        parts = line.strip().split(None, 1)
                        if parts:
                            alive = True
                            self.pid = int(parts[0])
                            break
            except Exception:
                pass

        with self.lock:
            return {
                "ok": True,
                "has_frontend": self.has_frontend(),
                "running": alive,
                "pid": self.pid if alive else None,
                "port": self.port,
                "logs": list(self.logs),
            }


# Singleton manager
_WATCHERS: dict[str, ViteSiteWatcher] = {}
_WATCHERS_LOCK = threading.Lock()


def get_watcher(site_path: str) -> ViteSiteWatcher:
    norm = os.path.realpath(site_path)
    with _WATCHERS_LOCK:
        if norm not in _WATCHERS:
            _WATCHERS[norm] = ViteSiteWatcher(norm)
        return _WATCHERS[norm]


def get_vite_status(site_path: str) -> dict[str, Any]:
    return get_watcher(site_path).get_status()


def start_vite(site_path: str) -> dict[str, Any]:
    return get_watcher(site_path).start()


def stop_vite(site_path: str) -> dict[str, Any]:
    return get_watcher(site_path).stop()

