#!/usr/bin/env bash
# ui/forge_scripts/db_dump.sh - Dump database from remote Laravel app and stream gzipped to stdout
set -euo pipefail

APP_DIR="${1:-}"
EXCLUDE="${2:-}" # Comma-separated list of tables to ignore

if [ -z "$APP_DIR" ]; then
  echo "Error: APP_DIR is required." >&2
  exit 1
fi

ENV_FILE=""
if [ -f "$APP_DIR/shared/.env" ]; then
  ENV_FILE="$APP_DIR/shared/.env"
elif [ -f "$APP_DIR/current/.env" ]; then
  ENV_FILE="$APP_DIR/current/.env"
elif [ -f "$APP_DIR/.env" ]; then
  ENV_FILE="$APP_DIR/.env"
else
  echo "Error: Could not find .env file in $APP_DIR" >&2
  exit 1
fi

# Parse .env key values
parse_env() {
  local key="$1"
  grep -E "^${key}=" "$ENV_FILE" 2>/dev/null | tail -n1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'$//" | tr -d '\r'
}

DB_CONN="$(parse_env "DB_CONNECTION")"
DB_HOST="$(parse_env "DB_HOST")"
DB_PORT="$(parse_env "DB_PORT")"
DB_NAME="$(parse_env "DB_DATABASE")"
DB_USER="$(parse_env "DB_USERNAME")"
DB_PASS="$(parse_env "DB_PASSWORD")"

DB_CONN="${DB_CONN:-mysql}"
DB_HOST="${DB_HOST:-127.0.0.1}"

if [ -z "$DB_NAME" ]; then
  echo "Error: DB_DATABASE is not configured in $ENV_FILE" >&2
  exit 1
fi

if [ "$DB_CONN" = "mysql" ] || [ "$DB_CONN" = "mariadb" ]; then
  DB_PORT="${DB_PORT:-3306}"
  IGNORE_ARGS=()
  if [ -n "$EXCLUDE" ]; then
    IFS=',' read -ra ADDR <<< "$EXCLUDE"
    for tbl in "${ADDR[@]}"; do
      tbl="$(echo "$tbl" | xargs)"
      [ -n "$tbl" ] && IGNORE_ARGS+=("--ignore-table=${DB_NAME}.${tbl}")
    done
  fi

  MYSQL_PWD="$DB_PASS" mysqldump \
    --host="$DB_HOST" \
    --port="$DB_PORT" \
    --user="$DB_USER" \
    --single-transaction \
    --quick \
    --skip-lock-tables \
    "${IGNORE_ARGS[@]}" \
    "$DB_NAME" | gzip -c

elif [ "$DB_CONN" = "pgsql" ] || [ "$DB_CONN" = "postgresql" ]; then
  DB_PORT="${DB_PORT:-5432}"
  EXCLUDE_ARGS=()
  if [ -n "$EXCLUDE" ]; then
    IFS=',' read -ra ADDR <<< "$EXCLUDE"
    for tbl in "${ADDR[@]}"; do
      tbl="$(echo "$tbl" | xargs)"
      [ -n "$tbl" ] && EXCLUDE_ARGS+=("-T" "$tbl")
    done
  fi

  PGPASSWORD="$DB_PASS" pg_dump \
    -h "$DB_HOST" \
    -p "$DB_PORT" \
    -U "$DB_USER" \
    -d "$DB_NAME" \
    --no-owner \
    --no-acl \
    "${EXCLUDE_ARGS[@]}" | gzip -c

else
  echo "Error: Unsupported database engine '$DB_CONN' for automated dump." >&2
  exit 1
fi
