#!/usr/bin/env bash
# ui/forge_scripts/create_site.sh - Create a remote site with directory structure, Nginx vhost, and database
set -euo pipefail

DOMAIN="${1:-}"
PHP_VERSION="${2:-8.3}"
DB_NAME="${3:-}"
DB_USER="${4:-}"
DB_PASS="${5:-}"
DB_ENGINE="${6:-mysql}"

if [ -z "$DOMAIN" ]; then
  echo "Error: Domain is required." >&2
  exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
  echo "Error: create_site must run with root/sudo privileges." >&2
  exit 1
fi

APP_DIR="/var/www/$DOMAIN"
echo "==> Creating site structure in $APP_DIR..."

mkdir -p "$APP_DIR/releases"
mkdir -p "$APP_DIR/shared"
mkdir -p "$APP_DIR/shared/storage/app/public"
mkdir -p "$APP_DIR/shared/storage/framework/cache/data"
mkdir -p "$APP_DIR/shared/storage/framework/sessions"
mkdir -p "$APP_DIR/shared/storage/framework/views"
mkdir -p "$APP_DIR/shared/storage/logs"

# Ensure web server user ownership (www-data or nginx)
WEB_USER="www-data"
if ! id "$WEB_USER" >/dev/null 2>&1; then
  WEB_USER="nginx"
fi
chown -R "$WEB_USER:$WEB_USER" "$APP_DIR"
chmod -R 775 "$APP_DIR/shared/storage"

# Create minimal initial current placeholder if no releases exist
if [ ! -L "$APP_DIR/current" ] && [ ! -d "$APP_DIR/current" ]; then
  INIT_DIR="$APP_DIR/releases/initial"
  mkdir -p "$INIT_DIR/public"
  cat <<HTML > "$INIT_DIR/public/index.html"
<!DOCTYPE html>
<html>
<head><title>$DOMAIN</title><style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#f3f4f6;color:#1f2937}.box{background:white;padding:2rem 3rem;border-radius:12px;box-shadow:0 4px 6px -1px rgba(0,0,0,0.1);text-align:center}</style></head>
<body><div class="box"><h1>$DOMAIN</h1><p>Site provisioned by Laravel Dev Tool. Awaiting initial deployment.</p></div></body>
</html>
HTML
  ln -sfn "$INIT_DIR" "$APP_DIR/current"
fi

# Generate Nginx vhost configuration
VHOST_AVAIL="/etc/nginx/sites-available/$DOMAIN"
VHOST_ENAB="/etc/nginx/sites-enabled/$DOMAIN"
mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled

PHP_SOCK="/run/php/php${PHP_VERSION}-fpm.sock"
if [ ! -S "$PHP_SOCK" ]; then
  # Fallback to alternate socket paths if standard is not found
  ALT_SOCK="$(ls /run/php/php*-fpm.sock 2>/dev/null | head -n1 || true)"
  if [ -n "$ALT_SOCK" ]; then
    PHP_SOCK="$ALT_SOCK"
  fi
fi

cat <<NGINX > "$VHOST_AVAIL"
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    root /var/www/$DOMAIN/current/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php index.html;
    charset utf-8;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php\$ {
        fastcgi_pass unix:$PHP_SOCK;
        fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_hide_header X-Powered-By;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
NGINX

ln -sfn "$VHOST_AVAIL" "$VHOST_ENAB"
if nginx -t >/dev/null 2>&1; then
  systemctl reload nginx
  echo "==> Nginx vhost configured and reloaded."
else
  echo "Warning: Nginx syntax check failed. Please inspect $VHOST_AVAIL" >&2
fi

# Database Setup if credentials provided
if [ -n "$DB_NAME" ] && [ -n "$DB_USER" ] && [ -n "$DB_PASS" ]; then
  echo "==> Configuring database ($DB_ENGINE)..."
  if [ "$DB_ENGINE" = "mysql" ] || [ "$DB_ENGINE" = "mariadb" ]; then
    if command -v mysql >/dev/null 2>&1; then
      mysql -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" || true
      mysql -e "CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';" || true
      mysql -e "ALTER USER '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';" || true
      mysql -e "GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost'; FLUSH PRIVILEGES;" || true
      echo "==> MySQL database $DB_NAME and user $DB_USER ready."
    fi
  elif [ "$DB_ENGINE" = "pgsql" ] || [ "$DB_ENGINE" = "postgresql" ]; then
    if command -v psql >/dev/null 2>&1; then
      sudo -u postgres psql -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '$DB_USER') THEN CREATE ROLE \"$DB_USER\" WITH LOGIN PASSWORD '$DB_PASS'; END IF; END \$\$;" || true
      sudo -u postgres psql -c "ALTER ROLE \"$DB_USER\" WITH PASSWORD '$DB_PASS';" || true
      sudo -u postgres psql -c "SELECT 'CREATE DATABASE \"$DB_NAME\" OWNER \"$DB_USER\"' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '$DB_NAME')\gexec" || true
      sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE \"$DB_NAME\" TO \"$DB_USER\";" || true
      echo "==> PostgreSQL database $DB_NAME and user $DB_USER ready."
    fi
  fi
fi

# Generate initial shared/.env if it does not exist
ENV_FILE="$APP_DIR/shared/.env"
if [ ! -f "$ENV_FILE" ]; then
  DB_PORT="3306"
  [ "$DB_ENGINE" = "pgsql" ] || [ "$DB_ENGINE" = "postgresql" ] && DB_PORT="5432"

  cat <<ENV > "$ENV_FILE"
APP_NAME="$DOMAIN"
APP_ENV=production
APP_KEY=
APP_DEBUG=false
APP_URL=http://$DOMAIN

LOG_CHANNEL=stack
LOG_LEVEL=debug

DB_CONNECTION=${DB_ENGINE:-mysql}
DB_HOST=127.0.0.1
DB_PORT=$DB_PORT
DB_DATABASE=${DB_NAME:-laravel}
DB_USERNAME=${DB_USER:-laravel}
DB_PASSWORD=${DB_PASS:-secret}

BROADCAST_DRIVER=log
CACHE_DRIVER=redis
FILESYSTEM_DISK=local
QUEUE_CONNECTION=redis
SESSION_DRIVER=redis
SESSION_LIFETIME=120

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379
ENV

  chown "$WEB_USER:$WEB_USER" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  echo "==> Generated shared/.env"
fi

echo "==> Site $DOMAIN setup complete! 🚀"
