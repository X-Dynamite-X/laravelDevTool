#!/usr/bin/env bash
# ui/forge_scripts/provision.sh - Server provisioning script (idempotent)
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Error: Provisioning must run as root (or via sudo)."
  exit 1
fi

if [ ! -f /etc/os-release ]; then
  echo "Error: /etc/os-release not found. Unsupported Linux distribution."
  exit 1
fi

. /etc/os-release
OS_ID="${ID:-ubuntu}"
OS_VERSION_ID="${VERSION_ID:-}"

echo "==> Provisioning Server ($PRETTY_NAME)..."

# 1. Setup swap if RAM < 2GB
MEM_TOTAL_KB="$(awk '/MemTotal/{print $2}' /proc/meminfo)"
if [ "$MEM_TOTAL_KB" -lt 2097152 ] && [ ! -f /swapfile ]; then
  echo "==> Creating 2GB swapfile..."
  fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

# 2. Package installation
if [ "$OS_ID" = "ubuntu" ] || [ "$OS_ID" = "debian" ]; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq

  # Dependencies
  apt-get install -y curl wget git unzip software-properties-common ca-certificates ufw ulogd2- fail2ban

  # Add Ondrej PPA for Ubuntu
  if [ "$OS_ID" = "ubuntu" ]; then
    add-apt-repository -y ppa:ondrej/php
    apt-get update -qq
  fi

  # Web Server & Supervisor
  apt-get install -y nginx supervisor certbot python3-certbot-nginx

  # PHP versions (Default: 8.3 & 8.4)
  apt-get install -y \
    php8.3-cli php8.3-fpm php8.3-common php8.3-mbstring php8.3-xml php8.3-curl php8.3-zip php8.3-bcmath php8.3-intl php8.3-gd php8.3-mysql php8.3-pgsql php8.3-sqlite3 php8.3-redis \
    php8.4-cli php8.4-fpm php8.4-common php8.4-mbstring php8.4-xml php8.4-curl php8.4-zip php8.4-bcmath php8.4-intl php8.4-gd php8.4-mysql php8.4-pgsql php8.4-sqlite3 php8.4-redis

  # Database & Redis (MySQL / MariaDB & Redis)
  apt-get install -y mysql-server redis-server
  systemctl enable --now redis-server || true
  systemctl enable --now mysql || true

elif [ "$OS_ID" = "fedora" ] || [ "$OS_ID" = "rocky" ] || [ "$OS_ID" = "almalinux" ]; then
  dnf install -y epel-release || true
  dnf install -y curl wget git unzip nginx supervisor certbot python3-certbot-nginx redis
  systemctl enable --now nginx || true
  systemctl enable --now redis || true
fi

# 3. Install Composer if missing
if ! command -v composer >/dev/null 2>&1; then
  echo "==> Installing Composer..."
  curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
fi

# 4. Install Node.js LTS if missing
if ! command -v node >/dev/null 2>&1; then
  echo "==> Installing Node.js LTS..."
  curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
  apt-get install -y nodejs || true
fi

# 5. Firewall (UFW)
if command -v ufw >/dev/null 2>&1; then
  echo "==> Configuring UFW firewall..."
  ufw --force reset
  ufw default deny incoming
  ufw default allow outgoing
  ufw allow OpenSSH
  ufw allow 80/tcp
  ufw allow 443/tcp
  ufw --force enable
fi

# 6. Save provisioned record
cat <<EOF > /etc/laravel-dev-provisioned.json
{
  "provisioned_at": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "os": "$PRETTY_NAME",
  "nginx": true,
  "php_versions": ["8.3", "8.4"],
  "mysql": true,
  "redis": true,
  "supervisor": true,
  "node": "$(node -v 2>/dev/null || echo '')",
  "composer": "$(composer --version 2>/dev/null | head -n1 || echo '')"
}
EOF

echo "==> Server Provisioning Complete! 🎉"
