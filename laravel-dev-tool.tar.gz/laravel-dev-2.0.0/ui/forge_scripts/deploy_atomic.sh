#!/usr/bin/env bash
# ui/forge_scripts/deploy_atomic.sh - Zero-downtime atomic deployment for Laravel apps
set -euo pipefail

APP_DIR="${1:-}"
REPO_URL="${2:-}"
BRANCH="${3:-main}"
PHP_VERSION="${4:-8.3}"

if [ -z "$APP_DIR" ] || [ -z "$REPO_URL" ]; then
  echo "Error: APP_DIR and REPO_URL are required." >&2
  echo "Usage: deploy_atomic.sh <APP_DIR> <REPO_URL> [BRANCH] [PHP_VERSION]" >&2
  exit 1
fi

if [ ! -d "$APP_DIR/shared" ]; then
  echo "Error: $APP_DIR does not appear to be an atomic deploy directory (missing shared/)." >&2
  exit 1
fi

PHP_BIN="$(command -v "php$PHP_VERSION" || command -v php)"
COMPOSER_BIN="$(command -v composer || true)"
if [ -z "$COMPOSER_BIN" ]; then
  echo "Error: composer is not installed." >&2
  exit 1
fi

RELEASE_ID="$(date +%Y%m%d%H%M%S)"
REL_DIR="$APP_DIR/releases/$RELEASE_ID"
echo "==> Deploying release $RELEASE_ID to $REL_DIR..."

mkdir -p "$APP_DIR/releases"

# 1. Clone repository
echo "==> Cloning $REPO_URL ($BRANCH)..."
git clone --depth 1 --branch "$BRANCH" "$REPO_URL" "$REL_DIR"

# 2. Link shared assets
echo "==> Linking shared .env and storage..."
if [ -f "$APP_DIR/shared/.env" ]; then
  ln -sfn "$APP_DIR/shared/.env" "$REL_DIR/.env"
fi
rm -rf "$REL_DIR/storage"
ln -sfn "$APP_DIR/shared/storage" "$REL_DIR/storage"

cd "$REL_DIR"

# 3. Generate APP_KEY if missing in .env
if grep -qE '^APP_KEY=\s*$' "$REL_DIR/.env" 2>/dev/null; then
  echo "==> Generating application key..."
  "$PHP_BIN" artisan key:generate --force
fi

# 4. Install PHP dependencies
echo "==> Installing Composer dependencies..."
export COMPOSER_NO_INTERACTION=1
export COMPOSER_ALLOW_SUPERUSER=1
"$PHP_BIN" "$COMPOSER_BIN" install --no-dev --optimize-autoloader --prefer-dist --no-progress

# 5. Build frontend assets if package.json exists
if [ -f package.json ] && command -v npm >/dev/null 2>&1; then
  echo "==> Building frontend assets with npm..."
  npm ci || npm install
  npm run build || true
fi

# 6. Database migrations & optimizations
echo "==> Running migrations & optimizing Laravel..."
"$PHP_BIN" artisan migrate --force || {
  echo "Warning: Database migration failed. Continuing deployment..." >&2
}
"$PHP_BIN" artisan optimize || true

# 7. Atomic Symlink Switch
echo "==> Performing atomic symlink switch..."
ln -sfn "$REL_DIR" "$APP_DIR/current.tmp"
mv -Tf "$APP_DIR/current.tmp" "$APP_DIR/current"

# 8. Post-deployment restarts & cache reloads
echo "==> Restarting queues and reloading PHP-FPM..."
"$PHP_BIN" artisan queue:restart || true

# Reload PHP-FPM to clear opcache
FPM_UNIT="php${PHP_VERSION}-fpm"
if command -v systemctl >/dev/null 2>&1; then
  if [ "$(id -u)" -eq 0 ]; then
    systemctl reload "$FPM_UNIT" || systemctl reload php-fpm || true
  else
    sudo -n systemctl reload "$FPM_UNIT" || sudo -n systemctl reload php-fpm || true
  fi
fi

# 9. Release housekeeping: keep only 5 newest releases
echo "==> Pruning old releases (keeping latest 5)..."
find "$APP_DIR/releases" -mindepth 1 -maxdepth 1 -type d | sort -r | tail -n +6 | xargs -r rm -rf

echo "==> Deployment successful! Active release: $RELEASE_ID 🎉"
