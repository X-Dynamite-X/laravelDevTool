"""ui/drivers.py - Framework Drivers for Laravel Dev:
Detects and configures drivers for non-Laravel PHP and static frameworks:
- WordPress (standard & Bedrock)
- Craft CMS
- Statamic
- Symfony
- Drupal
- Joomla
- Magento 2
- CakePHP
- Static HTML
- Custom user-defined drivers (~/.config/laravel-dev/drivers/)
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


BUILTIN_DRIVERS: Dict[str, Dict[str, Any]] = {
    "laravel": {
        "label": "Laravel",
        "public": "public",
        "index": "index.php",
        "php": True,
        "description": "The PHP Framework for Web Artisans",
    },
    "statamic": {
        "label": "Statamic",
        "public": "public",
        "index": "index.php",
        "php": True,
        "description": "Flat-first / Laravel-powered CMS",
    },
    "wordpress": {
        "label": "WordPress",
        "public": "",
        "index": "index.php",
        "php": True,
        "description": "WordPress publishing platform",
    },
    "bedrock": {
        "label": "Bedrock (Roots)",
        "public": "web",
        "index": "index.php",
        "php": True,
        "description": "WordPress stack with Composer and modern directory structure",
    },
    "craft": {
        "label": "Craft CMS",
        "public": "web",
        "index": "index.php",
        "php": True,
        "description": "Flexible, user-friendly CMS",
    },
    "symfony": {
        "label": "Symfony",
        "public": "public",
        "index": "index.php",
        "php": True,
        "description": "High-performance PHP framework for Web Development",
    },
    "drupal": {
        "label": "Drupal",
        "public": "web",
        "index": "index.php",
        "php": True,
        "description": "Open source content management platform",
    },
    "joomla": {
        "label": "Joomla",
        "public": "",
        "index": "index.php",
        "php": True,
        "description": "Open source CMS and web publishing system",
    },
    "magento": {
        "label": "Magento 2",
        "public": "pub",
        "index": "index.php",
        "php": True,
        "description": "E-commerce platform written in PHP",
    },
    "cakephp": {
        "label": "CakePHP",
        "public": "webroot",
        "index": "index.php",
        "php": True,
        "description": "The Rapid Development Framework for PHP",
    },
    "static": {
        "label": "Static HTML",
        "public": "",
        "index": "index.html",
        "php": False,
        "description": "Static HTML/CSS/JS website",
    },
    "php": {
        "label": "Generic PHP",
        "public": "",
        "index": "index.php",
        "php": True,
        "description": "Standard PHP application",
    },
}


def custom_drivers_dir() -> Path:
    return Path.home() / ".config" / "laravel-dev" / "drivers"


def parse_conf_file(path: Path) -> Dict[str, str]:
    res: Dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            res[k.strip().lower()] = v.strip().strip('"\'')
    return res


def load_custom_drivers() -> Dict[str, Dict[str, Any]]:
    custom: Dict[str, Dict[str, Any]] = {}
    cdir = custom_drivers_dir()
    if cdir.is_dir():
        for conf_file in sorted(cdir.iterdir()):
            if conf_file.suffix not in (".json", ".conf"):
                continue
            try:
                name = conf_file.stem
                if conf_file.suffix == ".json":
                    data = json.loads(conf_file.read_text(encoding="utf-8"))
                else:
                    raw = parse_conf_file(conf_file)
                    data = {
                        "label": raw.get("label", name.capitalize()),
                        "check_file": raw.get("check_file", ""),
                        "public": raw.get("public", raw.get("root", "")),
                        "index": raw.get("index", "index.php"),
                        "php": raw.get("php", "true").lower() in ("1", "true", "yes"),
                        "description": raw.get("description", "Custom user driver"),
                    }
                if isinstance(data, dict):
                    custom[name] = {
                        "label": data.get("label", name.capitalize()),
                        "check_file": data.get("check_file", ""),
                        "public": data.get("public", data.get("root", "")),
                        "index": data.get("index", "index.php"),
                        "php": data.get("php", True),
                        "description": data.get("description", "Custom user driver"),
                    }
            except Exception:
                pass
    return custom


def detect_driver(project_path: Path) -> Dict[str, Any]:
    """Detects the framework driver and returns metadata."""
    p = Path(project_path).resolve()
    if not p.is_dir():
        return {
            "driver": "unknown",
            "driver_label": "Unknown",
            "root": str(p),
            "public_dir": "",
            "public_path": str(p),
            "front_controller": "",
            "php": False,
        }

    # 1. Custom drivers
    for name, spec in load_custom_drivers().items():
        chk = spec.get("check_file")
        if chk and (p / chk).exists():
            pub = spec.get("public", "")
            return {
                "driver": name,
                "driver_label": spec.get("label", name),
                "root": str(p),
                "public_dir": pub,
                "public_path": str(p / pub) if pub else str(p),
                "front_controller": spec.get("index", "index.php"),
                "php": spec.get("php", True),
                "custom": True,
            }

    # 2. Built-in drivers
    if (p / "artisan").is_file():
        if (p / "please").is_file() or (p / "content" / "collections").is_dir():
            d = BUILTIN_DRIVERS["statamic"]
            return {"driver": "statamic", "driver_label": d["label"], "root": str(p), "public_dir": d["public"],
                    "public_path": str(p / d["public"]), "front_controller": d["index"], "php": d["php"]}
        d = BUILTIN_DRIVERS["laravel"]
        return {"driver": "laravel", "driver_label": d["label"], "root": str(p), "public_dir": d["public"],
                "public_path": str(p / d["public"]), "front_controller": d["index"], "php": d["php"]}

    if (p / "web" / "wp" / "wp-settings.php").is_file() or (p / "config" / "application.php").is_file():
        d = BUILTIN_DRIVERS["bedrock"]
        return {"driver": "bedrock", "driver_label": d["label"], "root": str(p), "public_dir": d["public"],
                "public_path": str(p / d["public"]), "front_controller": d["index"], "php": d["php"]}

    if (p / "wp-config.php").is_file() or (p / "wp-load.php").is_file():
        d = BUILTIN_DRIVERS["wordpress"]
        return {"driver": "wordpress", "driver_label": d["label"], "root": str(p), "public_dir": d["public"],
                "public_path": str(p), "front_controller": d["index"], "php": d["php"]}

    if (p / "craft").is_file() and (p / "web" / "index.php").is_file():
        d = BUILTIN_DRIVERS["craft"]
        return {"driver": "craft", "driver_label": d["label"], "root": str(p), "public_dir": d["public"],
                "public_path": str(p / d["public"]), "front_controller": d["index"], "php": d["php"]}

    if (p / "bin" / "magento").is_file():
        d = BUILTIN_DRIVERS["magento"]
        return {"driver": "magento", "driver_label": d["label"], "root": str(p), "public_dir": d["public"],
                "public_path": str(p / d["public"]), "front_controller": d["index"], "php": d["php"]}

    if (p / "bin" / "cake").is_file() and (p / "webroot" / "index.php").is_file():
        d = BUILTIN_DRIVERS["cakephp"]
        return {"driver": "cakephp", "driver_label": d["label"], "root": str(p), "public_dir": d["public"],
                "public_path": str(p / d["public"]), "front_controller": d["index"], "php": d["php"]}

    if (p / "bin" / "console").is_file():
        d = BUILTIN_DRIVERS["symfony"]
        return {"driver": "symfony", "driver_label": d["label"], "root": str(p), "public_dir": d["public"],
                "public_path": str(p / d["public"]), "front_controller": d["index"], "php": d["php"]}

    if (p / "web" / "core").is_dir() or (p / "core" / "lib" / "Drupal.php").is_file():
        pub = "web" if (p / "web").is_dir() else ""
        d = BUILTIN_DRIVERS["drupal"]
        return {"driver": "drupal", "driver_label": d["label"], "root": str(p), "public_dir": pub,
                "public_path": str(p / pub) if pub else str(p), "front_controller": d["index"], "php": d["php"]}

    if (p / "configuration.php").is_file() and (p / "administrator").is_dir():
        d = BUILTIN_DRIVERS["joomla"]
        return {"driver": "joomla", "driver_label": d["label"], "root": str(p), "public_dir": d["public"],
                "public_path": str(p), "front_controller": d["index"], "php": d["php"]}

    # Generic PHP with public/
    if (p / "public" / "index.php").is_file():
        return {"driver": "php", "driver_label": "PHP (public/)", "root": str(p), "public_dir": "public",
                "public_path": str(p / "public"), "front_controller": "index.php", "php": True}

    if (p / "index.php").is_file():
        return {"driver": "php", "driver_label": "PHP", "root": str(p), "public_dir": "",
                "public_path": str(p), "front_controller": "index.php", "php": True}

    if (p / "public" / "index.html").is_file():
        return {"driver": "static", "driver_label": "Static HTML (public/)", "root": str(p), "public_dir": "public",
                "public_path": str(p / "public"), "front_controller": "index.html", "php": False}

    if (p / "index.html").is_file():
        return {"driver": "static", "driver_label": "Static HTML", "root": str(p), "public_dir": "",
                "public_path": str(p), "front_controller": "index.html", "php": False}

    return {
        "driver": "generic",
        "driver_label": "Generic Application",
        "root": str(p),
        "public_dir": "",
        "public_path": str(p),
        "front_controller": "",
        "php": True,
    }


if __name__ == "__main__":
    import sys
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    res = detect_driver(target)
    if "--json" in sys.argv:
        print(json.dumps(res, indent=2))
    else:
        # Format: public_path|front_controller|driver|php
        php_val = "1" if res.get("php") else "0"
        print(f"{res.get('public_path','')}|{res.get('front_controller','')}|{res.get('driver','')}|{php_val}")

