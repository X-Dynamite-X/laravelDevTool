"""Visual Pest & PHPUnit Test Runner Engine for Laravel Dev.

Provides test discovery across tests/Feature, tests/Unit, tests/Browser,
extracts PHPUnit & Pest test cases, parses execution results with assertion diffs,
and supports targeted filtering and coverage reports.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

# Regex patterns for test discovery
PEST_TEST_RE = re.compile(r"""\b(?:test|it)\s*\(\s*['"]([^'"]+)['"]""", re.IGNORECASE)
PHPUNIT_METHOD_RE = re.compile(r"""\bpublic\s+function\s+(test[A-Za-z0-9_]+)\s*\(""", re.IGNORECASE)
PHPUNIT_ATTR_RE = re.compile(r"""(?:#\[(?:\\PHPUnit\\Framework\\Attributes\\)?Test\]|/\*\*[\s\S]*?@test[\s\S]*?\*/)\s*public\s+function\s+([A-Za-z0-9_]+)\s*\(""", re.IGNORECASE)


def detect_runner(site_path: Path) -> str:
    if (site_path / "vendor" / "bin" / "pest").is_file():
        return "pest"
    if (site_path / "vendor" / "bin" / "phpunit").is_file():
        return "phpunit"
    if (site_path / "artisan").is_file():
        return "artisan"
    return "unknown"


def discover_tests(site_path: str) -> dict[str, Any]:
    sp = Path(site_path).resolve()
    tests_dir = sp / "tests"

    if not tests_dir.is_dir():
        return {
            "ok": True,
            "runner": detect_runner(sp),
            "suites": [],
            "total_files": 0,
            "total_tests": 0,
        }

    suites_map: dict[str, list[dict[str, Any]]] = {}
    total_files = 0
    total_tests = 0

    for root, _, files in os.walk(tests_dir):
        for fname in sorted(files):
            if not fname.endswith(".php"):
                continue

            fpath = Path(root) / fname
            rel_path = str(fpath.relative_to(sp))
            parts = Path(root).relative_to(tests_dir).parts
            suite_name = parts[0] if parts else "Root"

            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            tests_in_file = []
            lines = content.splitlines()

            for line_idx, line in enumerate(lines, start=1):
                # Pest test(...) or it(...)
                pest_m = PEST_TEST_RE.search(line)
                if pest_m:
                    test_name = pest_m.group(1).strip()
                    tests_in_file.append({
                        "name": test_name,
                        "line": line_idx,
                        "type": "pest",
                    })
                    continue

                # PHPUnit testMethod()
                pu_m = PHPUNIT_METHOD_RE.search(line)
                if pu_m:
                    test_name = pu_m.group(1).strip()
                    tests_in_file.append({
                        "name": test_name,
                        "line": line_idx,
                        "type": "phpunit",
                    })
                    continue

            # Check #[Test] attributes that span multiple lines
            for attr_m in PHPUNIT_ATTR_RE.finditer(content):
                m_name = attr_m.group(1).strip()
                if not any(t["name"] == m_name for t in tests_in_file):
                    line_no = content[:attr_m.start()].count("\n") + 1
                    tests_in_file.append({
                        "name": m_name,
                        "line": line_no,
                        "type": "phpunit",
                    })

            if tests_in_file or "Test" in fname:
                total_files += 1
                total_tests += len(tests_in_file)
                if suite_name not in suites_map:
                    suites_map[suite_name] = []
                suites_map[suite_name].append({
                    "name": fname,
                    "rel_path": rel_path,
                    "abs_path": str(fpath),
                    "suite": suite_name,
                    "tests": tests_in_file,
                    "test_count": len(tests_in_file),
                })

    suites = []
    for s_name in sorted(suites_map.keys()):
        suites.append({
            "name": s_name,
            "files": sorted(suites_map[s_name], key=lambda x: x["name"]),
            "file_count": len(suites_map[s_name]),
            "test_count": sum(f["test_count"] for f in suites_map[s_name]),
        })

    return {
        "ok": True,
        "runner": detect_runner(sp),
        "suites": suites,
        "total_files": total_files,
        "total_tests": total_tests,
    }


def parse_assertion_diff(msg: str) -> dict[str, str | None]:
    """Extract expected and actual values from failure messages."""
    expected = None
    actual = None

    # Pattern: Failed asserting that 'actual' matches expected 'expected'
    m1 = re.search(r"Failed asserting that (.+?) (?:matches expected|is identical to|is equal to) (.+?)\.", msg, re.DOTALL)
    if m1:
        actual = m1.group(1).strip()
        expected = m1.group(2).strip()
    else:
        # Pattern diff: --- Expected\n+++ Actual
        diff_idx = msg.find("--- Expected")
        if diff_idx != -1:
            diff_part = msg[diff_idx:]
            lines = diff_part.splitlines()
            exp_lines = []
            act_lines = []
            for l in lines:
                if l.startswith("- ") or l.startswith("@@"):
                    exp_lines.append(l)
                elif l.startswith("+ "):
                    act_lines.append(l)
            if exp_lines:
                expected = "\n".join(exp_lines)
            if act_lines:
                actual = "\n".join(act_lines)

    return {"expected": expected, "actual": actual}


def run_tests_enhanced(
    site_path: str,
    php_bin: str = "php",
    filter_query: str = "",
    coverage: bool = False,
    stop_on_failure: bool = False,
) -> dict[str, Any]:
    """Run tests with JUnit XML logging, optional Clover coverage, and structured diff parsing."""
    sp = Path(site_path).resolve()
    pest_bin = sp / "vendor" / "bin" / "pest"
    phpunit_bin = sp / "vendor" / "bin" / "phpunit"
    artisan_bin = sp / "artisan"

    tmp_file = tempfile.NamedTemporaryFile(suffix=".xml", delete=False)
    tmp_path = tmp_file.name
    tmp_file.close()

    cov_file = tempfile.NamedTemporaryFile(suffix=".xml", delete=False) if coverage else None
    cov_path = cov_file.name if cov_file else ""
    if cov_file:
        cov_file.close()

    try:
        runner_name = detect_runner(sp)
        if runner_name == "pest":
            cmd = [php_bin, str(pest_bin), f"--log-junit={tmp_path}"]
            if coverage:
                cmd.append(f"--coverage-clover={cov_path}")
            if filter_query:
                cmd.append(f"--filter={filter_query}")
            if stop_on_failure:
                cmd.append("--stop-on-failure")
        elif runner_name == "phpunit":
            cmd = [php_bin, str(phpunit_bin), f"--log-junit={tmp_path}"]
            if coverage:
                cmd.append(f"--coverage-clover={cov_path}")
            if filter_query:
                cmd.append(f"--filter={filter_query}")
            if stop_on_failure:
                cmd.append("--stop-on-failure")
        elif runner_name == "artisan":
            cmd = [php_bin, "artisan", "test", f"--log-junit={tmp_path}"]
            if coverage:
                cmd.append(f"--coverage-clover={cov_path}")
            if filter_query:
                cmd.extend(["--filter", filter_query])
            if stop_on_failure:
                cmd.append("--stop-on-failure")
        else:
            return {
                "ok": False,
                "error": "No test runner found (pest, phpunit, or artisan).",
                "cases": [],
            }

        proc = subprocess.run(cmd, cwd=str(sp), capture_output=True, text=True, timeout=300)
        output = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")

        cases = []
        total = 0
        passed = 0
        failed = 0
        errors = 0
        skipped = 0
        duration = 0.0

        if os.path.isfile(tmp_path) and os.path.getsize(tmp_path) > 0:
            try:
                tree = ET.parse(tmp_path)
                root = tree.getroot()
                for tc in root.iter("testcase"):
                    total += 1
                    fail = tc.find("failure")
                    err = tc.find("error")
                    skip = tc.find("skipped")

                    if skip is not None:
                        status = "skipped"
                        skipped += 1
                    elif fail is not None:
                        status = "failed"
                        failed += 1
                    elif err is not None:
                        status = "error"
                        errors += 1
                    else:
                        status = "passed"
                        passed += 1

                    msg = ""
                    if fail is not None and fail.text:
                        msg = fail.text.strip()
                    elif err is not None and err.text:
                        msg = err.text.strip()
                    elif skip is not None and skip.text:
                        msg = skip.text.strip()

                    try:
                        case_time = float(tc.get("time") or 0)
                        duration += case_time
                    except ValueError:
                        case_time = 0.0

                    diff_info = parse_assertion_diff(msg) if status in ("failed", "error") else {"expected": None, "actual": None}

                    cases.append({
                        "name": tc.get("name") or "Unnamed test",
                        "class": tc.get("class") or tc.get("classname") or "",
                        "file": tc.get("file") or "",
                        "line": tc.get("line") or "",
                        "time": case_time,
                        "status": status,
                        "message": msg,
                        "expected": diff_info["expected"],
                        "actual": diff_info["actual"],
                    })
            except Exception:
                pass

        coverage_data = None
        if coverage and cov_path and os.path.isfile(cov_path) and os.path.getsize(cov_path) > 0:
            try:
                cov_tree = ET.parse(cov_path)
                cov_root = cov_tree.getroot()
                proj_metrics = cov_root.find(".//project/metrics")
                stmts = int(proj_metrics.get("statements", 0)) if proj_metrics is not None else 0
                cov_stmts = int(proj_metrics.get("coveredstatements", 0)) if proj_metrics is not None else 0
                pct = round((cov_stmts / stmts * 100), 1) if stmts else 0.0

                file_covs = []
                for f_elem in cov_root.iter("file"):
                    f_name = f_elem.get("name", "")
                    m_elem = f_elem.find("metrics")
                    if m_elem is not None:
                        f_stmts = int(m_elem.get("statements", 0))
                        f_cov = int(m_elem.get("coveredstatements", 0))
                        f_pct = round((f_cov / f_stmts * 100), 1) if f_stmts else 0.0
                        file_covs.append({
                            "file": f_name.replace(str(sp) + "/", ""),
                            "statements": f_stmts,
                            "covered": f_cov,
                            "percent": f_pct,
                        })

                coverage_data = {
                    "ok": True,
                    "percent": pct,
                    "statements": stmts,
                    "covered_statements": cov_stmts,
                    "files": sorted(file_covs, key=lambda x: x["percent"]),
                }
            except Exception as e:
                coverage_data = {"ok": False, "error": str(e)}

        return {
            "ok": proc.returncode == 0 or total > 0,
            "runner": runner_name,
            "total": total,
            "passed": passed,
            "failed": failed,
            "errors": errors,
            "skipped": skipped,
            "time": round(duration, 3),
            "cases": cases,
            "coverage": coverage_data,
            "raw_output": output,
        }
    finally:
        for p in (tmp_path, cov_path):
            if p and os.path.exists(p):
                try:
                    os.unlink(p)
                except OSError:
                    pass

