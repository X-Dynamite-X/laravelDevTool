"""Forge Mode - Server provisioning, remote site management, and zero-downtime deployments.

Works over standard SSH through the existing Remote connection layer.
Provides:
  - Server provisioning (Nginx, PHP-FPM, MySQL/PostgreSQL, Redis, Supervisor, UFW)
  - Remote atomic site creation with isolated directories and Nginx vhost
  - Zero-downtime atomic deployments (releases, symlink swap, opcache clear, release pruning)
  - 1-click atomic rollbacks
  - SSL certificate automation via Certbot
  - Background queue workers (Supervisor) and Scheduler (Cron)
  - GitHub Deploy Key automation and Cloudflare DNS/purge integration
  - Production database pull with automatic local snapshot protection
"""

import json
import os
import re
import shlex
from pathlib import Path
from typing import Any

FORGE_SCRIPTS_DIR = Path(__file__).resolve().parent / "forge_scripts"

DOMAIN_RE = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$")
PHP_RE = re.compile(r"^\d+\.\d+$")
IDENT_RE = re.compile(r"^[a-zA-Z0-9_]{1,64}$")


def validate_domain(domain: str) -> str:
    domain = (domain or "").strip()
    if not DOMAIN_RE.match(domain):
        raise ValueError(f"Invalid domain name: '{domain}'")
    return domain


def validate_php_version(php: str) -> str:
    php = (php or "8.3").strip()
    if not PHP_RE.match(php):
        raise ValueError(f"Invalid PHP version: '{php}'")
    return php


def validate_ident(val: str, label: str) -> str:
    val = (val or "").strip()
    if not IDENT_RE.match(val):
        raise ValueError(f"Invalid {label}: '{val}' (alphanumeric and underscores only)")
    return val


def get_provision_status(remote, server_id: str) -> dict[str, Any] | None:
    """Check if server has been provisioned with laravel-dev."""
    server = remote.get(server_id)
    code, out, _ = remote.run(server, '[ -f /etc/laravel-dev-provisioned.json ] && cat /etc/laravel-dev-provisioned.json || true')
    if code == 0 and out.strip():
        try:
            return json.loads(out)
        except Exception:
            pass
    return None


def list_releases(remote, server_id: str, app_dir: str) -> dict[str, Any]:
    """List releases in $APP_DIR/releases and current symlink target."""
    server = remote.get(server_id)
    script = r"""
APP="$1"
if [ ! -d "$APP/releases" ]; then
  exit 1
fi
CUR=""
if [ -L "$APP/current" ]; then
  CUR="$(basename "$(readlink -f "$APP/current" 2>/dev/null || echo '')")"
fi
printf 'current\t%s\n' "$CUR"
find "$APP/releases" -mindepth 1 -maxdepth 1 -type d -printf '%T@\t%f\n' 2>/dev/null | sort -nr
"""
    code, out, _ = remote.run(server, script, app_dir)
    if code != 0:
        return {"current": "", "releases": []}
    lines = out.strip().splitlines()
    cur = ""
    releases = []
    for line in lines:
        parts = line.split("\t")
        if parts[0] == "current":
            cur = parts[1] if len(parts) > 1 else ""
        elif len(parts) == 2:
            try:
                mtime, rel_id = float(parts[0]), parts[1]
                releases.append({"id": rel_id, "timestamp": mtime, "active": rel_id == cur})
            except ValueError:
                continue
    return {"current": cur, "releases": releases}


def build_forge_task(remote, action: str, p: dict[str, Any]):
    """Build executable task tuple (title, argv, env, stdin_data) for forge actions."""
    server = remote.get(p.get("server", ""))
    label = server["name"]

    # 1. forge-provision
    if action == "forge-provision":
        script_path = FORGE_SCRIPTS_DIR / "provision.sh"
        if not script_path.is_file():
            raise ValueError("Provisioning script missing from ui/forge_scripts/provision.sh")
        script_content = script_path.read_text(encoding="utf-8")
        prefix, data = remote.sudo_prefix(server["id"], p.get("sudo", "password"))
        remote_cmd = f"{prefix}bash -s"
        return f"Provision Server · {label}", remote.command(server, remote_cmd), remote.env(), (data or b"") + script_content.encode("utf-8")

    # 2. forge-site-create
    if action == "forge-site-create":
        domain = validate_domain(p.get("domain", ""))
        php = validate_php_version(p.get("php", "8.3"))
        db_engine = (p.get("db_engine") or "mysql").strip().lower()
        if db_engine not in ("mysql", "mariadb", "pgsql", "postgresql", "none"):
            raise ValueError(f"Unsupported DB engine: {db_engine}")

        db_name = p.get("db_name", "").strip()
        db_user = p.get("db_user", "").strip()
        db_pass = p.get("db_pass", "").strip()
        if db_engine != "none":
            if not db_name:
                db_name = validate_ident(domain.replace(".", "_").replace("-", "_"), "database name")
            else:
                db_name = validate_ident(db_name, "database name")
            if not db_user:
                db_user = validate_ident(db_name[:16], "database user")
            else:
                db_user = validate_ident(db_user, "database user")
            if not db_pass:
                import secrets
                db_pass = secrets.token_hex(12)

        script_path = FORGE_SCRIPTS_DIR / "create_site.sh"
        script_content = script_path.read_text(encoding="utf-8")
        prefix, data = remote.sudo_prefix(server["id"], p.get("sudo", "password"))
        args = [domain, php, db_name, db_user, db_pass, db_engine]
        remote_cmd = f"{prefix}bash -s -- " + " ".join(shlex.quote(a) for a in args)
        return f"Create Site {domain} · {label}", remote.command(server, remote_cmd), remote.env(), (data or b"") + script_content.encode("utf-8")

    # 3. forge-deploy
    if action == "forge-deploy":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        repo_url = (p.get("repo_url") or "").strip()
        if not repo_url:
            raise ValueError("Repository URL is required for atomic deployment")
        branch = (p.get("branch") or "main").strip()
        php = validate_php_version(p.get("php", "8.3"))

        script_path = FORGE_SCRIPTS_DIR / "deploy_atomic.sh"
        script_content = script_path.read_text(encoding="utf-8")
        args = [app_dir, repo_url, branch, php]
        remote_cmd = "bash -s -- " + " ".join(shlex.quote(a) for a in args)
        return f"Atomic Deploy {os.path.basename(app_dir)} · {label}", remote.command(server, remote_cmd, login=True), remote.env(), script_content.encode("utf-8")

    # 4. forge-rollback
    if action == "forge-rollback":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        target_rel = (p.get("release") or "").strip()
        php = validate_php_version(p.get("php", "8.3"))

        rollback_script = r"""
APP="$1"
TARGET="$2"
PHP_V="$3"

if [ ! -d "$APP/releases" ]; then
  echo "Error: No releases directory in $APP" >&2
  exit 1
fi

if [ -z "$TARGET" ]; then
  # Auto-select previous release
  CUR="$(basename "$(readlink -f "$APP/current" 2>/dev/null || echo '')")"
  PREV="$(find "$APP/releases" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | grep -v "^${CUR}$" | sort -r | head -n1 || true)"
  if [ -z "$PREV" ]; then
    echo "Error: No previous release found to rollback to." >&2
    exit 1
  fi
  TARGET="$PREV"
fi

TARGET_DIR="$APP/releases/$TARGET"
if [ ! -d "$TARGET_DIR" ]; then
  echo "Error: Target release $TARGET does not exist in $APP/releases" >&2
  exit 1
fi

echo "==> Rolling back to release $TARGET..."
ln -sfn "$TARGET_DIR" "$APP/current.tmp"
mv -Tf "$APP/current.tmp" "$APP/current"

PHP_BIN="$(command -v "php$PHP_V" || command -v php)"
"$PHP_BIN" "$TARGET_DIR/artisan" queue:restart || true
sudo -n systemctl reload "php${PHP_V}-fpm" || true

echo "==> Rollback complete! Active release is now $TARGET 🎉"
"""
        return f"Rollback {os.path.basename(app_dir)} · {label}", remote.command(server, rollback_script, app_dir, target_rel, php, login=True), remote.env(), None

    # 5. forge-ssl
    if action == "forge-ssl":
        domain = validate_domain(p.get("domain", ""))
        email = (p.get("email") or "").strip()
        email_arg = f"--email {shlex.quote(email)}" if email else "--register-unsafely-without-email"
        prefix, data = remote.sudo_prefix(server["id"], p.get("sudo", "password"))
        script = f"""{prefix}certbot --nginx -d {shlex.quote(domain)} --redirect --non-interactive --agree-tos {email_arg}"""
        return f"Issue SSL for {domain} · {label}", remote.command(server, script), remote.env(), data

    # 6. forge-worker
    if action == "forge-worker":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        site_name = os.path.basename(app_dir).replace(".", "_")
        queue = (p.get("queue") or "default").strip()
        numprocs = int(p.get("numprocs") or 1)
        if numprocs < 1 or numprocs > 32:
            numprocs = 1
        php = validate_php_version(p.get("php", "8.3"))

        prefix, data = remote.sudo_prefix(server["id"], p.get("sudo", "password"))
        conf = f"""[program:{site_name}-worker]
process_name=%(program_name)s_%(process_num)02d
command=php{php} {app_dir}/current/artisan queue:work --sleep=3 --tries=3 --max-time=3600 --queue={queue}
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
user=www-data
numprocs={numprocs}
redirect_stderr=true
stdout_logfile={app_dir}/shared/storage/logs/worker.log
stopwaitsecs=3600
"""
        script = f"""
cat << 'EOF' | {prefix}tee /etc/supervisor/conf.d/{site_name}-worker.conf >/dev/null
{conf}
EOF
{prefix}supervisorctl reread
{prefix}supervisorctl update
{prefix}supervisorctl restart {site_name}-worker:*
echo "==> Supervisor worker configured and started."
"""
        return f"Configure Worker {site_name} · {label}", remote.command(server, script), remote.env(), data

    # 7. forge-cron
    if action == "forge-cron":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        php = validate_php_version(p.get("php", "8.3"))
        op = p.get("op", "enable")  # enable or disable

        cron_line = f"* * * * * cd {app_dir}/current && php{php} artisan schedule:run >> /dev/null 2>&1 # laravel-dev:{os.path.basename(app_dir)}"
        if op == "disable":
            script = f"""
crontab -l 2>/dev/null | grep -v "laravel-dev:{os.path.basename(app_dir)}" | crontab - || true
echo "==> Scheduler cron removed."
"""
        else:
            script = f"""
(crontab -l 2>/dev/null | grep -v "laravel-dev:{os.path.basename(app_dir)}"; echo {shlex.quote(cron_line)}) | crontab -
echo "==> Scheduler cron active (running every minute)."
"""
        return f"Scheduler {op.capitalize()} {os.path.basename(app_dir)} · {label}", remote.command(server, script, login=True), remote.env(), None

    # 8. forge-deploy-key
    if action == "forge-deploy-key":
        domain = validate_domain(p.get("domain", ""))
        key_name = f"ld_{domain.replace('.', '_')}"
        script = f"""
mkdir -p ~/.ssh && chmod 700 ~/.ssh
KEY_FILE="$HOME/.ssh/{key_name}"
if [ ! -f "$KEY_FILE" ]; then
  ssh-keygen -t ed25519 -N "" -f "$KEY_FILE" -C "laravel-dev-{domain}" >/dev/null
fi
# Update ~/.ssh/config to map host
if ! grep -q "Host gh-{domain}" ~/.ssh/config 2>/dev/null; then
  cat << 'EOF' >> ~/.ssh/config

Host gh-{domain}
  HostName github.com
  User git
  IdentityFile ~/.ssh/{key_name}
  IdentitiesOnly yes
  StrictHostKeyChecking accept-new
EOF
  chmod 600 ~/.ssh/config
fi
cat "$KEY_FILE.pub"
"""
        return f"Generate Deploy Key {domain} · {label}", remote.command(server, script, login=True), remote.env(), None

    # 9. forge-db-pull
    if action == "forge-db-pull":
        app_dir = (p.get("path") or p.get("app_dir") or "").strip()
        local_site = (p.get("local_site") or "").strip()
        exclude = (p.get("exclude") or "sessions,jobs,telescope_entries").strip()
        if not app_dir.startswith("/"):
            raise ValueError(f"Invalid application path: '{app_dir}'")
        if not local_site:
            raise ValueError("Target local site name is required to pull database safely")

        # Command runs db_dump.sh on remote server and streams output
        script_path = FORGE_SCRIPTS_DIR / "db_dump.sh"
        script_content = script_path.read_text(encoding="utf-8")
        args = [app_dir, exclude]
        remote_cmd = "bash -s -- " + " ".join(shlex.quote(a) for a in args)
        return f"DB Pull {os.path.basename(app_dir)} -> {local_site} · {label}", remote.command(server, remote_cmd, login=True), remote.env(), script_content.encode("utf-8")

    raise ValueError(f"Unknown forge action: {action}")
