"""What differs between Linux, macOS and Windows: folders, opening things,
terminals and process control. Everything else in ui/ is plain Python."""

import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
from pathlib import Path

IS_WINDOWS = os.name == "nt"
IS_MAC = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")
PLATFORM = "windows" if IS_WINDOWS else "macos" if IS_MAC else "linux"

HOME = Path.home()

# Windows: start children without a console window and in their own group.
NO_WINDOW = 0x08000000 if IS_WINDOWS else 0
NEW_GROUP = 0x00000200 if IS_WINDOWS else 0


def config_dir():
    if IS_WINDOWS:
        return Path(os.environ.get("APPDATA") or HOME / "AppData" / "Roaming") / "LaravelDev"
    if IS_MAC:
        return HOME / "Library" / "Application Support" / "LaravelDev"
    return Path(os.environ.get("XDG_CONFIG_HOME") or HOME / ".config") / "laravel-dev"


def downloads_dir():
    path = HOME / "Downloads"
    return str(path if path.is_dir() else HOME)


def private_file(path):
    """Restrict a file (secrets, passwords) to the current user where the OS supports it."""
    if not IS_WINDOWS:
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass


def private_dir(path):
    try:
        Path(path).mkdir(parents=True, exist_ok=True)
        if not IS_WINDOWS:
            os.chmod(path, 0o700)
    except OSError:
        pass


def is_abs(path):
    return os.path.isabs(os.path.expanduser(path))


# ── launching things ─────────────────────────────────────────────────────────

def spawn(argv, cwd=None):
    """Start a program and forget about it."""
    if IS_WINDOWS:
        subprocess.Popen(argv, cwd=cwd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=NO_WINDOW | NEW_GROUP)
    else:
        subprocess.Popen(argv, cwd=cwd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return True


def open_path(target):
    """Open a URL, file or folder with the system default application."""
    if IS_WINDOWS:
        os.startfile(target)  # noqa: S606 — URL or local path chosen by the app
        return True
    return spawn(["open" if IS_MAC else "xdg-open", target])


def open_terminal(cwd=None, command=None):
    """Open the user's terminal in `cwd`, optionally running `command` (argv list)."""
    cwd = cwd or str(HOME)
    if IS_WINDOWS:
        line = subprocess.list2cmdline(command) if command else ""
        if shutil.which("wt"):
            return spawn(["wt", "-d", cwd, *(["cmd", "/K", line] if line else [])])
        return spawn(["cmd", "/C", "start", "", "cmd", "/K", line or f"cd /d {cwd}"], cwd=cwd)
    if IS_MAC:
        script = f"cd {shlex.quote(cwd)}" + (f"; {shlex.join(command)}" if command else "")
        escaped = script.replace("\\", "\\\\").replace('"', '\\"')
        return spawn(["osascript", "-e", f'tell application "Terminal" to do script "{escaped}"',
                      "-e", 'tell application "Terminal" to activate'])
    if shutil.which("exo-open"):
        extra = [shlex.join(command)] if command else []
        return spawn(["exo-open", "--working-directory", cwd, "--launch", "TerminalEmulator", *extra])
    if shutil.which("gnome-terminal"):
        return spawn(["gnome-terminal", f"--working-directory={cwd}", *(["--", *command] if command else [])])
    if shutil.which("konsole"):
        return spawn(["konsole", "--workdir", cwd, *(["-e", *command] if command else [])])
    return spawn(["x-terminal-emulator", *(["-e", shlex.join(command)] if command else [])], cwd=cwd)


EDITORS = [
    ("code", "VS Code", "Visual Studio Code"), ("cursor", "Cursor", "Cursor"), ("windsurf", "Windsurf", "Windsurf"),
    ("zed", "Zed", "Zed"), ("codium", "VSCodium", "VSCodium"), ("phpstorm", "PhpStorm", "PhpStorm"),
    ("pycharm", "PyCharm", "PyCharm"), ("webstorm", "WebStorm", "WebStorm"), ("subl", "Sublime Text", "Sublime Text"),
    ("kate", "Kate", ""), ("gnome-text-editor", "Text Editor", ""), ("gedit", "gedit", ""), ("mousepad", "Mousepad", ""),
    ("notepad++", "Notepad++", ""),
]


def detect_editors():
    found = []
    for binary, label, mac_app in EDITORS:
        if shutil.which(binary):
            found.append({"bin": binary, "label": label})
        elif IS_MAC and mac_app and Path(f"/Applications/{mac_app}.app").exists():
            found.append({"bin": f"mac:{mac_app}", "label": label})
    return found


def open_in_editor(file_path, editor="", line=None):
    editors = {e["bin"] for e in detect_editors()}
    if editor not in editors:
        editor = next(iter(e["bin"] for e in detect_editors()), "")
    if editor.startswith("mac:"):
        return spawn(["open", "-a", editor[4:], str(file_path)])
    if editor:
        binary = shutil.which(editor) or editor
        args = [binary]
        ed_lower = editor.lower()
        if line and any(k in ed_lower for k in ("code", "cursor", "vscodium")):
            args.extend(["-g", f"{file_path}:{line}"])
        elif line and "subl" in ed_lower:
            args.append(f"{file_path}:{line}")
        elif line and any(k in ed_lower for k in ("phpstorm", "idea", "pycharm", "webstorm")):
            args.extend(["--line", str(line), str(file_path)])
        else:
            args.append(str(file_path))

        # VS Code & co. ship .cmd launchers on Windows, which need the shell.
        if IS_WINDOWS and binary.lower().endswith((".cmd", ".bat")):
            return spawn(["cmd", "/C", *args])
        return spawn(args)
    return open_path(file_path)


def send_desktop_notification(title: str, body: str) -> bool:
    """Deliver a desktop notification via native system tools (notify-send, osascript, or powershell)."""
    if IS_LINUX:
        tool = shutil.which("notify-send")
        if tool:
            try:
                subprocess.Popen([tool, "-a", "Laravel Dev", title, body],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
            except Exception:
                pass
    elif IS_MAC:
        try:
            safe_title = title.replace('"', '\\"')
            safe_body = body.replace('"', '\\"')
            script = f'display notification "{safe_body}" with title "{safe_title}"'
            subprocess.Popen(["osascript", "-e", script],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except Exception:
            pass
    elif IS_WINDOWS:
        try:
            ps_script = f"""
            [reflection.assembly]::loadwithpartialname('System.Windows.Forms') | Out-Null
            $notify = New-Object System.Windows.Forms.NotifyIcon
            $notify.Icon = [System.Drawing.SystemIcons]::Information
            $notify.Visible = $True
            $notify.ShowBalloonTip(5000, '{title}', '{body}', [System.Windows.Forms.ToolTipIcon]::Info)
            """
            subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script],
                             creationflags=NO_WINDOW | NEW_GROUP, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except Exception:
            pass
    return False


# ── processes ────────────────────────────────────────────────────────────────

def _win_process_alive(pid):
    import ctypes

    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return False
    try:
        code = ctypes.c_ulong()
        kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
        return code.value == 259  # STILL_ACTIVE
    finally:
        kernel32.CloseHandle(handle)


def process_gone(pid):
    """True once `pid` has exited. Reaps it when it is our child, since an
    unreaped child is a zombie that still answers kill(pid, 0)."""
    if IS_WINDOWS:
        return not _win_process_alive(pid)
    try:
        if os.waitpid(pid, os.WNOHANG)[0] == pid:
            return True
    except ChildProcessError:
        pass  # not our child (started before the app restarted)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    if IS_LINUX:
        try:
            return Path(f"/proc/{pid}/stat").read_text().split(")")[-1].split()[0] == "Z"
        except OSError:
            return True
    code, out = run_quiet(["ps", "-o", "stat=", "-p", str(pid)])
    return code != 0 or out.startswith("Z")


def process_cwd(pid):
    """Working directory of a process, or "" when the OS won't tell us."""
    if IS_LINUX:
        try:
            return os.path.realpath(f"/proc/{pid}/cwd")
        except OSError:
            return ""
    if IS_MAC:
        code, out = run_quiet(["lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"])
        for line in out.splitlines():
            if line.startswith("n"):
                return os.path.realpath(line[1:])
    return ""


def terminate_tree(pid, force=False):
    """Stop a process and everything it started (it leads its own group/session)."""
    if IS_WINDOWS:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", *(["/F"] if force else [])],
                       capture_output=True, creationflags=NO_WINDOW)
        if not force:  # console apps ignore the polite request without a window
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, creationflags=NO_WINDOW)
        return
    try:
        os.killpg(pid, signal.SIGKILL if force else signal.SIGTERM)
    except ProcessLookupError:
        pass
    except PermissionError:
        os.kill(pid, signal.SIGKILL if force else signal.SIGTERM)


def run_quiet(argv, timeout=10, cwd=None):
    try:
        res = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, cwd=cwd,
                             creationflags=NO_WINDOW)
        return res.returncode, res.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return 1, ""


def tool_version(binary, args=("--version",)):
    path = shutil.which(binary)
    if not path:
        return ""
    argv = [path, *args]
    if IS_WINDOWS and path.lower().endswith((".cmd", ".bat")):
        argv = ["cmd", "/C", *argv]
    code, out = run_quiet(argv, timeout=8)
    match = re.search(r"\d+\.\d+(\.\d+)?", out) if code == 0 else None
    return match.group(0) if match else ("installed" if code == 0 else "")


def shell_argv(command):
    """Run a user-supplied command line the way their shell would."""
    if IS_WINDOWS:
        return ["cmd", "/C", command]
    return ["bash", "-c", command]
