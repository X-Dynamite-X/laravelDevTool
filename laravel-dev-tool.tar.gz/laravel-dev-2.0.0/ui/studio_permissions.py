"""Permission requests of Studio agents: what is approved by itself, and asking the user for the rest.

An agent that wants to run a command, edit a file, read outside the project or call a tool that
changes something asks the PermissionGate. Harmless requests (read-only commands such as `ls` or
`git status`, reading inside the project, read-only laravel-dev MCP tools) are approved without
bothering the user; everything else goes to `ask(request)`, which shows the request in Studio and
blocks until the user answers:

  request  {"id", "agent", "kind": "execute" | "edit" | "read" | "fetch" | "mcp" | "other",
            "tool", "title", "detail", "editable"}
  answer   {"decision": "allow" | "always" | "deny", "input": edited command (editable requests only)}

"always" approves the same request again for the rest of the conversation (`always` is the set the
caller keeps per conversation). The time spent waiting is tracked so a CLI time limit can pause.
"""
from __future__ import annotations

import re
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

# Commands that only look at the project. Matched word by word from the start of the command, and only
# when the command has no shell operators (so `ls; rm -rf x` or `cat a > b` still ask).
READONLY_COMMANDS = (
    "ls", "cat", "head", "tail", "pwd", "wc", "tree", "file", "stat", "du", "which", "grep", "rg",
    "git status", "git log", "git diff", "git show", "git branch", "git ls-files", "git blame",
    "php -v", "php --version", "php -m", "php -i", "php artisan about", "php artisan route:list",
    "php artisan model:show", "php artisan db:show", "php artisan db:table", "php artisan config:show",
    "php artisan list", "php artisan --version", "php artisan schedule:list", "php artisan event:list",
    "php artisan migrate:status", "composer show", "composer --version", "composer validate",
    "node -v", "node --version", "npm -v", "npm ls", "npm outdated",
)
_SHELL_OPERATORS = re.compile(r"[;&|<>`$(){}\\\n]")

# Read-only laravel-dev MCP tools (no .env / service writes).
READONLY_MCP_TOOLS = (
    "list_projects", "get_project_details", "get_routes", "get_models", "get_recent_logs", "run_doctor",
    "query_database", "run_artisan", "get_status", "site_info", "list_php_versions", "site_env_get",
    "db_connection", "list_mail", "read_mail", "insights_list", "insights_analyze", "site_services_get",
)

DECISIONS = ("allow", "always", "deny")
ANSWER_TIMEOUT = 30 * 60  # nobody answered: deny


def _inside(path: str, root: Path) -> bool:
    if not path:
        return True
    p = Path(path.replace("file://", "")).expanduser()
    if not p.is_absolute():
        p = root / p
    try:
        p.resolve().relative_to(root)
        return True
    except (ValueError, OSError):
        return False


def readonly_command(command: str, root: Path) -> bool:
    command = (command or "").strip()
    if not command or _SHELL_OPERATORS.search(command):
        return False
    words = command.split()
    if not any(words[:len(entry.split())] == entry.split() for entry in READONLY_COMMANDS):
        return False
    # Arguments that are paths must stay inside the project (`cat /etc/shadow` asks).
    return all(_inside(w, root) for w in words[1:] if w.startswith(("/", "~")) or ".." in w)


def auto_allowed(kind: str, tool: str, detail: str, root: Path) -> bool:
    if kind == "execute":
        return readonly_command(detail, root)
    if kind in ("read", "search", "think"):
        return _inside(detail, root)
    if kind == "mcp":
        server, _, name = (tool[5:] if tool.startswith("mcp__") else tool).partition("__")
        return server == "laravel-dev" and name in READONLY_MCP_TOOLS
    return False


def always_key(kind: str, tool: str, detail: str) -> str:
    """What "allow for this conversation" covers: every edit, or this exact command / tool call."""
    return "edit:*" if kind in ("edit", "delete", "move") else f"{kind}:{tool}:{detail}"


class PermissionGate:
    def __init__(self, root: Path, agent: str, ask: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]],
                 cancel: Optional[threading.Event] = None, always: Optional[Set[str]] = None,
                 activity: Optional[Callable[[Dict[str, Any]], None]] = None):
        self.root = root
        self.agent = agent
        self.ask = ask
        self.cancel = cancel
        self.always = always if always is not None else set()
        self.activity = activity
        self.denied: List[str] = []
        self.waiting = threading.Event()  # set while the user is being asked
        self.waited = 0.0                 # seconds spent waiting for the user
        self._lock = threading.Lock()

    @property
    def interactive(self) -> bool:
        return self.ask is not None

    def decide(self, kind: str, tool: str, title: str, detail: str = "", editable: bool = False) -> Dict[str, Any]:
        """Returns {"decision": "allow" | "always" | "deny" | "cancel", "input": str | None}."""
        kind = kind or "other"
        if auto_allowed(kind, tool, detail, self.root):
            return {"decision": "allow", "input": None, "auto": True}
        key = always_key(kind, tool, detail)
        if key in self.always:
            self._record(kind, tool, title, detail, "always")
            return {"decision": "allow", "input": None, "auto": True}
        if self.cancel is not None and self.cancel.is_set():
            return {"decision": "cancel", "input": None}
        if self.ask is None:  # nobody to ask (e.g. the synchronous API)
            self._record(kind, tool, title, detail, "deny")
            return {"decision": "deny", "input": None}
        request = {"id": uuid.uuid4().hex[:12], "agent": self.agent, "kind": kind, "tool": tool,
                   "title": title or tool, "detail": detail, "editable": bool(editable)}
        with self._lock:  # one question at a time
            started = time.monotonic()
            self.waiting.set()
            try:
                answer = self.ask(request) or {}
            except Exception:  # noqa: BLE001
                answer = {}
            finally:
                self.waiting.clear()
                self.waited += time.monotonic() - started
        decision = answer.get("decision")
        if self.cancel is not None and self.cancel.is_set():
            decision = "cancel"
        elif decision not in DECISIONS:
            decision = "deny"
        if decision == "always":
            self.always.add(key)
        edited = answer.get("input") if editable and isinstance(answer.get("input"), str) else None
        if edited is not None and not edited.strip():
            edited = None
        self._record(kind, tool, title, edited or detail, decision, request["id"])
        if decision == "deny":
            self.denied.append(title or detail or tool)
        return {"decision": decision, "input": edited}

    def _record(self, kind, tool, title, detail, decision, req_id=""):
        if self.activity:
            self.activity({"kind": "permission", "id": req_id or uuid.uuid4().hex[:12], "perm_kind": kind,
                           "tool": tool, "title": title, "detail": detail, "decision": decision})
