"""Laravel Development Tools: Interactive Web Tinker, Structured Real-Time Log Viewer, and Local Mail Collector.
Engineered for ultra-low memory (< 10MB) and high performance.
"""

from __future__ import annotations

import base64
import datetime
import email
from email import policy
import gzip
import io
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import socket
import sqlite3
import subprocess
import sys
import tarfile
import threading
import time
import urllib.error
import urllib.request
import uuid

import sites
from tasks import TaskError

ANSI_ESCAPE_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
LOG_ENTRY_RE = re.compile(
    r"^\[(?P<date>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]\s+(?:(?P<env>[a-zA-Z0-9_\-]+)\.)?(?P<level>[A-Z]+):\s+(?P<msg>.*)$"
)


def strip_ansi(text: str) -> str:
    """Strip ANSI color and terminal escape sequences."""
    return ANSI_ESCAPE_RE.sub("", text)


# ── Interactive Web Tinker ───────────────────────────────────────────────────

_ACTIVE_TINKER_PROCS: dict[str, subprocess.Popen] = {}
_TINKER_LOCK = threading.Lock()


def stop_tinker(site_key: str) -> bool:
    """Terminate any active Tinker subprocess for the given site name or directory path."""
    with _TINKER_LOCK:
        proc = _ACTIVE_TINKER_PROCS.pop(site_key, None)
        if proc and proc.poll() is None:
            try:
                proc.kill()
                proc.wait(timeout=1)
                return True
            except Exception:
                pass
    return False


def stop_all_tinker() -> None:
    """Terminate all active Tinker subprocesses across all sites."""
    with _TINKER_LOCK:
        for proc in list(_ACTIVE_TINKER_PROCS.values()):
            if proc and proc.poll() is None:
                try:
                    proc.kill()
                except Exception:
                    pass
        _ACTIVE_TINKER_PROCS.clear()


def run_tinker(site_path: str, php_bin: str = "php", code: str = "", timeout: int = 15, site_name: str = "") -> dict:
    """Execute arbitrary PHP / Eloquent code in the site's Laravel environment.

    Uses `php artisan tinker --execute="<code>"` with a strict timeout and automatic process reaping.
    Falls back to bootstrapped one-liner evaluation if `artisan tinker` is not available.
    """
    path = Path(site_path).resolve()
    if not path.is_dir():
        return {"ok": False, "error": f"Directory not found: {site_path}", "duration_ms": 0, "output": ""}

    artisan_file = path / "artisan"
    if not artisan_file.is_file():
        return {
            "ok": False,
            "error": "artisan file not found in project directory. Ensure this is a Laravel project.",
            "duration_ms": 0,
            "output": "",
        }

    # Clean code: strip whitespace and <?php opening tags
    code_clean = (code or "").strip()
    if code_clean.startswith("<?php"):
        code_clean = code_clean[5:].strip()
    elif code_clean.startswith("<?"):
        code_clean = code_clean[2:].strip()
    if code_clean.endswith("?>"):
        code_clean = code_clean[:-2].strip()

    if not code_clean:
        return {"ok": False, "error": "No PHP code provided.", "duration_ms": 0, "output": ""}

    # Terminate any previously running tinker process for this site
    key = site_name or str(path)
    stop_tinker(key)

    # Ensure php binary exists
    resolved_php = shutil.which(php_bin) or php_bin

    start_time = time.perf_counter()

    # Base64 encode code to prevent any shell or quote interpolation issues
    b64_code = base64.b64encode(code_clean.encode("utf-8")).decode("ascii")
    tinker_wrapper = f"""
$rawCode = base64_decode('{b64_code}');
try {{
    $trimmed = rtrim(trim($rawCode), "; \\t\\n\\r\\0\\x0B");
    $isDump = preg_match('/^\\s*(dump|var_dump|print_r|dd|echo)\\s*[\\(\\s]/i', $trimmed);
    if (!$isDump && strpos($trimmed, "\\n") === false && strpos($trimmed, ";") === false && strpos($trimmed, "return ") !== 0) {{
        $evalCode = "return " . $trimmed . ";";
    }} else {{
        $evalCode = $rawCode;
    }}
    $res = eval($evalCode);
    if (!$isDump && $res !== null) {{
        if (function_exists("dump")) {{
            dump($res);
        }} else {{
            var_dump($res);
        }}
    }}
}} catch (\\Throwable $e) {{
    echo "[!] Tinker Exception: " . get_class($e) . ": " . $e->getMessage() . " on line " . $e->getLine() . PHP_EOL;
}}
"""

    argv = [resolved_php, "-d", "error_reporting=E_ALL & ~E_DEPRECATED", "artisan", "tinker", f"--execute={tinker_wrapper}"]

    # Prepare environment without interfering with PHP CLI
    env = os.environ.copy()
    env["TERM"] = "dumb"

    proc = None
    try:
        proc = subprocess.Popen(
            argv,
            cwd=str(path),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
        )
        with _TINKER_LOCK:
            _ACTIVE_TINKER_PROCS[key] = proc

        stdout, stderr = proc.communicate(timeout=timeout)
        duration_ms = round((time.perf_counter() - start_time) * 1000, 1)
        exit_code = proc.returncode

        cleaned_out = strip_ansi(stdout).strip()
        cleaned_out = re.sub(r"\s*//\s*(vendor/psy/psysh/src/|.*eval\(\)'d code).*$", "", cleaned_out, flags=re.MULTILINE).strip()
        cleaned_err = strip_ansi(stderr).strip()

        # Check if process was killed by user
        if exit_code in (-9, -15):
            return {
                "ok": False,
                "output": cleaned_out,
                "error": "Execution stopped by user.",
                "exit_code": exit_code,
                "duration_ms": duration_ms,
            }

        # If tinker is not installed (e.g. Command "tinker" is not defined), fallback to bootstrap runner
        if exit_code != 0 and 'Command "tinker" is not defined' in (cleaned_err + cleaned_out):
            return _run_bootstrap_fallback(path, resolved_php, code_clean, timeout, key=key)

        # Truncate output if larger than 150KB to protect browser DOM and memory
        if len(cleaned_out) > 150 * 1024:
            cleaned_out = cleaned_out[: 150 * 1024] + "\n\n... [Output truncated at 150KB to preserve memory]"

        if "[!] Tinker Exception:" in cleaned_out:
            ok = False
            parts = cleaned_out.split("[!] Tinker Exception:", 1)
            cleaned_out = parts[0].strip()
            error_msg = parts[1].strip()
        else:
            ok = exit_code == 0
            error_msg = cleaned_err if not ok and cleaned_err else ""
            if not ok and not error_msg:
                error_msg = cleaned_out

        return {
            "ok": ok,
            "output": cleaned_out,
            "error": error_msg,
            "exit_code": exit_code,
            "duration_ms": duration_ms,
        }

    except subprocess.TimeoutExpired:
        if proc:
            proc.kill()
            try:
                proc.communicate(timeout=2)
            except Exception:
                pass
        return {
            "ok": False,
            "error": f"Execution timed out after {timeout} seconds.",
            "duration_ms": timeout * 1000,
            "output": "",
            "exit_code": -1,
        }
    except Exception as exc:
        return {
            "ok": False,
            "error": str(exc),
            "duration_ms": round((time.perf_counter() - start_time) * 1000, 1),
            "output": "",
            "exit_code": 1,
        }
    finally:
        with _TINKER_LOCK:
            if proc and _ACTIVE_TINKER_PROCS.get(key) is proc:
                _ACTIVE_TINKER_PROCS.pop(key, None)


def _run_bootstrap_fallback(path: Path, php_bin: str, code: str, timeout: int = 15, key: str = "") -> dict:
    """Fallback runner if `laravel/tinker` package is not installed."""
    autoload = path / "vendor" / "autoload.php"
    bootstrap = path / "bootstrap" / "app.php"
    if not autoload.is_file() or not bootstrap.is_file():
        return {
            "ok": False,
            "error": "laravel/tinker is not installed and vendor/autoload.php was not found.",
            "duration_ms": 0,
            "output": "",
        }

    b64_code = base64.b64encode(code.encode("utf-8")).decode("ascii")
    runner_script = f"""
require_once {json.dumps(str(autoload))};
$app = require_once {json.dumps(str(bootstrap))};
if (interface_exists("Illuminate\\Contracts\\Console\\Kernel")) {{
    $kernel = $app->make("Illuminate\\Contracts\\Console\\Kernel");
    $kernel->bootstrap();
}}

$rawCode = base64_decode('{b64_code}');
try {{
    $cleaned = false;
    if (class_exists('\\Psy\\CodeCleaner')) {{
        $cleaner = new \\Psy\\CodeCleaner();
        $cleaned = $cleaner->clean([$rawCode]);
    }}
    if ($cleaned === false) {{
        $trimmed = rtrim($rawCode, "; \\t\\n\\r\\0\\x0B");
        $cleaned = (strpos($trimmed, "return ") === false && strpos($trimmed, ";") === false) ? "return " . $trimmed . ";" : $rawCode . ";";
    }}
    $res = eval($cleaned);
    $isExplicitDump = preg_match("/^\\s*(dump|var_dump|print_r|dd)\\s*\\(/i", trim($rawCode));
    if (!$isExplicitDump && !($res instanceof \\Psy\\CodeCleaner\\NoReturnValue)) {{
        if (function_exists("dump")) {{
            dump($res);
        }} else {{
            var_dump($res);
        }}
    }}
}} catch (\\Throwable $e) {{
    echo "[!] Tinker Exception: " . get_class($e) . ": " . $e->getMessage() . " on line " . $e->getLine() . PHP_EOL;
}}
"""
    start_time = time.perf_counter()
    proc = None
    try:
        proc = subprocess.Popen(
            [php_bin, "-d", "error_reporting=E_ALL & ~E_DEPRECATED", "-r", runner_script],
            cwd=str(path),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        if key:
            with _TINKER_LOCK:
                _ACTIVE_TINKER_PROCS[key] = proc

        stdout, stderr = proc.communicate(timeout=timeout)
        duration_ms = round((time.perf_counter() - start_time) * 1000, 1)

        cleaned_out = strip_ansi(stdout).strip()
        cleaned_out = re.sub(r"\s*//\s*(vendor/psy/psysh/src/|.*eval\(\)'d code).*$", "", cleaned_out, flags=re.MULTILINE).strip()
        cleaned_err = strip_ansi(stderr).strip()

        if proc.returncode in (-9, -15):
            return {
                "ok": False,
                "output": cleaned_out,
                "error": "Execution stopped by user.",
                "exit_code": proc.returncode,
                "duration_ms": duration_ms,
            }

        if "[!] Tinker Exception:" in cleaned_out:
            ok = False
            parts = cleaned_out.split("[!] Tinker Exception:", 1)
            cleaned_out = parts[0].strip()
            error_msg = parts[1].strip()
        else:
            ok = proc.returncode == 0
            error_msg = cleaned_err if not ok and cleaned_err else ""
            if not ok and not error_msg:
                error_msg = cleaned_out

        return {
            "ok": ok,
            "output": cleaned_out,
            "error": error_msg,
            "exit_code": proc.returncode,
            "duration_ms": duration_ms,
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc), "duration_ms": 0, "output": ""}
    finally:
        if key and proc:
            with _TINKER_LOCK:
                if _ACTIVE_TINKER_PROCS.get(key) is proc:
                    _ACTIVE_TINKER_PROCS.pop(key, None)


def run_php_json(
    site_path: Path | str,
    php_bin: str = "php",
    script: str = "",
    timeout: int = 15,
) -> dict:
    """Execute a PHP script inside the bootstrapped Laravel environment and return parsed JSON.

    Sets error_reporting(E_ALL & ~E_DEPRECATED) to prevent PHP 8.5 deprecation warnings from breaking output.
    Returns:
      {"ok": True, "data": <parsed_json>, "duration_ms": <ms>, "error": None}
      or
      {"ok": False, "error": "<message>", "error_type": "no_vendor" | "db_error" | "php_error" | "timeout", "data": None, "duration_ms": <ms>}
    """
    path = Path(site_path).resolve()
    autoload = path / "vendor" / "autoload.php"
    bootstrap = path / "bootstrap" / "app.php"

    if not autoload.is_file():
        return {
            "ok": False,
            "error": "vendor/autoload.php not found. Run composer install first.",
            "error_type": "no_vendor",
            "data": None,
            "duration_ms": 0,
        }
    if not bootstrap.is_file():
        return {
            "ok": False,
            "error": "bootstrap/app.php not found. Ensure this is a valid Laravel project.",
            "error_type": "no_bootstrap",
            "data": None,
            "duration_ms": 0,
        }

    resolved_php = shutil.which(php_bin) or php_bin

    runner_code = f"""<?php
error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', '0');

$__startTime = microtime(true);
try {{
    require_once {json.dumps(str(autoload))};
    $app = require_once {json.dumps(str(bootstrap))};
    $kernel = $app->make(\\Illuminate\\Contracts\\Console\\Kernel::class);
    $kernel->bootstrap();

    $__run = function($app) {{
{script}
    }};
    $data = $__run($app);

    $payload = [
        'ok' => true,
        'data' => $data,
        'duration_ms' => round((microtime(true) - $__startTime) * 1000, 2)
    ];
}} catch (\\Throwable $e) {{
    $msg = $e->getMessage();
    $cls = get_class($e);
    $type = 'php_error';
    if ($e instanceof \\PDOException ||
        str_contains($cls, 'Database') ||
        str_contains($cls, 'QueryException') ||
        str_contains($cls, 'ConnectionException') ||
        str_contains($msg, 'SQLSTATE') ||
        str_contains($msg, 'Connection refused') ||
        str_contains($msg, 'Unknown database') ||
        str_contains($msg, 'Access denied')) {{
        $type = 'db_error';
    }}
    $payload = [
        'ok' => false,
        'error' => $msg,
        'error_class' => $cls,
        'error_type' => $type,
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'duration_ms' => round((microtime(true) - $__startTime) * 1000, 2)
    ];
}}

echo "\\n<<<LARAVEL_DEV_JSON_START>>>\\n";
echo json_encode($payload, JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
echo "\\n<<<LARAVEL_DEV_JSON_END>>>\\n";
"""

    start_time = time.perf_counter()
    env = os.environ.copy()
    env["TERM"] = "dumb"

    try:
        proc = subprocess.Popen(
            [resolved_php],
            cwd=str(path),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
        )
        stdout, stderr = proc.communicate(input=runner_code, timeout=timeout)
        duration_ms = round((time.perf_counter() - start_time) * 1000, 1)

        cleaned_out = strip_ansi(stdout)
        cleaned_err = strip_ansi(stderr)

        start_tag = "<<<LARAVEL_DEV_JSON_START>>>"
        end_tag = "<<<LARAVEL_DEV_JSON_END>>>"

        if start_tag in cleaned_out and end_tag in cleaned_out:
            json_str = cleaned_out.split(start_tag, 1)[1].split(end_tag, 1)[0].strip()
            try:
                parsed = json.loads(json_str)
                if parsed.get("ok"):
                    return {
                        "ok": True,
                        "data": parsed.get("data"),
                        "error": None,
                        "duration_ms": duration_ms,
                    }
                else:
                    return {
                        "ok": False,
                        "error": parsed.get("error") or "PHP execution error",
                        "error_type": parsed.get("error_type", "php_error"),
                        "data": None,
                        "duration_ms": duration_ms,
                    }
            except json.JSONDecodeError:
                pass

        raw_err = (cleaned_err + "\n" + cleaned_out).strip()
        err_type = "php_error"
        if "vendor/autoload.php" in raw_err:
            err_type = "no_vendor"
        elif any(
            x in raw_err
            for x in (
                "SQLSTATE",
                "Unknown database",
                "Connection refused",
                "Access denied",
                "PDOException",
                "QueryException",
            )
        ):
            err_type = "db_error"

        return {
            "ok": False,
            "error": raw_err or f"PHP process exited with code {proc.returncode}",
            "error_type": err_type,
            "data": None,
            "duration_ms": duration_ms,
        }

    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            proc.communicate(timeout=2)
        except Exception:
            pass
        return {
            "ok": False,
            "error": f"Execution timed out after {timeout} seconds.",
            "error_type": "timeout",
            "data": None,
            "duration_ms": timeout * 1000,
        }
    except Exception as exc:
        return {
            "ok": False,
            "error": str(exc),
            "error_type": "php_error",
            "data": None,
            "duration_ms": round((time.perf_counter() - start_time) * 1000, 1),
        }


# ── Structured Real-Time Log Viewer ──────────────────────────────────────────

def list_log_files(site_path: str) -> list[str]:
    """Scan and list all log files in storage/logs/ sorted by mtime descending."""
    log_dir = Path(site_path) / "storage" / "logs"
    if not log_dir.is_dir():
        return []
    files = []
    for f in log_dir.glob("*.log"):
        if f.is_file():
            try:
                files.append((f.stat().st_mtime, f.name))
            except OSError:
                pass
    files.sort(key=lambda x: x[0], reverse=True)
    names = [name for _, name in files]
    if "laravel.log" in names:
        names.remove("laravel.log")
        names.insert(0, "laravel.log")
    return names or ["laravel.log"]


def parse_laravel_logs(
    site_path: str,
    file_name: str = "laravel.log",
    offset: int = 0,
    inode: int = 0,
    mode: str = "structured",
    max_entries: int = 300,
    tail_bytes: int = 512 * 1024,
) -> dict:
    """Read and incrementally parse storage/logs files with daily channel support.

    Does not send raw and entries together. Generates stable IDs based on inode and byte offset.
    """
    all_files = list_log_files(site_path)

    if file_name == "__all__":
        all_entries = []
        for fn in all_files:
            if fn == "__all__":
                continue
            sub = parse_laravel_logs(site_path, file_name=fn, offset=0, inode=0, mode="structured", max_entries=max_entries)
            all_entries.extend(sub.get("entries", []))
        all_entries.sort(key=lambda x: x.get("date", ""), reverse=True)
        stats = {
            "total": len(all_entries),
            "errors": sum(1 for e in all_entries if e["level"] in ("EMERGENCY", "ALERT", "CRITICAL", "ERROR")),
            "warnings": sum(1 for e in all_entries if e["level"] == "WARNING"),
            "info": sum(1 for e in all_entries if e["level"] in ("NOTICE", "INFO", "DEBUG")),
        }
        return {
            "exists": bool(all_entries),
            "reset": True,
            "entries": all_entries[:max_entries],
            "raw": "",
            "stats": stats,
            "offset": 0,
            "inode": 0,
            "file_size": 0,
            "log_files": all_files,
            "current_file": "__all__",
        }

    clean_file = Path(file_name or "laravel.log").name
    log_file = Path(site_path) / "storage" / "logs" / clean_file

    if not log_file.is_file():
        return {
            "exists": False,
            "reset": True,
            "entries": [],
            "raw": "",
            "stats": {"total": 0, "errors": 0, "warnings": 0, "info": 0},
            "offset": 0,
            "inode": 0,
            "file_size": 0,
            "log_files": all_files,
            "current_file": clean_file,
        }

    try:
        st = log_file.stat()
        cur_size = st.st_size
        cur_inode = st.st_ino
    except OSError as exc:
        return {
            "exists": True,
            "reset": True,
            "entries": [],
            "raw": f"Error accessing log file: {exc}",
            "stats": {"total": 0, "errors": 0, "warnings": 0, "info": 0},
            "offset": 0,
            "inode": 0,
            "file_size": 0,
            "log_files": all_files,
            "current_file": clean_file,
        }

    is_reset = False
    if offset <= 0 or offset > cur_size or (inode != 0 and inode != cur_inode):
        is_reset = True
        start_seek = max(0, cur_size - tail_bytes)
    else:
        start_seek = offset

    if not is_reset and cur_size == offset:
        return {
            "exists": True,
            "reset": False,
            "entries": [],
            "raw": "",
            "offset": offset,
            "inode": cur_inode,
            "file_size": cur_size,
            "log_files": all_files,
            "current_file": clean_file,
        }

    try:
        with open(log_file, "rb") as handle:
            handle.seek(start_seek)
            if is_reset and start_seek > 0:
                handle.readline()
            data = handle.read().decode("utf-8", errors="replace")
            new_offset = handle.tell()
    except OSError as exc:
        return {
            "exists": True,
            "reset": True,
            "entries": [],
            "raw": f"Error reading log file: {exc}",
            "stats": {"total": 0, "errors": 0, "warnings": 0, "info": 0},
            "offset": 0,
            "inode": cur_inode,
            "file_size": cur_size,
            "log_files": all_files,
            "current_file": clean_file,
        }

    if mode == "raw":
        return {
            "exists": True,
            "reset": is_reset,
            "raw": data,
            "entries": [],
            "offset": new_offset,
            "inode": cur_inode,
            "file_size": cur_size,
            "log_files": all_files,
            "current_file": clean_file,
        }

    lines = data.splitlines()
    entries = []
    current_entry = None
    line_idx = 0

    for line in lines:
        line_idx += 1
        m = LOG_ENTRY_RE.match(line)
        if m:
            if current_entry is not None:
                current_entry["trace"] = "\n".join(current_entry["trace_lines"]).strip()
                del current_entry["trace_lines"]
                full_text = current_entry["message"] + " " + current_entry["trace"]
                for field in ("request_id", "trace_id", "job_id"):
                    m_id = re.search(rf'"{field}"\s*:\s*"([^"]+)"', full_text, re.IGNORECASE)
                    if not m_id:
                        m_id = re.search(rf'\b{field}=([a-zA-Z0-9_\-\.]+)', full_text, re.IGNORECASE)
                    if m_id:
                        current_entry[field] = m_id.group(1)
                entries.append(current_entry)

            lvl = m.group("level").upper()
            entry_id = f"{cur_inode}_{start_seek}_{line_idx}"
            current_entry = {
                "id": entry_id,
                "date": m.group("date"),
                "env": m.group("env") or "local",
                "level": lvl,
                "message": m.group("msg").strip(),
                "trace_lines": [],
            }
        elif current_entry is not None:
            current_entry["trace_lines"].append(line)

    if current_entry is not None:
        current_entry["trace"] = "\n".join(current_entry["trace_lines"]).strip()
        del current_entry["trace_lines"]
        full_text = current_entry["message"] + " " + current_entry["trace"]
        for field in ("request_id", "trace_id", "job_id"):
            m_id = re.search(rf'"{field}"\s*:\s*"([^"]+)"', full_text, re.IGNORECASE)
            if not m_id:
                m_id = re.search(rf'\b{field}=([a-zA-Z0-9_\-\.]+)', full_text, re.IGNORECASE)
            if m_id:
                current_entry[field] = m_id.group(1)
        entries.append(current_entry)

    stats = {
        "total": len(entries),
        "errors": sum(1 for e in entries if e["level"] in ("EMERGENCY", "ALERT", "CRITICAL", "ERROR")),
        "warnings": sum(1 for e in entries if e["level"] == "WARNING"),
        "info": sum(1 for e in entries if e["level"] in ("NOTICE", "INFO", "DEBUG")),
    }

    entries.reverse()
    return {
        "exists": True,
        "reset": is_reset,
        "entries": entries[:max_entries],
        "raw": "",
        "stats": stats,
        "offset": new_offset,
        "inode": cur_inode,
        "file_size": cur_size,
        "log_files": all_files,
        "current_file": clean_file,
    }


# ── Local Mail Collector ─────────────────────────────────────────────────────

def fetch_captured_mail(site_path: str, site_name: str = "", max_messages: int = 50) -> dict:
    """Fetch captured development emails for a specific project.

    Checks Mailpit REST API on http://127.0.0.1:8025 first with project filtering.
    Falls back to zero-config extraction from storage/logs/laravel.log (used by MAIL_MAILER=log).
    Does NOT fetch bodies for every message; returns list summaries for snappy performance.
    """
    mailpit_result = _fetch_mailpit(site_path, site_name=site_name, max_messages=max_messages)
    if mailpit_result.get("active"):
        return mailpit_result

    return _fetch_log_mail(site_path, max_messages=max_messages)


def _fetch_mailpit(site_path: str, site_name: str = "", port: int = 8025, max_messages: int = 50) -> dict:
    """Fetch message list from local Mailpit instance filtered by project."""
    url = f"http://127.0.0.1:{port}/api/v1/messages?limit=100"
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=0.6) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        raw_msgs = data.get("messages") or []

        # Read project .env to determine APP_NAME and MAIL_FROM_ADDRESS
        app_name = ""
        mail_from = ""
        env_file = Path(site_path) / ".env"
        if env_file.is_file():
            try:
                import envfile
                env_dict = envfile.to_dict(env_file.read_text(encoding="utf-8", errors="replace"))
                app_name = (env_dict.get("APP_NAME") or "").strip().strip('"').strip("'")
                mail_from = (env_dict.get("MAIL_FROM_ADDRESS") or "").strip().strip('"').strip("'")
            except Exception:
                pass

        proj_name = (site_name or Path(site_path).name).strip().lower()
        app_name_lower = app_name.lower()
        mail_from_lower = mail_from.lower()

        # Known project names across the tool to avoid claiming other projects' emails
        other_project_names = set()
        try:
            import sites
            for s in sites.list_sites():
                s_name = s.get("name", "").lower()
                if s_name and s_name != proj_name:
                    other_project_names.add(s_name)
        except Exception:
            pass

        messages = []

        for m in raw_msgs:
            msg_id = m.get("ID") or m.get("id")
            from_info = m.get("From") or {}
            from_name = from_info.get("Name", "") if isinstance(from_info, dict) else ""
            from_addr = from_info.get("Address", "") if isinstance(from_info, dict) else str(from_info)

            sender = f"{from_name} <{from_addr}>".strip() if from_name else from_addr

            to_list = m.get("To") or []
            recipients = ", ".join(
                f"{t.get('Name', '')} <{t.get('Address', '')}>".strip() if isinstance(t, dict) else str(t)
                for t in to_list
            )

            tags = [t.lower() for t in (m.get("Tags") or [])]

            from_name_lower = from_name.lower()
            from_addr_lower = from_addr.lower()

            # 1. Tag match
            tag_match = proj_name in tags or (app_name_lower and app_name_lower in tags)

            # 2. From Name match (e.g. From: "DynamiteGo" <...>)
            name_match = (
                (app_name_lower and app_name_lower != "laravel" and app_name_lower in from_name_lower)
                or (proj_name in from_name_lower)
            )

            # 3. From Address match
            addr_match = (
                (mail_from_lower and mail_from_lower in from_addr_lower)
                or (proj_name in from_addr_lower)
            )

            # 4. Check if message belongs to another known project
            belongs_to_other = any(
                other_name in tags or other_name in from_name_lower or other_name in from_addr_lower
                for other_name in other_project_names
            )

            if belongs_to_other and not (tag_match or name_match or addr_match):
                continue

            if tag_match or name_match or addr_match or (not belongs_to_other and not other_project_names):
                messages.append(
                    {
                        "id": msg_id,
                        "subject": m.get("Subject") or "(No Subject)",
                        "from": sender or "Unknown",
                        "to": recipients or "Unknown",
                        "date": m.get("Created") or "",
                        "size": m.get("Size") or 0,
                        "tags": m.get("Tags") or [],
                        "source": "mailpit",
                    }
                )

        return {
            "active": True,
            "source": "mailpit",
            "messages": messages[:max_messages],
            "mailpit_url": f"http://127.0.0.1:{port}",
            "count": len(messages),
        }
    except Exception:
        return {"active": False, "source": "none", "messages": [], "mailpit_url": None, "count": 0}


def fetch_mail_message(site_path: str, message_id: str, source: str = "mailpit", port: int = 8025) -> dict:
    """Retrieve message HTML and Plaintext body on demand."""
    if not message_id:
        return {"id": "", "html": "", "text": "", "source": source}

    if source == "mailpit":
        url = f"http://127.0.0.1:{port}/api/v1/message/{message_id}"
        try:
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=0.8) as resp:
                detail = json.loads(resp.read().decode("utf-8"))
            raw_headers = ""
            try:
                raw_req = urllib.request.Request(f"{url}/raw", headers={"Accept": "text/plain"})
                with urllib.request.urlopen(raw_req, timeout=0.6) as raw_resp:
                    raw_headers = raw_resp.read(8192).decode("utf-8", errors="replace")
            except Exception:
                pass
            return {
                "id": message_id,
                "html": detail.get("HTML") or "",
                "text": detail.get("Text") or "",
                "raw": raw_headers,
                "source": "mailpit",
            }
        except Exception as exc:
            return {"id": message_id, "html": "", "text": f"Error loading body: {exc}", "source": "mailpit"}

    # Log mailer extraction
    log_mail = _fetch_log_mail(site_path, max_messages=100)
    for m in log_mail.get("messages", []):
        if m.get("id") == message_id:
            return {
                "id": message_id,
                "html": m.get("html", ""),
                "text": m.get("text", ""),
                "raw": m.get("raw", ""),
                "source": "log",
            }

    return {"id": message_id, "html": "", "text": "Message not found in laravel.log", "source": "log"}


def _fetch_log_mail(site_path: str, max_messages: int = 50) -> dict:
    """Extract zero-config emails written by Laravel's MAIL_MAILER=log into laravel.log."""
    log_file = Path(site_path) / "storage" / "logs" / "laravel.log"
    if not log_file.is_file():
        return {
            "active": False,
            "source": "log",
            "messages": [],
            "mailpit_url": None,
            "count": 0,
            "notice": "No laravel.log file found. Send an email with MAIL_MAILER=log to preview it here.",
        }

    try:
        file_size = log_file.stat().st_size
        read_size = min(file_size, 1024 * 1024)  # Read up to 1MB tail
        with open(log_file, "rb") as handle:
            if file_size > read_size:
                handle.seek(file_size - read_size)
                handle.readline()
            content = handle.read().decode("utf-8", errors="replace")
    except OSError:
        return {"active": False, "source": "log", "messages": [], "mailpit_url": None, "count": 0}

    # Pattern for Laravel log mailer entries
    mail_pattern = re.compile(
        r"\[(?P<date>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]\s+[a-zA-Z0-9_\-.]*DEBUG:\s+(?=(?i:From:|To:|Subject:|Message-ID:|Date:|MIME-Version:|Content-Type:))",
        re.MULTILINE,
    )

    matches = list(mail_pattern.finditer(content))
    messages = []
    idx = 0

    for m in matches:
        idx += 1
        start = m.end()
        date_str = m.group("date")

        # Find where next log entry starts
        next_entry = re.search(r"\n\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\]", content[start:])
        raw_msg = content[start : start + next_entry.start()] if next_entry else content[start:]
        raw_msg = re.sub(r"\s+\[\]\s+\[\]\s*$", "", raw_msg.strip())

        try:
            parsed = email.message_from_string(raw_msg, policy=policy.default)
            subject = parsed.get("subject") or "(No Subject)"
            from_hdr = parsed.get("from") or "Unknown"
            to_hdr = parsed.get("to") or "Unknown"
            date_hdr = parsed.get("date") or date_str

            html_part = parsed.get_body(preferencelist=("html",))
            text_part = parsed.get_body(preferencelist=("plain",))

            html_body = html_part.get_content() if html_part else ""
            text_body = text_part.get_content() if text_part else ""

            if not html_body and not text_body:
                payload = parsed.get_payload()
                if isinstance(payload, str):
                    text_body = payload
                elif isinstance(payload, list) and payload:
                    first = payload[0]
                    if hasattr(first, "get_payload"):
                        text_body = str(first.get_payload(decode=True) or "")

            messages.append(
                {
                    "id": f"log-mail-{idx}",
                    "subject": subject,
                    "from": from_hdr,
                    "to": to_hdr,
                    "date": date_hdr,
                    "html": html_body,
                    "text": text_body,
                    "raw": raw_msg[:2000],
                    "source": "log",
                }
            )
        except Exception:
            continue

    messages.reverse()
    clipped = messages[:max_messages]

    return {
        "active": len(clipped) > 0,
        "source": "log",
        "messages": clipped,
        "mailpit_url": None,
        "count": len(clipped),
    }


def clear_captured_mail(site_path: str, site_name: str = "", ids: list[str] | None = None, port: int = 8025) -> dict:
    """Clear captured emails belonging to this project from Mailpit."""
    # Attempt Mailpit clear
    if ids is None:
        proj_mail = _fetch_mailpit(site_path, site_name=site_name, port=port)
        if proj_mail.get("active"):
            ids = [m["id"] for m in proj_mail.get("messages", [])]
        else:
            return {"ok": False, "source": "log", "error": "Emails are part of laravel.log and cannot be deleted individually."}

    if not ids:
        return {"ok": True, "source": "mailpit", "cleared": True, "deleted_count": 0}

    try:
        data = json.dumps({"IDs": ids}).encode("utf-8")
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}/api/v1/messages",
            data=data,
            headers={"Content-Type": "application/json"},
            method="DELETE",
        )
        with urllib.request.urlopen(req, timeout=1.0) as resp:
            if resp.status in (200, 204):
                return {"ok": True, "source": "mailpit", "cleared": True, "deleted_count": len(ids)}
    except Exception as exc:
        return {"ok": False, "source": "mailpit", "error": str(exc)}

    return {"ok": False, "source": "mailpit", "error": "Failed to delete project emails"}



# ── Queue Monitor & Failed Jobs ──────────────────────────────────────────────

def check_horizon_status(site_path: str, php_bin: str = "php") -> str:
    path = Path(site_path).resolve()
    artisan = path / "artisan"
    if not artisan.is_file():
        return ""
    try:
        res = subprocess.run(
            [php_bin, str(artisan), "horizon:status"],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=3,
        )
        low = (res.stdout or res.stderr or "").lower()
        if "is running" in low or "running" in low:
            return "running"
        if "is paused" in low or "paused" in low:
            return "paused"
        if "is inactive" in low or "inactive" in low:
            return "inactive"
        return "inactive" if res.returncode != 0 else "unknown"
    except Exception:
        return "unknown"


def get_queue_status(site_path: str, php_bin: str = "php") -> dict:
    """Retrieve queue status, failed jobs, pending jobs, and per-queue counts via a single PHP run."""
    path = Path(site_path).resolve()
    artisan = path / "artisan"
    if not artisan.is_file():
        return {
            "ok": False,
            "error": "artisan not found in project directory",
            "error_type": "no_artisan",
            "failed_jobs": [],
            "failed_count": 0,
            "pending_jobs": [],
            "pending_count": 0,
            "queue_counts": {},
        }

    script = """
        $failedJobs = [];
        $pendingJobs = [];
        $queueCounts = [];

        // 1. Failed jobs
        if ($app->bound('queue.failer')) {
            $failer = $app->make('queue.failer');
            if ($failer && method_exists($failer, 'all')) {
                $rawFailed = $failer->all();
                foreach ($rawFailed as $f) {
                    $fArr = (array)$f;
                    $payload = isset($fArr['payload']) ? (json_decode($fArr['payload'], true) ?: []) : [];
                    $cls = $payload['displayName'] ?? ($payload['job'] ?? ($fArr['class'] ?? 'Job'));
                    $exc = (string)($fArr['exception'] ?? '');
                    $excLines = explode("\\n", $exc);
                    $failedJobs[] = [
                        'id' => (string)($fArr['id'] ?? ($fArr['uuid'] ?? '')),
                        'uuid' => (string)($fArr['uuid'] ?? ($fArr['id'] ?? '')),
                        'connection' => (string)($fArr['connection'] ?? 'default'),
                        'queue' => (string)($fArr['queue'] ?? 'default'),
                        'class' => (string)$cls,
                        'failed_at' => (string)($fArr['failed_at'] ?? ''),
                        'exception_short' => (string)(isset($excLines[0]) ? trim($excLines[0]) : ''),
                        'exception' => $exc,
                        'payload' => $payload,
                    ];
                }
            }
        }

        // 2. Pending jobs & Queue sizes
        $defaultConn = config('queue.default', 'sync');
        $driver = config("queue.connections.{$defaultConn}.driver", $defaultConn);

        if ($driver === 'database' || \\Illuminate\\Support\\Facades\\Schema::hasTable('jobs')) {
            try {
                if (\\Illuminate\\Support\\Facades\\Schema::hasTable('jobs')) {
                    $rows = \\Illuminate\\Support\\Facades\\DB::table('jobs')->orderBy('id', 'asc')->limit(50)->get();
                    foreach ($rows as $j) {
                        $payload = json_decode($j->payload, true) ?: [];
                        $name = $payload['displayName'] ?? ($payload['job'] ?? 'Job');
                        $pendingJobs[] = [
                            'id' => (string)$j->id,
                            'queue' => (string)$j->queue,
                            'attempts' => (int)$j->attempts,
                            'available_at' => isset($j->available_at) ? date('Y-m-d H:i:s', $j->available_at) : '',
                            'created_at' => isset($j->created_at) ? date('Y-m-d H:i:s', $j->created_at) : '',
                            'class' => $name,
                            'payload' => $payload,
                        ];
                    }
                    $counts = \\Illuminate\\Support\\Facades\\DB::table('jobs')
                        ->select('queue', \\Illuminate\\Support\\Facades\\DB::raw('count(*) as count'))
                        ->groupBy('queue')
                        ->get();
                    foreach ($counts as $c) {
                        $queueCounts[$c->queue] = (int)$c->count;
                    }
                }
            } catch (\\Throwable $e) {}
        } elseif ($driver === 'redis') {
            try {
                $queues = [config("queue.connections.{$defaultConn}.queue", 'default')];
                foreach ($queues as $q) {
                    $queueCounts[$q] = (int)\\Illuminate\\Support\\Facades\\Queue::size($q);
                }
            } catch (\\Throwable $e) {}
        }

        return [
            'failed_jobs' => $failedJobs,
            'pending_jobs' => $pendingJobs,
            'queue_counts' => $queueCounts,
        ];
    """

    res = run_php_json(path, php_bin=php_bin, script=script, timeout=8)
    if not res.get("ok"):
        return {
            "ok": False,
            "error": res.get("error") or "Queue query failed",
            "error_type": res.get("error_type", "error"),
            "failed_jobs": [],
            "failed_count": 0,
            "pending_jobs": [],
            "pending_count": 0,
            "queue_counts": {},
        }

    data = res.get("data") or {}
    failed = data.get("failed_jobs") or []
    pending = data.get("pending_jobs") or []
    counts = data.get("queue_counts") or {}

    return {
        "ok": True,
        "error": None,
        "failed_jobs": failed,
        "failed_count": len(failed),
        "pending_jobs": pending,
        "pending_count": len(pending),
        "queue_counts": counts,
    }


def retry_failed_job(site_path: str, php_bin: str = "php", job_id: str = "all") -> dict:
    """Retry a failed job by ID or UUID, or 'all' to retry every failed job."""
    path = Path(site_path).resolve()
    resolved_php = shutil.which(php_bin) or php_bin

    target = "all" if str(job_id).lower() in ("all", "*") else str(job_id).strip()
    try:
        proc = subprocess.run(
            [resolved_php, "artisan", "queue:retry", target],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=15,
        )
        return {
            "ok": proc.returncode == 0,
            "output": strip_ansi(proc.stdout).strip(),
            "error": strip_ansi(proc.stderr).strip(),
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc), "output": ""}


def forget_failed_job(site_path: str, php_bin: str = "php", job_id: str = "all") -> dict:
    """Delete a failed job from the queue, or 'all' to flush the entire failed jobs table."""
    path = Path(site_path).resolve()
    resolved_php = shutil.which(php_bin) or php_bin

    if str(job_id).lower() in ("all", "flush"):
        argv = [resolved_php, "artisan", "queue:flush"]
    else:
        argv = [resolved_php, "artisan", "queue:forget", str(job_id).strip()]

    try:
        proc = subprocess.run(
            argv,
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=15,
        )
        return {
            "ok": proc.returncode == 0,
            "output": strip_ansi(proc.stdout).strip(),
            "error": strip_ansi(proc.stderr).strip(),
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc), "output": ""}


def clear_pending_jobs(site_path: str, php_bin: str = "php", job_id: str = "all") -> dict:
    """Clear/delete pending jobs from the database queue table."""
    path = Path(site_path).resolve()
    script = f"""
        if (\\Illuminate\\Support\\Facades\\Schema::hasTable('jobs')) {{
            if ('{job_id}' === 'all') {{
                \\Illuminate\\Support\\Facades\\DB::table('jobs')->truncate();
                return ['deleted' => 'all'];
            }} else {{
                $d = \\Illuminate\\Support\\Facades\\DB::table('jobs')->where('id', '{job_id}')->delete();
                return ['deleted' => $d];
            }}
        }}
        return ['deleted' => 0, 'error' => 'No jobs table found'];
    """
    res = run_php_json(path, php_bin=php_bin, script=script, timeout=10)
    if not res.get("ok"):
        return {"ok": False, "error": res.get("error") or "Failed to clear pending jobs"}
    return {"ok": True, "output": "Pending jobs cleared successfully"}



# ── Scheduled Tasks & Cron Dashboard ─────────────────────────────────────────

def get_schedule_list(site_path: str, php_bin: str = "php") -> dict:
    """Fetch scheduled tasks from Laravel's Schedule instance using run_php_json."""
    path = Path(site_path).resolve()
    script = """
        $schedule = $app->make(\\Illuminate\\Console\\Scheduling\\Schedule::class);
        $events = $schedule->events();
        $tasks = [];

        foreach ($events as $idx => $event) {
            $desc = (string)($event->description ?? '');
            $type = 'command';
            $command = '';

            if ($event instanceof \\Illuminate\\Console\\Scheduling\\CallbackEvent) {
                if (!empty($desc) && (class_exists($desc) || str_contains($desc, 'Job'))) {
                    $type = 'job';
                } else {
                    $type = 'closure';
                }
                $command = $desc ?: ($type === 'job' ? 'Job' : 'Closure');
            } else {
                $type = 'command';
                $rawCmd = (string)($event->command ?? '');
                // Same replacement schedule:list does, then drop the leading "php artisan".
                $normalized = str_replace(
                    [\\Illuminate\\Console\\Application::phpBinary(), \\Illuminate\\Console\\Application::artisanBinary()],
                    ['php', 'artisan'],
                    $rawCmd
                );
                $normalized = preg_replace('/^php\\s+artisan\\s+/', '', trim($normalized));
                $command = $normalized;
                if (empty($desc)) {
                    $desc = $command;
                }
            }

            $tz = $event->timezone ?? config('app.timezone', 'UTC');
            $nextDue = '';
            try {
                if (method_exists($event, 'nextRunDate')) {
                    $nextDue = $event->nextRunDate()->setTimezone($tz)->format('Y-m-d H:i:s');
                }
            } catch (\\Throwable $e) {}

            $withoutOverlapping = !empty($event->withoutOverlapping);
            $hasMutex = $withoutOverlapping;

            $isLocked = false;
            try {
                if ($withoutOverlapping && isset($event->mutex)) {
                    $isLocked = $event->mutex->exists($event);
                }
            } catch (\\Throwable $e) {}

            $canRun = true;
            $runReason = '';
            if ($isLocked) {
                $canRun = false;
                $runReason = 'Task is currently running (mutex locked)';
            }

            $tasks[] = [
                'index' => $idx,
                'expression' => (string)$event->expression,
                'cron' => (string)$event->expression,
                'command' => $command,
                'description' => $desc,
                'type' => $type,
                'next_due' => $nextDue,
                'timezone' => (string)$tz,
                'without_overlapping' => $withoutOverlapping,
                'has_mutex' => $hasMutex,
                'can_run' => $canRun,
                'run_reason' => $runReason,
            ];
        }

        return $tasks;
    """
    res = run_php_json(path, php_bin=php_bin, script=script, timeout=8)
    if not res.get("ok"):
        return {
            "ok": False,
            "error": res.get("error") or "Failed to load schedule",
            "error_type": res.get("error_type", "error"),
            "tasks": [],
            "count": 0,
        }
    tasks = res.get("data") or []

    # Parse last run status and duration from schedule log (Task 4.12)
    s_name = path.name
    log_file = Path.home() / ".local" / "log" / "laravel-dev" / f"laravel-dev-{s_name}-schedule.log"
    last_runs = {}
    if log_file.is_file():
        try:
            with open(log_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - 65536))
                lines = f.read().decode("utf-8", errors="replace").splitlines()
            run_pattern = re.compile(r"(?:\[([0-9: -]+)\]\s+)?Running\s+\[?(?:'artisan'\s+)?([^\]]+)\]?\s*\.{2,}\s*([0-9.]+\s*m?s)\s*(DONE|FAIL)", re.IGNORECASE)
            for line in lines:
                m = run_pattern.search(line)
                if m:
                    dt, cmd, dur, status = m.groups()
                    cmd_norm = cmd.strip().strip("'\"")
                    last_runs[cmd_norm] = {
                        "time": dt or "",
                        "duration": dur.strip(),
                        "status": status.upper(),
                    }
        except Exception:
            pass

    for t in tasks:
        cmd = (t.get("command") or "").strip().strip("'\"")
        lr = last_runs.get(cmd)
        if not lr:
            for k, v in last_runs.items():
                if k in cmd or cmd in k:
                    lr = v
                    break
        t["last_run"] = lr

    return {"ok": True, "error": None, "tasks": tasks, "count": len(tasks)}


def run_scheduled_task(
    site_path: str,
    php_bin: str = "php",
    command: str = "",
    task_index: int | str | None = None,
) -> dict:
    """Execute a scheduled task by index or command, or run all due tasks with `schedule:run`."""
    path = Path(site_path).resolve()
    resolved_php = shutil.which(php_bin) or php_bin

    # If task_index is provided, execute the specific schedule event via PHP
    if task_index is not None and str(task_index).strip() != "":
        try:
            idx = int(task_index)
        except ValueError:
            idx = 0
        script = f"""
            $schedule = $app->make(\\Illuminate\\Console\\Scheduling\\Schedule::class);
            $events = $schedule->events();
            $idx = {idx};
            if (!isset($events[$idx])) {{
                throw new \\RuntimeException("Scheduled task #$idx not found.");
            }}
            $event = $events[$idx];
            // Command events write to /dev/null unless told otherwise, and report failure only via exitCode.
            $tmp = tempnam(sys_get_temp_dir(), 'ld-sched');
            if (!($event instanceof \\Illuminate\\Console\\Scheduling\\CallbackEvent)) {{
                $event->sendOutputTo($tmp);
            }}
            ob_start();
            try {{
                $event->run($app);
            }} finally {{
                $out = ob_get_clean() . (is_file($tmp) ? file_get_contents($tmp) : '');
                @unlink($tmp);
            }}
            if (!empty($event->exitCode)) {{
                throw new \\RuntimeException("Task exited with code {{$event->exitCode}}: " . trim($out));
            }}
            return [
                'output' => trim($out) ?: 'Task completed successfully (no terminal output).'
            ];
        """
        res = run_php_json(path, php_bin=php_bin, script=script, timeout=300)
        if res.get("ok"):
            data = res.get("data") or {}
            return {
                "ok": True,
                "output": data.get("output", "Task completed."),
                "error": "",
                "duration_ms": res.get("duration_ms", 0),
            }
        else:
            return {
                "ok": False,
                "output": "",
                "error": res.get("error") or "Task execution failed.",
                "duration_ms": res.get("duration_ms", 0),
            }

    # Otherwise run via artisan CLI (e.g. schedule:run or normalized artisan command)
    cmd_clean = (command or "").strip()
    if not cmd_clean or cmd_clean == "schedule:run":
        argv = [resolved_php, "artisan", "schedule:run"]
    else:
        parts = shlex.split(cmd_clean)
        # Strip redundant "php" and "artisan" tokens
        while (parts and parts[0] in ("php", "artisan")) or (parts and parts[0].endswith("artisan")):
            parts = parts[1:]
        if not parts:
            argv = [resolved_php, "artisan", "schedule:run"]
        else:
            argv = [resolved_php, "artisan", *parts]

    start_time = time.perf_counter()
    try:
        proc = subprocess.run(
            argv,
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=300,
        )
        duration_ms = round((time.perf_counter() - start_time) * 1000, 1)
        return {
            "ok": proc.returncode == 0,
            "output": strip_ansi(proc.stdout).strip(),
            "error": strip_ansi(proc.stderr).strip(),
            "duration_ms": duration_ms,
        }
    except subprocess.TimeoutExpired:
        return {
            "ok": False,
            "error": "Task execution timed out after 300 seconds.",
            "duration_ms": 300000,
            "output": "",
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc), "duration_ms": 0, "output": ""}


# ── Interactive Routes Explorer ───────────────────────────────────────────────

_ROUTES_CACHE: dict[str, tuple[float, list]] = {}


def get_routes(site_path: str, php_bin: str = "php", force: bool = False) -> dict:
    """Retrieve full routes list with HTTP methods, uri, name, action, middleware, and source file:line."""
    canon_path = str(Path(site_path).resolve())
    now = time.time()

    if not force and canon_path in _ROUTES_CACHE:
        cached_time, cached_routes = _ROUTES_CACHE[canon_path]
        if now - cached_time < 60:
            return {"ok": True, "routes": cached_routes, "cached": True}

    script = """
    $routes = [];
    $router = $app->make('router');
    foreach ($router->getRoutes() as $route) {
        $action = $route->getActionName();
        $file = null;
        $line = null;
        if ($action && is_string($action) && strpos($action, '@') !== false) {
            [$class, $method] = explode('@', $action, 2);
            if (class_exists($class) && method_exists($class, $method)) {
                try {
                    $ref = new ReflectionMethod($class, $method);
                    $file = $ref->getFileName();
                    $line = $ref->getStartLine();
                } catch (Throwable $e) {}
            }
        } elseif ($action && is_string($action) && class_exists($action)) {
            if (method_exists($action, '__invoke')) {
                try {
                    $ref = new ReflectionMethod($action, '__invoke');
                    $file = $ref->getFileName();
                    $line = $ref->getStartLine();
                } catch (Throwable $e) {}
            }
        }
        $methods = array_diff($route->methods(), ['HEAD']);
        $routes[] = [
            'domain' => $route->domain(),
            'method' => implode('|', $methods) ?: 'GET',
            'uri' => $route->uri(),
            'name' => $route->getName() ?: '',
            'action' => is_string($action) ? $action : 'Closure',
            'middleware' => array_values($route->gatherMiddleware() ?: []),
            'file' => $file,
            'line' => $line,
        ];
    }
    return ['routes' => $routes];
    """
    res = run_php_json(site_path, php_bin=php_bin, script=script, timeout=12)
    if res.get("ok") and isinstance(res.get("data"), dict):
        routes = res["data"].get("routes", [])
        _ROUTES_CACHE[canon_path] = (now, routes)
        return {
            "ok": True,
            "routes": routes,
            "duration_ms": res.get("duration_ms", 0),
            "cached": False,
        }

    # Fallback to artisan route:list --json
    path = Path(site_path).resolve()
    artisan = path / "artisan"
    if artisan.is_file():
        try:
            resolved_php = shutil.which(php_bin) or php_bin
            cmd = [resolved_php, str(artisan), "route:list", "--json"]
            proc = subprocess.run(cmd, cwd=str(path), capture_output=True, text=True, timeout=12)
            if proc.returncode == 0:
                raw_routes = json.loads(proc.stdout)
                routes = []
                for r in raw_routes:
                    routes.append({
                        "domain": r.get("domain"),
                        "method": r.get("method") or "GET",
                        "uri": r.get("uri") or "",
                        "name": r.get("name") or "",
                        "action": r.get("action") or "",
                        "middleware": r.get("middleware") or [],
                        "file": None,
                        "line": None,
                    })
                _ROUTES_CACHE[canon_path] = (now, routes)
                return {"ok": True, "routes": routes, "duration_ms": 0, "cached": False}
        except Exception:
            pass

    return {"ok": False, "error": res.get("error") or "Failed to load routes", "routes": []}


# ── Artisan Command Autocompletion ───────────────────────────────────────────

_ARTISAN_COMMANDS_CACHE: dict[str, tuple[float, list[dict]]] = {}


def get_artisan_commands(site_path: str, php_bin: str = "php") -> list[dict]:
    """Retrieve full list of available Artisan commands with descriptions, cached by composer.lock mtime."""
    path = Path(site_path).resolve()
    artisan = path / "artisan"
    if not artisan.is_file():
        return []

    lock_file = path / "composer.lock"
    current_mtime = lock_file.stat().st_mtime if lock_file.is_file() else 0.0

    canon_path = str(path)
    if canon_path in _ARTISAN_COMMANDS_CACHE:
        cached_mtime, cached_cmds = _ARTISAN_COMMANDS_CACHE[canon_path]
        if cached_mtime == current_mtime:
            return cached_cmds

    resolved_php = shutil.which(php_bin) or php_bin
    argv = [resolved_php, str(artisan), "list", "--format=json"]
    try:
        proc = subprocess.run(argv, cwd=str(path), capture_output=True, text=True, timeout=10)
        if proc.returncode == 0 and proc.stdout:
            data = json.loads(proc.stdout)
            raw_cmds = data.get("commands") or []
            commands = []
            for c in raw_cmds:
                name = c.get("name")
                if name and not name.startswith("_"):
                    commands.append({
                        "name": name,
                        "description": c.get("description") or "",
                        "synopsis": c.get("synopsis") or "",
                    })
            _ARTISAN_COMMANDS_CACHE[canon_path] = (current_mtime, commands)
            return commands
    except Exception:
        pass

    return _ARTISAN_COMMANDS_CACHE.get(canon_path, (0.0, []))[1]


# ── Health Diagnostics & Doctor ───────────────────────────────────────────────

def check_site_health(site_path: str, php_bin: str = "php") -> list[dict]:
    """Perform comprehensive health diagnostics on a Laravel project."""
    path = Path(site_path).resolve()
    checks = []

    # 1. Environment & APP_KEY
    env_file = path / ".env"
    example_file = path / ".env.example"
    env_data = {}
    if not env_file.is_file():
        checks.append({
            "id": "env_exists",
            "name": "Environment File (.env)",
            "status": "fail",
            "message": ".env file is missing in project root.",
            "fix_action": None,
            "fix_params": {},
            "fix_label": None,
        })
    else:
        try:
            import envfile
            env_data = envfile.to_dict(env_file.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            pass

        app_key = env_data.get("APP_KEY", "").strip()
        if not app_key:
            checks.append({
                "id": "app_key",
                "name": "Application Key",
                "status": "fail",
                "message": "APP_KEY is missing or empty. Encryption and sessions will fail.",
                "fix_action": "artisan",
                "fix_params": {"args": "key:generate"},
                "fix_label": "Generate Key",
            })
        else:
            checks.append({
                "id": "app_key",
                "name": "Application Key",
                "status": "ok",
                "message": "APP_KEY is properly configured.",
                "fix_action": None,
                "fix_params": {},
                "fix_label": None,
            })

        # Missing keys compared to .env.example
        if example_file.is_file():
            try:
                import envfile
                example_data = envfile.to_dict(example_file.read_text(encoding="utf-8", errors="replace"))
                missing_keys = [k for k in example_data if k not in env_data]
                if missing_keys:
                    checks.append({
                        "id": "env_missing_keys",
                        "name": "Environment Variables",
                        "status": "warn",
                        "message": f"{len(missing_keys)} key(s) from .env.example are missing in .env ({', '.join(missing_keys[:3])}{'…' if len(missing_keys) > 3 else ''}).",
                        "fix_action": None,
                        "fix_params": {},
                        "fix_label": None,
                    })
                else:
                    checks.append({
                        "id": "env_missing_keys",
                        "name": "Environment Variables",
                        "status": "ok",
                        "message": "All keys from .env.example are defined.",
                        "fix_action": None,
                        "fix_params": {},
                        "fix_label": None,
                    })
            except Exception:
                pass

    # 2. Storage Symlink
    storage_link = path / "public" / "storage"
    if not storage_link.exists() and not storage_link.is_symlink():
        checks.append({
            "id": "storage_link",
            "name": "Storage Symlink (public/storage)",
            "status": "warn",
            "message": "public/storage link is missing. Uploaded files will not be accessible publicly.",
            "fix_action": "artisan",
            "fix_params": {"args": "storage:link"},
            "fix_label": "Link Storage",
        })
    else:
        checks.append({
            "id": "storage_link",
            "name": "Storage Symlink",
            "status": "ok",
            "message": "public/storage symlink is properly linked.",
            "fix_action": None,
            "fix_params": {},
            "fix_label": None,
        })

    # 3. Directory Permissions
    crit_dirs = [
        path / "storage",
        path / "storage" / "framework",
        path / "storage" / "logs",
        path / "bootstrap" / "cache",
    ]
    unwritable = [str(d.relative_to(path)) for d in crit_dirs if d.is_dir() and not os.access(d, os.W_OK)]
    if unwritable:
        checks.append({
            "id": "permissions",
            "name": "Directory Permissions",
            "status": "fail",
            "message": f"Write permissions missing for: {', '.join(unwritable)}",
            "fix_action": None,
            "fix_params": {},
            "fix_label": None,
        })
    else:
        checks.append({
            "id": "permissions",
            "name": "Directory Permissions",
            "status": "ok",
            "message": "storage/ and bootstrap/cache/ directories are writable.",
            "fix_action": None,
            "fix_params": {},
            "fix_label": None,
        })

    # 4. Vendor & Composer dependencies
    autoload = path / "vendor" / "autoload.php"
    lock_file = path / "composer.lock"
    if not autoload.is_file():
        checks.append({
            "id": "composer_vendor",
            "name": "Composer Dependencies",
            "status": "fail",
            "message": "vendor/autoload.php not found.",
            "fix_action": "composer",
            "fix_params": {"cmd": "install"},
            "fix_label": "Run Composer Install",
        })
    elif lock_file.is_file() and lock_file.stat().st_mtime > autoload.stat().st_mtime:
        checks.append({
            "id": "composer_vendor",
            "name": "Composer Dependencies",
            "status": "warn",
            "message": "composer.lock is newer than vendor/autoload.php. Dependencies may be outdated.",
            "fix_action": "composer",
            "fix_params": {"cmd": "install"},
            "fix_label": "Run Composer Install",
        })
    else:
        checks.append({
            "id": "composer_vendor",
            "name": "Composer Dependencies",
            "status": "ok",
            "message": "vendor/ dependencies installed and up to date.",
            "fix_action": None,
            "fix_params": {},
            "fix_label": None,
        })

    # Node modules
    pkg_file = path / "package.json"
    modules_dir = path / "node_modules"
    if pkg_file.is_file() and not modules_dir.is_dir():
        checks.append({
            "id": "node_modules",
            "name": "Node / Frontend Modules",
            "status": "warn",
            "message": "package.json exists but node_modules/ is missing.",
            "fix_action": None,
            "fix_params": {},
            "fix_label": None,
        })

    # 5. Config/Route cache
    cached_config = path / "bootstrap" / "cache" / "config.php"
    cached_routes = path / "bootstrap" / "cache" / "routes-v7.php"
    if cached_config.is_file() or cached_routes.is_file():
        checks.append({
            "id": "cache_files",
            "name": "Configuration & Route Cache",
            "status": "warn",
            "message": "Configuration or routes are cached. Changes in .env or routes won't take effect until cleared.",
            "fix_action": "artisan",
            "fix_params": {"args": "optimize:clear"},
            "fix_label": "Clear Caches",
        })
    else:
        checks.append({
            "id": "cache_files",
            "name": "Configuration & Route Cache",
            "status": "ok",
            "message": "No stale configuration or route caches detected.",
            "fix_action": None,
            "fix_params": {},
            "fix_label": None,
        })

    # 6. Database Connection & Pending Migrations
    spec = get_site_db_spec(path)
    if spec:
        db_driver = spec.get("driver")
        db_connected = False
        try:
            if db_driver == "sqlite":
                sf = Path(spec.get("file", ""))
                db_connected = sf.is_file()
            else:
                from database import DatabaseManager
                mgr = DatabaseManager()
                conn = mgr._connect(spec)
                conn.close()
                db_connected = True
        except Exception as exc:
            checks.append({
                "id": "database_connection",
                "name": "Database Connection",
                "status": "fail",
                "message": f"Connection failed to {db_driver}: {exc}",
                "fix_action": None,
                "fix_params": {},
                "fix_label": None,
            })

        if db_connected:
            checks.append({
                "id": "database_connection",
                "name": "Database Connection",
                "status": "ok",
                "message": f"Successfully connected to {db_driver} ({spec.get('database') or (Path(spec.get('file', '')).name if spec.get('file') else 'sqlite')}).",
                "fix_action": None,
                "fix_params": {},
                "fix_label": None,
            })

            # Check migrations table vs migration files
            mig_dir = path / "database" / "migrations"
            if mig_dir.is_dir():
                mig_files = sorted([f.stem for f in mig_dir.glob("*.php")])
                applied_migs = set()
                try:
                    if db_driver == "sqlite":
                        conn = sqlite3.connect(str(Path(spec.get("file", ""))))
                        cur = conn.cursor()
                        cur.execute("SELECT migration FROM migrations")
                        applied_migs = {r[0] for r in cur.fetchall()}
                        conn.close()
                    else:
                        from database import DatabaseManager
                        mgr = DatabaseManager()
                        conn = mgr._connect(spec)
                        cur = conn.cursor()
                        cur.execute("SELECT migration FROM migrations")
                        applied_migs = {r[0] for r in cur.fetchall()}
                        conn.close()

                    pending = [m for m in mig_files if m not in applied_migs]
                    if pending:
                        checks.append({
                            "id": "migrations",
                            "name": "Database Migrations",
                            "status": "warn",
                            "message": f"{len(pending)} pending migration(s) waiting to run.",
                            "fix_action": "artisan",
                            "fix_params": {"args": "migrate"},
                            "fix_label": "Run Migrations",
                        })
                    else:
                        checks.append({
                            "id": "migrations",
                            "name": "Database Migrations",
                            "status": "ok",
                            "message": f"All {len(applied_migs)} migrations are up to date.",
                            "fix_action": None,
                            "fix_params": {},
                            "fix_label": None,
                        })
                except Exception:
                    pass

    # 7. Supervisor Worker Permission Check
    conf_dir = Path("/etc/supervisor/conf.d")
    if conf_dir.is_dir():
        for conf_file in conf_dir.glob(f"laravel-dev-{path.name}*.conf"):
            try:
                text = conf_file.read_text(encoding="utf-8", errors="replace")
                if re.search(r"^\s*user\s*=\s*root\b", text, re.MULTILINE):
                    checks.append({
                        "id": "supervisor_root",
                        "name": "Queue Worker User (Root Warning)",
                        "status": "warn",
                        "message": f"Worker in {conf_file.name} is configured to run as root. Storage files may become inaccessible.",
                        "fix_action": "worker-setup",
                        "fix_params": {"site": path.name},
                        "fix_label": "Recreate Worker",
                    })
                    break
            except Exception:
                pass

    return checks


def heal_site(site_path: str, php_bin: str = "php") -> dict:
    """Automatically fix common project configuration issues in one click."""
    path = Path(site_path).resolve()
    resolved_php = shutil.which(php_bin) or php_bin
    healed = []

    # 1. Fix directory permissions
    crit_dirs = [
        path / "storage",
        path / "storage" / "framework",
        path / "storage" / "framework" / "cache",
        path / "storage" / "framework" / "sessions",
        path / "storage" / "framework" / "views",
        path / "storage" / "logs",
        path / "bootstrap" / "cache",
    ]
    for d in crit_dirs:
        d.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(str(d), 0o775)
        except Exception:
            pass
    healed.append("Permissions fixed (storage & cache writable)")

    # 2. Key generate if missing
    env_file = path / ".env"
    if env_file.is_file():
        txt = env_file.read_text(encoding="utf-8", errors="replace")
        if "APP_KEY=" in txt and ("APP_KEY=\n" in txt or "APP_KEY=\r" in txt or txt.endswith("APP_KEY=")):
            subprocess.run([resolved_php, "artisan", "key:generate", "--force"], cwd=str(path), capture_output=True)
            healed.append("Application key generated")

    # 3. Storage link
    storage_link = path / "public" / "storage"
    if not storage_link.exists() and not storage_link.is_symlink() and (path / "artisan").is_file():
        subprocess.run([resolved_php, "artisan", "storage:link"], cwd=str(path), capture_output=True)
        healed.append("public/storage symlink created")

    # 4. Sync missing .env.example keys
    example_file = path / ".env.example"
    if env_file.is_file() and example_file.is_file():
        try:
            import envfile
            env_data = envfile.to_dict(env_file.read_text(encoding="utf-8", errors="replace"))
            example_data = envfile.to_dict(example_file.read_text(encoding="utf-8", errors="replace"))
            missing = [f"{k}={v}" for k, v in example_data.items() if k not in env_data]
            if missing:
                with open(env_file, "a", encoding="utf-8") as f:
                    f.write("\n# Added by Laravel Dev Auto-Heal\n" + "\n".join(missing) + "\n")
                healed.append(f"{len(missing)} missing .env keys synchronized")
        except Exception:
            pass

    # 5. Clear caches
    if (path / "artisan").is_file():
        subprocess.run([resolved_php, "artisan", "optimize:clear"], cwd=str(path), capture_output=True)
        healed.append("Framework caches cleared")

    return {"ok": True, "healed": healed}



# ── Backups, Snapshots & Deploy Targets Engine ───────────────────────────────

CUSTOM_NAME_RE = re.compile(r"^[A-Za-z0-9._-]+$")


def fmt_bytes(size: int) -> str:
    """Format bytes into a human-readable string (KB, MB, GB)."""
    s = float(size)
    for unit in ["B", "KB", "MB", "GB"]:
        if s < 1024.0:
            return f"{s:.1f} {unit}" if unit != "B" else f"{int(s)} B"
        s /= 1024.0
    return f"{s:.1f} TB"


def get_dir_size(path: Path) -> int:
    """Recursively calculate directory size in bytes without following symlinks."""
    total = 0
    if not path.is_dir():
        return 0
    try:
        for root, dirs, files in os.walk(path, followlinks=False):
            for f in files:
                try:
                    fp = os.path.join(root, f)
                    if not os.path.islink(fp):
                        total += os.path.getsize(fp)
                except OSError:
                    pass
    except OSError:
        pass
    return total


def estimate_db_size(site_path: Path, spec: dict | None) -> int:
    """Estimate database size in bytes."""
    if not spec:
        return 0
    driver = spec.get("driver")
    if driver == "sqlite":
        sqlite_file = Path(spec.get("file") or site_path / "database" / "database.sqlite")
        if sqlite_file.is_file():
            try:
                return sqlite_file.stat().st_size
            except OSError:
                return 0
        return 0
    if driver in ("mysql", "mariadb"):
        try:
            from database import DatabaseManager
            mgr = DatabaseManager()
            conn = mgr._connect(spec)
            cur = conn.cursor()
            cur.execute("""
                SELECT COALESCE(SUM(data_length + index_length), 0)
                FROM information_schema.tables
                WHERE table_schema = %s
            """, (spec.get("database"),))
            row = cur.fetchone()
            cur.close()
            conn.close()
            if row and row[0]:
                return int(row[0])
        except Exception:
            return 0
    if driver in ("pgsql", "postgres", "postgresql"):
        try:
            from database import DatabaseManager
            mgr = DatabaseManager()
            conn = mgr._connect(spec)
            cur = conn.cursor()
            cur.execute("SELECT pg_database_size(%s)", (spec.get("database"),))
            row = cur.fetchone()
            cur.close()
            conn.close()
            if row and row[0]:
                return int(row[0])
        except Exception:
            return 0
    return 0


def estimate_backup(site_path: str) -> dict:
    """Calculate expected storage, database, and total backup sizes for display."""
    path = Path(site_path).resolve()
    spec = get_site_db_spec(path)
    storage_path = path / "storage" / "app" / "public"
    storage_bytes = get_dir_size(storage_path)
    db_bytes = estimate_db_size(path, spec)
    total_bytes = storage_bytes + db_bytes
    return {
        "storage_bytes": storage_bytes,
        "storage_human": fmt_bytes(storage_bytes),
        "db_bytes": db_bytes,
        "db_human": fmt_bytes(db_bytes),
        "total_bytes": total_bytes,
        "total_human": fmt_bytes(total_bytes),
    }


def get_backups_dir(site_path: str, create: bool = False) -> Path:
    bdir = Path(site_path) / "storage" / "app" / "backups"
    if create:
        bdir.mkdir(parents=True, exist_ok=True)
    return bdir


def get_site_db_spec(site_path: Path) -> dict | None:
    """Read and parse the site's database connection spec from .env."""
    env_file = site_path / ".env"
    if not env_file.is_file():
        return None
    try:
        import envfile
        import database
        env_data = envfile.to_dict(env_file.read_text(encoding="utf-8", errors="replace"))
        return database.spec_from_env(env_data, str(site_path))
    except Exception:
        return None


def get_spec_tables(spec: dict | None) -> list[str]:
    """Retrieve list of table names for database manifest."""
    if not spec:
        return []
    driver = spec.get("driver")
    if driver == "sqlite":
        f = Path(spec.get("file", ""))
        if f.is_file():
            try:
                conn = sqlite3.connect(str(f))
                cur = conn.cursor()
                cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
                tables = [r[0] for r in cur.fetchall()]
                conn.close()
                return sorted(tables)
            except Exception:
                return []
        return []
    try:
        from database import DatabaseManager
        mgr = DatabaseManager()
        tables_info = mgr.tables(spec)
        return sorted(t["name"] for t in tables_info)
    except Exception:
        return []


def list_backups(site_path: str) -> list[dict]:
    """Scan and list all backup snapshots for a project without creating directory if missing."""
    bdir = get_backups_dir(site_path, create=False)
    if not bdir.is_dir():
        return []

    results = []
    for f in bdir.glob("*"):
        if f.is_file() and (f.name.endswith(".tar.gz") or f.name.endswith(".sql.gz") or f.name.endswith(".sql")):
            try:
                st = f.stat()
                name = f.name
                btype = "full" if "full" in name else "db" if ("db" in name or name.endswith(".sql") or name.endswith(".sql.gz")) else "storage"
                manifest_info = None

                # Extract manifest metadata if present in tar archive
                if name.endswith(".tar.gz") or name.endswith(".tar"):
                    try:
                        with tarfile.open(f, "r:*") as tar:
                            if "manifest.json" in tar.getnames():
                                mf = tar.extractfile("manifest.json")
                                if mf:
                                    mdata = json.loads(mf.read().decode("utf-8"))
                                    btype = mdata.get("type", btype)
                                    manifest_info = {
                                        "db_driver": mdata.get("db_driver"),
                                        "db_name": mdata.get("db_name"),
                                        "tables": mdata.get("tables") or [],
                                    }
                    except Exception:
                        pass

                results.append({
                    "filename": name,
                    "path": str(f),
                    "size_bytes": st.st_size,
                    "size_human": fmt_bytes(st.st_size),
                    "created_at": datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                    "type": btype,
                    "manifest": manifest_info,
                })
            except OSError:
                pass
    results.sort(key=lambda x: x["created_at"], reverse=True)
    return results


def delete_backup(site_path: str, filename: str) -> dict:
    """Delete a specific backup file."""
    bdir = get_backups_dir(site_path, create=False)
    if not bdir.is_dir():
        return {"ok": False, "error": "Backups directory does not exist"}
    target = (bdir / filename).resolve()
    if target.parent != bdir.resolve():
        return {"ok": False, "error": "Invalid backup filename"}
    if target.is_file():
        target.unlink()
        return {"ok": True, "message": f"Deleted {filename}"}
    return {"ok": False, "error": "Backup file not found"}


def _drain_proc_to_file(proc, out_file, check_cancel_fn=None):
    """Drain proc.stdout to file while draining stderr concurrently in a daemon thread to prevent pipe deadlock."""
    stderr_chunks = []

    def _read_err():
        while True:
            chunk = proc.stderr.read(4096)
            if not chunk:
                break
            stderr_chunks.append(chunk)

    t = threading.Thread(target=_read_err, daemon=True)
    t.start()

    while True:
        if check_cancel_fn:
            check_cancel_fn()
        chunk = proc.stdout.read(65536)
        if not chunk:
            break
        out_file.write(chunk)

    proc.wait()
    t.join(timeout=3)
    err = b"".join(stderr_chunks).decode("utf-8", errors="replace").strip()
    return proc.returncode, err


def _drain_proc_to_bytes(proc, check_cancel_fn=None):
    """Drain proc.stdout to bytes while draining stderr concurrently in a daemon thread to prevent pipe deadlock."""
    stdout_chunks = []
    stderr_chunks = []

    def _read_err():
        while True:
            chunk = proc.stderr.read(4096)
            if not chunk:
                break
            stderr_chunks.append(chunk)

    t = threading.Thread(target=_read_err, daemon=True)
    t.start()

    while True:
        if check_cancel_fn:
            check_cancel_fn()
        chunk = proc.stdout.read(65536)
        if not chunk:
            break
        stdout_chunks.append(chunk)

    proc.wait()
    t.join(timeout=3)
    err = b"".join(stderr_chunks).decode("utf-8", errors="replace").strip()
    return proc.returncode, b"".join(stdout_chunks), err


def create_backup(site_path: str, backup_type: str = "full", custom_name: str = None,
                  log_fn=None, is_cancelled=None) -> dict:
    """Create a high-speed streaming backup snapshot with real database dump support.

    Types:
      - 'db': SQL or SQLite database snapshot compressed directly with gzip
      - 'storage': storage/app uploaded media files
      - 'full': Database + .env + storage + manifest.json in a single .tar.gz
    """
    path = Path(site_path).resolve()
    if custom_name:
        custom_name = custom_name.strip()
        if not CUSTOM_NAME_RE.fullmatch(custom_name):
            return {"ok": False, "error": "Invalid custom name. Only letters, numbers, dashes, dots, and underscores are allowed."}

    bdir = get_backups_dir(site_path, create=True)
    site_name = path.name
    now_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    start_time = time.perf_counter()

    def log(msg: str):
        if log_fn:
            log_fn(f"[backup] {msg}\n")

    def check_cancel(partial_file: Path | None = None, proc: subprocess.Popen | None = None):
        if is_cancelled and is_cancelled():
            if proc and proc.poll() is None:
                try:
                    proc.kill()
                    proc.wait(timeout=1.0)
                except Exception:
                    pass
            if partial_file:
                partial_file.unlink(missing_ok=True)
            log("Backup cancelled by user.")
            raise TaskError("Backup operation cancelled by user.")

    spec = get_site_db_spec(path)

    # 1. Database only backup
    if backup_type == "db":
        out_name = custom_name or f"{site_name}_db_{now_str}.sql.gz"
        if not out_name.endswith(".gz"):
            out_name += ".gz"
        out_path = bdir / out_name

        if not spec:
            return {"ok": False, "error": "No database connection configured in project .env"}

        driver = spec.get("driver")
        log(f"Starting database dump ({driver})...")
        check_cancel(out_path)

        if driver == "sqlite":
            sqlite_file = Path(spec.get("file") or path / "database" / "database.sqlite")
            if not sqlite_file.is_file():
                return {"ok": False, "error": f"SQLite database file not found: {sqlite_file}"}
            try:
                with gzip.open(out_path, "wb") as gz_out:
                    src = sqlite3.connect(str(sqlite_file))
                    for idx, line in enumerate(src.iterdump()):
                        if idx % 1000 == 0:
                            check_cancel(out_path)
                            log(f"Exporting SQLite: {idx} statements...")
                        gz_out.write((line + "\n").encode("utf-8"))
                    src.close()
            except TaskError:
                raise
            except Exception as exc:
                out_path.unlink(missing_ok=True)
                return {"ok": False, "error": f"SQLite dump failed: {exc}"}

        elif driver in ("mysql", "mariadb"):
            tool = shutil.which("mysqldump")
            if not tool:
                return {"ok": False, "error": "mysqldump is not installed. Please install mysql-client or mariadb-client (e.g. sudo apt install default-mysql-client)."}
            env = os.environ.copy()
            env["MYSQL_PWD"] = spec.get("password") or ""
            argv = [
                tool,
                "-h", spec.get("host") or "127.0.0.1",
                "-P", str(spec.get("port") or "3306"),
                "-u", spec.get("user") or "root",
                "--single-transaction",
                "--routines",
                "--triggers",
                "--no-tablespaces",
                spec["database"],
            ]
            try:
                with gzip.open(out_path, "wb") as gz_out:
                    proc = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    rc, err = _drain_proc_to_file(proc, gz_out, lambda: check_cancel(out_path, proc))
                    if rc != 0:
                        out_path.unlink(missing_ok=True)
                        return {"ok": False, "error": f"mysqldump failed: {err}"}
            except TaskError:
                raise
            except Exception as exc:
                out_path.unlink(missing_ok=True)
                return {"ok": False, "error": f"mysqldump execution error: {exc}"}

        elif driver in ("pgsql", "postgres", "postgresql"):
            tool = shutil.which("pg_dump")
            if not tool:
                return {"ok": False, "error": "pg_dump is not installed. Please install postgresql-client (e.g. sudo apt install postgresql-client)."}
            env = os.environ.copy()
            env["PGPASSWORD"] = spec.get("password") or ""
            argv = [
                tool,
                "-h", spec.get("host") or "127.0.0.1",
                "-p", str(spec.get("port") or "5432"),
                "-U", spec.get("user") or "postgres",
                "--no-owner",
                "-d", spec["database"],
            ]
            try:
                with gzip.open(out_path, "wb") as gz_out:
                    proc = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    rc, err = _drain_proc_to_file(proc, gz_out, lambda: check_cancel(out_path, proc))
                    if rc != 0:
                        out_path.unlink(missing_ok=True)
                        return {"ok": False, "error": f"pg_dump failed: {err}"}
            except TaskError:
                raise
            except Exception as exc:
                out_path.unlink(missing_ok=True)
                return {"ok": False, "error": f"pg_dump execution error: {exc}"}
        else:
            return {"ok": False, "error": f"Unsupported database driver: {driver}"}

        st = out_path.stat()
        duration_ms = round((time.perf_counter() - start_time) * 1000, 1)
        log(f"Database dump saved: {out_name} ({fmt_bytes(st.st_size)}) in {duration_ms}ms")
        return {
            "ok": True,
            "filename": out_name,
            "path": str(out_path),
            "size_bytes": st.st_size,
            "size_human": fmt_bytes(st.st_size),
            "duration_ms": duration_ms,
            "type": "db",
        }

    # 2. Storage only backup
    if backup_type == "storage":
        out_name = custom_name or f"{site_name}_storage_{now_str}.tar.gz"
        if not out_name.endswith(".tar.gz"):
            out_name += ".tar.gz"
        out_path = bdir / out_name

        log("Compressing storage/app/public directory...")
        check_cancel(out_path)

        storage_public = path / "storage" / "app" / "public"
        try:
            with tarfile.open(out_path, "w:gz") as tar:
                if storage_public.is_dir():
                    def tar_filter(ti):
                        check_cancel(out_path)
                        return ti
                    tar.add(str(storage_public), arcname="storage/app/public", filter=tar_filter)
        except TaskError:
            raise
        except Exception as exc:
            out_path.unlink(missing_ok=True)
            return {"ok": False, "error": f"Storage backup failed: {exc}"}

        st = out_path.stat()
        duration_ms = round((time.perf_counter() - start_time) * 1000, 1)
        log(f"Storage backup saved: {out_name} ({fmt_bytes(st.st_size)}) in {duration_ms}ms")
        return {
            "ok": True,
            "filename": out_name,
            "path": str(out_path),
            "size_bytes": st.st_size,
            "size_human": fmt_bytes(st.st_size),
            "duration_ms": duration_ms,
            "type": "storage",
        }

    # 3. Full Project Backup (DB + .env + storage + manifest)
    out_name = custom_name or f"{site_name}_full_{now_str}.tar.gz"
    if not out_name.endswith(".tar.gz"):
        out_name += ".tar.gz"
    out_path = bdir / out_name

    driver = spec.get("driver") if spec else "none"
    log("Scanning database tables...")
    check_cancel(out_path)
    tables = get_spec_tables(spec)

    try:
        with tarfile.open(out_path, "w:gz") as tar:
            # Include .env if exists
            env_file = path / ".env"
            if env_file.is_file():
                log("Including .env configuration...")
                tar.add(str(env_file), arcname=".env")

            # Include database dump
            check_cancel(out_path)
            log(f"Creating database dump ({driver})...")
            if driver == "sqlite":
                sqlite_file = Path(spec.get("file") or path / "database" / "database.sqlite")
                if sqlite_file.is_file():
                    tar.add(str(sqlite_file), arcname="database/database.sqlite")
            elif driver in ("mysql", "mariadb"):
                tool = shutil.which("mysqldump")
                if not tool:
                    out_path.unlink(missing_ok=True)
                    return {"ok": False, "error": "mysqldump is not installed. Please install mysql-client or mariadb-client (e.g. sudo apt install default-mysql-client)."}
                env = os.environ.copy()
                env["MYSQL_PWD"] = spec.get("password") or ""
                argv = [
                    tool,
                    "-h", spec.get("host") or "127.0.0.1",
                    "-P", str(spec.get("port") or "3306"),
                    "-u", spec.get("user") or "root",
                    "--single-transaction",
                    "--routines",
                    "--triggers",
                    "--no-tablespaces",
                    spec["database"],
                ]
                proc = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                rc, dump_bytes, dump_err = _drain_proc_to_bytes(proc, lambda: check_cancel(out_path, proc))
                if rc != 0:
                    out_path.unlink(missing_ok=True)
                    return {"ok": False, "error": f"mysqldump failed: {dump_err}"}
                ti = tarfile.TarInfo(name="database/dump.sql")
                ti.size = len(dump_bytes)
                ti.mtime = time.time()
                tar.addfile(ti, io.BytesIO(dump_bytes))

            elif driver in ("pgsql", "postgres", "postgresql"):
                tool = shutil.which("pg_dump")
                if not tool:
                    out_path.unlink(missing_ok=True)
                    return {"ok": False, "error": "pg_dump is not installed. Please install postgresql-client (e.g. sudo apt install postgresql-client)."}
                env = os.environ.copy()
                env["PGPASSWORD"] = spec.get("password") or ""
                argv = [
                    tool,
                    "-h", spec.get("host") or "127.0.0.1",
                    "-p", str(spec.get("port") or "5432"),
                    "-U", spec.get("user") or "postgres",
                    "--no-owner",
                    "-d", spec["database"],
                ]
                proc = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                rc, dump_bytes, dump_err = _drain_proc_to_bytes(proc, lambda: check_cancel(out_path, proc))
                if rc != 0:
                    out_path.unlink(missing_ok=True)
                    return {"ok": False, "error": f"pg_dump failed: {dump_err}"}
                ti = tarfile.TarInfo(name="database/dump.sql")
                ti.size = len(dump_bytes)
                ti.mtime = time.time()
                tar.addfile(ti, io.BytesIO(dump_bytes))

            # Include storage uploads if exists
            check_cancel(out_path)
            storage_public = path / "storage" / "app" / "public"
            if storage_public.is_dir():
                log("Compressing storage/app/public directory...")
                def tar_filter(ti):
                    check_cancel(out_path)
                    return ti
                tar.add(str(storage_public), arcname="storage/app/public", filter=tar_filter)

            # Include manifest
            check_cancel(out_path)
            log("Generating backup manifest.json...")
            manifest = {
                "site": site_name,
                "created_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "type": "full",
                "version": "1.0",
                "db_driver": driver,
                "db_name": spec.get("database") or (Path(spec.get("file", "")).name if spec and spec.get("file") else "none"),
                "tables": tables,
            }
            manifest_bytes = json.dumps(manifest, indent=2).encode("utf-8")
            ti = tarfile.TarInfo(name="manifest.json")
            ti.size = len(manifest_bytes)
            ti.mtime = time.time()
            tar.addfile(ti, io.BytesIO(manifest_bytes))

    except TaskError:
        raise
    except Exception as exc:
        out_path.unlink(missing_ok=True)
        return {"ok": False, "error": f"Failed to build full backup archive: {exc}"}

    st = out_path.stat()
    duration_ms = round((time.perf_counter() - start_time) * 1000, 1)
    log(f"Full snapshot saved: {out_name} ({fmt_bytes(st.st_size)}) in {duration_ms}ms")
    return {
        "ok": True,
        "filename": out_name,
        "path": str(out_path),
        "size_bytes": st.st_size,
        "size_human": fmt_bytes(st.st_size),
        "duration_ms": duration_ms,
        "type": "full",
    }


def restore_backup(site_path: str, filename: str) -> dict:
    """Restore a database or storage snapshot with full safety verification and rollback backups."""
    path = Path(site_path).resolve()
    if not filename or not CUSTOM_NAME_RE.fullmatch(filename):
        return {"ok": False, "error": "Invalid backup filename"}

    bdir = get_backups_dir(site_path, create=False)
    if not bdir.is_dir():
        return {"ok": False, "error": "Backups directory does not exist"}

    target = (bdir / filename).resolve()
    if not target.is_file() or target.parent != bdir.resolve():
        return {"ok": False, "error": "Backup file not found"}

    spec = get_site_db_spec(path)

    try:
        # Full tar archive restore
        if filename.endswith(".tar.gz") or filename.endswith(".tar"):
            with tarfile.open(target, "r:*") as tar:
                members = tar.getnames()

                # 1. Restore database if present
                if "database/database.sqlite" in members:
                    if spec and spec.get("driver") != "sqlite":
                        return {"ok": False, "error": f"Backup contains SQLite database, but this project uses {spec.get('driver')}"}
                    dest = Path(spec.get("file") if spec else path / "database" / "database.sqlite")
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    if dest.is_file():
                        shutil.copy2(dest, dest.with_suffix(".sqlite.bak"))
                    member = tar.getmember("database/database.sqlite")
                    f = tar.extractfile(member)
                    if f:
                        dest.write_bytes(f.read())

                elif "database/dump.sql" in members:
                    if not spec:
                        return {"ok": False, "error": "No database connection configured in project .env"}
                    member = tar.getmember("database/dump.sql")
                    f = tar.extractfile(member)
                    sql_bytes = f.read() if f else b""

                    driver = spec.get("driver")
                    if driver in ("mysql", "mariadb"):
                        tool = shutil.which("mysql")
                        if not tool:
                            return {"ok": False, "error": "mysql client is not installed. Please install default-mysql-client."}
                        # Strip MariaDB 11 sandbox header comment if present (causes syntax error on MySQL)
                        sql_bytes = re.sub(rb"/\*M!999999\\?-? enable the sandbox mode \*/\s*", b"", sql_bytes)
                        env = os.environ.copy()
                        env["MYSQL_PWD"] = spec.get("password") or ""
                        argv = [
                            tool,
                            "-h", spec.get("host") or "127.0.0.1",
                            "-P", str(spec.get("port") or "3306"),
                            "-u", spec.get("user") or "root",
                            spec["database"],
                        ]
                        proc = subprocess.Popen(argv, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                        stdout, stderr = proc.communicate(input=sql_bytes)
                        if proc.returncode != 0:
                            return {"ok": False, "error": f"MySQL restore failed: {stderr.decode('utf-8', errors='replace').strip()}"}

                    elif driver in ("pgsql", "postgres", "postgresql"):
                        tool = shutil.which("psql")
                        if not tool:
                            return {"ok": False, "error": "psql client is not installed. Please install postgresql-client."}
                        env = os.environ.copy()
                        env["PGPASSWORD"] = spec.get("password") or ""
                        argv = [
                            tool,
                            "-h", spec.get("host") or "127.0.0.1",
                            "-p", str(spec.get("port") or "5432"),
                            "-U", spec.get("user") or "postgres",
                            "-d", spec["database"],
                        ]
                        proc = subprocess.Popen(argv, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                        stdout, stderr = proc.communicate(input=sql_bytes)
                        if proc.returncode != 0:
                            return {"ok": False, "error": f"PostgreSQL restore failed: {stderr.decode('utf-8', errors='replace').strip()}"}
                    else:
                        return {"ok": False, "error": f"Unsupported database driver: {driver}"}

                # 2. Extract storage uploads
                for m in tar.getmembers():
                    if m.name.startswith("storage/app/public"):
                        try:
                            tar.extract(m, path=str(path), filter="data")
                        except TypeError:
                            tar.extract(m, path=str(path))

            return {"ok": True, "message": f"Successfully restored {filename}"}

        # SQL gzip restore
        if filename.endswith(".sql.gz"):
            if not spec:
                return {"ok": False, "error": "No database connection configured in project .env"}

            with gzip.open(target, "rb") as gz_in:
                sql_bytes = gz_in.read()

            driver = spec.get("driver")
            if driver == "sqlite":
                sqlite_file = Path(spec.get("file") or path / "database" / "database.sqlite")
                sqlite_file.parent.mkdir(parents=True, exist_ok=True)
                if sqlite_file.is_file():
                    shutil.copy2(sqlite_file, sqlite_file.with_suffix(".sqlite.bak"))
                temp_db = sqlite_file.with_suffix(".sqlite.tmp")
                temp_db.unlink(missing_ok=True)
                conn = sqlite3.connect(str(temp_db))
                conn.executescript(sql_bytes.decode("utf-8", errors="replace"))
                conn.close()
                temp_db.replace(sqlite_file)
                return {"ok": True, "message": f"Successfully restored SQLite database from {filename}"}

            elif driver in ("mysql", "mariadb"):
                tool = shutil.which("mysql")
                if not tool:
                    return {"ok": False, "error": "mysql client is not installed. Please install default-mysql-client."}
                # Strip MariaDB 11 sandbox header comment if present (causes syntax error on MySQL)
                sql_bytes = re.sub(rb"/\*M!999999\\?-? enable the sandbox mode \*/\s*", b"", sql_bytes)
                env = os.environ.copy()
                env["MYSQL_PWD"] = spec.get("password") or ""
                argv = [
                    tool,
                    "-h", spec.get("host") or "127.0.0.1",
                    "-P", str(spec.get("port") or "3306"),
                    "-u", spec.get("user") or "root",
                    spec["database"],
                ]
                proc = subprocess.Popen(argv, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout, stderr = proc.communicate(input=sql_bytes)
                if proc.returncode != 0:
                    return {"ok": False, "error": f"MySQL restore failed: {stderr.decode('utf-8', errors='replace').strip()}"}
                return {"ok": True, "message": f"Successfully restored MySQL database from {filename}"}

            elif driver in ("pgsql", "postgres", "postgresql"):
                tool = shutil.which("psql")
                if not tool:
                    return {"ok": False, "error": "psql client is not installed. Please install postgresql-client."}
                env = os.environ.copy()
                env["PGPASSWORD"] = spec.get("password") or ""
                argv = [
                    tool,
                    "-h", spec.get("host") or "127.0.0.1",
                    "-p", str(spec.get("port") or "5432"),
                    "-U", spec.get("user") or "postgres",
                    "-d", spec["database"],
                ]
                proc = subprocess.Popen(argv, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout, stderr = proc.communicate(input=sql_bytes)
                if proc.returncode != 0:
                    return {"ok": False, "error": f"PostgreSQL restore failed: {stderr.decode('utf-8', errors='replace').strip()}"}
                return {"ok": True, "message": f"Successfully restored PostgreSQL database from {filename}"}

            else:
                return {"ok": False, "error": f"Unsupported database driver: {driver}"}

        return {"ok": False, "error": f"Unsupported backup format: {filename}"}
    except Exception as exc:
        return {"ok": False, "error": f"Restore failed: {exc}"}


def prune_backups(site_path: str, keep: int = 5) -> dict:
    """Keep the newest N backups in storage/app/backups and delete older snapshots."""
    bdir = get_backups_dir(site_path, create=False)
    if not bdir.is_dir():
        return {"ok": True, "kept": 0, "deleted": 0, "deleted_files": []}
    files = []
    for f in bdir.glob("*"):
        if f.is_file() and (f.suffix == ".gz" or f.name.endswith(".tar.gz")):
            try:
                files.append((f.stat().st_mtime, f))
            except OSError:
                pass
    files.sort(key=lambda x: x[0], reverse=True)
    if keep <= 0:
        keep = 5
    to_delete = files[keep:]
    deleted_names = []
    for _, f in to_delete:
        try:
            f.unlink()
            deleted_names.append(f.name)
        except OSError:
            pass
    return {
        "ok": True,
        "kept": min(len(files), keep),
        "deleted": len(deleted_names),
        "deleted_files": deleted_names,
    }


def get_backup_schedule(site_name: str) -> dict:
    """Read the project's backup cron line and last run status."""
    marker = f"# laravel-dev:{site_name}:backup"
    code, out = sites.run_quiet(["crontab", "-l"])
    line = ""
    if code == 0 and out:
        for l in out.splitlines():
            if l.strip().endswith(marker):
                line = l.strip()
                break

    log_path = Path.home() / ".local" / "log" / "laravel-dev" / f"laravel-dev-{site_name}-backup.log"
    last_log = ""
    last_run_time = ""
    last_status = "idle"
    if log_path.is_file():
        try:
            st = log_path.stat()
            last_run_time = datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")
            lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
            if lines:
                last_log = "\n".join(lines[-15:])
                low = last_log.lower()
                if "error" in low or "failed" in low:
                    last_status = "fail"
                elif "snapshot created" in low or "finished" in low or "done" in low:
                    last_status = "ok"
        except Exception:
            pass

    if not line:
        return {
            "enabled": False,
            "frequency": "off",
            "retention": 5,
            "type": "full",
            "remote": "",
            "last_run": last_run_time,
            "last_status": last_status,
            "last_log": last_log,
        }

    freq = "daily" if line.startswith("0 2 * * *") else ("weekly" if line.startswith("0 3 * * 0") else "custom")
    btype = "full"
    retention = 5
    remote = ""
    parts = line.split()
    for i, p in enumerate(parts):
        if p == "backup-run" and i + 3 < len(parts):
            btype = parts[i + 2] if parts[i + 2] in ("full", "db", "storage") else "full"
            try:
                retention = int(parts[i + 3])
            except ValueError:
                pass
            if i + 4 < len(parts) and not parts[i + 4].startswith(">") and not parts[i + 4].startswith("#"):
                remote = parts[i + 4].strip("'\"")

    return {
        "enabled": True,
        "frequency": freq,
        "retention": retention,
        "type": btype,
        "remote": remote,
        "last_run": last_run_time,
        "last_status": last_status,
        "last_log": last_log,
    }


def set_backup_schedule(site_name: str, site_path: str, frequency: str = "daily",
                        retention: int = 5, backup_type: str = "full", remote_id: str = "") -> dict:
    """Configure or remove scheduled backups for a site in crontab via CLI."""
    base_dir = Path(__file__).resolve().parent.parent
    bin_path = base_dir / "bin" / "laravel-dev"
    freq = frequency if frequency in ("daily", "weekly") else "off"
    btype = backup_type if backup_type in ("full", "db", "storage") else "full"
    ret = max(1, min(int(retention or 5), 100))
    cmd = [str(bin_path), "backup-schedule", site_name, freq, str(ret), btype, remote_id or ""]
    code, out = sites.run_quiet(cmd)
    if code != 0:
        return {"ok": False, "error": f"Failed to update backup schedule: {out.strip()}"}
    return {
        "ok": True,
        "enabled": freq != "off",
        "frequency": freq,
        "retention": ret,
        "type": btype,
        "remote": remote_id or "",
        "message": f"Updated backup schedule for {site_name}",
    }


def upload_backup_remote(site_path: str, filename: str, remote_server_id: str, remote_path: str = "", log_fn=None) -> dict:
    """Stream a local snapshot file to a saved SSH remote server."""
    bdir = get_backups_dir(site_path, create=False)
    local_file = bdir / filename
    if not local_file.is_file():
        return {"ok": False, "error": f"Backup file {filename} does not exist"}

    config_dir = sites.CONFIG_DIR
    servers_file = config_dir / "servers.json"
    if not servers_file.is_file():
        return {"ok": False, "error": "No remote SSH servers configured"}
    try:
        servers = json.loads(servers_file.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"ok": False, "error": f"Cannot read servers.json: {exc}"}

    server = next((s for s in servers if s.get("id") == remote_server_id or s.get("name") == remote_server_id), None)
    if not server:
        return {"ok": False, "error": f"Remote server '{remote_server_id}' not found"}

    dest_dir = remote_path.strip() if remote_path else "~/backups"
    dest_file = f"{dest_dir.rstrip('/')}/{filename}"

    if log_fn:
        log_fn(f"[backup] Connecting to {server.get('user', '')}@{server.get('host', '')}...\n")
        log_fn(f"[backup] Uploading {filename} ({fmt_bytes(local_file.stat().st_size)}) to {dest_file}...\n")

    import remote
    ui_dir = Path(__file__).resolve().parent
    rem = remote.Remote(config_dir, ui_dir, emit=lambda *a: None)
    rem.connect(server["id"])
    rem.run(server, f'mkdir -p "{dest_dir}"')

    argv = rem.command(server, f'cat > "{dest_file}"')
    with open(local_file, "rb") as f:
        res = subprocess.run(argv, stdin=f, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=rem.env())
    if res.returncode != 0:
        err = res.stderr.decode("utf-8", "replace").strip()
        return {"ok": False, "error": f"SSH transfer failed: {err}"}

    if log_fn:
        log_fn(f"[backup] Upload completed successfully to {dest_file}.\n")

    return {"ok": True, "message": f"Successfully uploaded {filename} to {server.get('host')}:{dest_file}", "remote_path": dest_file}


def _find_sqlite_file(site_path: Path) -> Path | None:
    """Detect SQLite database file in a Laravel project only if DB_CONNECTION is sqlite."""
    spec = get_site_db_spec(site_path)
    if not spec or spec.get("driver") != "sqlite":
        return None
    f = Path(spec.get("file", ""))
    if f.is_file():
        return f
    default_sqlite = site_path / "database" / "database.sqlite"
    if default_sqlite.is_file():
        return default_sqlite
    return None


def get_deploy_target(config_dir: Path, site_name: str) -> dict:
    """Retrieve saved remote deploy target for a local site."""
    targets_file = config_dir / "deployments.json"
    if targets_file.is_file():
        try:
            data = json.loads(targets_file.read_text(encoding="utf-8"))
            return data.get(site_name) or {}
        except Exception:
            pass
    return {}


def save_deploy_target(config_dir: Path, site_name: str, server_id: str, remote_path: str, branch: str = "main", server_php: str = "") -> dict:
    """Persist remote deploy target for a local site, preserving deployment history."""
    targets_file = config_dir / "deployments.json"
    data = {}
    if targets_file.is_file():
        try:
            data = json.loads(targets_file.read_text(encoding="utf-8"))
        except Exception:
            data = {}

    existing = data.get(site_name) or {}
    entry = {
        **existing,
        "server": (server_id or "").strip(),
        "path": (remote_path or "").strip(),
        "branch": (branch or "main").strip(),
        "server_php": (server_php or "").strip(),
        "updated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    data[site_name] = entry
    targets_file.parent.mkdir(parents=True, exist_ok=True)
    targets_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return entry


def record_deploy_history(config_dir: Path, site_name: str, action: str, server_id: str, status: str, message: str = "") -> dict:
    """Record a deploy or rollback run in deployments.json."""
    targets_file = config_dir / "deployments.json"
    data = {}
    if targets_file.is_file():
        try:
            data = json.loads(targets_file.read_text(encoding="utf-8"))
        except Exception:
            data = {}

    site_entry = data.setdefault(site_name, {})
    history = site_entry.setdefault("history", [])
    record = {
        "id": uuid.uuid4().hex[:8],
        "action": action,
        "server": server_id,
        "status": status,
        "message": message,
        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    history.insert(0, record)
    site_entry["history"] = history[:30]
    targets_file.parent.mkdir(parents=True, exist_ok=True)
    targets_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return record


# ── Share / Expose & Cloudflare Tunnel ──────────────────────────────────────

ACTIVE_TUNNELS: dict[str, dict] = {}


def get_lan_ip() -> str:
    """Return the primary local IPv4 address of the machine."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        pass
    try:
        out = subprocess.check_output(["hostname", "-I"], text=True, timeout=2)
        ips = [i.strip() for i in out.split() if i.strip() and not i.startswith("127.")]
        if ips:
            return ips[0]
    except Exception:
        pass
    return "127.0.0.1"


def nginx_lan_port(site_name: str) -> str:
    """Port nginx listens on for this site on all interfaces (see ensure_lan_listen)."""
    for conf in (Path("/etc/nginx/sites-available") / site_name, Path("/etc/nginx/conf.d") / f"{site_name}.conf",
                 Path("/etc/nginx/http.d") / f"{site_name}.conf"):
        try:
            match = re.search(r"^\s*listen\s+(?:0\.0\.0\.0:)?(\d+);\s*# laravel-dev:lan", conf.read_text(errors="replace"), re.M)
        except OSError:
            continue
        if match:
            return match.group(1)
    return ""


def _tunnel_dirs() -> tuple[Path, Path]:
    uid = os.getuid() if hasattr(os, "getuid") else 1000
    candidates_runtime = [
        Path.home() / ".config" / "laravel-dev" / "runtime" / "tunnels",
        Path(f"/tmp/laravel-dev-{uid}/runtime/tunnels"),
    ]
    candidates_config = [
        Path.home() / ".config" / "laravel-dev" / "tunnels",
        Path(f"/tmp/laravel-dev-{uid}/tunnels"),
    ]
    runtime_dir = candidates_runtime[0]
    for d in candidates_runtime:
        try:
            d.mkdir(parents=True, exist_ok=True)
            runtime_dir = d
            break
        except OSError:
            continue

    config_dir = candidates_config[0]
    for d in candidates_config:
        try:
            d.mkdir(parents=True, exist_ok=True)
            config_dir = d
            break
        except OSError:
            continue

    return runtime_dir, config_dir


def _is_pid_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def get_tunnel_token(site_name: str) -> str:
    """Read saved Cloudflare Tunnel token if configured."""
    _, config_dir = _tunnel_dirs()
    token_file = config_dir / f"{site_name}.token"
    if token_file.is_file():
        try:
            return token_file.read_text(errors="ignore").strip()
        except OSError:
            pass
    return ""


def set_tunnel_token(site_name: str, token: str) -> bool:
    """Save or clear Cloudflare Tunnel token."""
    _, config_dir = _tunnel_dirs()
    token_file = config_dir / f"{site_name}.token"
    try:
        if token.strip():
            token_file.write_text(token.strip())
            try:
                os.chmod(token_file, 0o600)
            except OSError:
                pass
        else:
            token_file.unlink(missing_ok=True)
        return True
    except OSError:
        return False


def get_tunnel_status(site_name: str) -> dict:
    """Return live status of Cloudflare Tunnel for a site."""
    runtime_dir, _ = _tunnel_dirs()
    pid_file = runtime_dir / f"{site_name}.pid"
    url_file = runtime_dir / f"{site_name}.url"
    json_file = runtime_dir / f"{site_name}.json"
    log_file = runtime_dir / f"{site_name}.log"

    saved_token = get_tunnel_token(site_name)

    # 1. In-memory record
    mem = ACTIVE_TUNNELS.get(site_name)
    if mem and mem.get("proc"):
        proc = mem["proc"]
        if proc.poll() is None:
            return {
                "active": True,
                "pid": proc.pid,
                "url": mem.get("url") or (url_file.read_text().strip() if url_file.is_file() else ""),
                "mode": mem.get("mode", "quick"),
                "started": mem.get("started", 0),
                "token": saved_token,
                "has_token": bool(saved_token),
                "log_file": str(log_file),
            }
        else:
            ACTIVE_TUNNELS.pop(site_name, None)

    # 2. File-based PID check (e.g. started via CLI `laravel-dev tunnel start`)
    if pid_file.is_file():
        try:
            pid = int(pid_file.read_text().strip())
            if _is_pid_alive(pid):
                url = url_file.read_text().strip() if url_file.is_file() else ""
                mode = "quick"
                started = 0
                if json_file.is_file():
                    try:
                        meta = json.loads(json_file.read_text())
                        mode = meta.get("mode", "quick")
                        started = meta.get("started", 0)
                        if not url:
                            url = meta.get("url", "")
                    except Exception:
                        pass
                if not url and log_file.is_file():
                    m = re.search(r"https://[a-zA-Z0-9.-]+\.trycloudflare\.com", log_file.read_text(errors="ignore"))
                    if m:
                        url = m.group(0)
                        try:
                            url_file.write_text(url)
                        except OSError:
                            pass
                return {
                    "active": True,
                    "pid": pid,
                    "url": url,
                    "mode": mode,
                    "started": started,
                    "token": saved_token,
                    "has_token": bool(saved_token),
                    "log_file": str(log_file),
                }
            else:
                # Stale PID
                pid_file.unlink(missing_ok=True)
                url_file.unlink(missing_ok=True)
        except (ValueError, OSError):
            pass

    return {
        "active": False,
        "pid": None,
        "url": "",
        "mode": "quick",
        "started": 0,
        "token": saved_token,
        "has_token": bool(saved_token),
        "log_file": str(log_file),
    }


def get_share_info(site_name: str, domain: str = "", port: str = "") -> dict:
    """Return local, LAN and public tunnel share info for a site."""
    lan_ip = get_lan_ip()
    lan_port = nginx_lan_port(site_name) or port or ""
    if lan_port:
        lan_url = f"http://{lan_ip}:{lan_port}" if lan_port != "80" else f"http://{lan_ip}"
    else:
        lan_url = ""  # created before LAN ports existed: Repair the site to add one
    domain_url = f"http://{domain}" if domain else f"http://{site_name}.test"

    tunnel_info = get_tunnel_status(site_name)
    return {
        "site": site_name,
        "domain_url": domain_url,
        "lan_ip": lan_ip,
        "lan_port": lan_port,
        "lan_url": lan_url,
        "tunnel": tunnel_info,
    }


def start_tunnel(site_name: str, domain: str = "", port: str = "", mode: str = "quick", token: str = "") -> dict:
    """Start a Cloudflare tunnel (Quick Tunnel or Token-based Named Tunnel)."""
    curr = get_tunnel_status(site_name)
    if curr.get("active") and curr.get("url"):
        return {"ok": True, "url": curr["url"], "pid": curr.get("pid")}

    cloudflared = shutil.which("cloudflared") or "/usr/local/bin/cloudflared"
    if not os.path.isfile(cloudflared) or not os.access(cloudflared, os.X_OK):
        return {"ok": False, "error": "cloudflared binary not found. Please install cloudflared to use public tunnels."}

    runtime_dir, config_dir = _tunnel_dirs()
    pid_file = runtime_dir / f"{site_name}.pid"
    url_file = runtime_dir / f"{site_name}.url"
    json_file = runtime_dir / f"{site_name}.json"
    log_file = runtime_dir / f"{site_name}.log"

    # Save token if passed
    if token:
        set_tunnel_token(site_name, token)
    else:
        token = get_tunnel_token(site_name)

    use_token = bool(token and mode != "quick")
    effective_mode = "token" if use_token else "quick"

    if use_token:
        cmd = [cloudflared, "tunnel", "run", "--token", token]
    elif port and str(port) != "80":
        cmd = [cloudflared, "tunnel", "--url", f"http://127.0.0.1:{port}"]
    else:
        host = domain or f"{site_name}.test"
        cmd = [cloudflared, "tunnel", "--url", "http://127.0.0.1:80", "--http-host-header", host]

    try:
        log_handle = open(log_file, "w", buffering=1, encoding="utf-8", errors="replace")
    except OSError as e:
        return {"ok": False, "error": f"Cannot write log file {log_file}: {e}"}

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            close_fds=True,
        )
    except Exception as e:
        log_handle.close()
        return {"ok": False, "error": str(e)}

    # Save PID immediately
    try:
        pid_file.write_text(str(proc.pid))
    except OSError:
        pass

    url = None
    url_re = re.compile(r"https://[a-zA-Z0-9.-]+\.trycloudflare\.com")
    token_conn_re = re.compile(r"Registered tunnel connection|Connection.*registered", re.IGNORECASE)
    start_t = time.time()
    last_log_pos = 0

    # Wait for the tunnel URL or connection up to 10 seconds
    while time.time() - start_t < 10:
        if proc.poll() is not None:
            break

        try:
            if log_file.is_file():
                with open(log_file, "r", encoding="utf-8", errors="replace") as rf:
                    rf.seek(last_log_pos)
                    chunk = rf.read()
                    last_log_pos = rf.tell()
                    if chunk:
                        if effective_mode == "quick":
                            m = url_re.search(chunk)
                            if m:
                                url = m.group(0)
                                break
                        else:
                            if token_conn_re.search(chunk):
                                url = "custom-domain (token tunnel active)"
                                break
        except Exception:
            pass

        time.sleep(0.2)

    if not url and proc.poll() is None and log_file.is_file():
        try:
            content = log_file.read_text(encoding="utf-8", errors="replace")
            m = url_re.search(content)
            if m:
                url = m.group(0)
            elif effective_mode == "token" and token_conn_re.search(content):
                url = "custom-domain (token tunnel active)"
        except Exception:
            pass

    if url or (proc.poll() is None and effective_mode == "token"):
        url = url or "custom-domain (token tunnel active)"
        started_ts = time.time()
        try:
            url_file.write_text(url)
            meta = {
                "project": site_name,
                "active": True,
                "pid": proc.pid,
                "url": url,
                "mode": effective_mode,
                "started": started_ts,
            }
            json_file.write_text(json.dumps(meta))
        except OSError:
            pass

        ACTIVE_TUNNELS[site_name] = {
            "proc": proc,
            "url": url,
            "mode": effective_mode,
            "started": started_ts,
        }
        return {"ok": True, "url": url, "pid": proc.pid, "mode": effective_mode}
    else:
        try:
            proc.terminate()
            proc.wait(timeout=1)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        pid_file.unlink(missing_ok=True)
        url_file.unlink(missing_ok=True)
        err_msg = ""
        try:
            if log_file.is_file():
                lines = [ln.strip() for ln in log_file.read_text(encoding="utf-8", errors="replace").splitlines() if ln.strip()]
                err_msg = "\n".join(lines[-4:])
        except Exception:
            pass
        return {"ok": False, "error": err_msg or "Failed to connect to Cloudflare service within 10 seconds."}


def stop_tunnel(site_name: str) -> bool:
    """Stop active tunnel for site."""
    runtime_dir, _ = _tunnel_dirs()
    pid_file = runtime_dir / f"{site_name}.pid"
    url_file = runtime_dir / f"{site_name}.url"
    json_file = runtime_dir / f"{site_name}.json"

    # Stop in-memory proc
    if site_name in ACTIVE_TUNNELS:
        t = ACTIVE_TUNNELS.pop(site_name)
        proc = t.get("proc")
        if proc:
            try:
                proc.terminate()
                proc.wait(timeout=2)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

    # Stop PID if still running
    if pid_file.is_file():
        try:
            pid = int(pid_file.read_text().strip())
            if _is_pid_alive(pid):
                try:
                    os.kill(pid, 15)  # SIGTERM
                    for _ in range(20):
                        if not _is_pid_alive(pid):
                            break
                        time.sleep(0.1)
                    if _is_pid_alive(pid):
                        os.kill(pid, 9)  # SIGKILL
                except OSError:
                    pass
        except (ValueError, OSError):
            pass

    pid_file.unlink(missing_ok=True)
    url_file.unlink(missing_ok=True)
    if json_file.is_file():
        try:
            meta = json.loads(json_file.read_text())
            meta["active"] = False
            meta["pid"] = None
            json_file.write_text(json.dumps(meta))
        except Exception:
            pass
    return True


def restart_tunnel(site_name: str, domain: str = "", port: str = "", mode: str = "quick", token: str = "") -> dict:
    """Restart active tunnel for site."""
    stop_tunnel(site_name)
    time.sleep(0.5)
    return start_tunnel(site_name, domain=domain, port=port, mode=mode, token=token)


def get_tunnel_logs(site_name: str, lines: int = 100) -> str:
    """Return recent logs for a site's Cloudflare Tunnel."""
    runtime_dir, _ = _tunnel_dirs()
    log_file = runtime_dir / f"{site_name}.log"
    if not log_file.is_file():
        return "No log file found for this tunnel."
    try:
        content = log_file.read_text(encoding="utf-8", errors="replace")
        all_lines = content.splitlines()
        return "\n".join(all_lines[-lines:])
    except OSError as e:
        return f"Error reading tunnel log: {e}"


def list_all_tunnels() -> list[dict]:
    """List all active tunnels across all projects."""
    runtime_dir, _ = _tunnel_dirs()
    tunnels = []
    if not runtime_dir.is_dir():
        return tunnels
    for pid_file in runtime_dir.glob("*.pid"):
        site = pid_file.stem
        info = get_tunnel_status(site)
        if info.get("active"):
            tunnels.append({"site": site, **info})
    return tunnels


def stop_all_tunnels() -> None:
    """Stop all active tunnels on shutdown."""
    runtime_dir, _ = _tunnel_dirs()
    for name in list(ACTIVE_TUNNELS.keys()):
        stop_tunnel(name)
    if runtime_dir.is_dir():
        for pid_file in runtime_dir.glob("*.pid"):
            stop_tunnel(pid_file.stem)


def run_tests(site_path: str, php_bin: str = "php", filter_query: str = "", coverage: bool = False) -> dict:
    """Run Pest/PHPUnit tests with JUnit XML logging and optional Clover coverage parsing."""
    import tempfile
    import xml.etree.ElementTree as ET

    sp = Path(site_path)
    pest_bin = sp / "vendor" / "bin" / "pest"
    phpunit_bin = sp / "vendor" / "bin" / "phpunit"
    artisan_bin = sp / "artisan"

    tmp_file = tempfile.NamedTemporaryFile(suffix=".xml", delete=False)
    tmp_path = tmp_file.name
    tmp_file.close()

    cov_file = tempfile.NamedTemporaryFile(suffix=".xml", delete=False) if coverage else None
    cov_path = cov_file.name if cov_file else ""
    if cov_file:
        cov_file.close()

    try:
        if pest_bin.is_file() and os.access(pest_bin, os.X_OK):
            cmd = [php_bin, str(pest_bin), f"--log-junit={tmp_path}"]
            if coverage:
                cmd.append(f"--coverage-clover={cov_path}")
            if filter_query:
                cmd.append(f"--filter={filter_query}")
        elif phpunit_bin.is_file() and os.access(phpunit_bin, os.X_OK):
            cmd = [php_bin, str(phpunit_bin), f"--log-junit={tmp_path}"]
            if coverage:
                cmd.append(f"--coverage-clover={cov_path}")
            if filter_query:
                cmd.append(f"--filter={filter_query}")
        elif artisan_bin.is_file():
            cmd = [php_bin, "artisan", "test", f"--log-junit={tmp_path}"]
            if coverage:
                cmd.append(f"--coverage-clover={cov_path}")
            if filter_query:
                cmd.extend(["--filter", filter_query])
        else:
            return {
                "ok": False,
                "error": "No test runner found (pest, phpunit, or artisan).",
                "cases": [],
            }

        proc = subprocess.run(cmd, cwd=site_path, capture_output=True, text=True, timeout=300)
        output = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")

        cases = []
        total = 0
        passed = 0
        failed = 0
        errors = 0
        duration = 0.0

        if os.path.isfile(tmp_path) and os.path.getsize(tmp_path) > 0:
            try:
                tree = ET.parse(tmp_path)
                root = tree.getroot()
                for tc in root.iter("testcase"):
                    total += 1
                    fail = tc.find("failure")
                    err = tc.find("error")
                    status = "failed" if fail is not None else "error" if err is not None else "passed"
                    if status == "passed":
                        passed += 1
                    elif status == "failed":
                        failed += 1
                    else:
                        errors += 1

                    msg = ""
                    if fail is not None and fail.text:
                        msg = fail.text.strip()
                    elif err is not None and err.text:
                        msg = err.text.strip()

                    try:
                        case_time = float(tc.get("time") or 0)
                        duration += case_time
                    except ValueError:
                        case_time = 0.0

                    cases.append({
                        "name": tc.get("name") or "Unnamed test",
                        "class": tc.get("class") or tc.get("classname") or "",
                        "file": tc.get("file") or "",
                        "line": tc.get("line") or "",
                        "time": case_time,
                        "status": status,
                        "message": msg,
                    })
            except Exception:
                pass

        coverage_data = None
        if coverage:
            if cov_path and os.path.isfile(cov_path) and os.path.getsize(cov_path) > 0:
                try:
                    cov_tree = ET.parse(cov_path)
                    cov_root = cov_tree.getroot()
                    proj_metrics = cov_root.find(".//project/metrics")
                    stmts = int(proj_metrics.get("statements", 0)) if proj_metrics is not None else 0
                    cov_stmts = int(proj_metrics.get("coveredstatements", 0)) if proj_metrics is not None else 0
                    pct = round((cov_stmts / stmts * 100), 1) if stmts else 0.0

                    file_covs = []
                    for f_elem in cov_root.iter("file"):
                        f_name = f_elem.get("name", "")
                        f_met = f_elem.find("metrics")
                        if f_met is not None and f_name:
                            f_stmts = int(f_met.get("statements", 0))
                            f_cov = int(f_met.get("coveredstatements", 0))
                            f_pct = round((f_cov / f_stmts * 100), 1) if f_stmts else 100.0
                            rel_name = f_name
                            if str(sp) in f_name:
                                rel_name = str(Path(f_name).relative_to(sp))
                            file_covs.append({
                                "file": rel_name,
                                "percent": f_pct,
                                "statements": f_stmts,
                                "covered": f_cov,
                            })

                    coverage_data = {
                        "ok": True,
                        "percent": pct,
                        "statements": stmts,
                        "covered_statements": cov_stmts,
                        "files": sorted(file_covs, key=lambda x: x["percent"]),
                    }
                except Exception as exc:
                    coverage_data = {"ok": False, "error": f"Failed to parse coverage: {exc}"}
            else:
                coverage_data = {"ok": False, "error": "No coverage data generated. Ensure PCOV or Xdebug is enabled in PHP."}

        if total == 0 and proc.returncode != 0:
            return {
                "ok": False,
                "error": "Tests failed to execute or produce JUnit output.",
                "raw_output": output.strip(),
                "cases": [],
                "total": 0,
                "passed": 0,
                "failed": 0,
                "errors": 0,
                "time": 0.0,
                "coverage": coverage_data,
            }

        return {
            "ok": True,
            "total": total,
            "passed": passed,
            "failed": failed,
            "errors": errors,
            "time": round(duration, 3),
            "raw_output": output.strip(),
            "cases": cases,
            "coverage": coverage_data,
        }
    finally:
        try:
            if os.path.isfile(tmp_path):
                os.unlink(tmp_path)
            if cov_path and os.path.isfile(cov_path):
                os.unlink(cov_path)
        except OSError:
            pass


AUDIT_CACHE: dict[str, dict] = {}


def audit_packages(site_path: str, php_bin: str = "php", force: bool = False) -> dict:
    """Audit project dependencies using composer audit, composer outdated, and npm audit."""
    sp = Path(site_path)
    cache_key = str(sp.resolve())
    now = time.time()
    if not force and cache_key in AUDIT_CACHE:
        entry = AUDIT_CACHE[cache_key]
        if now - entry["time"] < 600:
            return entry["data"]

    composer_bin = shutil.which("composer") or "composer"
    npm_bin = shutil.which("npm") or "npm"
    is_win = sys.platform.startswith("win")

    has_composer = (sp / "composer.json").is_file()
    has_npm = (sp / "package.json").is_file()

    advisories = []
    outdated = []
    npm_vulnerabilities = 0
    npm_advisories = []

    if has_composer:
        try:
            cmd = [php_bin, composer_bin, "audit", "--format=json"] if not is_win else [composer_bin, "audit", "--format=json"]
            proc = subprocess.run(cmd, cwd=site_path, capture_output=True, text=True, timeout=30)
            raw = proc.stdout.strip()
            if raw:
                try:
                    data = json.loads(raw)
                    adv_map = data.get("advisories", {})
                    for pkg, adv_list in adv_map.items():
                        for adv in adv_list:
                            advisories.append({
                                "package": pkg,
                                "title": adv.get("title") or "Security vulnerability",
                                "cve": adv.get("cve") or "",
                                "link": adv.get("link") or "",
                                "affected": adv.get("affectedVersions") or "",
                                "severity": adv.get("severity") or "warning",
                            })
                except Exception:
                    pass
        except Exception:
            pass

        try:
            cmd_outdated = [php_bin, composer_bin, "outdated", "--direct", "--format=json"] if not is_win else [composer_bin, "outdated", "--direct", "--format=json"]
            proc = subprocess.run(cmd_outdated, cwd=site_path, capture_output=True, text=True, timeout=30)
            raw = proc.stdout.strip()
            if raw:
                try:
                    data = json.loads(raw)
                    installed = data.get("installed", [])
                    for item in installed:
                        outdated.append({
                            "name": item.get("name"),
                            "version": item.get("version"),
                            "latest": item.get("latest"),
                            "status": item.get("latest-status", "update-possible"),
                            "description": item.get("description", ""),
                        })
                except Exception:
                    pass
        except Exception:
            pass

    if has_npm and (sp / "package-lock.json").is_file():
        try:
            proc = subprocess.run([npm_bin, "audit", "--json"], cwd=site_path, capture_output=True, text=True, timeout=30)
            raw = proc.stdout.strip()
            if raw:
                try:
                    data = json.loads(raw)
                    metadata = data.get("metadata", {}).get("vulnerabilities", {})
                    npm_vulnerabilities = metadata.get("total", 0)
                    vulns = data.get("vulnerabilities", {})
                    for name, v in vulns.items():
                        npm_advisories.append({
                            "package": name,
                            "severity": v.get("severity", "moderate"),
                            "isDirect": v.get("isDirect", False),
                            "range": v.get("range", ""),
                        })
                except Exception:
                    pass
        except Exception:
            pass

    res = {
        "ok": True,
        "has_composer": has_composer,
        "has_npm": has_npm,
        "composer_advisories": advisories,
        "composer_outdated": outdated,
        "npm_vulnerabilities": npm_vulnerabilities,
        "npm_advisories": npm_advisories,
    }
    AUDIT_CACHE[cache_key] = {"time": now, "data": res}
    return res


# ── Developer Productivity Tools (Phase 7) ───────────────────────────────────

def list_models(site_path: str) -> list[str]:
    """Discover all Eloquent models in app/Models and app/."""
    path = Path(site_path).resolve()
    models = []
    models_dir = path / "app" / "Models"
    if models_dir.is_dir():
        for p in sorted(models_dir.rglob("*.php")):
            rel = p.relative_to(models_dir).with_suffix("")
            name = str(rel).replace("/", "\\")
            models.append(name)
    app_dir = path / "app"
    if app_dir.is_dir():
        for p in sorted(app_dir.glob("*.php")):
            models.append(p.stem)
    return sorted(list(set(models)))


def show_model(site_path: str, model_name: str, php_bin: str = "php") -> dict:
    """Run `artisan model:show <model> --json` and return structured model details."""
    path = Path(site_path).resolve()
    full_name = model_name if model_name.startswith("App\\") else f"App\\Models\\{model_name}"
    cmd = [php_bin, "artisan", "model:show", full_name, "--json"]
    try:
        proc = subprocess.run(cmd, cwd=str(path), capture_output=True, text=True, timeout=12)
        if proc.returncode == 0 and proc.stdout.strip().startswith("{"):
            return {"ok": True, "model": json.loads(proc.stdout)}
    except Exception:
        pass

    # Fallback to short name
    cmd_short = [php_bin, "artisan", "model:show", model_name, "--json"]
    try:
        proc = subprocess.run(cmd_short, cwd=str(path), capture_output=True, text=True, timeout=12)
        if proc.returncode == 0 and proc.stdout.strip().startswith("{"):
            return {"ok": True, "model": json.loads(proc.stdout)}
        err_msg = proc.stderr.strip() or f"artisan model:show failed with exit code {proc.returncode}"
    except Exception as exc:
        err_msg = str(exc)

    return {"ok": False, "error": err_msg}


def get_aggregated_errors(site_path: str, file_name: str = "laravel.log") -> dict:
    """Group log errors by (exception_type, caller_file, line) like Sentry."""
    path = Path(site_path).resolve()
    parsed = parse_laravel_logs(str(path), file_name=file_name, max_entries=1000)
    entries = parsed.get("entries", [])

    resolved_file = sites.CONFIG_DIR / "resolved_errors" / f"{path.name}.json"
    resolved_sigs = set()
    if resolved_file.is_file():
        try:
            resolved_sigs = set(json.loads(resolved_file.read_text(encoding="utf-8")))
        except Exception:
            pass

    groups: dict[str, dict[str, object]] = {}
    for e in entries:
        if e.get("level") not in ("EMERGENCY", "ALERT", "CRITICAL", "ERROR"):
            continue
        msg = e.get("message", "")
        match = re.search(r"^(?:(?P<exc>[A-Za-z0-9_\\]+(?:Exception|Error|Fault)):)?\s*(?P<desc>.*?)(?: in (?P<file>/[^:]+):(?P<line>\d+))?$", msg, re.DOTALL)
        exc_type = match.group("exc") if match and match.group("exc") else "Error"
        fpath = match.group("file") if match and match.group("file") else ""
        line_no = int(match.group("line")) if match and match.group("line") else 0

        rel_file = fpath
        if fpath and str(path) in fpath:
            rel_file = str(Path(fpath).relative_to(path))

        sig = f"{exc_type}:{rel_file}:{line_no}" if rel_file else f"{exc_type}:{msg[:80].strip()}"

        if sig not in groups:
            groups[sig] = {
                "signature": sig,
                "type": exc_type,
                "message": msg[:200],
                "file": rel_file,
                "line": line_no,
                "count": 0,
                "first_seen": e.get("date", ""),
                "last_seen": e.get("date", ""),
                "trace": e.get("trace", ""),
                "resolved": sig in resolved_sigs,
            }
        g = groups[sig]
        g["count"] += 1
        g["last_seen"] = e.get("date", g["last_seen"])

    items = sorted(groups.values(), key=lambda x: x["count"], reverse=True)
    return {
        "ok": True,
        "total_issues": len(items),
        "unresolved_count": sum(1 for i in items if not i["resolved"]),
        "issues": items,
    }


def mark_error_resolved(site_path: str, signature: str, resolved: bool = True) -> dict:
    """Mark an error signature as resolved or unresolved."""
    path = Path(site_path).resolve()
    resolved_dir = sites.CONFIG_DIR / "resolved_errors"
    try:
        resolved_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    resolved_file = resolved_dir / f"{path.name}.json"
    resolved_sigs = set()
    if resolved_file.is_file():
        try:
            resolved_sigs = set(json.loads(resolved_file.read_text(encoding="utf-8")))
        except Exception:
            pass

    if resolved:
        resolved_sigs.add(signature)
    else:
        resolved_sigs.discard(signature)

    resolved_file.write_text(json.dumps(list(resolved_sigs)), encoding="utf-8")
    return {"ok": True, "signature": signature, "resolved": resolved}


def test_route_request(url: str, method: str = "GET", headers: dict = None, body: str = "", timeout: float = 15.0) -> dict:
    """Execute an HTTP request without CORS restrictions and return response details."""
    req_headers = {"User-Agent": "LaravelDevTool/1.0", "Accept": "application/json, text/html, */*"}
    if headers and isinstance(headers, dict):
        req_headers.update(headers)

    method = method.upper()
    data = body.encode("utf-8") if body and method in ("POST", "PUT", "PATCH", "DELETE") else None
    if data and "Content-Type" not in req_headers:
        req_headers["Content-Type"] = "application/json"

    t0 = time.perf_counter()
    req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            dur_ms = round((time.perf_counter() - t0) * 1000, 1)
            raw = resp.read()
            text = raw.decode("utf-8", errors="replace")
            try:
                parsed_json = json.loads(text)
            except Exception:
                parsed_json = None
            return {
                "ok": True,
                "status": resp.status,
                "duration_ms": dur_ms,
                "headers": dict(resp.headers),
                "is_json": parsed_json is not None,
                "json": parsed_json,
                "text": text if parsed_json is None else None,
                "size_bytes": len(raw),
            }
    except urllib.error.HTTPError as exc:
        dur_ms = round((time.perf_counter() - t0) * 1000, 1)
        raw = exc.read()
        text = raw.decode("utf-8", errors="replace")
        try:
            parsed_json = json.loads(text)
        except Exception:
            parsed_json = None
        return {
            "ok": True,
            "status": exc.code,
            "duration_ms": dur_ms,
            "headers": dict(exc.headers),
            "is_json": parsed_json is not None,
            "json": parsed_json,
            "text": text if parsed_json is None else None,
            "size_bytes": len(raw),
        }
    except Exception as exc:
        dur_ms = round((time.perf_counter() - t0) * 1000, 1)
        return {"ok": False, "error": str(exc), "duration_ms": dur_ms}


def get_about_info(site_path: str, php_bin: str = "php") -> dict:
    """Run `php artisan about --json` to get environment & driver configurations."""
    path = Path(site_path).resolve()
    cmd = [php_bin, "artisan", "about", "--json"]
    try:
        proc = subprocess.run(cmd, cwd=str(path), capture_output=True, text=True, timeout=12)
        if proc.returncode == 0 and proc.stdout.strip().startswith("{"):
            return {"ok": True, "about": json.loads(proc.stdout)}
        err_msg = proc.stderr.strip()
    except Exception as exc:
        err_msg = str(exc)
    return {"ok": False, "error": err_msg or "about command failed"}


def get_events_list(site_path: str, php_bin: str = "php") -> dict:
    """Run `php artisan event:list --json` to get events and listeners."""
    path = Path(site_path).resolve()
    cmd = [php_bin, "artisan", "event:list", "--json"]
    try:
        proc = subprocess.run(cmd, cwd=str(path), capture_output=True, text=True, timeout=12)
        if proc.returncode == 0 and (proc.stdout.strip().startswith("[") or proc.stdout.strip().startswith("{")):
            return {"ok": True, "events": json.loads(proc.stdout)}
        err_msg = proc.stderr.strip()
    except Exception as exc:
        err_msg = str(exc)
    return {"ok": False, "error": err_msg or "event:list command failed"}


_SECRET_CONFIG_KEY = re.compile(r"key|secret|password|token|passphrase|credentials|dsn|private", re.I)


def _mask_config_secrets(value, key=""):
    """Hide values like app.key or database.connections.mysql.password from the config viewer."""
    if isinstance(value, dict):
        return {k: _mask_config_secrets(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_mask_config_secrets(v, key) for v in value]
    if key and _SECRET_CONFIG_KEY.search(key) and isinstance(value, str) and value:
        return "••••••" + value[-4:] if len(value) > 12 else "••••••"
    return value


def get_config_show(site_path: str, config_name: str = "app", php_bin: str = "php") -> dict:
    """Run `artisan config:show <file> --json` or evaluate config with fallback."""
    path = Path(site_path).resolve()
    clean_name = re.sub(r"[^a-zA-Z0-9_\-]", "", config_name.strip() or "app")

    # config:show has no --json option; calling it with one logs an ERROR in the project's laravel.log.
    res = run_php_json(path, php_bin=php_bin, script=f"return config({json.dumps(clean_name)});", timeout=10)
    if res.get("ok") and res.get("data") is not None:
        return {"ok": True, "config": _mask_config_secrets(res["data"]), "name": clean_name}

    # 3. Read config/<name>.php file directly
    cfg_file = path / "config" / f"{clean_name}.php"
    if cfg_file.is_file():
        return {"ok": True, "raw": cfg_file.read_text(encoding="utf-8", errors="replace"), "name": clean_name}

    return {"ok": False, "error": f"Configuration '{clean_name}' could not be loaded."}


def list_mailables(site_path: str) -> list[str]:
    """Scan app/Mail directory for Mailable classes."""
    path = Path(site_path).resolve()
    mail_dir = path / "app" / "Mail"
    mailables = []
    if mail_dir.is_dir():
        for p in sorted(mail_dir.rglob("*.php")):
            rel = p.relative_to(mail_dir).with_suffix("")
            mailables.append(str(rel).replace("/", "\\"))
    return mailables


def render_mailable(site_path: str, mailable_name: str, php_bin: str = "php") -> dict:
    """Instantiate and render a Mailable to HTML for previewing."""
    path = Path(site_path).resolve()
    full_class = mailable_name if mailable_name.startswith("App\\") else f"App\\Mail\\{mailable_name}"

    php_script = f"""
    try {{
        $ref = new ReflectionClass('{full_class}');
        $ctor = $ref->getConstructor();
        $args = [];
        if ($ctor) {{
            foreach ($ctor->getParameters() as $param) {{
                $type = $param->getType();
                $typeName = $type ? $type->getName() : '';
                if ($param->isDefaultValueAvailable()) {{
                    $args[] = $param->getDefaultValue();
                }} elseif ($typeName === 'string') {{
                    $args[] = 'Sample ' . $param->getName();
                }} elseif ($typeName === 'int' || $typeName === 'float') {{
                    $args[] = 1;
                }} elseif ($typeName === 'bool') {{
                    $args[] = true;
                }} elseif ($typeName === 'array') {{
                    $args[] = [];
                }} elseif (class_exists($typeName)) {{
                    if (method_exists($typeName, 'factory')) {{
                        try {{ $args[] = $typeName::factory()->make(); continue; }} catch (\\Throwable $e) {{}}
                    }}
                    try {{
                        $args[] = (new ReflectionClass($typeName))->newInstanceWithoutConstructor();
                    }} catch (\\Throwable $e) {{
                        $args[] = null;
                    }}
                }} else {{
                    $args[] = null;
                }}
            }}
        }}
        $mailable = $ref->newInstanceArgs($args);
        if (method_exists($mailable, 'render')) {{
            $html = $mailable->render();
            echo json_encode(['ok' => true, 'html' => $html]);
        }} else {{
            echo json_encode(['ok' => false, 'error' => 'Class does not provide a render() method.']);
        }}
    }} catch (\\Throwable $e) {{
        echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
    }}
    """
    cmd = [php_bin, "artisan", "tinker", "--execute", php_script]
    try:
        proc = subprocess.run(cmd, cwd=str(path), capture_output=True, text=True, timeout=15)
        out = proc.stdout.strip()
        idx = out.find('{"ok":')
        if idx != -1:
            return json.loads(out[idx:])
        return {"ok": False, "error": proc.stderr.strip() or out or "Failed to render mailable"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


_PHP_LANG_DUMP = r"""
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
$dir = $argv[1]; $out = [];
$flat = function ($arr, $prefix) use (&$flat, &$row) {
    foreach ($arr as $k => $v) {
        $key = $prefix . '.' . $k;
        if (is_array($v)) { $flat($v, $key); } elseif (is_scalar($v) || $v === null) { $row[$key] = (string) $v; }
    }
};
foreach (glob($dir . '/*', GLOB_ONLYDIR) ?: [] as $locDir) {
    $loc = basename($locDir);
    if ($loc === 'vendor') { continue; }
    $out[$loc] = [];
    foreach (glob($locDir . '/*.php') ?: [] as $file) {
        $row = [];
        try { $arr = (function ($f) { return include $f; })($file); } catch (\Throwable $e) { $arr = null; }
        if (is_array($arr)) { $flat($arr, basename($file, '.php')); }
        foreach ($row as $k => $v) { $out[$loc][$k] = ['v' => $v, 'f' => substr($file, strlen($dir) + 1)]; }
    }
}
echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
"""


def _lang_dir(path: Path) -> Path | None:
    for d in (path / "lang", path / "resources" / "lang"):
        if d.is_dir():
            return d
    return None


def get_translations(site_path: str, php_bin: str = "php") -> dict:
    """Read all translation keys across JSON (`lang/ar.json`) and PHP group files
    (`lang/ar/orders.php`, shown as `orders.key` the way `__()` addresses them)."""
    path = Path(site_path).resolve()
    target_dir = _lang_dir(path)

    locales: set[str] = set()
    json_translations: dict[str, dict[str, str]] = {}
    php_translations: dict[str, dict[str, dict]] = {}

    if target_dir:
        for jf in sorted(target_dir.glob("*.json")):
            locales.add(jf.stem)
            try:
                parsed = json.loads(jf.read_text(encoding="utf-8"))
                json_translations[jf.stem] = {k: v for k, v in parsed.items() if isinstance(v, str)} \
                    if isinstance(parsed, dict) else {}
            except Exception:
                json_translations[jf.stem] = {}

        if any(target_dir.glob("*/*.php")):
            try:
                proc = subprocess.run(
                    [php_bin, "-r", _PHP_LANG_DUMP, str(target_dir)],
                    capture_output=True, text=True, timeout=15, cwd=str(path),
                )
                data = json.loads(proc.stdout or "{}")
                if isinstance(data, dict):
                    php_translations = {loc: v for loc, v in data.items() if isinstance(v, dict)}
                    locales.update(php_translations)
            except Exception:
                pass

    if not locales:
        # A project without a lang/ folder yet: start from the configured locale.
        import envfile
        env_file = path / ".env"
        env = envfile.to_dict(env_file.read_text(encoding="utf-8", errors="replace")) if env_file.is_file() else {}
        locales = {env.get("APP_LOCALE") or "en"}

    sorted_locales = sorted(locales)
    rows = []

    php_keys = sorted({k for data in php_translations.values() for k in data})
    for k in php_keys:
        values, files = {}, {}
        for loc in sorted_locales:
            item = php_translations.get(loc, {}).get(k)
            values[loc] = item["v"] if item else None
            if item:
                files[loc] = item["f"]
        rows.append({"key": k, "source": "php", "values": values, "files": files,
                     "missing": any(not values[loc] for loc in sorted_locales)})

    json_keys = sorted({k for data in json_translations.values() for k in data} - set(php_keys))
    for k in json_keys:
        values = {loc: json_translations.get(loc, {}).get(k) for loc in sorted_locales}
        rows.append({"key": k, "source": "json", "values": values,
                     "missing": any(not values[loc] for loc in sorted_locales)})

    return {
        "ok": True,
        "lang_dir": str(target_dir.relative_to(path)) if target_dir else "lang",
        "locales": sorted_locales,
        "total_keys": len(rows),
        "missing_keys_count": sum(1 for r in rows if r["missing"]),
        "rows": rows,
    }


def save_translation(site_path: str, locale: str, key: str, value: str) -> dict:
    """Save or update a translation key in the JSON translation file."""
    path = Path(site_path).resolve()
    target_dir = _lang_dir(path) or path / "lang"
    target_dir.mkdir(parents=True, exist_ok=True)

    safe_loc = re.sub(r"[^a-zA-Z0-9_\-]", "", locale.strip() or "en")
    file_path = target_dir / f"{safe_loc}.json"
    data = {}
    if file_path.is_file():
        try:
            parsed = json.loads(file_path.read_text(encoding="utf-8"))
            if isinstance(parsed, dict):
                data = parsed
        except Exception:
            data = {}

    if value == "":
        data.pop(key, None)
    else:
        data[key] = value

    file_path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {"ok": True, "locale": safe_loc, "key": key, "value": value}


def get_snapshots_dir(site_name: str) -> Path:
    sdir = sites.CONFIG_DIR / "snapshots" / site_name
    try:
        sdir.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return sdir


def list_db_snapshots(site_name: str) -> list[dict]:
    sdir = get_snapshots_dir(site_name)
    manifest = sdir / "snapshots.json"
    if not manifest.is_file():
        return []
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
        items = []
        for s in data:
            f = sdir / s.get("filename", "")
            if f.is_file():
                s["size_bytes"] = f.stat().st_size
                items.append(s)
        return sorted(items, key=lambda x: x.get("created_at", ""), reverse=True)
    except Exception:
        return []


def create_db_snapshot(site_path: str, site_name: str, name: str, description: str = "") -> dict:
    sdir = get_snapshots_dir(site_name)
    now_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_name = re.sub(r"[^a-zA-Z0-9_\-]", "_", name.strip() or "snapshot")
    filename = f"{safe_name}_{now_str}.sql.gz"

    res = create_backup(site_path, backup_type="db", custom_name=filename)
    if not res.get("ok"):
        return res

    bdir = get_backups_dir(site_path, create=False)
    src_file = bdir / filename
    dst_file = sdir / filename
    if src_file.is_file():
        shutil.move(str(src_file), str(dst_file))

    commit_hash = ""
    try:
        proc = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=site_path, capture_output=True, text=True, timeout=3)
        if proc.returncode == 0:
            commit_hash = proc.stdout.strip()
    except Exception:
        pass

    snap_id = str(uuid.uuid4())[:8]
    item = {
        "id": snap_id,
        "name": name.strip() or safe_name,
        "description": description.strip(),
        "filename": filename,
        "created_at": datetime.datetime.now().isoformat(),
        "tables_count": res.get("tables_count", 0),
        "git_commit": commit_hash,
    }

    manifest = sdir / "snapshots.json"
    items = []
    if manifest.is_file():
        try:
            items = json.loads(manifest.read_text(encoding="utf-8"))
        except Exception:
            pass
    items.append(item)
    manifest.write_text(json.dumps(items, indent=2), encoding="utf-8")

    return {"ok": True, "snapshot": item}


def restore_db_snapshot(site_path: str, site_name: str, snapshot_id: str) -> dict:
    sdir = get_snapshots_dir(site_name)
    manifest = sdir / "snapshots.json"
    if not manifest.is_file():
        return {"ok": False, "error": "No snapshots found"}
    try:
        items = json.loads(manifest.read_text(encoding="utf-8"))
        target = next((s for s in items if s["id"] == snapshot_id), None)
        if not target:
            return {"ok": False, "error": f"Snapshot {snapshot_id} not found"}
        filename = target["filename"]
        snap_file = sdir / filename
        if not snap_file.is_file():
            return {"ok": False, "error": f"Snapshot file {filename} missing on disk"}

        bdir = get_backups_dir(site_path, create=True)
        tmp_dst = bdir / filename
        shutil.copy2(str(snap_file), str(tmp_dst))
        try:
            res = restore_backup(site_path, filename)
        finally:
            tmp_dst.unlink(missing_ok=True)
        return res
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def delete_db_snapshot(site_name: str, snapshot_id: str) -> dict:
    sdir = get_snapshots_dir(site_name)
    manifest = sdir / "snapshots.json"
    if not manifest.is_file():
        return {"ok": False, "error": "Manifest not found"}
    try:
        items = json.loads(manifest.read_text(encoding="utf-8"))
        target = next((s for s in items if s["id"] == snapshot_id), None)
        if target:
            (sdir / target.get("filename", "")).unlink(missing_ok=True)
            items = [s for s in items if s["id"] != snapshot_id]
            manifest.write_text(json.dumps(items, indent=2), encoding="utf-8")
            return {"ok": True}
        return {"ok": False, "error": "Snapshot not found"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def compare_env_with_server(site_path: str, remote_env_text: str) -> dict:
    """Compare local .env with remote server .env, masking secrets."""
    import envfile
    local_env_path = Path(site_path) / ".env"
    local_text = local_env_path.read_text(encoding="utf-8", errors="replace") if local_env_path.is_file() else ""
    local_data = envfile.to_dict(local_text)
    remote_data = envfile.to_dict(remote_env_text or "")

    all_keys = sorted(list(set(local_data.keys()) | set(remote_data.keys())))
    sensitive_patterns = re.compile(r"(key|secret|password|token|pwd|auth|private|cert)", re.I)

    comparison = []
    identical = 0
    different = 0
    local_only = 0
    remote_only = 0

    for k in all_keys:
        in_local = k in local_data
        in_remote = k in remote_data
        l_val = local_data.get(k, "")
        r_val = remote_data.get(k, "")
        is_secret = bool(sensitive_patterns.search(k))

        if in_local and not in_remote:
            status = "local_only"
            local_only += 1
        elif in_remote and not in_local:
            status = "remote_only"
            remote_only += 1
        elif l_val == r_val:
            status = "identical"
            identical += 1
        else:
            status = "different"
            different += 1

        comparison.append({
            "key": k,
            "status": status,
            "is_secret": is_secret,
            "local_val": ("••••••••" if is_secret and l_val else l_val) if in_local else None,
            "remote_val": ("••••••••" if is_secret and r_val else r_val) if in_remote else None,
            "raw_local_val": l_val if in_local else None,
            "raw_remote_val": r_val if in_remote else None,
        })

    return {
        "ok": True,
        "total_keys": len(all_keys),
        "identical": identical,
        "different": different,
        "local_only": local_only,
        "remote_only": remote_only,
        "keys": comparison,
    }


def artisan_make(site_path: str, make_type: str, name: str, flags: list[str] = None, php_bin: str = "php") -> dict:
    """Run `php artisan make:<type> <name> [flags]` and locate created files."""
    path = Path(site_path).resolve()
    valid_types = {
        "model", "controller", "migration", "request", "job", "event",
        "listener", "seeder", "factory", "mail", "notification", "resource",
        "rule", "command", "middleware", "cast", "channel", "scope"
    }
    mtype = make_type.lower().strip()
    if mtype not in valid_types:
        return {"ok": False, "error": f"Invalid make type '{mtype}'"}

    name = name.strip()
    if not name:
        return {"ok": False, "error": "Name is required"}

    cmd = [php_bin, "artisan", f"make:{mtype}", name]
    if flags:
        for f in flags:
            if f and f.startswith("-"):
                cmd.append(f)

    try:
        proc = subprocess.run(cmd, cwd=str(path), capture_output=True, text=True, timeout=15)
        out = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
        ok = proc.returncode == 0

        created_files = []
        for line in out.splitlines():
            m = re.search(r"\[([a-zA-Z0-9_\-\./\\]+\.php)\]", line)
            if m:
                created_files.append(m.group(1))

        return {
            "ok": ok,
            "output": out.strip(),
            "created_files": created_files,
            "cmd": " ".join(cmd),
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def check_laravel_upgrade(site_path: str, target_major: int = None, php_bin: str = "php") -> dict:
    """Analyze current framework version and check compatibility with next major version."""
    path = Path(site_path).resolve()
    composer_json = path / "composer.json"
    composer_lock = path / "composer.lock"

    if not composer_json.is_file():
        return {"ok": False, "error": "composer.json not found"}

    current_ver = ""
    if composer_lock.is_file():
        try:
            lock_data = json.loads(composer_lock.read_text(encoding="utf-8"))
            for pkg in lock_data.get("packages", []):
                if pkg.get("name") == "laravel/framework":
                    current_ver = pkg.get("version", "").lstrip("v")
                    break
        except Exception:
            pass

    if not current_ver:
        try:
            cjson = json.loads(composer_json.read_text(encoding="utf-8"))
            current_ver = cjson.get("require", {}).get("laravel/framework", "")
        except Exception:
            pass

    cur_major = 10
    m = re.search(r"(\d+)\.", current_ver)
    if m:
        cur_major = int(m.group(1))

    # The newest stable major on Packagist; "current + 1" may not be released yet.
    latest_major = None
    try:
        req = urllib.request.Request("https://repo.packagist.org/p2/laravel/framework.json",
                                     headers={"User-Agent": "laravel-dev-tool"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            releases = json.loads(resp.read().decode("utf-8"))["packages"]["laravel/framework"]
        stable = [r["version"].lstrip("v") for r in releases if re.fullmatch(r"v?\d+\.\d+\.\d+", r.get("version", ""))]
        if stable:
            latest_major = max(int(v.split(".")[0]) for v in stable)
    except Exception:
        pass

    if not target_major and latest_major is not None and latest_major <= cur_major:
        return {
            "ok": True,
            "current_version": current_ver or f"{cur_major}.x",
            "target_version": f"{cur_major}.x",
            "latest_major": latest_major,
            "is_up_to_date": True,
            "upgrade_guide_url": "",
            "blockers": [],
            "blockers_count": 0,
        }
    target = target_major or (latest_major if latest_major and latest_major > cur_major else cur_major + 1)
    target_req = f"^{target}.0"

    cmd = ["composer", "why-not", "laravel/framework", target_req]
    blockers = []
    try:
        proc = subprocess.run(cmd, cwd=str(path), capture_output=True, text=True, timeout=20)
        output = (proc.stdout or "") + (proc.stderr or "")
        for line in output.splitlines():
            line = line.strip()
            if line and not line.startswith("Deprecation") and ("requires" in line or "satisfies" in line or "does not" in line):
                blockers.append(line)
    except Exception:
        pass

    guide_url = f"https://laravel.com/docs/{target}.x/upgrade"

    return {
        "ok": True,
        "current_version": current_ver or f"{cur_major}.x",
        "target_version": f"{target}.x",
        "target_constraint": target_req,
        "is_up_to_date": cur_major >= target,
        "latest_major": latest_major,
        "upgrade_guide_url": guide_url,
        "blockers": blockers[:20],
        "blockers_count": len(blockers),
    }



