#!/usr/bin/env bash

set -euo pipefail

# Non-PHP apps (Next.js, Nuxt, Vite, Node, Django). Nginx proxies <domain> to
# the app's local port; the desktop app starts and stops the dev server.

APP_TYPES="next nuxt vite node django"

detect_project_type() {
  local dir="$1"

  if [[ -f "$dir/artisan" ]]; then
    echo "laravel"
  elif [[ -f "$dir/manage.py" ]]; then
    echo "django"
  elif [[ -f "$dir/package.json" ]]; then
    if grep -qE '"next"[[:space:]]*:' "$dir/package.json"; then
      echo "next"
    elif grep -qE '"nuxt"[[:space:]]*:' "$dir/package.json"; then
      echo "nuxt"
    elif grep -qE '"vite"[[:space:]]*:' "$dir/package.json"; then
      echo "vite"
    else
      echo "node"
    fi
  else
    echo ""
  fi
}

app_runtime() {
  case "$1" in
    django) echo "python" ;;
    laravel) echo "php-fpm" ;;
    *) echo "node" ;;
  esac
}

js_package_manager() {
  local dir="$1"
  if [[ -f "$dir/pnpm-lock.yaml" ]]; then echo "pnpm"
  elif [[ -f "$dir/yarn.lock" ]]; then echo "yarn"
  elif [[ -f "$dir/bun.lockb" || -f "$dir/bun.lock" ]]; then echo "bun"
  else echo "npm"
  fi
}

validate_app_type() {
  if [[ " $APP_TYPES " != *" $1 "* ]]; then
    echo "Error: unsupported app type '$1'. Use one of: $APP_TYPES"
    exit 1
  fi
}

validate_app_port() {
  if [[ ! "$1" =~ ^[0-9]+$ ]] || (( $1 < 1024 || $1 > 65535 )); then
    echo "Error: invalid port '$1' (use 1024-65535)."
    exit 1
  fi
}

# Make sure <www>/<name> can be created by the desktop user even when the www
# folder is root-owned (/var/www): sudo creates the empty folder and hands it over.
prepare_project_dir() {
  local dir="$1"
  local parent
  parent="$(dirname "$dir")"
  if [[ -e "$dir" && -n "$(ls -A "$dir" 2>/dev/null)" ]]; then
    echo "Error: Project directory already exists: $dir"
    exit 1
  fi
  if mkdir -p "$parent" 2>/dev/null && [[ -w "$parent" ]]; then
    return 0
  fi
  echo "$parent is not writable by $(id -un) — creating $dir with sudo..."
  sudo_cmd mkdir -p "$dir"
  sudo_cmd chown "$(id -un):$(id -gn)" "$dir"
}

# Put an existing project into the www folder: move it, copy it, or add a
# symlink that points at where it already is. Prints nothing else on success.
adopt_project() {
  local mode="$1"
  local src="$2"
  local name="$3"
  local dest="$LARAVEL_SITES_DIR/$name"
  local use_sudo=""

  src="$(realpath "$src" 2>/dev/null || printf '%s' "$src")"
  if [[ ! -d "$src" ]]; then
    echo "Error: Path does not exist: $src"
    exit 1
  fi
  if [[ "$(realpath -m "$dest")" == "$src" ]]; then
    echo "Already in the www folder: $dest"
    return 0
  fi
  case "$(realpath -m "$LARAVEL_SITES_DIR")/" in
    "$src"/*) echo "Error: the www folder is inside the project; pick another www folder."; exit 1 ;;
  esac
  if [[ -e "$dest" || -L "$dest" ]]; then
    echo "Error: $dest already exists in the www folder. Choose another site name."
    exit 1
  fi
  if ! { mkdir -p "$LARAVEL_SITES_DIR" 2>/dev/null && [[ -w "$LARAVEL_SITES_DIR" ]]; }; then
    use_sudo=1
    require_system_access
    sudo_cmd mkdir -p "$LARAVEL_SITES_DIR"
  fi

  case "$mode" in
    move)
      echo "Moving $src -> $dest"
      if [[ -n "$use_sudo" ]]; then sudo_cmd mv -- "$src" "$dest"; else mv -- "$src" "$dest"; fi
      ;;
    copy)
      echo "Copying $src -> $dest (this can take a while for node_modules / vendor)"
      if [[ -n "$use_sudo" ]]; then sudo_cmd cp -a -- "$src" "$dest"; else cp -a -- "$src" "$dest"; fi
      ;;
    symlink)
      echo "Linking $dest -> $src"
      if [[ -n "$use_sudo" ]]; then sudo_cmd ln -s -- "$src" "$dest"; else ln -s -- "$src" "$dest"; fi
      ;;
    *)
      echo "Error: unknown mode '$mode' (use move, copy or symlink)"
      exit 1
      ;;
  esac
  if [[ -n "$use_sudo" && "$mode" != "symlink" ]]; then
    sudo_cmd chown -R "$(id -un):$(id -gn)" "$dest"
  fi
}

create_nginx_proxy() {
  local name="$1"
  local port="$2"
  local domain="${3:-${name}.test}"
  local template="$BASE_DIR/config/nginx-proxy-template.conf"
  local config

  if [[ ! -f "$template" ]]; then
    echo "Error: nginx proxy template not found"
    exit 1
  fi

  local aliases=""
  local wildcard="1"
  if declare -F get_project_field >/dev/null 2>&1; then
    aliases="$(get_project_field "$name" "ALIASES" 2>/dev/null || true)"
    wildcard="$(get_project_field "$name" "WILDCARD" 2>/dev/null || echo "1")"
  fi
  local server_names="$domain"
  if [[ "$wildcard" != "0" ]]; then
    server_names="$server_names *.$domain"
  fi
  if [[ -n "$aliases" ]]; then
    server_names="$server_names $aliases"
  fi

  config="$(get_nginx_config_path "$name")"
  ensure_nginx_include_exists
  sudo_cmd mkdir -p "$(dirname "$config")"
  sed -e "s#server_name PROJECT_DOMAIN \*\.PROJECT_DOMAIN;#server_name $server_names;#g" \
      -e "s#PROJECT_DOMAIN#$domain#g" -e "s#APP_PORT#$port#g" -e "s#PROJECT#$name#g" "$template" | sudo_cmd tee "$config" >/dev/null
  echo "Nginx: http://$domain -> 127.0.0.1:$port"
  activate_nginx_site "$name" "$config" "$domain"
}

link_app() {
  local name="$1"
  local path="$2"
  local type="${3:-}"
  local port="${4:-}"
  local domain="${5:-}"

  path="$(realpath "$path" 2>/dev/null || printf '%s' "$path")"
  if [[ ! -d "$path" ]]; then
    echo "Error: Path does not exist: $path"
    exit 1
  fi

  type="${type:-$(detect_project_type "$path")}"
  if [[ "$type" == "laravel" ]]; then
    link_project "$name" "$path" "" "$domain"
    return
  fi
  validate_app_type "$type"
  port="${port:-$(allocate_project_port)}"
  validate_app_port "$port"
  domain="${domain:-${name}.test}"

  echo "Linking $type app '$name' from '$path' on port $port..."
  create_nginx_proxy "$name" "$port" "$domain"

  write_project_record "$name" \
    "PROJECT_TYPE" "$type" \
    "RUNTIME" "$(app_runtime "$type")" \
    "PROJECT_PATH" "$path" \
    "DOMAIN" "$domain" \
    "PORT" "$port" \
    "RUN_MODE" "dev" \
    "RUN_COMMAND" "" \
    "PACKAGE_MANAGER" "$( [[ "$type" == "django" ]] && echo "" || js_package_manager "$path")" \
    "STATUS" "ready"

  echo "Successfully linked $type app: $name"
  echo "Start it from Laravel Dev, then open http://$domain"
}

# Scaffold a new app in the sites directory, install dependencies and link it.
create_app() {
  local type="$1"
  local name="$2"
  local port="${3:-}"
  local domain="${4:-}"
  local dir="$LARAVEL_SITES_DIR/$name"

  prepare_project_dir "$dir"

  case "$type" in
    next)
      command -v npx >/dev/null 2>&1 || { echo "Error: Node.js (npx) is not installed."; exit 1; }
      (cd "$LARAVEL_SITES_DIR" && CI=1 npx --yes create-next-app@latest "$name" --yes --skip-install --disable-git)
      (cd "$dir" && npm install)
      ;;
    nuxt)
      command -v npx >/dev/null 2>&1 || { echo "Error: Node.js (npx) is not installed."; exit 1; }
      (cd "$LARAVEL_SITES_DIR" && CI=1 npx --yes nuxi@latest init "$name" --template minimal \
        --packageManager npm --no-gitInit --no-install --modules= --force)
      (cd "$dir" && npm install)
      ;;
    django)
      command -v python3 >/dev/null 2>&1 || { echo "Error: python3 is not installed."; exit 1; }
      mkdir -p "$dir"
      python3 -m venv "$dir/.venv" || { rm -rf "${dir:?}/.venv"; echo "Error: could not create a virtualenv (install python3-venv)."; exit 1; }
      "$dir/.venv/bin/pip" install --upgrade pip django
      "$dir/.venv/bin/django-admin" startproject config "$dir"
      "$dir/.venv/bin/pip" freeze >"$dir/requirements.txt"
      ;;
    *)
      echo "Error: cannot create apps of type '$type' (supported: next, nuxt, django)."
      exit 1
      ;;
  esac

  link_app "$name" "$dir" "$type" "$port" "$domain"
}

repair_app() {
  local name="$1"
  local port domain
  port="$(get_project_field "$name" "PORT" 2>/dev/null || true)"
  domain="$(get_project_field "$name" "DOMAIN" 2>/dev/null || true)"
  if [[ -z "$port" ]]; then
    echo "Error: no port recorded for '$name'. Unlink and link it again."
    exit 1
  fi
  create_nginx_proxy "$name" "$port" "${domain:-${name}.test}"
  echo "Repaired nginx proxy for: $name"
}

expose_project() {
  local project="$1"
  local mode="${2:-tunnel}"
  validate_project_name "$project"

  local site_path="$LARAVEL_SITES_DIR/$project"
  if [[ ! -d "$site_path" ]]; then
    site_path="$(get_project_field "$project" "PATH" 2>/dev/null || echo "$site_path")"
  fi
  if [[ ! -d "$site_path" ]]; then
    echo "Error: project '$project' not found at '$site_path'."
    exit 1
  fi

  local domain
  domain="$(get_project_field "$project" "DOMAIN" 2>/dev/null || echo "${project}.test")"
  local port
  port="$(get_project_field "$project" "PORT" 2>/dev/null || true)"

  if [[ "$mode" == "lan" ]]; then
    local lan_ip lan_port
    lan_ip="$(lan_ip)"
    lan_port="$(get_project_field "$project" "LAN_PORT" 2>/dev/null || true)"
    if [[ -n "$lan_port" ]]; then
      echo "LAN access for $project: http://${lan_ip}:${lan_port}"
    elif [[ -n "$port" && "$port" != "80" ]]; then
      echo "LAN access for $project: http://${lan_ip}:${port}"
    else
      echo "Starting LAN server for $project on 0.0.0.0:8000..."
      echo "LAN access: http://${lan_ip}:8000"
      cd "$site_path"
      php artisan serve --host=0.0.0.0 --port=8000
    fi
  else
    if ! command -v cloudflared >/dev/null 2>&1; then
      echo "Error: cloudflared is not installed. Please install cloudflared to use public tunnels."
      exit 1
    fi
    if [[ -n "$port" ]]; then
      echo "Creating Cloudflare Tunnel for $project (port $port)..."
      exec cloudflared tunnel --url "http://127.0.0.1:${port}"
    else
      echo "Creating Cloudflare Tunnel for $domain..."
      exec cloudflared tunnel --url "http://127.0.0.1:80" --http-host-header "$domain"
    fi
  fi
}
