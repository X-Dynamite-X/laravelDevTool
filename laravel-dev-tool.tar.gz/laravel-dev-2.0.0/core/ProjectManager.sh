#!/usr/bin/env bash

set -euo pipefail

update_env_key() {
  local env_file="$1"
  local key="$2"
  local value="$3"
  local tmp

  # Replace the first occurrence in place (keeps the file's ordering and
  # comments), drop later duplicates, and append only when the key is missing.
  # Values go through ENVIRON so passwords containing / & or \ stay intact.
  tmp="$(mktemp)"
  ENV_KEY="$key" ENV_VALUE="$value" awk '
    BEGIN { key = ENVIRON["ENV_KEY"]; value = ENVIRON["ENV_VALUE"]; done = 0 }
    index($0, key "=") == 1 {
      if (!done) { print key "=" value; done = 1 }
      next
    }
    { print }
    END { if (!done) print key "=" value }
  ' "$env_file" >"$tmp"
  cat "$tmp" >"$env_file"
  rm -f "$tmp"
}

# Print the current (unquoted) value of KEY from an .env file.
get_env_key() {
  local env_file="$1"
  local key="$2"
  [[ -f "$env_file" ]] || return 0
  ENV_KEY="$key" awk '
    BEGIN { key = ENVIRON["ENV_KEY"] }
    index($0, key "=") == 1 {
      v = substr($0, length(key) + 2)
      gsub(/^["\047]|["\047]$/, "", v)
      print v
      exit
    }
  ' "$env_file"
}

project_env_domain() {
  local name="$1"
  local domain=""
  if declare -F get_project_field >/dev/null 2>&1; then
    domain="$(get_project_field "$name" "DOMAIN" 2>/dev/null || true)"
  fi
  echo "${domain:-${name}.test}"
}

# Database name a project should use: an existing project keeps the
# DB_DATABASE it already has, a fresh one is named after the project.
project_database_name() {
  local dir="$1"
  local name="$2"
  local current="" connection=""
  current="$(get_env_key "$dir/.env" "DB_DATABASE")"
  connection="$(get_env_key "$dir/.env" "DB_CONNECTION")"
  if [[ -n "$current" && "$connection" != "sqlite" && "$current" =~ ^[A-Za-z0-9_-]+$ ]]; then
    echo "$current"
  else
    echo "$name"
  fi
}

# configure_project_env DIR NAME [MODE] [DOMAIN]
#   MODE=fresh    (new projects) – force DB name, file sessions/cache.
#   MODE=preserve (link/repair)  – keep the project's own DB name and drivers.
configure_project_env() {
  local dir="$1"
  local name="$2"
  local mode="${3:-fresh}"
  local domain="${4:-}"
  local env_file="$dir/.env"

  if [[ ! -f "$env_file" ]]; then
    return 0
  fi

  # Map DB_TYPE values to Laravel connection driver names.
  local db_connection
  case "${DB_TYPE:-mysql}" in
    mariadb)                   db_connection="mysql"   ;;  # MariaDB uses the mysql driver in Laravel
    postgresql|postgres|pgsql) db_connection="pgsql"   ;;
    sqlite)                    db_connection="sqlite"  ;;
    *)                         db_connection="${DB_TYPE:-mysql}" ;;
  esac

  local db_name="$name"
  if [[ "$mode" == "preserve" ]]; then
    db_name="$(project_database_name "$dir" "$name")"
  fi

  local default_port="3306"
  if [[ "$db_connection" == "pgsql" ]]; then
    default_port="5432"
  fi

  update_env_key "$env_file" "DB_CONNECTION" "$db_connection"
  update_env_key "$env_file" "DB_HOST" "$DB_HOST"
  update_env_key "$env_file" "DB_PORT" "${DB_PORT:-$default_port}"
  update_env_key "$env_file" "DB_DATABASE" "$db_name"
  update_env_key "$env_file" "DB_USERNAME" "$DB_USER"
  update_env_key "$env_file" "DB_PASSWORD" "${DB_PASSWORD:-}"

  if [[ "$mode" != "preserve" ]]; then
    update_env_key "$env_file" "SESSION_DRIVER" "file"
    update_env_key "$env_file" "CACHE_STORE" "file"
  fi

  # Every site is served over HTTPS now; keep generated URLs in sync so
  # assets/redirects don't fall back to http:// (mixed content).
  update_env_key "$env_file" "APP_URL" "https://${domain:-$(project_env_domain "$name")}"

  # If Mailpit is installed, route local development emails to Mailpit SMTP
  if command -v mailpit >/dev/null 2>&1; then
    local cur_mailer
    cur_mailer="$(sed -nE 's/^[[:space:]]*MAIL_MAILER=([^#;]+).*/\1/p' "$env_file" | head -n1 | tr -d '\042\047' | xargs)"
    if [[ "$mode" != "preserve" || -z "$cur_mailer" || "$cur_mailer" == "log" || "$cur_mailer" == "smtp" ]]; then
      update_env_key "$env_file" "MAIL_MAILER" "smtp"
      update_env_key "$env_file" "MAIL_HOST" "127.0.0.1"
      update_env_key "$env_file" "MAIL_PORT" "1025"
      update_env_key "$env_file" "MAIL_USERNAME" "null"
      update_env_key "$env_file" "MAIL_PASSWORD" "null"
      update_env_key "$env_file" "MAIL_ENCRYPTION" "null"
    fi
  fi
}

detect_nginx_user() {
  local nginx_conf="/etc/nginx/nginx.conf"
  local user=""

  if [[ -f "$nginx_conf" ]]; then
    user="$(sed -nE 's/^[[:space:]]*user[[:space:]]+([^ ;]+).*/\1/p' "$nginx_conf" | head -n1)"
  fi

  if [[ -n "$user" ]]; then
    echo "$user"
    return 0
  fi

  for user in http www-data nginx; do
    if id -u "$user" >/dev/null 2>&1; then
      echo "$user"
      return 0
    fi
  done

  echo ""
}

detect_php_fpm_user() {
  local pool_files=(
    /etc/php/php-fpm.d/*.conf
    /etc/php-fpm.d/*.conf
    /etc/php/*/fpm/pool.d/*.conf
  )
  local file=""
  local user=""

  for file in "${pool_files[@]}"; do
    [[ -f "$file" ]] || continue
    user="$(sed -nE 's/^[[:space:]]*user[[:space:]]*=[[:space:]]*([^ ;]+).*/\1/p' "$file" | head -n1)"
    if [[ -n "$user" ]]; then
      echo "$user"
      return 0
    fi
  done

  for user in www-data http nginx; do
    if id -u "$user" >/dev/null 2>&1; then
      echo "$user"
      return 0
    fi
  done

  echo ""
}

grant_runtime_access() {
  local dir="$1"
  local runtime_users=()
  local runtime_user=""
  local path=""

  runtime_user="$(detect_nginx_user)"
  [[ -n "$runtime_user" ]] && runtime_users+=("$runtime_user")
  runtime_user="$(detect_php_fpm_user)"
  [[ -n "$runtime_user" ]] && runtime_users+=("$runtime_user")

  if [[ ${#runtime_users[@]} -eq 0 ]]; then
    chmod a+rx "$HOME" "$SITES_DIR" "$dir" "$dir/public" 2>/dev/null || true
    find "$dir" -type d -exec chmod a+rx {} \; 2>/dev/null || true
    find "$dir/public" -type f -exec chmod a+r {} \; 2>/dev/null || true
    return 0
  fi

  if command -v setfacl >/dev/null 2>&1; then
    for runtime_user in "${runtime_users[@]}"; do
      [[ -n "$runtime_user" ]] || continue
      for path in "$HOME" "$SITES_DIR" "$dir" "$dir/public"; do
        [[ -e "$path" ]] || continue
        setfacl -m "u:${runtime_user}:rx" "$path" 2>/dev/null || true
      done
      setfacl -R -m "u:${runtime_user}:rX" "$dir/public" 2>/dev/null || true
      setfacl -R -m "u:${runtime_user}:rwX" "$dir/storage" "$dir/bootstrap/cache" 2>/dev/null || true
      setfacl -dR -m "u:${runtime_user}:rwX" "$dir/storage" "$dir/bootstrap/cache" 2>/dev/null || true
    done
  else
    chmod a+rx "$HOME" "$SITES_DIR" "$dir" "$dir/public" 2>/dev/null || true
    find "$dir" -type d -exec chmod a+rx {} \; 2>/dev/null || true
    find "$dir/public" -type f -exec chmod a+r {} \; 2>/dev/null || true
  fi
}

fix_project_permissions() {
  local dir="$1"
  mkdir -p \
    "$dir/storage/framework/cache" \
    "$dir/storage/framework/sessions" \
    "$dir/storage/framework/views" \
    "$dir/storage/logs" \
    "$dir/bootstrap/cache"

  find "$dir/storage" "$dir/bootstrap/cache" -type d -exec chmod u+rwx {} \; || true
  find "$dir/storage" "$dir/bootstrap/cache" -type d -exec chmod g+rwxs {} \; || true

  # Prefer ACL for php-fpm user when available, no sudo required for owner.
  if command -v setfacl >/dev/null 2>&1 && id -u www-data >/dev/null 2>&1; then
    setfacl -R -m u:www-data:rwx "$dir/storage" "$dir/bootstrap/cache" 2>/dev/null || true
    setfacl -dR -m u:www-data:rwx "$dir/storage" "$dir/bootstrap/cache" 2>/dev/null || true
  else
    # Local-dev fallback to avoid "File not found." and tempnam warnings.
    find "$dir/storage" "$dir/bootstrap/cache" -type d -exec chmod a+rwx {} \; || true
  fi

  # Clear generated runtime files that may be owned by another user.
  rm -f "$dir/storage/framework/views/"*.php 2>/dev/null || true
  rm -f "$dir/storage/framework/cache/data/"* 2>/dev/null || true
  rm -f "$dir/storage/logs/"*.log 2>/dev/null || true

  grant_runtime_access "$dir"
}

resolve_php_binary() {
  local requested_version="$1"
  local binary_name="php${requested_version}"
  local default_php_version=""

  if command -v "$binary_name" >/dev/null 2>&1; then
    echo "$binary_name"
    return 0
  fi

  if command -v php >/dev/null 2>&1; then
    default_php_version="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
    if [[ "$default_php_version" == "$requested_version" ]]; then
      echo "php"
      return 0
    fi
  fi

  echo ""
}

create_project() {
  local name="$1"
  local php_version="$2"
  local custom_domain="${3:-}"
  local starter="${4:-none}"
  local db_engine="${5:-sqlite}"
  local pest_flag="${6:-0}"
  local addons="${7:-}"
  local using_pkg="${8:-}"
  local git_flag="${9:-0}"
  local boost_flag="${10:-0}"
  local dir="$LARAVEL_SITES_DIR/$name"
  local php_bin=""
  local domain="${custom_domain:-${name}.test}"

  # Domain / site availability check
  local nginx_conf
  nginx_conf="$(get_nginx_config_path "$name")"
  if [[ -f "$nginx_conf" ]]; then
    echo "Error: Site '$name' or domain '$domain' already has an active configuration" >&2
    exit 1
  fi

  prepare_project_dir "$dir"

  php_bin="$(resolve_php_binary "$php_version")"
  if [[ -z "$php_bin" ]]; then
    echo "Error: PHP $php_version binary not found."
    echo "Install php$php_version (or set default php to version $php_version)."
    exit 1
  fi

  if ! command -v composer >/dev/null 2>&1; then
    echo "Error: composer not found in PATH"
    exit 1
  fi

  local target_pkg="${using_pkg:-laravel/laravel}"
  echo "Creating project using $target_pkg..."
  "$php_bin" "$(command -v composer)" create-project --no-interaction "$target_pkg" "$dir"
  fix_project_permissions "$dir"

  # 1. Configure DB connection in .env if requested
  if [[ -f "$dir/.env" ]]; then
    if [[ "$db_engine" == "sqlite" ]]; then
      sed -i 's/^DB_CONNECTION=.*/DB_CONNECTION=sqlite/' "$dir/.env"
      sed -i 's/^DB_HOST=/#DB_HOST=/' "$dir/.env"
      sed -i 's/^DB_PORT=/#DB_PORT=/' "$dir/.env"
      sed -i 's/^DB_DATABASE=/#DB_DATABASE=/' "$dir/.env"
      sed -i 's/^DB_USERNAME=/#DB_USERNAME=/' "$dir/.env"
      sed -i 's/^DB_PASSWORD=/#DB_PASSWORD=/' "$dir/.env"
      mkdir -p "$dir/database" && touch "$dir/database/database.sqlite" || true
    elif [[ "$db_engine" == "pgsql" || "$db_engine" == "postgresql" ]]; then
      sed -i 's/^DB_CONNECTION=.*/DB_CONNECTION=pgsql/' "$dir/.env"
      sed -i 's/^DB_PORT=.*/DB_PORT=5432/' "$dir/.env"
    fi
  fi

  # 2. Testing framework (Pest)
  if [[ "$pest_flag" == "1" ]]; then
    (cd "$dir" && "$php_bin" "$(command -v composer)" require pestphp/pest --dev --no-interaction && "$php_bin" ./vendor/bin/pest --init --no-interaction || true)
  fi

  # 3. Starter kits (Laravel 12 / Breeze)
  case "$starter" in
    react|breeze-react)
      echo "Installing React starter kit..."
      (cd "$dir" && "$php_bin" "$(command -v composer)" require laravel/breeze --dev --no-interaction && "$php_bin" artisan breeze:install react --no-interaction || true)
      ;;
    vue|breeze-vue)
      echo "Installing Vue starter kit..."
      (cd "$dir" && "$php_bin" "$(command -v composer)" require laravel/breeze --dev --no-interaction && "$php_bin" artisan breeze:install vue --no-interaction || true)
      ;;
    livewire|breeze-livewire)
      echo "Installing Livewire starter kit..."
      (cd "$dir" && "$php_bin" "$(command -v composer)" require laravel/breeze --dev --no-interaction && "$php_bin" artisan breeze:install livewire --no-interaction || true)
      ;;
    blade|breeze-blade)
      echo "Installing Blade starter kit..."
      (cd "$dir" && "$php_bin" "$(command -v composer)" require laravel/breeze --dev --no-interaction && "$php_bin" artisan breeze:install blade --no-interaction || true)
      ;;
    api|breeze-api)
      echo "Installing API scaffolding..."
      (cd "$dir" && "$php_bin" "$(command -v composer)" require laravel/breeze --dev --no-interaction && "$php_bin" artisan breeze:install api --no-interaction || true)
      ;;
  esac

  # 4. Add-on packages (comma-separated: filament,api,horizon,telescope)
  if [[ -n "$addons" ]]; then
    local old_ifs="$IFS"
    IFS=','
    for addon in $addons; do
      addon="$(echo "$addon" | tr -d ' ')"
      case "$addon" in
        filament)
          echo "Installing Filament Admin Panel..."
          (cd "$dir" && "$php_bin" "$(command -v composer)" require filament/filament:"^3.2" -W --no-interaction && "$php_bin" artisan filament:install --panels -n || true)
          ;;
        api)
          if [[ "$starter" != "api" && "$starter" != "breeze-api" ]]; then
            echo "Installing Laravel Sanctum API..."
            (cd "$dir" && "$php_bin" artisan install:api -n || true)
          fi
          ;;
        horizon)
          echo "Installing Laravel Horizon..."
          (cd "$dir" && "$php_bin" "$(command -v composer)" require laravel/horizon --no-interaction && "$php_bin" artisan horizon:install -n || true)
          ;;
        telescope)
          echo "Installing Laravel Telescope..."
          (cd "$dir" && "$php_bin" "$(command -v composer)" require laravel/telescope --dev --no-interaction && "$php_bin" artisan telescope:install -n || true)
          ;;
      esac
    done
    IFS="$old_ifs"
  fi

  # 5. Build frontend assets if package.json exists and npm is available
  if [[ -f "$dir/package.json" ]] && command -v npm >/dev/null 2>&1; then
    echo "Compiling frontend assets..."
    (cd "$dir" && npm install --silent && npm run build --silent || true)
  fi

  # 6. Laravel Boost if requested
  if [[ "$boost_flag" == "1" ]]; then
    echo "Installing Laravel Boost..."
    (cd "$dir" && "$php_bin" "$(command -v composer)" require boostphp/boost --dev --no-interaction || true)
  fi

  # 7. Git repository initialization
  if [[ "$git_flag" == "1" ]] && command -v git >/dev/null 2>&1; then
    echo "Initializing Git repository..."
    (cd "$dir" && git init -b main >/dev/null 2>&1 && git add . >/dev/null 2>&1 && git commit -m "Initial commit via Laravel Dev" >/dev/null 2>&1 || true)
  fi

  fix_project_permissions "$dir"
  if declare -F write_project_record >/dev/null 2>&1; then
    write_project_record "$name" \
      "PROJECT_TYPE" "laravel" \
      "RUNTIME" "php-fpm" \
      "PHP_VERSION" "$php_version" \
      "APP_ROLE" "fullstack" \
      "STORAGE_ROOT" "$LARAVEL_SITES_DIR" \
      "PROJECT_PATH" "$dir" \
      "DOMAIN" "$domain" \
      "PORT" "80" \
      "RUN_COMMAND" "" \
      "INSTALL_COMMAND" "composer create-project laravel/laravel" \
      "EXPOSURE_MODE" "local" \
      "STATUS" "ready" \
      "PUBLIC_URL" ""
  fi

  # Setup Supervisor queue worker (only if AUTO_QUEUE_WORKER=1)
  if [[ "${AUTO_QUEUE_WORKER:-0}" == "1" ]] && declare -F supervisor_is_installed >/dev/null 2>&1; then
    if supervisor_is_installed || ensure_supervisor_installed; then
      create_supervisor_config "$name" "$dir" "$php_bin"
      reload_supervisor
      start_supervisor_worker "$name" || true
    fi
  fi
}

delete_project() {
  local name="$1"
  local dir="${2:-$LARAVEL_SITES_DIR/$name}"
  local project_type=""
  local domain=""
  local registered_dir=""

  if declare -F get_project_field >/dev/null 2>&1; then
    project_type="$(get_project_field "$name" "PROJECT_TYPE" 2>/dev/null || true)"
    registered_dir="$(get_project_field "$name" "PROJECT_PATH" 2>/dev/null || true)"
    domain="$(get_project_field "$name" "DOMAIN" 2>/dev/null || true)"
  fi
  dir="${registered_dir:-$dir}"
  domain="${domain:-${name}.test}"

  # Refuse to wipe obviously wrong targets (empty/corrupt registry entries).
  local resolved_dir=""
  resolved_dir="$(realpath -m "$dir" 2>/dev/null || printf '%s' "$dir")"
  if [[ -z "$resolved_dir" || "$resolved_dir" == "/" || "$resolved_dir" == "$(realpath -m "$HOME")" \
        || "$resolved_dir" == "$(realpath -m "$LARAVEL_SITES_DIR")" ]]; then
    echo "Error: refusing to delete unsafe project path: '$dir'"
    exit 1
  fi

  rm -rf "$resolved_dir"

  if declare -F remove_nginx_site >/dev/null 2>&1; then
    remove_nginx_site "$name"
  else
    sudo_cmd rm -f "/etc/nginx/sites-enabled/$name" "/etc/nginx/sites-enabled/$name.conf" 2>/dev/null || true
    sudo_cmd rm -f "/etc/nginx/sites-available/$name" "/etc/nginx/sites-available/$name.conf" 2>/dev/null || true
    sudo_cmd rm -f "/etc/nginx/conf.d/$name.conf" 2>/dev/null || true
  fi

  if [[ -f /etc/hosts ]]; then
    sudo_cmd sed -i "/^127\\.0\\.0\\.1[[:space:]]\\+${domain//./\\.}$/d" /etc/hosts || true
  fi

  if [[ "$project_type" == "laravel" || "$project_type" == "" ]]; then
    MYSQL_PWD="${DB_PASSWORD:-}" mysql -h "$DB_HOST" -P "${DB_PORT:-3306}" -u "$DB_USER" \
      -e "DROP DATABASE IF EXISTS \`$name\`;" || true
  fi

  # Remove Supervisor queue worker
  if declare -F supervisor_is_installed >/dev/null 2>&1; then
    if supervisor_is_installed; then
      remove_supervisor_config "$name"
      reload_supervisor
    fi
  fi

  if declare -F disable_project_cron >/dev/null 2>&1; then
    disable_project_cron "$name" >/dev/null || true
  fi
  if declare -F disable_backup_cron >/dev/null 2>&1; then
    disable_backup_cron "$name" >/dev/null || true
  fi

  sudo_cmd systemctl restart nginx || sudo_cmd service nginx restart || true

  if declare -F delete_project_record >/dev/null 2>&1; then
    delete_project_record "$name"
  fi

  echo "Deleted project: $name"
}

repair_project() {
  local name="$1"
  local dir="${2:-$SITES_DIR/$name}"
  local registered_dir=""

  # Read actual project path from registry if available
  if declare -F get_project_field >/dev/null 2>&1; then
    registered_dir="$(get_project_field "$name" "PROJECT_PATH" 2>/dev/null || true)"
  fi
  dir="${registered_dir:-$dir}"

  if [[ ! -d "$dir" ]]; then
    echo "Error: project not found: $dir"
    exit 1
  fi

  configure_project_env "$dir" "$name" preserve
  fix_project_permissions "$dir"
  echo "Repaired runtime permissions for: $name"
}

# Unlink/deregister a project from Laravel Dev without deleting the project files
unlink_project() {
  local name="$1"
  local dir="${2:-$SITES_DIR/$name}"
  local project_type=""
  local runtime=""

  if declare -F get_project_field >/dev/null 2>&1; then
    project_type="$(get_project_field "$name" "PROJECT_TYPE" 2>/dev/null || true)"
    runtime="$(get_project_field "$name" "RUNTIME" 2>/dev/null || true)"
    dir="$(get_project_field "$name" "PROJECT_PATH" 2>/dev/null || printf '%s' "$dir")"
  fi

  echo "Unlinking project '$name' from Laravel Dev (keeping files at $dir)..."

  # Remove Nginx config
  if declare -F remove_nginx_site >/dev/null 2>&1; then
    remove_nginx_site "$name"
  else
    sudo_cmd rm -f "/etc/nginx/sites-enabled/$name" "/etc/nginx/sites-enabled/$name.conf" 2>/dev/null || true
    sudo_cmd rm -f "/etc/nginx/sites-available/$name" "/etc/nginx/sites-available/$name.conf" 2>/dev/null || true
    sudo_cmd rm -f "/etc/nginx/conf.d/${name}.conf" 2>/dev/null || true
  fi

  # Remove domain from hosts file
  local domain="${name}.test"
  if declare -F get_project_field >/dev/null 2>&1; then
    domain="$(get_project_field "$name" "DOMAIN" 2>/dev/null || echo "${name}.test")"
  fi
  if [[ -f /etc/hosts ]]; then
    sudo_cmd sed -i "/^127\.0\.0\.1[[:space:]]\+${domain//./\.}$/d" /etc/hosts 2>/dev/null || true
    # Also remove wildcard subdomains
    sudo_cmd sed -i "/^127\.0\.0\.1[[:space:]]\+\*.${domain//./\.}$/d" /etc/hosts 2>/dev/null || true
  fi

  # Remove Supervisor queue worker config
  if declare -F supervisor_is_installed >/dev/null 2>&1; then
    if supervisor_is_installed; then
      remove_supervisor_config "$name"
      reload_supervisor
    fi
  fi

  if declare -F disable_project_cron >/dev/null 2>&1; then
    disable_project_cron "$name" >/dev/null || true
  fi
  if declare -F disable_backup_cron >/dev/null 2>&1; then
    disable_backup_cron "$name" >/dev/null || true
  fi

  # Restart nginx
  sudo_cmd systemctl restart nginx 2>/dev/null || sudo_cmd service nginx restart 2>/dev/null || true

  # Delete project registry record (keep files)
  if declare -F delete_project_record >/dev/null 2>&1; then
    delete_project_record "$name"
  fi

  echo "Project '$name' unlinked successfully. Files remain at: $dir"
}

# Apply the current global DB settings (DB_HOST, DB_PORT, DB_USER, DB_PASSWORD,
# DB_TYPE) to a project's .env without touching any other settings.
update_project_db() {
  local name="$1"
  local dir="${2:-$SITES_DIR/$name}"

  if [[ ! -d "$dir" ]]; then
    echo "Error: project not found: $dir"
    exit 1
  fi

  configure_project_env "$dir" "$name" preserve
  echo "Database configuration updated for: $name"
}

link_project() {
  local name="$1"
  local path="$2"
  local php_version="${3:-}"
  local custom_domain="${4:-}"
  local domain="${custom_domain:-${name}.test}"

  if [[ ! -d "$path" ]]; then
    echo "Error: Path does not exist: $path"
    exit 1
  fi

  if [[ ! -f "$path/artisan" ]]; then
    echo "Warning: Artisan not found in $path. Is this a Laravel project?"
  fi

  if [[ -z "$php_version" ]]; then
    php_version="$(default_php_version)"
  fi

  echo "Linking existing project '$name' from '$path' with domain '$domain'..."

  # Create database if missing (keep the project's own DB name if it has one)
  if declare -F create_database >/dev/null 2>&1; then
    create_database "$(project_database_name "$path" "$name")"
  fi

  # Setup Nginx
  create_nginx "$name" "$php_version" "$path" "$domain"

  # Configure .env and permissions
  configure_project_env "$path" "$name" preserve "$domain"
  fix_project_permissions "$path"

  # Setup Supervisor queue worker (only if AUTO_QUEUE_WORKER=1)
  if [[ "${AUTO_QUEUE_WORKER:-0}" == "1" ]] && declare -F supervisor_is_installed >/dev/null 2>&1; then
    local link_php_bin=""
    link_php_bin="$(resolve_php_binary "$php_version")"
    if [[ -n "$link_php_bin" ]]; then
      if supervisor_is_installed || ensure_supervisor_installed; then
        create_supervisor_config "$name" "$path" "$link_php_bin"
        reload_supervisor
        start_supervisor_worker "$name" || true
      fi
    fi
  fi

  if declare -F write_project_record >/dev/null 2>&1; then
    write_project_record "$name" \
      "PROJECT_TYPE" "laravel" \
      "RUNTIME" "php-fpm" \
      "PHP_VERSION" "$php_version" \
      "APP_ROLE" "fullstack" \
      "STORAGE_ROOT" "$LARAVEL_SITES_DIR" \
      "PROJECT_PATH" "$path" \
      "DOMAIN" "$domain" \
      "PORT" "80" \
      "RUN_COMMAND" "" \
      "INSTALL_COMMAND" "composer install" \
      "EXPOSURE_MODE" "local" \
      "STATUS" "ready" \
      "PUBLIC_URL" ""
  fi

  echo "Successfully linked project: $name"
}

isolate_project() {
  local name="$1"
  local version="$2"
  require_system_access

  if ! list_available_php_versions | grep -qx "$version"; then
    echo "Error: PHP $version is not installed. Run 'laravel-dev php-install $version' first."
    exit 1
  fi

  local dir
  dir="$(get_project_field "$name" "PROJECT_PATH" 2>/dev/null || echo "$LARAVEL_SITES_DIR/$name")"
  local php_bin
  php_bin="$(resolve_php_binary "$version")"

  update_project_record "$name" "PHP_VERSION" "$version"
  create_nginx "$name" "$version" "$dir" ""

  if [[ -f "/etc/supervisor/conf.d/laravel-dev-$name.conf" ]] && declare -F create_supervisor_config >/dev/null 2>&1; then
    create_supervisor_config "$name" "$dir" "$php_bin"
    reload_supervisor
    start_supervisor_worker "$name" || true
  fi

  if declare -F project_cron_enabled >/dev/null 2>&1 && project_cron_enabled "$name"; then
    enable_project_cron "$name" "$dir" "$php_bin"
  fi

  if [[ -d "$dir" && "${WRITE_PHP_VERSION_FILE:-1}" == "1" ]]; then
    printf "%s\n" "$version" > "$dir/.php-version"
  fi

  echo "Site '$name' isolated on PHP $version successfully."
}

unisolate_project() {
  local name="$1"
  require_system_access

  local def_version
  def_version="$(default_php_version)"
  local dir
  dir="$(get_project_field "$name" "PROJECT_PATH" 2>/dev/null || echo "$LARAVEL_SITES_DIR/$name")"
  local php_bin
  php_bin="$(resolve_php_binary "$def_version")"

  update_project_record "$name" "PHP_VERSION" ""
  create_nginx "$name" "$def_version" "$dir" ""

  if [[ -f "/etc/supervisor/conf.d/laravel-dev-$name.conf" ]] && declare -F create_supervisor_config >/dev/null 2>&1; then
    create_supervisor_config "$name" "$dir" "$php_bin"
    reload_supervisor
    start_supervisor_worker "$name" || true
  fi

  if declare -F project_cron_enabled >/dev/null 2>&1 && project_cron_enabled "$name"; then
    enable_project_cron "$name" "$dir" "$php_bin"
  fi

  if [[ -f "$dir/.php-version" ]]; then
    rm -f "$dir/.php-version"
  fi

  echo "Site '$name' returned to default PHP $def_version."
}

