#!/usr/bin/env bash

set -euo pipefail

# core/ProxyManager.sh - Manages reverse proxies to arbitrary local ports/Docker containers

proxy_file() {
  local cfg_dir="${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev"
  mkdir -p "$cfg_dir" 2>/dev/null || true
  echo "$cfg_dir/proxies.json"
}

proxy_list() {
  local fmt="${1:-text}"
  local file
  file="$(proxy_file)"

  if [[ "$fmt" == "--json" || "$fmt" == "json" ]]; then
    if [[ -f "$file" ]]; then
      cat "$file"
    else
      echo "[]"
    fi
    return 0
  fi

  if [[ ! -f "$file" ]] || ! grep -q '\[' "$file" 2>/dev/null; then
    echo "No proxies configured. Use 'laravel-dev proxy <name> <url|port>' to create one."
    return 0
  fi

  python3 - "$file" <<'PY'
import json, sys
try:
    data = json.load(open(sys.argv[1]))
except Exception:
    data = []
if not data:
    print('No proxies configured.')
    sys.exit(0)
print(f"{'Name':<18} {'Domain':<24} {'Target URL':<34}")
print("-" * 78)
for p in data:
    print(f"{p.get('name', '-'):<18} {p.get('domain', '-'):<24} {p.get('url', '-'):<34}")
PY
}

proxy_add() {
  require_system_access
  local name="$1"
  local raw_target="$2"
  local domain="${name}.test"
  local port="" host="127.0.0.1" scheme="http" url=""

  # Accepted: 8080 | localhost:8080 | http(s)://host:8080[/] (host: letters, digits, . and -)
  if [[ "$raw_target" =~ ^[0-9]+$ ]]; then
    port="$raw_target"
  elif [[ "$raw_target" =~ ^(https?)://([A-Za-z0-9.-]+):([0-9]+)/?$ ]]; then
    scheme="${BASH_REMATCH[1]}"; host="${BASH_REMATCH[2]}"; port="${BASH_REMATCH[3]}"
  elif [[ "$raw_target" =~ ^([A-Za-z0-9.-]+):([0-9]+)$ ]]; then
    host="${BASH_REMATCH[1]}"; port="${BASH_REMATCH[2]}"
  else
    echo "Error: target must be a port (8080), host:port or http(s)://host:port, got '$raw_target'" >&2
    return 1
  fi
  if (( port < 1 || port > 65535 )); then
    echo "Error: port must be between 1 and 65535." >&2
    return 1
  fi
  url="${scheme}://${host}:${port}"
  if [[ -f "$(get_nginx_config_path "$name")" ]] && ! proxy_exists "$name"; then
    echo "Error: '$name' is already a site. Pick another proxy name." >&2
    return 1
  fi

  echo "Configuring proxy for '$name' ($domain -> $url)..."

  # Ensure SSL and domain mapping
  ensure_domain_ssl "$domain"
  ensure_domain_mapping "$name" "$domain"

  # Create proxy vhost using template
  create_nginx_proxy "$name" "$port" "$domain"
  if [[ "$url" != "http://127.0.0.1:${port}" ]]; then
    # The template proxies to 127.0.0.1; point it at the requested host/scheme instead.
    local config
    config="$(get_nginx_config_path "$name")"
    sudo_cmd sed -i "s#proxy_pass http://127.0.0.1:${port};#proxy_pass ${url};#" "$config"
    sudo_cmd nginx -t && sudo_cmd systemctl reload nginx
  fi

  # Record in proxies.json
  local file
  file="$(proxy_file)"
  python3 - "$file" "$name" "$domain" "$url" "$port" <<'PY'
import json, sys, time
f, name, domain, url, port = sys.argv[1:6]
try:
    data = json.load(open(f))
except Exception:
    data = []
if not isinstance(data, list):
    data = []
data = [item for item in data if item.get("name") != name]
data.append({"name": name, "domain": domain, "url": url, "port": int(port), "created_at": int(time.time())})
with open(f, "w") as fp:
    json.dump(data, fp, indent=2)
PY

  echo "Success: Proxied http://$domain (and https://$domain) -> $url"
}

proxy_exists() {
  local file
  file="$(proxy_file)"
  [[ -f "$file" ]] && python3 - "$file" "$1" <<'PY'
import json, sys
try:
    data = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(1)
sys.exit(0 if any(isinstance(i, dict) and i.get("name") == sys.argv[2] for i in data) else 1)
PY
}

proxy_remove() {
  require_system_access
  local name="$1"
  local domain="${name}.test"
  # Never remove the vhost of a real project that happens to have this name.
  if ! proxy_exists "$name"; then
    echo "Error: '$name' is not a proxy created with 'laravel-dev proxy'. See 'laravel-dev proxies'." >&2
    return 1
  fi

  echo "Removing proxy for '$name'..."
  remove_nginx_site "$name"

  local file
  file="$(proxy_file)"
  if [[ -f "$file" ]]; then
    python3 - "$file" "$name" <<'PY'
import json, sys
f, name = sys.argv[1], sys.argv[2]
try:
    data = json.load(open(f))
    if isinstance(data, list):
        data = [item for item in data if item.get("name") != name]
        with open(f, "w") as fp:
            json.dump(data, fp, indent=2)
except Exception:
    pass
PY
  fi

  sudo_cmd systemctl reload nginx 2>/dev/null || true
  echo "Success: Removed proxy for '$name'."
}
