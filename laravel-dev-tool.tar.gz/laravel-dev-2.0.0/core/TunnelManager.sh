#!/usr/bin/env bash

set -euo pipefail

# Cloudflare Tunnel Manager for Laravel Dev
# Manages public HTTPS tunnels via cloudflared (Quick Tunnels & Named Token Tunnels)

tunnel_runtime_dir() {
  local candidates=(
    "${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev/runtime/tunnels"
    "/tmp/laravel-dev-${UID:-$(id -u)}/runtime/tunnels"
  )
  local dir=""
  for dir in "${candidates[@]}"; do
    if mkdir -p "$dir" 2>/dev/null; then
      chmod 700 "$dir" 2>/dev/null || true
      echo "$dir"
      return 0
    fi
  done
  echo "/tmp/laravel-dev-${UID:-$(id -u)}/runtime/tunnels"
}

tunnel_config_dir() {
  local candidates=(
    "${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev/tunnels"
    "/tmp/laravel-dev-${UID:-$(id -u)}/tunnels"
  )
  local dir=""
  for dir in "${candidates[@]}"; do
    if mkdir -p "$dir" 2>/dev/null; then
      chmod 700 "$dir" 2>/dev/null || true
      echo "$dir"
      return 0
    fi
  done
  echo "/tmp/laravel-dev-${UID:-$(id -u)}/tunnels"
}

ensure_tunnel_dirs() {
  mkdir -p "$(tunnel_runtime_dir)" "$(tunnel_config_dir)" 2>/dev/null || true
}

tunnel_pid_file() {
  local project="$1"
  echo "$(tunnel_runtime_dir)/${project}.pid"
}

tunnel_url_file() {
  local project="$1"
  echo "$(tunnel_runtime_dir)/${project}.url"
}

tunnel_log_file() {
  local project="$1"
  echo "$(tunnel_runtime_dir)/${project}.log"
}

tunnel_json_file() {
  local project="$1"
  echo "$(tunnel_runtime_dir)/${project}.json"
}

tunnel_token_file() {
  local project="$1"
  echo "$(tunnel_config_dir)/${project}.token"
}

get_tunnel_pid() {
  local project="$1"
  local pid_file
  pid_file="$(tunnel_pid_file "$project")"
  if [[ -f "$pid_file" ]]; then
    local pid
    pid="$(cat "$pid_file" 2>/dev/null || true)"
    if [[ -n "$pid" && -d "/proc/$pid" ]]; then
      local comm
      comm="$(cat "/proc/$pid/comm" 2>/dev/null || true)"
      if [[ "$comm" == *"cloudflared"* || "$comm" == *"tunnel"* ]]; then
        echo "$pid"
        return 0
      fi
    fi
    # Stale pid file
    rm -f "$pid_file" "$(tunnel_url_file "$project")" 2>/dev/null || true
  fi

  # Fallback: check pgrep for cloudflared matching project domain or port
  local domain port
  domain="$(get_project_field "$project" "DOMAIN" 2>/dev/null || echo "${project}.test")"
  port="$(get_project_field "$project" "PORT" 2>/dev/null || true)"

  local p=""
  while IFS= read -r p; do
    [[ -n "$p" ]] || continue
    local cmdline
    cmdline="$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null || true)"
    if [[ "$cmdline" == *"cloudflared"* ]]; then
      if [[ -n "$domain" && "$cmdline" == *"$domain"* ]] || [[ -n "$port" && "$port" != "80" && "$cmdline" == *":${port}"* ]]; then
        ensure_tunnel_dirs
        echo "$p" > "$pid_file"
        echo "$p"
        return 0
      fi
    fi
  done < <(pgrep -f "cloudflared.*tunnel" 2>/dev/null || true)

  return 1
}

get_tunnel_url() {
  local project="$1"
  local url_file
  url_file="$(tunnel_url_file "$project")"
  if [[ -f "$url_file" ]]; then
    local u
    u="$(cat "$url_file" 2>/dev/null || true)"
    if [[ -n "$u" ]]; then
      echo "$u"
      return 0
    fi
  fi

  # Fallback: parse log file
  local log_file
  log_file="$(tunnel_log_file "$project")"
  if [[ -f "$log_file" ]]; then
    local match
    match="$(grep -oE 'https://[a-zA-Z0-9.-]+\.trycloudflare\.com' "$log_file" 2>/dev/null | tail -n1 || true)"
    if [[ -n "$match" ]]; then
      ensure_tunnel_dirs
      echo "$match" > "$url_file"
      echo "$match"
      return 0
    fi
  fi
  return 1
}

get_tunnel_token() {
  local project="$1"
  local token_file
  token_file="$(tunnel_token_file "$project")"
  if [[ -f "$token_file" ]]; then
    cat "$token_file" 2>/dev/null || true
  fi
}

set_tunnel_token() {
  local project="$1"
  local token="$2"
  ensure_tunnel_dirs
  local token_file
  token_file="$(tunnel_token_file "$project")"
  if [[ -n "$token" ]]; then
    echo "$token" > "$token_file"
    chmod 600 "$token_file" 2>/dev/null || true
    echo "Cloudflare Tunnel token saved for '$project'."
  else
    rm -f "$token_file" 2>/dev/null || true
    echo "Cloudflare Tunnel token removed for '$project'."
  fi
}

status_tunnel() {
  local project="$1"
  local format="${2:-text}"
  local pid="" url="" mode="quick" started=0

  ensure_tunnel_dirs
  local json_file
  json_file="$(tunnel_json_file "$project")"

  if pid="$(get_tunnel_pid "$project")"; then
    url="$(get_tunnel_url "$project" || true)"
    if [[ -f "$json_file" ]] && command -v jq >/dev/null 2>&1; then
      mode="$(jq -r '.mode // "quick"' "$json_file" 2>/dev/null || echo "quick")"
      started="$(jq -r '.started // 0' "$json_file" 2>/dev/null || echo "0")"
    fi

    if [[ "$format" == "json" ]]; then
      cat <<JSON
{"project":"$project","active":true,"pid":$pid,"url":"$url","mode":"$mode","started":$started}
JSON
    else
      echo "tunnel=running pid=$pid url=$url mode=$mode started=$started log=$(tunnel_log_file "$project")"
    fi
    return 0
  else
    if [[ "$format" == "json" ]]; then
      cat <<JSON
{"project":"$project","active":false,"pid":null,"url":"","mode":"$mode","started":0}
JSON
    else
      echo "tunnel=stopped"
    fi
    return 0
  fi
}

list_tunnels() {
  ensure_tunnel_dirs
  echo -e "PROJECT\t\tSTATUS\t\tPID\tMODE\t\tURL"
  echo -e "───────\t\t──────\t\t───\t────\t\t───"

  local found=0
  local pid_file
  local rdir
  rdir="$(tunnel_runtime_dir)"
  for pid_file in "$rdir"/*.pid; do
    [[ -f "$pid_file" ]] || continue
    local project
    project="$(basename "$pid_file" .pid)"
    local pid url mode="quick"
    if pid="$(get_tunnel_pid "$project")"; then
      found=1
      url="$(get_tunnel_url "$project" || echo "-")"
      local json_file
      json_file="$(tunnel_json_file "$project")"
      if [[ -f "$json_file" ]] && command -v jq >/dev/null 2>&1; then
        mode="$(jq -r '.mode // "quick"' "$json_file" 2>/dev/null || echo "quick")"
      fi
      echo -e "${project}\t\trunning\t\t${pid}\t${mode}\t\t${url}"
    fi
  done

  if [[ $found -eq 0 ]]; then
    echo "No active Cloudflare tunnels."
  fi
}

start_tunnel() {
  local project="$1"
  local mode="${2:-quick}"
  local custom_token="${3:-}"

  ensure_tunnel_dirs

  if ! command -v cloudflared >/dev/null 2>&1; then
    echo "Error: cloudflared is not installed."
    echo "Please install cloudflared or run 'laravel-dev tunnel install'."
    return 1
  fi

  local pid
  if pid="$(get_tunnel_pid "$project")"; then
    local url
    url="$(get_tunnel_url "$project" || true)"
    echo "Cloudflare Tunnel is already running for '$project' (PID: $pid)."
    if [[ -n "$url" ]]; then
      echo "Public URL: $url"
    fi
    return 0
  fi

  local domain port
  domain="$(get_project_field "$project" "DOMAIN" 2>/dev/null || echo "${project}.test")"
  port="$(get_project_field "$project" "PORT" 2>/dev/null || true)"

  # Check token
  local token="$custom_token"
  if [[ -z "$token" ]]; then
    token="$(get_tunnel_token "$project")"
  fi

  local pid_file log_file url_file json_file
  pid_file="$(tunnel_pid_file "$project")"
  log_file="$(tunnel_log_file "$project")"
  url_file="$(tunnel_url_file "$project")"
  json_file="$(tunnel_json_file "$project")"

  # Clean old state
  rm -f "$pid_file" "$url_file" 2>/dev/null || true
  : > "$log_file"

  local cmd=()
  if [[ -n "$token" && "$mode" != "quick" ]]; then
    mode="token"
    echo "Starting Named Cloudflare Tunnel for '$project' using token..."
    cmd=(cloudflared tunnel run --token "$token")
  else
    mode="quick"
    if [[ -n "$port" && "$port" != "80" ]]; then
      echo "Starting Quick Cloudflare Tunnel for '$project' (port $port)..."
      cmd=(cloudflared tunnel --url "http://127.0.0.1:${port}")
    else
      echo "Starting Quick Cloudflare Tunnel for '$project' ($domain)..."
      cmd=(cloudflared tunnel --url "http://127.0.0.1:80" --http-host-header "$domain")
    fi
  fi

  # Start cloudflared in background
  nohup "${cmd[@]}" >> "$log_file" 2>&1 &
  local new_pid=$!
  echo "$new_pid" > "$pid_file"

  # Wait for URL or error (up to 10 seconds)
  local url=""
  local count=0
  local max_count=50 # 50 * 0.2s = 10s

  while [[ $count -lt $max_count ]]; do
    if ! kill -0 "$new_pid" 2>/dev/null; then
      break
    fi

    if [[ "$mode" == "quick" ]]; then
      url="$(grep -oE 'https://[a-zA-Z0-9.-]+\.trycloudflare\.com' "$log_file" 2>/dev/null | tail -n1 || true)"
      if [[ -n "$url" ]]; then
        break
      fi
    else
      # For token tunnels, check if connected
      if grep -qE 'Registered tunnel connection|Connection.*registered' "$log_file" 2>/dev/null; then
        url="custom-domain (token tunnel active)"
        break
      fi
    fi

    sleep 0.2
    count=$((count + 1))
  done

  if ! kill -0 "$new_pid" 2>/dev/null; then
    rm -f "$pid_file" 2>/dev/null || true
    echo "Error: Cloudflare Tunnel failed to start."
    echo "Recent log output:"
    tail -n 10 "$log_file" | sed 's/^/  /'
    return 1
  fi

  local started_ts
  started_ts="$(date +%s)"
  if [[ -n "$url" ]]; then
    echo "$url" > "$url_file"
  fi

  # Write json state
  cat <<JSON > "$json_file"
{
  "project": "$project",
  "active": true,
  "pid": $new_pid,
  "url": "$url",
  "mode": "$mode",
  "port": "$port",
  "domain": "$domain",
  "started": $started_ts
}
JSON

  echo "Cloudflare Tunnel started successfully (PID: $new_pid)."
  if [[ -n "$url" ]]; then
    echo "Public URL: $url"
  fi
  return 0
}

stop_tunnel() {
  local project="$1"
  local pid_file
  pid_file="$(tunnel_pid_file "$project")"
  local json_file
  json_file="$(tunnel_json_file "$project")"

  local pid
  if ! pid="$(get_tunnel_pid "$project")"; then
    echo "Cloudflare Tunnel is not running for '$project'."
    rm -f "$pid_file" "$(tunnel_url_file "$project")" 2>/dev/null || true
    return 0
  fi

  echo "Stopping Cloudflare Tunnel for '$project' (PID: $pid)..."
  kill -TERM "$pid" 2>/dev/null || true

  local count=0
  while kill -0 "$pid" 2>/dev/null && [[ $count -lt 25 ]]; do
    sleep 0.1
    count=$((count + 1))
  done

  if kill -0 "$pid" 2>/dev/null; then
    kill -KILL "$pid" 2>/dev/null || true
  fi

  rm -f "$pid_file" "$(tunnel_url_file "$project")" 2>/dev/null || true

  if [[ -f "$json_file" ]]; then
    cat <<JSON > "$json_file"
{
  "project": "$project",
  "active": false,
  "pid": null,
  "url": "",
  "mode": "quick",
  "started": 0
}
JSON
  fi

  echo "Cloudflare Tunnel stopped for '$project'."
  return 0
}

restart_tunnel() {
  local project="$1"
  local mode="${2:-quick}"
  local token="${3:-}"
  stop_tunnel "$project"
  sleep 0.5
  start_tunnel "$project" "$mode" "$token"
}

log_tunnel() {
  local project="$1"
  local lines="${2:-50}"
  local log_file
  log_file="$(tunnel_log_file "$project")"
  if [[ -f "$log_file" ]]; then
    tail -n "$lines" "$log_file"
  else
    echo "No tunnel log file found for '$project'."
  fi
}

install_cloudflared() {
  if command -v cloudflared >/dev/null 2>&1; then
    echo "cloudflared is already installed: $(command -v cloudflared) ($(cloudflared --version 2>/dev/null || true))"
    return 0
  fi

  echo "Installing cloudflared..."
  local arch
  arch="$(uname -m)"
  local deb_arch="amd64"
  if [[ "$arch" == "aarch64" || "$arch" == "arm64" ]]; then
    deb_arch="arm64"
  elif [[ "$arch" == "armv7l" || "$arch" == "armhf" ]]; then
    deb_arch="arm"
  elif [[ "$arch" == "i386" || "$arch" == "i686" ]]; then
    deb_arch="386"
  fi

  if command -v apt-get >/dev/null 2>&1; then
    local tmp_deb
    tmp_deb="$(mktemp /tmp/cloudflared-XXXXXX.deb)"
    local deb_url="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${deb_arch}.deb"
    echo "Downloading $deb_url..."
    if curl -fsSL -o "$tmp_deb" "$deb_url"; then
      sudo dpkg -i "$tmp_deb" || sudo apt-get install -f -y
      rm -f "$tmp_deb"
      echo "cloudflared installed successfully!"
      cloudflared --version
      return 0
    fi
  fi

  # Fallback standalone binary
  local bin_url="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${deb_arch}"
  local tmp_bin
  tmp_bin="$(mktemp /tmp/cloudflared-bin-XXXXXX)"
  echo "Downloading standalone binary from $bin_url..."
  if curl -fsSL -o "$tmp_bin" "$bin_url"; then
    chmod +x "$tmp_bin"
    sudo mv "$tmp_bin" /usr/local/bin/cloudflared
    echo "cloudflared binary installed to /usr/local/bin/cloudflared!"
    cloudflared --version
    return 0
  fi

  echo "Failed to auto-install cloudflared. Please download it manually from https://github.com/cloudflare/cloudflared/releases"
  return 1
}

tunnel_oauth_info() {
  local project="$1"
  local fmt="${2:-text}"
  local url
  url="$(get_tunnel_url "$project" 2>/dev/null || echo "")"
  local domain
  domain="$(get_project_field "$project" "DOMAIN" 2>/dev/null || echo "${project}.test")"
  local base_url="${url:-https://${domain}}"

  python3 -c "
import json, sys
project = '$project'
base = '$base_url'
fmt = '$fmt'
domain = '$domain'
tunnel_url = '$url'

data = {
    'project': project,
    'base_url': base,
    'tunnel_active': bool(tunnel_url),
    'tunnel_url': tunnel_url,
    'local_url': f'https://{domain}',
    'oauth_callbacks': {
        'default': f'{base}/auth/callback',
        'github': f'{base}/auth/github/callback',
        'google': f'{base}/auth/google/callback',
        'facebook': f'{base}/auth/facebook/callback'
    },
    'webhooks': {
        'stripe': f'{base}/stripe/webhook',
        'paddle': f'{base}/paddle/webhook',
        'generic': f'{base}/webhook'
    }
}

if fmt in ('--json', 'json'):
    print(json.dumps(data, indent=2))
    sys.exit(0)

print('=' * 75)
print(f'OAuth & Webhook Callback Helper · {project}')
print('=' * 75)
if tunnel_url:
    print(f'Public Tunnel URL:  {tunnel_url}')
else:
    print(f'Local Test URL:     https://{domain} (Tunnel not running)')
print(f'Live Helper Webpage: {base}/_laravel_dev/oauth')
print('-' * 75)
print('OAuth Callback URLs (copy into GitHub / Google Console / OAuth App):')
for k, v in data['oauth_callbacks'].items():
    print(f'  {k.capitalize():<12} -> {v}')
print('-' * 75)
print('Webhook Endpoint URLs (copy into Stripe / Webhook settings):')
for k, v in data['webhooks'].items():
    print(f'  {k.capitalize():<12} -> {v}')
print('=' * 75)
"
}
