#!/usr/bin/env bash

set -euo pipefail

# Backup Manager for Laravel Dev
# Manages scheduled backups via cron, backup retention pruning,
# and off-site uploads.
# Entries use the marker "# laravel-dev:<project>:backup".

BACKUP_CRON_MARKER_SUFFIX=":backup"

backup_cron_marker() {
  local project_name="$1"
  echo "# laravel-dev:${project_name}${BACKUP_CRON_MARKER_SUFFIX}"
}

backup_cron_enabled() {
  local project_name="$1"
  local marker
  marker="$(backup_cron_marker "$project_name")"
  current_crontab | awk -v m="$marker" 'substr($0, length($0) - length(m) + 1) == m { found = 1 } END { exit !found }'
}

crontab_without_backup() {
  local project_name="$1"
  local marker
  marker="$(backup_cron_marker "$project_name")"
  current_crontab | awk -v m="$marker" 'substr($0, length($0) - length(m) + 1) != m'
}

enable_backup_cron() {
  local project_name="$1"
  local frequency="${2:-daily}"
  local retention="${3:-5}"
  local btype="${4:-full}"
  local remote_id="${5:-}"

  ensure_cron_installed || return 1

  mkdir -p "$CRON_LOG_DIR"
  chmod 700 "$CRON_LOG_DIR" 2>/dev/null || true
  if [[ -n "${SUDO_USER:-}" && "$(id -u)" -eq 0 ]]; then
    chown "$SUDO_USER": "$CRON_LOG_DIR" 2>/dev/null || true
  fi

  local cron_schedule
  case "$frequency" in
    daily)  cron_schedule="0 2 * * *" ;;
    weekly) cron_schedule="0 3 * * 0" ;;
    *)
      echo "Error: frequency must be daily or weekly (got: $frequency)"
      return 1
      ;;
  esac

  local log_file entry marker bin_path
  log_file="${CRON_LOG_DIR}/laravel-dev-${project_name}-backup.log"
  marker="$(backup_cron_marker "$project_name")"
  bin_path="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/bin/laravel-dev"

  entry="${cron_schedule} '${bin_path}' backup-run '${project_name}' '${btype}' '${retention}' '${remote_id}' >> '${log_file}' 2>&1 ${marker}"

  local remaining
  remaining="$(crontab_without_backup "$project_name")"
  { [[ -n "$remaining" ]] && printf '%s\n' "$remaining"; echo "$entry"; } | user_crontab -

  echo "Backup schedule enabled for: $project_name"
  echo "  Schedule: $frequency ($cron_schedule)"
  echo "  Retention: keep last $retention snapshots"
  echo "  Type: $btype"
  [[ -n "$remote_id" ]] && echo "  Remote: $remote_id"
  echo "  Log: $log_file"
}

disable_backup_cron() {
  local project_name="$1"
  if ! cron_is_installed || ! backup_cron_enabled "$project_name"; then
    echo "Backup schedule is not enabled for: $project_name"
    return 0
  fi

  local remaining
  remaining="$(crontab_without_backup "$project_name")"
  if [[ -n "${remaining//[[:space:]]/}" ]]; then
    printf '%s\n' "$remaining" | user_crontab -
  else
    user_crontab -r 2>/dev/null || true
  fi
  echo "Backup schedule disabled for: $project_name"
}

status_backup_cron() {
  local project_name="$1"
  if ! cron_is_installed; then
    echo "cron=not_installed"
    return 0
  fi
  local marker line
  marker="$(backup_cron_marker "$project_name")"
  line="$(current_crontab | grep -F "$marker" || true)"
  if [[ -z "$line" ]]; then
    echo "enabled=0 frequency=off"
  else
    echo "enabled=1 line=$line"
  fi
}

