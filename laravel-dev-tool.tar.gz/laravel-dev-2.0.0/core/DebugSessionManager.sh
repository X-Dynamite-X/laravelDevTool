#!/usr/bin/env bash

set -euo pipefail

# core/DebugSessionManager.sh - "Debug session" for a site.
#
# While armed, every PHP request to the site's domain starts an Xdebug step-debug session
# (pages, API calls from a separate frontend on any origin, Postman, webhooks). It works
# through php/debug_prepend.php, which the site's vhost loads as auto_prepend_file, and a
# flag file per domain in DEBUG_SESSION_DIR. Arming / disarming only writes that file:
# no nginx reload, no sudo. The one-time setup (Xdebug install + config, vhost hook,
# flag directory) is done automatically the first time and needs sudo once.

DEBUG_SESSION_DIR="/var/lib/laravel-dev/debug"
DEBUG_IDE_PORT=9003

_dbg_prepend_file() { echo "$BASE_DIR/php/debug_prepend.php"; }

# Value of an ini key as PHP-FPM sees it (falls back to the CLI SAPI).
_dbg_ini_value() {
  local version="$1" key="$2" bin=""
  for bin in "php-fpm${version}" "/usr/sbin/php-fpm${version}" "php${version}"; do
    if command -v "$bin" >/dev/null 2>&1; then
      "$bin" -i 2>/dev/null | sed -n "s/^${key//./\\.} => \\([^=]*\\) => .*/\\1/p" | head -n1 | sed 's/[[:space:]]*$//'
      return 0
    fi
  done
}

_dbg_ide_listening() {
  python3 - "$DEBUG_IDE_PORT" <<'PY'
import sys
port = "%04X" % int(sys.argv[1])
for f in ("/proc/net/tcp", "/proc/net/tcp6"):
    try:
        for line in open(f).read().splitlines()[1:]:
            parts = line.split()
            if parts[1].rsplit(":", 1)[1] == port and parts[3] == "0A":
                sys.exit(0)
    except OSError:
        pass
sys.exit(1)
PY
}

_dbg_vhost_ready() {
  local project="$1" conf
  conf="$(get_nginx_config_path "$project" 2>/dev/null || true)"
  [[ -n "$conf" && -f "$conf" ]] && grep -qs "debug_prepend.php" "$conf"
}

_dbg_flag_file() { echo "$DEBUG_SESSION_DIR/${1}.json"; }

debug_session_status() {
  local project="$1"
  local domain php_ver runtime xdebug_mode start_with expires=0 now
  domain="$(get_project_domain "$project" 2>/dev/null || echo "${project}.test")"
  php_ver="$(get_project_php_version "$project" 2>/dev/null || true)"
  runtime="$(get_project_field "$project" "RUNTIME" 2>/dev/null || true)"
  xdebug_mode="$(_dbg_ini_value "$php_ver" xdebug.mode || true)"
  start_with="$(_dbg_ini_value "$php_ver" xdebug.start_with_request || true)"
  now="$(date +%s)"
  local flag
  flag="$(_dbg_flag_file "$domain")"
  if [[ -f "$flag" ]]; then
    expires="$(python3 -c 'import json,sys; print(int(json.load(open(sys.argv[1])).get("expires_at",0)))' "$flag" 2>/dev/null || echo 0)"
  fi

  local ide=false vhost=false dir=false
  _dbg_ide_listening && ide=true
  _dbg_vhost_ready "$project" && vhost=true
  [[ -d "$DEBUG_SESSION_DIR" && -w "$DEBUG_SESSION_DIR" ]] && dir=true

  python3 - "$project" "$domain" "$php_ver" "${runtime:-php-fpm}" "$xdebug_mode" "$start_with" "$expires" "$now" \
    "$ide" "$vhost" "$dir" "$DEBUG_IDE_PORT" <<'PY'
import json, sys
(project, domain, php, runtime, mode, start_with, expires, now, ide, vhost, d, port) = sys.argv[1:13]
expires, now = int(expires), int(now)
installed = bool(mode)
debug_mode = "debug" in mode.split(",")
armed = expires > now
supported = runtime != "octane"
print(json.dumps({
    "project": project, "domain": domain, "php": php, "runtime": runtime,
    "supported": supported,
    "armed": armed and supported,
    "expires_at": expires if armed else 0,
    "remaining_seconds": max(0, expires - now) if armed else 0,
    "ide_port": int(port),
    "checks": {
        "xdebug_installed": installed,
        "xdebug_debug_mode": debug_mode,
        "trigger_mode": start_with == "trigger",
        "vhost_hook": vhost == "true",
        "flag_dir": d == "true",
        "ide_listening": ide == "true",
    },
    "xdebug_mode": mode,
    "ready": installed and debug_mode and vhost == "true" and d == "true",
}, indent=2))
PY
}

# One-time setup, only the missing pieces (needs sudo).
debug_session_setup() {
  local project="$1"
  local php_ver mode
  php_ver="$(get_project_php_version "$project" 2>/dev/null || true)"
  if [[ -z "$php_ver" ]]; then
    echo "Error: could not determine the PHP version of $project."
    return 1
  fi

  mode="$(_dbg_ini_value "$php_ver" xdebug.mode || true)"
  local need_sudo=0
  [[ -z "$mode" || ",$mode," != *",debug,"* ]] && need_sudo=1
  _dbg_vhost_ready "$project" || need_sudo=1
  [[ -d "$DEBUG_SESSION_DIR" && -w "$DEBUG_SESSION_DIR" ]] || need_sudo=1
  [[ "$need_sudo" == "0" ]] && return 0

  require_system_access

  if [[ -z "$mode" ]]; then
    echo "Installing Xdebug for PHP $php_ver..."
    php_ext_install "$php_ver" xdebug
  fi
  mode="$(_dbg_ini_value "$php_ver" xdebug.mode || true)"
  if [[ -z "$mode" || ",$mode," != *",debug,"* ]]; then
    echo "Configuring Xdebug (develop,debug · trigger) for PHP $php_ver..."
    php_xdebug_configure_jit "$php_ver"
  fi
  mode="$(_dbg_ini_value "$php_ver" xdebug.mode || true)"
  if [[ ",$mode," != *",debug,"* ]]; then
    echo "Error: Xdebug is still not active in PHP-FPM $php_ver (xdebug.mode='${mode}')."
    return 1
  fi

  if [[ ! -d "$DEBUG_SESSION_DIR" || ! -w "$DEBUG_SESSION_DIR" ]]; then
    echo "Creating $DEBUG_SESSION_DIR..."
    sudo_cmd mkdir -p "$DEBUG_SESSION_DIR"
    # Owned by the desktop user (arm/disarm without sudo), readable by PHP-FPM (www-data).
    sudo_cmd chown "$(id -un):$(id -gn)" "$DEBUG_SESSION_DIR"
    sudo_cmd chmod 755 "$DEBUG_SESSION_DIR" /var/lib/laravel-dev
  fi

  if ! _dbg_vhost_ready "$project"; then
    local conf prepend backup
    conf="$(get_nginx_config_path "$project")"
    prepend="$(_dbg_prepend_file)"
    if [[ ! -f "$conf" ]] || ! grep -q "fastcgi_pass" "$conf"; then
      echo "Error: no PHP-FPM vhost found for $project ($conf)."
      return 1
    fi
    echo "Adding the debug hook to $conf..."
    backup="$(mktemp)"
    sudo_cmd cat "$conf" > "$backup"
    sudo_cmd sed -i "s#^\\([[:space:]]*\\)fastcgi_pass unix:#\\1fastcgi_param PHP_VALUE \"auto_prepend_file=${prepend}\";\\n\\1fastcgi_pass unix:#" "$conf"
    if ! sudo_cmd nginx -t >/dev/null 2>&1; then
      echo "Error: nginx rejected the change, restoring the vhost."
      sudo_cmd tee "$conf" < "$backup" >/dev/null
      rm -f -- "$backup"
      return 1
    fi
    rm -f -- "$backup"
    sudo_cmd systemctl reload nginx 2>/dev/null || sudo_cmd nginx -s reload
  fi
}

debug_session_on() {
  local project="${1:-}" minutes="${2:-30}"
  if [[ -z "$project" ]]; then
    echo "Usage: laravel-dev debug-session on <project> [minutes]"
    return 1
  fi
  if [[ ! "$minutes" =~ ^[0-9]+$ ]] || (( minutes < 1 || minutes > 480 )); then
    echo "Error: minutes must be between 1 and 480."
    return 1
  fi
  local runtime domain
  runtime="$(get_project_field "$project" "RUNTIME" 2>/dev/null || true)"
  if [[ "$runtime" == "octane" ]]; then
    echo "Error: $project runs on Octane (no PHP-FPM). Disable Octane to step-debug requests."
    return 1
  fi
  domain="$(get_project_domain "$project" 2>/dev/null || echo "${project}.test")"

  debug_session_setup "$project"

  local expires
  expires=$(( $(date +%s) + minutes * 60 ))
  printf '{"project":"%s","domain":"%s","expires_at":%s}\n' "$project" "$domain" "$expires" > "$(_dbg_flag_file "$domain")"
  chmod 644 "$(_dbg_flag_file "$domain")"

  echo "Debug session ON for $domain (and *.$domain) for $minutes minutes."
  echo "Every PHP request — browser, API calls from your frontend, Postman — now stops at your breakpoints."
  if ! _dbg_ide_listening; then
    echo "Warning: nothing is listening on port $DEBUG_IDE_PORT yet. Start your IDE's Xdebug listener"
    echo "         (VS Code: Run → 'Listen for Xdebug' / PhpStorm: 'Start Listening for PHP Debug Connections')."
  fi
}

debug_session_off() {
  local project="${1:-}"
  if [[ -z "$project" ]]; then
    echo "Usage: laravel-dev debug-session off <project>"
    return 1
  fi
  local domain flag
  domain="$(get_project_domain "$project" 2>/dev/null || echo "${project}.test")"
  flag="$(_dbg_flag_file "$domain")"
  if [[ -f "$flag" ]]; then
    rm -f -- "$flag" 2>/dev/null || sudo_cmd rm -f -- "$flag"
  fi
  echo "Debug session OFF for $domain."
}
