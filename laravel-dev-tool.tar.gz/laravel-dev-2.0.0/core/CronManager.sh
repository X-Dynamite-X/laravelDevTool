#!/usr/bin/env bash

set -euo pipefail

# Cron Manager for Laravel Dev
# Runs each project's Laravel scheduler (`artisan schedule:run`) every minute
# from the user's own crontab. Every entry ends with a "# laravel-dev:<project>"
# marker so it can be found and removed without touching other cron lines.

CRON_MARKER_PREFIX="# laravel-dev:"
CRON_LOG_DIR="$HOME/.local/log/laravel-dev"

cron_is_installed() {
  command -v crontab >/dev/null 2>&1
}

cron_service_name() {
  local unit
  for unit in cron cronie crond; do
    if systemctl list-unit-files "${unit}.service" 2>/dev/null | grep -q "^${unit}\.service"; then
      echo "$unit"
      return 0
    fi
  done
  echo ""
}

cron_service_status() {
  local unit
  unit="$(cron_service_name)"
  if [[ -z "$unit" ]]; then
    echo "missing"
    return 0
  fi
  systemctl is-active "$unit" 2>/dev/null || true
}

ensure_cron_installed() {
  if ! cron_is_installed; then
    local pkg_manager
    pkg_manager="$(detect_package_manager)"
    echo "cron not found. Attempting to install via ${pkg_manager:-?}..."
    case "$pkg_manager" in
      apt)    sudo_cmd apt-get update -qq && sudo_cmd apt-get install -y cron ;;
      pacman) sudo_cmd pacman -S --noconfirm cronie ;;
      dnf)    sudo_cmd dnf install -y cronie ;;
      yum)    sudo_cmd yum install -y cronie ;;
      zypper) sudo_cmd zypper install -y cronie ;;
      *)
        echo "Error: could not detect package manager. Please install cron manually."
        return 1
        ;;
    esac
  fi

  local unit
  unit="$(cron_service_name)"
  if [[ -n "$unit" && "$(systemctl is-active "$unit" 2>/dev/null || true)" != "active" ]]; then
    require_system_access
    sudo_cmd systemctl enable --now "$unit" 2>/dev/null || true
  fi

  cron_is_installed
}

# crontab for the real user, even when the CLI itself runs under sudo.
user_crontab() {
  if [[ "$(id -u)" -eq 0 && -n "${SUDO_USER:-}" ]]; then
    crontab -u "$SUDO_USER" "$@"
  else
    crontab "$@"
  fi
}

current_crontab() {
  user_crontab -l 2>/dev/null || true
}

crontab_without_project() {
  local marker="${CRON_MARKER_PREFIX}$1"
  current_crontab | awk -v m="$marker" 'substr($0, length($0) - length(m) + 1) != m'
}

get_cron_log_file() {
  echo "${CRON_LOG_DIR}/laravel-dev-$1-schedule.log"
}

project_cron_enabled() {
  local marker="${CRON_MARKER_PREFIX}$1"
  current_crontab | awk -v m="$marker" 'substr($0, length($0) - length(m) + 1) == m { found = 1 } END { exit !found }'
}

enable_project_cron() {
  local project_name="$1"
  local project_path="$2"
  local php_bin="$3"

  if [[ ! -f "$project_path/artisan" ]]; then
    echo "Error: artisan not found in $project_path"
    return 1
  fi
  # cron treats % as a newline and the entry quotes paths with single quotes.
  if [[ "$project_path" == *[\'%]* ]]; then
    echo "Error: project path contains ' or %, which cron cannot run safely: $project_path"
    return 1
  fi

  local php_path
  php_path="$(command -v "$php_bin" 2>/dev/null || true)"
  if [[ -z "$php_path" ]]; then
    echo "Error: PHP binary not found: $php_bin"
    return 1
  fi

  ensure_cron_installed || return 1

  mkdir -p "$CRON_LOG_DIR"
  chmod 700 "$CRON_LOG_DIR" 2>/dev/null || true
  if [[ -n "${SUDO_USER:-}" && "$(id -u)" -eq 0 ]]; then
    chown "$SUDO_USER": "$CRON_LOG_DIR" 2>/dev/null || true
  fi

  local log_file entry
  log_file="$(get_cron_log_file "$project_name")"
  entry="* * * * * cd '${project_path}' && '${php_path}' artisan schedule:run >> '${log_file}' 2>&1 ${CRON_MARKER_PREFIX}${project_name}"

  # Read the whole crontab before writing it back, never in the same pipeline.
  local remaining
  remaining="$(crontab_without_project "$project_name")"
  { [[ -n "$remaining" ]] && printf '%s\n' "$remaining"; echo "$entry"; } | user_crontab -

  echo "Scheduler enabled for: $project_name"
  echo "  Runs: php artisan schedule:run (every minute)"
  echo "  Log: $log_file"
  if [[ "$(cron_service_status)" != "active" ]]; then
    echo "Warning: the cron service is not running, so scheduled tasks will not fire yet."
  fi
}

disable_project_cron() {
  local project_name="$1"

  if ! cron_is_installed || ! project_cron_enabled "$project_name"; then
    echo "Scheduler is not enabled for: $project_name"
    return 0
  fi

  local remaining
  remaining="$(crontab_without_project "$project_name")"
  if [[ -n "${remaining//[[:space:]]/}" ]]; then
    printf '%s\n' "$remaining" | user_crontab -
  else
    user_crontab -r 2>/dev/null || true
  fi
  echo "Scheduler disabled for: $project_name"
}

status_project_cron() {
  local project_name="$1"
  if ! cron_is_installed; then
    echo "cron=not_installed"
    return 0
  fi
  local state="disabled"
  project_cron_enabled "$project_name" && state="enabled"
  echo "cron=$state service=$(cron_service_status) log=$(get_cron_log_file "$project_name")"
}

log_project_cron() {
  local log_file
  log_file="$(get_cron_log_file "$1")"
  if [[ -f "$log_file" ]]; then
    tail -n 200 "$log_file"
  else
    echo "No scheduler output yet."
  fi
}
