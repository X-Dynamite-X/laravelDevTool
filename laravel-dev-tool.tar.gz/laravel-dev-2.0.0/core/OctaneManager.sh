#!/usr/bin/env bash

set -euo pipefail

# core/OctaneManager.sh - Manages Laravel Octane (FrankenPHP, RoadRunner, Swoole)
#
# Octane runs under Supervisor on 127.0.0.1:<port> and nginx proxies the site's
# domain to it. Nginx is only switched once the server really answers, so a failed
# start never leaves the site on a 502.

SUPERVISOR_CONF_DIR="/etc/supervisor/conf.d"

_octane_program() { echo "laravel-dev-${1}-octane"; }

_octane_project_dir() {
  local p
  p="$(get_project_field "$1" "PROJECT_PATH" 2>/dev/null || true)"
  echo "${p:-${LARAVEL_SITES_DIR:-$HOME/Sites}/$1}"
}

_octane_php_bin() {
  local project="$1" php_ver php_bin
  # Registry, then .php-version, then auto-detection, then the default (most records
  # have no PHP_VERSION field, so the registry alone is not enough).
  php_ver="$(_octane_fpm_version "$project")"
  php_bin="$(resolve_php_binary "$php_ver" 2>/dev/null || true)"
  [[ -n "$php_bin" ]] || php_bin="$(command -v php || echo php)"
  # Supervisor runs with a minimal PATH, so store an absolute path.
  command -v "$php_bin" 2>/dev/null || echo "$php_bin"
}

# PHP version to run Octane with / restore PHP-FPM to: the version saved at enable time,
# else the php binary in the Supervisor program (sites enabled before OCTANE_PHP existed),
# else the normal detection (only correct while the vhost is still a PHP-FPM one).
_octane_fpm_version() {
  local project="$1" v conf
  v="$(get_project_field "$project" "OCTANE_PHP" 2>/dev/null || true)"
  if [[ -z "$v" ]]; then
    conf="$SUPERVISOR_CONF_DIR/$(_octane_program "$project").conf"
    v="$(sed -n 's#^command=[^ ]*php\([0-9][0-9]*\.[0-9][0-9]*\) .*#\1#p' "$conf" 2>/dev/null | head -n1 || true)"
  fi
  [[ -n "$v" ]] || v="$(get_project_php_version "$project" 2>/dev/null || true)"
  echo "$v"
}

_octane_log_file() {
  local project="$1" user
  user="$(resolve_project_user "$(_octane_project_dir "$project")")"
  echo "$(resolve_user_home "$user")/.local/log/laravel-dev/octane-${project}.log"
}

_octane_port_open() {
  (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null
}

# FrankenPHP derives its Caddy admin port as 2019 + (port - 8000), which is negative for
# the 4100-4999 range laravel-dev allocates ("Unable to determine admin port"), so it is
# always passed explicitly.
_octane_admin_port() { echo $(( $1 + 10000 )); }

_octane_server_binary_ok() {
  local server="$1" dir="$2"
  case "$server" in
    frankenphp) [[ -x "$dir/frankenphp" ]] || command -v frankenphp >/dev/null 2>&1 ;;
    roadrunner) [[ -x "$dir/rr" ]] || command -v rr >/dev/null 2>&1 ;;
    *) return 0 ;;
  esac
}

_octane_has_swoole() {
  "$1" -m 2>/dev/null | grep -qiE '^(swoole|openswoole)$'
}

octane_status() {
  local project="$1"
  local runtime server port workers watch project_dir php_bin log_file
  runtime="$(get_project_field "$project" "RUNTIME" 2>/dev/null || true)"
  server="$(get_project_field "$project" "OCTANE_SERVER" 2>/dev/null || true)"
  port="$(get_project_field "$project" "PORT" 2>/dev/null || true)"
  workers="$(get_project_field "$project" "OCTANE_WORKERS" 2>/dev/null || true)"
  watch="$(get_project_field "$project" "OCTANE_WATCH" 2>/dev/null || true)"
  project_dir="$(_octane_project_dir "$project")"
  php_bin="$(_octane_php_bin "$project")"
  log_file="$(_octane_log_file "$project")"

  local conf_file="$SUPERVISOR_CONF_DIR/$(_octane_program "$project").conf"
  local enabled=false running=false installed=false
  [[ "$runtime" == "octane" || -f "$conf_file" ]] && enabled=true
  # A port check instead of `sudo supervisorctl status`: status is polled by the UI
  # and must never trigger a password prompt.
  if [[ "$enabled" == true && -n "$port" && "$port" != "80" ]] && _octane_port_open "$port"; then
    running=true
  fi
  grep -q '"laravel/octane"' "$project_dir/composer.json" 2>/dev/null && installed=true

  local supervisor=false swoole=false node=false chokidar=false
  command -v supervisorctl >/dev/null 2>&1 && supervisor=true
  _octane_has_swoole "$php_bin" && swoole=true
  command -v node >/dev/null 2>&1 && node=true
  [[ -d "$project_dir/node_modules/chokidar" ]] && chokidar=true

  python3 - "$project" "$enabled" "$running" "$installed" "${server:-frankenphp}" "${port:-80}" "${workers:-auto}" \
    "${watch:-0}" "$supervisor" "$swoole" "$node" "$chokidar" "$log_file" <<'PY'
import json, sys
a = sys.argv[1:]
b = lambda v: v == "true"
port = int(a[5]) if a[5].isdigit() else 80
print(json.dumps({
    "project": a[0], "enabled": b(a[1]), "running": b(a[2]), "package_installed": b(a[3]),
    "server": a[4], "port": port, "workers": a[6], "watch": a[7] == "1",
    "url": f"http://127.0.0.1:{port}" if port != 80 else "",
    "requirements": {"supervisor": b(a[8]), "swoole": b(a[9]), "node": b(a[10]), "chokidar": b(a[11])},
    "log_file": a[12],
}, indent=2))
PY
}

octane_logs() {
  local project="$1" lines="${2:-80}"
  local log_file
  log_file="$(_octane_log_file "$project")"
  if [[ -f "$log_file" ]]; then
    tail -n "$lines" "$log_file" | sed 's/\x1b\[[0-9;]*m//g'
  else
    echo "No Octane log yet ($log_file)."
  fi
}

octane_enable() {
  local project="$1"
  local server="${2:-frankenphp}"
  local workers="${3:-auto}"
  local watch_flag="${4:-0}"
  [[ "$watch_flag" == "--watch" ]] && watch_flag=1

  case "$server" in
    frankenphp|roadrunner|swoole) ;;
    *) echo "Error: unsupported Octane server '$server'. Choose frankenphp, roadrunner, or swoole."; return 1 ;;
  esac
  if [[ "$workers" != "auto" && ! "$workers" =~ ^[0-9]+$ ]]; then
    echo "Error: workers must be 'auto' or a number."
    return 1
  fi

  local project_dir domain php_bin fpm_version
  project_dir="$(_octane_project_dir "$project")"
  domain="$(get_project_domain "$project" 2>/dev/null || echo "${project}.test")"
  fpm_version="$(_octane_fpm_version "$project")"
  php_bin="$(_octane_php_bin "$project")"

  # ── 1. Pre-flight: fail before touching anything ──
  if [[ ! -f "$project_dir/artisan" ]]; then
    echo "Error: artisan not found in $project_dir. Is this a Laravel project?"
    return 1
  fi
  if ! command -v supervisorctl >/dev/null 2>&1; then
    echo "Error: Supervisor is required to keep Octane running. Install it first:"
    echo "  sudo apt install supervisor   (Fedora: sudo dnf install supervisor, Arch: sudo pacman -S supervisor)"
    return 1
  fi
  if [[ "$server" == "swoole" ]] && ! _octane_has_swoole "$php_bin"; then
    echo "Error: the Swoole extension is not installed for $php_bin."
    echo "Install it with: laravel-dev php-ext $(get_project_php_version "$project" 2>/dev/null || echo '<version>') install swoole"
    echo "or pick FrankenPHP / RoadRunner, which need no PHP extension."
    return 1
  fi

  require_system_access

  local composer_bin
  composer_bin="$(command -v composer || true)"
  if [[ -z "$composer_bin" ]]; then
    echo "Error: composer is not installed."
    return 1
  fi
  local composer_cmd=("$composer_bin")
  # Run composer with the project's PHP version when composer is a PHP script / phar.
  if head -c 200 "$composer_bin" 2>/dev/null | grep -qa "php"; then
    composer_cmd=("$php_bin" "$composer_bin")
  fi

  # ── 2. Package + server binary ──
  if ! grep -q '"laravel/octane"' "$project_dir/composer.json" 2>/dev/null; then
    echo "Installing laravel/octane..."
    (cd "$project_dir" && "${composer_cmd[@]}" require laravel/octane --no-interaction)
  fi

  if [[ "$server" != "swoole" ]] && ! _octane_server_binary_ok "$server" "$project_dir"; then
    echo "Running artisan octane:install --server=$server (downloads the $server binary)..."
    if ! (cd "$project_dir" && "$php_bin" artisan octane:install --server="$server" --no-interaction); then
      echo "Error: octane:install failed (see output above)."
      return 1
    fi
  elif [[ ! -f "$project_dir/config/octane.php" ]]; then
    (cd "$project_dir" && "$php_bin" artisan octane:install --server="$server" --no-interaction) || true
  fi
  if ! _octane_server_binary_ok "$server" "$project_dir"; then
    echo "Error: the $server binary was not found after installation."
    return 1
  fi

  # ── 3. Watch mode needs Node + chokidar ──
  if [[ "$watch_flag" == "1" ]]; then
    if ! command -v node >/dev/null 2>&1; then
      echo "Warning: Node.js is not installed, starting without --watch."
      watch_flag=0
    elif [[ ! -d "$project_dir/node_modules/chokidar" ]]; then
      echo "Installing chokidar (required by octane --watch)..."
      if ! (cd "$project_dir" && npm install --save-dev chokidar --no-audit --no-fund); then
        echo "Warning: could not install chokidar, starting without --watch."
        watch_flag=0
      fi
    fi
  fi

  # ── 4. Port ──
  local port
  port="$(get_project_field "$project" "PORT" 2>/dev/null || true)"
  if [[ -z "$port" || "$port" == "80" ]]; then
    port="$(allocate_project_port)"
  fi
  # Skip ports something else is already listening on (unless it is this site's own Octane).
  local tries=0
  while _octane_port_open "$port" || { [[ "$server" == "frankenphp" ]] && _octane_port_open "$(_octane_admin_port "$port")"; }; do
    if [[ -f "$SUPERVISOR_CONF_DIR/$(_octane_program "$project").conf" ]] && grep -q -- "--port=$port" "$SUPERVISOR_CONF_DIR/$(_octane_program "$project").conf"; then
      sudo_cmd supervisorctl stop "$(_octane_program "$project")" >/dev/null 2>&1 || true
      sleep 1
      _octane_port_open "$port" || break
    fi
    port=$((port + 1))
    tries=$((tries + 1))
    if (( tries > 200 )); then
      echo "Error: could not find a free port for Octane."
      return 1
    fi
  done

  # ── 5. Supervisor program ──
  local current_user user_home log_file conf_file program
  program="$(_octane_program "$project")"
  current_user="$(resolve_project_user "$project_dir")"
  user_home="$(resolve_user_home "$current_user")"
  log_file="$(_octane_log_file "$project")"
  conf_file="$SUPERVISOR_CONF_DIR/${program}.conf"

  ensure_log_directory "$project_dir"
  sudo_cmd mkdir -p "$SUPERVISOR_CONF_DIR"

  local cmd_args="--server=$server --host=127.0.0.1 --port=$port"
  [[ "$server" == "frankenphp" ]] && cmd_args="$cmd_args --admin-port=$(_octane_admin_port "$port")"
  [[ "$workers" != "auto" ]] && cmd_args="$cmd_args --workers=$workers"
  [[ "$watch_flag" == "1" ]] && cmd_args="$cmd_args --watch"

  echo "Writing Supervisor program $program..."
  sudo_cmd tee "$conf_file" >/dev/null <<EOF
[program:${program}]
process_name=%(program_name)s
command=${php_bin} ${project_dir}/artisan octane:start ${cmd_args}
directory=${project_dir}
environment=HOME="${user_home}",PATH="/usr/local/bin:/usr/bin:/bin"
autostart=true
autorestart=true
startsecs=3
stopasgroup=true
killasgroup=true
numprocs=1
redirect_stderr=true
stdout_logfile=${log_file}
stdout_logfile_maxbytes=10MB
stdout_logfile_backups=2
stopwaitsecs=30
user=${current_user}
EOF

  # Start from a clean log so a failure report only shows this attempt.
  : > "$log_file" 2>/dev/null || sudo_cmd truncate -s 0 "$log_file" 2>/dev/null || true

  echo "Starting Octane ($server) on 127.0.0.1:$port..."
  sudo_cmd supervisorctl reread >/dev/null
  sudo_cmd supervisorctl update >/dev/null
  sudo_cmd supervisorctl restart "$program" >/dev/null 2>&1 || sudo_cmd supervisorctl start "$program" >/dev/null 2>&1 || true

  # ── 6. Wait until it really answers ──
  local i up=0
  for i in $(seq 1 40); do
    if _octane_port_open "$port"; then up=1; break; fi
    sleep 0.5
  done

  if [[ "$up" != "1" ]]; then
    echo "Error: Octane did not start listening on 127.0.0.1:$port. Last log lines:"
    echo "------------------------------------------------------------"
    tail -n 30 "$log_file" 2>/dev/null | sed 's/\x1b\[[0-9;]*m//g' || true
    echo "------------------------------------------------------------"
    echo "Rolling back: the site stays on PHP-FPM."
    sudo_cmd supervisorctl stop "$program" >/dev/null 2>&1 || true
    sudo_cmd rm -f -- "$conf_file"
    sudo_cmd supervisorctl reread >/dev/null 2>&1 || true
    sudo_cmd supervisorctl update >/dev/null 2>&1 || true
    return 1
  fi

  # ── 7. Switch nginx and record ──
  echo "Switching nginx for $domain to proxy 127.0.0.1:$port..."
  create_nginx_proxy "$project" "$port" "$domain"

  update_project_record "$project" "RUNTIME" "octane" "OCTANE_SERVER" "$server" "PORT" "$port" \
    "OCTANE_WORKERS" "$workers" "OCTANE_WATCH" "$watch_flag" "OCTANE_PHP" "$fpm_version"

  echo "Success: Laravel Octane ($server) is serving $domain (127.0.0.1:$port)."
}

octane_disable() {
  local project="$1"
  require_system_access

  local php_ver domain program conf_file
  # Must be read before the Supervisor program is removed (it is one of the sources).
  php_ver="$(_octane_fpm_version "$project")"
  [[ -n "$php_ver" ]] || php_ver="$(default_php_version)"
  echo "Restoring PHP-FPM $php_ver..."
  domain="$(get_project_domain "$project" 2>/dev/null || echo "${project}.test")"
  program="$(_octane_program "$project")"
  conf_file="$SUPERVISOR_CONF_DIR/${program}.conf"

  if [[ -f "$conf_file" ]]; then
    echo "Stopping and removing Octane supervisor program..."
    sudo_cmd supervisorctl stop "$program" 2>/dev/null || true
    sudo_cmd rm -f -- "$conf_file"
    sudo_cmd supervisorctl reread 2>/dev/null || true
    sudo_cmd supervisorctl update 2>/dev/null || true
  fi

  echo "Restoring nginx vhost to PHP-FPM..."
  create_nginx "$project" "$php_ver" "" "$domain"

  update_project_record "$project" "RUNTIME" "php-fpm" "OCTANE_SERVER" "" "PORT" "80" "OCTANE_WORKERS" "" "OCTANE_WATCH" "" "OCTANE_PHP" ""

  echo "Success: Disabled Laravel Octane for $project (restored to PHP-FPM)."
}

octane_reload() {
  local project="$1"
  local port project_dir php_bin
  port="$(get_project_field "$project" "PORT" 2>/dev/null || true)"
  if [[ -z "$port" || "$port" == "80" ]] || ! _octane_port_open "$port"; then
    echo "Error: Octane is not running for $project. Last log lines:"
    octane_logs "$project" 20
    return 1
  fi
  project_dir="$(_octane_project_dir "$project")"
  php_bin="$(_octane_php_bin "$project")"
  echo "Reloading Octane workers for $project..."
  (cd "$project_dir" && "$php_bin" artisan octane:reload)
  echo "Octane reloaded successfully."
}

octane_restart() {
  local project="$1"
  require_system_access
  local program port i
  program="$(_octane_program "$project")"
  port="$(get_project_field "$project" "PORT" 2>/dev/null || true)"
  sudo_cmd supervisorctl restart "$program"
  for i in $(seq 1 40); do
    _octane_port_open "$port" && { echo "Octane restarted on 127.0.0.1:$port."; return 0; }
    sleep 0.5
  done
  echo "Error: Octane did not come back up. Last log lines:"
  octane_logs "$project" 30
  return 1
}
