#!/usr/bin/env bash

set -euo pipefail

# GitHub Hub Manager for Laravel Dev
# CLI management for GitHub Repositories, PRs, Issues, Actions, and 1-Click Publishing

gh_python_script() {
  local base="${BASE_DIR:-}"
  if [[ -z "$base" ]]; then
    base="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
  fi
  echo "$base/ui/github.py"
}

github_usage() {
  cat <<USAGE
Usage:
  laravel-dev github status [--json]
  laravel-dev github accounts [--json]
  laravel-dev github switch <username_or_label>
  laravel-dev github remove <username_or_label>
  laravel-dev github auth [token] [--name "Account Name"]
  laravel-dev github logout
  laravel-dev github repos [public|private|forks] [--json]
  laravel-dev github repo create <name> [--public] [--desc 'Description']
  laravel-dev github repo delete <owner/repo>
  laravel-dev github repo clone <owner/repo> [target_dir]
  laravel-dev github pr list <owner/repo> [--state open|closed|all] [--json]
  laravel-dev github pr merge <owner/repo> <pr_number> [--squash|--rebase]
  laravel-dev github issues list <owner/repo> [--closed] [--json]
  laravel-dev github actions <owner/repo> [--json]
  laravel-dev github publish <site_name_or_path> [--public] [--name 'repo_name']
  laravel-dev github link <site_name_or_path> <owner/repo>
USAGE
}

manage_github() {
  local script
  script="$(gh_python_script)"

  if [[ ! -f "$script" ]]; then
    echo "Error: GitHub Python backend not found at '$script'." >&2
    return 1
  fi

  if [[ $# -eq 0 || "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    github_usage
    return 0
  fi

  python3 "$script" "$@"
}
