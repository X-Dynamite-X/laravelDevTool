#!/usr/bin/env bash

set -euo pipefail

registry_dir() {
  local candidates=(
    "${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev/projects.d"
    "/tmp/laravel-dev-${UID:-$(id -u)}/projects.d"
  )
  local dir=""
  for dir in "${candidates[@]}"; do
    if mkdir -p "$dir" 2>/dev/null; then
      chmod 700 "$dir" 2>/dev/null || true
      echo "$dir"
      return 0
    fi
  done
  echo "/tmp"
}

project_registry_file() {
  local name="$1"
  echo "$(registry_dir)/${name}.env"
}

project_process_dir() {
  local dir
  dir="$(auth_runtime_dir)/projects"
  mkdir -p "$dir"
  chmod 700 "$dir" 2>/dev/null || true
  echo "$dir"
}

project_pid_file() {
  local name="$1"
  echo "$(project_process_dir)/${name}.pid"
}

project_log_file() {
  local name="$1"
  echo "$(project_process_dir)/${name}.log"
}

project_tunnel_log_file() {
  local name="$1"
  echo "$(project_process_dir)/${name}-tunnel.log"
}

upsert_project_key() {
  local file="$1"
  local key="$2"
  local value="${3:-}"
  touch "$file"
  chmod 600 "$file" 2>/dev/null || true
  sed -i "/^${key}=.*/d" "$file"
  printf '%s="%s"\n' "$key" "${value//\"/\\\"}" >>"$file"
}

write_project_record() {
  local name="$1"
  shift
  local file
  file="$(project_registry_file "$name")"
  mkdir -p "$(dirname "$file")"
  : >"$file"
  chmod 600 "$file" 2>/dev/null || true
  upsert_project_key "$file" "PROJECT_NAME" "$name"
  while [[ $# -gt 1 ]]; do
    upsert_project_key "$file" "$1" "$2"
    shift 2
  done
}

update_project_record() {
  local name="$1"
  shift
  local file
  file="$(project_registry_file "$name")"
  [[ -f "$file" ]] || write_project_record "$name"
  while [[ $# -gt 1 ]]; do
    upsert_project_key "$file" "$1" "$2"
    shift 2
  done
}

delete_project_record() {
  local name="$1"
  rm -f "$(project_registry_file "$name")"
  rm -f "$(project_pid_file "$name")" "$(project_log_file "$name")" "$(project_tunnel_log_file "$name")"
}

project_record_exists() {
  local name="$1"
  [[ -f "$(project_registry_file "$name")" ]]
}

read_project_record() {
  local name="$1"
  local file
  file="$(project_registry_file "$name")"
  [[ -f "$file" ]] || return 1
  # shellcheck source=/dev/null
  source "$file"
}

get_project_field() {
  local name="$1"
  local key="$2"
  local file value
  file="$(project_registry_file "$name")"
  [[ -f "$file" ]] || return 1
  value="$(sed -n "s/^${key}=\"\\(.*\\)\"$/\\1/p" "$file" | head -n1)"
  printf '%s' "$value"
}

get_project_path() {
  local name="$1"
  local p=""
  p="$(get_project_field "$name" "PROJECT_PATH" 2>/dev/null || true)"
  if [[ -z "$p" ]]; then
    p="${LARAVEL_SITES_DIR:-${SITES_DIR:-$HOME/Sites}}/$name"
  fi
  printf '%s' "$p"
}

get_project_domain() {
  local name="$1"
  local d=""
  d="$(get_project_field "$name" "DOMAIN" 2>/dev/null || true)"
  printf '%s' "${d:-${name}.test}"
}

get_project_php_version() {
  local name="$1"
  local v=""
  v="$(get_project_field "$name" "PHP_VERSION" 2>/dev/null || true)"
  # While a site runs on Octane its vhost is a proxy with no PHP-FPM socket to detect the
  # version from, so use the version saved when Octane was enabled.
  if [[ -z "$v" ]]; then
    v="$(get_project_field "$name" "OCTANE_PHP" 2>/dev/null || true)"
  fi
  if [[ -z "$v" ]]; then
    local p
    p="$(get_project_path "$name")"
    if [[ -f "$p/.php-version" ]]; then
      v="$(head -n1 "$p/.php-version" | tr -d '[:space:]')"
    fi
  fi
  if [[ -z "$v" ]] && declare -F detect_project_php_version >/dev/null 2>&1; then
    v="$(detect_project_php_version "$name" 2>/dev/null || true)"
  fi
  if [[ -z "$v" ]] && declare -F default_php_version >/dev/null 2>&1; then
    v="$(default_php_version 2>/dev/null || true)"
  fi
  printf '%s' "${v:-8.3}"
}

list_registered_project_names() {
  local dir file
  dir="$(registry_dir)"
  for file in "$dir"/*.env; do
    [[ -f "$file" ]] || continue
    basename "$file" .env
  done
}

allocate_project_port() {
  local used port
  used="$( (list_registered_project_names | while IFS= read -r name; do get_project_field "$name" "PORT" || true; echo; done) | tr ' ' '\n' | awk 'NF' | sort -u )"
  for port in $(seq 4100 4999); do
    if ! printf '%s\n' "$used" | grep -qx "$port"; then
      echo "$port"
      return 0
    fi
  done
  echo "5000"
}

# Per-site port nginx listens on for other devices on the network (phones,
# tablets): they can't resolve *.test, so they reach the site by <lan-ip>:<port>.
allocate_lan_port() {
  local used port
  used="$( (list_registered_project_names | while IFS= read -r name; do get_project_field "$name" "LAN_PORT" || true; echo; done) | awk 'NF' | sort -u )"
  for port in $(seq 8100 8999); do
    printf '%s\n' "$used" | grep -qx "$port" && continue
    ss -Hltn "sport = :$port" 2>/dev/null | grep -q . && continue
    echo "$port"
    return 0
  done
  return 1
}

project_pid_is_running() {
  local name="$1"
  local pid_file pid
  pid_file="$(project_pid_file "$name")"
  [[ -f "$pid_file" ]] || return 1
  pid="$(cat "$pid_file" 2>/dev/null || true)"
  [[ -n "$pid" ]] || return 1
  kill -0 "$pid" 2>/dev/null
}
