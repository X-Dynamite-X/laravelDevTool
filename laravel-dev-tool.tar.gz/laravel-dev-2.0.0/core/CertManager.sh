#!/usr/bin/env bash

set -euo pipefail

# core/CertManager.sh - Manages SSL certificate audits, CA expiry warnings, and directory listings

ssl_secured_list() {
  local fmt="${1:-text}"
  local cert_dir="${SSL_CERT_DIR:-/etc/nginx/ssl/laravel-dev}"

  local ca_root=""
  if command -v mkcert >/dev/null 2>&1; then
    ca_root="$(run_as_desktop_user mkcert -CAROOT 2>/dev/null || true)"
  fi
  local ca_cert="${ca_root:+$ca_root/rootCA.pem}"

  python3 -c "
import glob, json, os, subprocess, sys
from datetime import datetime, timezone

ca_cert = '$ca_cert'
cert_dir = '$cert_dir'
fmt = '$fmt'

now = datetime.now(timezone.utc)

def parse_cert_dates(path):
    try:
        out = subprocess.check_output(['openssl', 'x509', '-dates', '-noout', '-in', path], stderr=subprocess.DEVNULL).decode('utf-8')
        not_before = ''
        not_after = ''
        for line in out.splitlines():
            if line.startswith('notBefore='):
                not_before = line.split('=', 1)[1]
            elif line.startswith('notAfter='):
                not_after = line.split('=', 1)[1]
        dt = datetime.strptime(not_after, '%b %d %H:%M:%S %Y %Z').replace(tzinfo=timezone.utc)
        days_left = (dt - now).days
        status = 'Valid'
        if days_left < 0:
            status = 'Expired'
        elif days_left <= 30:
            status = 'Expiring Soon'
        return {
            'not_before': not_before,
            'not_after': not_after,
            'days_left': days_left,
            'status': status
        }
    except Exception:
        return None

ca_info = None
if ca_cert and os.path.isfile(ca_cert):
    d = parse_cert_dates(ca_cert)
    if d:
        ca_info = {
            'path': ca_cert,
            'not_before': d['not_before'],
            'not_after': d['not_after'],
            'days_left': d['days_left'],
            'status': d['status']
        }

certs = []
for p in sorted(glob.glob(os.path.join(cert_dir, '*.pem'))):
    if p.endswith('-key.pem'):
        continue
    domain = os.path.basename(p)[:-4]
    d = parse_cert_dates(p)
    if d:
        certs.append({
            'domain': domain,
            'path': p,
            'not_before': d['not_before'],
            'not_after': d['not_after'],
            'days_left': d['days_left'],
            'status': d['status']
        })

if fmt in ('--json', 'json'):
    print(json.dumps({'ca': ca_info, 'certificates': certs}, indent=2))
    sys.exit(0)

print('=' * 75)
print('Laravel Dev SSL Certificate & CA Monitor')
print('=' * 75)
if ca_info:
    print(f'Local Root CA:  {ca_info[\"path\"]}')
    print(f'CA Expiration:  {ca_info[\"not_after\"]} ({ca_info[\"days_left\"]} days left - {ca_info[\"status\"]})')
    if ca_info['days_left'] <= 30:
        print('  [!] WARNING: Local CA is expiring soon! Run \"laravel-dev ca-renew\" to renew.')
else:
    print('Local Root CA:  Not detected or mkcert missing')

print('-' * 75)
if not certs:
    print('No domain certificates found in ' + cert_dir)
else:
    print(f'{\"Domain\":<28} {\"Expires\":<24} {\"Days Left\":<10} {\"Status\":<12}')
    print('-' * 75)
    for c in certs:
        print(f'{c[\"domain\"]:<28} {c[\"not_after\"][:20]:<24} {str(c[\"days_left\"]):<10} {c[\"status\"]:<12}')
print('=' * 75)
"
}

ssl_ca_renew() {
  require_system_access
  echo "Renewing local mkcert Root CA..."
  ensure_local_ca_trusted 1
  echo "Success: Local CA renewed and trusted in system/browser stores."
}

site_directory_listing() {
  require_system_access
  local name="$1"
  local val="$2"
  local config
  config="$(get_nginx_config_path "$name")"

  if [[ ! -f "$config" ]]; then
    echo "Error: Nginx config not found for '$name' at $config" >&2
    return 1
  fi

  if [[ "$val" == "on" || "$val" == "1" || "$val" == "true" ]]; then
    if grep -q "autoindex on;" "$config"; then
      echo "Directory listing is already enabled for '$name'."
      return 0
    fi
    sudo_cmd sed -i '/location \/ {/a \        autoindex on;' "$config"
    echo "Enabled directory listing for '$name'."
  elif [[ "$val" == "off" || "$val" == "0" || "$val" == "false" ]]; then
    sudo_cmd sed -i '/autoindex on;/d' "$config"
    echo "Disabled directory listing for '$name'."
  else
    echo "Error: Invalid directory-listing setting '$val'. Use 'on' or 'off'." >&2
    return 1
  fi

  sudo_cmd nginx -t
  sudo_cmd systemctl reload nginx
}
