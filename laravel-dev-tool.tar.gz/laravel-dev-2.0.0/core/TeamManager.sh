#!/usr/bin/env bash

set -euo pipefail

# core/TeamManager.sh - Manages herd.yml and laravel-dev.yml team configurations

team_inspect() {
  local project="$1"
  local site_path
  site_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$site_path" || ! -d "$site_path" ]]; then
    site_path="${SITES_DIR:-$HOME/Sites}/$project"
  fi

  if [[ ! -d "$site_path" ]]; then
    echo "Error: Project directory '$site_path' not found."
    return 1
  fi

  python3 -c "
import sys, os, json
base_dir = sys.argv[1]
site_path = sys.argv[2]
project = sys.argv[3]
sys.path.insert(0, os.path.join(base_dir, 'ui'))

import team_config
import sites

try:
    details = sites.site_details(project)
    srv_list = sites.list_services()
    srv_map = {}
    for s in srv_list:
        active = s.get('status') == 'active'
        unit = s.get('unit', '').lower()
        label = s.get('label', '').lower()
        if 'mysql' in unit or 'mariadb' in unit or 'database' in label:
            srv_map['mysql'] = active
            srv_map['mariadb'] = active
        elif 'postgres' in unit:
            srv_map['postgresql'] = active
            srv_map['pgsql'] = active
        elif 'redis' in unit:
            srv_map['redis'] = active
        elif 'mailpit' in unit:
            srv_map['mail'] = active
            srv_map['mailpit'] = active
        elif 'meilisearch' in unit:
            srv_map['meilisearch'] = active
        elif 'minio' in unit:
            srv_map['minio'] = active
    curr_env = {
        'php': details.get('php', ''),
        'node': details.get('node_version', '') or details.get('node', ''),
        'services': srv_map
    }
except Exception:
    curr_env = {}

res = team_config.inspect_team_config(site_path, curr_env)
print(json.dumps(res, indent=2))
" "$BASE_DIR" "$site_path" "$project"
}

team_apply() {
  local project="$1"
  local site_path
  site_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$site_path" || ! -d "$site_path" ]]; then
    site_path="${SITES_DIR:-$HOME/Sites}/$project"
  fi

  if [[ ! -d "$site_path" ]]; then
    echo "Error: Project directory '$site_path' not found."
    return 1
  fi

  echo "Applying team configuration (herd.yml) for '$project'..."

  local parsed
  parsed="$(python3 -c "
import sys, os, json
base_dir = sys.argv[1]
site_path = sys.argv[2]
sys.path.insert(0, os.path.join(base_dir, 'ui'))
import team_config
cfg = team_config.load_team_config(site_path) or {}
req_srv = cfg.get('services') or {}
active_srvs = [k for k, v in req_srv.items() if v] if isinstance(req_srv, dict) else []
print(json.dumps({
    'php': str(cfg.get('php', '') or '').strip(),
    'node': str(cfg.get('node', '') or '').strip(),
    'services': active_srvs
}))
" "$BASE_DIR" "$site_path")"

  local req_php req_node req_services
  req_php="$(python3 -c "import sys, json; print(json.loads(sys.argv[1]).get('php',''))" "$parsed")"
  req_node="$(python3 -c "import sys, json; print(json.loads(sys.argv[1]).get('node',''))" "$parsed")"
  req_services="$(python3 -c "import sys, json; print(' '.join(json.loads(sys.argv[1]).get('services',[])))" "$parsed")"

  if [[ -n "$req_php" ]]; then
    echo "-> Isolating PHP to version $req_php..."
    isolate_project "$project" "$req_php"
  fi

  if [[ -n "$req_node" ]]; then
    echo "-> Setting Node.js version to $req_node..."
    node_use_project "$project" "$req_node"
  fi

  if [[ -n "$req_services" ]]; then
    local srv
    for srv in $req_services; do
      echo "-> Ensuring service '$srv' is running..."
      case "$srv" in
        mysql|mariadb) control_service "start" "mysql" 2>/dev/null || control_service "start" "mariadb" 2>/dev/null || true ;;
        postgresql|pgsql|postgres) control_service "start" "postgresql" 2>/dev/null || true ;;
        redis) control_service "start" "redis-server" 2>/dev/null || control_service "start" "redis" 2>/dev/null || true ;;
        mail|mailpit) control_service "start" "mailpit" 2>/dev/null || true ;;
        meilisearch) control_service "start" "meilisearch" 2>/dev/null || true ;;
        minio) control_service "start" "minio" 2>/dev/null || true ;;
      esac
    done
  fi

  echo "Team configuration applied successfully."
}

team_export() {
  local project="$1"
  local filename="${2:-herd.yml}"
  local site_path
  site_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$site_path" || ! -d "$site_path" ]]; then
    site_path="${SITES_DIR:-$HOME/Sites}/$project"
  fi

  if [[ ! -d "$site_path" ]]; then
    echo "Error: Project directory '$site_path' not found."
    return 1
  fi

  python3 -c "
import sys, os
base_dir = sys.argv[1]
site_path = sys.argv[2]
project = sys.argv[3]
filename = sys.argv[4]
sys.path.insert(0, os.path.join(base_dir, 'ui'))

import team_config
import sites

try:
    details = sites.site_details(project)
    srv_list = sites.list_services()
    srv_map = {}
    for s in srv_list:
        if s.get('status') == 'active':
            unit = s.get('unit', '').lower()
            label = s.get('label', '').lower()
            if 'mysql' in unit or 'mariadb' in unit or 'database' in label:
                srv_map['mysql'] = True
            elif 'postgres' in unit:
                srv_map['postgresql'] = True
            elif 'redis' in unit:
                srv_map['redis'] = True
            elif 'mailpit' in unit:
                srv_map['mail'] = True
            elif 'meilisearch' in unit:
                srv_map['meilisearch'] = True
            elif 'minio' in unit:
                srv_map['minio'] = True
    settings = {
        'php': details.get('php') or '8.3',
        'node': details.get('node_version') or details.get('node') or '',
        'services': srv_map or {'mysql': True, 'redis': True}
    }
except Exception:
    settings = {'php': '8.3', 'services': {'mysql': True}}

out = team_config.export_team_config(site_path, settings, filename)
print(f'Exported {filename} to: {out}')
" "$BASE_DIR" "$site_path" "$project" "$filename"
}
