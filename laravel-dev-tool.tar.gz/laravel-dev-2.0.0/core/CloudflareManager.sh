#!/usr/bin/env bash

set -euo pipefail

# Cloudflare Hub Manager for Laravel Dev
# CLI management for Cloudflare DNS, Cache, Security, R2, and Zero Trust Tunnels

cf_python_script() {
  local base="${BASE_DIR:-}"
  if [[ -z "$base" ]]; then
    base="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
  fi
  echo "$base/ui/cloudflare.py"
}

cloudflare_usage() {
  cat <<USAGE
Usage:
  laravel-dev cloudflare status [--json]
  laravel-dev cloudflare accounts [--json]
  laravel-dev cloudflare switch <account_id_or_name>
  laravel-dev cloudflare remove <account_id_or_name>
  laravel-dev cloudflare auth [token] [--name "Account Name"]
  laravel-dev cloudflare logout
  laravel-dev cloudflare zones [--json]
  laravel-dev cloudflare dns list <zone> [--json]
  laravel-dev cloudflare dns add <zone> <type> <name> <content> [--proxied] [--ttl N]
  laravel-dev cloudflare dns delete <zone> <record_id>
  laravel-dev cloudflare dns proxy <zone> <record_id> <on|off>
  laravel-dev cloudflare purge <zone> [--all] [files...]
  laravel-dev cloudflare dev-mode <zone> [on|off|status]
  laravel-dev cloudflare security <zone> [essentially_off|low|medium|high|under_attack]
  laravel-dev cloudflare r2 list [--json]
  laravel-dev cloudflare r2 create <bucket_name> [location_hint]
  laravel-dev cloudflare r2 delete <bucket_name>
  laravel-dev cloudflare r2 env <project_or_path> <bucket_name> [access_key] [secret_key]
  laravel-dev cloudflare tunnels list [--json]
  laravel-dev cloudflare tunnels create <name>
  laravel-dev cloudflare tunnels token <tunnel_id>
  laravel-dev cloudflare tunnels delete <tunnel_id>
USAGE
}

manage_cloudflare() {
  local script
  script="$(cf_python_script)"

  if [[ ! -f "$script" ]]; then
    echo "Error: Cloudflare Python backend not found at '$script'." >&2
    return 1
  fi

  if [[ $# -eq 0 || "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    cloudflare_usage
    return 0
  fi

  python3 "$script" "$@"
}
