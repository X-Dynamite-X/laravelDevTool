#!/usr/bin/env bash

set -euo pipefail

# Reverb WebSocket Manager for Laravel Dev
# Handles Laravel Reverb lifecycle, status tracking and logs

REVERB_RUNTIME_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev/runtime"

ensure_reverb_runtime_dir() {
  mkdir -p "$REVERB_RUNTIME_DIR"
}

project_has_reverb() {
  local project_path="$1"
  if [[ -f "$project_path/config/reverb.php" ]]; then
    return 0
  fi
  if [[ -f "$project_path/composer.json" ]] && grep -q '"laravel/reverb"' "$project_path/composer.json" 2>/dev/null; then
    return 0
  fi
  if [[ -f "$project_path/.env" ]] && grep -qE '^REVERB_APP_KEY=|^BROADCAST_CONNECTION=reverb' "$project_path/.env" 2>/dev/null; then
    return 0
  fi
  return 1
}

get_reverb_env_field() {
  local project_path="$1"
  local key="$2"
  local default_val="${3:-}"
  if [[ -f "$project_path/.env" ]]; then
    local val
    val="$(grep -E "^${key}=" "$project_path/.env" | head -n1 | cut -d= -f2- | tr -d '"'\'' ' || true)"
    if [[ -n "$val" ]]; then
      echo "$val"
      return 0
    fi
  fi
  echo "$default_val"
}

get_reverb_pid() {
  local project_path="$1"
  local real_path
  real_path="$(readlink -f "$project_path" 2>/dev/null || echo "$project_path")"

  # 1. Check PID file in runtime dir
  local pid_file="$REVERB_RUNTIME_DIR/reverb-$(basename "$project_path").pid"
  if [[ -f "$pid_file" ]]; then
    local p
    p="$(cat "$pid_file" 2>/dev/null || true)"
    if [[ -n "$p" && -d "/proc/$p" ]]; then
      local proc_cwd
      proc_cwd="$(readlink -f "/proc/$p/cwd" 2>/dev/null || true)"
      if [[ "$proc_cwd" == "$real_path" ]]; then
        echo "$p"
        return 0
      fi
    fi
  fi

  # 2. Check running processes with artisan reverb:start
  local pid=""
  while IFS= read -r pid; do
    [[ -n "$pid" ]] || continue
    local proc_cwd
    proc_cwd="$(readlink -f "/proc/$pid/cwd" 2>/dev/null || true)"
    if [[ "$proc_cwd" == "$real_path" ]]; then
      echo "$pid"
      return 0
    fi
  done < <(pgrep -f "artisan.*reverb:start" 2>/dev/null || true)

  return 1
}

status_reverb() {
  local project_name="$1"
  local project_path="${2:-}"
  if [[ -z "$project_path" ]] && declare -F get_project_field >/dev/null 2>&1; then
    project_path="$(get_project_field "$project_name" "PROJECT_PATH" 2>/dev/null || true)"
  fi
  project_path="${project_path:-$SITES_DIR/$project_name}"

  if ! project_has_reverb "$project_path"; then
    echo "reverb=not_configured"
    return 0
  fi

  local host port scheme
  host="$(get_reverb_env_field "$project_path" "REVERB_HOST" "localhost")"
  port="$(get_reverb_env_field "$project_path" "REVERB_PORT" "8080")"
  scheme="$(get_reverb_env_field "$project_path" "REVERB_SCHEME" "http")"

  local pid
  if pid="$(get_reverb_pid "$project_path")"; then
    echo "reverb=running pid=$pid host=$host port=$port scheme=$scheme url=${scheme}://${host}:${port}"
    return 0
  else
    echo "reverb=stopped host=$host port=$port scheme=$scheme url=${scheme}://${host}:${port}"
    return 0
  fi
}

start_reverb() {
  local project_name="$1"
  local project_path="${2:-}"
  if [[ -z "$project_path" ]] && declare -F get_project_field >/dev/null 2>&1; then
    project_path="$(get_project_field "$project_name" "PROJECT_PATH" 2>/dev/null || true)"
  fi
  project_path="${project_path:-$SITES_DIR/$project_name}"

  if [[ ! -d "$project_path" ]]; then
    echo "Error: project path '$project_path' does not exist."
    return 1
  fi

  local pid
  if pid="$(get_reverb_pid "$project_path")"; then
    echo "Reverb is already running for '$project_name' (PID: $pid)."
    return 0
  fi

  ensure_reverb_runtime_dir
  local pid_file="$REVERB_RUNTIME_DIR/reverb-${project_name}.pid"
  local log_file="$REVERB_RUNTIME_DIR/reverb-${project_name}.log"

  local php_bin
  php_bin="$(command -v php || echo "php")"
  if declare -F detect_project_php_version >/dev/null 2>&1; then
    local v
    v="$(detect_project_php_version "$project_name")"
    if command -v "php${v}" >/dev/null 2>&1; then
      php_bin="php${v}"
    fi
  fi

  local host port
  host="$(get_reverb_env_field "$project_path" "REVERB_HOST" "0.0.0.0")"
  port="$(get_reverb_env_field "$project_path" "REVERB_PORT" "8080")"

  echo "Starting Reverb for '$project_name' on $host:$port..."
  (
    cd "$project_path"
    nohup "$php_bin" artisan reverb:start --host="$host" --port="$port" --debug >> "$log_file" 2>&1 &
    echo $! > "$pid_file"
  )

  sleep 0.5
  if pid="$(get_reverb_pid "$project_path")"; then
    echo "Reverb started successfully (PID: $pid)."
    return 0
  else
    echo "Error: Reverb failed to start. Check log at: $log_file"
    return 1
  fi
}

stop_reverb() {
  local project_name="$1"
  local project_path="${2:-}"
  if [[ -z "$project_path" ]] && declare -F get_project_field >/dev/null 2>&1; then
    project_path="$(get_project_field "$project_name" "PROJECT_PATH" 2>/dev/null || true)"
  fi
  project_path="${project_path:-$SITES_DIR/$project_name}"

  local pid
  if ! pid="$(get_reverb_pid "$project_path")"; then
    echo "Reverb is not running for '$project_name'."
    return 0
  fi

  echo "Stopping Reverb for '$project_name' (PID: $pid)..."
  kill -TERM "$pid" 2>/dev/null || kill -9 "$pid" 2>/dev/null || true
  rm -f "$REVERB_RUNTIME_DIR/reverb-${project_name}.pid"

  local count=0
  while kill -0 "$pid" 2>/dev/null && [[ $count -lt 20 ]]; do
    sleep 0.1
    count=$((count + 1))
  done
  if kill -0 "$pid" 2>/dev/null; then
    kill -KILL "$pid" 2>/dev/null || true
  fi

  echo "Reverb stopped."
}

restart_reverb() {
  local project_name="$1"
  local project_path="${2:-}"
  stop_reverb "$project_name" "$project_path"
  sleep 0.5
  start_reverb "$project_name" "$project_path"
}

log_reverb() {
  local project_name="$1"
  local log_file="$REVERB_RUNTIME_DIR/reverb-${project_name}.log"
  if [[ -f "$log_file" ]]; then
    tail -n 100 "$log_file"
  else
    echo "No log file found for '$project_name' at $log_file"
  fi
}

