#!/usr/bin/env bash

set -euo pipefail

can_connect_mysql() {
  local host="$1"
  local user="$2"
  local pass="${3:-}"
  local port="${4:-${DB_PORT:-3306}}"

  MYSQL_PWD="$pass" mysql -h "$host" -P "$port" -u "$user" -e "SELECT 1;" >/dev/null 2>&1
}

escape_sql_string() {
  printf "%s" "$1" | sed "s/'/''/g"
}

can_connect_mysql_as_sudo_root() {
  sudo_cmd mysql -e "SELECT 1;" >/dev/null 2>&1
}

create_database() {
  local db="$1"
  local host="${DB_HOST:-127.0.0.1}"
  local port="${DB_PORT:-3306}"
  local user="${DB_USER:-$USER}"
  local pass="${DB_PASSWORD:-}"
  local sudo_user
  local esc_user
  local esc_pass

  if ! can_connect_mysql "$host" "$user" "$pass" "$port"; then
    if can_connect_mysql "127.0.0.1" "$USER" "" "$port"; then
      host="127.0.0.1"
      user="$USER"
      pass=""
    elif can_connect_mysql "127.0.0.1" "root" "" "$port"; then
      host="127.0.0.1"
      user="root"
      pass=""
    elif can_connect_mysql_as_sudo_root; then
      sudo_user="${USER:-devuser}"
      if [[ ! "$sudo_user" =~ ^[a-zA-Z0-9_]+$ ]]; then
        sudo_user="devuser"
      fi
      esc_user="$(escape_sql_string "$sudo_user")"
      esc_pass="$(escape_sql_string "")"
      sudo_cmd mysql -e "CREATE DATABASE IF NOT EXISTS \`$db\`;"
      sudo_cmd mysql -e "CREATE USER IF NOT EXISTS '$esc_user'@'127.0.0.1' IDENTIFIED BY '$esc_pass';"
      sudo_cmd mysql -e "GRANT ALL PRIVILEGES ON \`$db\`.* TO '$esc_user'@'127.0.0.1'; FLUSH PRIVILEGES;"
      host="127.0.0.1"
      user="$sudo_user"
      pass=""
    else
      echo "Error: could not connect to MySQL/MariaDB. Update DB settings in ~/.config/laravel-dev/config.env"
      exit 1
    fi
  fi

  DB_HOST="$host"
  DB_PORT="$port"
  DB_USER="$user"
  DB_PASSWORD="$pass"
  MYSQL_PWD="$DB_PASSWORD" mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -e "CREATE DATABASE IF NOT EXISTS \`$db\`;"
}

can_connect_pgsql() {
  local host="$1"
  local port="${2:-5432}"
  local user="$3"
  local pass="${4:-}"
  local db="${5:-postgres}"

  PGPASSWORD="$pass" psql -h "$host" -p "$port" -U "$user" -d "$db" -c "SELECT 1;" >/dev/null 2>&1
}

can_connect_pgsql_as_sudo() {
  sudo_cmd -u postgres psql -c "SELECT 1;" >/dev/null 2>&1
}

create_pgsql_database() {
  local name="$1"
  local project_dir="${2:-${LARAVEL_SITES_DIR:-$HOME/Sites}/$name}"
  local host="${DB_HOST:-127.0.0.1}"
  local port="${DB_PORT:-5432}"
  local user="${DB_USER:-$USER}"
  local pass="${DB_PASSWORD:-}"
  local db_name="${name//-/_}"
  local db_user="${name//-/_}_user"
  local db_pass=""
  local env_file="$project_dir/.env"

  db_name="$(echo "$db_name" | tr '[:upper:]' '[:lower:]')"
  db_user="$(echo "$db_user" | tr '[:upper:]' '[:lower:]')"

  # Ensure PostgreSQL service prerequisites and startup if local
  if [[ "$host" == "127.0.0.1" || "$host" == "localhost" ]]; then
    if declare -f is_service_active >/dev/null 2>&1 && ! is_service_active "postgresql"; then
      declare -f ensure_service_prerequisites >/dev/null 2>&1 && ensure_service_prerequisites "postgresql" 2>/dev/null || true
      declare -f control_service >/dev/null 2>&1 && control_service "start" "postgresql" >/dev/null 2>&1 || true
    fi
  fi

  if can_connect_pgsql "$host" "$port" "$user" "$pass"; then
    echo "Connecting to PostgreSQL at $host:$port as $user..."
    PGPASSWORD="$pass" psql -h "$host" -p "$port" -U "$user" -d postgres -tc "SELECT 1 FROM pg_database WHERE datname='$db_name'" 2>/dev/null | grep -q 1 || \
      PGPASSWORD="$pass" psql -h "$host" -p "$port" -U "$user" -d postgres -c "CREATE DATABASE \"$db_name\";" 2>/dev/null || true
  elif can_connect_pgsql "$host" "$port" "postgres" ""; then
    user="postgres"
    pass=""
    echo "Connecting to PostgreSQL as postgres..."
    PGPASSWORD="" psql -h "$host" -p "$port" -U "postgres" -d postgres -tc "SELECT 1 FROM pg_database WHERE datname='$db_name'" 2>/dev/null | grep -q 1 || \
      PGPASSWORD="" psql -h "$host" -p "$port" -U "postgres" -d postgres -c "CREATE DATABASE \"$db_name\";" 2>/dev/null || true
  else
    if [[ "$host" == "127.0.0.1" || "$host" == "localhost" ]]; then
      declare -f ensure_service_prerequisites >/dev/null 2>&1 && ensure_service_prerequisites "postgresql" 2>/dev/null || true
    fi
    if can_connect_pgsql_as_sudo; then
      echo "Configuring PostgreSQL database and user via sudo -u postgres..."
      db_pass="$(head -c 16 /dev/urandom 2>/dev/null | base64 2>/dev/null | tr -dc 'a-zA-Z0-9' | head -c 16 || echo "")"
      if [[ -z "$db_pass" ]]; then
        db_pass="secret_${RANDOM}"
      fi

      # Create role if not exists
      sudo_cmd -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='$db_user'" 2>/dev/null | grep -q 1 || \
        sudo_cmd -u postgres psql -c "CREATE ROLE \"$db_user\" WITH LOGIN PASSWORD '$db_pass';" 2>/dev/null || true
      sudo_cmd -u postgres psql -c "ALTER ROLE \"$db_user\" WITH PASSWORD '$db_pass';" 2>/dev/null || true

      # Create database if not exists
      sudo_cmd -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='$db_name'" 2>/dev/null | grep -q 1 || \
        sudo_cmd -u postgres psql -c "CREATE DATABASE \"$db_name\" OWNER \"$db_user\";" 2>/dev/null || true
      sudo_cmd -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE \"$db_name\" TO \"$db_user\";" 2>/dev/null || true
      sudo_cmd -u postgres psql -d "$db_name" -c "GRANT ALL ON SCHEMA public TO \"$db_user\";" 2>/dev/null || true

      user="$db_user"
      pass="$db_pass"
    else
      echo "Notice: Could not connect to PostgreSQL. If postgresql is not running, start it or run: laravel-dev service-install postgresql"
    fi
  fi

  if [[ -f "$env_file" ]]; then
    update_env_key "$env_file" "DB_CONNECTION" "pgsql"
    update_env_key "$env_file" "DB_HOST" "$host"
    update_env_key "$env_file" "DB_PORT" "$port"
    update_env_key "$env_file" "DB_DATABASE" "$db_name"
    update_env_key "$env_file" "DB_USERNAME" "$user"
    update_env_key "$env_file" "DB_PASSWORD" "$pass"
  fi
}
