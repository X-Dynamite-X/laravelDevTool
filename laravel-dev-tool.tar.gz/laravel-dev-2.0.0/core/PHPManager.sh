#!/usr/bin/env bash

set -euo pipefail

normalize_php_version() {
  local version="$1"
  if [[ "$version" =~ ^[0-9]+\.[0-9]+$ ]]; then
    echo "$version"
    return 0
  fi
  if [[ "$version" =~ ^php([0-9]+\.[0-9]+)$ ]]; then
    echo "${BASH_REMATCH[1]}"
    return 0
  fi
  echo ""
}

list_available_php_versions() {
  local versions=()
  local cmd=""
  local version=""
  local sock=""

  if command -v php >/dev/null 2>&1; then
    version="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  fi

  while IFS= read -r cmd; do
    version="$(normalize_php_version "${cmd##*/}")"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  done < <(compgen -c | grep -E '^php[0-9]+\.[0-9]+$' | sort -u || true)

  while IFS= read -r sock; do
    version="$(printf '%s\n' "$sock" | sed -nE 's#.*php([0-9]+\.[0-9]+)-fpm\.sock#\1#p')"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  done < <(find /run/php /run/php-fpm -maxdepth 1 -type s -name 'php*-fpm.sock' 2>/dev/null || true)

  if [[ ${#versions[@]} -eq 0 ]]; then
    echo "8.4"
    return 0
  fi

  printf '%s\n' "${versions[@]}" | awk 'NF' | sort -Vu | uniq
}

list_php_fpm_services() {
  local units=()

  if command -v systemctl >/dev/null 2>&1; then
    while IFS= read -r unit; do
      unit="${unit%.service}"
      [[ -n "$unit" ]] && units+=("$unit")
    done < <(systemctl list-unit-files --type=service --no-legend 2>/dev/null | awk '{print $1}' | grep -E '^php.*fpm\.service$' | sort -u || true)
  fi

  if [[ ${#units[@]} -eq 0 ]]; then
    units+=(php-fpm)
  fi

  printf '%s\n' "${units[@]}" | awk 'NF' | sort -u
}

default_php_version() {
  local v
  local best=""
  # Prefer the newest PHP version that has mbstring extension installed and working
  while IFS= read -r v; do
    [[ -n "$v" ]] || continue
    if command -v "php${v}" >/dev/null 2>&1; then
      if "php${v}" -m 2>/dev/null | grep -qi 'mbstring'; then
        best="$v"
      fi
    fi
  done < <(list_available_php_versions)

  if [[ -n "$best" ]]; then
    echo "$best"
    return 0
  fi

  list_available_php_versions | tail -n1
}

get_php_socket() {
  local version="$1"
  local candidates=(
    "/run/php/php${version}-fpm.sock"
    "/run/php-fpm/php${version}-fpm.sock"
    "/run/php-fpm/www.sock"
    "/run/php-fpm/php-fpm.sock"
  )
  local sock=""

  for sock in "${candidates[@]}"; do
    if [[ -S "$sock" ]]; then
      echo "$sock"
      return 0
    fi
  done

  echo "/run/php/php${version}-fpm.sock"
}

php_fpm_unit() {
  local version="$1"
  if command -v systemctl >/dev/null 2>&1; then
    if systemctl list-unit-files --type=service 2>/dev/null | grep -q "php${version}-fpm\.service"; then
      echo "php${version}-fpm"
      return 0
    elif systemctl list-unit-files --type=service 2>/dev/null | grep -q "php-fpm\.service"; then
      echo "php-fpm"
      return 0
    fi
  fi
  echo "php${version}-fpm"
}

restart_php_fpm() {
  local version="$1"
  local unit
  unit="$(php_fpm_unit "$version")"
  if command -v systemctl >/dev/null 2>&1; then
    sudo_cmd systemctl restart "$unit" >/dev/null 2>&1 || sudo_cmd service "$unit" restart >/dev/null 2>&1 || true
  fi
}

php_xdebug_status() {
  local version="$1"
  local bin="php${version}"
  command -v "$bin" >/dev/null 2>&1 || bin="php"
  if "$bin" -m 2>/dev/null | grep -qi "xdebug"; then
    echo "on"
  else
    echo "off"
  fi
}

php_xdebug_toggle() {
  local version="$1"
  local state="$2" # on | off
  require_system_access

  if command -v phpenmod >/dev/null 2>&1 && command -v phpdismod >/dev/null 2>&1; then
    if [[ "$state" == "on" ]]; then
      sudo_cmd phpenmod -v "$version" xdebug || true
    else
      sudo_cmd phpdismod -v "$version" xdebug || true
    fi
  else
    local inis=(
      "/etc/php/${version}/mods-available/xdebug.ini"
      "/etc/php/${version}/conf.d/xdebug.ini"
    )
    local extra
    for extra in /etc/php.d/*xdebug.ini /etc/php/conf.d/*xdebug.ini; do  # Fedora / Arch
      inis+=("$extra")
    done
    for f in "${inis[@]}"; do
      if [[ -f "$f" ]]; then
        if [[ "$state" == "on" ]]; then
          sudo_cmd sed -i 's/^;zend_extension/zend_extension/' "$f"
        else
          sudo_cmd sed -i 's/^zend_extension/;zend_extension/' "$f"
        fi
      fi
    done
  fi
  restart_php_fpm "$version"
  echo "Xdebug is now $state for PHP $version"
}

php_ini_get() {
  local version="$1"
  local key="$2"
  local bin="php${version}"
  command -v "$bin" >/dev/null 2>&1 || bin="php"
  "$bin" -r "echo ini_get('$key');" 2>/dev/null || true
}

php_ini_set() {
  local version="$1"
  local key="$2"
  local value="$3"
  require_system_access

  local targets=(
    "/etc/php/${version}/fpm/conf.d/99-laravel-dev.ini"
    "/etc/php/${version}/cli/conf.d/99-laravel-dev.ini"
  )
  for t in "${targets[@]}"; do
    local dir="${t%/*}"
    if [[ -d "$dir" ]]; then
      sudo_cmd mkdir -p "$dir"
      if sudo_cmd grep -qE "^${key}\s*=" "$t" 2>/dev/null; then
        sudo_cmd sed -i "s|^${key}\s*=.*|${key} = ${value}|" "$t"
      else
        echo "${key} = ${value}" | sudo_cmd tee -a "$t" >/dev/null
      fi
    fi
  done
  restart_php_fpm "$version"
  echo "Updated $key = $value for PHP $version"
}

php_ext_install() {
  local version="$1"
  local ext="$2"
  require_system_access

  if command -v apt-get >/dev/null 2>&1; then
    sudo_cmd apt-get update -qq
    sudo_cmd apt-get install -y "php${version}-${ext}" || sudo_cmd apt-get install -y "php-${ext}"
  elif command -v dnf >/dev/null 2>&1; then
    sudo_cmd dnf install -y "php-${ext}" || sudo_cmd dnf install -y "php${version}-${ext}"
  elif command -v pacman >/dev/null 2>&1; then
    sudo_cmd pacman -S --noconfirm "php-${ext}"
  fi
  restart_php_fpm "$version"
  echo "Installed extension $ext for PHP $version"
}
