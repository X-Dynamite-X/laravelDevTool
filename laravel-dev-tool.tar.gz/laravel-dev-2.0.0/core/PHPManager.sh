#!/usr/bin/env bash

set -euo pipefail

normalize_php_version() {
  local version="$1"
  if [[ "$version" =~ ^[0-9]+\.[0-9]+$ ]]; then
    echo "$version"
    return 0
  fi
  if [[ "$version" =~ ^php([0-9]+\.[0-9]+)$ ]]; then
    echo "${BASH_REMATCH[1]}"
    return 0
  fi
  echo ""
}

list_available_php_versions() {
  local versions=()
  local cmd=""
  local version=""
  local sock=""

  if command -v php >/dev/null 2>&1; then
    version="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  fi

  while IFS= read -r cmd; do
    version="$(normalize_php_version "${cmd##*/}")"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  done < <(compgen -c | grep -E '^php[0-9]+\.[0-9]+$' | sort -u || true)

  for remi_bin in /opt/remi/php*/root/usr/bin/php; do
    if [[ -x "$remi_bin" ]]; then
      version="$("$remi_bin" -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
      if [[ -n "$version" ]]; then
        versions+=("$version")
      fi
    fi
  done

  while IFS= read -r sock; do
    version="$(printf '%s\n' "$sock" | sed -nE 's#.*php([0-9]+\.[0-9]+)-fpm\.sock#\1#p')"
    if [[ -n "$version" ]]; then
      versions+=("$version")
    fi
  done < <(find /run/php /run/php-fpm -maxdepth 1 -type s -name 'php*-fpm.sock' 2>/dev/null || true)

  if [[ ${#versions[@]} -eq 0 ]]; then
    echo "8.4"
    return 0
  fi

  printf '%s\n' "${versions[@]}" | awk 'NF' | sort -Vu | uniq
}

list_php_fpm_services() {
  local units=()

  if command -v systemctl >/dev/null 2>&1; then
    while IFS= read -r unit; do
      unit="${unit%.service}"
      [[ -n "$unit" ]] && units+=("$unit")
    done < <(systemctl list-unit-files --type=service --no-legend 2>/dev/null | awk '{print $1}' | grep -E '^php.*fpm\.service$' | sort -u || true)
  fi

  if [[ ${#units[@]} -eq 0 ]]; then
    units+=(php-fpm)
  fi

  printf '%s\n' "${units[@]}" | awk 'NF' | sort -u
}

default_php_version() {
  local v
  local best=""
  # Prefer the newest PHP version that has mbstring extension installed and working
  while IFS= read -r v; do
    [[ -n "$v" ]] || continue
    if command -v "php${v}" >/dev/null 2>&1; then
      if "php${v}" -m 2>/dev/null | grep -qi 'mbstring'; then
        best="$v"
      fi
    fi
  done < <(list_available_php_versions)

  if [[ -n "$best" ]]; then
    echo "$best"
    return 0
  fi

  list_available_php_versions | tail -n1
}

get_php_socket() {
  local version="$1"
  local nodot="${version//./}"
  local candidates=(
    "/run/php/php${version}-fpm.sock"
    "/run/php-fpm/php${version}-fpm.sock"
    "/var/opt/remi/php${nodot}/run/php-fpm/www.sock"
    "/run/php-fpm/www.sock"
    "/run/php-fpm/php-fpm.sock"
  )
  local sock=""

  for sock in "${candidates[@]}"; do
    if [[ -S "$sock" ]]; then
      echo "$sock"
      return 0
    fi
  done

  echo "/run/php/php${version}-fpm.sock"
}

get_php_debug_socket() {
  local version="$1"
  local candidates=(
    "/run/php/php${version}-fpm-debug.sock"
    "/run/php-fpm/php${version}-fpm-debug.sock"
  )
  for s in "${candidates[@]}"; do
    if [[ -S "$s" ]]; then
      echo "$s"
      return 0
    fi
  done
  echo "/run/php/php${version}-fpm-debug.sock"
}

php_fpm_unit() {
  local version="$1"
  if command -v systemctl >/dev/null 2>&1; then
    if systemctl list-unit-files --type=service 2>/dev/null | grep -q "php${version}-fpm\.service"; then
      echo "php${version}-fpm"
      return 0
    elif systemctl list-unit-files --type=service 2>/dev/null | grep -q "php-fpm\.service"; then
      echo "php-fpm"
      return 0
    fi
  fi
  echo "php${version}-fpm"
}

restart_php_fpm() {
  local version="$1"
  local unit
  unit="$(php_fpm_unit "$version")"
  if command -v systemctl >/dev/null 2>&1; then
    sudo_cmd systemctl restart "$unit" >/dev/null 2>&1 || sudo_cmd service "$unit" restart >/dev/null 2>&1 || true
  fi
}

php_xdebug_status() {
  local version="$1"
  local bin="php${version}"
  command -v "$bin" >/dev/null 2>&1 || bin="php"
  if "$bin" -m 2>/dev/null | grep -qi "xdebug"; then
    echo "on"
  else
    echo "off"
  fi
}

php_xdebug_toggle() {
  local version="$1"
  local state="$2" # on | off
  require_system_access

  if command -v phpenmod >/dev/null 2>&1 && command -v phpdismod >/dev/null 2>&1; then
    if [[ "$state" == "on" ]]; then
      sudo_cmd phpenmod -v "$version" xdebug || true
    else
      sudo_cmd phpdismod -v "$version" xdebug || true
    fi
  else
    local inis=(
      "/etc/php/${version}/mods-available/xdebug.ini"
      "/etc/php/${version}/conf.d/xdebug.ini"
    )
    local extra
    for extra in /etc/php.d/*xdebug.ini /etc/php/conf.d/*xdebug.ini; do  # Fedora / Arch
      inis+=("$extra")
    done
    for f in "${inis[@]}"; do
      if [[ -f "$f" ]]; then
        if [[ "$state" == "on" ]]; then
          sudo_cmd sed -i 's/^;zend_extension/zend_extension/' "$f"
        else
          sudo_cmd sed -i 's/^zend_extension/;zend_extension/' "$f"
        fi
      fi
    done
  fi
  restart_php_fpm "$version"
  echo "Xdebug is now $state for PHP $version"
}

php_xdebug_configure_jit() {
  local version="$1"
  require_system_access

  # First make sure xdebug is enabled
  php_xdebug_toggle "$version" "on" >/dev/null 2>&1 || true

  local candidates=(
    "/etc/php/${version}/mods-available/xdebug.ini"
    "/etc/php/${version}/conf.d/xdebug.ini"
    "/etc/php/${version}/fpm/conf.d/20-xdebug.ini"
    "/etc/php/${version}/cli/conf.d/20-xdebug.ini"
  )
  local extra
  for extra in /etc/php.d/*xdebug.ini /etc/php/conf.d/*xdebug.ini; do
    candidates+=("$extra")
  done

  # Resolve symlinks and de-duplicate: on Debian/Ubuntu conf.d/20-xdebug.ini is a symlink to
  # mods-available/xdebug.ini, and `sed -i` on the link would replace it with a plain copy,
  # after which phpdismod can no longer turn Xdebug off.
  local -A seen=()
  local inis=() f real
  for f in "${candidates[@]}"; do
    [[ -e "$f" ]] || continue
    real="$(readlink -f "$f")"
    [[ -f "$real" && -z "${seen[$real]:-}" ]] || continue
    seen[$real]=1
    inis+=("$real")
  done

  if [[ ${#inis[@]} -eq 0 ]]; then
    echo "Error: no xdebug.ini found for PHP $version. Install it first: laravel-dev php-ext $version install xdebug"
    return 1
  fi

  local settings=(
    "xdebug.mode=develop,debug"
    "xdebug.start_with_request=trigger"
    "xdebug.trigger_value=LARAVEL_DEV"
    "xdebug.client_host=127.0.0.1"
    "xdebug.client_port=9003"
  )
  local kv key val
  for f in "${inis[@]}"; do
    for kv in "${settings[@]}"; do
      key="${kv%%=*}"
      val="${kv#*=}"
      if grep -qE "^[;[:space:]]*${key//./\\.}[[:space:]]*=" "$f"; then
        sudo_cmd sed -i -E "s|^[;[:space:]]*${key//./\\.}[[:space:]]*=.*|${key} = ${val}|" "$f"
      else
        echo "${key} = ${val}" | sudo_cmd tee -a "$f" >/dev/null
      fi
    done
  done

  restart_php_fpm "$version"
  echo "Xdebug configured in JIT (Just-In-Time trigger) mode for PHP $version."
  echo "Debug a web request: add ?XDEBUG_TRIGGER=LARAVEL_DEV or set the XDEBUG_TRIGGER=LARAVEL_DEV cookie."
  echo "Debug artisan:       laravel-dev debug <project> artisan <command>"
}

php_fpm_manage_debug_pool() {
  local version="$1"
  local action="${2:-enable}" # enable | disable | status
  local nodot="${version//./}"

  local pool_dir=""
  local candidates=(
    "/etc/php/${version}/fpm/pool.d"
    "/etc/php-fpm.d"
    "/etc/php/php-fpm.d"
    "/var/opt/remi/php${nodot}/etc/php-fpm.d"
  )
  for c in "${candidates[@]}"; do
    if [[ -d "$c" ]]; then
      pool_dir="$c"
      break
    fi
  done

  local conf_file="${pool_dir}/laravel-dev-debug.conf"
  local sock="/run/php/php${version}-fpm-debug.sock"

  if [[ "$action" == "status" ]]; then
    if [[ -f "$conf_file" ]]; then
      echo "Debug pool for PHP $version: enabled ($sock)"
      return 0
    else
      echo "Debug pool for PHP $version: disabled"
      return 1
    fi
  elif [[ "$action" == "disable" ]]; then
    require_system_access
    if [[ -f "$conf_file" ]]; then
      sudo_cmd rm -f "$conf_file"
      restart_php_fpm "$version"
    fi
    echo "Debug pool for PHP $version disabled."
    return 0
  fi

  require_system_access
  if [[ -z "$pool_dir" ]]; then
    echo "Error: PHP-FPM pool directory not found for PHP $version." >&2
    return 1
  fi

  local user="www-data" group="www-data"
  id -u www-data >/dev/null 2>&1 || user="nginx"
  id -g www-data >/dev/null 2>&1 || group="nginx"

  cat <<EOF | sudo_cmd tee "$conf_file" >/dev/null
[laravel-dev-debug-${version}]
user = $user
group = $group
listen = $sock
listen.owner = $user
listen.group = $group
listen.mode = 0660
pm = ondemand
pm.max_children = 5
pm.process_idle_timeout = 60s
php_admin_value[xdebug.mode] = debug,develop
php_admin_value[xdebug.start_with_request] = yes
php_admin_value[xdebug.client_host] = 127.0.0.1
php_admin_value[xdebug.client_port] = 9003
EOF

  restart_php_fpm "$version"
  echo "PHP-FPM debug pool configured for PHP $version at $sock"
}

php_coverage_command() {
  local project="$1"
  shift || true

  local project_path
  project_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$project_path" || ! -d "$project_path" ]]; then
    project_path="${SITES_DIR:-$HOME/Sites}/$project"
  fi
  if [[ ! -d "$project_path" ]]; then
    echo "Error: Project directory '$project_path' not found." >&2
    return 1
  fi

  local version
  version="$(get_project_php_version "$project" 2>/dev/null || echo "8.3")"
  local bin="php${version}"
  command -v "$bin" >/dev/null 2>&1 || bin="php"

  local cmd=()
  if [[ $# -eq 0 ]]; then
    if [[ -f "$project_path/artisan" ]]; then
      cmd=("$bin" "artisan" "test" "--coverage")
    elif [[ -x "$project_path/vendor/bin/pest" ]]; then
      cmd=("$bin" "$project_path/vendor/bin/pest" "--coverage")
    elif [[ -x "$project_path/vendor/bin/phpunit" ]]; then
      cmd=("$bin" "$project_path/vendor/bin/phpunit" "--coverage")
    else
      cmd=("$bin" "artisan" "test" "--coverage")
    fi
  else
    if [[ "$1" == "artisan" ]]; then
      shift
      cmd=("$bin" "artisan" "$@")
    elif [[ "$1" == "pest" ]]; then
      shift
      cmd=("$bin" "$project_path/vendor/bin/pest" "$@")
    elif [[ "$1" == "phpunit" ]]; then
      shift
      cmd=("$bin" "$project_path/vendor/bin/phpunit" "$@")
    else
      cmd=("$@")
    fi
  fi

  echo "Running test coverage with Xdebug for '$project' (PHP $version)..."
  (
    cd "$project_path"
    export XDEBUG_MODE=coverage
    exec "${cmd[@]}"
  )
}

php_debug_artisan() {
  local project="$1"
  shift

  local project_path
  project_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$project_path" || ! -d "$project_path" ]]; then
    project_path="$SITES_DIR/$project"
  fi

  if [[ ! -d "$project_path" ]]; then
    echo "Error: Project directory '$project_path' not found."
    return 1
  fi

  local php_version
  php_version="$(get_project_php_version "$project" 2>/dev/null || echo "")"
  local php_bin="php"
  if [[ -n "$php_version" ]] && command -v "php$php_version" >/dev/null 2>&1; then
    php_bin="php$php_version"
  fi

  echo "Starting artisan command with Xdebug trigger enabled..."
  (cd "$project_path" && XDEBUG_TRIGGER="LARAVEL_DEV" XDEBUG_SESSION="LARAVEL_DEV" "$php_bin" artisan "$@")
}

php_ini_get() {
  local version="$1"
  local key="$2"
  local bin="php${version}"
  command -v "$bin" >/dev/null 2>&1 || bin="php"
  "$bin" -r "echo ini_get('$key');" 2>/dev/null || true
}

php_ini_set() {
  local version="$1"
  local key="$2"
  local value="$3"
  require_system_access

  local targets=(
    "/etc/php/${version}/fpm/conf.d/99-laravel-dev.ini"
    "/etc/php/${version}/cli/conf.d/99-laravel-dev.ini"
  )
  for t in "${targets[@]}"; do
    local dir="${t%/*}"
    if [[ -d "$dir" ]]; then
      sudo_cmd mkdir -p "$dir"
      if sudo_cmd grep -qE "^${key}\s*=" "$t" 2>/dev/null; then
        sudo_cmd sed -i "s|^${key}\s*=.*|${key} = ${value}|" "$t"
      else
        echo "${key} = ${value}" | sudo_cmd tee -a "$t" >/dev/null
      fi
    fi
  done
  restart_php_fpm "$version"
  echo "Updated $key = $value for PHP $version"
}

php_ext_install() {
  local version="$1"
  local ext="$2"
  require_system_access

  if command -v apt-get >/dev/null 2>&1; then
    sudo_cmd apt-get update -qq
    sudo_cmd apt-get install -y "php${version}-${ext}" || sudo_cmd apt-get install -y "php-${ext}"
  elif command -v dnf >/dev/null 2>&1; then
    sudo_cmd dnf install -y "php-${ext}" || sudo_cmd dnf install -y "php${version}-${ext}"
  elif command -v pacman >/dev/null 2>&1; then
    sudo_cmd pacman -S --noconfirm "php-${ext}"
  fi
  restart_php_fpm "$version"
  echo "Installed extension $ext for PHP $version"
}

ensure_php_apt_repo() {
  local os_id=""
  if [[ -f /etc/os-release ]]; then
    # shellcheck source=/dev/null
    os_id="$(grep -E '^ID=' /etc/os-release | cut -d= -f2 | tr -d '"')"
  fi

  if [[ "$os_id" == "ubuntu" || "$os_id" == "linuxmint" || "$os_id" == "pop" ]]; then
    if ! grep -rq "ondrej/php" /etc/apt/sources.list /etc/apt/sources.list.d/ 2>/dev/null; then
      echo "Adding Ondřej Surý PHP PPA for Ubuntu..."
      sudo_cmd apt-get update -qq
      sudo_cmd apt-get install -y software-properties-common ca-certificates lsb-release apt-transport-https
      sudo_cmd add-apt-repository -y ppa:ondrej/php
      sudo_cmd apt-get update -qq
    fi
  elif [[ "$os_id" == "debian" || "$os_id" == "kali" || "$os_id" == "raspbian" ]]; then
    if [[ ! -f /etc/apt/sources.list.d/sury-php.list ]]; then
      echo "Configuring Sury PHP repository for Debian..."
      sudo_cmd apt-get update -qq
      sudo_cmd apt-get install -y ca-certificates apt-transport-https lsb-release curl gnupg
      sudo_cmd mkdir -p /usr/share/keyrings
      curl -sSLo /tmp/sury-php.gpg https://packages.sury.org/php/apt.gpg
      sudo_cmd gpg --dearmor -o /usr/share/keyrings/deb.sury.org-php.gpg < /tmp/sury-php.gpg 2>/dev/null || sudo_cmd cp /tmp/sury-php.gpg /usr/share/keyrings/deb.sury.org-php.gpg
      rm -f /tmp/sury-php.gpg
      local dist
      dist="$(lsb_release -sc 2>/dev/null || echo "bookworm")"
      echo "deb [signed-by=/usr/share/keyrings/deb.sury.org-php.gpg] https://packages.sury.org/php/ $dist main" | sudo_cmd tee /etc/apt/sources.list.d/sury-php.list >/dev/null
      sudo_cmd apt-get update -qq
    fi
  fi
}

php_install_version() {
  local version="$1"
  require_system_access

  local pkg_manager
  pkg_manager="$(detect_package_manager)"

  echo "Installing PHP $version via $pkg_manager..."

  case "$pkg_manager" in
    apt)
      ensure_php_apt_repo
      sudo_cmd apt-get install -y \
        "php${version}-cli" \
        "php${version}-fpm" \
        "php${version}-common" \
        "php${version}-mbstring" \
        "php${version}-xml" \
        "php${version}-curl" \
        "php${version}-zip" \
        "php${version}-bcmath" \
        "php${version}-intl" \
        "php${version}-gd" \
        "php${version}-mysql" \
        "php${version}-pgsql" \
        "php${version}-sqlite3" \
        "php${version}-redis" || {
          echo "Error: Failed to install PHP $version packages via apt"
          return 1
        }
      local unit
      unit="$(php_fpm_unit "$version")"
      sudo_cmd systemctl enable --now "$unit" >/dev/null 2>&1 || true
      ;;
    dnf|yum)
      echo "Enabling Remi repository on Fedora/RHEL..."
      local fedora_ver
      fedora_ver="$(rpm -E %fedora 2>/dev/null || true)"
      if [[ -n "$fedora_ver" && "$fedora_ver" != "%fedora" ]]; then
        sudo_cmd dnf install -y "https://rpms.remirepo.net/fedora/remi-release-${fedora_ver}.rpm" || true
      fi
      local nodot="${version//./}"
      sudo_cmd dnf install -y \
        "php${nodot}-php-cli" \
        "php${nodot}-php-fpm" \
        "php${nodot}-php-mbstring" \
        "php${nodot}-php-xml" \
        "php${nodot}-php-curl" \
        "php${nodot}-php-zip" \
        "php${nodot}-php-bcmath" \
        "php${nodot}-php-intl" \
        "php${nodot}-php-gd" \
        "php${nodot}-php-mysqlnd" \
        "php${nodot}-php-pgsql" \
        "php${nodot}-php-pdo" \
        "php${nodot}-php-pecl-redis5" || sudo_cmd dnf install -y "php${version}" "php${version}-fpm"
      sudo_cmd systemctl enable --now "php${nodot}-php-fpm" 2>/dev/null || true
      ;;
    pacman)
      echo "Arch Linux uses rolling release. Attempting to install PHP via pacman..."
      sudo_cmd pacman -S --noconfirm "php" "php-fpm" 2>/dev/null || {
        echo "Tip: On Arch Linux, specific historical PHP versions can be installed from AUR: yay -S php${version//./} php${version//./}-fpm"
        return 1
      }
      sudo_cmd systemctl enable --now php-fpm >/dev/null 2>&1 || true
      ;;
    *)
      echo "Error: unsupported package manager for automatic PHP installation"
      return 1
      ;;
  esac

  echo "PHP $version installed successfully!"
}

php_update_version() {
  local version="$1"
  require_system_access

  local pkg_manager
  pkg_manager="$(detect_package_manager)"

  echo "Checking updates for PHP $version..."
  case "$pkg_manager" in
    apt)
      sudo_cmd apt-get update -qq
      sudo_cmd apt-get install --only-upgrade -y "php${version}*" 2>/dev/null || sudo_cmd apt-get install --only-upgrade -y "php${version}"
      ;;
    dnf)
      sudo_cmd dnf upgrade -y "php${version}*"
      ;;
    pacman)
      sudo_cmd pacman -Sy --noconfirm "php${version}" 2>/dev/null || sudo_cmd pacman -Sy --noconfirm php
      ;;
    apk)
      sudo_cmd apk upgrade "php${version}*" 2>/dev/null || sudo_cmd apk upgrade "php${version/./}"
      ;;
    *)
      echo "Error: unsupported package manager"
      return 1
      ;;
  esac

  # Restart FPM service to pick up new patch release
  php_fpm_service_action "restart" "$version" 2>/dev/null || true
  echo "PHP $version updated to latest available release."
}

php_installable_versions() {
  local installed_list
  installed_list="$(list_available_php_versions)"
  local all_versions=("7.4" "8.0" "8.1" "8.2" "8.3" "8.4" "8.5")
  for v in "${all_versions[@]}"; do
    if echo "$installed_list" | grep -qx "$v"; then
      echo "$v:installed"
    else
      echo "$v:available"
    fi
  done
}

