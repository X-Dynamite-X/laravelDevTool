#!/usr/bin/env bash

set -euo pipefail

# Supervisor Manager for Laravel Dev
# Handles queue worker configuration, installation, and lifecycle

SUPERVISOR_CONF_DIR="/etc/supervisor/conf.d"
SUPERVISOR_LOG_DIR="$HOME/.local/log/laravel-dev"

supervisor_is_installed() {
    command -v supervisord >/dev/null 2>&1 && command -v supervisorctl >/dev/null 2>&1
}

detect_package_manager() {
    if command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v pacman >/dev/null 2>&1; then
        echo "pacman"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo ""
    fi
}

ensure_supervisor_installed() {
    if supervisor_is_installed; then
        return 0
    fi

    local pkg_manager
    pkg_manager="$(detect_package_manager)"

    if [[ -z "$pkg_manager" ]]; then
        echo "Warning: Could not detect package manager. Please install supervisor manually."
        return 1
    fi

    echo "Supervisor not found. Attempting to install via $pkg_manager..."

    case "$pkg_manager" in
        apt)
            sudo_cmd apt-get update -qq
            sudo_cmd apt-get install -y supervisor
            ;;
        pacman)
            sudo_cmd pacman -S --noconfirm supervisor
            ;;
        dnf)
            sudo_cmd dnf install -y supervisor
            ;;
        yum)
            sudo_cmd yum install -y supervisor
            ;;
        zypper)
            sudo_cmd zypper install -y supervisor
            ;;
    esac

    # Enable and start supervisor service
    if command -v systemctl >/dev/null 2>&1; then
        sudo_cmd systemctl enable supervisord 2>/dev/null || sudo_cmd systemctl enable supervisor 2>/dev/null || true
        sudo_cmd systemctl start supervisord 2>/dev/null || sudo_cmd systemctl start supervisor 2>/dev/null || true
    fi

    if supervisor_is_installed; then
        echo "Supervisor installed successfully."
        return 0
    else
        echo "Warning: Supervisor installation failed. Queue workers will not be configured."
        return 1
    fi
}

get_supervisor_config_file() {
    local project_name="$1"
    echo "${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}.conf"
}

ensure_log_directory() {
    if [[ ! -d "$SUPERVISOR_LOG_DIR" ]]; then
        mkdir -p "$SUPERVISOR_LOG_DIR"
        chmod 700 "$SUPERVISOR_LOG_DIR"
    fi
    if [[ -n "${SUDO_USER:-}" && "$(id -u)" -eq 0 ]]; then
        chown -R "$SUDO_USER": "$SUPERVISOR_LOG_DIR" 2>/dev/null || true
    fi
}

get_queue_config() {
    local project_name="$1"
    local default_queues="${QUEUE_WORKER_QUEUES:-default}"
    local default_numprocs="${QUEUE_WORKER_NUMPROCS:-1}"
    local default_sleep="${QUEUE_WORKER_SLEEP:-3}"
    local default_tries="${QUEUE_WORKER_TRIES:-3}"
    local default_timeout="${QUEUE_WORKER_TIMEOUT:-90}"

    # Check if project has custom config in registry
    local project_queues project_numprocs project_sleep project_tries project_timeout

    project_queues="$(get_project_field "$project_name" "QUEUE_WORKER_QUEUES" 2>/dev/null || echo "")"
    project_numprocs="$(get_project_field "$project_name" "QUEUE_WORKER_NUMPROCS" 2>/dev/null || echo "")"
    project_sleep="$(get_project_field "$project_name" "QUEUE_WORKER_SLEEP" 2>/dev/null || echo "")"
    project_tries="$(get_project_field "$project_name" "QUEUE_WORKER_TRIES" 2>/dev/null || echo "")"
    project_timeout="$(get_project_field "$project_name" "QUEUE_WORKER_TIMEOUT" 2>/dev/null || echo "")"

    echo "${project_queues:-$default_queues}"
    echo "${project_numprocs:-$default_numprocs}"
    echo "${project_sleep:-$default_sleep}"
    echo "${project_tries:-$default_tries}"
    echo "${project_timeout:-$default_timeout}"
    echo "$(get_project_field "$project_name" "QUEUE_WORKER_MODE" 2>/dev/null || echo "")"
}

# queue (artisan queue:work) or horizon (artisan horizon). Unset means horizon
# when the project requires laravel/horizon, queue otherwise.
resolve_worker_mode() {
    local requested="$1"
    local project_path="$2"
    if [[ "$requested" == "queue" || "$requested" == "horizon" ]]; then
        echo "$requested"
    elif [[ -f "$project_path/composer.json" ]] && grep -q '"laravel/horizon"' "$project_path/composer.json" 2>/dev/null; then
        echo "horizon"
    else
        echo "queue"
    fi
}

get_supervisor_log_file() {
    echo "${SUPERVISOR_LOG_DIR}/laravel-dev-$1.log"
}

create_supervisor_config() {
    local project_name="$1"
    local project_path="$2"
    local php_bin="$3"

    # Validate inputs
    if [[ -z "$project_name" || -z "$project_path" || -z "$php_bin" ]]; then
        echo "Error: Missing required parameters for supervisor config"
        return 1
    fi

    if [[ ! -d "$project_path" ]]; then
        echo "Error: Project path does not exist: $project_path"
        return 1
    fi

    if [[ ! -f "$project_path/artisan" ]]; then
        echo "Warning: artisan not found in $project_path. Skipping supervisor config."
        return 0
    fi

    require_system_access

    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"

    # Get queue configuration
    local queues numprocs sleep tries timeout mode
    {
        read -r queues
        read -r numprocs
        read -r sleep
        read -r tries
        read -r timeout
        read -r mode || true
    } <<< "$(get_queue_config "$project_name")"
    mode="$(resolve_worker_mode "$mode" "$project_path")"

    local command="${php_bin} ${project_path}/artisan queue:work --queue=${queues} --sleep=${sleep} --tries=${tries} --timeout=${timeout}"
    local stopwait=$(( timeout + 30 ))
    if [[ "$mode" == "horizon" ]]; then
        # Horizon spawns and balances its own workers; one supervisor process is enough.
        command="${php_bin} ${project_path}/artisan horizon"
        numprocs=1
        stopwait=3600
    fi

    ensure_log_directory

    # Generate supervisor config
    local log_file
    log_file="$(get_supervisor_log_file "$project_name")"
    local current_user
    # When invoked through sudo (e.g. from the dashboard) $USER is root.
    current_user="${SUDO_USER:-${USER:-$(id -un)}}"

    sudo_cmd mkdir -p "$SUPERVISOR_CONF_DIR"

    sudo_cmd tee "$config_file" > /dev/null <<EOF
[program:laravel-dev-${project_name}]
process_name=%(program_name)s_%(process_num)02d
command=${command}
directory=${project_path}
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
numprocs=${numprocs}
redirect_stderr=true
stdout_logfile=${log_file}
stdout_logfile_maxbytes=10MB
stdout_logfile_backups=2
stopwaitsecs=${stopwait}
user=${current_user}
EOF

    echo "Supervisor config created: $config_file"
    if [[ "$mode" == "horizon" ]]; then
        echo "  Mode: horizon"
    else
        echo "  Mode: queue:work"
        echo "  Queue: $queues"
        echo "  Workers: $numprocs"
    fi
    echo "  Log: $log_file"

    return 0
}

remove_supervisor_config() {
    local project_name="$1"

    if [[ -z "$project_name" ]]; then
        return 0
    fi

    if ! supervisor_is_installed; then
        return 0
    fi

    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"

    if [[ ! -f "$config_file" ]]; then
        return 0
    fi

    require_system_access

    # Stop the worker first
    stop_supervisor_worker "$project_name" 2>/dev/null || true

    sudo_cmd rm -f "$config_file"
    echo "Removed supervisor config for: $project_name"
}

reload_supervisor() {
    if ! supervisor_is_installed; then
        return 0
    fi

    require_system_access

    sudo_cmd supervisorctl reread >/dev/null 2>&1 || true
    sudo_cmd supervisorctl update >/dev/null 2>&1 || true
}

start_supervisor_worker() {
    local project_name="$1"

    if ! supervisor_is_installed; then
        return 0
    fi

    require_system_access

    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"

    if [[ ! -f "$config_file" ]]; then
        echo "Warning: Supervisor config not found for $project_name"
        return 1
    fi

    sudo_cmd supervisorctl start "laravel-dev-${project_name}:*" >/dev/null 2>&1 || {
        echo "Warning: Failed to start supervisor worker for $project_name"
        return 1
    }

    echo "Started queue worker for: $project_name"
}

stop_supervisor_worker() {
    local project_name="$1"

    if ! supervisor_is_installed; then
        return 0
    fi

    require_system_access

    sudo_cmd supervisorctl stop "laravel-dev-${project_name}:*" >/dev/null 2>&1 || true
}

status_supervisor_worker() {
    local project_name="$1"

    if ! supervisor_is_installed; then
        echo "supervisor=not_installed"
        return 0
    fi

    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"

    if [[ ! -f "$config_file" ]]; then
        echo "supervisor=no_config"
        return 0
    fi

    local status
    status="$(sudo_cmd supervisorctl status "laravel-dev-${project_name}:*" 2>/dev/null | awk '{print $2}' | sort -u | paste -sd, - || echo "unknown")"
    echo "supervisor=$status"
}

# Export queue configuration to registry for a project
set_project_queue_config() {
    local project_name="$1"
    shift

    while [[ $# -gt 1 ]]; do
        update_project_record "$project_name" "$1" "$2"
        shift 2
    done
}

# ── Multi-Program Supervisor Support ─────────────────────────────────────────

create_supervisor_program() {
    local project_name="$1"
    local project_path="$2"
    local program_name="$3"
    local command="$4"
    local numprocs="${5:-1}"
    local stopwait="${6:-60}"

    if [[ -z "$project_name" || -z "$project_path" || -z "$program_name" || -z "$command" ]]; then
        echo "Error: Missing required parameters for supervisor program"
        return 1
    fi

    require_system_access
    ensure_log_directory

    local config_file="${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}-${program_name}.conf"
    local log_file="${SUPERVISOR_LOG_DIR}/laravel-dev-${project_name}-${program_name}.log"
    local current_user="${SUDO_USER:-${USER:-$(id -un)}}"

    sudo_cmd mkdir -p "$SUPERVISOR_CONF_DIR"

    sudo_cmd tee "$config_file" > /dev/null <<EOF
[program:laravel-dev-${project_name}-${program_name}]
process_name=%(program_name)s_%(process_num)02d
command=${command}
directory=${project_path}
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
numprocs=${numprocs}
redirect_stderr=true
stdout_logfile=${log_file}
stdout_logfile_maxbytes=10MB
stdout_logfile_backups=2
stopwaitsecs=${stopwait}
user=${current_user}
EOF

    echo "Supervisor program config created: $config_file"
    reload_supervisor
    sudo_cmd supervisorctl start "laravel-dev-${project_name}-${program_name}:*" >/dev/null 2>&1 || true
    return 0
}

remove_supervisor_program() {
    local project_name="$1"
    local program_name="$2"

    if [[ -z "$project_name" || -z "$program_name" ]]; then
        return 0
    fi

    require_system_access

    local config_file="${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}-${program_name}.conf"
    if [[ ! -f "$config_file" ]]; then
        return 0
    fi

    sudo_cmd supervisorctl stop "laravel-dev-${project_name}-${program_name}:*" >/dev/null 2>&1 || true
    sudo_cmd rm -f "$config_file"
    reload_supervisor
    echo "Removed supervisor program: ${program_name} for ${project_name}"
}

control_supervisor_program() {
    local project_name="$1"
    local program_name="$2"
    local action="$3"

    if [[ ! "$action" =~ ^(start|stop|restart)$ ]]; then
        echo "Error: Invalid supervisor action: $action"
        return 1
    fi

    require_system_access
    local target
    if [[ "$program_name" == "worker" || -z "$program_name" ]]; then
        target="laravel-dev-${project_name}:*"
        if [[ ! -f "${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}.conf" ]] && [[ -f "${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}-worker.conf" ]]; then
            target="laravel-dev-${project_name}-worker:*"
        fi
    else
        target="laravel-dev-${project_name}-${program_name}:*"
    fi

    sudo_cmd supervisorctl "$action" "$target"
}
