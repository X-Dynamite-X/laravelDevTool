#!/usr/bin/env bash

set -euo pipefail

# Supervisor Manager for Laravel Dev
# Handles queue worker configuration, installation, and lifecycle

SUPERVISOR_CONF_DIR="/etc/supervisor/conf.d"
SUPERVISOR_LOG_DIR="$HOME/.local/log/laravel-dev"

supervisor_is_installed() {
    command -v supervisord >/dev/null 2>&1 && command -v supervisorctl >/dev/null 2>&1
}

detect_package_manager() {
    if command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v pacman >/dev/null 2>&1; then
        echo "pacman"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    else
        echo ""
    fi
}

ensure_supervisor_installed() {
    if supervisor_is_installed; then
        return 0
    fi

    local pkg_manager
    pkg_manager="$(detect_package_manager)"

    if [[ -z "$pkg_manager" ]]; then
        echo "Warning: Could not detect package manager. Please install supervisor manually."
        return 1
    fi

    echo "Supervisor not found. Attempting to install via $pkg_manager..."

    case "$pkg_manager" in
        apt)
            sudo_cmd apt-get update -qq
            sudo_cmd apt-get install -y supervisor
            ;;
        pacman)
            sudo_cmd pacman -S --noconfirm supervisor
            ;;
        dnf)
            sudo_cmd dnf install -y supervisor
            ;;
        yum)
            sudo_cmd yum install -y supervisor
            ;;
        zypper)
            sudo_cmd zypper install -y supervisor
            ;;
    esac

    # Enable and start supervisor service
    if command -v systemctl >/dev/null 2>&1; then
        sudo_cmd systemctl enable supervisord 2>/dev/null || sudo_cmd systemctl enable supervisor 2>/dev/null || true
        sudo_cmd systemctl start supervisord 2>/dev/null || sudo_cmd systemctl start supervisor 2>/dev/null || true
    fi

    if supervisor_is_installed; then
        echo "Supervisor installed successfully."
        return 0
    else
        echo "Warning: Supervisor installation failed. Queue workers will not be configured."
        return 1
    fi
}

get_supervisor_config_file() {
    local project_name="$1"
    echo "${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}.conf"
}

resolve_project_user() {
    local project_path="${1:-}"
    local owner=""
    if [[ -n "$project_path" && -e "$project_path" ]]; then
        owner="$(stat -c '%U' "$project_path" 2>/dev/null || true)"
    fi
    if [[ -n "$owner" && "$owner" != "root" && "$owner" != "UNKNOWN" ]]; then
        echo "$owner"
        return 0
    fi
    if [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != "root" ]]; then
        echo "$SUDO_USER"
        return 0
    fi
    if [[ -n "${USER:-}" && "${USER}" != "root" ]]; then
        echo "$USER"
        return 0
    fi
    id -un
}

resolve_user_home() {
    local target_user="${1:-}"
    local user_home=""
    if [[ -n "$target_user" ]] && command -v getent >/dev/null 2>&1; then
        user_home="$(getent passwd "$target_user" 2>/dev/null | cut -d: -f6 || true)"
    fi
    echo "${user_home:-$HOME}"
}

ensure_log_directory() {
    local project_path="${1:-}"
    local target_user target_home log_dir
    target_user="$(resolve_project_user "$project_path")"
    target_home="$(resolve_user_home "$target_user")"
    log_dir="${target_home}/.local/log/laravel-dev"

    if [[ ! -d "$log_dir" ]]; then
        mkdir -p "$log_dir" 2>/dev/null || sudo_cmd mkdir -p "$log_dir"
        chmod 755 "$log_dir" 2>/dev/null || sudo_cmd chmod 755 "$log_dir" || true
    fi
    if [[ -n "$target_user" && "$target_user" != "root" ]]; then
        if [[ "$(id -u)" -eq 0 ]]; then
            chown -R "$target_user": "$log_dir" 2>/dev/null || true
        elif [[ ! -w "$log_dir" ]]; then
            sudo_cmd chown -R "$target_user": "$log_dir" 2>/dev/null || true
        fi
    fi
    if [[ "$SUPERVISOR_LOG_DIR" != "$log_dir" && ! -d "$SUPERVISOR_LOG_DIR" ]]; then
        mkdir -p "$SUPERVISOR_LOG_DIR" 2>/dev/null || true
    fi
}

supervisor_is_running() {
    supervisor_is_installed || return 1
    sudo_cmd supervisorctl pid >/dev/null 2>&1
}

ensure_supervisor_running() {
    if ! supervisor_is_installed; then
        ensure_supervisor_installed || return 1
    fi

    ensure_log_directory

    if supervisor_is_running; then
        return 0
    fi

    require_system_access
    echo "Starting Supervisor daemon..."

    if command -v systemctl >/dev/null 2>&1; then
        sudo_cmd systemctl unmask supervisor supervisord >/dev/null 2>&1 || true
        sudo_cmd systemctl enable --now supervisor >/dev/null 2>&1 \
            || sudo_cmd systemctl enable --now supervisord >/dev/null 2>&1 \
            || sudo_cmd systemctl start supervisor >/dev/null 2>&1 \
            || sudo_cmd systemctl start supervisord >/dev/null 2>&1 \
            || true
    fi

    if ! supervisor_is_running && command -v service >/dev/null 2>&1; then
        sudo_cmd service supervisor start >/dev/null 2>&1 \
            || sudo_cmd service supervisord start >/dev/null 2>&1 \
            || true
    fi

    if ! supervisor_is_running && [[ -f /etc/supervisor/supervisord.conf ]]; then
        sudo_cmd supervisord -c /etc/supervisor/supervisord.conf >/dev/null 2>&1 || true
    fi

    local attempt
    for attempt in {1..15}; do
        if supervisor_is_running; then
            return 0
        fi
        sleep 0.2
    done

    echo "Error: Supervisor daemon is not running and could not be started."
    if command -v systemctl >/dev/null 2>&1; then
        sudo_cmd systemctl status supervisor supervisord --no-pager -n 12 2>&1 || true
    fi
    return 1
}

get_queue_config() {
    local project_name="$1"
    local default_queues="${QUEUE_WORKER_QUEUES:-default}"
    local default_numprocs="${QUEUE_WORKER_NUMPROCS:-1}"
    local default_sleep="${QUEUE_WORKER_SLEEP:-3}"
    local default_tries="${QUEUE_WORKER_TRIES:-3}"
    local default_timeout="${QUEUE_WORKER_TIMEOUT:-90}"

    # Check if project has custom config in registry
    local project_queues project_numprocs project_sleep project_tries project_timeout

    project_queues="$(get_project_field "$project_name" "QUEUE_WORKER_QUEUES" 2>/dev/null || echo "")"
    project_numprocs="$(get_project_field "$project_name" "QUEUE_WORKER_NUMPROCS" 2>/dev/null || echo "")"
    project_sleep="$(get_project_field "$project_name" "QUEUE_WORKER_SLEEP" 2>/dev/null || echo "")"
    project_tries="$(get_project_field "$project_name" "QUEUE_WORKER_TRIES" 2>/dev/null || echo "")"
    project_timeout="$(get_project_field "$project_name" "QUEUE_WORKER_TIMEOUT" 2>/dev/null || echo "")"

    echo "${project_queues:-$default_queues}"
    echo "${project_numprocs:-$default_numprocs}"
    echo "${project_sleep:-$default_sleep}"
    echo "${project_tries:-$default_tries}"
    echo "${project_timeout:-$default_timeout}"
    echo "$(get_project_field "$project_name" "QUEUE_WORKER_MODE" 2>/dev/null || echo "")"
}

# queue (artisan queue:work) or horizon (artisan horizon). Unset means horizon
# when the project requires laravel/horizon, queue otherwise.
resolve_worker_mode() {
    local requested="$1"
    local project_path="$2"
    if [[ "$requested" == "queue" || "$requested" == "horizon" ]]; then
        echo "$requested"
    elif [[ -f "$project_path/composer.json" ]] && grep -q '"laravel/horizon"' "$project_path/composer.json" 2>/dev/null; then
        echo "horizon"
    else
        echo "queue"
    fi
}

get_supervisor_log_file() {
    local project_name="$1"
    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"
    if [[ -f "$config_file" ]]; then
        local configured_log
        configured_log="$(awk -F= '/^stdout_logfile=/{print $2; exit}' "$config_file" 2>/dev/null || true)"
        if [[ -n "$configured_log" ]]; then
            echo "$configured_log"
            return 0
        fi
    fi
    echo "${SUPERVISOR_LOG_DIR}/laravel-dev-${project_name}.log"
}

create_supervisor_config() {
    local project_name="$1"
    local project_path="$2"
    local php_bin="$3"

    # Validate inputs
    if [[ -z "$project_name" || -z "$project_path" || -z "$php_bin" ]]; then
        echo "Error: Missing required parameters for supervisor config"
        return 1
    fi

    if [[ ! -d "$project_path" ]]; then
        echo "Error: Project path does not exist: $project_path"
        return 1
    fi

    if [[ ! -f "$project_path/artisan" ]]; then
        echo "Warning: artisan not found in $project_path. Skipping supervisor config."
        return 0
    fi

    if [[ "$php_bin" != /* ]]; then
        php_bin="$(command -v "$php_bin" 2>/dev/null || echo "$php_bin")"
    fi

    require_system_access

    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"

    # Get queue configuration
    local queues numprocs sleep tries timeout mode
    {
        read -r queues
        read -r numprocs
        read -r sleep
        read -r tries
        read -r timeout
        read -r mode || true
    } <<< "$(get_queue_config "$project_name")"
    mode="$(resolve_worker_mode "$mode" "$project_path")"

    local command="${php_bin} ${project_path}/artisan queue:work --queue=${queues} --sleep=${sleep} --tries=${tries} --timeout=${timeout}"
    local stopwait=$(( timeout + 30 ))
    if [[ "$mode" == "horizon" ]]; then
        # Horizon spawns and balances its own workers; one supervisor process is enough.
        command="${php_bin} ${project_path}/artisan horizon"
        numprocs=1
        stopwait=3600
    fi

    ensure_log_directory "$project_path"

    # Generate supervisor config
    local current_user user_home log_file
    current_user="$(resolve_project_user "$project_path")"
    user_home="$(resolve_user_home "$current_user")"
    log_file="${user_home}/.local/log/laravel-dev/laravel-dev-${project_name}.log"

    sudo_cmd mkdir -p "$SUPERVISOR_CONF_DIR"

    sudo_cmd tee "$config_file" > /dev/null <<EOF
[program:laravel-dev-${project_name}]
process_name=%(program_name)s_%(process_num)02d
command=${command}
directory=${project_path}
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
numprocs=${numprocs}
redirect_stderr=true
stdout_logfile=${log_file}
stdout_logfile_maxbytes=10MB
stdout_logfile_backups=2
stopwaitsecs=${stopwait}
user=${current_user}
EOF

    echo "Supervisor config created: $config_file"
    if [[ "$mode" == "horizon" ]]; then
        echo "  Mode: horizon"
    else
        echo "  Mode: queue:work"
        echo "  Queue: $queues"
        echo "  Workers: $numprocs"
    fi
    echo "  Log: $log_file"

    return 0
}

repair_supervisor_config_if_needed() {
    local project_name="$1"
    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"
    [[ -f "$config_file" ]] || return 0

    local dir_val user_val log_val cmd_val
    dir_val="$(awk -F= '/^directory=/{sub(/^directory=/, ""); print; exit}' "$config_file" 2>/dev/null || true)"
    user_val="$(awk -F= '/^user=/{sub(/^user=/, ""); print; exit}' "$config_file" 2>/dev/null || true)"
    log_val="$(awk -F= '/^stdout_logfile=/{sub(/^stdout_logfile=/, ""); print; exit}' "$config_file" 2>/dev/null || true)"
    cmd_val="$(awk -F= '/^command=/{sub(/^command=/, ""); print; exit}' "$config_file" 2>/dev/null || true)"

    local expected_user
    expected_user="$(resolve_project_user "$dir_val")"

    ensure_log_directory "$dir_val"
    if [[ -n "$log_val" ]]; then
        local log_parent
        log_parent="$(dirname "$log_val")"
        if [[ ! -d "$log_parent" ]]; then
            mkdir -p "$log_parent" 2>/dev/null || sudo_cmd mkdir -p "$log_parent"
        fi
        if [[ -n "$expected_user" && "$expected_user" != "root" && "$log_parent" != "/root"* ]]; then
            sudo_cmd chown -R "$expected_user": "$log_parent" 2>/dev/null || true
        fi
    fi

    if [[ "$user_val" == "root" && -n "$expected_user" && "$expected_user" != "root" ]]; then
        local expected_home new_log
        expected_home="$(resolve_user_home "$expected_user")"
        new_log="${expected_home}/.local/log/laravel-dev/laravel-dev-${project_name}.log"
        mkdir -p "$(dirname "$new_log")" 2>/dev/null || sudo_cmd mkdir -p "$(dirname "$new_log")"
        sudo_cmd chown -R "$expected_user": "$(dirname "$new_log")" 2>/dev/null || true
        sudo_cmd sed -i "s|^user=.*|user=${expected_user}|" "$config_file"
        if [[ "$log_val" == "/root/"* ]]; then
            sudo_cmd sed -i "s|^stdout_logfile=.*|stdout_logfile=${new_log}|" "$config_file"
        fi
    fi

    local first_tok resolved_php
    first_tok="${cmd_val%% *}"
    if [[ -n "$first_tok" && "$first_tok" != /* ]]; then
        resolved_php="$(command -v "$first_tok" 2>/dev/null || true)"
        if [[ -n "$resolved_php" ]]; then
            local rest_cmd="${cmd_val#"$first_tok"}"
            sudo_cmd sed -i "s|^command=.*|command=${resolved_php}${rest_cmd}|" "$config_file"
        fi
    fi
}

remove_supervisor_config() {
    local project_name="$1"

    if [[ -z "$project_name" ]]; then
        return 0
    fi

    if ! supervisor_is_installed; then
        return 0
    fi

    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"

    if [[ ! -f "$config_file" ]]; then
        return 0
    fi

    require_system_access

    # Stop the worker first
    stop_supervisor_worker "$project_name" 2>/dev/null || true

    sudo_cmd rm -f "$config_file"
    if supervisor_is_running; then
        sudo_cmd supervisorctl reread >/dev/null 2>&1 || true
        sudo_cmd supervisorctl update >/dev/null 2>&1 || true
    fi
    echo "Removed supervisor config for: $project_name"
}

reload_supervisor() {
    if ! supervisor_is_installed; then
        return 0
    fi

    require_system_access
    ensure_supervisor_running || return 1

    sudo_cmd supervisorctl reread >/dev/null 2>&1 || true
    sudo_cmd supervisorctl update >/dev/null 2>&1 || true
}

control_supervisor_worker() {
    local action="$1"
    local project_name="$2"

    if [[ ! "$action" =~ ^(start|stop|restart)$ ]]; then
        echo "Error: Invalid worker action: $action"
        return 1
    fi

    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"
    if [[ ! -f "$config_file" ]]; then
        echo "Error: no queue worker configured for '$project_name'. Run: laravel-dev worker-setup $project_name"
        return 1
    fi

    require_system_access

    if [[ "$action" == "stop" ]]; then
        if ! supervisor_is_running; then
            echo "Queue worker for $project_name is already stopped."
            return 0
        fi
        sudo_cmd supervisorctl stop "laravel-dev-${project_name}:*"
        return 0
    fi

    repair_supervisor_config_if_needed "$project_name"
    ensure_supervisor_running || return 1

    sudo_cmd supervisorctl reread >/dev/null 2>&1 || true
    sudo_cmd supervisorctl update >/dev/null 2>&1 || true

    local current_state
    current_state="$(sudo_cmd supervisorctl status "laravel-dev-${project_name}:*" 2>/dev/null || true)"
    if [[ "$action" == "start" ]] && [[ -n "$current_state" ]] && ! grep -qv "RUNNING" <<< "$current_state"; then
        echo "$current_state"
    else
        sudo_cmd supervisorctl "$action" "laravel-dev-${project_name}:*"
    fi

    sleep 0.8
    local post_state
    post_state="$(sudo_cmd supervisorctl status "laravel-dev-${project_name}:*" 2>/dev/null || true)"
    if grep -Eq '\b(FATAL|BACKOFF)\b' <<< "$post_state"; then
        echo "$post_state"
        local log_file
        log_file="$(get_supervisor_log_file "$project_name")"
        if [[ -f "$log_file" ]]; then
            echo ""
            echo "--- Recent worker log ($log_file) ---"
            tail -n 25 "$log_file" || true
        fi
        return 1
    fi

    return 0
}

start_supervisor_worker() {
    local project_name="$1"
    control_supervisor_worker "start" "$project_name"
}

stop_supervisor_worker() {
    local project_name="$1"

    if ! supervisor_is_installed || ! supervisor_is_running; then
        return 0
    fi

    require_system_access

    sudo_cmd supervisorctl stop "laravel-dev-${project_name}:*" >/dev/null 2>&1 || true
}

status_supervisor_worker() {
    local project_name="$1"

    if ! supervisor_is_installed; then
        echo "supervisor=not_installed"
        return 0
    fi

    local config_file
    config_file="$(get_supervisor_config_file "$project_name")"

    if [[ ! -f "$config_file" ]]; then
        echo "supervisor=no_config"
        return 0
    fi

    if ! supervisor_is_running; then
        echo "supervisor=STOPPED"
        return 0
    fi

    local status
    status="$(sudo_cmd supervisorctl status "laravel-dev-${project_name}:*" 2>/dev/null | awk '{print $2}' | sort -u | paste -sd, - || echo "unknown")"
    echo "supervisor=${status:-STOPPED}"
}

# Export queue configuration to registry for a project
set_project_queue_config() {
    local project_name="$1"
    shift

    while [[ $# -gt 1 ]]; do
        update_project_record "$project_name" "$1" "$2"
        shift 2
    done
}

# ── Multi-Program Supervisor Support ─────────────────────────────────────────

create_supervisor_program() {
    local project_name="$1"
    local project_path="$2"
    local program_name="$3"
    local command="$4"
    local numprocs="${5:-1}"
    local stopwait="${6:-60}"

    if [[ -z "$project_name" || -z "$project_path" || -z "$program_name" || -z "$command" ]]; then
        echo "Error: Missing required parameters for supervisor program"
        return 1
    fi

    require_system_access
    ensure_log_directory "$project_path"

    local current_user user_home
    current_user="$(resolve_project_user "$project_path")"
    user_home="$(resolve_user_home "$current_user")"
    local config_file="${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}-${program_name}.conf"
    local log_file="${user_home}/.local/log/laravel-dev/laravel-dev-${project_name}-${program_name}.log"

    sudo_cmd mkdir -p "$SUPERVISOR_CONF_DIR"

    sudo_cmd tee "$config_file" > /dev/null <<EOF
[program:laravel-dev-${project_name}-${program_name}]
process_name=%(program_name)s_%(process_num)02d
command=${command}
directory=${project_path}
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
numprocs=${numprocs}
redirect_stderr=true
stdout_logfile=${log_file}
stdout_logfile_maxbytes=10MB
stdout_logfile_backups=2
stopwaitsecs=${stopwait}
user=${current_user}
EOF

    echo "Supervisor program config created: $config_file"
    reload_supervisor
    sudo_cmd supervisorctl start "laravel-dev-${project_name}-${program_name}:*" >/dev/null 2>&1 || true
    return 0
}

remove_supervisor_program() {
    local project_name="$1"
    local program_name="$2"

    if [[ -z "$project_name" || -z "$program_name" ]]; then
        return 0
    fi

    require_system_access

    local config_file="${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}-${program_name}.conf"
    if [[ ! -f "$config_file" ]]; then
        return 0
    fi

    if supervisor_is_running; then
        sudo_cmd supervisorctl stop "laravel-dev-${project_name}-${program_name}:*" >/dev/null 2>&1 || true
    fi
    sudo_cmd rm -f "$config_file"
    if supervisor_is_running; then
        reload_supervisor
    fi
    echo "Removed supervisor program: ${program_name} for ${project_name}"
}

control_supervisor_program() {
    local project_name="$1"
    local program_name="$2"
    local action="$3"

    if [[ ! "$action" =~ ^(start|stop|restart)$ ]]; then
        echo "Error: Invalid supervisor action: $action"
        return 1
    fi

    if [[ "$program_name" == "worker" || -z "$program_name" ]]; then
        if [[ -f "$(get_supervisor_config_file "$project_name")" ]]; then
            control_supervisor_worker "$action" "$project_name"
            return $?
        fi
    fi

    require_system_access
    if [[ "$action" != "stop" ]]; then
        ensure_supervisor_running || return 1
        sudo_cmd supervisorctl reread >/dev/null 2>&1 || true
        sudo_cmd supervisorctl update >/dev/null 2>&1 || true
    elif ! supervisor_is_running; then
        return 0
    fi

    local target
    if [[ "$program_name" == "worker" || -z "$program_name" ]]; then
        target="laravel-dev-${project_name}:*"
        if [[ ! -f "${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}.conf" ]] && [[ -f "${SUPERVISOR_CONF_DIR}/laravel-dev-${project_name}-worker.conf" ]]; then
            target="laravel-dev-${project_name}-worker:*"
        fi
    else
        target="laravel-dev-${project_name}-${program_name}:*"
    fi

    sudo_cmd supervisorctl "$action" "$target"
}
