#!/usr/bin/env bash

set -euo pipefail

load_config() {
  SITES_DIR="$HOME/Sites"
  LARAVEL_SITES_DIR="$HOME/Sites"
  DB_HOST="127.0.0.1"
  DB_PORT="3306"
  DB_USER="root"
  DB_PASSWORD=""
  DB_TYPE="mysql"
  AUTO_QUEUE_WORKER="0"

  # System-level defaults (installed with the app).
  local config_file="$BASE_DIR/config/config.env"
  if [[ -f "$config_file" ]]; then
    # shellcheck source=/dev/null
    source "$config_file"
  fi

  # User-level config overrides system config and is always writable by the
  # current user without requiring sudo.
  local user_config_file="${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev/config.env"
  if [[ -f "$user_config_file" ]]; then
    # shellcheck source=/dev/null
    source "$user_config_file"
  fi

  # Backward compatibility for older config that only knows SITES_DIR.
  LARAVEL_SITES_DIR="${LARAVEL_SITES_DIR:-$SITES_DIR}"
  SITES_DIR="$LARAVEL_SITES_DIR"
}

detect_package_manager() {
  if command -v apt-get >/dev/null 2>&1; then
    echo "apt"
  elif command -v pacman >/dev/null 2>&1; then
    echo "pacman"
  elif command -v dnf >/dev/null 2>&1; then
    echo "dnf"
  elif command -v yum >/dev/null 2>&1; then
    echo "yum"
  elif command -v zypper >/dev/null 2>&1; then
    echo "zypper"
  else
    echo ""
  fi
}

