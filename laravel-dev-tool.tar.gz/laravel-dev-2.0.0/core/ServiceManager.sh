#!/usr/bin/env bash

# core/ServiceManager.sh - Installation and lifecycle management of services:
# Nginx, MySQL/MariaDB, PostgreSQL, Redis, Mailpit, Meilisearch, MinIO, Supervisor, Cron, PHP-FPM.

normalize_service_unit() {
  local unit="$1"
  case "$unit" in
    postgres|pgsql)
      echo "postgresql"
      ;;
    redis)
      if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files redis-server.service 2>/dev/null | grep -q "redis-server\.service"; then
        echo "redis-server"
      elif [[ -f /etc/init.d/redis-server || -f /etc/systemd/system/redis-server.service || -f /lib/systemd/system/redis-server.service ]]; then
        echo "redis-server"
      else
        echo "redis"
      fi
      ;;
    redis-server)
      if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files redis.service 2>/dev/null | grep -q "redis\.service" && ! systemctl list-unit-files redis-server.service 2>/dev/null | grep -q "redis-server\.service"; then
        echo "redis"
      elif [[ -f /etc/init.d/redis && ! -f /etc/init.d/redis-server ]]; then
        echo "redis"
      else
        echo "redis-server"
      fi
      ;;
    mysql)
      if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files mariadb.service 2>/dev/null | grep -q "mariadb\.service" && ! systemctl list-unit-files mysql.service 2>/dev/null | grep -q "mysql\.service"; then
        echo "mariadb"
      elif [[ -f /etc/init.d/mariadb && ! -f /etc/init.d/mysql ]]; then
        echo "mariadb"
      else
        echo "mysql"
      fi
      ;;
    mariadb)
      if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files mysql.service 2>/dev/null | grep -q "mysql\.service" && ! systemctl list-unit-files mariadb.service 2>/dev/null | grep -q "mariadb\.service"; then
        echo "mysql"
      elif [[ -f /etc/init.d/mysql && ! -f /etc/init.d/mariadb ]]; then
        echo "mysql"
      else
        echo "mariadb"
      fi
      ;;
    supervisor)
      if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files supervisord.service 2>/dev/null | grep -q "supervisord\.service" && ! systemctl list-unit-files supervisor.service 2>/dev/null | grep -q "supervisor\.service"; then
        echo "supervisord"
      elif [[ -f /etc/init.d/supervisord && ! -f /etc/init.d/supervisor ]]; then
        echo "supervisord"
      else
        echo "supervisor"
      fi
      ;;
    supervisord)
      if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files supervisor.service 2>/dev/null | grep -q "supervisor\.service" && ! systemctl list-unit-files supervisord.service 2>/dev/null | grep -q "supervisord\.service"; then
        echo "supervisor"
      elif [[ -f /etc/init.d/supervisor && ! -f /etc/init.d/supervisord ]]; then
        echo "supervisor"
      else
        echo "supervisord"
      fi
      ;;
    cron|cronie|crond)
      if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files cronie.service 2>/dev/null | grep -q "cronie\.service"; then
        echo "cronie"
      elif command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files crond.service 2>/dev/null | grep -q "crond\.service"; then
        echo "crond"
      elif [[ -f /etc/init.d/cron ]]; then
        echo "cron"
      elif [[ -f /etc/init.d/crond ]]; then
        echo "crond"
      else
        echo "$unit"
      fi
      ;;
    *)
      echo "$unit"
      ;;
  esac
}

is_service_installed() {
  local raw_unit="$1"
  local unit
  unit="$(normalize_service_unit "$raw_unit")"

  if command -v systemctl >/dev/null 2>&1; then
    if systemctl list-unit-files "$unit.service" 2>/dev/null | grep -q "$unit\.service"; then
      return 0
    fi
  fi
  if [[ -f "/etc/systemd/system/$unit.service" || -f "/lib/systemd/system/$unit.service" || -f "/usr/lib/systemd/system/$unit.service" ]]; then
    return 0
  fi
  if [[ -x "/etc/init.d/$unit" ]]; then
    return 0
  fi
  case "$raw_unit" in
    postgresql|postgres|pgsql)
      command -v psql >/dev/null 2>&1 || command -v postgres >/dev/null 2>&1 || [[ -d /etc/postgresql ]]
      ;;
    nginx)
      command -v nginx >/dev/null 2>&1
      ;;
    mysql|mariadb)
      command -v mysql >/dev/null 2>&1 || command -v mysqld >/dev/null 2>&1 || command -v mariadbd >/dev/null 2>&1
      ;;
    redis|redis-server)
      command -v redis-server >/dev/null 2>&1 || command -v redis-cli >/dev/null 2>&1
      ;;
    supervisor|supervisord)
      command -v supervisord >/dev/null 2>&1 || command -v supervisorctl >/dev/null 2>&1
      ;;
    cron|cronie|crond)
      command -v cron >/dev/null 2>&1 || command -v crond >/dev/null 2>&1 || command -v crontab >/dev/null 2>&1
      ;;
    mailpit)
      command -v mailpit >/dev/null 2>&1 || [[ -f /usr/local/bin/mailpit ]]
      ;;
    meilisearch)
      command -v meilisearch >/dev/null 2>&1 || [[ -f /usr/local/bin/meilisearch ]]
      ;;
    minio)
      command -v minio >/dev/null 2>&1 || [[ -f /usr/local/bin/minio ]]
      ;;
    php*-fpm)
      [[ -d "/etc/php" ]] || command -v "$unit" >/dev/null 2>&1
      ;;
    *)
      command -v "$unit" >/dev/null 2>&1
      ;;
  esac
}

is_service_active() {
  local raw_unit="$1"
  local unit
  unit="$(normalize_service_unit "$raw_unit")"

  # 1. Systemd active check
  if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
    if systemctl is-active --quiet "$unit" 2>/dev/null; then
      return 0
    fi
  fi

  # 2. SysV service status check
  if command -v service >/dev/null 2>&1; then
    local s_out
    s_out="$(service "$unit" status 2>&1 || true)"
    if echo "$s_out" | grep -qiE 'is running|is active|active \(running\)|\bonline\b'; then
      return 0
    fi
  fi

  # 3. Direct init.d status check
  if [[ -x "/etc/init.d/$unit" ]]; then
    local init_out
    init_out="$("/etc/init.d/$unit" status 2>&1 || true)"
    if echo "$init_out" | grep -qiE 'is running|is active|active \(running\)|\bonline\b'; then
      return 0
    fi
  fi

  # 4. Specific service checks
  case "$raw_unit" in
    postgresql|postgres|pgsql)
      if command -v pg_isready >/dev/null 2>&1 && pg_isready -q 2>/dev/null; then
        return 0
      fi
      if command -v pg_lsclusters >/dev/null 2>&1 && pg_lsclusters 2>/dev/null | grep -q 'online'; then
        return 0
      fi
      if pgrep -x postgres >/dev/null 2>&1 || pgrep -x postmaster >/dev/null 2>&1; then
        return 0
      fi
      ;;
    nginx)
      if pgrep -x nginx >/dev/null 2>&1; then
        return 0
      fi
      ;;
    mysql|mariadb)
      if pgrep -x mysqld >/dev/null 2>&1 || pgrep -x mariadbd >/dev/null 2>&1; then
        return 0
      fi
      ;;
    redis|redis-server)
      if pgrep -x redis-server >/dev/null 2>&1; then
        return 0
      fi
      ;;
    supervisor|supervisord)
      if pgrep -x supervisord >/dev/null 2>&1; then
        return 0
      fi
      ;;
    cron|cronie|crond)
      if pgrep -x cron >/dev/null 2>&1 || pgrep -x crond >/dev/null 2>&1; then
        return 0
      fi
      ;;
    mailpit)
      if pgrep -x mailpit >/dev/null 2>&1; then
        return 0
      fi
      ;;
    meilisearch)
      if pgrep -x meilisearch >/dev/null 2>&1; then
        return 0
      fi
      ;;
    minio)
      if pgrep -x minio >/dev/null 2>&1; then
        return 0
      fi
      ;;
    php*-fpm)
      if pgrep -f "$unit" >/dev/null 2>&1 || pgrep -x php-fpm >/dev/null 2>&1; then
        return 0
      fi
      ;;
    *)
      if pgrep -x "$unit" >/dev/null 2>&1; then
        return 0
      fi
      ;;
  esac

  return 1
}

ensure_service_prerequisites() {
  local raw_unit="$1"
  local unit
  unit="$(normalize_service_unit "$raw_unit")"

  case "$raw_unit" in
    postgresql|postgres|pgsql)
      if id postgres >/dev/null 2>&1; then
        sudo_cmd mkdir -p /var/run/postgresql /run/postgresql 2>/dev/null || true
        sudo_cmd chown postgres:postgres /var/run/postgresql /run/postgresql 2>/dev/null || true
        sudo_cmd chmod 2775 /var/run/postgresql /run/postgresql 2>/dev/null || true
      fi
      if command -v pg_lsclusters >/dev/null 2>&1 && command -v pg_createcluster >/dev/null 2>&1; then
        if [[ -z "$(pg_lsclusters --no-header 2>/dev/null)" ]]; then
          local pg_ver
          pg_ver="$(ls -1 /etc/postgresql 2>/dev/null | sort -V | tail -n1 || echo "")"
          if [[ -n "$pg_ver" ]]; then
            sudo_cmd pg_createcluster "$pg_ver" main 2>/dev/null || true
          fi
        fi
      fi
      ;;
    redis|redis-server)
      if id redis >/dev/null 2>&1; then
        sudo_cmd mkdir -p /var/run/redis /run/redis /var/lib/redis 2>/dev/null || true
        sudo_cmd chown redis:redis /var/run/redis /run/redis /var/lib/redis 2>/dev/null || true
      fi
      ;;
    meilisearch)
      sudo_cmd mkdir -p /var/lib/meilisearch/data 2>/dev/null || true
      ;;
    minio)
      sudo_cmd mkdir -p /var/lib/minio/data 2>/dev/null || true
      ;;
    nginx)
      sudo_cmd mkdir -p /var/log/nginx /var/log/nginx/laravel-dev 2>/dev/null || true
      ;;
  esac
}

control_service() {
  local action="$1"
  local raw_unit="$2"
  local unit
  unit="$(normalize_service_unit "$raw_unit")"

  if [[ ! "$action" =~ ^(start|stop|restart|reload|status)$ ]]; then
    echo "Error: invalid action '$action'. Must be start, stop, restart, reload, or status." >&2
    return 1
  fi

  if [[ "$action" == "status" ]]; then
    if is_service_active "$raw_unit"; then
      echo "$raw_unit: active"
      return 0
    else
      echo "$raw_unit: inactive"
      return 1
    fi
  fi

  require_system_access

  if [[ "$action" =~ ^(start|restart)$ ]]; then
    ensure_service_prerequisites "$raw_unit"
  fi

  # If unit is nginx and action is start/restart/reload, test config first
  if [[ "$unit" == "nginx" && "$action" =~ ^(start|restart|reload)$ ]]; then
    if command -v nginx >/dev/null 2>&1; then
      if ! sudo_cmd nginx -t >/dev/null 2>&1; then
        echo "Error: Nginx configuration test failed. Check syntax before $action." >&2
        return 1
      fi
    fi
  fi

  # Attempt 1: systemctl if systemd is active PID 1
  local systemd_ok=0
  if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
    local sys_state
    sys_state="$(systemctl is-system-running 2>/dev/null || true)"
    if [[ "$sys_state" =~ ^(running|degraded|starting)$ ]]; then
      systemd_ok=1
    fi
  fi

  if [[ "$systemd_ok" -eq 1 ]]; then
    if sudo_cmd systemctl "$action" "$unit" 2>/dev/null; then
      return 0
    fi
    if [[ "$raw_unit" != "$unit" ]]; then
      if sudo_cmd systemctl "$action" "$raw_unit" 2>/dev/null; then
        return 0
      fi
    fi
  fi

  # Attempt 2: SysV init via `service`
  if command -v service >/dev/null 2>&1; then
    if sudo_cmd service "$unit" "$action" 2>/dev/null; then
      return 0
    fi
    if [[ "$raw_unit" != "$unit" ]]; then
      if sudo_cmd service "$raw_unit" "$action" 2>/dev/null; then
        return 0
      fi
    fi
  fi

  # Attempt 3: direct /etc/init.d/ script
  if [[ -x "/etc/init.d/$unit" ]]; then
    if sudo_cmd "/etc/init.d/$unit" "$action" 2>/dev/null; then
      return 0
    fi
  fi
  if [[ "$raw_unit" != "$unit" && -x "/etc/init.d/$raw_unit" ]]; then
    if sudo_cmd "/etc/init.d/$raw_unit" "$action" 2>/dev/null; then
      return 0
    fi
  fi

  # Attempt 4: PostgreSQL specific fallback via pg_ctlcluster
  if [[ "$unit" == "postgresql" ]] && command -v pg_ctlcluster >/dev/null 2>&1; then
    local cluster_action="$action"
    [[ "$cluster_action" == "reload" ]] && cluster_action="restart"
    local any_started=0
    while read -r ver cluster port status rest; do
      [[ -z "$ver" || "$ver" == "Ver" ]] && continue
      if sudo_cmd pg_ctlcluster "$ver" "$cluster" "$cluster_action" 2>/dev/null; then
        any_started=1
      fi
    done < <(pg_lsclusters --no-header 2>/dev/null || true)
    if [[ "$any_started" -eq 1 ]]; then
      return 0
    fi
  fi

  # Attempt 5: Non-systemd standalone service fallback (mailpit, meilisearch, minio)
  case "$raw_unit" in
    mailpit)
      local bin_path
      bin_path="$(command -v mailpit || echo "/usr/local/bin/mailpit")"
      if [[ -x "$bin_path" ]]; then
        if [[ "$action" =~ ^(stop|restart)$ ]]; then
          sudo_cmd pkill -x mailpit 2>/dev/null || true
        fi
        if [[ "$action" =~ ^(start|restart)$ ]]; then
          sudo_cmd nohup "$bin_path" --listen 127.0.0.1:8025 --smtp 127.0.0.1:1025 >/dev/null 2>&1 &
        fi
        return 0
      fi
      ;;
    meilisearch)
      local bin_path
      bin_path="$(command -v meilisearch || echo "/usr/local/bin/meilisearch")"
      if [[ -x "$bin_path" ]]; then
        if [[ "$action" =~ ^(stop|restart)$ ]]; then
          sudo_cmd pkill -x meilisearch 2>/dev/null || true
        fi
        if [[ "$action" =~ ^(start|restart)$ ]]; then
          sudo_cmd mkdir -p /var/lib/meilisearch/data
          sudo_cmd nohup "$bin_path" --db-path /var/lib/meilisearch/data --http-addr 127.0.0.1:7700 --env development --no-analytics >/dev/null 2>&1 &
        fi
        return 0
      fi
      ;;
    minio)
      local bin_path
      bin_path="$(command -v minio || echo "/usr/local/bin/minio")"
      if [[ -x "$bin_path" ]]; then
        if [[ "$action" =~ ^(stop|restart)$ ]]; then
          sudo_cmd pkill -x minio 2>/dev/null || true
        fi
        if [[ "$action" =~ ^(start|restart)$ ]]; then
          load_minio_credentials
          sudo_cmd mkdir -p /var/lib/minio/data
          MINIO_ROOT_USER="$MINIO_USER" MINIO_ROOT_PASSWORD="$MINIO_PASSWORD" sudo_cmd -E nohup "$bin_path" server /var/lib/minio/data --address 127.0.0.1:9000 --console-address 127.0.0.1:9001 >/dev/null 2>&1 &
        fi
        return 0
      fi
      ;;
  esac

  echo "Failed to $action service '$unit'." >&2
  return 1
}

service_install_mailpit() {
  require_system_access
  echo "Installing Mailpit..."
  if ! command -v mailpit >/dev/null 2>&1; then
    if curl -sL https://raw.githubusercontent.com/axllent/mailpit/develop/install.sh | bash; then
      echo "Mailpit binary installed successfully."
    else
      echo "Failed to install Mailpit via installer script."
      return 1
    fi
  fi

  local bin_path
  bin_path="$(command -v mailpit || echo "/usr/local/bin/mailpit")"

  if [[ ! -f /etc/systemd/system/mailpit.service ]]; then
    echo "Creating /etc/systemd/system/mailpit.service..."
    sudo_cmd tee /etc/systemd/system/mailpit.service >/dev/null <<EOF
[Unit]
Description=Mailpit - local mail catcher
After=network.target

[Service]
Type=simple
# Local only: Mailpit listens on all interfaces by default.
ExecStart=${bin_path} --listen 127.0.0.1:8025 --smtp 127.0.0.1:1025
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    sudo_cmd systemctl daemon-reload
  fi

  sudo_cmd systemctl enable --now mailpit
  echo "Mailpit is active on SMTP :1025 and Web UI http://localhost:8025"
}

service_install_redis() {
  require_system_access
  echo "Installing Redis..."
  if command -v apt-get >/dev/null 2>&1; then
    sudo_cmd apt-get update -qq && sudo_cmd apt-get install -y redis-server
  elif command -v dnf >/dev/null 2>&1; then
    sudo_cmd dnf install -y redis
  elif command -v pacman >/dev/null 2>&1; then
    sudo_cmd pacman -S --noconfirm redis
  else
    echo "Unsupported package manager for automatic Redis installation."
    return 1
  fi
  ensure_service_prerequisites "redis-server"
  if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
    sudo_cmd systemctl enable redis-server 2>/dev/null || sudo_cmd systemctl enable redis 2>/dev/null || true
  fi
  control_service "start" "redis-server" || true
  echo "Redis is active on port 6379"
}

service_install_postgresql() {
  require_system_access
  echo "Installing PostgreSQL..."
  local pm
  pm="$(detect_package_manager)"
  case "$pm" in
    apt)
      sudo_cmd apt-get update -qq && sudo_cmd apt-get install -y postgresql postgresql-contrib
      ;;
    dnf)
      sudo_cmd dnf install -y postgresql-server postgresql-contrib
      sudo_cmd postgresql-setup --initdb 2>/dev/null || true
      ;;
    pacman)
      sudo_cmd pacman -S --noconfirm postgresql
      if [[ ! -d /var/lib/postgres/data/base ]]; then
        sudo_cmd -u postgres initdb -D /var/lib/postgres/data 2>/dev/null || true
      fi
      ;;
    *)
      echo "Unsupported package manager for automatic PostgreSQL installation."
      return 1
      ;;
  esac
  ensure_service_prerequisites "postgresql"
  if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
    sudo_cmd systemctl enable postgresql 2>/dev/null || true
  fi
  control_service "start" "postgresql" || true
  echo "PostgreSQL is active on port 5432"
}

service_install_meilisearch() {
  require_system_access
  echo "Installing Meilisearch..."
  if ! command -v meilisearch >/dev/null 2>&1 && [[ ! -f /usr/local/bin/meilisearch ]]; then
    local tmp_dir
    tmp_dir="$(mktemp -d)"
    local installed=0
    if ( cd "$tmp_dir" && curl -fsSL https://install.meilisearch.com | sh ); then
      if [[ -f "$tmp_dir/meilisearch" ]]; then
        sudo_cmd mv "$tmp_dir/meilisearch" /usr/local/bin/meilisearch
        sudo_cmd chmod +x /usr/local/bin/meilisearch
        installed=1
      fi
    fi

    if [[ "$installed" -ne 1 ]]; then
      local arch
      arch="$(uname -m)"
      case "$arch" in
        x86_64) arch="amd64" ;;
        aarch64|arm64) arch="aarch64" ;;
        *) arch="" ;;
      esac
      if [[ -n "$arch" ]]; then
        echo "Attempting fallback download of Meilisearch binary for $arch..."
        if curl -fsSL "https://github.com/meilisearch/meilisearch/releases/latest/download/meilisearch-linux-${arch}" -o "$tmp_dir/meilisearch"; then
          sudo_cmd mv "$tmp_dir/meilisearch" /usr/local/bin/meilisearch
          sudo_cmd chmod +x /usr/local/bin/meilisearch
          installed=1
        fi
      fi
    fi

    rm -rf "$tmp_dir"
    if [[ "$installed" -ne 1 ]]; then
      echo "Could not download Meilisearch binary."
      return 1
    fi
  fi

  sudo_cmd mkdir -p /var/lib/meilisearch/data

  if [[ ! -f /etc/systemd/system/meilisearch.service ]]; then
    echo "Creating /etc/systemd/system/meilisearch.service..."
    sudo_cmd tee /etc/systemd/system/meilisearch.service >/dev/null <<'EOF'
[Unit]
Description=Meilisearch Full-Text Search Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/meilisearch --db-path /var/lib/meilisearch/data --http-addr 127.0.0.1:7700 --env development --no-analytics
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    sudo_cmd systemctl daemon-reload
  fi

  sudo_cmd systemctl enable --now meilisearch
  echo "Meilisearch is active on http://127.0.0.1:7700"
}

# MinIO root credentials: generated once per machine and kept in a user-only
# file, so the app can fill AWS_* in a project's .env. An existing unit keeps
# the credentials it already runs with (changing them can lock out its data).
minio_credentials_file() {
  echo "${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev/minio.env"
}

load_minio_credentials() {
  local file unit=/etc/systemd/system/minio.service
  file="$(minio_credentials_file)"
  MINIO_USER="" MINIO_PASSWORD=""
  if [[ -f "$unit" ]]; then
    MINIO_USER="$(sed -n 's/^Environment="MINIO_ROOT_USER=\(.*\)"$/\1/p' "$unit" | head -n1)"
    MINIO_PASSWORD="$(sed -n 's/^Environment="MINIO_ROOT_PASSWORD=\(.*\)"$/\1/p' "$unit" | head -n1)"
  fi
  if [[ -z "$MINIO_USER" && -f "$file" ]]; then
    MINIO_USER="$(sed -n 's/^MINIO_ROOT_USER=//p' "$file" | head -n1)"
    MINIO_PASSWORD="$(sed -n 's/^MINIO_ROOT_PASSWORD=//p' "$file" | head -n1)"
  fi
  # The old shared default is replaced; projects pick the new pair up when
  # MinIO is applied to their .env again.
  if [[ -z "$MINIO_USER" || -z "$MINIO_PASSWORD" || "$MINIO_PASSWORD" == "minioadmin" ]]; then
    [[ "$MINIO_PASSWORD" == "minioadmin" ]] && echo "Replacing the default minioadmin password. Re-apply MinIO to each project's .env afterwards."
    MINIO_USER="laravel-dev"
    MINIO_PASSWORD="$(head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"
  fi
  mkdir -p "$(dirname "$file")"
  ( umask 077; printf 'MINIO_ROOT_USER=%s\nMINIO_ROOT_PASSWORD=%s\n' "$MINIO_USER" "$MINIO_PASSWORD" > "$file" )
}

service_install_minio() {
  require_system_access
  echo "Installing MinIO..."
  if ! command -v minio >/dev/null 2>&1 && [[ ! -f /usr/local/bin/minio ]]; then
    local arch
    arch="$(uname -m)"
    if [[ "$arch" == "x86_64" ]]; then
      arch="amd64"
    elif [[ "$arch" == "aarch64" || "$arch" == "arm64" ]]; then
      arch="arm64"
    else
      echo "Unsupported architecture for MinIO: $arch"
      return 1
    fi

    local tmp_bin
    tmp_bin="$(mktemp)"
    local downloaded=0
    local minio_urls=(
      "https://dl.min.io/server/minio/release/linux-${arch}/minio"
      "https://github.com/minio/minio/releases/latest/download/minio"
      "https://github.com/easybill/minio-builds/releases/download/RELEASE.2025-10-15T17-29-55Z/minio-linux-${arch}"
      "https://github.com/golithus/minio-builds/releases/download/RELEASE.2025-10-15T17-29-55Z/minio-linux-${arch}"
    )

    for url in "${minio_urls[@]}"; do
      echo "Downloading MinIO binary from $url..."
      if curl -fsSL "$url" -o "$tmp_bin" && [[ -s "$tmp_bin" ]]; then
        downloaded=1
        break
      fi
    done

    if [[ "$downloaded" -ne 1 ]] && command -v go >/dev/null 2>&1; then
      echo "Attempting to build MinIO via 'go install github.com/minio/minio@latest'..."
      if go install github.com/minio/minio@latest 2>/dev/null; then
        local gopath_bin
        gopath_bin="$(go env GOPATH 2>/dev/null || echo "$HOME/go")/bin/minio"
        if [[ -f "$gopath_bin" ]]; then
          cp "$gopath_bin" "$tmp_bin"
          downloaded=1
        fi
      fi
    fi

    if [[ "$downloaded" -eq 1 ]]; then
      sudo_cmd mv "$tmp_bin" /usr/local/bin/minio
      sudo_cmd chmod +x /usr/local/bin/minio
    else
      rm -f "$tmp_bin"
      echo "Failed to download MinIO binary. MinIO discontinued direct binary downloads on dl.min.io."
      echo "You can install MinIO manually or run 'go install github.com/minio/minio@latest'."
      return 1
    fi
  fi

  sudo_cmd mkdir -p /var/lib/minio/data

  if [[ ! -f /etc/systemd/system/minio.service ]]; then
    echo "Creating /etc/systemd/system/minio.service..."
    load_minio_credentials
    sudo_cmd tee /etc/systemd/system/minio.service >/dev/null <<EOF
[Unit]
Description=MinIO Object Storage
After=network.target

[Service]
Type=simple
Environment="MINIO_ROOT_USER=${MINIO_USER}"
Environment="MINIO_ROOT_PASSWORD=${MINIO_PASSWORD}"
# Local only: the default credentials must never be reachable from the network.
ExecStart=/usr/local/bin/minio server /var/lib/minio/data --address 127.0.0.1:9000 --console-address 127.0.0.1:9001
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    sudo_cmd systemctl daemon-reload
  fi

  sudo_cmd systemctl enable --now minio
  echo "MinIO is active on API :9000 and Web Console http://127.0.0.1:9001"
  echo "Credentials: $(minio_credentials_file)"
}

service_repair_mailpit() {
  require_system_access
  local bin_path
  bin_path="$(command -v mailpit || echo "/usr/local/bin/mailpit")"
  if [[ ! -x "$bin_path" ]]; then
    echo "Error: mailpit binary not found at $bin_path"
    return 1
  fi
  echo "Repairing /etc/systemd/system/mailpit.service to bind strictly to 127.0.0.1..."
  sudo_cmd tee /etc/systemd/system/mailpit.service >/dev/null <<EOF
[Unit]
Description=Mailpit - local mail catcher
After=network.target

[Service]
Type=simple
ExecStart=${bin_path} --listen 127.0.0.1:8025 --smtp 127.0.0.1:1025
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
  sudo_cmd systemctl daemon-reload
  sudo_cmd systemctl restart mailpit
  echo "Mailpit repaired: strictly listening on 127.0.0.1:8025 and 127.0.0.1:1025"
}

service_repair_meilisearch() {
  require_system_access
  local bin_path
  bin_path="$(command -v meilisearch || echo "/usr/local/bin/meilisearch")"
  if [[ ! -x "$bin_path" ]]; then
    echo "Error: meilisearch binary not found at $bin_path"
    return 1
  fi
  sudo_cmd mkdir -p /var/lib/meilisearch/data
  echo "Repairing /etc/systemd/system/meilisearch.service to bind strictly to 127.0.0.1:7700..."
  sudo_cmd tee /etc/systemd/system/meilisearch.service >/dev/null <<EOF
[Unit]
Description=Meilisearch Full-Text Search Server
After=network.target

[Service]
Type=simple
ExecStart=${bin_path} --db-path /var/lib/meilisearch/data --http-addr 127.0.0.1:7700 --env development --no-analytics
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
  sudo_cmd systemctl daemon-reload
  sudo_cmd systemctl restart meilisearch
  echo "Meilisearch repaired: strictly listening on 127.0.0.1:7700"
}

service_repair_minio() {
  require_system_access
  local bin_path
  bin_path="$(command -v minio || echo "/usr/local/bin/minio")"
  if [[ ! -x "$bin_path" ]]; then
    echo "Error: minio binary not found at $bin_path"
    return 1
  fi
  sudo_cmd mkdir -p /var/lib/minio/data
  echo "Repairing /etc/systemd/system/minio.service to bind strictly to 127.0.0.1..."
  load_minio_credentials
  sudo_cmd tee /etc/systemd/system/minio.service >/dev/null <<EOF
[Unit]
Description=MinIO Object Storage
After=network.target

[Service]
Type=simple
Environment="MINIO_ROOT_USER=${MINIO_USER}"
Environment="MINIO_ROOT_PASSWORD=${MINIO_PASSWORD}"
ExecStart=${bin_path} server /var/lib/minio/data --address 127.0.0.1:9000 --console-address 127.0.0.1:9001
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
  sudo_cmd systemctl daemon-reload
  sudo_cmd chmod 600 /etc/systemd/system/minio.service
  sudo_cmd systemctl restart minio
  echo "MinIO repaired: strictly listening on 127.0.0.1:9000 and 127.0.0.1:9001"
  echo "Credentials: $(minio_credentials_file)"
}

service_repair() {
  local service_name="${1:-}"
  case "$service_name" in
    mailpit)
      service_repair_mailpit
      ;;
    meilisearch)
      service_repair_meilisearch
      ;;
    minio)
      service_repair_minio
      ;;
    postgresql|postgres|pgsql)
      require_system_access
      echo "Repairing PostgreSQL configuration and directories..."
      ensure_service_prerequisites "postgresql"
      control_service "restart" "postgresql" || true
      if is_service_active "postgresql"; then
        echo "PostgreSQL repaired and active on port 5432."
      else
        echo "PostgreSQL service restarted."
      fi
      ;;
    redis|redis-server)
      require_system_access
      echo "Repairing Redis configuration and directories..."
      ensure_service_prerequisites "redis-server"
      control_service "restart" "redis-server" || true
      if is_service_active "redis-server"; then
        echo "Redis repaired and active on port 6379."
      else
        echo "Redis service restarted."
      fi
      ;;
    nginx)
      require_system_access
      echo "Testing and repairing Nginx configuration..."
      ensure_service_prerequisites "nginx"
      if command -v nginx >/dev/null 2>&1; then
        sudo_cmd nginx -t || true
      fi
      control_service "restart" "nginx" || true
      echo "Nginx service restarted."
      ;;
    mysql|mariadb)
      require_system_access
      echo "Repairing MySQL/MariaDB service..."
      control_service "restart" "mysql" || control_service "restart" "mariadb" || true
      echo "MySQL/MariaDB service restarted."
      ;;
    all)
      service_repair_mailpit || true
      service_repair_meilisearch || true
      service_repair_minio || true
      service_repair "postgresql" || true
      service_repair "redis" || true
      service_repair "nginx" || true
      service_repair "mysql" || true
      ;;
    *)
      echo "Usage: laravel-dev service-repair <mailpit|meilisearch|minio|postgresql|redis|nginx|mysql|all>"
      return 1
      ;;
  esac
}

service_install() {
  local service_name="${1:-}"
  case "$service_name" in
    mailpit)
      service_install_mailpit
      ;;
    redis|redis-server)
      service_install_redis
      ;;
    meilisearch)
      service_install_meilisearch
      ;;
    minio)
      service_install_minio
      ;;
    postgresql|postgres|pgsql)
      service_install_postgresql
      ;;
    *)
      echo "Error: unknown service '$service_name'. Supported: mailpit, redis, meilisearch, minio, postgresql"
      return 1
      ;;
  esac
}

# ── Multi-instance services (isolated redis / mysql / postgresql on custom ports) ──
# Each instance gets its own data directory and a `systemd --user` unit when a user
# session bus is available, otherwise a plain background process with a pid file.

INSTANCE_CONF_DIR="${HOME}/.config/laravel-dev/instances"
INSTANCE_DATA_ROOT="${HOME}/.config/laravel-dev/services"
INSTANCE_UNIT_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"

_instance_default_port() {
  case "$1" in
    redis) echo 6380 ;;
    mysql) echo 3307 ;;
    postgresql) echo 5433 ;;
  esac
}

_instance_validate() {
  local type="$1" name="$2"
  case "$type" in
    redis|mysql|postgresql) ;;
    *) echo "Error: unsupported instance type '$type'. Supported: redis, mysql, postgresql" >&2; return 1 ;;
  esac
  if [[ ! "$name" =~ ^[a-z0-9][a-z0-9_-]{0,31}$ ]]; then
    echo "Error: invalid instance name '$name' (use lowercase letters, digits, - and _)." >&2
    return 1
  fi
}

_instance_port_in_use() {
  (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null
}

_instance_unit() { echo "laravel-dev-${1}-${2}.service"; }

_instance_has_systemd_user() {
  command -v systemctl >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1
}

_instance_find_mysqld() {
  local c
  for c in "$(command -v mariadbd 2>/dev/null)" "$(command -v mysqld 2>/dev/null)" /usr/sbin/mariadbd /usr/sbin/mysqld /usr/libexec/mysqld /usr/bin/mysqld; do
    [[ -n "$c" && -x "$c" ]] && { echo "$c"; return 0; }
  done
  return 1
}

_instance_find_pg_bindir() {
  local c
  c="$(command -v initdb 2>/dev/null || true)"
  if [[ -n "$c" ]]; then dirname "$c"; return 0; fi
  c="$(ls -d /usr/lib/postgresql/*/bin /usr/pgsql-*/bin 2>/dev/null | sort -V | tail -1)"
  [[ -n "$c" && -x "$c/initdb" ]] && { echo "$c"; return 0; }
  return 1
}

_instance_wait_port() {
  local port="$1" i
  for i in $(seq 1 30); do
    _instance_port_in_use "$port" && return 0
    sleep 0.5
  done
  return 1
}

_instance_port_assigned() {
  python3 - "$INSTANCE_CONF_DIR" "$1" <<'PY'
import glob, json, os, sys
for f in glob.glob(os.path.join(sys.argv[1], '*.json')):
    try:
        if int(json.load(open(f)).get('port') or 0) == int(sys.argv[2]):
            sys.exit(0)
    except Exception:
        pass
sys.exit(1)
PY
}

service_instance_list() {
  mkdir -p "$INSTANCE_CONF_DIR"
  python3 - "$INSTANCE_CONF_DIR" <<'PY'
import glob, json, os, socket, sys
res = []
for f in sorted(glob.glob(os.path.join(sys.argv[1], '*.json'))):
    try:
        with open(f) as fp:
            data = json.load(fp)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        data['active'] = sock.connect_ex(('127.0.0.1', int(data.get('port') or 0))) == 0
        sock.close()
        res.append(data)
    except Exception:
        pass
print(json.dumps(res, indent=2))
PY
}

service_instance_create() {
  local type="${1:-}" name="${2:-}" port="${3:-}"
  if [[ -z "$type" || -z "$name" ]]; then
    echo "Usage: laravel-dev instance create <redis|mysql|postgresql> <name> [port]" >&2
    return 1
  fi
  _instance_validate "$type" "$name" || return 1
  port="${port:-$(_instance_default_port "$type")}"
  if [[ ! "$port" =~ ^[0-9]+$ ]] || (( port < 1024 || port > 65535 )); then
    echo "Error: port must be a number between 1024 and 65535." >&2
    return 1
  fi

  local id="${type}-${name}"
  local conf_file="$INSTANCE_CONF_DIR/${id}.json"
  local data_dir="$INSTANCE_DATA_ROOT/${id}"
  mkdir -p "$INSTANCE_CONF_DIR"
  if [[ -f "$conf_file" ]]; then
    echo "Error: Instance '$id' already exists." >&2
    return 1
  fi
  if _instance_port_assigned "$port"; then
    echo "Error: port $port is already assigned to another instance." >&2
    return 1
  fi
  if _instance_port_in_use "$port"; then
    echo "Error: port $port is already in use on this machine." >&2
    return 1
  fi

  mkdir -p "$data_dir"
  chmod 700 "$data_dir"
  local run_script="$data_dir/run.sh"
  local user
  user="$(id -un)"
  # Unix socket paths are limited to ~107 bytes, so keep sockets in the short runtime dir.
  local sock_dir="${XDG_RUNTIME_DIR:-/tmp}/laravel-dev-instances"
  mkdir -p "$sock_dir"
  chmod 700 "$sock_dir"

  echo "Creating ${type} instance '${name}' on 127.0.0.1:${port}..."
  case "$type" in
    redis)
      command -v redis-server >/dev/null 2>&1 || { echo "Error: redis-server is not installed (laravel-dev service-install redis)." >&2; return 1; }
      cat > "$data_dir/redis.conf" <<EOF
port $port
bind 127.0.0.1
daemonize no
dir $data_dir
logfile $data_dir/redis.log
EOF
      printf '#!/usr/bin/env bash\nexec %q %q\n' "$(command -v redis-server)" "$data_dir/redis.conf" > "$run_script"
      ;;
    mysql)
      local mysqld
      mysqld="$(_instance_find_mysqld)" || { echo "Error: mysqld/mariadbd is not installed." >&2; return 1; }
      mkdir -p "$data_dir/data"
      local extra=""
      if "$mysqld" --version 2>/dev/null | grep -qi mariadb; then
        local installer
        installer="$(command -v mariadb-install-db || command -v mysql_install_db || true)"
        [[ -n "$installer" ]] || { echo "Error: mariadb-install-db not found." >&2; return 1; }
        "$installer" --no-defaults --datadir="$data_dir/data" --user="$user" \
          --auth-root-authentication-method=normal --skip-test-db >"$data_dir/init.log" 2>&1 \
          || { echo "Error: MariaDB initialisation failed, see $data_dir/init.log" >&2; return 1; }
      else
        "$mysqld" --no-defaults --initialize-insecure --datadir="$data_dir/data" --user="$user" >"$data_dir/init.log" 2>&1 \
          || { echo "Error: MySQL initialisation failed, see $data_dir/init.log (AppArmor may block data directories outside /var/lib/mysql)." >&2; return 1; }
        extra="--mysqlx=OFF"
      fi
      printf '#!/usr/bin/env bash\nexec %q --no-defaults --datadir=%q --port=%q --bind-address=127.0.0.1 --socket=%q --pid-file=%q --log-error=%q %s\n' \
        "$mysqld" "$data_dir/data" "$port" "$sock_dir/${id}.sock" "$data_dir/mysqld.pid" "$data_dir/mysqld.log" "$extra" > "$run_script"
      ;;
    postgresql)
      local pgbin
      pgbin="$(_instance_find_pg_bindir)" || { echo "Error: PostgreSQL server binaries (initdb) are not installed." >&2; return 1; }
      "$pgbin/initdb" -D "$data_dir/data" -U postgres --auth=trust -E UTF8 >"$data_dir/init.log" 2>&1 \
        || { echo "Error: PostgreSQL initialisation failed, see $data_dir/init.log" >&2; return 1; }
      printf '#!/usr/bin/env bash\nexec %q -D %q -p %q -k %q -c listen_addresses=127.0.0.1\n' \
        "$pgbin/postgres" "$data_dir/data" "$port" "$sock_dir" > "$run_script"
      ;;
  esac
  chmod 700 "$run_script"

  local manager="process" unit=""
  if _instance_has_systemd_user; then
    manager="systemd"
    unit="$(_instance_unit "$type" "$name")"
    mkdir -p "$INSTANCE_UNIT_DIR"
    cat > "$INSTANCE_UNIT_DIR/$unit" <<EOF
[Unit]
Description=Laravel Dev ${type} instance '${name}' (port ${port})
After=network.target

[Service]
Type=simple
ExecStart=${run_script}
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
EOF
    systemctl --user daemon-reload
    systemctl --user enable "$unit" >/dev/null 2>&1 || true
  fi

  python3 - "$conf_file" "$name" "$type" "$port" "$data_dir" "$manager" "$unit" <<'PY'
import json, sys
f, name, typ, port, data_dir, manager, unit = sys.argv[1:8]
users = {"redis": "", "mysql": "root", "postgresql": "postgres"}
with open(f, "w") as fp:
    json.dump({"name": name, "type": typ, "port": int(port), "host": "127.0.0.1",
               "username": users[typ], "password": "", "data_dir": data_dir,
               "manager": manager, "unit": unit}, fp, indent=2)
PY

  service_instance_control start "$type" "$name" || return 1
  echo "Instance '$id' created and running on 127.0.0.1:$port."
  case "$type" in
    mysql) echo "Connect: mysql -h 127.0.0.1 -P $port -u root   (no password)" ;;
    postgresql) echo "Connect: psql -h 127.0.0.1 -p $port -U postgres" ;;
    redis) echo "Connect: redis-cli -p $port" ;;
  esac
}

service_instance_control() {
  local action="${1:-}" type="${2:-}" name="${3:-}"
  _instance_validate "$type" "$name" || return 1
  local id="${type}-${name}"
  local conf_file="$INSTANCE_CONF_DIR/${id}.json"
  local data_dir="$INSTANCE_DATA_ROOT/${id}"
  [[ -f "$conf_file" ]] || { echo "Error: Instance '$id' does not exist." >&2; return 1; }
  local port unit
  port="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["port"])' "$conf_file")"
  unit="$(_instance_unit "$type" "$name")"

  if [[ -f "$INSTANCE_UNIT_DIR/$unit" ]] && _instance_has_systemd_user; then
    systemctl --user "$action" "$unit"
  elif [[ "$action" == "start" ]]; then
    if ! _instance_port_in_use "$port"; then
      nohup "$data_dir/run.sh" >>"$data_dir/instance.log" 2>&1 &
      echo $! > "$data_dir/instance.pid"
    fi
  elif [[ -f "$data_dir/instance.pid" ]]; then
    kill "$(cat "$data_dir/instance.pid")" 2>/dev/null || true
    rm -f -- "${data_dir:?}/instance.pid"
  fi

  if [[ "$action" == "start" ]]; then
    if ! _instance_wait_port "$port"; then
      echo "Error: instance '$id' did not start listening on port $port. Logs: $data_dir" >&2
      return 1
    fi
    echo "Instance '$id' is running on 127.0.0.1:$port."
  else
    echo "Instance '$id' stopped."
  fi
}

service_instance_delete() {
  local type="${1:-}" name="${2:-}"
  _instance_validate "$type" "$name" || return 1
  local id="${type}-${name}"
  local conf_file="$INSTANCE_CONF_DIR/${id}.json"
  local data_dir="$INSTANCE_DATA_ROOT/${id}"
  local unit
  unit="$(_instance_unit "$type" "$name")"

  if [[ -f "$conf_file" ]]; then
    service_instance_control stop "$type" "$name" >/dev/null 2>&1 || true
  fi
  if [[ -f "$INSTANCE_UNIT_DIR/$unit" ]]; then
    systemctl --user disable "$unit" >/dev/null 2>&1 || true
    rm -f -- "${INSTANCE_UNIT_DIR:?}/${unit:?}"
    systemctl --user daemon-reload >/dev/null 2>&1 || true
  fi

  rm -f -- "${conf_file:?}"
  # $type and $name are validated above, so this is always <data-root>/<type>-<name>.
  if [[ -d "$data_dir" ]]; then
    rm -rf -- "${INSTANCE_DATA_ROOT:?}/${id:?}"
  fi
  echo "Instance '$id' deleted."
}

