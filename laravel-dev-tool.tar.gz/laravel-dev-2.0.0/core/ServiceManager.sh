#!/usr/bin/env bash

# core/ServiceManager.sh - Installation and lifecycle management of extra local services:
# Mailpit, Redis, Meilisearch, and MinIO.

service_install_mailpit() {
  require_system_access
  echo "Installing Mailpit..."
  if ! command -v mailpit >/dev/null 2>&1; then
    if curl -sL https://raw.githubusercontent.com/axllent/mailpit/develop/install.sh | bash; then
      echo "Mailpit binary installed successfully."
    else
      echo "Failed to install Mailpit via installer script."
      return 1
    fi
  fi

  local bin_path
  bin_path="$(command -v mailpit || echo "/usr/local/bin/mailpit")"

  if [[ ! -f /etc/systemd/system/mailpit.service ]]; then
    echo "Creating /etc/systemd/system/mailpit.service..."
    sudo_cmd tee /etc/systemd/system/mailpit.service >/dev/null <<EOF
[Unit]
Description=Mailpit - local mail catcher
After=network.target

[Service]
Type=simple
# Local only: Mailpit listens on all interfaces by default.
ExecStart=${bin_path} --listen 127.0.0.1:8025 --smtp 127.0.0.1:1025
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    sudo_cmd systemctl daemon-reload
  fi

  sudo_cmd systemctl enable --now mailpit
  echo "Mailpit is active on SMTP :1025 and Web UI http://localhost:8025"
}

service_install_redis() {
  require_system_access
  echo "Installing Redis..."
  if command -v apt-get >/dev/null 2>&1; then
    sudo_cmd apt-get update -qq && sudo_cmd apt-get install -y redis-server
    sudo_cmd systemctl enable --now redis-server
  elif command -v dnf >/dev/null 2>&1; then
    sudo_cmd dnf install -y redis
    sudo_cmd systemctl enable --now redis
  elif command -v pacman >/dev/null 2>&1; then
    sudo_cmd pacman -S --noconfirm redis
    sudo_cmd systemctl enable --now redis
  else
    echo "Unsupported package manager for automatic Redis installation."
    return 1
  fi
  echo "Redis is active on port 6379"
}

service_install_meilisearch() {
  require_system_access
  echo "Installing Meilisearch..."
  if ! command -v meilisearch >/dev/null 2>&1 && [[ ! -f /usr/local/bin/meilisearch ]]; then
    local tmp_dir
    tmp_dir="$(mktemp -d)"
    local installed=0
    if ( cd "$tmp_dir" && curl -fsSL https://install.meilisearch.com | sh ); then
      if [[ -f "$tmp_dir/meilisearch" ]]; then
        sudo_cmd mv "$tmp_dir/meilisearch" /usr/local/bin/meilisearch
        sudo_cmd chmod +x /usr/local/bin/meilisearch
        installed=1
      fi
    fi

    if [[ "$installed" -ne 1 ]]; then
      local arch
      arch="$(uname -m)"
      case "$arch" in
        x86_64) arch="amd64" ;;
        aarch64|arm64) arch="aarch64" ;;
        *) arch="" ;;
      esac
      if [[ -n "$arch" ]]; then
        echo "Attempting fallback download of Meilisearch binary for $arch..."
        if curl -fsSL "https://github.com/meilisearch/meilisearch/releases/latest/download/meilisearch-linux-${arch}" -o "$tmp_dir/meilisearch"; then
          sudo_cmd mv "$tmp_dir/meilisearch" /usr/local/bin/meilisearch
          sudo_cmd chmod +x /usr/local/bin/meilisearch
          installed=1
        fi
      fi
    fi

    rm -rf "$tmp_dir"
    if [[ "$installed" -ne 1 ]]; then
      echo "Could not download Meilisearch binary."
      return 1
    fi
  fi

  sudo_cmd mkdir -p /var/lib/meilisearch/data

  if [[ ! -f /etc/systemd/system/meilisearch.service ]]; then
    echo "Creating /etc/systemd/system/meilisearch.service..."
    sudo_cmd tee /etc/systemd/system/meilisearch.service >/dev/null <<'EOF'
[Unit]
Description=Meilisearch Full-Text Search Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/meilisearch --db-path /var/lib/meilisearch/data --http-addr 127.0.0.1:7700 --env development --no-analytics
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    sudo_cmd systemctl daemon-reload
  fi

  sudo_cmd systemctl enable --now meilisearch
  echo "Meilisearch is active on http://127.0.0.1:7700"
}

# MinIO root credentials: generated once per machine and kept in a user-only
# file, so the app can fill AWS_* in a project's .env. An existing unit keeps
# the credentials it already runs with (changing them can lock out its data).
minio_credentials_file() {
  echo "${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev/minio.env"
}

load_minio_credentials() {
  local file unit=/etc/systemd/system/minio.service
  file="$(minio_credentials_file)"
  MINIO_USER="" MINIO_PASSWORD=""
  if [[ -f "$unit" ]]; then
    MINIO_USER="$(sed -n 's/^Environment="MINIO_ROOT_USER=\(.*\)"$/\1/p' "$unit" | head -n1)"
    MINIO_PASSWORD="$(sed -n 's/^Environment="MINIO_ROOT_PASSWORD=\(.*\)"$/\1/p' "$unit" | head -n1)"
  fi
  if [[ -z "$MINIO_USER" && -f "$file" ]]; then
    MINIO_USER="$(sed -n 's/^MINIO_ROOT_USER=//p' "$file" | head -n1)"
    MINIO_PASSWORD="$(sed -n 's/^MINIO_ROOT_PASSWORD=//p' "$file" | head -n1)"
  fi
  # The old shared default is replaced; projects pick the new pair up when
  # MinIO is applied to their .env again.
  if [[ -z "$MINIO_USER" || -z "$MINIO_PASSWORD" || "$MINIO_PASSWORD" == "minioadmin" ]]; then
    [[ "$MINIO_PASSWORD" == "minioadmin" ]] && echo "Replacing the default minioadmin password. Re-apply MinIO to each project's .env afterwards."
    MINIO_USER="laravel-dev"
    MINIO_PASSWORD="$(head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"
  fi
  mkdir -p "$(dirname "$file")"
  ( umask 077; printf 'MINIO_ROOT_USER=%s\nMINIO_ROOT_PASSWORD=%s\n' "$MINIO_USER" "$MINIO_PASSWORD" > "$file" )
}

service_install_minio() {
  require_system_access
  echo "Installing MinIO..."
  if ! command -v minio >/dev/null 2>&1 && [[ ! -f /usr/local/bin/minio ]]; then
    local arch
    arch="$(uname -m)"
    if [[ "$arch" == "x86_64" ]]; then
      arch="amd64"
    elif [[ "$arch" == "aarch64" || "$arch" == "arm64" ]]; then
      arch="arm64"
    else
      echo "Unsupported architecture for MinIO: $arch"
      return 1
    fi

    local tmp_bin
    tmp_bin="$(mktemp)"
    local downloaded=0
    local minio_urls=(
      "https://dl.min.io/server/minio/release/linux-${arch}/minio"
      "https://github.com/minio/minio/releases/latest/download/minio"
      "https://github.com/easybill/minio-builds/releases/download/RELEASE.2025-10-15T17-29-55Z/minio-linux-${arch}"
      "https://github.com/golithus/minio-builds/releases/download/RELEASE.2025-10-15T17-29-55Z/minio-linux-${arch}"
    )

    for url in "${minio_urls[@]}"; do
      echo "Downloading MinIO binary from $url..."
      if curl -fsSL "$url" -o "$tmp_bin" && [[ -s "$tmp_bin" ]]; then
        downloaded=1
        break
      fi
    done

    if [[ "$downloaded" -ne 1 ]] && command -v go >/dev/null 2>&1; then
      echo "Attempting to build MinIO via 'go install github.com/minio/minio@latest'..."
      if go install github.com/minio/minio@latest 2>/dev/null; then
        local gopath_bin
        gopath_bin="$(go env GOPATH 2>/dev/null || echo "$HOME/go")/bin/minio"
        if [[ -f "$gopath_bin" ]]; then
          cp "$gopath_bin" "$tmp_bin"
          downloaded=1
        fi
      fi
    fi

    if [[ "$downloaded" -eq 1 ]]; then
      sudo_cmd mv "$tmp_bin" /usr/local/bin/minio
      sudo_cmd chmod +x /usr/local/bin/minio
    else
      rm -f "$tmp_bin"
      echo "Failed to download MinIO binary. MinIO discontinued direct binary downloads on dl.min.io."
      echo "You can install MinIO manually or run 'go install github.com/minio/minio@latest'."
      return 1
    fi
  fi

  sudo_cmd mkdir -p /var/lib/minio/data

  if [[ ! -f /etc/systemd/system/minio.service ]]; then
    echo "Creating /etc/systemd/system/minio.service..."
    load_minio_credentials
    sudo_cmd tee /etc/systemd/system/minio.service >/dev/null <<EOF
[Unit]
Description=MinIO Object Storage
After=network.target

[Service]
Type=simple
Environment="MINIO_ROOT_USER=${MINIO_USER}"
Environment="MINIO_ROOT_PASSWORD=${MINIO_PASSWORD}"
# Local only: the default credentials must never be reachable from the network.
ExecStart=/usr/local/bin/minio server /var/lib/minio/data --address 127.0.0.1:9000 --console-address 127.0.0.1:9001
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    sudo_cmd systemctl daemon-reload
  fi

  sudo_cmd systemctl enable --now minio
  echo "MinIO is active on API :9000 and Web Console http://127.0.0.1:9001"
  echo "Credentials: $(minio_credentials_file)"
}

service_repair_mailpit() {
  require_system_access
  local bin_path
  bin_path="$(command -v mailpit || echo "/usr/local/bin/mailpit")"
  if [[ ! -x "$bin_path" ]]; then
    echo "Error: mailpit binary not found at $bin_path"
    return 1
  fi
  echo "Repairing /etc/systemd/system/mailpit.service to bind strictly to 127.0.0.1..."
  sudo_cmd tee /etc/systemd/system/mailpit.service >/dev/null <<EOF
[Unit]
Description=Mailpit - local mail catcher
After=network.target

[Service]
Type=simple
ExecStart=${bin_path} --listen 127.0.0.1:8025 --smtp 127.0.0.1:1025
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
  sudo_cmd systemctl daemon-reload
  sudo_cmd systemctl restart mailpit
  echo "Mailpit repaired: strictly listening on 127.0.0.1:8025 and 127.0.0.1:1025"
}

service_repair_meilisearch() {
  require_system_access
  local bin_path
  bin_path="$(command -v meilisearch || echo "/usr/local/bin/meilisearch")"
  if [[ ! -x "$bin_path" ]]; then
    echo "Error: meilisearch binary not found at $bin_path"
    return 1
  fi
  sudo_cmd mkdir -p /var/lib/meilisearch/data
  echo "Repairing /etc/systemd/system/meilisearch.service to bind strictly to 127.0.0.1:7700..."
  sudo_cmd tee /etc/systemd/system/meilisearch.service >/dev/null <<EOF
[Unit]
Description=Meilisearch Full-Text Search Server
After=network.target

[Service]
Type=simple
ExecStart=${bin_path} --db-path /var/lib/meilisearch/data --http-addr 127.0.0.1:7700 --env development --no-analytics
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
  sudo_cmd systemctl daemon-reload
  sudo_cmd systemctl restart meilisearch
  echo "Meilisearch repaired: strictly listening on 127.0.0.1:7700"
}

service_repair_minio() {
  require_system_access
  local bin_path
  bin_path="$(command -v minio || echo "/usr/local/bin/minio")"
  if [[ ! -x "$bin_path" ]]; then
    echo "Error: minio binary not found at $bin_path"
    return 1
  fi
  sudo_cmd mkdir -p /var/lib/minio/data
  echo "Repairing /etc/systemd/system/minio.service to bind strictly to 127.0.0.1..."
  load_minio_credentials
  sudo_cmd tee /etc/systemd/system/minio.service >/dev/null <<EOF
[Unit]
Description=MinIO Object Storage
After=network.target

[Service]
Type=simple
Environment="MINIO_ROOT_USER=${MINIO_USER}"
Environment="MINIO_ROOT_PASSWORD=${MINIO_PASSWORD}"
ExecStart=${bin_path} server /var/lib/minio/data --address 127.0.0.1:9000 --console-address 127.0.0.1:9001
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
  sudo_cmd systemctl daemon-reload
  sudo_cmd chmod 600 /etc/systemd/system/minio.service
  sudo_cmd systemctl restart minio
  echo "MinIO repaired: strictly listening on 127.0.0.1:9000 and 127.0.0.1:9001"
  echo "Credentials: $(minio_credentials_file)"
}

service_repair() {
  local service_name="${1:-}"
  case "$service_name" in
    mailpit)
      service_repair_mailpit
      ;;
    meilisearch)
      service_repair_meilisearch
      ;;
    minio)
      service_repair_minio
      ;;
    all)
      service_repair_mailpit || true
      service_repair_meilisearch || true
      service_repair_minio || true
      ;;
    *)
      echo "Usage: laravel-dev service-repair <mailpit|meilisearch|minio|all>"
      return 1
      ;;
  esac
}

service_install() {
  local service_name="${1:-}"
  case "$service_name" in
    mailpit)
      service_install_mailpit
      ;;
    redis|redis-server)
      service_install_redis
      ;;
    meilisearch)
      service_install_meilisearch
      ;;
    minio)
      service_install_minio
      ;;
    *)
      echo "Error: unknown service '$service_name'. Supported: mailpit, redis, meilisearch, minio"
      return 1
      ;;
  esac
}

