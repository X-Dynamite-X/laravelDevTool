#!/usr/bin/env bash

set -euo pipefail

get_nginx_include_glob() {
  local nginx_conf="/etc/nginx/nginx.conf"

  if [[ -d /etc/nginx/sites-enabled ]]; then
    echo "/etc/nginx/sites-enabled/*"
    return 0
  fi
  if [[ -f "$nginx_conf" ]] && grep -qE '/etc/nginx/http\.d/\*\.conf' "$nginx_conf"; then
    echo "/etc/nginx/http.d/*.conf"
    return 0
  fi
  if [[ -f "$nginx_conf" ]] && grep -qE '/etc/nginx/conf\.d/\*\.conf' "$nginx_conf"; then
    echo "/etc/nginx/conf.d/*.conf"
    return 0
  fi
  if [[ -d /etc/nginx/http.d ]]; then
    echo "/etc/nginx/http.d/*.conf"
    return 0
  fi
  echo "/etc/nginx/conf.d/*.conf"
}

nginx_loads_path() {
  local path="$1"
  local output
  output="$(sudo_cmd nginx -T 2>/dev/null)"

  # Check the path as given first (handles conf.d / http.d layouts).
  echo "$output" | grep -Fq "$path" && return 0

  # On sites-available/sites-enabled setups nginx -T reports the *symlink*
  # path (sites-enabled/name), not the real-file path (sites-available/name).
  # Cross-check both directions so the caller doesn't need to care which
  # side of the symlink pair it holds.
  local basename_path
  basename_path="$(basename "$path")"

  local enabled_path="/etc/nginx/sites-enabled/${basename_path}"
  if [[ "$enabled_path" != "$path" ]]; then
    echo "$output" | grep -Fq "$enabled_path" && return 0
  fi

  local avail_path="/etc/nginx/sites-available/${basename_path}"
  if [[ "$avail_path" != "$path" ]]; then
    echo "$output" | grep -Fq "$avail_path" && return 0
  fi

  return 1
}

get_nginx_config_path() {
  local name="$1"
  local include_glob=""

  if [[ -d /etc/nginx/sites-available ]]; then
    echo "/etc/nginx/sites-available/$name"
    return 0
  fi

  include_glob="$(get_nginx_include_glob)"
  echo "${include_glob/\*/$name.conf}"
}

ensure_nginx_include_exists() {
  local nginx_conf="/etc/nginx/nginx.conf"
  local include_glob=""
  local include_line=""

  if [[ ! -f "$nginx_conf" ]]; then
    return 0
  fi

  include_glob="$(get_nginx_include_glob)"
  include_line="    include ${include_glob};"

  if grep -Eq "^[[:space:]]*include[[:space:]]+${include_glob//\*/\\*};" "$nginx_conf"; then
    return 0
  fi

  sudo_cmd mkdir -p "$(dirname "$include_glob")"
  sudo_cmd cp "$nginx_conf" "${nginx_conf}.bak-laravel-dev"
  sudo_cmd awk -v include_line="$include_line" '
    BEGIN { inserted = 0; in_http = 0; depth = 0 }
    {
      line = $0
      if (line ~ /^[[:space:]]*http[[:space:]]*\{[[:space:]]*$/) {
        in_http = 1
        depth = 1
        print line
        next
      }

      if (in_http) {
        opens = gsub(/\{/, "{", line)
        closes = gsub(/\}/, "}", line)
        if (!inserted && depth == 1 && closes > 0 && opens == 0) {
          print include_line
          inserted = 1
        }
        print line
        depth += opens - closes
        if (depth <= 0) {
          in_http = 0
        }
        next
      }

      print line
    }
    END {
      if (!inserted) {
        exit 1
      }
    }
  ' "$nginx_conf" | sudo_cmd tee "$nginx_conf.tmp" >/dev/null
  sudo_cmd mv "$nginx_conf.tmp" "$nginx_conf"
}

remove_nginx_site() {
  local name="$1"
  local config_path
  config_path="$(get_nginx_config_path "$name")"

  sudo_cmd rm -f "$config_path" 2>/dev/null || true
  sudo_cmd rm -f "/etc/nginx/sites-enabled/$name" "/etc/nginx/sites-enabled/$name.conf" 2>/dev/null || true
  sudo_cmd rm -f "/etc/nginx/http.d/${name}.conf" 2>/dev/null || true
  sudo_cmd rm -f "/etc/nginx/conf.d/${name}.conf" 2>/dev/null || true
}

detect_project_php_version() {
  local name="$1"
  local config
  local parsed=""
  config="$(get_nginx_config_path "$name")"

  if [[ ! -f "$config" && -f "/etc/nginx/sites-available/$name" ]]; then
    config="/etc/nginx/sites-available/$name"
  fi
  if [[ ! -f "$config" && -f "/etc/nginx/sites-available/$name.conf" ]]; then
    config="/etc/nginx/sites-available/$name.conf"
  fi

  if [[ -f "$config" ]]; then
    parsed="$(grep -Eo 'php[0-9]+\.[0-9]+-fpm\.sock' "$config" | head -n1 | sed -E 's/php([0-9]+\.[0-9]+)-fpm\.sock/\1/' || true)"
  fi

  if [[ -n "$parsed" ]]; then
    echo "$parsed"
    return 0
  fi

  default_php_version
}

SSL_CERT_DIR="/etc/nginx/ssl/laravel-dev"
SSL_CERT_FILE=""
SSL_KEY_FILE=""

desktop_user() {
  echo "${SUDO_USER:-${USER:-$(id -un)}}"
}

desktop_user_home() {
  local user home_dir=""
  user="$(desktop_user)"
  home_dir="$(getent passwd "$user" 2>/dev/null | cut -d: -f6 || true)"
  echo "${home_dir:-$HOME}"
}

run_as_desktop_user() {
  local user home_dir
  user="$(desktop_user)"
  home_dir="$(desktop_user_home)"
  if [[ "$(id -u)" -eq 0 && "$user" != "root" ]]; then
    sudo -u "$user" env HOME="$home_dir" "$@"
  else
    env HOME="$home_dir" "$@"
  fi
}

ensure_local_ca_trusted() {
  local force="${1:-0}"
  if ! command -v mkcert >/dev/null 2>&1; then
    return 0
  fi

  local ca_root=""
  ca_root="$(run_as_desktop_user mkcert -CAROOT 2>/dev/null || true)"
  if [[ -z "$ca_root" ]]; then
    return 0
  fi

  # Install into browser NSS stores (Chrome/Brave/Firefox) as the desktop user
  # without invoking mkcert's internal sudo prompt.
  if [[ "$force" == "1" || ! -f "$ca_root/rootCA.pem" || ! -f "$ca_root/.laravel-dev-nss" ]]; then
    if run_as_desktop_user env TRUST_STORES=nss mkcert -install >/dev/null 2>&1; then
      run_as_desktop_user touch "$ca_root/.laravel-dev-nss" 2>/dev/null || true
    fi
  fi

  # Ensure rootCA.pem exists even if NSS tools were not present.
  if [[ ! -f "$ca_root/rootCA.pem" ]]; then
    local tmp_dir
    tmp_dir="$(mktemp -d)"
    chmod 755 "$tmp_dir"
    run_as_desktop_user mkcert -cert-file "$tmp_dir/c.pem" -key-file "$tmp_dir/k.pem" localhost >/dev/null 2>&1 || true
    rm -rf "$tmp_dir"
  fi

  [[ -f "$ca_root/rootCA.pem" ]] || return 0

  # Install into the system CA store via sudo_cmd (supports GUI askpass).
  if command -v update-ca-certificates >/dev/null 2>&1 && [[ -d /usr/local/share/ca-certificates ]]; then
    local sys_crt="/usr/local/share/ca-certificates/laravel-dev-mkcert-rootCA.crt"
    if [[ "$force" == "1" ]] || ! cmp -s "$ca_root/rootCA.pem" "$sys_crt" 2>/dev/null; then
      sudo_cmd cp "$ca_root/rootCA.pem" "$sys_crt"
      sudo_cmd chmod 644 "$sys_crt"
      sudo_cmd update-ca-certificates >/dev/null 2>&1 || true
    fi
  elif command -v trust >/dev/null 2>&1 && [[ -d /etc/ca-certificates/trust-source/anchors ]]; then
    local arch_crt="/etc/ca-certificates/trust-source/anchors/laravel-dev-mkcert-rootCA.crt"
    if [[ "$force" == "1" ]] || ! cmp -s "$ca_root/rootCA.pem" "$arch_crt" 2>/dev/null; then
      sudo_cmd cp "$ca_root/rootCA.pem" "$arch_crt"
      sudo_cmd chmod 644 "$arch_crt"
      sudo_cmd trust extract-compat >/dev/null 2>&1 || true
    fi
  elif command -v update-ca-trust >/dev/null 2>&1 && [[ -d /etc/pki/ca-trust/source/anchors ]]; then
    local rhel_crt="/etc/pki/ca-trust/source/anchors/laravel-dev-mkcert-rootCA.pem"
    if [[ "$force" == "1" ]] || ! cmp -s "$ca_root/rootCA.pem" "$rhel_crt" 2>/dev/null; then
      sudo_cmd cp "$ca_root/rootCA.pem" "$rhel_crt"
      sudo_cmd chmod 644 "$rhel_crt"
      sudo_cmd update-ca-trust extract >/dev/null 2>&1 || true
    fi
  fi
}

ensure_domain_ssl() {
  local domain="$1"
  local force="${2:-0}"
  SSL_CERT_FILE="$SSL_CERT_DIR/${domain}.pem"
  SSL_KEY_FILE="$SSL_CERT_DIR/${domain}-key.pem"

  # Trust the CA once (no-op when already trusted); forcing a certificate
  # renewal shouldn't re-run the whole system trust-store update.
  ensure_local_ca_trusted 0

  if [[ "$force" != "1" && -s "$SSL_CERT_FILE" && -s "$SSL_KEY_FILE" ]]; then
    return 0
  fi

  local tmp_dir
  tmp_dir="$(mktemp -d)"
  chmod 755 "$tmp_dir"

  if command -v mkcert >/dev/null 2>&1; then
    run_as_desktop_user mkcert \
      -cert-file "$tmp_dir/cert.pem" \
      -key-file "$tmp_dir/key.pem" \
      "$domain" "*.$domain" localhost 127.0.0.1 ::1 >/dev/null 2>&1 || true
  fi

  if [[ ! -s "$tmp_dir/cert.pem" || ! -s "$tmp_dir/key.pem" ]]; then
    openssl req -x509 -nodes -newkey rsa:2048 -days 825 \
      -subj "/CN=${domain}" \
      -addext "subjectAltName=DNS:${domain},DNS:*.${domain},DNS:localhost,IP:127.0.0.1" \
      -keyout "$tmp_dir/key.pem" \
      -out "$tmp_dir/cert.pem" >/dev/null 2>&1
  fi

  sudo_cmd mkdir -p "$SSL_CERT_DIR"
  sudo_cmd cp "$tmp_dir/cert.pem" "$SSL_CERT_FILE"
  sudo_cmd cp "$tmp_dir/key.pem" "$SSL_KEY_FILE"
  sudo_cmd chmod 644 "$SSL_CERT_FILE"
  sudo_cmd chmod 600 "$SSL_KEY_FILE"
  rm -rf "$tmp_dir"
  echo "SSL: https://$domain ready"
}

ensure_domain_mapping() {
  local name="$1"
  local domain="${2:-${name}.test}"

  if ! grep -qE "^[[:space:]]*127\\.0\\.0\\.1([[:space:]]+[^#[:space:]]+)*[[:space:]]+${domain}([[:space:]]|$)" /etc/hosts; then
    echo "127.0.0.1 ${domain}" | sudo_cmd tee -a /etc/hosts >/dev/null
  fi
  # if ! grep -qE "^[[:space:]]*::1([[:space:]]+[^#[:space:]]+)*[[:space:]]+${domain}([[:space:]]|$)" /etc/hosts; then
  #   echo "::1 ${domain}" | sudo_cmd tee -a /etc/hosts >/dev/null
  # fi

  # Refresh resolver cache when available.
  if command -v resolvectl >/dev/null 2>&1; then
    sudo_cmd resolvectl flush-caches >/dev/null 2>&1 || true
  elif command -v systemd-resolve >/dev/null 2>&1; then
    sudo_cmd systemd-resolve --flush-caches >/dev/null 2>&1 || true
  fi

  # Hard check to prevent "DNS_PROBE_POSSIBLE" after a "successful" create.
  if ! grep -qE "^[^#]*[[:space:]]${domain}([[:space:]]|$)" /etc/hosts; then
    echo "Error: domain mapping missing from /etc/hosts for $domain."
    exit 1
  fi

  if ! getent hosts "$domain" | awk '{print $1}' | grep -Eq "^(127\\.0\\.0\\.1|::1)$"; then
    echo "Error: domain mapping failed for $domain. Verify /etc/hosts and NSS config."
    exit 1
  fi
}

create_nginx() {
  local name="$1"
  local php_version="$2"
  local custom_path="${3:-}"
  local custom_domain="${4:-}"
  local domain=""
  local socket
  local config
  local project_root
  local project_dir

  # Read project path from registry if available and no custom path provided
  if [[ -z "$custom_path" ]] && declare -F get_project_field >/dev/null 2>&1; then
    project_dir="$(get_project_field "$name" "PROJECT_PATH" 2>/dev/null || true)"
  else
    project_dir="$custom_path"
  fi
  project_dir="${project_dir:-$SITES_DIR/$name}"

  # Without an explicit domain, reuse the registered one so repair doesn't
  # silently reset a custom domain back to <name>.test.
  if [[ -z "$custom_domain" ]] && declare -F get_project_field >/dev/null 2>&1; then
    custom_domain="$(get_project_field "$name" "DOMAIN" 2>/dev/null || true)"
  fi
  domain="${custom_domain:-${name}.test}"

  socket="$(get_php_socket "$php_version")"
  config="$(get_nginx_config_path "$name")"
  project_root="$project_dir/public"

  ensure_nginx_include_exists
  sudo_cmd mkdir -p "$(dirname "$config")"

  if [[ ! -S "$socket" ]]; then
    local fallback_socket
    fallback_socket="$(
      ls -1 /run/php/php*-fpm.sock /run/php-fpm/php*-fpm.sock /run/php-fpm/www.sock /run/php-fpm/php-fpm.sock 2>/dev/null \
      | head -n1 || true
    )"
    if [[ -n "$fallback_socket" ]]; then
      echo "Warning: requested socket '$socket' not found, using '$fallback_socket'"
      socket="$fallback_socket"
    fi
  fi

  if [[ ! -f "$BASE_DIR/config/nginx-template.conf" ]]; then
    echo "Error: nginx template not found"
    exit 1
  fi

  sudo_cmd cp "$BASE_DIR/config/nginx-template.conf" "$config"

  # Build server_name with domain, wildcard, and any extra aliases
  local aliases=""
  local wildcard="1"
  if declare -F get_project_field >/dev/null 2>&1; then
    aliases="$(get_project_field "$name" "ALIASES" 2>/dev/null || true)"
    wildcard="$(get_project_field "$name" "WILDCARD" 2>/dev/null || echo "1")"
  fi
  local server_names="$domain"
  if [[ "$wildcard" != "0" ]]; then
    server_names="$server_names *.$domain"
  fi
  if [[ -n "$aliases" ]]; then
    server_names="$server_names $aliases"
  fi

  # Replace longer placeholders first to avoid partial replacement bugs
  # like PROJECT_ROOT -> test2_ROOT when PROJECT is replaced first.
  sudo_cmd sed -i "s#PROJECT_ROOT#$project_root#g" "$config"
  sudo_cmd sed -i "s#PHP_SOCKET#$socket#g" "$config"
  sudo_cmd sed -i "s#LARAVEL_DEV_DEBUG_PREPEND#$BASE_DIR/php/debug_prepend.php#g" "$config"
  sudo_cmd sed -i "s/server_name PROJECT_DOMAIN \*\.PROJECT_DOMAIN;/server_name $server_names;/g" "$config"
  sudo_cmd sed -i "s/PROJECT_DOMAIN/$domain/g" "$config"
  sudo_cmd sed -i "s/PROJECT/$name/g" "$config"
  # Backward compatibility with old template placeholder.
  sudo_cmd sed -i "s#HOME_PATH#$HOME#g" "$config"

  if sudo_cmd grep -qE 'PROJECT_ROOT|PROJECT_DOMAIN|PROJECT|PHP_SOCKET|HOME_PATH' "$config"; then
    echo "Error: unresolved placeholders detected in nginx config: $config"
    exit 1
  fi

  if [[ ! -f "$project_root/index.php" ]]; then
    echo "Error: project public index not found at $project_root/index.php"
    exit 1
  fi

  activate_nginx_site "$name" "$config" "$domain"
}

ensure_nginx_perf_logging() {
  # The format must live in a directory nginx.conf really includes (Arch has no
  # conf.d include), and sort before the site files that reference it.
  local include_dir
  include_dir="$(dirname "$(get_nginx_include_glob)")"
  if [[ -n "$include_dir" ]]; then
    sudo_cmd mkdir -p "$include_dir"
    local fmt_file="$include_dir/00-laravel-dev-log-format.conf"
    local legacy="/etc/nginx/conf.d/laravel-dev-log-format.conf"
    # A second definition of the same format makes `nginx -t` fail.
    [[ "$legacy" != "$fmt_file" ]] && sudo_cmd rm -f "$legacy"
    # Update the owned format file so existing sites receive new request
    # metadata too. Bodies, cookies and authorization headers are never logged.
    echo 'log_format laravel_dev_json escape=json '\''{"t":"$time_iso8601","m":"$request_method","u":"$request_uri","h":"$host","s":$status,"b":$body_bytes_sent,"rt":$request_time,"ut":"$upstream_response_time","uht":"$upstream_header_time","uct":"$upstream_connect_time","us":"$upstream_status","uaddr":"$upstream_addr","ip":"$remote_addr","ref":"$http_referer","ua":"$http_user_agent"}'\'';' | sudo_cmd tee "$fmt_file" >/dev/null
    # The app's once-a-minute uptime ping would otherwise drown out real traffic.
    printf '%s\n' 'map $http_user_agent $laravel_dev_loggable {' '    ~LaravelDev-Uptime 0;' '    default 1;' '}' \
      | sudo_cmd tee -a "$fmt_file" >/dev/null
  fi
  sudo_cmd mkdir -p /var/log/nginx/laravel-dev
  sudo_cmd chmod 755 /var/log/nginx/laravel-dev 2>/dev/null || true
}

# Make the site reachable from the local network: add a `listen <port>` on all
# interfaces next to port 80. Being the only server on that port, nginx routes
# every request there to this site whatever the Host header (an IP) says.
ensure_lan_listen() {
  local name="$1"
  local config="$2"
  declare -F get_project_field >/dev/null 2>&1 || return 0
  sudo_cmd sed -i '/# laravel-dev:lan$/d' "$config"
  [[ "$(get_project_field "$name" "LAN_ACCESS" 2>/dev/null || true)" == "0" ]] && return 0

  local port
  port="$(get_project_field "$name" "LAN_PORT" 2>/dev/null || true)"
  if [[ -z "$port" ]]; then
    port="$(allocate_lan_port)" || { echo "Warning: no free LAN port for $name"; return 0; }
    update_project_record "$name" "LAN_PORT" "$port"
  fi
  sudo_cmd sed -i "0,/^\([[:space:]]*\)listen 80;/s//&\n\1listen 0.0.0.0:${port}; # laravel-dev:lan/" "$config"

  if command -v ufw >/dev/null 2>&1 && sudo_cmd ufw status 2>/dev/null | grep -q "^Status: active"; then
    sudo_cmd ufw allow "$port/tcp" comment "laravel-dev $name" >/dev/null 2>&1 || true
  fi
  echo "LAN: http://$(lan_ip):${port}"
}

lan_ip() {
  local ip
  ip="$(ip route get 1.1.1.1 2>/dev/null | awk '{for (i = 1; i < NF; i++) if ($i == "src") { print $(i + 1); exit }}')"
  [[ -n "$ip" ]] || ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
  echo "${ip:-127.0.0.1}"
}

# Enable a site config, map its domain in /etc/hosts and reload nginx.
activate_nginx_site() {
  local name="$1"
  local config="$2"
  local domain="$3"

  ensure_nginx_perf_logging
  ensure_domain_ssl "$domain" "${FORCE_SSL_RENEW:-0}"
  sudo_cmd sed -i "s#SSL_CERT#$SSL_CERT_FILE#g" "$config"
  sudo_cmd sed -i "s#SSL_KEY#$SSL_KEY_FILE#g" "$config"
  ensure_lan_listen "$name" "$config"

  # ── Symlink: sites-available → sites-enabled ──────────────────────────
  # When the sites-available/sites-enabled layout is present (Debian/Ubuntu),
  # ensure sites-enabled exists and the symlink is always created/updated.
  if [[ -d /etc/nginx/sites-available ]]; then
    sudo_cmd mkdir -p /etc/nginx/sites-enabled
    local symlink_target="/etc/nginx/sites-enabled/$name"
    if [[ -L "$symlink_target" || -e "$symlink_target" ]]; then
      sudo_cmd rm -f "$symlink_target"
    fi
    sudo_cmd ln -s "$config" "$symlink_target"
    echo "Nginx: symlink created → $symlink_target → $config"
  elif [[ -d /etc/nginx/sites-enabled ]]; then
    # sites-enabled exists but sites-available doesn't (unusual layout).
    sudo_cmd ln -sfn "$config" "/etc/nginx/sites-enabled/$name"
  fi
  # ──────────────────────────────────────────────────────────────────────

  if ! nginx_loads_path "$config"; then
    ensure_nginx_include_exists
  fi

  ensure_domain_mapping "$name" "$domain"
  local site_aliases=""
  if declare -F get_project_field >/dev/null 2>&1; then
    site_aliases="$(get_project_field "$name" "ALIASES" 2>/dev/null || true)"
  fi
  for alias_host in $site_aliases; do
    if [[ "$alias_host" != \** ]]; then
      ensure_domain_mapping "$name" "$alias_host"
    fi
  done

  sudo_cmd nginx -t
  if ! nginx_loads_path "$config"; then
    echo "Error: nginx is not loading project config: $config"
    echo "Check include directives inside /etc/nginx/nginx.conf"
    exit 1
  fi
  # Prefer reload (graceful, zero-downtime) when only adding/updating a site.
  sudo_cmd systemctl reload nginx 2>/dev/null \
    || sudo_cmd systemctl restart nginx 2>/dev/null \
    || sudo_cmd service nginx reload 2>/dev/null \
    || sudo_cmd service nginx restart
}

secure_project() {
  local name="$1"
  local project_type=""
  if declare -F get_project_field >/dev/null 2>&1; then
    project_type="$(get_project_field "$name" "PROJECT_TYPE" 2>/dev/null || true)"
  fi

  FORCE_SSL_RENEW=1
  if [[ -n "$project_type" && "$project_type" != "laravel" ]]; then
    repair_app "$name"
  else
    local php_version
    php_version="$(detect_project_php_version "$name")"
    create_nginx "$name" "$php_version"
  fi
  FORCE_SSL_RENEW=0
}

secure_all_projects() {
  ensure_local_ca_trusted 1
  local name
  while IFS= read -r name; do
    [[ -n "$name" ]] || continue
    secure_project "$name" || true
  done < <(list_registered_project_names | sort -u)
}


diagnose_project() {
  local name="$1"
  local domain=""
  local config
  local project_root=""
  local project_public

  if declare -F get_project_field >/dev/null 2>&1; then
    domain="$(get_project_field "$name" "DOMAIN" 2>/dev/null || true)"
    project_root="$(get_project_field "$name" "PROJECT_PATH" 2>/dev/null || true)"
  fi
  domain="${domain:-${name}.test}"
  project_root="${project_root:-$SITES_DIR/$name}"
  config="$(get_nginx_config_path "$name")"
  project_public="$project_root/public"

  echo "Project: $name"
  echo "Sites dir: $SITES_DIR"
  echo "Project root: $project_root"
  echo "Public dir: $project_public"
  echo "Domain: $domain"
  echo "Nginx config path: $config"
  echo

  if [[ -d "$project_root" ]]; then
    echo "[ok] project directory exists"
  else
    echo "[error] project directory missing"
  fi

  if [[ -f "$project_public/index.php" ]]; then
    echo "[ok] public/index.php exists"
  else
    echo "[error] public/index.php missing"
  fi

  if [[ -f "$project_root/routes/web.php" ]]; then
    echo "[ok] routes/web.php exists"
  else
    echo "[warn] routes/web.php missing"
  fi

  if [[ -f "$config" ]]; then
    echo "[ok] nginx config exists"
  else
    echo "[error] nginx config missing"
  fi

  if nginx_loads_path "$config"; then
    echo "[ok] nginx loads project config"
  else
    echo "[error] nginx does not load project config"
  fi

  if grep -qE "^[^#]*[[:space:]]${domain}([[:space:]]|$)" /etc/hosts; then
    echo "[ok] hosts entry exists"
  else
    echo "[error] hosts entry missing"
  fi

  echo
  echo "getent hosts:"
  getent hosts "$domain" || true
  echo
  echo "curl headers:"
  curl -I --max-time 5 "http://$domain" 2>/dev/null || true
}
