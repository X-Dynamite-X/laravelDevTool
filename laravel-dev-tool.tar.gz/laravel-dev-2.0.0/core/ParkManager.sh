#!/usr/bin/env bash

set -euo pipefail

# core/ParkManager.sh - Manages Valet-style parked directories for unlinked sites in SITES_DIR

PARK_CONF_NAME="00-laravel-dev-park"

park_paths_file() {
  local cfg_dir="${XDG_CONFIG_HOME:-$HOME/.config}/laravel-dev"
  mkdir -p "$cfg_dir" 2>/dev/null || true
  echo "$cfg_dir/parked.json"
}

# Parked directories: the sites directory (always) plus the ones added with `park add`.
park_list_paths() {
  local file
  file="$(park_paths_file)"
  echo "${LARAVEL_SITES_DIR:-$HOME/Sites}"
  if [[ -f "$file" ]] && command -v python3 >/dev/null 2>&1; then
    python3 -c "import json, sys; [print(p) for p in json.load(open(sys.argv[1])) if isinstance(p, str)]" "$file" 2>/dev/null || true
  fi
}

# Paths end up inside an nginx string and a ":"-separated list.
PARK_BAD_PATH_RE='[:"|$;\\]'
park_validate_path() {
  if [[ "$1" =~ $PARK_BAD_PATH_RE || "$1" == *$'\n'* ]]; then
    echo "Error: parked directory paths may not contain : \" | \$ ; or backslashes: $1" >&2
    return 1
  fi
}

park_dirs_param() {
  local seen="" out="" dir
  while IFS= read -r dir; do
    [[ -n "$dir" ]] || continue
    [[ ":$seen:" == *":$dir:"* ]] && continue
    park_validate_path "$dir" 2>/dev/null || continue
    seen="$seen:$dir"
    out="${out:+$out:}$dir"
  done < <(park_list_paths)
  echo "$out"
}

park_status() {
  local conf_path
  conf_path="$(get_nginx_config_path "$PARK_CONF_NAME")"
  if [[ -f "$conf_path" ]] && nginx_loads_path "$conf_path"; then
    echo "enabled"
  else
    echo "disabled"
  fi
}

park_paths() {
  local fmt="${1:-text}"
  local file
  file="$(park_paths_file)"

  if [[ "$fmt" == "--json" || "$fmt" == "json" ]]; then
    if [[ -f "$file" ]]; then
      cat "$file"
    else
      echo "[]"
    fi
    return 0
  fi

  local count=0
  echo "Parked Directories:"
  while IFS= read -r p; do
    [[ -z "$p" ]] && continue
    echo "  - $p"
    ((count++)) || true
  done < <(park_list_paths)

  if [[ "$count" -eq 0 ]]; then
    echo "  (No directories parked yet. Use 'laravel-dev park add <dir>' or 'laravel-dev park' inside a folder)."
  fi
}

park_add() {
  local target="${1:-$PWD}"
  target="$(realpath "$target" 2>/dev/null || echo "$target")"

  if [[ ! -d "$target" ]]; then
    echo "Error: Directory does not exist: $target" >&2
    return 1
  fi
  park_validate_path "$target" || return 1

  local file
  file="$(park_paths_file)"

  python3 - "$file" "$target" <<'PY'
import json, sys
f, p = sys.argv[1], sys.argv[2]
try:
    data = json.load(open(f))
except Exception:
    data = []
if not isinstance(data, list):
    data = []
if p not in data:
    data.append(p)
with open(f, "w") as fp:
    json.dump(data, fp, indent=2)
PY

  echo "Added '$target' to parked directories."
  grant_runtime_access "$target" 2>/dev/null || true

  # Ensure parking vhost is enabled
  park_enable
}

park_remove() {
  local target="${1:-$PWD}"
  target="$(realpath "$target" 2>/dev/null || echo "$target")"

  local file
  file="$(park_paths_file)"

  if [[ "$target" == "$(realpath "${LARAVEL_SITES_DIR:-$HOME/Sites}" 2>/dev/null || echo "${LARAVEL_SITES_DIR:-$HOME/Sites}")" ]]; then
    echo "The sites directory is always parked. Use 'laravel-dev park disable' to turn parking off." >&2
    return 1
  fi
  if [[ -f "$file" ]]; then
    python3 - "$file" "$target" <<'PY'
import json, sys
f, p = sys.argv[1], sys.argv[2]
try:
    data = json.load(open(f))
except Exception:
    data = []
data = [x for x in data if x != p] if isinstance(data, list) else []
with open(f, "w") as fp:
    json.dump(data, fp, indent=2)
PY
  fi

  echo "Removed '$target' from parked directories."
  # Regenerate the vhost so nginx stops serving the removed directory (if parking is on).
  if [[ "$(park_status)" == "enabled" ]]; then
    park_enable >/dev/null 2>&1 || true
  fi
}

park_enable() {
  require_system_access
  local template="$BASE_DIR/config/nginx-park-template.conf"
  local conf_path
  conf_path="$(get_nginx_config_path "$PARK_CONF_NAME")"
  local php_socket
  php_socket="$(get_php_socket)"
  local sites_dir="${LARAVEL_SITES_DIR:-$HOME/Sites}"
  local dispatcher="$BASE_DIR/php/park_dispatcher.php"

  if [[ ! -f "$template" ]]; then
    echo "Error: Park template not found at $template"
    return 1
  fi

  echo "Enabling Parked directories vhost..."
  local tmp
  tmp="$(mktemp)"
  sed \
    -e "s|SITES_DIR|$sites_dir|g" \
    -e "s|PHP_SOCKET|$php_socket|g" \
    -e "s|PARK_DISPATCHER|$dispatcher|g" \
    -e "s|PARKED_DIRS|$(park_dirs_param)|g" \
    -e "s|LARAVEL_DEV_DEBUG_PREPEND|$BASE_DIR/php/debug_prepend.php|g" \
    "$template" > "$tmp"

  sudo_cmd mkdir -p "$(dirname "$conf_path")"
  sudo_cmd cp "$tmp" "$conf_path"
  rm -f "$tmp"

  if [[ -d /etc/nginx/sites-enabled && -d /etc/nginx/sites-available ]]; then
    sudo_cmd ln -sf "$conf_path" "/etc/nginx/sites-enabled/$PARK_CONF_NAME"
  fi

  # Set base ACL permissions on all parked directories
  while IFS= read -r dir; do
    [[ -n "$dir" && -d "$dir" ]] && grant_runtime_access "$dir" 2>/dev/null || true
  done < <(park_list_paths)

  echo "Testing Nginx configuration..."
  if ! sudo_cmd nginx -t; then
    echo "Error: Nginx configuration test failed. Rolling back..."
    park_disable >/dev/null 2>&1 || true
    return 1
  fi

  sudo_cmd systemctl reload nginx
  echo "Success: Parked directories enabled! Any site inside parked directories is accessible at http://<folder>.test"
}

park_disable() {
  require_system_access
  local conf_path
  conf_path="$(get_nginx_config_path "$PARK_CONF_NAME")"
  sudo_cmd rm -f "$conf_path" "/etc/nginx/sites-enabled/$PARK_CONF_NAME" 2>/dev/null || true
  sudo_cmd systemctl reload nginx 2>/dev/null || true
  echo "Parked directories disabled."
}
