#!/usr/bin/env bash

set -euo pipefail

# core/ParkManager.sh - Manages Valet-style parked directories for unlinked sites in SITES_DIR

PARK_CONF_NAME="00-laravel-dev-park"

park_status() {
  local conf_path
  conf_path="$(get_nginx_config_path "$PARK_CONF_NAME")"
  if [[ -f "$conf_path" ]] && nginx_loads_path "$conf_path"; then
    echo "enabled"
  else
    echo "disabled"
  fi
}

park_enable() {
  require_system_access
  local template="$BASE_DIR/config/nginx-park-template.conf"
  local conf_path
  conf_path="$(get_nginx_config_path "$PARK_CONF_NAME")"
  local php_socket
  php_socket="$(get_php_socket)"
  local sites_dir="${LARAVEL_SITES_DIR:-$HOME/Sites}"

  if [[ ! -f "$template" ]]; then
    echo "Error: Park template not found at $template"
    return 1
  fi

  echo "Enabling Parked directories in $sites_dir..."
  local tmp
  tmp="$(mktemp)"
  sed \
    -e "s|SITES_DIR|$sites_dir|g" \
    -e "s|PHP_SOCKET|$php_socket|g" \
    -e "s|LARAVEL_DEV_DEBUG_PREPEND|$BASE_DIR/php/debug_prepend.php|g" \
    "$template" > "$tmp"

  sudo_cmd mkdir -p "$(dirname "$conf_path")"
  sudo_cmd cp "$tmp" "$conf_path"
  rm -f "$tmp"

  if [[ -d /etc/nginx/sites-enabled && -d /etc/nginx/sites-available ]]; then
    sudo_cmd ln -sf "$conf_path" "/etc/nginx/sites-enabled/$PARK_CONF_NAME"
  fi

  # Set base ACL permissions on sites directory for web server
  grant_runtime_access "$sites_dir" 2>/dev/null || true

  echo "Testing Nginx configuration..."
  if ! sudo_cmd nginx -t; then
    echo "Error: Nginx configuration test failed. Rolling back..."
    park_disable >/dev/null 2>&1 || true
    return 1
  fi

  sudo_cmd systemctl reload nginx
  echo "Success: Parked directories enabled! Any Laravel site in $sites_dir is available at http://<folder>.test"
}

park_disable() {
  require_system_access
  local conf_path
  conf_path="$(get_nginx_config_path "$PARK_CONF_NAME")"
  sudo_cmd rm -f "$conf_path" "/etc/nginx/sites-enabled/$PARK_CONF_NAME" 2>/dev/null || true
  sudo_cmd systemctl reload nginx 2>/dev/null || true
  echo "Parked directories disabled."
}
