#!/usr/bin/env bash
set -euo pipefail

# Manages CLI PATH shim for per-directory PHP version selection

SHIM_INSTALL_DIR="${HOME}/.local/share/laravel-dev/bin"
SHIM_BIN="${SHIM_INSTALL_DIR}/php"

shim_status() {
  local active=0
  if [[ -x "$SHIM_BIN" ]]; then
    if grep -q "laravel-dev:shim" "${HOME}/.bashrc" 2>/dev/null || grep -q "laravel-dev:shim" "${HOME}/.zshrc" 2>/dev/null; then
      active=1
    fi
  fi
  if [[ "$active" -eq 1 ]]; then
    echo "enabled"
  else
    echo "disabled"
  fi
}

shim_enable() {
  mkdir -p "$SHIM_INSTALL_DIR"
  cp "$BASE_DIR/config/php-shim.sh" "$SHIM_BIN"
  chmod +x "$SHIM_BIN"

  local line="export PATH=\"\$HOME/.local/share/laravel-dev/bin:\$PATH\" # laravel-dev:shim"

  for rc in "${HOME}/.bashrc" "${HOME}/.zshrc"; do
    if [[ -f "$rc" ]] && ! grep -q "laravel-dev:shim" "$rc"; then
      echo "" >> "$rc"
      echo "$line" >> "$rc"
    fi
  done

  echo "PHP CLI shim enabled in ~/.bashrc and ~/.zshrc."
  echo "Open a new terminal or run: source ~/.bashrc"
}

shim_disable() {
  rm -f "$SHIM_BIN"

  for rc in "${HOME}/.bashrc" "${HOME}/.zshrc"; do
    if [[ -f "$rc" ]] && grep -q "laravel-dev:shim" "$rc"; then
      sed -i '/laravel-dev:shim/d' "$rc" 2>/dev/null || true
    fi
  done

  echo "PHP CLI shim disabled."
}
