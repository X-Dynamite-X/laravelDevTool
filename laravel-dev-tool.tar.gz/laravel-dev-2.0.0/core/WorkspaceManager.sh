#!/usr/bin/env bash

set -euo pipefail

# core/WorkspaceManager.sh - Manages isolated Git Workspaces & Branch Subdomains

sanitize_branch_name() {
  local branch="$1"
  echo "$branch" | tr '/_.' '-' | tr '[:upper:]' '[:lower:]' | tr -cd '[:alnum:]-' | sed 's/^-*//;s/-*$//'
}

workspace_exclude_dir() {
  local project_path="$1"
  local exclude_file
  exclude_file="$(git -C "$project_path" rev-parse --git-path info/exclude 2>/dev/null || echo "")"
  [[ -n "$exclude_file" ]] || return 0
  [[ "$exclude_file" == /* ]] || exclude_file="$project_path/$exclude_file"
  mkdir -p "$(dirname "$exclude_file")"
  if ! grep -qxF "/.worktrees/" "$exclude_file" 2>/dev/null; then
    printf '\n# laravel-dev branch workspaces\n/.worktrees/\n' >> "$exclude_file"
  fi
}

workspace_list() {
  local project="${1:-}"
  if [[ -z "$project" ]]; then
    echo "Usage: laravel-dev workspace list <project>" >&2
    return 1
  fi
  local project_path project_domain
  project_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$project_path" || ! -d "$project_path" ]]; then
    project_path="${SITES_DIR:-$HOME/Sites}/$project"
  fi

  if [[ ! -d "$project_path" ]]; then
    echo "[]"
    return 0
  fi

  project_domain="$(get_project_domain "$project" 2>/dev/null || echo "$project.test")"

  if ! git -C "$project_path" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo "[]"
    return 0
  fi

  python3 -c "
import sys, subprocess, json, os

project_path = sys.argv[1]
project_domain = sys.argv[2]
project = sys.argv[3]

res = []
try:
    out = subprocess.check_output(['git', '-C', project_path, 'worktree', 'list', '--porcelain'], text=True)
    current_item = {}
    for line in (out + '\n').splitlines():
        line = line.strip()
        if not line:
            if current_item and 'worktree' in current_item:
                wt_path = current_item['worktree']
                if '.worktrees' in wt_path:
                    branch = current_item.get('branch', '').replace('refs/heads/', '')
                    sanitized = os.path.basename(wt_path)
                    res.append({
                        'project': project,
                        'branch': branch or sanitized,
                        'sanitized': sanitized,
                        'subdomain': f'{sanitized}.{project_domain}',
                        'url': f'http://{sanitized}.{project_domain}',
                        'path': wt_path,
                        'commit': current_item.get('HEAD', '')[:8],
                        'active': os.path.isdir(wt_path)
                    })
            current_item = {}
            continue

        if line.startswith('worktree '):
            current_item['worktree'] = line.split(' ', 1)[1]
        elif line.startswith('HEAD '):
            current_item['HEAD'] = line.split(' ', 1)[1]
        elif line.startswith('branch '):
            current_item['branch'] = line.split(' ', 1)[1]
except Exception:
    pass

print(json.dumps(res, indent=2))
" "$project_path" "$project_domain" "$project"
}

workspace_create() {
  local project="${1:-}"
  local branch="${2:-}"
  if [[ -z "$project" || -z "$branch" ]]; then
    echo "Usage: laravel-dev workspace create <project> <branch> [source-branch]" >&2
    return 1
  fi
  local source_branch="${3:-}"

  local project_path project_domain php_version php_socket
  project_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$project_path" || ! -d "$project_path" ]]; then
    project_path="${SITES_DIR:-$HOME/Sites}/$project"
  fi

  if [[ ! -d "$project_path" ]]; then
    echo "Error: Project directory '$project_path' not found."
    return 1
  fi

  ensure_git_repository "$project_path"

  local sanitized_branch
  sanitized_branch="$(sanitize_branch_name "$branch")"
  if [[ -z "$sanitized_branch" ]]; then
    echo "Error: Invalid branch name '$branch'."
    return 1
  fi

  project_domain="$(get_project_domain "$project" 2>/dev/null || echo "$project.test")"
  local workspace_domain="${sanitized_branch}.${project_domain}"
  local worktrees_dir="$project_path/.worktrees"
  local target_wt_path="$worktrees_dir/$sanitized_branch"

  mkdir -p "$worktrees_dir"

  if [[ -d "$target_wt_path" ]]; then
    echo "Error: Workspace already exists at '$target_wt_path'."
    return 1
  fi

  echo "Creating Git worktree for branch '$branch' at '$target_wt_path'..."
  if git -C "$project_path" show-ref --verify --quiet "refs/heads/$branch"; then
    git -C "$project_path" worktree add "$target_wt_path" "$branch"
  else
    if [[ -n "$source_branch" ]]; then
      git -C "$project_path" worktree add -b "$branch" "$target_wt_path" "$source_branch"
    else
      git -C "$project_path" worktree add -b "$branch" "$target_wt_path"
    fi
  fi

  # Ensure writable Laravel storage & cache directories exist in the worktree
  if [[ -f "$target_wt_path/artisan" ]]; then
    mkdir -p \
      "$target_wt_path/storage/framework/cache/data" \
      "$target_wt_path/storage/framework/sessions" \
      "$target_wt_path/storage/framework/views" \
      "$target_wt_path/storage/logs" \
      "$target_wt_path/bootstrap/cache"
  fi

  # Keep .worktrees/ out of the main checkout's `git status` / `git add .`
  workspace_exclude_dir "$project_path"

  local ssl_cert="${SSL_CERT_DIR:-/etc/nginx/ssl/laravel-dev}/${project_domain}.pem"
  local ssl_key="${SSL_CERT_DIR:-/etc/nginx/ssl/laravel-dev}/${project_domain}-key.pem"
  local scheme="http"
  if [[ -f "$ssl_cert" && -f "$ssl_key" ]]; then
    # The project certificate is issued for "<domain>" and "*.<domain>", so it covers branch subdomains.
    scheme="https"
  fi

  # Copy .env if exists and update APP_URL
  if [[ -f "$project_path/.env" && ! -f "$target_wt_path/.env" ]]; then
    cp "$project_path/.env" "$target_wt_path/.env"
    sed -i "s|^APP_URL=.*|APP_URL=${scheme}://$workspace_domain|" "$target_wt_path/.env"
  fi

  # vendor/ must be a real copy: PHP resolves symlinks in __DIR__, so a symlinked vendor/
  # makes Composer autoload App\ classes from the MAIN checkout instead of this branch.
  # --reflink=auto makes the copy instant (copy-on-write) on btrfs/xfs.
  if [[ ! -e "$target_wt_path/vendor" ]]; then
    if [[ -d "$project_path/vendor" ]]; then
      echo "Copying vendor/ into the workspace..."
      cp -a --reflink=auto "$project_path/vendor" "$target_wt_path/vendor" 2>/dev/null \
        || cp -a "$project_path/vendor" "$target_wt_path/vendor"
    elif [[ -f "$target_wt_path/composer.json" ]] && command -v composer >/dev/null 2>&1; then
      echo "Running composer install in the workspace..."
      (cd "$target_wt_path" && composer install --no-interaction --no-progress) || echo "Warning: composer install failed; run it manually in $target_wt_path"
    fi
  fi
  # node_modules is only used by build tools, which handle a symlinked folder fine.
  if [[ -d "$project_path/node_modules" && ! -e "$target_wt_path/node_modules" ]]; then
    ln -s "$project_path/node_modules" "$target_wt_path/node_modules"
  fi

  local public_root="$target_wt_path/public"
  if [[ ! -d "$public_root" ]]; then
    public_root="$target_wt_path"
  fi

  php_version="$(get_project_php_version "$project" 2>/dev/null || echo "8.3")"
  php_socket="$(get_php_socket "$php_version" 2>/dev/null || echo "/run/php/php${php_version}-fpm.sock")"

  if command -v nginx >/dev/null 2>&1 && [[ -d /etc/nginx ]]; then
    require_system_access
    local vhost_name="laravel-dev-ws-${project}-${sanitized_branch}"
    local vhost_conf
    vhost_conf="$(get_nginx_config_path "$vhost_name")"

    echo "Configuring Nginx virtual host for '$workspace_domain'..."
    local ssl_block=""
    if [[ "$scheme" == "https" ]]; then
      ssl_block="listen 443 ssl;
    listen [::]:443 ssl;
    ssl_certificate $ssl_cert;
    ssl_certificate_key $ssl_key;"
    fi

    local conf_content="server {
    listen 80;
    listen [::]:80;
    $ssl_block
    server_name $workspace_domain;

    root $public_root;
    index index.php index.html;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php$ {
        try_files \$uri =404;
        include fastcgi.conf;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param DOCUMENT_ROOT \$document_root;
        fastcgi_param PHP_VALUE \"auto_prepend_file=$BASE_DIR/php/debug_prepend.php\";
        fastcgi_pass unix:$php_socket;
    }
}"

    echo "$conf_content" | sudo_cmd tee "$vhost_conf" >/dev/null
    if [[ -d /etc/nginx/sites-enabled && "$vhost_conf" == /etc/nginx/sites-available/* ]]; then
      sudo_cmd ln -sf "$vhost_conf" "/etc/nginx/sites-enabled/$(basename "$vhost_conf")"
    fi
    sudo_cmd systemctl reload nginx 2>/dev/null || true

    if ! getent hosts "$workspace_domain" >/dev/null 2>&1; then
      if ! grep -qE "[[:space:]]${workspace_domain}([[:space:]]|$)" /etc/hosts 2>/dev/null; then
        echo "127.0.0.1 $workspace_domain" | sudo_cmd tee -a /etc/hosts >/dev/null
      fi
    fi
  fi

  echo "Workspace created successfully:"
  echo "  Branch: $branch"
  echo "  Path:   $target_wt_path"
  echo "  URL:    ${scheme}://$workspace_domain"
}

workspace_delete() {
  local project="${1:-}"
  local branch="${2:-}"
  if [[ -z "$project" || -z "$branch" ]]; then
    echo "Usage: laravel-dev workspace delete <project> <branch>" >&2
    return 1
  fi

  local project_path project_domain
  project_path="$(get_project_path "$project" 2>/dev/null || echo "")"
  if [[ -z "$project_path" || ! -d "$project_path" ]]; then
    project_path="${SITES_DIR:-$HOME/Sites}/$project"
  fi

  local sanitized_branch
  sanitized_branch="$(sanitize_branch_name "$branch")"
  if [[ -z "$sanitized_branch" ]]; then
    echo "Error: Invalid branch name '$branch'."
    return 1
  fi
  local target_wt_path="$project_path/.worktrees/$sanitized_branch"

  project_domain="$(get_project_domain "$project" 2>/dev/null || echo "$project.test")"
  local workspace_domain="${sanitized_branch}.${project_domain}"

  echo "Removing workspace for branch '$branch'..."

  local vhost_name="laravel-dev-ws-${project}-${sanitized_branch}"
  if [[ -f "/etc/nginx/sites-available/$vhost_name" || -f "/etc/nginx/conf.d/${vhost_name}.conf" || -f "/etc/nginx/http.d/${vhost_name}.conf" ]] || grep -qE "[[:space:]]${workspace_domain}([[:space:]]|$)" /etc/hosts 2>/dev/null; then
    require_system_access
    remove_nginx_site "$vhost_name"
    sudo_cmd rm -f "/etc/nginx/sites-enabled/laravel-dev-workspace-${project}-${sanitized_branch}.conf" "/etc/nginx/sites-available/laravel-dev-workspace-${project}-${sanitized_branch}.conf" 2>/dev/null || true
    sudo_cmd systemctl reload nginx 2>/dev/null || true

    if grep -qE "[[:space:]]${workspace_domain}([[:space:]]|$)" /etc/hosts 2>/dev/null; then
      sudo_cmd sed -i "/[[:space:]]${workspace_domain}\\([[:space:]]\\|$\\)/d" /etc/hosts 2>/dev/null || true
    fi
  fi

  if [[ -d "$project_path" ]]; then
    git -C "$project_path" worktree remove "$target_wt_path" --force 2>/dev/null || true
    git -C "$project_path" worktree prune 2>/dev/null || true
  fi
  rm -rf "$target_wt_path"

  echo "Workspace '$branch' removed successfully."
}
