#!/usr/bin/env bash
set -euo pipefail

# Node.js version management via fnm / nvm

FNM_DIR="${HOME}/.local/share/laravel-dev/fnm"
FNM_BIN="${FNM_DIR}/fnm"

find_node_manager() {
  if command -v fnm >/dev/null 2>&1; then
    echo "fnm:$(command -v fnm)"
    return 0
  fi
  if [[ -x "$FNM_BIN" ]]; then
    echo "fnm:$FNM_BIN"
    return 0
  fi
  if [[ -s "${NVM_DIR:-$HOME/.nvm}/nvm.sh" ]]; then
    echo "nvm:${NVM_DIR:-$HOME/.nvm}/nvm.sh"
    return 0
  fi
  echo ""
}

ensure_node_manager() {
  local mgr
  mgr="$(find_node_manager)"
  if [[ -n "$mgr" ]]; then
    return 0
  fi

  echo "fnm (Fast Node Manager) not found. Installing into $FNM_DIR..."
  mkdir -p "$FNM_DIR"

  local arch
  arch="$(uname -m)"
  local zip_name="fnm-linux.zip"
  case "$arch" in
    aarch64|arm64) zip_name="fnm-arm64.zip" ;;
    x86_64) zip_name="fnm-linux.zip" ;;
    *) echo "Unsupported architecture for fnm: $arch"; return 1 ;;
  esac

  local tmp_zip="/tmp/${zip_name}"
  if curl -fsSL "https://github.com/Schniz/fnm/releases/latest/download/${zip_name}" -o "$tmp_zip"; then
    unzip -o -q "$tmp_zip" -d "$FNM_DIR"
    chmod +x "$FNM_BIN"
    rm -f "$tmp_zip"
    echo "fnm installed successfully at $FNM_BIN"
    return 0
  fi

  echo "Failed to download fnm binary."
  return 1
}

run_fnm() {
  local mgr
  mgr="$(find_node_manager)"
  if [[ -z "$mgr" ]]; then
    ensure_node_manager
    mgr="$(find_node_manager)"
  fi

  local kind="${mgr%%:*}"
  local bin="${mgr#*:}"

  if [[ "$kind" == "fnm" ]]; then
    "$bin" --fnm-dir "$FNM_DIR/data" "$@"
  elif [[ "$kind" == "nvm" ]]; then
    # shellcheck source=/dev/null
    source "$bin"
    nvm "$@"
  fi
}

node_install() {
  local version="$1"
  ensure_node_manager
  echo "Installing Node.js $version..."
  run_fnm install "$version"
  echo "Node.js $version installed successfully!"
}

list_node_versions() {
  local mgr
  mgr="$(find_node_manager)"
  if [[ -z "$mgr" ]]; then
    if command -v node >/dev/null 2>&1; then
      node -v | sed 's/^v//'
    fi
    return 0
  fi

  local kind="${mgr%%:*}"
  local bin="${mgr#*:}"
  if [[ "$kind" == "fnm" ]]; then
    "$bin" --fnm-dir "$FNM_DIR/data" list 2>/dev/null | awk '{print $1}' | grep -E '^[0-9]+' || true
  elif [[ "$kind" == "nvm" ]]; then
    # shellcheck source=/dev/null
    source "$bin"
    nvm ls --no-colors 2>/dev/null | grep -Eo 'v[0-9]+\.[0-9]+\.[0-9]+' | sed 's/^v//' | sort -u || true
  fi
}

node_use_project() {
  local name="$1"
  local version="$2"

  local dir
  dir="$(get_project_field "$name" "PROJECT_PATH" 2>/dev/null || echo "$LARAVEL_SITES_DIR/$name")"

  if [[ -d "$dir" ]]; then
    printf "%s\n" "$version" > "$dir/.node-version"
  fi

  update_project_record "$name" "NODE_VERSION" "$version"
  echo "Site '$name' configured to use Node.js $version"
}
