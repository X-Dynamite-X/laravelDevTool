#!/usr/bin/env bash
# Laravel Dev - Automatic PHP Version Selector Shim
set -euo pipefail

DIR="$PWD"
PHP_VER=""

while [[ "$DIR" != "/" && -n "$DIR" ]]; do
  if [[ -f "$DIR/.php-version" ]]; then
    PHP_VER="$(head -n1 "$DIR/.php-version" | tr -d '\r\n ')"
    break
  fi
  DIR="$(dirname "$DIR")"
done

if [[ -n "$PHP_VER" && "$PHP_VER" =~ ^[0-9]+\.[0-9]+$ ]]; then
  if command -v "php${PHP_VER}" >/dev/null 2>&1; then
    exec "php${PHP_VER}" "$@"
  fi
fi

# Fallback to system php excluding this shim directory
SHIM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLEAN_PATH="$(echo "$PATH" | tr ':' '\n' | grep -v "^${SHIM_DIR}$" | tr '\n' ':' | sed 's/:$//')"
PATH="$CLEAN_PATH" exec php "$@"
